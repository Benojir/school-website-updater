<?php

function getStudentInfo(PDO $pdo, $student_id)
{
    $stmt = $pdo->prepare("SELECT s.student_id, s.name, s.father_name, s.address, s.student_image, s.class_id, c.class_name, sec.section_name
                            FROM students s
                            LEFT JOIN classes c ON s.class_id = c.id
                            LEFT JOIN sections sec ON s.section_id = sec.id
                            WHERE s.student_id = ?");

    $stmt->execute([$student_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}