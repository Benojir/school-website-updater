<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is logged in
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

// $pdo is assumed to be included from auth-check.php

// 1. Check for POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit();
}

// 2. Validate input data
if (
    empty($_POST['id']) ||
    empty($_POST['class_id']) ||
    !isset($_POST['fee_type']) || // Use !isset to allow '0'
    !isset($_POST['amount'])      // Use !isset to allow 0
) {
    echo json_encode(['success' => false, 'message' => 'All fields are required.']);
    exit();
}

// 3. Sanitize and assign variables
$id = (int)$_POST['id'];
$class_id = (int)$_POST['class_id'];
$fee_type = trim($_POST['fee_type']);
$amount = $_POST['amount'];

// 4. Further validation
if ($id <= 0 || $class_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid ID or Class ID.']);
    exit();
}

if (empty($fee_type)) {
    echo json_encode(['success' => false, 'message' => 'Fee Type cannot be empty.']);
    exit();
}

if (!is_numeric($amount) || $amount < 0) {
    echo json_encode(['success' => false, 'message' => 'Amount must be a non-negative number.']);
    exit();
}

// 5. Update the database
try {
    // Prepare the SQL statement
    $sql = "UPDATE class_wise_additional_fees 
            SET class_id = :class_id, 
                fee_type = :fee_type, 
                amount = :amount 
            WHERE id = :id";
    
    $stmt = $pdo->prepare($sql);
    
    // Execute the statement with bound parameters
    $stmt->execute([
        ':class_id' => $class_id,
        ':fee_type' => $fee_type,
        ':amount'   => $amount,
        ':id'       => $id
    ]);

    // If execute() completes without error, assume success
    echo json_encode(['success' => true, 'message' => 'Fee updated successfully.']);

} catch (PDOException $e) {
    // Handle potential database errors
    // In a real-world app, you should log this error, not show it to the user
    // error_log('Update fee error: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'A database error occurred. Please try again.']);
}

?>