<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Edit Exam Routine - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

if (!hasPermission(PERM_MANAGE_EXAMS)) {
    include_once("../../includes/permission-denied.php");
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Fetch routine details
$stmt = $pdo->prepare("
    SELECT er.*, e.exam_name, c.class_name, s.subject_name 
    FROM exam_routines er
    JOIN exams e ON er.exam_id = e.id
    JOIN classes c ON er.class_id = c.id
    JOIN subjects s ON er.subject_id = s.id
    WHERE er.id = ?
");
$stmt->execute([$id]);
$routine = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$routine) {
    echo "<div class='container py-5'><div class='alert alert-danger'>Routine not found!</div></div>";
    include_once("../../includes/body-close.php");
    exit;
}
?>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-lg border-0">
                <div class="card-header bg-primary text-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4 class="mb-0"><i class="fas fa-edit me-2"></i> Edit Routine</h4>
                        <a href="list-exam-routines.php" class="btn btn-light btn-sm">
                            <i class="fas fa-arrow-left me-1"></i> Back
                        </a>
                    </div>
                </div>

                <div class="card-body p-4">
                    <div class="alert alert-light border mb-4">
                        <div class="row">
                            <div class="col-md-4"><strong>Exam:</strong><br> <?= safe_htmlspecialchars($routine['exam_name']) ?></div>
                            <div class="col-md-4"><strong>Class:</strong><br> <?= safe_htmlspecialchars($routine['class_name']) ?></div>
                            <div class="col-md-4"><strong>Subject:</strong><br> <?= safe_htmlspecialchars($routine['subject_name']) ?></div>
                        </div>
                    </div>

                    <form id="editRoutineForm">
                        <input type="hidden" name="id" value="<?= $routine['id'] ?>">
                        <input type="hidden" name="exam_id" value="<?= $routine['exam_id'] ?>">
                        <input type="hidden" name="class_id" value="<?= $routine['class_id'] ?>">
                        <input type="hidden" name="subject_name" value="<?= safe_htmlspecialchars($routine['subject_name']) ?>">

                        <div class="row g-3 mb-4">
                            <h5 class="text-primary border-bottom pb-2">Marks Distribution</h5>
                            <div class="col-md-6">
                                <label class="form-label">Written Marks (Theory)</label>
                                <input type="number" name="theory_marks" class="form-control" value="<?= $routine['theory_marks'] ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Oral Marks (Practical)</label>
                                <input type="number" name="practical_marks" class="form-control" value="<?= $routine['practical_marks'] ?>" required>
                            </div>
                        </div>

                        <div class="row g-3">
                            <div class="col-md-6 border-end">
                                <h6 class="text-primary mb-3"><i class="fas fa-pen-alt me-1"></i> Written Exam (Theory)</h6>
                                <div class="mb-3">
                                    <label class="form-label">Date</label>
                                    <input type="date" name="theory_exam_date" class="form-control" value="<?= $routine['theory_exam_date'] ?>" required>
                                </div>
                                <div class="row g-2">
                                    <div class="col-6">
                                        <label class="form-label">Start Time</label>
                                        <input type="time" name="theory_start_time" class="form-control" value="<?= date('H:i', strtotime($routine['theory_start_time'])) ?>" step="60" required>
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label">End Time</label>
                                        <input
                                            type="time"
                                            name="theory_end_time"
                                            class="form-control"
                                            value="<?= date('H:i', strtotime($routine['theory_end_time'])) ?>"
                                            required>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <h6 class="text-success mb-3"><i class="fas fa-microphone me-1"></i> Oral Exam (Practical)</h6>
                                <div class="mb-3">
                                    <label class="form-label">Date</label>
                                    <input type="date" name="practical_exam_date" class="form-control" value="<?= $routine['practical_exam_date'] ?>">
                                    <small class="text-muted">Optional if marks are 0</small>
                                </div>
                                <div class="row g-2">
                                    <div class="col-6">
                                        <label class="form-label">Start Time</label>
                                        <input
                                            type="time"
                                            name="practical_start_time"
                                            class="form-control"
                                            value="<?= !empty($routine['practical_start_time']) ? date('H:i', strtotime($routine['practical_start_time'])) : '' ?>">
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label">End Time</label>
                                        <input
                                            type="time"
                                            name="practical_end_time"
                                            class="form-control"
                                            value="<?= !empty($routine['practical_end_time']) ? date('H:i', strtotime($routine['practical_end_time'])) : '' ?>">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mt-4 pt-3 border-top text-end">
                            <button type="submit" id="saveBtn" class="btn btn-primary px-4">
                                <i class="fas fa-save me-1"></i> Update Changes
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#editRoutineForm').submit(function(e) {
            e.preventDefault();
            const submitBtn = $('#saveBtn');
            const originalBtnText = submitBtn.html();

            submitBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1"></span> Updating...');

            $.ajax({
                url: '../../api/admin/put/exam/update-exam-routine.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            title: 'Updated!',
                            text: response.message,
                            icon: 'success',
                            confirmButtonText: 'Back to List',
                            customClass: {
                                popup: 'rounded-4 shadow-lg',
                                confirmButton: 'btn btn-success px-4 py-2'
                            }
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.href = 'list-exam-routines.php';
                            }
                        });
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function() {
                    toastr.error('Server connection error');
                },
                complete: function() {
                    submitBtn.prop('disabled', false).html(originalBtnText);
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>