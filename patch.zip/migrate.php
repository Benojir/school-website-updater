<?php
$config_file_path = 'includes/config.php';
if (file_exists($config_file_path)) {
    include_once($config_file_path);
}

try {
    // Start a transaction
    $pdo->beginTransaction();
    
    // Query 1: Create attendance table
    $sql1 = "CREATE TABLE `attendance` (
        `id` int(11) NOT NULL,
        `student_id` varchar(50) NOT NULL,
        `class_id` int(11) NOT NULL,
        `section_id` int(11) NOT NULL,
        `status` enum('present','late','absent','leave') NOT NULL,
        `time` datetime NOT NULL,
        `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
    $pdo->exec($sql1);
    
    // Query 2: Add primary key
    $sql2 = "ALTER TABLE `attendance` ADD PRIMARY KEY (`id`)";
    $pdo->exec($sql2);
    
    // Query 3: Add indexes
    $sql3 = "ALTER TABLE `attendance`
        ADD KEY `student_id` (`student_id`),
        ADD KEY `class_id` (`class_id`),
        ADD KEY `section_id` (`section_id`)";
    $pdo->exec($sql3);
    
    // Query 4: Set auto increment
    $sql4 = "ALTER TABLE `attendance` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4";
    $pdo->exec($sql4);
    
    // Query 5: Add foreign key constraints
    $sql5 = "ALTER TABLE `attendance`
        ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
        ADD CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE,
        ADD CONSTRAINT `attendance_ibfk_3` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`) ON DELETE CASCADE";
    $pdo->exec($sql5);
    
    // Query 6: Add promoted_date to students table
    $sql6 = "ALTER TABLE `students` ADD `promoted_date` DATE NULL DEFAULT NULL AFTER `admission_date`";
    $pdo->exec($sql6);
    
    // Query 7: Add currency_symbol to website_config table
    $sql7 = "ALTER TABLE `website_config` ADD `currency_symbol` VARCHAR(5) NULL AFTER `timezone`";
    $pdo->exec($sql7);
    
    // Commit the transaction
    $pdo->commit();
    echo "Database schema updated successfully. Created attendance table and added new columns.";
} catch (PDOException $e) {
    // Rollback the transaction if any query fails
    $pdo->rollBack();
    echo "Error updating database schema: " . $e->getMessage();
}