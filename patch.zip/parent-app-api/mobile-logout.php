<?php
require_once '../includes/config.php';
require_once 'mobile-auth.php';

header('Content-Type: application/json');

// Authenticate first
$authData = authenticateMobileRequest($pdo);

// Get token from header
$headers = getallheaders();
$token = str_replace('Bearer ', '', $headers['Authorization']);
$tokenHash = hash('sha256', $token);

// Delete the session
$stmt = $pdo->prepare("DELETE FROM parent_mobile_sessions WHERE token_hash = ?");
$stmt->execute([$tokenHash]);

echo json_encode(['success' => true, 'message' => 'Logout successful']);