<?php
require_once '../includes/config.php';
require_once 'mobile-auth.php';

header('Content-Type: application/json');

// Authenticate the parent first
$parent = authenticateMobileRequest($pdo);

// Get all students associated with this parent
$stmt = $pdo->prepare('
    SELECT 
        s.student_id,
        s.name,
        s.roll_no,
        s.student_image,
        s.father_name,
        s.mother_name,
        s.date_of_birth,
        s.gender,
        s.blood_group,
        s.address,
        c.class_name,
        sec.section_name,
        CONCAT("/parent/dashboard/view-student-details.php?student_id=", s.student_id) as profile_url,
        CONCAT("/uploads/students/", s.student_image) as image_url
    FROM students s
    LEFT JOIN classes c ON s.class_id = c.id
    LEFT JOIN sections sec ON s.section_id = sec.id
    WHERE s.phone_number = ?
    ORDER BY c.id, sec.id, s.roll_no
');
$stmt->execute([$parent['phone_number']]);
$students = $stmt->fetchAll();

// Format data for mobile response
$formattedStudents = [];
foreach ($students as $student) {
    $formattedStudents[] = [
        'student_id' => $student['student_id'],
        'name' => $student['name'],
        'class_name' => $student['class_name'] ?? 'N/A',
        'section_name' => $student['section_name'] ?? 'N/A',
        'roll_no' => $student['roll_no'] ?? 'N/A',
        'father_name' => $student['father_name'] ?? 'N/A',
        'mother_name' => $student['mother_name'] ?? 'N/A',
        'date_of_birth' => $student['date_of_birth'] 
            ? date('d M, Y', strtotime($student['date_of_birth'])) 
            : 'N/A',
        'gender' => $student['gender'] ?? 'N/A',
        'blood_group' => $student['blood_group'] ?? 'N/A',
        'address' => $student['address'] ?? 'N/A',
        'profile_image' => $student['student_image'] !== 'default_student_dp.jpg' 
            ? $student['image_url'] 
            : null,
        'profile_url' => $student['profile_url']
    ];
}

// Return the data
echo json_encode([
    'success' => true,
    'data' => [
        'parent_phone' => $parent['phone_number'],
        'children' => $formattedStudents,
        'count' => count($formattedStudents),
        'fcm_token' => $parent['fcm_token'] ?? null
    ]
]);