<?php
require_once '../includes/config.php';
require_once 'mobile-auth.php';

header('Content-Type: application/json');

// Authenticate the parent first
$parent = authenticateMobileRequest($pdo);

// Validate student_id parameter
if (empty($_GET['student_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Student ID is required']);
    exit;
}

$studentId = sanitize_input($_GET['student_id']);

// Check if parent has permission to access this student
if (!hasParentAccessToStudent($parent['parent_id'], $studentId)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'You do not have permission to access this student']);
    exit;
}

// Get student data with class and section names
$student = getStudentDataWithClassInfo($studentId);
if (!$student) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Student not found']);
    exit;
}

// Get all financial data for the student
$financeData = getStudentFinanceData($studentId);

// Get download permissions
$downloadPermissions = getDownloadPermissions($studentId, $financeData['fee_summary']['all_fees_paid']);

// Return combined student data
echo json_encode([
    'success' => true,
    'data' => [
        'personal_info' => filterStudentData($student),
        'financial_info' => $financeData,
        'download_permissions' => $downloadPermissions
    ]
]);

/**
 * Get student data with class and section information
 */
function getStudentDataWithClassInfo($studentId) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT s.*, 
                          c.class_name,
                          sec.section_name,
                          CONCAT(c.class_name, ' - ', sec.section_name) AS full_class_section
                          FROM students s
                          LEFT JOIN classes c ON s.class_id = c.id
                          LEFT JOIN sections sec ON s.section_id = sec.id
                          WHERE s.student_id = ?");
    $stmt->execute([$studentId]);
    return $stmt->fetch();
}

/**
 * Filter student data before returning to client
 */
function filterStudentData($student) {
    return [
        'student_id' => $student['student_id'],
        'name' => $student['name'],
        'father_name' => $student['father_name'],
        'mother_name' => $student['mother_name'],
        'class_info' => [
            'class_id' => $student['class_id'],
            'class_name' => $student['class_name'],
            'section_id' => $student['section_id'],
            'section_name' => $student['section_name'],
            'full_class_section' => $student['full_class_section']
        ],
        'roll_no' => $student['roll_no'],
        'phone_number' => $student['phone_number'],
        'alternate_phone_number' => $student['alternate_phone_number'],
        'email' => $student['email'],
        'gender' => $student['gender'],
        'date_of_birth' => $student['date_of_birth'],
        'blood_group' => $student['blood_group'],
        'status' => $student['status'],
        'student_image' => $student['student_image'],
        'father_occupation' => $student['father_occupation'],
        'mother_occupation' => $student['mother_occupation'],
        'address' => $student['address'],
        'admission_date' => $student['admission_date']
    ];
}

/**
 * Get all financial data for a student
 */
function getStudentFinanceData($studentId) {
    global $pdo;
    
    $data = [];
    
    // 1. Get basic student info
    $data['student_info'] = getStudentBasicInfo($studentId);
    
    // 2. Get fee summary
    $data['fee_summary'] = getFeeSummary($studentId);
    
    // 3. Get wallet data
    $data['wallet'] = getWalletData($studentId);
    
    // 4. Get wallet transactions (last 10)
    $data['wallet_transactions'] = getWalletTransactions($studentId);
    
    // 5. Get unpaid fees with partial payments
    $data['unpaid_fees'] = getUnpaidFeesWithPartialPayments($studentId);
    
    // 6. Get paid fees with partial payments
    $data['paid_fees'] = getPaidFeesWithPartialPayments($studentId);

    // 7. Get admission fees data
    $data['admission_fees'] = getAdmissionFees($studentId);
    
    // 8. Get payment history (last 10)
    $data['payment_history'] = getPaymentHistory($studentId);
    
    return $data;
}

/**
 * Get basic student info for financial data
 */
function getStudentBasicInfo($studentId) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT 
            s.student_id, 
            s.name, 
            s.student_image,
            c.class_name,
            sec.section_name,
            s.roll_no
        FROM students s
        LEFT JOIN classes c ON s.class_id = c.id
        LEFT JOIN sections sec ON s.section_id = sec.id
        WHERE s.student_id = ?
    ");
    $stmt->execute([$studentId]);
    return $stmt->fetch();
}

/**
 * Get fee summary with totals
 */
function getFeeSummary($studentId) {
    global $pdo;
    
    $summary = [
        'total_amount' => 0,
        'total_paid' => 0,
        'total_unpaid' => 0,
        'all_fees_paid' => true
    ];
    
    // Get paid fees total
    $stmt = $pdo->prepare("
        SELECT 
            SUM(actual_amount) as total_amount,
            SUM(total_paid_amount) as total_paid
        FROM student_full_paid_fees 
        WHERE student_id = ?
    ");
    $stmt->execute([$studentId]);
    $paidResult = $stmt->fetch();
    
    if ($paidResult) {
        $summary['total_amount'] += (float)$paidResult['total_amount'];
        $summary['total_paid'] += (float)$paidResult['total_paid'];
    }
    
    // Get unpaid fees total
    $stmt = $pdo->prepare("
        SELECT 
            SUM(actual_amount) as total_amount,
            SUM(unpaid_amount) as total_unpaid
        FROM student_unpaid_fees 
        WHERE student_id = ?
    ");
    $stmt->execute([$studentId]);
    $unpaidResult = $stmt->fetch();
    
    if ($unpaidResult) {
        $summary['total_amount'] += (float)$unpaidResult['total_amount'];
        $summary['total_unpaid'] += (float)$unpaidResult['total_unpaid'];
    }

    // Get admission unpaid fees total
    $stmt = $pdo->prepare("
        SELECT 
            SUM(unpaid_amount) as total_unpaid
        FROM student_admission_fees 
        WHERE student_id = ?
    ");
    $stmt->execute([$studentId]);
    $admissionUnpaidResult = $stmt->fetch();

    if ($admissionUnpaidResult) {
        $summary['total_unpaid'] += (float)$admissionUnpaidResult['total_unpaid'];
    }
    
    $summary['all_fees_paid'] = ($summary['total_unpaid'] <= 0);
    
    return $summary;
}

/**
 * Get wallet data
 */
function getWalletData($studentId) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT * FROM student_wallet WHERE student_id = ?");
    $stmt->execute([$studentId]);
    return $stmt->fetch() ?: ['balance' => 0.00];
}

/**
 * Get wallet transactions (last 10)
 */
function getWalletTransactions($studentId) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT 
            id,
            amount,
            transaction_type,
            description,
            created_at
        FROM wallet_transactions 
        WHERE student_id = ? 
        ORDER BY created_at DESC
        LIMIT 10
    ");
    $stmt->execute([$studentId]);
    return $stmt->fetchAll();
}

/**
 * Get unpaid fees with partial payments
 */
function getUnpaidFeesWithPartialPayments($studentId) {
    global $pdo;
    
    // Get unpaid fees
    $stmt = $pdo->prepare("
        SELECT 
            id,
            month_year,
            actual_amount,
            unpaid_amount,
            discount_amount,
            remark,
            updated_at
        FROM student_unpaid_fees 
        WHERE student_id = ? 
        ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC
    ");
    $stmt->execute([$studentId]);
    $unpaidFees = $stmt->fetchAll();
    
    // Get partial payments for each unpaid fee
    foreach ($unpaidFees as &$unpaidFee) {
        $stmt = $pdo->prepare("
            SELECT 
                id,
                month_year,
                partial_paid_amount,
                method,
                remark,
                created_at
            FROM student_partial_payments 
            WHERE unpaid_fees_id = ?
            ORDER BY created_at ASC
        ");
        $stmt->execute([$unpaidFee['id']]);
        $unpaidFee['partial_payments'] = $stmt->fetchAll();
    }
    
    return $unpaidFees;
}

/**
 * Get paid fees with partial payments
 */
function getPaidFeesWithPartialPayments($studentId) {
    global $pdo;
    
    // Get paid fees
    $stmt = $pdo->prepare("
        SELECT 
            id,
            month_year,
            actual_amount,
            total_paid_amount,
            discount_amount,
            remark,
            created_at
        FROM student_full_paid_fees 
        WHERE student_id = ? 
        ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC
    ");
    $stmt->execute([$studentId]);
    $paidFees = $stmt->fetchAll();
    
    // Get partial payments for each paid fee
    foreach ($paidFees as &$paidFee) {
        $stmt = $pdo->prepare("
            SELECT 
                id,
                month_year,
                partial_paid_amount,
                method,
                remark,
                created_at
            FROM student_partial_payments 
            WHERE full_paid_fees_id = ?
            ORDER BY created_at ASC
        ");
        $stmt->execute([$paidFee['id']]);
        $paidFee['partial_payments'] = $stmt->fetchAll();
    }
    
    return $paidFees;
}
/**
 * Get admission fees
 */
function getAdmissionFees($studentId) {
    global $pdo;

    $unpaid_fees = [];
    $paid_fees = [];

    // Unpaid fees
    $stmt = $pdo->prepare("
    SELECT student_admission_fees.*, classes.class_name
    FROM student_admission_fees
    JOIN classes ON classes.id = student_admission_fees.class_id
    WHERE student_admission_fees.student_id = ? AND student_admission_fees.payment_status = 'unpaid';
    ");
    $stmt->execute([$studentId]);
    $unpaid_fees = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Paid fees
    $stmt = $pdo->prepare("
    SELECT student_admission_fees.*, classes.class_name
    FROM student_admission_fees
    JOIN classes ON classes.id = student_admission_fees.class_id
    WHERE student_admission_fees.student_id = ? AND student_admission_fees.payment_status = 'paid';
    ");
    $stmt->execute([$studentId]);
    $paid_fees = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return [
        'unpaid_fees' => $unpaid_fees,
        'paid_fees' => $paid_fees
    ];
}


/**
 * Get payment history (last 10)
 */
function getPaymentHistory($studentId) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT 
            id,
            payment_amount,
            payment_date,
            method,
            remark,
            updated_at
        FROM student_payment_history 
        WHERE student_id = ? 
        ORDER BY payment_date DESC
        LIMIT 20
    ");
    $stmt->execute([$studentId]);
    return $stmt->fetchAll();
}

/**
 * Get download permissions
 */
function getDownloadPermissions($studentId, $allFeesPaid) {
    global $pdo;
    
    $permissions = [
        'can_download_admit' => $allFeesPaid,
        'can_download_marksheet' => $allFeesPaid,
        'has_admit_override' => false,
        'has_marksheet_override' => false
    ];
    
    // Check if there are any permission overrides
    $stmt = $pdo->prepare("
        SELECT 
            override_admit_check,
            allow_admit_card,
            override_marksheet_check,
            allow_marksheet
        FROM student_permissions
        WHERE student_id = ?
    ");
    $stmt->execute([$studentId]);
    $permissionData = $stmt->fetch();
    
    if ($permissionData) {
        // Check admit card override
        if ($permissionData['override_admit_check']) {
            $permissions['can_download_admit'] = $permissionData['allow_admit_card'];
            $permissions['has_admit_override'] = true;
        }
        
        // Check marksheet override
        if ($permissionData['override_marksheet_check']) {
            $permissions['can_download_marksheet'] = $permissionData['allow_marksheet'];
            $permissions['has_marksheet_override'] = true;
        }
    }
    
    return $permissions;
}