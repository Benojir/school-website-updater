<?php
require_once '../includes/config.php';
require_once 'mobile-auth.php';

header('Content-Type: application/json');

// Authenticate the parent first
$parent = authenticateMobileRequest($pdo);

// Validate student_id parameter
if (empty($_GET['student_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Student ID is required']);
    exit;
}

$studentId = sanitize_input($_GET['student_id']);

// Check if parent has permission to access this student
if (!hasParentAccessToStudent($parent['parent_id'], $studentId)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'You do not have permission to access this student']);
    exit;
}

// Get student data with current class information
$student = getStudentWithClassInfo($studentId);
if (!$student) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Student not found']);
    exit;
}

// Get all released admit cards for the student's current class
$admitCards = getStudentAdmitCards($student['class_id'], $studentId);

// Return the data
echo json_encode([
    'success' => true,
    'data' => [
        'student_info' => [
            'student_id' => $student['student_id'],
            'name' => $student['name'],
            'class_name' => $student['class_name'],
            'section_name' => $student['section_name'],
            'roll_no' => $student['roll_no'],
            'student_image' => $student['student_image']
        ],
        'admit_cards' => $admitCards,
        'download_permissions' => getDownloadPermissions($studentId, areAllFeesPaid($studentId))
    ]
]);

/**
 * Get student data with class information
 */
function getStudentWithClassInfo($studentId)
{
    global $pdo;

    $stmt = $pdo->prepare("SELECT s.student_id, s.name, s.roll_no, s.student_image,
                          c.class_name, s.class_id, s.section_id
                          FROM students s 
                          JOIN classes c ON s.class_id = c.id 
                          WHERE s.student_id = ?");
    $stmt->execute([$studentId]);
    $studentInfo = $stmt->fetch();

    $studentInfo['section_name'] = "";

    if (!empty($studentInfo['section_id'])) {
        $stmt = $pdo->prepare("SELECT section_name FROM sections WHERE id = ? LIMIT 1");
        $stmt->execute([$studentInfo['section_id']]);
        $sectionInfo = $stmt->fetch();
        $studentInfo['section_name'] = $sectionInfo['section_name'];
    }

    return $studentInfo;
}

/**
 * Get all released admit cards for a student's class
 */
function getStudentAdmitCards($classId, $studentId)
{
    global $pdo;

    $stmt = $pdo->prepare("SELECT ea.id, e.exam_name, e.exam_date, ea.release_date, ea.status,
                          CONCAT('/download-admit-card.php?admit_id=', ea.id, '&student_id=', ?) as download_url
                          FROM exam_admit_releases ea
                          JOIN exams e ON ea.exam_id = e.id
                          WHERE ea.class_id = ? 
                          AND ea.status = 'released'
                          ORDER BY e.exam_date DESC");
    $stmt->execute([$studentId, $classId]);

    $admitCards = $stmt->fetchAll();

    // Format dates and add additional fields
    foreach ($admitCards as &$card) {
        $card['exam_date_formatted'] = date('d M Y', strtotime($card['exam_date']));
        $card['release_date_formatted'] = date('d M Y H:i', strtotime($card['release_date']));
        $card['can_download'] = canDownloadAdmitCard($studentId);
    }

    return $admitCards;
}

/**
 * Check if all fees are paid for a student
 */
function areAllFeesPaid($studentId)
{
    global $pdo;

    $stmt = $pdo->prepare("SELECT SUM(unpaid_amount) as total_unpaid 
                          FROM student_unpaid_fees 
                          WHERE student_id = ?");
    $stmt->execute([$studentId]);
    $result = $stmt->fetch();

    return ($result && $result['total_unpaid'] <= 0);
}

/**
 * Check if student can download admit card
 */
function canDownloadAdmitCard($studentId)
{
    global $pdo;

    // First check if there's an override permission
    $stmt = $pdo->prepare("SELECT override_admit_check, allow_admit_card 
                          FROM student_permissions 
                          WHERE student_id = ?");
    $stmt->execute([$studentId]);
    $permission = $stmt->fetch();

    if ($permission && $permission['override_admit_check']) {
        return (bool)$permission['allow_admit_card'];
    }

    // If no override, check if all fees are paid
    return areAllFeesPaid($studentId);
}

/**
 * Get download permissions (same as in get-student-data.php)
 */
function getDownloadPermissions($studentId, $allFeesPaid)
{
    global $pdo;

    $permissions = [
        'can_download_admit' => $allFeesPaid,
        'can_download_marksheet' => $allFeesPaid,
        'has_override' => false
    ];

    // Check if there are any permission overrides
    $stmt = $pdo->prepare("SELECT 
                          override_admit_check,
                          allow_admit_card,
                          override_marksheet_check,
                          allow_marksheet
                          FROM student_permissions
                          WHERE student_id = ?");
    $stmt->execute([$studentId]);
    $permissionData = $stmt->fetch();

    if ($permissionData) {
        // Check admit card override
        if ($permissionData['override_admit_check']) {
            $permissions['can_download_admit'] = $permissionData['allow_admit_card'];
            $permissions['has_override'] = true;
        }

        // Check marksheet override
        if ($permissionData['override_marksheet_check']) {
            $permissions['can_download_marksheet'] = $permissionData['allow_marksheet'];
            $permissions['has_override'] = true;
        }
    }

    return $permissions;
}
