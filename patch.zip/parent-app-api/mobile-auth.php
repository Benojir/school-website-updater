<?php
require_once '../includes/config.php';

function authenticateMobileRequest($pdo) {
    $headers = getallheaders();
    
    // Check Authorization header
    if (empty($headers['Authorization'])) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Authorization token required']);
        exit;
    }

    // Extract token
    $authHeader = $headers['Authorization'];
    $token = str_replace('Bearer ', '', $authHeader);
    
    if (empty($token)) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid token format']);
        exit;
    }

    // Hash the token for database comparison
    $tokenHash = hash('sha256', $token);
    $currentDateTime = date('Y-m-d H:i:s');

    // Find valid session
    $stmt = $pdo->prepare("SELECT s.*, p.phone_number, p.student_ids 
                          FROM parent_mobile_sessions s
                          JOIN parent_accounts p ON s.parent_id = p.id
                          WHERE s.token_hash = ? AND s.expires_at > ?");
    $stmt->execute([$tokenHash, $currentDateTime]);
    $session = $stmt->fetch();

    if (!$session) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
        exit;
    }

    // Update session expiry (optional - refresh on each request)
    $newExpiry = date('Y-m-d H:i:s', strtotime('+7 days'));
    $stmt = $pdo->prepare("UPDATE parent_mobile_sessions SET expires_at = ? WHERE id = ?");
    $stmt->execute([$newExpiry, $session['id']]);

    // Update last activity timestamp
    $stmt = $pdo->prepare("UPDATE parent_mobile_sessions SET last_activity = ? WHERE id = ?");
    $stmt->execute([date('Y-m-d H:i:s'), $session['id']]);

    return [
        'parent_id' => $session['parent_id'],
        'phone_number' => $session['phone_number'],
        'student_ids' => explode(',', $session['student_ids']),
        'session_id' => $session['id'],
        'device_id' => $session['device_id'],
        'fcm_token' => $session['fcm_token'] ?? null
    ];
}

/**
 * Check if parent has access to the requested student
 */
function hasParentAccessToStudent($parentId, $studentId) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT 1 FROM students 
                          WHERE student_id = ? 
                          AND (phone_number = (SELECT phone_number FROM parent_accounts WHERE id = ?))
                          LIMIT 1");
    $stmt->execute([$studentId, $parentId]);
    
    if ($stmt->fetch()) {
        return true;
    }
    
    $stmt = $pdo->prepare("SELECT 1 FROM parent_accounts 
                          WHERE id = ? 
                          AND FIND_IN_SET(?, student_ids)");
    $stmt->execute([$parentId, $studentId]);
    
    return (bool)$stmt->fetch();
}