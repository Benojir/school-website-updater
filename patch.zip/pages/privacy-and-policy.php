<?php
include_once("../includes/header-open.php");
echo "<title>Privacy & Policy - " . $school_name . "</title>";
include_once("../includes/header-close.php");
?>

<style>
  body {
    background-color: #f8f9fa;
  }

  .logo-container {
    text-align: center;
    padding: 1.5rem 0;
  }

  .logo-container .navbar-brand {
    display: block;
    text-decoration: none;
  }

  .navbar-brand img {
    height: 100px;
    width: 100px;
    object-fit: cover;
    border-radius: 50%;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }

  .navbar-brand-text {
    color: var(--primary-color);
    text-transform: uppercase;
    font-size: 2rem;
    text-align: center;
    font-family: "Oswald", sans-serif;
    font-weight: 700;
    margin: 1rem 0;
  }

  .card-body h3 {
    margin-top: 2rem;
    color: #0056b3;
    font-size: 1.4rem;
    font-weight: 600;
  }

  .card-body ul {
    padding-left: 1.25rem;
    margin-bottom: 1.5rem;
  }

  .card-body p {
    margin-bottom: 1rem;
  }

  @media (max-width: 768px) {
    .navbar-brand-text {
      font-size: 1.4rem;
    }

    .card-body h3 {
      font-size: 1.2rem;
    }
  }
</style>

<div class="container mt-4 mb-5">

  <div class="logo-container">
    <a class="navbar-brand" href="/">
      <img src="../uploads/school/logo-square.png" alt="School Logo" onerror="this.style.display='none'">
      <div class="navbar-brand-text"><?= safe_htmlspecialchars($schoolInfo['name']); ?></div>
    </a>
  </div>

  <div class="card shadow-lg border-0 rounded-lg">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
      <h4 class="mb-0 py-2"><i class="fa-solid fa-bullhorn me-2"></i> Privacy & Policy</h4>
      <a href="../" class="btn btn-light btn-sm">
        <i class="fas fa-arrow-left me-1"></i> Back to Home
      </a>
    </div>

    <div class="card-body p-4">
      <h3>Privacy Policy</h3>
      <p>This Privacy Policy explains how <strong><?= $schoolInfo['name'] ?></strong> collects, uses, and protects user data on this website.</p>

      <h3>1. Information We Collect</h3>
      <ul>
        <li>Student and parent names</li>
        <li>Contact information (phone, email, address)</li>
        <li>Academic details and fee transactions</li>
      </ul>

      <h3>2. How We Use This Information</h3>
      <ul>
        <li>To manage academic records and fee payments</li>
        <li>To communicate with students and parents</li>
        <li>To send important updates, reminders, and receipts</li>
      </ul>

      <h3>3. Payment Security</h3>
      <p>All online payments are securely processed via trusted payment gateways. We do not store sensitive payment information on our servers.</p>

      <h3>4. Data Sharing</h3>
      <p>We do not sell or share your personal data with third parties except where required by law.</p>

      <h3>5. Use of Cookies</h3>
      <p>Cookies may be used to enhance your experience. You can disable them in your browser settings if preferred.</p>

      <h3>6. Changes to This Policy</h3>
      <p>We may update this Privacy Policy occasionally. We encourage you to check this page regularly for any updates.</p>

      <h3>7. Contact Us</h3>
      <p>If you have any questions or concerns about this policy, please contact us at <strong><?= safe_htmlspecialchars($schoolInfo['email']) ?></strong> or call us at <strong><?= safe_htmlspecialchars($schoolInfo['phone']) ?></strong>.</p>
    </div>
  </div>
</div>
<?php include_once("../includes/body-close.php");?>