<?php
include_once("../includes/header-open.php");
echo "<title>School Notices - " . $school_name . "</title>";
include_once("../includes/header-close.php");

// Pagination settings
$itemsPerPage = 36; // Number of images per page
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($currentPage < 1) $currentPage = 1;

// Count total images
$stmt = $pdo->prepare("SELECT COUNT(*) FROM gallery");
$stmt->execute();
$totalImages = $stmt->fetchColumn();

// Calculate total pages
$totalPages = ceil($totalImages / $itemsPerPage);

// Adjust current page if it's out of bounds
if ($currentPage > $totalPages && $totalPages > 0) {
    $currentPage = $totalPages;
}

// Fetch gallery images for current page
$offset = ($currentPage - 1) * $itemsPerPage;
$stmt = $pdo->prepare("SELECT * FROM gallery ORDER BY event_date DESC LIMIT :limit OFFSET :offset");
$stmt->bindValue(':limit', $itemsPerPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$gallery_images = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<style>
    :root {
        --card-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        --card-hover-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }

    body {
        background-color: #f8f9fa;
    }

    .logo-container {
        text-align: center;
        padding: 1.5rem 0;
    }

    .logo-container .navbar-brand {
        display: block;
        text-decoration: none;
    }

    .navbar-brand img {
        height: 100px;
        width: 100px;
        object-fit: cover;
        border-radius: 50%;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .navbar-brand-text {
        color: var(--primary-color);
        text-transform: uppercase;
        font-size: 2rem;
        white-space: normal;
        word-wrap: break-word;
        text-align: center;
        max-width: 100%;
        font-family: "Oswald", sans-serif;
        font-optical-sizing: auto;
        font-weight: 700;
        font-style: normal;
        margin: 1rem 0;
    }

    .gallery-images-container {
        display: grid;
        grid-template-columns: repeat(6, 1fr);
        gap: 1rem;
        width: 100%;
    }

    .gallery-images-container .gallery-item {
        border-radius: 0.8rem;
        overflow: hidden;
        width: 100%;
    }

    .gallery-images-container img {
        width: 100%;
        cursor: pointer;
    }

    .pagination {
        justify-content: center;
        margin-top: 20px;
    }

    .page-item.active .page-link {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
    }

    .page-link {
        color: var(--primary-color);
    }

    /* Responsive adjustments */
    @media (max-width: 991px) {
        .gallery-images-container {
            grid-template-columns: repeat(3, 1fr);
        }
    }

    @media (max-width: 440px) {
        .gallery-images-container {
            grid-template-columns: repeat(2, 1fr);
        }
    }
</style>

<div class="container mt-4 mb-5">

    <div class="logo-container">
        <a class="navbar-brand" href="/">
            <img src="../uploads/school/logo-square.png" alt="School Logo" onerror="this.style.display='none'">
            <div class="navbar-brand-text"><?= safe_htmlspecialchars($schoolInfo['name']); ?></div>
        </a>
    </div>

    <div class="card shadow-lg border-0 rounded-lg">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0 py-2"><i class="fa-solid fa-camera me-2"></i> Photo Gallery</h4>
            <a href="../" class="btn btn-light btn-sm">
                <i class="fas fa-arrow-left me-1"></i> Back to Home
            </a>
        </div>

        <div class="card-body p-4">
            <div class="row">
                <?php if (empty($gallery_images)): ?>
                    <div class="col-12">
                        <p class="text-center text-muted">No images found.</p>
                    </div>
                <?php else: ?>
                    <div class="gallery-images-container col-12">
                        <?php foreach ($gallery_images as $image):
                            $formattedDate = (new DateTime($image['event_date']))->format('d F Y');
                            $caption =  $image['caption'] . '&nbsp;&nbsp;(' . $formattedDate . ')';
                            $photo_url =  $image['photo_url'];
                            $thumbnail = $image['thumbnail_url']; ?>
                            <div class="gallery-item shadow" data-caption="<?= $caption ?>" data-fancybox data-src="<?= $photo_url ?>">
                                <img src="<?= $thumbnail ?>" alt="<?= $caption ?>">
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                        <nav aria-label="Gallery pagination">
                            <ul class="pagination">
                                <?php if ($currentPage > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?= $currentPage - 1 ?>" aria-label="Previous">
                                            <span aria-hidden="true">&laquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                    <li class="page-item <?= $i === $currentPage ? 'active' : '' ?>">
                                        <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                                    </li>
                                <?php endfor; ?>

                                <?php if ($currentPage < $totalPages): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?= $currentPage + 1 ?>" aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include_once("../includes/body-close.php"); ?>