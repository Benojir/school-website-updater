<?php
include_once("../includes/header-open.php");
echo "<title>School Videos - " . $school_name . "</title>";
include_once("../includes/header-close.php");

// Pagination settings
$itemsPerPage = 18; // Videos per page
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($currentPage < 1) $currentPage = 1;

// Count total videos
$stmt = $pdo->prepare("SELECT COUNT(*) FROM gallery_videos");
$stmt->execute();
$totalVideos = $stmt->fetchColumn();

// Calculate total pages
$totalPages = ceil($totalVideos / $itemsPerPage);

// Adjust current page if out of bounds
if ($currentPage > $totalPages && $totalPages > 0) {
    $currentPage = $totalPages;
}

// Fetch videos for current page
$offset = ($currentPage - 1) * $itemsPerPage;
$stmt = $pdo->prepare("SELECT * FROM gallery_videos ORDER BY event_date DESC LIMIT :limit OFFSET :offset");
$stmt->bindValue(':limit', $itemsPerPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$videos = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<style>
    :root {
        --card-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        --card-hover-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        --video-aspect-ratio: 56.25%; /* 16:9 aspect ratio */
    }

    body {
        background-color: #f8f9fa;
    }

    .logo-container {
        text-align: center;
        padding: 1.5rem 0;
    }

    .logo-container .navbar-brand {
        display: block;
        text-decoration: none;
    }

    .navbar-brand img {
        height: 100px;
        width: 100px;
        object-fit: cover;
        border-radius: 50%;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .navbar-brand-text {
        color: var(--primary-color);
        text-transform: uppercase;
        font-size: 2rem;
        white-space: normal;
        word-wrap: break-word;
        text-align: center;
        max-width: 100%;
        font-family: "Oswald", sans-serif;
        font-optical-sizing: auto;
        font-weight: 700;
        font-style: normal;
        margin: 1rem 0;
    }

    .video-gallery-container {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
        gap: 1.5rem;
        width: 100%;
    }

    .video-card {
        border-radius: 0.8rem;
        overflow: hidden;
        box-shadow: var(--card-shadow);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        background: white;
    }

    .video-card:hover {
        transform: translateY(-5px);
        box-shadow: var(--card-hover-shadow);
    }

    .video-thumbnail {
        position: relative;
        padding-bottom: var(--video-aspect-ratio);
        background: #000;
        cursor: pointer;
    }

    .video-thumbnail img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .play-icon {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 60px;
        height: 60px;
        background: rgba(255, 255, 255, 0.8);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.3s ease;
    }

    .play-icon i {
        color: #ff0000;
        font-size: 24px;
        margin-left: 5px;
    }

    .video-thumbnail:hover .play-icon {
        background: rgba(255, 255, 255, 0.95);
        transform: translate(-50%, -50%) scale(1.1);
    }

    .video-info {
        padding: 1rem;
    }

    .video-title {
        font-weight: 600;
        margin-bottom: 0.5rem;
        color: #333;
        display: -webkit-box;
        line-clamp: 2;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }

    .video-date {
        color: #666;
        font-size: 0.9rem;
    }

    .pagination {
        justify-content: center;
        margin-top: 30px;
    }

    .page-item.active .page-link {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
    }

    .page-link {
        color: var(--primary-color);
    }

    .video-modal .modal-dialog {
        max-width: 800px;
    }

    .video-modal .modal-body {
        padding: 0;
        position: relative;
        padding-bottom: var(--video-aspect-ratio);
        height: 0;
        overflow: hidden;
    }

    .video-modal iframe {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border: none;
    }

    @media (max-width: 767px) {
        .video-gallery-container {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="container mt-4 mb-5">
    <div class="logo-container">
        <a class="navbar-brand" href="/">
            <img src="../uploads/school/logo-square.png" alt="School Logo" onerror="this.style.display='none'">
            <div class="navbar-brand-text"><?= safe_htmlspecialchars($schoolInfo['name']); ?></div>
        </a>
    </div>

    <div class="card shadow-lg border-0 rounded-lg">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0 py-2"><i class="fa-solid fa-video me-2"></i> Video Gallery</h4>
            <a href="../" class="btn btn-light btn-sm">
                <i class="fas fa-arrow-left me-1"></i> Back to Home
            </a>
        </div>

        <div class="card-body p-4">
            <div class="row">
                <?php if (empty($videos)): ?>
                    <div class="col-12">
                        <p class="text-center text-muted">No videos found.</p>
                    </div>
                <?php else: ?>
                    <div class="video-gallery-container col-12">
                        <?php foreach ($videos as $video): 
                            $formattedDate = (new DateTime($video['event_date']))->format('d F Y');
                            $thumbnailUrl = "https://img.youtube.com/vi/{$video['video_yt_id']}/maxresdefault.jpg";
                            ?>
                            <div class="video-card">
                                <div class="video-thumbnail" data-video-id="<?= $video['video_yt_id'] ?>">
                                    <img loading="lazy" src="<?= $thumbnailUrl ?>" alt="<?= safe_htmlspecialchars($video['video_title']) ?>" 
                                         onerror="this.src='https://img.youtube.com/vi/<?= $video['video_yt_id'] ?>/hqdefault.jpg'">
                                    <div class="play-icon">
                                        <i class="fas fa-play"></i>
                                    </div>
                                </div>
                                <div class="video-info">
                                    <h5 class="video-title"><?= safe_htmlspecialchars($video['video_title']) ?></h5>
                                    <div class="video-date">
                                        <i class="far fa-calendar-alt me-1"></i> <?= $formattedDate ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                        <nav aria-label="Video pagination">
                            <ul class="pagination">
                                <?php if ($currentPage > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?= $currentPage - 1 ?>" aria-label="Previous">
                                            <span aria-hidden="true">&laquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                    <li class="page-item <?= $i === $currentPage ? 'active' : '' ?>">
                                        <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                                    </li>
                                <?php endfor; ?>

                                <?php if ($currentPage < $totalPages): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?= $currentPage + 1 ?>" aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Video Modal -->
<div class="modal fade video-modal" id="videoModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="videoModalTitle"></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- YouTube iframe will be inserted here by jQuery -->
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Initialize video modal
    var videoModal = new bootstrap.Modal(document.getElementById('videoModal'));
    var videoModalTitle = $('#videoModalTitle');
    var videoModalBody = $('.video-modal .modal-body');
    
    // Handle video thumbnail click
    $('.video-thumbnail').click(function() {
        var videoId = $(this).data('video-id');
        var videoTitle = $(this).siblings('.video-info').find('.video-title').text();
        
        // Set modal title
        videoModalTitle.text(videoTitle);
        
        // Create iframe
        var iframe = $('<iframe>', {
            src: 'https://www.youtube.com/embed/' + videoId + '?autoplay=1&rel=0',
            allow: 'autoplay; encrypted-media',
            allowfullscreen: true
        });
        
        // Clear previous iframe and add new one
        videoModalBody.empty().append(iframe);
        
        // Show modal
        videoModal.show();
    });
    
    // Clear iframe when modal is closed to stop video playback
    $('#videoModal').on('hidden.bs.modal', function() {
        videoModalBody.empty();
    });
});
</script>

<?php include_once("../includes/body-close.php"); ?>