<?php
include_once("../includes/header-open.php");
echo "<title>School Notices - " . $school_name . "</title>";
include_once("../includes/header-close.php");

// Pagination settings
$notices_per_page = 10;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $notices_per_page;

// Fetch total number of notices
$total_stmt = $pdo->prepare("SELECT COUNT(*) FROM notices");
$total_stmt->execute();
$total_notices = $total_stmt->fetchColumn();
$total_pages = ceil($total_notices / $notices_per_page);

// Fetch notices for the current page
$stmt = $pdo->prepare("SELECT * FROM notices ORDER BY notice_date DESC LIMIT :limit OFFSET :offset");
$stmt->bindParam(':limit', $notices_per_page, PDO::PARAM_INT);
$stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$notices = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
    :root {
        --card-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        --card-hover-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }

    body {
        background-color: #f8f9fa;
    }

    .logo-container {
        text-align: center;
        padding: 1.5rem 0;
    }

    .logo-container .navbar-brand {
        display: block;
        text-decoration: none;
    }

    .navbar-brand img {
        height: 100px;
        width: 100px;
        object-fit: cover;
        border-radius: 50%;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .navbar-brand-text {
        color: var(--primary-color);
        text-transform: uppercase;
        font-size: 2rem;
        white-space: normal;
        /* Allows word wrapping */
        word-wrap: break-word;
        /* Breaks long words if needed */
        text-align: center;
        /* Optional: center-align text */
        max-width: 100%;
        /* Prevent overflow */
        font-family: "Oswald", sans-serif;
        font-optical-sizing: auto;
        font-weight: 700;
        font-style: normal;
        margin: 1rem 0;
    }

    .notice-card {
        background: #fff;
        border: none;
        border-radius: 15px;
        box-shadow: var(--card-shadow);
        transition: all 0.3s ease-in-out;
        margin-bottom: 30px;
        display: flex;
        flex-direction: column;
    }

    .notice-card:hover {
        transform: translateY(-10px);
        box-shadow: var(--card-hover-shadow);
    }

    .notice-card-header {
        background: linear-gradient(135deg, var(--primary-dark), var(--primary-light));
        color: white;
        padding: 1rem 1.5rem;
        border-top-left-radius: 15px;
        border-top-right-radius: 15px;
        font-size: 1.2rem;
        font-weight: 600;
    }

    .notice-card-body {
        padding: 1.5rem;
        display: flex;
        flex-direction: column;
        flex-grow: 1;
    }

    .notice-date-badge {
        background-color: var(--secondary-color);
        color: white;
        padding: 0.3rem 0.8rem;
        border-radius: 50px;
        font-size: 0.8rem;
        align-self: flex-start;
        margin-bottom: 1rem;
    }

    .notice-card-body .notice-content {
        font-family: 'Roboto', sans-serif;
        color: #555;
        line-height: 1.6;
        flex-grow: 1;
        overflow: hidden;
        display: -webkit-box;
        line-clamp: 4;
        -webkit-line-clamp: 4;
        -webkit-box-orient: vertical;
        text-overflow: ellipsis;
    }
    
    .notice-card-footer {
        padding: 1rem 1.5rem;
        background: #fdfdff;
        border-bottom-left-radius: 15px;
        border-bottom-right-radius: 15px;
    }

    .pagination .page-item .page-link {
        color: var(--primary-color);
    }

    .pagination .page-item.active .page-link {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
        color: white;
    }
    
    .modal-header {
        background-color: var(--primary-color);
        color: white;
    }
    
    .modal-title {
        font-weight: 600;
    }
    
    .modal-body .notice-date {
        font-size: 0.9rem;
        color: var(--secondary-color);
        margin-bottom: 1rem;
    }

    .modal-body .notice-full-content {
        white-space: pre-wrap; /* respects newlines in the notice */
        line-height: 1.7;
    }

</style>

<div class="container mt-4 mb-5">

    <div class="logo-container">
        <a class="navbar-brand" href="/">
            <img src="../uploads/school/logo-square.png" alt="School Logo" onerror="this.style.display='none'">
            <div class="navbar-brand-text"><?= safe_htmlspecialchars($schoolInfo['name']); ?></div>
        </a>
    </div>

    <div class="card shadow-lg border-0 rounded-lg">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0 py-2"><i class="fa-solid fa-bullhorn me-2"></i> School Notices</h4>
            <a href="../" class="btn btn-light btn-sm">
                <i class="fas fa-arrow-left me-1"></i> Back to Home
            </a>
        </div>

        <div class="card-body p-4">
            <div class="row">
                <?php if (empty($notices)): ?>
                    <div class="col-12">
                        <p class="text-center text-muted">No notices found.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($notices as $notice): ?>
                        <div class="col-md-6 col-lg-4 mb-4 d-flex align-items-stretch">
                            <div class="notice-card w-100">
                                <div class="notice-card-header">
                                    <?= safe_htmlspecialchars($notice['title']) ?>
                                </div>
                                <div class="notice-card-body">
                                    <span class="notice-date-badge"><?= (new DateTime($notice['notice_date']))->format('d F Y'); ?></span>
                                    <div class="notice-content"><?= safe_htmlspecialchars($notice['content']) ?></div>
                                </div>
                                <div class="notice-card-footer text-end">
                                    <button class="btn btn-sm btn-outline-primary read-more-btn" 
                                            data-title="<?= safe_htmlspecialchars($notice['title']) ?>"
                                            data-date="<?= (new DateTime($notice['notice_date']))->format('l, d F Y') ?>"
                                            data-content="<?= safe_htmlspecialchars($notice['content']) ?>">
                                        Read More <i class="fas fa-arrow-right ms-1"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <?php if ($total_pages > 1): ?>
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center mt-4">
                    <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
                        <a class="page-link" href="?page=<?= $page - 1 ?>" tabindex="-1" aria-disabled="true">Previous</a>
                    </li>
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                            <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?= ($page >= $total_pages) ? 'disabled' : '' ?>">
                        <a class="page-link" href="?page=<?= $page + 1 ?>">Next</a>
                    </li>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="modal fade" id="noticeModal" tabindex="-1" aria-labelledby="noticeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="noticeModalLabel"></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="notice-date" id="modalNoticeDate"></p>
                <p class="notice-full-content" id="modalNoticeContent"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const noticeModal = new bootstrap.Modal(document.getElementById('noticeModal'));
    const readMoreButtons = document.querySelectorAll('.read-more-btn');

    readMoreButtons.forEach(button => {
        button.addEventListener('click', function () {
            const title = this.dataset.title;
            const date = this.dataset.date;
            const content = this.dataset.content;

            document.getElementById('noticeModalLabel').textContent = title;
            document.getElementById('modalNoticeDate').textContent = 'Published on: ' + date;
            document.getElementById('modalNoticeContent').textContent = content;

            noticeModal.show();
        });
    });
});
</script>

<?php include_once("../includes/body-close.php"); ?>