<?php
include_once("../includes/header-open.php");
echo "<title>Refund & Cancellation Policy - " . $school_name . "</title>";
include_once("../includes/header-close.php");
?>

<style>
  body {
    background-color: #f8f9fa;
  }

  .logo-container {
    text-align: center;
    padding: 1.5rem 0;
  }

  .logo-container .navbar-brand {
    display: block;
    text-decoration: none;
  }

  .navbar-brand img {
    height: 100px;
    width: 100px;
    object-fit: cover;
    border-radius: 50%;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }

  .navbar-brand-text {
    color: var(--primary-color);
    text-transform: uppercase;
    font-size: 2rem;
    text-align: center;
    font-family: "Oswald", sans-serif;
    font-weight: 700;
    margin: 1rem 0;
  }

  .card-body h3 {
    margin-top: 2rem;
    color: #0056b3;
    font-size: 1.4rem;
    font-weight: 600;
  }

  .card-body p {
    margin-bottom: 1rem;
  }

  @media (max-width: 768px) {
    .navbar-brand-text {
      font-size: 1.4rem;
    }

    .card-body h3 {
      font-size: 1.2rem;
    }
  }
</style>

<div class="container mt-4 mb-5">

  <div class="logo-container">
    <a class="navbar-brand" href="/">
      <img src="../uploads/school/logo-square.png" alt="School Logo" onerror="this.style.display='none'">
      <div class="navbar-brand-text"><?= safe_htmlspecialchars($schoolInfo['name']); ?></div>
    </a>
  </div>

  <div class="card shadow-lg border-0 rounded-lg">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
      <h4 class="mb-0 py-2"><i class="fa-solid fa-undo me-2"></i> Refund & Cancellation Policy</h4>
      <a href="../" class="btn btn-light btn-sm">
        <i class="fas fa-arrow-left me-1"></i> Back to Home
      </a>
    </div>

    <div class="card-body p-4">
      <h3>Fee Payment</h3>
      <p>
        School fees are to be paid as per the schedule provided by the school administration. This policy outlines the terms related to refunds and cancellations of fees paid to <strong><?= safe_htmlspecialchars($schoolInfo['name']); ?></strong>.
      </p>

      <h3>Fee Cancellation</h3>
      <p>
        For a student who has confirmed their admission and paid the fees, if they wish to cancel the admission, a request must be submitted in writing to the school office.
      </p>

      <h3>Refund Policy</h3>
      <p>
        Refunds for admission fees, tuition fees, and other fees will be processed as per the school's regulations. The amount of refund will depend on the timing of the cancellation request.
      </p>
      <ul>
        <li><strong>Admission Fee:</strong> This fee is generally non-refundable once the admission is confirmed.</li>
        <li><strong>Tuition Fee:</strong> A proportionate refund of the tuition fee may be possible if the cancellation request is received before the commencement of the academic session.</li>
        <li><strong>Other Fees:</strong> The refund of other fees such as transport and activity fees will be considered on a case-by-case basis.</li>
      </ul>

      <h3>Duplicate Payment</h3>
      <p>
        In case of a duplicate payment made by the user, the excess amount will be refunded. To claim a refund for a duplicate payment, please contact the school accounts office with the transaction details. The refund will be processed within 15-20 working days.
      </p>

      <h3>Processing of Refunds</h3>
      <p>
        All refund requests must be submitted to the school administration in writing. The refund process will be initiated after a review of the request and will be made through the original mode of payment where possible.
      </p>

      <h3>Contact for Refunds</h3>
      <p>For any questions related to refunds and cancellations, please contact our accounts department at <strong><?= safe_htmlspecialchars($schoolInfo['email']) ?></strong> or call us at <strong><?= safe_htmlspecialchars($schoolInfo['phone']) ?></strong>.</p>
    </div>
  </div>
</div>
<?php include_once("../includes/body-close.php");?>