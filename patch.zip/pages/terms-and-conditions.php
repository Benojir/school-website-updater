<?php
include_once("../includes/header-open.php");
echo "<title>Terms & Conditions - " . $school_name . "</title>";
include_once("../includes/header-close.php");
?>

<style>
  body {
    background-color: #f8f9fa;
  }

  .logo-container {
    text-align: center;
    padding: 1.5rem 0;
  }

  .logo-container .navbar-brand {
    display: block;
    text-decoration: none;
  }

  .navbar-brand img {
    height: 100px;
    width: 100px;
    object-fit: cover;
    border-radius: 50%;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }

  .navbar-brand-text {
    color: var(--primary-color);
    text-transform: uppercase;
    font-size: 2rem;
    text-align: center;
    font-family: "Oswald", sans-serif;
    font-weight: 700;
    margin: 1rem 0;
  }

  .card-body h3 {
    margin-top: 2rem;
    color: #0056b3;
    font-size: 1.4rem;
    font-weight: 600;
  }
  
  .card-body ul {
    padding-left: 1.25rem;
    margin-bottom: 1.5rem;
  }

  .card-body p {
    margin-bottom: 1rem;
  }

  @media (max-width: 768px) {
    .navbar-brand-text {
      font-size: 1.4rem;
    }

    .card-body h3 {
      font-size: 1.2rem;
    }
  }
</style>

<div class="container mt-4 mb-5">

  <div class="logo-container">
    <a class="navbar-brand" href="/">
      <img src="../uploads/school/logo-square.png" alt="School Logo" onerror="this.style.display='none'">
      <div class="navbar-brand-text"><?= safe_htmlspecialchars($schoolInfo['name']); ?></div>
    </a>
  </div>

  <div class="card shadow-lg border-0 rounded-lg">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
      <h4 class="mb-0 py-2"><i class="fa-solid fa-file-contract me-2"></i> Terms & Conditions</h4>
      <a href="../" class="btn btn-light btn-sm">
        <i class="fas fa-arrow-left me-1"></i> Back to Home
      </a>
    </div>

    <div class="card-body p-4">
      <h3>1. Introduction</h3>
      <p>Welcome to <strong><?= safe_htmlspecialchars($schoolInfo['name']); ?></strong>. These terms and conditions outline the rules and regulations for the use of our website and its services.</p>

      <h3>2. Acceptance of Terms</h3>
      <p>By accessing this website, you accept these terms and conditions in full. Do not continue to use this website if you do not accept all of the terms and conditions stated on this page.</p>

      <h3>3. Online Fee Payment</h3>
      <ul>
        <li>The online fee payment facility is provided for the convenience of parents and guardians.</li>
        <li>All fees are payable in accordance with the school's fee schedule.</li>
        <li>We accept payments through various secure payment gateways.</li>
        <li>Please ensure you enter the correct student information when making a payment.</li>
      </ul>
      
      <h3>4. User Account</h3>
      <p>If you create an account on this website, you are responsible for maintaining the security of your account and you are fully responsible for all activities that occur under the account.</p>

      <h3>5. Intellectual Property</h3>
      <p>The content on this website, including text, graphics, logos, and images, is the property of <strong><?= safe_htmlspecialchars($schoolInfo['name']); ?></strong> and is protected by copyright and other intellectual property laws.</p>

      <h3>6. Limitation of Liability</h3>
      <p>While we strive to provide accurate information, we shall not be held liable for any errors or omissions in the content of this site. The use of the website and its content is at your own risk.</p>

      <h3>7. Governing Law</h3>
      <p>These terms and conditions are governed by and construed in accordance with the laws of India and you irrevocably submit to the exclusive jurisdiction of the courts in that State or location.</p>
      
      <h3>8. Changes to Terms</h3>
      <p>We reserve the right to revise these terms and conditions at any time. By using this website, you are expected to review these terms on a regular basis.</p>

      <h3>9. Contact Information</h3>
      <p>If you have any queries regarding any of our terms, please contact us at <strong><?= safe_htmlspecialchars($schoolInfo['email']) ?></strong> or call us at <strong><?= safe_htmlspecialchars($schoolInfo['phone']) ?></strong>.</p>
    </div>
  </div>
</div>
<?php include_once("../includes/body-close.php");?>