<?php
include_once("../includes/header-open.php");
echo "<title>Contact Us - " . $school_name . "</title>";
include_once("../includes/header-close.php");
?>

<style>
  body {
    background-color: #f8f9fa;
  }

  .logo-container {
    text-align: center;
    padding: 1.5rem 0;
  }

  .logo-container .navbar-brand {
    display: block;
    text-decoration: none;
  }

  .navbar-brand img {
    height: 100px;
    width: 100px;
    object-fit: cover;
    border-radius: 50%;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }

  .navbar-brand-text {
    color: var(--primary-color);
    text-transform: uppercase;
    font-size: 2rem;
    text-align: center;
    font-family: "Oswald", sans-serif;
    font-weight: 700;
    margin: 1rem 0;
  }

  .card-body h3 {
    margin-top: 2rem;
    color: #0056b3;
    font-size: 1.4rem;
    font-weight: 600;
  }

  .contact-details p {
    font-size: 1.1rem;
    margin-bottom: 0.75rem;
  }
  
  .contact-details i {
    color: var(--primary-color);
    margin-right: 10px;
  }

  .map-container {
    margin-top: 2rem;
  }

  @media (max-width: 768px) {
    .navbar-brand-text {
      font-size: 1.4rem;
    }

    .card-body h3 {
      font-size: 1.2rem;
    }
  }
</style>

<div class="container mt-4 mb-5">

  <div class="logo-container">
    <a class="navbar-brand" href="/">
      <img src="../uploads/school/logo-square.png" alt="School Logo" onerror="this.style.display='none'">
      <div class="navbar-brand-text"><?= safe_htmlspecialchars($schoolInfo['name']); ?></div>
    </a>
  </div>

  <div class="card shadow-lg border-0 rounded-lg">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
      <h4 class="mb-0 py-2"><i class="fa-solid fa-address-book me-2"></i> Contact Us</h4>
      <a href="../" class="btn btn-light btn-sm">
        <i class="fas fa-arrow-left me-1"></i> Back to Home
      </a>
    </div>

    <div class="card-body p-4">
      <h3>Get in Touch</h3>
      <p>We welcome your inquiries. Please feel free to contact us with any questions or for more information about our school.</p>
      
      <div class="contact-details mt-4">
        <p><i class="fas fa-map-marker-alt"></i> <strong>Address:</strong> <?= safe_htmlspecialchars($schoolInfo['address']); ?></p>
        <p><i class="fas fa-phone-alt"></i> <strong>Phone:</strong> <?= safe_htmlspecialchars($schoolInfo['phone']); ?></p>
        <p><i class="fas fa-envelope"></i> <strong>Email:</strong> <a href="mailto:<?= safe_htmlspecialchars($schoolInfo['email']); ?>"><?= safe_htmlspecialchars($schoolInfo['email']); ?></a></p>
      </div>

      <div class="map-container">
          <h3>Our Location</h3>
          <iframe src="https://maps.google.com/maps?q=<?= urlencode($schoolInfo['address']); ?>&output=embed" width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
      </div>
      
    </div>
  </div>
</div>

<?php include_once("../includes/body-close.php");?>