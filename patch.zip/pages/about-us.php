<?php
include_once("../includes/header-open.php");
echo "<title>About Us - " . $school_name . "</title>";
include_once("../includes/header-close.php");
?>

<style>
  body {
    background-color: #f8f9fa;
  }

  .logo-container {
    text-align: center;
    padding: 1.5rem 0;
  }

  .logo-container .navbar-brand {
    display: block;
    text-decoration: none;
  }

  .navbar-brand img {
    height: 100px;
    width: 100px;
    object-fit: cover;
    border-radius: 50%;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }

  .navbar-brand-text {
    color: var(--primary-color);
    text-transform: uppercase;
    font-size: 2rem;
    text-align: center;
    font-family: "Oswald", sans-serif;
    font-weight: 700;
    margin: 1rem 0;
  }

  .card-body h3 {
    margin-top: 2rem;
    color: #0056b3;
    font-size: 1.4rem;
    font-weight: 600;
  }

  .card-body p {
    margin-bottom: 1rem;
    line-height: 1.6;
  }

  @media (max-width: 768px) {
    .navbar-brand-text {
      font-size: 1.4rem;
    }

    .card-body h3 {
      font-size: 1.2rem;
    }
  }
</style>

<div class="container mt-4 mb-5">

  <div class="logo-container">
    <a class="navbar-brand" href="/">
      <img src="../uploads/school/logo-square.png" alt="School Logo" onerror="this.style.display='none'">
      <div class="navbar-brand-text"><?= safe_htmlspecialchars($schoolInfo['name']); ?></div>
    </a>
  </div>

  <div class="card shadow-lg border-0 rounded-lg">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
      <h4 class="mb-0 py-2"><i class="fa-solid fa-school me-2"></i> About Us</h4>
      <a href="../" class="btn btn-light btn-sm">
        <i class="fas fa-arrow-left me-1"></i> Back to Home
      </a>
    </div>

    <div class="card-body p-4">
      <h3>Welcome to <?= safe_htmlspecialchars($schoolInfo['name']); ?></h3>
      <p>
        Established with a vision to provide quality education, <strong><?= safe_htmlspecialchars($schoolInfo['name']); ?></strong> is a place where young minds are nurtured and future leaders are made. Our school is committed to fostering an environment of academic excellence, creativity, and holistic development.
      </p>

      <h3>Our Mission</h3>
      <p>
        Our mission is to empower students with the knowledge, skills, and values needed to thrive in a dynamic world. We aim to cultivate a passion for learning and a commitment to lifelong personal growth.
      </p>

      <h3>Our Vision</h3>
      <p>
        We envision a community of learners who are not only academically proficient but also compassionate, and responsible citizens. We strive to create an inclusive and supportive atmosphere where every student can reach their full potential.
      </p>

      <h3>Our Values</h3>
      <p>
        We are guided by our core values of integrity, respect, and excellence. We believe in the importance of a strong partnership between the school, students, and parents to achieve our shared goals.
      </p>
    </div>
  </div>
</div>

<?php include_once("../includes/body-close.php");?>