<?php
/** @var string $school_name */
/** @var PDO $pdo */
include_once("../includes/header-open.php");
echo "<title>Our Apps - " . $school_name . "</title>";
?>
<style>
    body {
        background-color: #f8f9fa; /* পেজের ব্যাকগ্রাউন্ডে হালকা একটি রঙ */
    }
    
    .page-header-wrapper {
        background: linear-gradient(135deg, #f8f9fa 0%, #e2e8f0 100%);
        padding: 40px 0;
        border-radius: 15px;
        margin-bottom: 40px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.03);
    }

    .app-card {
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        border-radius: 20px;
        border: 1px solid rgba(0,0,0,0.05);
        background: #ffffff;
        overflow: hidden;
        z-index: 1;
    }
    
    .app-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(0,0,0,0.08) !important;
        border-color: rgba(13, 110, 253, 0.1);
    }

    .icon-wrapper {
        width: 90px;
        height: 90px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        font-size: 2.5rem;
        margin: 0 auto;
        transition: all 0.4s ease;
    }
    
    .app-card:hover .icon-wrapper {
        transform: scale(1.15) rotate(5deg);
    }

    /* কাস্টম অপাসিটি ব্যাকগ্রাউন্ড ক্লাস (যেহেতু Bootstrap opacity কাজ করছিল না) */
    .icon-bg-primary { background-color: rgba(13, 110, 253, 0.1); color: #0d6efd; }
    .icon-bg-success { background-color: rgba(25, 135, 84, 0.1); color: #198754; }
    .icon-bg-warning { background-color: rgba(255, 193, 7, 0.15); color: #e0a800; }
    .icon-bg-info { background-color: rgba(13, 202, 240, 0.1); color: #0dcaf0; }

    .btn-download {
        border-radius: 50px;
        font-weight: 600;
        letter-spacing: 0.5px;
        text-transform: uppercase;
        font-size: 0.9rem;
        padding: 12px 20px;
        transition: all 0.3s ease;
    }
    
    .btn-download:hover {
        transform: translateY(-3px);
        filter: brightness(1.1);
    }

    .btn-primary-shadow:hover { box-shadow: 0 8px 15px rgba(13, 110, 253, 0.3); }
    .btn-success-shadow:hover { box-shadow: 0 8px 15px rgba(25, 135, 84, 0.3); }
    .btn-warning-shadow:hover { box-shadow: 0 8px 15px rgba(255, 193, 7, 0.3); }
</style>
<?php
include_once("../includes/header-close.php");

// Fetch saved app links from JSON
$apps_links = [];
try {
    $stmt = $pdo->query("SELECT apps_link FROM school_information LIMIT 1");
    $schoolInfo = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($schoolInfo && !empty($schoolInfo['apps_link'])) {
        $apps_links = json_decode($schoolInfo['apps_link'], true) ?: [];
    }
} catch (PDOException $e) {
    // Error handling
}

// ==========================================
// APP DIRECTORY:
// ==========================================
$app_directory = [
    'parent_app_link' => [
        'title' => 'Parent App',
        'description' => 'Stay updated with your child\'s attendance, marks, fees, and daily school activities.',
        'icon' => 'fas fa-mobile-screen-button',
        'icon_class' => 'icon-bg-primary',
        'btn_class' => 'btn-primary btn-primary-shadow'
    ],
    'student_attendance_app_link' => [
        'title' => 'Student Attendance App',
        'description' => 'Quickly and efficiently mark daily student attendance with real-time syncing.',
        'icon' => 'fas fa-user-check',
        'icon_class' => 'icon-bg-success',
        'btn_class' => 'btn-success btn-success-shadow'
    ],
    'driver_app_link' => [
        'title' => 'Driver App',
        'description' => 'Manage bus routes, student pick-up/drop-off status, and navigate easily.',
        'icon' => 'fas fa-bus',
        'icon_class' => 'icon-bg-warning',
        'btn_class' => 'btn-warning btn-warning-shadow text-dark'
    ]
];
?>

<div class="container mt-4 mb-5">
    
    <div class="page-header-wrapper text-center">
        <div class="row">
            <div class="col-12">
                <h2 class="fw-bold text-dark mb-2">Download Our Official Apps</h2>
                <p class="text-muted fs-5 mb-0">Get the right tools to stay connected and manage school activities smoothly.</p>
                <div class="d-flex justify-content-center mt-3">
                    <div style="height: 4px; width: 60px; background-color: #0d6efd; border-radius: 2px;"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 justify-content-center">
        <?php
        $apps_found = false;

        foreach ($app_directory as $db_key => $app_details) {
            if (!empty($apps_links[$db_key])) {
                $apps_found = true;
                $download_url = safe_htmlspecialchars($apps_links[$db_key]);
                ?>
                
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card app-card h-100 p-4 text-center">
                        <div class="card-body d-flex flex-column p-0">
                            <div class="icon-wrapper <?= $app_details['icon_class'] ?> mb-4">
                                <i class="<?= $app_details['icon'] ?>"></i>
                            </div>
                            
                            <h4 class="card-title fw-bold mb-3"><?= $app_details['title'] ?></h4>
                            <p class="card-text text-secondary mb-4 flex-grow-1" style="line-height: 1.6;">
                                <?= $app_details['description'] ?>
                            </p>
                            
                            <div class="mt-auto">
                                <a href="<?= $download_url ?>" target="_blank" class="btn <?= $app_details['btn_class'] ?> text-white btn-download w-100">
                                    <i class="fab fa-google-play me-2"></i> Download App
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <?php
            }
        }

        if (!$apps_found) {
            echo '
            <div class="col-12 text-center py-5">
                <img src="../../assets/images/empty-apps.svg" alt="No Apps" style="width: 150px; opacity: 0.5;" class="mb-4">
                <h5 class="text-secondary fw-bold">No applications are currently available for download.</h5>
                <p class="text-muted">Please contact the administration or check back later.</p>
            </div>';
        }
        ?>
    </div>
</div>

<?php include_once("../includes/body-close.php"); ?>