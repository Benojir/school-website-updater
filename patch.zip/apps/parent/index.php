<?php include_once "../../includes/header-open.php"; ?>

<title>Download Parent App - <?=$school_name?></title>

<!-- Custom CSS -->
<style>
    :root {
        --bs-primary-rgb: 0, 90, 156;
        /* Deep School Blue */
        --bs-secondary-rgb: 255, 179, 0;
        /* Warm Accent */
    }

    body {
        font-family: 'Inter', sans-serif;
        background-color: #fcfdff;
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
        font-weight: 700;
    }

    .navbar {
        background-color: rgba(255, 255, 255, 0.9);
        backdrop-filter: blur(10px);
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
    }

    .navbar-brand {
        font-weight: 800;
        color: rgb(var(--bs-primary-rgb));
    }

    /* Remove the grey border */
    .navbar-toggler {
        border: none; 
    }

    /* Remove the outline/shadow when clicked */
    .navbar-toggler:focus,
    .navbar-toggler:active {
        outline: none;
        box-shadow: none;
    }

    /* By default (when menu is OPEN), show the X and hide the List */
    .navbar-toggler .bi-list {
        display: none;
    }
    .navbar-toggler .bi-x-lg {
        display: inline-block;
    }

    /* When the menu is CLOSED (Bootstrap adds the .collapsed class), swap them */
    .navbar-toggler.collapsed .bi-list {
        display: inline-block;
    }
    .navbar-toggler.collapsed .bi-x-lg {
        display: none;
    }

    /* Optional: Remove the default border and focus glow for a cleaner look */
    .navbar-toggler {
        border: none;
        box-shadow: none !important;
    }
    /* Optional: Adjust icon size */
    .mobile-nav-toggle-icon {
        font-size: 1.5rem; 
        color: rgba(0, 0, 0, 0.55); /* Match default Bootstrap toggle color */
    }

    /* --- Hero Section --- */
    .hero-section {
        padding-top: 140px;
        padding-bottom: 80px;
        background: linear-gradient(135deg, rgba(var(--bs-primary-rgb), 0.05) 0%, rgba(255, 255, 255, 1) 60%);
        overflow: hidden;
    }

    .hero-section .display-4 {
        font-weight: 800;
        color: #222;
    }

    .hero-section .lead {
        font-size: 1.25rem;
        color: #555;
    }

    /* Updated Download Buttons Layout */
    .download-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 15px;
        margin-top: 2rem;
    }

    .btn-store {
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0.8rem 1rem;
        border-radius: 12px;
        font-weight: 600;
        font-size: 0.95rem;
        transition: all 0.3s ease;
        text-decoration: none;
        border: 1px solid transparent;
        box-shadow: 0 4px 6px rgba(0,0,0,0.05);
    }
    
    .btn-store i {
        font-size: 1.2rem;
        margin-right: 8px;
    }

    .btn-store:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 15px rgba(0,0,0,0.1);
    }

    /* Brand Specific Colors */
    .btn-google {
        background-color: #fff;
        color: #333;
        border-color: #e0e0e0;
    }

    .btn-indus {
        background: linear-gradient(45deg, #EC008C, #782F99); /* Approximate Indus gradient */
        color: #fff;
        border: none;
    }

    .btn-aptoide {
        background-color: #FF6F00;
        color: #fff;
    }
    
    .btn-apk {
        background-color: #2e7d32;
        color: #fff;
    }

    /* --- Screenshot Image --- */
    .app-screenshot-container {
        position: relative;
        max-width: 320px;
        margin: 0 auto;
        /* Optional: Add a subtle backdrop or shadow behind the screenshot */
    }

    .app-screenshot {
        width: 100%;
        height: auto;
        border-radius: 20px;
        box-shadow: 0 20px 50px rgba(0,0,0,0.15);
        border: 8px solid #FFF;
    }

    /* --- Features Section --- */
    #features {
        padding: 80px 0;
    }

    .feature-icon-box {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 70px;
        height: 70px;
        border-radius: 50%;
        font-size: 2rem;
        background-color: rgba(var(--bs-primary-rgb), 0.1);
        color: rgb(var(--bs-primary-rgb));
        margin-bottom: 20px;
    }

    /* --- Testimonials Section --- */
    #testimonials {
        padding: 80px 0;
        background-color: #f8f9fa;
    }

    .testimonial-card {
        border: 0;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.07);
    }

    .testimonial-img {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        margin: -40px auto 0;
        border: 4px solid #fff;
    }

    .testimonial-card .card-body {
        padding-top: 30px;
    }

    .testimonial-card blockquote {
        font-style: italic;
        color: #555;
    }

    .testimonial-author {
        font-weight: 700;
        color: rgb(var(--bs-primary-rgb));
    }

    .testimonial-author span {
        font-weight: 400;
        font-size: 0.9rem;
        color: #777;
    }

    /* --- CTA Section --- */
    #cta {
        padding: 80px 0;
        background: linear-gradient(135deg, rgb(var(--bs-primary-rgb)) 0%, #002d4b 100%);
    }

    /* --- Footer --- */
    footer {
        padding: 30px 0;
        background-color: #fff;
        border-top: 1px solid #eee;
    }

    /* --- Animation Utility --- */
    /* Class to hide elements until they are animated in */
    .wow {
        opacity: 0;
    }
</style>
<?php include_once "../../includes/header-close.php"; ?>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg fixed-top shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="#">
            <i class="bi bi-mortarboard-fill"></i>
            Parent App
        </a>
        <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <i class="bi bi-list mobile-nav-toggle-icon"></i>
            <i class="bi bi-x-lg mobile-nav-toggle-icon"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#features">Features</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#testimonials">Testimonials</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<header class="hero-section">
    <div class="container">
        <div class="row align-items-center">
            <!-- Text Content -->
            <div class="col-lg-6">
                <h1 class="display-4 animate__animated animate__fadeInUp">
                    Stay connected to your child's success.
                </h1>
                <p class="lead my-4 animate__animated animate__fadeInUp animate__delay-1s">
                    Get real-time updates on grades, attendance, announcements, and
                    school events right from your phone.
                </p>
                
                <p class="small text-muted mb-2 animate__animated animate__fadeInUp animate__delay-2s">Available on multiple platforms:</p>
                
                <!-- New Download Grid Layout -->
                <div class="download-grid animate__animated animate__fadeInUp animate__delay-2s">
                    <!-- Google Play -->
                    <!-- <a href="<?= $schoolInfo['app_download_link'] ?? '#';?>" class="btn-store btn-google">
                        <i class="bi bi-google-play"></i> Google Play
                    </a> -->
                    
                    <!-- Indus Appstore -->
                    <!-- <a href="#" class="btn-store btn-indus">
                        <i class="bi bi-shop-window"></i> Indus Appstore
                    </a> -->

                    <!-- Apptoid (using generic download icon as specific brand icon might not exist in BS icons) -->
                    <!-- <a href="#" class="btn-store btn-aptoide">
                        <i class="bi bi-box-seam"></i> Aptoide
                    </a> -->

                    <!-- Direct APK -->
                    <a href="<?=$schoolInfo['app_download_link'] ?? '#';?>" class="btn-store btn-apk">
                        <i class="bi bi-android2"></i> Download APK
                    </a>
                </div>
            </div>

            <!-- Screenshot Section (Replaces Phone Mockup) -->
            <div class="col-lg-6 mt-5 mt-lg-0 text-center">
                <div class="app-screenshot-container animate__animated animate__fadeInRight animate__delay-1s">
                    <!-- Replace the src below with your actual screenshot image URL -->
                    <!-- We use an ID here to target it with JS -->
                    <img src="https://i.ibb.co/qYhPGJRJ/Screenshot-20251122-202604-Dahuk-Parent-App.png" 
                         alt="App Screenshot" 
                         id="dynamic-screenshot"
                         class="app-screenshot img-fluid">
                </div>
            </div>
        </div>
    </div>
</header>

<!-- Features Section -->
<section id="features">
    <div class="container">
        <div class="row text-center">
            <div class="col-lg-8 mx-auto">
                <h2 class="mb-3">All The Tools You Need</h2>
                <p class="lead text-muted mb-5">
                    Our app is designed to give you a complete picture of your child's
                    school life, all in one simple, secure place.
                </p>
            </div>
        </div>

        <div class="row g-4 text-center">
            <div class="col-md-4 wow">
                <div class="feature-icon-box">
                    <i class="bi bi-bell-fill"></i>
                </div>
                <h4>Real-time Notifications</h4>
                <p class="text-muted">
                    Get instant alerts for new grades, attendance marks, fee reminders,
                    and important school announcements.
                </p>
            </div>
            <div class="col-md-4 wow" data-wow-delay="100ms">
                <div class="feature-icon-box">
                    <i class="bi bi-chat-dots-fill"></i>
                </div>
                <h4>Direct Communication</h4>
                <p class="text-muted">
                    Securely message teachers and school administration with any
                    questions or concerns, right from the app.
                </p>
            </div>
            <div class="col-md-4 wow" data-wow-delay="200ms">
                <div class="feature-icon-box">
                    <i class="bi bi-calendar2-check-fill"></i>
                </div>
                <h4>Events & Calendars</h4>
                <p class="text-muted">
                    Stay on top of the school calendar, including holidays, exams,
                    sports events, and PTA meetings.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section id="testimonials">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto text-center">
                <h2 class="mb-3">Trusted by Parents & Teachers</h2>
                <p class="lead text-muted mb-5">
                    See what other parents are saying about the app.
                </p>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-lg-6 wow">
                <div class="card testimonial-card h-100">
                    <img src="https://placehold.co/100x100/EBF4FF/005A9C?text=S" class="testimonial-img" alt="Parent">
                    <div class="card-body text-center">
                        <blockquote class="mb-3">
                            "This app is a game-changer. I used to find out about
                            assignments after they were due! Now I feel so much more
                            involved and can support my daughter."
                        </blockquote>
                        <h5 class="testimonial-author">
                            Sarah K.
                            <span class="d-block">Parent, Grade 8</span>
                        </h5>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 wow" data-wow-delay="100ms">
                <div class="card testimonial-card h-100">
                    <img src="https://placehold.co/100x100/FFF3E0/FFA500?text=M" class="testimonial-img" alt="Teacher">
                    <div class="card-body text-center">
                        <blockquote class="mb-3">
                            "As a teacher, communication is key. This app has made it
                            so much easier to connect with parents, share progress,
                            and ensure we're all working together."
                        </blockquote>
                        <h5 class="testimonial-author">
                            Mr. D. Patel
                            <span class="d-block">Maths Teacher, Grade 10</span>
                        </h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Call to Action (CTA) Section -->
<section id="cta">
    <div class="container text-center text-white">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <h2 class="display-5 mb-3">Get Started Today</h2>
                <p class="lead mb-4">
                    Download the School Parent App and take the first step towards
                    a more connected school experience.
                </p>
                <!-- Simple CTA Button to scroll back up or open modal -->
                <a href="#" class="btn btn-light btn-lg rounded-pill px-5 shadow fw-bold">
                    <i class="bi bi-download me-2"></i> Download Now
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class="text-center">
    <div class="container">
        <p class="mb-0 text-muted">
            &copy; <?= date('Y') . " " . ($school_name ?? 'School Name'); ?>. All Rights Reserved.
            <a href="/" class="ms-2 text-decoration-none">Main School Website</a>
        </p>
    </div>
</footer>

<!-- Custom jQuery for Scroll Animations and Screenshot Rotator -->
<script>
    $(document).ready(function() {
        // --- 1. Screenshot Rotator Logic ---
        // REPLACE THESE LINKS with your actual screenshot URLs
        const screenshots = [
            "https://i.ibb.co/4Zyh12FM/Screenshot-20251122-202616-Dahuk-Parent-App.png", 
            "https://i.ibb.co/C3Pr1yJR/Screenshot-20251122-202610-Dahuk-Parent-App.png", 
            "https://i.ibb.co/qYhPGJRJ/Screenshot-20251122-202604-Dahuk-Parent-App.png"
        ];
        
        let currentImageIndex = 0;
        const $screenshotImg = $('#dynamic-screenshot');

        setInterval(function() {
            // Calculate next index
            currentImageIndex = (currentImageIndex + 1) % screenshots.length;
            
            // Fade out, change src, fade in
            $screenshotImg.fadeOut(400, function() {
                $(this).attr('src', screenshots[currentImageIndex]).fadeIn(400);
            });
        }, 5000); // 3000ms = 3 seconds

        // --- 2. Existing Smooth Scroll ---
        $('.navbar-nav .nav-link, .navbar-brand, .navbar .btn').on('click', function(e) {
            const hash = this.hash;
            if (hash !== "") {
                if ($(hash).length) {
                    e.preventDefault();
                    $('html, body').animate({
                        scrollTop: $(hash).offset().top - 70 
                    }, 500);
                }
            }
        });

        // --- 3. Existing Animation on Scroll ---
        function isInViewport(element) {
            const rect = element.getBoundingClientRect();
            return (
                rect.top <= (window.innerHeight || document.documentElement.clientHeight) - 100 && 
                rect.bottom >= 0
            );
        }

        function checkAnimations() {
            $('.wow').each(function() {
                if (isInViewport(this)) {
                    const delay = $(this).data('wow-delay') || '0ms';
                    $(this).css({
                        'animation-delay': delay,
                        'opacity': '1' 
                    }).addClass('animate__animated animate__fadeInUp');
                }
            });
        }

        checkAnimations();
        $(window).on('scroll', checkAnimations);
    });
</script>

<?php include_once "../../includes/body-close.php"; ?>