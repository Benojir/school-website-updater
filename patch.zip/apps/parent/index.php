<?php include_once "../../includes/header-open.php"; ?>

<title>School Parent App - Stay Connected</title>

<!-- Custom CSS -->
<style>
    :root {
        --bs-primary-rgb: 0, 90, 156;
        /* Deep School Blue */
        --bs-secondary-rgb: 255, 179, 0;
        /* Warm Accent */
    }

    body {
        font-family: 'Inter', sans-serif;
        background-color: #fcfdff;
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
        font-weight: 700;
    }

    .navbar {
        background-color: rgba(255, 255, 255, 0.9);
        backdrop-filter: blur(10px);
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
    }

    .navbar-brand {
        font-weight: 800;
        color: rgb(var(--bs-primary-rgb));
    }

    /* --- Hero Section --- */
    .hero-section {
        padding-top: 140px;
        padding-bottom: 80px;
        background: linear-gradient(135deg, rgba(var(--bs-primary-rgb), 0.05) 0%, rgba(255, 255, 255, 1) 60%);
        overflow: hidden;
    }

    .hero-section .display-4 {
        font-weight: 800;
        color: #222;
    }

    .hero-section .lead {
        font-size: 1.25rem;
        color: #555;
    }

    .btn-download {
        font-size: 1.1rem;
        font-weight: 500;
        padding: 0.75rem 1.5rem;
        border-radius: 50px;
        transition: all 0.3s ease;
    }

    .btn-apple {
        background-color: #000;
        color: #fff;
    }

    .btn-apple:hover {
        background-color: #333;
        color: #fff;
        transform: translateY(-3px);
    }

    .btn-google {
        background-color: #fff;
        color: #333;
        border: 1px solid #ddd;
    }

    .btn-google:hover {
        background-color: #f8f9fa;
        color: #000;
        transform: translateY(-3px);
        border-color: #ccc;
    }

    /* --- Phone Mockup --- */
    .phone-mockup {
        position: relative;
        max-width: 320px;
        margin: 0 auto;
        background: #111;
        border: 2px solid #333;
        border-radius: 40px;
        padding: 10px;
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2), inset 0 0 10px rgba(0, 0, 0, 0.5);
    }

    .phone-screen {
        background: #f8f9fa;
        border-radius: 30px;
        padding: 15px;
        height: 580px;
        overflow: hidden;
        color: #333;
    }

    .app-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-bottom: 10px;
        border-bottom: 1px solid #eee;
    }

    .app-header .bi-list {
        font-size: 1.5rem;
        color: rgb(var(--bs-primary-rgb));
    }

    .app-header .app-title {
        font-weight: 700;
        font-size: 0.9rem;
        color: #222;
    }

    .app-header .bi-bell-fill {
        font-size: 1.2rem;
        color: #777;
    }

    .app-profile {
        text-align: center;
        padding: 20px 0;
    }

    .app-profile img {
        width: 70px;
        height: 70px;
        border-radius: 50%;
        border: 3px solid rgb(var(--bs-primary-rgb));
        margin-bottom: 10px;
    }

    .app-profile h5 {
        margin: 0;
        font-size: 1.1rem;
        font-weight: 700;
    }

    .app-profile p {
        font-size: 0.85rem;
        color: #666;
        margin: 0;
    }

    .app-section {
        margin-top: 20px;
    }

    .app-section h6 {
        font-weight: 700;
        font-size: 0.9rem;
        color: #555;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .app-card {
        background: #fff;
        border-radius: 12px;
        padding: 12px;
        margin-bottom: 10px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        display: flex;
        align-items: center;
    }

    .app-card-icon {
        font-size: 1.5rem;
        padding: 10px;
        border-radius: 10px;
        margin-right: 12px;
    }

    .app-card-icon.icon-grades {
        background-color: rgba(255, 179, 0, 0.15);
        color: rgb(var(--bs-secondary-rgb));
    }

    .app-card-icon.icon-events {
        background-color: rgba(0, 90, 156, 0.15);
        color: rgb(var(--bs-primary-rgb));
    }

    .app-card-icon.icon-homework {
        background-color: rgba(25, 135, 84, 0.15);
        color: #198754;
    }

    .app-card-text strong {
        display: block;
        font-size: 0.95rem;
        font-weight: 700;
        color: #333;
    }

    .app-card-text span {
        font-size: 0.85rem;
        color: #666;
    }

    /* --- Features Section --- */
    #features {
        padding: 80px 0;
    }

    .feature-icon-box {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 70px;
        height: 70px;
        border-radius: 50%;
        font-size: 2rem;
        background-color: rgba(var(--bs-primary-rgb), 0.1);
        color: rgb(var(--bs-primary-rgb));
        margin-bottom: 20px;
    }

    /* --- Testimonials Section --- */
    #testimonials {
        padding: 80px 0;
        background-color: #f8f9fa;
    }

    .testimonial-card {
        border: 0;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.07);
    }

    .testimonial-img {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        margin: -40px auto 0;
        border: 4px solid #fff;
    }

    .testimonial-card .card-body {
        padding-top: 30px;
    }

    .testimonial-card blockquote {
        font-style: italic;
        color: #555;
    }

    .testimonial-author {
        font-weight: 700;
        color: rgb(var(--bs-primary-rgb));
    }

    .testimonial-author span {
        font-weight: 400;
        font-size: 0.9rem;
        color: #777;
    }

    /* --- CTA Section --- */
    #cta {
        padding: 80px 0;
        background: linear-gradient(135deg, rgb(var(--bs-primary-rgb)) 0%, #002d4b 100%);
    }

    /* --- Footer --- */
    footer {
        padding: 30px 0;
        background-color: #fff;
        border-top: 1px solid #eee;
    }

    /* --- Animation Utility --- */
    /* Class to hide elements until they are animated in */
    .wow {
        opacity: 0;
    }
</style>
<?php include_once "../../includes/header-close.php"; ?>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg fixed-top shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="#">
            <i class="bi bi-mortarboard-fill"></i>
            Parent App
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#features">Features</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#testimonials">Testimonials</a>
                </li>
                <li class="nav-item ms-lg-3">
                    <a class="btn btn-primary rounded-pill px-4" href="#cta">Download Now</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<header class="hero-section">
    <div class="container">
        <div class="row align-items-center">
            <!-- Text Content -->
            <div class="col-lg-6">
                <h1 class="display-4 animate__animated animate__fadeInUp">
                    Stay connected to your child's success.
                </h1>
                <p class="lead my-4 animate__animated animate__fadeInUp animate__delay-1s">
                    Get real-time updates on grades, attendance, announcements, and
                    school events right from your phone.
                </p>
                <div class="d-flex flex-wrap gap-3 animate__animated animate__fadeInUp animate__delay-2s">
                    <a href="<?= $schoolInfo['app_download_link'];?>" class="btn btn-download btn-apple shadow">
                        <i class="bi bi-apple me-2"></i> App Store
                    </a>
                    <a href="<?= $schoolInfo['app_download_link'];?>" class="btn btn-download btn-google shadow-sm">
                        <i class="bi bi-google-play me-2"></i> Google Play
                    </a>
                </div>
            </div>

            <!-- Phone Mockup -->
            <div class="col-lg-6 mt-5 mt-lg-0">
                <div class="phone-mockup animate__animated animate__fadeInRight animate__delay-1s">
                    <div class="phone-screen">
                        <!-- App UI Mockup -->
                        <div class="app-header">
                            <i class="bi bi-list"></i>
                            <span class="app-title">Parent Dashboard</span>
                            <i class="bi bi-bell-fill"></i>
                        </div>

                        <div class="app-profile">
                            <img src="https://placehold.co/100x100/EBF4FF/005A9C?text=JS" alt="Student Photo">
                            <h5>Jessica Smith</h5>
                            <p>Grade 7, Section B</p>
                        </div>

                        <div class="app-section">
                            <h6>Quick Access</h6>
                            <div class="app-card">
                                <div class="app-card-icon icon-grades">
                                    <i class="bi bi-clipboard2-check-fill"></i>
                                </div>
                                <div class="app-card-text">
                                    <strong>View Grades</strong>
                                    <span>Science: A- (New)</span>
                                </div>
                            </div>
                            <div class="app-card">
                                <div class="app-card-icon icon-events">
                                    <i class="bi bi-calendar-week-fill"></i>
                                </div>
                                <div class="app-card-text">
                                    <strong>School Events</strong>
                                    <span>PTA Meeting on Fri 22nd</span>
                                </div>
                            </div>
                            <div class="app-card">
                                <div class="app-card-icon icon-homework">
                                    <i class="bi bi-book-fill"></i>
                                </div>
                                <div class="app-card-text">
                                    <strong>Homework</strong>
                                    <span>Maths Ch.4 Due Today</span>
                                </div>
                            </div>
                        </div>
                        <!-- End App UI -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- Features Section -->
<section id="features">
    <div class="container">
        <div class="row text-center">
            <div class="col-lg-8 mx-auto">
                <h2 class="mb-3">All The Tools You Need</h2>
                <p class="lead text-muted mb-5">
                    Our app is designed to give you a complete picture of your child's
                    school life, all in one simple, secure place.
                </p>
            </div>
        </div>

        <div class="row g-4 text-center">
            <div class="col-md-4 wow">
                <div class="feature-icon-box">
                    <i class="bi bi-bell-fill"></i>
                </div>
                <h4>Real-time Notifications</h4>
                <p class="text-muted">
                    Get instant alerts for new grades, attendance marks, fee reminders,
                    and important school announcements.
                </p>
            </div>
            <div class="col-md-4 wow" data-wow-delay="100ms">
                <div class="feature-icon-box">
                    <i class="bi bi-chat-dots-fill"></i>
                </div>
                <h4>Direct Communication</h4>
                <p class="text-muted">
                    Securely message teachers and school administration with any
                    questions or concerns, right from the app.
                </p>
            </div>
            <div class="col-md-4 wow" data-wow-delay="200ms">
                <div class="feature-icon-box">
                    <i class="bi bi-calendar2-check-fill"></i>
                </div>
                <h4>Events & Calendars</h4>
                <p class="text-muted">
                    Stay on top of the school calendar, including holidays, exams,
                    sports events, and PTA meetings.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section id="testimonials">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto text-center">
                <h2 class="mb-3">Trusted by Parents & Teachers</h2>
                <p class="lead text-muted mb-5">
                    See what other parents are saying about the app.
                </p>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-lg-6 wow">
                <div class="card testimonial-card h-100">
                    <img src="https://placehold.co/100x100/EBF4FF/005A9C?text=S" class="testimonial-img" alt="Parent">
                    <div class="card-body text-center">
                        <blockquote class="mb-3">
                            "This app is a game-changer. I used to find out about
                            assignments after they were due! Now I feel so much more
                            involved and can support my daughter."
                        </blockquote>
                        <h5 class="testimonial-author">
                            Sarah K.
                            <span class="d-block">Parent, Grade 8</span>
                        </h5>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 wow" data-wow-delay="100ms">
                <div class="card testimonial-card h-100">
                    <img src="https://placehold.co/100x100/FFF3E0/FFA500?text=M" class="testimonial-img" alt="Teacher">
                    <div class="card-body text-center">
                        <blockquote class="mb-3">
                            "As a teacher, communication is key. This app has made it
                            so much easier to connect with parents, share progress,
                            and ensure we're all working together."
                        </blockquote>
                        <h5 class="testimonial-author">
                            Mr. D. Patel
                            <span class="d-block">Maths Teacher, Grade 10</span>
                        </h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Call to Action (CTA) Section -->
<section id="cta">
    <div class="container text-center text-white">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <h2 class="display-5 mb-3">Get Started Today</h2>
                <p class="lead mb-4">
                    Download the School Parent App and take the first step towards
                    a more connected school experience.
                </p>
                <div class="d-flex flex-wrap justify-content-center gap-3">
                    <a href="<?= $schoolInfo['app_download_link'];?>" class="btn btn-download btn-apple shadow">
                        <i class="bi bi-apple me-2"></i> App Store
                    </a>
                    <a href="<?= $schoolInfo['app_download_link'];?>" class="btn btn-download btn-google shadow-sm">
                        <i class="bi bi-google-play me-2"></i> Google Play
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class="text-center">
    <div class="container">
        <p class="mb-0 text-muted">
            &copy; <?= date('Y') . " " . $school_name; ?>. All Rights Reserved.
            <a href="/" class="ms-2 text-decoration-none">Main School Website</a>
        </p>
    </div>
</footer>

<!-- JavaScript Libraries -->
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" xintegrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

<!-- Custom jQuery for Scroll Animations -->
<script>
    $(document).ready(function() {
        // Smooth scroll for nav links
        $('.navbar-nav .nav-link, .navbar-brand, .navbar .btn').on('click', function(e) {
            const hash = this.hash;
            if (hash !== "") {
                // Check if the target is on the page
                if ($(hash).length) {
                    e.preventDefault();
                    $('html, body').animate({
                        scrollTop: $(hash).offset().top - 70 // Adjust for fixed navbar
                    }, 500);
                }
            }
        });

        // Function to check if element is in viewport
        function isInViewport(element) {
            const rect = element.getBoundingClientRect();
            return (
                rect.top <= (window.innerHeight || document.documentElement.clientHeight) - 100 && // 100px buffer
                rect.bottom >= 0
            );
        }

        // Scroll event to trigger animations
        function checkAnimations() {
            $('.wow').each(function() {
                if (isInViewport(this)) {
                    const delay = $(this).data('wow-delay') || '0ms';
                    $(this).css({
                        'animation-delay': delay,
                        'opacity': '1' // Make it visible
                    }).addClass('animate__animated animate__fadeInUp');
                }
            });
        }

        // Initial check on load
        checkAnimations();

        // Check on scroll
        $(window).on('scroll', checkAnimations);
    });
</script>

<?php include_once "../../includes/body-close.php"; ?>