<?php
// Keep identical to schoolsongi.com/include/subscription-policy.php: independent deployments.
// Pure date/accounting rules; this file never connects to a database.
function schoolSongiSubscriptionDate($value): ?DateTimeImmutable
{
    if (!is_string($value) || !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $value)) {
        return null;
    }
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value, new DateTimeZone('Asia/Kolkata'));
    return $date && $date->format('Y-m-d') === $value ? $date : null;
}

function schoolSongiSubscriptionPolicy(array $school, ?DateTimeImmutable $now = null): array
{
    $zone = new DateTimeZone('Asia/Kolkata');
    $today = ($now ?? new DateTimeImmutable('now', $zone))->setTimezone($zone)->setTime(0, 0);
    $end = schoolSongiSubscriptionDate($school['subscription_end_at'] ?? null);
    $deadline = schoolSongiSubscriptionDate($school['subscription_payment_due_at'] ?? null);
    // Existing balance convention: received credits minus billed debits.
    $balancePaise = (int) round((float) ($school['current_subscription_total'] ?? 0) * 100);
    $duePaise = max(0, -$balancePaise);
    $endDays = $end ? (int) $today->diff($end)->format('%r%a') : null;
    $paymentDays = $deadline ? (int) $today->diff($deadline)->format('%r%a') : null;
    $reason = null;
    if (($school['status'] ?? 'active') !== 'active') {
        $reason = 'inactive';
    } elseif (!$end) {
        $reason = 'unavailable';
    } elseif ($endDays < 0) {
        $reason = 'expired';
    } elseif ($duePaise > 0 && $paymentDays !== null && $paymentDays < 0) {
        $reason = 'payment_overdue';
    }
    return [
        'subscription_due_amount' => $duePaise / 100,
        'subscription_days_left' => $endDays,
        'payment_days_left' => $paymentDays,
        'payment_warning' => $duePaise > 0 && $paymentDays !== null && $paymentDays >= 0 && $paymentDays <= 15,
        'access_blocked' => $reason !== null,
        'access_reason' => $reason,
    ];
}
