<?php
if (empty($_SESSION['contact_message_csrf'])) {
    $_SESSION['contact_message_csrf'] = bin2hex(random_bytes(32));
}
?>
<input type="hidden" name="csrf_token" value="<?= safe_htmlspecialchars($_SESSION['contact_message_csrf']) ?>">
<div class="mb-3" style="max-width:100%;overflow-x:auto;">
    <?php if (!empty($websiteConfig['captcha_site_key']) && !empty($websiteConfig['captcha_secret_key'])): ?>
        <div class="contact-turnstile" data-sitekey="<?= safe_htmlspecialchars($websiteConfig['captcha_site_key']) ?>"></div>
    <?php else: ?>
        <p class="text-danger" role="alert">Messaging is temporarily unavailable. Please contact the school by phone.</p>
    <?php endif; ?>
</div>
<div class="alert d-none" data-contact-feedback role="status" aria-live="polite" tabindex="-1"></div>
<noscript><p>Please enable JavaScript to send a message.</p></noscript>
<script src="<?= BASE_URL ?>/assets/js/contact-form.js?v=<?= filemtime(__DIR__ . '/../assets/js/contact-form.js') ?>" defer></script>
