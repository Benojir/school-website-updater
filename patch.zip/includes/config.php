<?php
// Detect current protocol (http or https)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';

// Check if the current host starts with "www."
if (strpos($_SERVER['HTTP_HOST'], 'www.') === 0) {
    // Remove "www." from the host
    $newUrl = $protocol . substr($_SERVER['HTTP_HOST'], 4) . $_SERVER['REQUEST_URI'];
    
    // Permanent redirect (301)
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: $newUrl");
    exit();
}

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once("db.php");
require_once("functions.php");

// Captcha Verify URL
$captchaVerifyUrl = "https://hcaptcha.com/siteverify";

// Get school information
$schoolInfo = $pdo->query("SELECT * FROM school_information LIMIT 1")->fetch();
$school_name = $schoolInfo['name'];

// Get website configuration
$imgbb_api_key = 'fea77adb2bb6adfce9d184e2851be8c5';
$theme_color = '#0d6efd ';
$currency_symbol = '₹';

$websiteConfig = $pdo->query("SELECT * FROM website_config LIMIT 1")->fetch();

if ($websiteConfig) {
    $theme_color = $websiteConfig['theme_color'];
    $imgbb_api_key = $websiteConfig['imgbb_api_key'];
    $currency_symbol = $websiteConfig['currency_symbol'];
}


$theme_color_dark = adjustColorShades($theme_color, 30)['darker'];
$theme_color_light = adjustColorShades($theme_color, 30)['lighter'];

// Set time zone
$timezone = !empty($websiteConfig['timezone']) ? $websiteConfig['timezone'] : 'Asia/Kolkata';
date_default_timezone_set($timezone);


// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user']);
}


/**
 * Checks if parent is authenticated (works for both web and mobile)
 */
function isParentAuthenticated() {
    // Check web session first
    if (isset($_SESSION['parent_logged_in']) && $_SESSION['parent_logged_in'] === true) {
        return true;
    }
    
    // Check web remember token
    if (!empty($_COOKIE['parent_remember_token'])) {
        global $pdo;
        $token = $_COOKIE['parent_remember_token'];
        $stmt = $pdo->prepare("SELECT * FROM parent_accounts WHERE remember_token = ? AND token_expiry > NOW()");
        $stmt->execute([$token]);
        $parent = $stmt->fetch();
        
        if ($parent) {
            $_SESSION['parent_logged_in'] = true;
            $_SESSION['parent_phone'] = $parent['phone_number'];
            return true;
        }
    }
    
    // Check mobile token
    $headers = getallheaders();
    if (!empty($headers['Authorization'])) {
        $authHeader = $headers['Authorization'];
        if (str_starts_with($authHeader, 'Bearer ')) {
            $token = substr($authHeader, 7);
            return validateMobileToken($token);
        }
    }
    
    return false;
}

/**
 * Validates mobile token and sets session if valid
 */
function validateMobileToken($token) {
    global $pdo;
    
    $tokenHash = hash('sha256', $token);
    $currentDateTime = date('Y-m-d H:i:s');

    $stmt = $pdo->prepare("SELECT p.* FROM parent_mobile_sessions s
                          JOIN parent_accounts p ON s.parent_id = p.id
                          WHERE s.token_hash = ? AND s.expires_at > ?");
    $stmt->execute([$tokenHash, $currentDateTime]);
    $parent = $stmt->fetch();

    if ($parent) {
        // Update session to work with web-based code
        $_SESSION['parent_logged_in'] = true;
        $_SESSION['parent_phone'] = $parent['phone_number'];
        return true;
    }
    
    return false;
}

/**
 * Checks if parent has access to specific student (works for both web and mobile)
 */
function hasParentAccessPermission($student_id) {
    global $pdo;
    
    // Get parent phone number from session (set by either web or mobile auth)
    if (empty($_SESSION['parent_phone'])) {
        return false;
    }
    
    $phone_number = $_SESSION['parent_phone'];
    
    // Check direct parent-student relationship
    $stmt = $pdo->prepare("SELECT 1 FROM students WHERE student_id = ? AND phone_number = ?");
    $stmt->execute([$student_id, $phone_number]);
    
    if ($stmt->fetch()) {
        return true;
    }
    
    // If using student_ids field in parent_accounts (comma-separated)
    $stmt = $pdo->prepare("SELECT 1 FROM parent_accounts 
                          WHERE phone_number = ? AND FIND_IN_SET(?, student_ids)");
    $stmt->execute([$phone_number, $student_id]);
    
    return (bool)$stmt->fetch();
}