<?php
// Detect current protocol (http or https)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';

// Check if the current host starts with "www."
if (strpos($_SERVER['HTTP_HOST'], 'www.') === 0) {
    // Remove "www." from the host
    $newUrl = $protocol . substr($_SERVER['HTTP_HOST'], 4) . $_SERVER['REQUEST_URI'];
    
    // Permanent redirect (301)
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: $newUrl");
    exit();
}

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once("db.php");
require_once("functions.php");

// Captcha Verify URL
$captchaVerifyUrl = "https://hcaptcha.com/siteverify";

// Get school information
$schoolInfo = $pdo->query("SELECT * FROM school_information LIMIT 1")->fetch();
$school_name = $schoolInfo['name'];

// Get website configuration
$imgbb_api_key = 'fea77adb2bb6adfce9d184e2851be8c5';
$theme_color = '#0d6efd ';
$currency_symbol = '₹';

$websiteConfig = $pdo->query("SELECT * FROM website_config LIMIT 1")->fetch();

if ($websiteConfig) {
    $theme_color = $websiteConfig['theme_color'];
    $imgbb_api_key = $websiteConfig['imgbb_api_key'];
    $currency_symbol = $websiteConfig['currency_symbol'];
}


$theme_color_dark = adjustColorShades($theme_color, 30)['darker'];
$theme_color_light = adjustColorShades($theme_color, 30)['lighter'];

// Set time zone
$timezone = !empty($websiteConfig['timezone']) ? $websiteConfig['timezone'] : 'Asia/Kolkata';
date_default_timezone_set($timezone);


// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user']);
}