<?php
// Detect current protocol (http or https)
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";

// Get the server host (e.g., localhost or example.com)
$host = $_SERVER['HTTP_HOST'];

// Get the directory of THIS file (e.g. C:/xampp/htdocs/myproject/includes)
$current_file_path = str_replace('\\', '/', __DIR__);

// Go UP one level to get the true project root (e.g. C:/xampp/htdocs/myproject)
$project_root = dirname($current_file_path); 

$server_root = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);

// Calculate the path relative to the server root
$folder_path = str_replace($server_root, '', $project_root);

// Construct the base URL
define('BASE_URL', $protocol . "://" . $host . $folder_path);

// Maximum number of document images that can be attached to a single teacher
define('MAX_TEACHER_DOCUMENTS', 15);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once(__DIR__ . "/db.php");
require_once(__DIR__ . "/functions.php");

// Captcha Verify URL (Cloudflare Turnstile)
$captchaVerifyUrl = "https://challenges.cloudflare.com/turnstile/v0/siteverify";

// Get school information
$schoolInfo = $pdo->query("SELECT * FROM school_information LIMIT 1")->fetch();
$school_name = $schoolInfo['name'];

// Default values
$imgbb_api_key = 'fea77adb2bb6adfce9d184e2851be8c5';
$theme_color = '#0d6efd ';
$currency_symbol = '₹';

$websiteConfig = $pdo->query("SELECT * FROM website_config LIMIT 1")->fetch();

if ($websiteConfig) {
    $theme_color = $websiteConfig['theme_color'];
    $imgbb_api_key = $websiteConfig['imgbb_api_key'];
    $currency_symbol = $websiteConfig['currency_symbol'];
}

$additional_website_configs = json_decode($websiteConfig['additional_settings'] ?? '{}', true);


$theme_color_dark = adjustColorShades($theme_color, 30)['darker'];
$theme_color_light = adjustColorShades($theme_color, 30)['lighter'];

// Set time zone
$timezone = !empty($websiteConfig['timezone']) ? $websiteConfig['timezone'] : 'Asia/Kolkata';
date_default_timezone_set($timezone);