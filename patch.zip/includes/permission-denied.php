<?php
echo "<div class='container'><div class='alert alert-danger mt-5'><h1 class='fw-bold'><i class=\"fa-solid fa-circle-exclamation\"></i> Permission Denied</h1><h5>You do not have permission to access this page.</h5></div></div>";
die();