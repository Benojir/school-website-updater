<?php
// No need to close PHP tag yet
echo '
<div style="
    position: fixed; 
    top: 0; 
    left: 0; 
    width: 100%; 
    height: 100%; 
    background: rgba(255, 255, 255, 0.5); 
    z-index: 9999; 
    display: flex; 
    align-items: center; 
    justify-content: center;
    backdrop-filter: blur(5px);
">
    <div class="text-center p-5 animate__animated animate__fadeIn">
        <div class="mb-4 text-danger">
            <i class="fa-solid fa-shield-halved fa-5x"></i>
        </div>
        <h1 class="display-4 fw-bold text-dark">403</h1>
        <h2 class="h4 mb-4 text-secondary">Permission Denied</h2>
        <p class="lead text-muted mb-5" style="max-width: 500px; margin: 0 auto;">
            You do not have the required permissions to access this resource.<br>
            Your attempt has been denied.
        </p>
        <a href="javascript:history.back()" class="btn btn-dark btn-lg px-5 rounded-pill shadow-sm">
            <i class="fa-solid fa-rotate-left me-2"></i> Return
        </a>
    </div>
</div>
</body>
</html>';

die();
?>