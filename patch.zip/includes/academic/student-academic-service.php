<?php
/**
 * Yearly enrollment is authoritative. students retains the operational projection
 * required by existing clients. This file has no bootstrap or migration side effects.
 */
function academicNormalizeYear(mixed $value, bool $allowNull = false): ?string
{
    if ($allowNull && ($value === null || $value === '')) return null;
    if (!is_scalar($value) || !preg_match('/^20[0-9]{2}$|^21[0-9]{2}$|^2200$/D', trim((string)$value))) {
        throw new InvalidArgumentException('Choose an academic year between 2000 and 2200.');
    }
    return trim((string)$value);
}

function academicCurrentYear(PDO $pdo): ?string
{
    $value = $pdo->query('SELECT current_academic_year FROM school_settings ORDER BY id LIMIT 1')->fetchColumn();
    return academicNormalizeYear($value === false ? null : $value, true);
}

function academicRequireCurrentYear(PDO $pdo): string
{
    $year = academicCurrentYear($pdo);
    if ($year === null) throw new RuntimeException('Set the current academic year in School Settings first. Review students with an unknown year before activation.');
    return $year;
}

function academicAssertReady(PDO $pdo): void
{
    $stmt = $pdo->prepare('SELECT phase FROM academic_schema_migrations WHERE migration_key = ?');
    $stmt->execute(['20260921_01_student_academic_history']);
    if ($stmt->fetchColumn() !== 'complete') throw new RuntimeException('Academic migration is not complete. Keep maintenance mode enabled and review migrate.sql.');
}

function academicTransaction(PDO $pdo, callable $work): mixed
{
    $owns = !$pdo->inTransaction();
    if ($owns) $pdo->beginTransaction();
    try {
        $result = $work();
        if ($owns) $pdo->commit();
        return $result;
    } catch (Throwable $e) {
        if ($owns && $pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

function academicLockSettings(PDO $pdo): void
{
    academicAssertReady($pdo);
    // Serializes enrollment uniqueness checks, including legacy registrations
    // which cannot safely acquire a UNIQUE index until duplicates are reviewed.
    $row = $pdo->query('SELECT id FROM school_settings ORDER BY id LIMIT 1 FOR UPDATE')->fetchColumn();
    if ($row === false) throw new RuntimeException('Save School Settings before changing academic records.');
}

function academicRequireStudentRow(PDO $pdo, string $studentId): array
{
    $stmt = $pdo->prepare('SELECT * FROM students WHERE student_id = ?');
    $stmt->execute([$studentId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) throw new InvalidArgumentException('Student not found.');
    return $row;
}

function academicGetRecord(PDO $pdo, int $studentRowId, ?string $year): ?array
{
    $year = academicNormalizeYear($year, true);
    $stmt = $pdo->prepare('SELECT * FROM student_academic_records WHERE student_row_id = ? AND academic_year <=> ?');
    $stmt->execute([$studentRowId, $year]);
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

function academicFields(): array
{
    return ['academic_year', 'class_id', 'section_id', 'roll_no', 'registration_no', 'admission_date', 'promoted_date', 'status', 'custom_class_fee'];
}

function academicDate(mixed $value): ?string
{
    if ($value === null || $value === '') return null;
    if (!is_string($value) || !preg_match('/^[1-9][0-9]{3}-[0-9]{2}-[0-9]{2}$/D', $value)) throw new InvalidArgumentException('Invalid academic date.');
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    if (!$date || $date->format('Y-m-d') !== $value) throw new InvalidArgumentException('Use a valid date in YYYY-MM-DD format.');
    return $value;
}

function academicYearForDate(PDO $pdo, string $date): string
{
    academicRequireCurrentYear($pdo);
    $valid = academicDate($date);
    if ($valid === null) throw new InvalidArgumentException('A date is required.');
    return academicNormalizeYear(substr($valid, 0, 4));
}

function academicPositiveId(mixed $value, string $label): ?int
{
    if ($value === null || $value === '') return null;
    if (!is_scalar($value) || is_bool($value) || !preg_match('/^[1-9][0-9]*$/D', (string)$value) || (float)$value > 2147483647) {
        throw new InvalidArgumentException($label . ' must be a positive whole number.');
    }
    return (int)$value;
}

function academicNormalizeFields(array $input): array
{
    $data = array_intersect_key($input, array_flip(academicFields()));
    $data['academic_year'] = academicNormalizeYear($data['academic_year'] ?? null);
    foreach (['class_id', 'section_id', 'roll_no'] as $key) $data[$key] = academicPositiveId($data[$key] ?? null, $key);
    if ($data['class_id'] === null && ($data['section_id'] !== null || $data['roll_no'] !== null)) {
        throw new InvalidArgumentException('Select a class before assigning a section or roll.');
    }
    $reg = $data['registration_no'] ?? null;
    if ($reg !== null && !is_scalar($reg)) throw new InvalidArgumentException('Invalid registration number.');
    $registration = trim((string)$reg);
    $data['registration_no'] = $registration === '' ? null : $registration;
    if ($data['registration_no'] !== null && mb_strlen($data['registration_no']) > 50) throw new InvalidArgumentException('Registration number is limited to 50 characters.');
    $statuses = ['active' => 'Active', 'left' => 'Left', 'alumni' => 'Alumni'];
    $status = strtolower((string)($data['status'] ?? 'Active'));
    if (!isset($statuses[$status])) throw new InvalidArgumentException('Invalid enrollment status.');
    $data['status'] = $statuses[$status];
    foreach (['admission_date', 'promoted_date'] as $key) $data[$key] = academicDate($data[$key] ?? null);
    $fee = $data['custom_class_fee'] ?? 0;
    if (!is_scalar($fee) || !is_numeric($fee) || !is_finite((float)$fee) || (float)$fee < 0 || (float)$fee > 99999999.99) {
        throw new InvalidArgumentException('Custom class fee must be a nonnegative amount.');
    }
    $data['custom_class_fee'] = number_format((float)$fee, 2, '.', '');
    return $data;
}

function academicNormalizeUpdate(array $fields, ?array $existing): array
{
    if (!$existing) return academicNormalizeFields($fields);
    $validation = array_replace($existing, $fields);
    $preserved = [];
    // Editing one field must not trim an old registration, turn NULL status into
    // Active, or otherwise rewrite unrelated legacy values as a side effect.
    $neutral = ['roll_no' => null, 'registration_no' => null, 'admission_date' => null,
        'promoted_date' => null, 'status' => 'Active', 'custom_class_fee' => 0];
    foreach ($neutral as $key => $value) {
        if (!array_key_exists($key, $existing)) continue;
        $same = !array_key_exists($key, $fields) || $fields[$key] === $existing[$key];
        if (!$same && $fields[$key] !== null && $existing[$key] !== null && is_scalar($fields[$key]) && is_scalar($existing[$key])) {
            $same = (string)$fields[$key] === (string)$existing[$key];
        }
        if ($same) {
            $preserved[$key] = $existing[$key];
            $validation[$key] = $value;
        }
    }
    return array_replace(academicNormalizeFields($validation), $preserved);
}

function academicSaveRecord(PDO $pdo, int $studentRowId, array $fields, ?int $recordId = null, bool $createOnly = false): array
{
    return academicTransaction($pdo, function () use ($pdo, $studentRowId, $fields, $recordId, $createOnly) {
        academicLockSettings($pdo);
        $lock = $pdo->prepare('SELECT id FROM students WHERE id = ? FOR UPDATE');
        $lock->execute([$studentRowId]);
        if (!$lock->fetchColumn()) throw new InvalidArgumentException('Student not found.');
        $year = academicNormalizeYear($fields['academic_year'] ?? null);
        if ($recordId !== null) {
            $stmt = $pdo->prepare('SELECT * FROM student_academic_records WHERE id = ? AND student_row_id = ? FOR UPDATE');
            $stmt->execute([$recordId, $studentRowId]);
            $existing = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$existing) throw new InvalidArgumentException('Academic record not found for this student.');
            if ($existing['academic_year'] !== null && $existing['academic_year'] !== $year) {
                throw new InvalidArgumentException('An existing academic year cannot be replaced. Use promotion/re-admission to create another year.');
            }
        } else {
            $existing = academicGetRecord($pdo, $studentRowId, $year);
        }
        if ($createOnly && $existing) throw new InvalidArgumentException('This student already has an academic record for ' . $year . '. Edit that record instead.');
        $data = academicNormalizeUpdate($fields, $existing ?: null);
        if ($data['class_id'] === null && ($data['section_id'] !== null || $data['roll_no'] !== null)) throw new InvalidArgumentException('Select a class before assigning a section or roll.');
        if ($data['class_id'] !== null) {
            $stmt = $pdo->prepare('SELECT id FROM classes WHERE id = ?');
            $stmt->execute([$data['class_id']]);
            if (!$stmt->fetchColumn()) throw new InvalidArgumentException('Class not found.');
        }
        if ($data['section_id'] !== null) {
            $stmt = $pdo->prepare('SELECT id FROM sections WHERE id = ? AND class_id = ?');
            $stmt->execute([$data['section_id'], $data['class_id']]);
            if (!$stmt->fetchColumn()) throw new InvalidArgumentException('The section does not belong to this class.');
        }
        $exclude = (int)($existing['id'] ?? 0);
        if ($data['roll_no'] !== null) {
            $stmt = $pdo->prepare('SELECT id FROM student_academic_records WHERE academic_year = ? AND class_id = ? AND COALESCE(section_id, 0) = ? AND roll_no = ? AND id <> ? LIMIT 1');
            $stmt->execute([$year, $data['class_id'], $data['section_id'] ?? 0, $data['roll_no'], $exclude]);
            if ($stmt->fetchColumn()) throw new InvalidArgumentException('Roll ' . $data['roll_no'] . ' is already assigned in this class and section for ' . $year . '.');
        }
        // Resolving an unknown legacy year must retain its unchanged registration,
        // including pre-existing duplicates. Enforce uniqueness for new records
        // and explicitly changed registration values. Known years cannot be moved.
        $registrationChanged = !$existing || $existing['registration_no'] !== $data['registration_no'];
        if ($data['registration_no'] !== null && $registrationChanged) {
            $stmt = $pdo->prepare('SELECT id FROM student_academic_records WHERE academic_year = ? AND registration_no = ? AND id <> ? LIMIT 1');
            $stmt->execute([$year, $data['registration_no'], $exclude]);
            if ($stmt->fetchColumn()) throw new InvalidArgumentException('Registration number is already assigned for ' . $year . '.');
        }
        $keys = academicFields();
        if ($existing) {
            // A legacy zero/partial date can remain stored, but rebinding that
            // same value may fail under strict SQL modes. Unrelated edits must
            // leave these columns untouched rather than clearing or guessing.
            $keys = array_values(array_filter($keys, static fn($key) =>
                !in_array($key, ['admission_date', 'promoted_date'], true)
                || $data[$key] !== $existing[$key]
            ));
        }
        $values = array_map(static fn($key) => $data[$key], $keys);
        if ($existing) {
            $stmt = $pdo->prepare('UPDATE student_academic_records SET ' . implode(', ', array_map(static fn($key) => '`' . $key . '` = ?', $keys)) . ', updated_at = CURRENT_TIMESTAMP WHERE id = ?');
            $stmt->execute([...$values, $existing['id']]);
            $savedId = (int)$existing['id'];
        } else {
            $stmt = $pdo->prepare('INSERT INTO student_academic_records (student_row_id, ' . implode(', ', $keys) . ') VALUES (' . implode(', ', array_fill(0, count($keys) + 1, '?')) . ')');
            $stmt->execute([$studentRowId, ...$values]);
            $savedId = (int)$pdo->lastInsertId();
        }
        academicSyncStudent($pdo, $studentRowId);
        return ['id' => $savedId, 'student_row_id' => $studentRowId] + $data;
    });
}

function academicCaptureNewStudent(PDO $pdo, int $studentRowId, array $fields): array
{
    return academicTransaction($pdo, function () use ($pdo, $studentRowId, $fields) {
        academicRequireCurrentYear($pdo);
        $record = academicSaveRecord($pdo, $studentRowId, $fields, null, true);
        if (($fields['_verified_first_admission'] ?? true) && $record['admission_date'] !== null) {
            $stmt = $pdo->prepare('UPDATE students SET first_admission_date = ? WHERE id = ? AND first_admission_date IS NULL');
            $stmt->execute([$record['admission_date'], $studentRowId]);
        }
        return $record;
    });
}

function academicSaveRecordsBatch(PDO $pdo, array $changes): array
{
    return academicTransaction($pdo, function () use ($pdo, $changes) {
        academicLockSettings($pdo);
        $prepared = [];
        foreach ($changes as $change) {
            $rowId = (int)($change['student_row_id'] ?? 0);
            $recordId = (int)($change['record_id'] ?? 0);
            if (!$rowId || !$recordId || isset($prepared[$recordId])) throw new InvalidArgumentException('Invalid or repeated academic record.');
            $stmt = $pdo->prepare('SELECT * FROM student_academic_records WHERE id = ? AND student_row_id = ? FOR UPDATE');
            $stmt->execute([$recordId, $rowId]);
            $record = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$record) throw new InvalidArgumentException('Academic record not found.');
            $prepared[$recordId] = ['student_row_id' => $rowId, 'fields' => array_replace($record, $change['fields'])];
        }
        // Clear only within this transaction so valid roll/section swaps have no
        // intermediate collision. Any failed validation restores the entire batch.
        foreach ($prepared as $recordId => $change) {
            $stmt = $pdo->prepare('UPDATE student_academic_records SET roll_no = NULL WHERE id = ?');
            $stmt->execute([$recordId]);
            $stmt = $pdo->prepare('UPDATE students SET roll_no = NULL WHERE id = ?');
            $stmt->execute([$change['student_row_id']]);
        }
        $saved = [];
        foreach ($prepared as $recordId => $change) $saved[] = academicSaveRecord($pdo, $change['student_row_id'], $change['fields'], $recordId);
        return $saved;
    });
}

function academicProjection(array $student, array $records, ?string $currentYear): ?array
{
    // Pure selection logic: never let an upcoming enrollment replace a current one.
    if ($currentYear === null) {
        foreach ($records as $record) if ($record['academic_year'] === ($student['academic_year'] ?? null)) return $record;
        return count($records) === 1 ? $records[0] : null;
    }
    foreach ($records as $record) if ($record['academic_year'] === $currentYear) return $record;
    $known = array_values(array_filter($records, static fn($record) => $record['academic_year'] !== null));
    usort($known, static fn($a, $b) => strcmp($a['academic_year'], $b['academic_year']));
    foreach ($known as $record) {
        if ($record['academic_year'] > $currentYear && strtolower((string)$record['status']) === 'active') {
            $record['status'] = 'Upcoming';
            return $record;
        }
    }
    $past = array_values(array_filter($known, static fn($record) => $record['academic_year'] < $currentYear));
    $record = $past ? end($past) : ($known[0] ?? $records[0] ?? null);
    if ($record && strtolower((string)$record['status']) === 'active') $record['status'] = 'Unassigned';
    return $record;
}

function academicSyncStudent(PDO $pdo, int $studentRowId): void
{
    $stmt = $pdo->prepare('SELECT * FROM students WHERE id = ?');
    $stmt->execute([$studentRowId]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$student) throw new InvalidArgumentException('Student not found.');
    $stmt = $pdo->prepare('SELECT * FROM student_academic_records WHERE student_row_id = ? ORDER BY id');
    $stmt->execute([$studentRowId]);
    $record = academicProjection($student, $stmt->fetchAll(PDO::FETCH_ASSOC), academicCurrentYear($pdo));
    if (!$record) return;
    $keys = academicFields();
    foreach (['admission_date' => 'annual admission date', 'promoted_date' => 'promotion date'] as $key => $label) {
        if ($record[$key] === $student[$key]) {
            $keys = array_values(array_diff($keys, [$key]));
            continue;
        }
        try {
            academicDate($record[$key]);
        } catch (InvalidArgumentException $e) {
            $identity = trim((string)($student['student_id'] ?? '')) ?: '#' . $studentRowId;
            $year = $record['academic_year'] ?? 'unknown year';
            throw new RuntimeException('Student ' . $identity . ' (' . $year . ') has a legacy ' . $label . ' that needs review in Academic History before changing the school year or updating this profile.', 0, $e);
        }
    }
    $stmt = $pdo->prepare('UPDATE students SET ' . implode(', ', array_map(static fn($key) => '`' . $key . '` = ?', $keys)) . ' WHERE id = ?');
    $stmt->execute([...array_map(static fn($key) => $record[$key], $keys), $studentRowId]);
}

function academicSetStatus(PDO $pdo, string $studentId, string $status, ?string $year = null, ?string $date = null): void
{
    $year = $year ?? academicRequireCurrentYear($pdo);
    $student = academicRequireStudentRow($pdo, $studentId);
    $record = academicGetRecord($pdo, (int)$student['id'], $year);
    if (!$record) throw new InvalidArgumentException('This student has no enrollment for ' . $year . '.');
    $fields = ['academic_year' => $year, 'status' => $status];
    if ($date !== null) $fields['promoted_date'] = academicDate($date);
    academicSaveRecord($pdo, (int)$student['id'], $fields, (int)$record['id']);
}

function academicSetCurrentYear(PDO $pdo, string $year): void
{
    $year = academicNormalizeYear($year);
    academicTransaction($pdo, function () use ($pdo, $year) {
        academicLockSettings($pdo);
        $unknown = (int)$pdo->query("SELECT COUNT(*) FROM student_academic_records WHERE academic_year IS NULL AND LOWER(status) = 'active'")->fetchColumn();
        if ($unknown) throw new InvalidArgumentException('Review the unknown academic year of ' . $unknown . ' active legacy student(s) before activating a year. Open Academic History / Legacy Review.');
        $current = academicCurrentYear($pdo);
        if ($current === $year) return;
        $stmt = $pdo->prepare('UPDATE school_settings SET current_academic_year = ? ORDER BY id LIMIT 1');
        $stmt->execute([$year]);
        // Compatibility projection changes atomically with the selected school year.
        $ids = $pdo->query('SELECT id FROM students ORDER BY id')->fetchAll(PDO::FETCH_COLUMN);
        foreach ($ids as $id) academicSyncStudent($pdo, (int)$id);
    });
}

function academicStudentSourceSql(PDO $pdo, ?string $year = null): string
{
    if ($year === null || $year === '') return 'students';
    $year = academicNormalizeYear($year);
    // Derive columns from this school's table, preserving additional client columns.
    // Only validated metadata identifiers and validated YYYY are interpolated.
    $columns = $pdo->query('SHOW COLUMNS FROM students')->fetchAll(PDO::FETCH_COLUMN);
    $academic = array_flip(academicFields());
    $select = [];
    foreach ($columns as $column) {
        if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/D', $column)) throw new RuntimeException('Unsupported student column identifier.');
        $select[] = (isset($academic[$column]) ? 'ar' : 'sp') . '.`' . $column . '`';
    }
    return '(SELECT ' . implode(', ', $select) . ', ar.id AS academic_record_id, sp.status AS profile_status FROM students sp JOIN student_academic_records ar ON ar.student_row_id = sp.id WHERE ar.academic_year = ' . $pdo->quote($year) . ')';
}

function academicGetStudent(PDO $pdo, string $studentId, ?string $year = null): ?array
{
    $source = academicStudentSourceSql($pdo, $year);
    $stmt = $pdo->prepare('SELECT s.*, c.class_name, sec.section_name FROM ' . $source . ' s LEFT JOIN classes c ON c.id = s.class_id LEFT JOIN sections sec ON sec.id = s.section_id WHERE s.student_id = ?');
    $stmt->execute([$studentId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) return null;
    $row['current_academic_year'] = academicCurrentYear($pdo);
    $row['enrollment_status'] = $row['status'];
    return $row;
}

function academicGetHistory(PDO $pdo, int $studentRowId): array
{
    $stmt = $pdo->prepare('SELECT ar.*, c.class_name, sec.section_name FROM student_academic_records ar LEFT JOIN classes c ON c.id = ar.class_id LEFT JOIN sections sec ON sec.id = ar.section_id WHERE ar.student_row_id = ? ORDER BY ar.academic_year DESC, ar.id DESC');
    $stmt->execute([$studentRowId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function academicRequestedYear(array $input): ?string
{
    return academicNormalizeYear($input['selected_year'] ?? $input['academic_year'] ?? null, true);
}
