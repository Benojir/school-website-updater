<?php

/** Parse an explicitly selected monthly billing period; never infer an enrollment year. */
function academicBillingYear(string $monthYear): string
{
    $date = DateTimeImmutable::createFromFormat('!F Y', $monthYear);
    if (!$date || $date->format('F Y') !== $monthYear) {
        throw new InvalidArgumentException('Please select a valid billing month (for example January 2027).');
    }
    return $date->format('Y');
}

/** Existing result identity is a historical snapshot, including intentionally blank rolls. */
function academicResultSnapshot(?array $existing, ?array $enrollment, int $classId): array
{
    if ($existing) {
        if ((int)$existing['class_id'] !== $classId) {
            throw new InvalidArgumentException('The selected class does not match the saved result.');
        }
        return ['class_id' => $classId, 'section_id' => $existing['section_id'], 'roll_no' => $existing['result_roll_no']];
    }
    if (!$enrollment || (int)$enrollment['class_id'] !== $classId) {
        throw new InvalidArgumentException('The student has no enrollment in this exam year and class.');
    }
    return ['class_id' => $classId, 'section_id' => $enrollment['section_id'], 'roll_no' => $enrollment['roll_no']];
}

/** Select the active current enrollment as the rate source; advance months may cross years. */
function academicCanGenerateAutomaticFee(?string $currentYear, string $billingYear, ?array $enrollment): bool
{
    return $currentYear !== null && $billingYear === $currentYear && $enrollment !== null
        && (string)($enrollment['academic_year'] ?? '') === $billingYear
        && strcasecmp((string)($enrollment['status'] ?? ''), 'Active') === 0;
}

function academicRequireExamYear(PDO $pdo, int $examId): string
{
    $stmt = $pdo->prepare('SELECT academic_year FROM exams WHERE id = ?');
    $stmt->execute([$examId]);
    $year = $stmt->fetchColumn();
    if ($year === false || $year === null || trim((string)$year) === '') {
        throw new InvalidArgumentException('Set the academic year of this exam in Manage Examinations before continuing.');
    }
    return academicNormalizeYear($year);
}
