<?php

/**
 * Students results rank function
 */
function getStudentPositionInClass(PDO $pdo, $examId, $classId, $studentId, $includeMinorSubjectsMarks, $section_id = null) {

    // 1. Select the correct column based on the flag
    $column = $includeMinorSubjectsMarks ? 'percentage' : 'percentage_without_minor';
    
    // 2. Start building SQL
    $sql = "SELECT student_id, $column as percentage 
            FROM results 
            WHERE exam_id = ? AND class_id = ?";
    
    // 3. Start building Parameters Array
    $params = [$examId, $classId];

    // 4. Add Section ID if provided
    if ($section_id) {
        $sql .= " AND section_id = ?";
        $params[] = $section_id; 
    }

    $sql .= " ORDER BY percentage DESC";

    // Step 1: Execute with the DYNAMIC params array
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params); 
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Step 2: Rank students (Dense Ranking: 1, 1, 1, 1, 2...)
    $rank = 0;
    $lastMarks = null;

    foreach ($results as $row) {
        
        // Only increase the rank number if the percentage is DIFFERENT from the last one
        if ($lastMarks === null || $row['percentage'] != $lastMarks) {
            $rank++; 
            $lastMarks = $row['percentage'];
        }

        if ($row['student_id'] == $studentId) {
            return $rank;
        }
    }

    return null;
}

// Get Ordinal function
function getOrdinal($number) {
    $suffix = ['th', 'st', 'nd', 'rd'];
    $mod100 = $number % 100;
    return $number . ($suffix[($mod100 - 20) % 10] ?? $suffix[$mod100] ?? $suffix[0]);
}

// Get Pass/Fail status based on grade
function getPassFailStatus($grade) {
    if ($grade == 'D' || $grade == 'F') {
        return '<b style="color:#FF0000;">FAIL</b>';
    } else {
        return '<b style="color:#008000;">PASS</b>';
    }
}

// Calculate overall grade based on percentage
function calculateGrade($percentage)
{
    // Implement your grade calculation logic
    if ($percentage >= 90) return 'AA';
    if ($percentage >= 80) return 'A+';
    if ($percentage >= 70) return 'A';
    if ($percentage >= 60) return 'B+';
    if ($percentage >= 50) return 'B';
    if ($percentage >= 40) return 'C+';
    if ($percentage >= 35) return 'C';
    return 'D';
}

// Get remarks based on grade
function getRemarksByGrade($grade) {
    $remarks = [
        'AA' => 'Outstanding',
        'A+' => 'Excellent',
        'A' => 'Very Good',
        'B+' => 'Good',
        'B' => 'Satisfactory',
        'C+' => 'Acceptable',
        'C' => 'Basic',
        'D' => 'Disqualified'
    ];
    return $remarks[$grade] ?? '-';
}

// Get class name by ID
function getClassNameById(PDO $pdo, $classId) {
    $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
    $stmt->execute([$classId]);
    return $stmt->fetchColumn() ?: 'Unknown Class';
}

// Get section name by ID
function getSectionNameById(PDO $pdo, $sectionId) {
    $stmt = $pdo->prepare("SELECT section_name FROM sections WHERE id = ?");
    $stmt->execute([$sectionId]);
    return $stmt->fetchColumn() ?: 'Not Assigned';
}


/**
 * Generate unique student ID
 */
function generateUniqueStudentId($pdo, $prefix)
{
    do {
        $student_id = $prefix . str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT);
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE student_id = ?");
        $stmt->execute([$student_id]);
    } while ($stmt->fetchColumn() > 0);

    return $student_id;
}

// Generate academic year
function generateAcademicYear() {
    $currentYear = date('Y');
    $data = array($currentYear, $currentYear + 1);
    return json_encode($data);
}


// Get top rankers for single marksheet
function getTopRankersForSingleMarksheet($pdo, $classId, $examId, $include_minor_subjects_marks = false, $section_id = null, $total_students = 5) {
    
    if ($total_students <= 0) {
        $total_students = 5;
    }
    // 1. Dynamic Column Selection (Normal vs Without Minor)
    // We select the specific column but alias it as 'percentage'/'grade' so the rest of the code doesn't need to change.
    $colPercentage = $include_minor_subjects_marks ? 'r.percentage' : 'r.percentage_without_minor';
    $colGrade      = $include_minor_subjects_marks ? 'r.grade' : 'r.grade_without_minor';

    // 2. Start Building SQL
    $sql = "SELECT s.name, s.roll_no, s.status as student_status, r.student_id, $colPercentage as percentage, $colGrade as grade, r.obtained_marks, r.obtained_minor_marks, c.class_name, sec.section_name 
            FROM results r 
            JOIN students s ON r.student_id = s.student_id 
            JOIN classes c ON r.class_id = c.id
            LEFT JOIN sections sec ON r.section_id = sec.id
            WHERE r.class_id = ? AND r.exam_id = ?";
            
    // 3. Dynamic Parameters Array (Crucial for preventing crashes)
    $params = [$classId, $examId];

    // 4. Add Section Filter if provided
    if ($section_id) {
        $sql .= " AND r.section_id = ?";
        $params[] = $section_id;
    }

    // 5. Order and Limit
    $sql .= " ORDER BY percentage DESC LIMIT $total_students";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rankers_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $rankers = [];
    $rank = 0; // Start at 0
    $prev_percentage = null;

    foreach ($rankers_data as $row) {
        
        // DENSE RANKING LOGIC (1, 1, 1, 1, 2)
        // Only increase rank if the percentage is different from the previous one
        if ($prev_percentage === null || $row['percentage'] != $prev_percentage) {
            $rank++; 
        }

        if ($row['roll_no'] == 0 || $row['roll_no'] == null) {
            $row['roll_no'] = '-';
        }

        if ($row['obtained_minor_marks'] == null) {
            $row['obtained_minor_marks'] = 0;
        }

        if ($row['obtained_marks'] == null) {
            $row['obtained_marks'] = 0;
        } else {
            if (!$include_minor_subjects_marks) {
                 $row['obtained_marks'] = $row['obtained_marks'] - $row['obtained_minor_marks'];
            }
        }

        if ($row['obtained_minor_marks'] == null) {
            $row['obtained_minor_marks'] = 0;
        }

        if ($row['section_name'] == null) {
            $row['section_name'] = '-';
        }

        $rankers[] = [
            'name'                       => $row['name'],
            'student_status'             => $row['student_status'],
            'percentage'                 => $row['percentage'],
            'grade'                      => $row['grade'],
            'rank'                       => $rank,
            'roll_no'                    => $row['roll_no'],
            'student_id'                 => $row['student_id'],
            'obtained_marks'             => $row['obtained_marks'],
            'obtained_minor_marks'       => $row['obtained_minor_marks'],
            'class_name'                 => $row['class_name'],
            'section_name'               => $row['section_name']
        ];

        $prev_percentage = $row['percentage'];
    }

    return $rankers;
}