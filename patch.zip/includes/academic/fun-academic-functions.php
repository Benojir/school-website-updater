<?php

// Get section name by ID
function getSectionNameById(PDO $pdo, $sectionId) {
    $stmt = $pdo->prepare("SELECT section_name FROM sections WHERE id = ?");
    $stmt->execute([$sectionId]);
    return $stmt->fetchColumn() ?: 'Not Assigned';
}