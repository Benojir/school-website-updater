<?php

// Get section name by ID
function getSectionNameById(PDO $pdo, $sectionId) {
    $stmt = $pdo->prepare("SELECT section_name FROM sections WHERE id = ?");
    $stmt->execute([$sectionId]);
    return $stmt->fetchColumn() ?: 'Not Assigned';
}


/**
 * Generate unique student ID
 */
function generateUniqueStudentId($pdo, $prefix)
{
    do {
        $student_id = $prefix . str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT);
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE student_id = ?");
        $stmt->execute([$student_id]);
    } while ($stmt->fetchColumn() > 0);

    return $student_id;
}

// Generate academic year
function generateAcademicYear() {
    $currentYear = date('Y');
    $data = array($currentYear, $currentYear + 1);
    return json_encode($data);
}
