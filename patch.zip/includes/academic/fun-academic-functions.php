<?php

/**
 * Students results rank function
 */
function getStudentPositionInClass(PDO $pdo, int $examId, int $classId, string $studentId): ?int {
    // Step 1: Fetch all results for the given exam and class
    $stmt = $pdo->prepare("SELECT student_id, percentage 
                           FROM results 
                           WHERE exam_id = ? AND class_id = ? 
                           ORDER BY percentage DESC");
    $stmt->execute([$examId, $classId]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Step 2: Rank students with tie handling
    $position = 0;
    $rank = 0;
    $lastMarks = null;

    foreach ($results as $row) {
        $position++;

        if ($lastMarks === null || $row['percentage'] != $lastMarks) {
            $rank = $position;
            $lastMarks = $row['percentage'];
        }

        if ($row['student_id'] === $studentId) {
            return $rank;
        }
    }

    // If student not found in results
    return null;
}

// Get Ordinal function
function getOrdinal($number) {
    $suffix = ['th', 'st', 'nd', 'rd'];
    $mod100 = $number % 100;
    return $number . ($suffix[($mod100 - 20) % 10] ?? $suffix[$mod100] ?? $suffix[0]);
}

// Get Pass/Fail status based on grade
function getPassFailStatus($grade) {
    if ($grade == 'D' || $grade == 'F') {
        return '<b style="color:#FF0000;">FAIL</b>';
    } else {
        return '<b style="color:#008000;">PASS</b>';
    }
}

// Calculate overall grade based on percentage
function calculateGrade($percentage)
{
    // Implement your grade calculation logic
    if ($percentage >= 90) return 'AA';
    if ($percentage >= 80) return 'A+';
    if ($percentage >= 70) return 'A';
    if ($percentage >= 60) return 'B+';
    if ($percentage >= 50) return 'B';
    if ($percentage >= 40) return 'C+';
    if ($percentage >= 35) return 'C';
    return 'D';
}

// Get remarks based on grade
function getRemarksByGrade($grade) {
    $remarks = [
        'AA' => 'Outstanding',
        'A+' => 'Excellent',
        'A' => 'Very Good',
        'B+' => 'Good',
        'B' => 'Satisfactory',
        'C+' => 'Acceptable',
        'C' => 'Basic',
        'D' => 'Disqualified'
    ];
    return $remarks[$grade] ?? '-';
}

// Get class name by ID
function getClassNameById(PDO $pdo, $classId) {
    $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
    $stmt->execute([$classId]);
    return $stmt->fetchColumn() ?: 'Unknown Class';
}

// Get section name by ID
function getSectionNameById(PDO $pdo, $sectionId) {
    $stmt = $pdo->prepare("SELECT section_name FROM sections WHERE id = ?");
    $stmt->execute([$sectionId]);
    return $stmt->fetchColumn() ?: 'Not Assigned';
}


/**
 * Generate unique student ID
 */
function generateUniqueStudentId($pdo, $prefix)
{
    do {
        $student_id = $prefix . str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT);
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE student_id = ?");
        $stmt->execute([$student_id]);
    } while ($stmt->fetchColumn() > 0);

    return $student_id;
}

// Generate academic year
function generateAcademicYear() {
    $currentYear = date('Y');
    $data = array($currentYear, $currentYear + 1);
    return json_encode($data);
}


// Get top rankers for single marksheet
function getTopRankersForSingleMarksheet($pdo, $classId, $examId) {
    // 1. Fetch slightly more than 5 rows in case of ties
    // Note: If you want exactly 5 people regardless of rank, keep LIMIT 5.
    $sql = "SELECT s.name, r.percentage, r.grade 
            FROM results r 
            JOIN students s ON r.student_id = s.student_id 
            WHERE r.class_id = ? AND r.exam_id = ? 
            ORDER BY r.percentage DESC LIMIT 5";
            
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$classId, $examId]);
    $rankers_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $rankers = [];
    $current_rank = 0;
    $prev_percentage = null;

    foreach ($rankers_data as $row) {
        // 2. Compare current percentage with the previous one
        // If they are NOT equal, we move to the next rank number
        if ($row['percentage'] !== $prev_percentage) {
            $current_rank++; 
        }

        // 3. Build the ranker array
        $rankers[] = [
            'name'       => $row['name'],
            'percentage' => $row['percentage'],
            'grade'      => $row['grade'],
            'rank'       => $current_rank // Assign the calculated rank
        ];

        // 4. Update previous percentage for the next iteration
        $prev_percentage = $row['percentage'];
    }

    return $rankers;
}