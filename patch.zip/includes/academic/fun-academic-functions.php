<?php

/**
 * Students results rank function
 */
function getStudentPositionInClass(PDO $pdo, mixed $examId, mixed $classId, string $studentId, mixed $includeMinorSubjectsMarks, $section_id = null) {

    // 1. Select the correct column based on the flag
    $column = $includeMinorSubjectsMarks ? 'percentage' : 'percentage_without_minor';
    
    // 2. Start building SQL
    $sql = "SELECT student_id, $column as percentage 
            FROM results 
            WHERE exam_id = ? AND class_id = ?";
    
    // 3. Start building Parameters Array
    $params = [$examId, $classId];

    // 4. Add Section ID if provided
    if ($section_id) {
        $sql .= " AND section_id = ?";
        $params[] = $section_id; 
    }

    $sql .= " ORDER BY percentage DESC";

    // Step 1: Execute with the DYNAMIC params array
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params); 
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Step 2: Rank students (Dense Ranking: 1, 1, 1, 1, 2...)
    $rank = 0;
    $lastMarks = null;

    foreach ($results as $row) {
        
        // Only increase the rank number if the percentage is DIFFERENT from the last one
        if ($lastMarks === null || $row['percentage'] != $lastMarks) {
            $rank++; 
            $lastMarks = $row['percentage'];
        }

        if ($row['student_id'] == $studentId) {
            return $rank;
        }
    }

    return null;
}

/**
 * Rank the whole class using the same subject totals as combined marksheets.
 * Call once per class/section, then look up each student's position in the map.
 */
function getStudentPositionsForCombinedMarksheet(PDO $pdo, array $examIds, mixed $classId, bool $includeMinorSubjectsMarks, bool $makeOverallAverage = false, $sectionId = null): array {
    return array_column(getTopRankersForCombinedMarksheet(
        $pdo, $examIds, $classId, $includeMinorSubjectsMarks, $makeOverallAverage, $sectionId
    ), 'rank', 'student_id');
}

function getTopRankersForCombinedMarksheet(PDO $pdo, array $examIds, mixed $classId, bool $includeMinorSubjectsMarks, bool $makeOverallAverage = false, $sectionId = null): array {
    $examIds = array_values(array_unique(array_filter(array_map('intval', $examIds), fn($id) => $id > 0)));
    if (!$examIds || !$classId) {
        return [];
    }
    sort($examIds);
    $placeholders = implode(',', array_fill(0, count($examIds), '?'));

    // Keep all sections' subject rows: filtering individual exams would change
    // the combined percentage of a student who moved between sections.
    // Students with selected results in different classes are skipped by the designs.
    $stmt = $pdo->prepare("SELECT r.student_id, r.exam_id, r.section_id, r.result_roll_no AS roll_no,
                                 s.name, s.status AS student_status, c.class_name, sec.section_name,
                                 sm.subject_id, sm.is_excluded, sm.total_marks, sm.obtained_marks,
                                 sub.subject_name, sub.subject_type
                          FROM results r
                          JOIN exams e ON e.id = r.exam_id
                          JOIN classes c ON c.id = r.class_id
                          LEFT JOIN students s ON s.student_id = r.student_id
                          LEFT JOIN sections sec ON sec.id = r.section_id
                          LEFT JOIN subject_marks sm ON sm.result_id = r.id
                          LEFT JOIN subjects sub ON sub.id = sm.subject_id
                          WHERE r.class_id = ? AND r.exam_id IN ($placeholders)
                            AND NOT EXISTS (
                                SELECT 1 FROM results other_result
                                WHERE other_result.student_id = r.student_id
                                  AND other_result.exam_id IN ($placeholders)
                                  AND other_result.class_id <> r.class_id
                            )
                          ORDER BY r.exam_id ASC, sub.marksheet_order_by ASC");
    $stmt->execute(array_merge([$classId], $examIds, $examIds));

    return calculateCombinedMarksheetRankers(
        $stmt->fetchAll(PDO::FETCH_ASSOC), $includeMinorSubjectsMarks, $makeOverallAverage, $sectionId
    );
}

/**
 * Subject rows must be ordered by exam ID, as in all three combined designs.
 * Missing exams contribute no marks; exclusions from the first available exam
 * apply to all selected exams. Average mode divides each subject by its own count.
 */
function calculateCombinedMarksheetPositions(array $rows, bool $includeMinorSubjectsMarks, bool $makeOverallAverage = false, $sectionId = null): array {
    return array_column(calculateCombinedMarksheetRankers(
        $rows, $includeMinorSubjectsMarks, $makeOverallAverage, $sectionId
    ), 'rank', 'student_id');
}

function calculateCombinedMarksheetRankers(array $rows, bool $includeMinorSubjectsMarks, bool $makeOverallAverage = false, $sectionId = null): array {
    $students = [];
    foreach ($rows as $row) {
        $studentId = $row['student_id'];
        if (!isset($students[$studentId])) {
            $students[$studentId] = [
                'first_exam_id' => $row['exam_id'],
                'section_id' => $row['section_id'],
                'details' => [
                    'student_id' => $studentId,
                    'name' => $row['name'] ?? '-',
                    'student_status' => $row['student_status'] ?? '',
                    'class_name' => $row['class_name'] ?? '-',
                    'section_name' => !empty($row['section_name']) ? $row['section_name'] : '-',
                    'roll_no' => !empty($row['roll_no']) ? $row['roll_no'] : '-'
                ],
                'excluded' => [],
                'subjects' => []
            ];
        }
        $student = &$students[$studentId];
        if ($row['subject_name'] === null) {
            unset($student);
            continue;
        }
        if ($row['exam_id'] == $student['first_exam_id'] && $row['is_excluded']) {
            $student['excluded'][$row['subject_id']] = true;
        }
        if (isset($student['excluded'][$row['subject_id']])) {
            unset($student);
            continue;
        }

        // Combined templates group subjects by name across exams.
        $name = $row['subject_name'];
        if (!isset($student['subjects'][$name])) {
            $student['subjects'][$name] = ['total' => 0, 'obtained' => 0, 'count' => 0];
        }
        $student['subjects'][$name]['type'] = $row['subject_type'];
        $student['subjects'][$name]['total'] += (float)$row['total_marks'];
        $student['subjects'][$name]['obtained'] += (float)$row['obtained_marks'];
        $student['subjects'][$name]['count']++;
        unset($student);
    }

    $rankers = [];
    foreach ($students as $studentId => $student) {
        // Use the result's historical section, not the student's current section.
        if ($sectionId && $student['section_id'] != $sectionId) {
            continue;
        }
        $total = 0;
        $obtained = 0;
        $obtainedMinor = 0;
        foreach ($student['subjects'] as $subject) {
            $count = $makeOverallAverage ? max(1, $subject['count']) : 1;
            if (strtolower($subject['type']) === 'minor') {
                $obtainedMinor += round($subject['obtained'] / $count, 2);
            }
            if (!$includeMinorSubjectsMarks && strtolower($subject['type']) === 'minor') {
                continue;
            }
            $total += round($subject['total'] / $count, 2);
            $obtained += round($subject['obtained'] / $count, 2);
        }
        // Tie at the percentage precision displayed on the marksheet.
        $percentage = $total > 0 ? $obtained / $total * 100 : 0;
        $rankers[] = array_merge($student['details'], [
            'percentage' => round($percentage, 2),
            'total_marks' => round($total, 2),
            'obtained_marks' => round($obtained, 2),
            'obtained_minor_marks' => round($obtainedMinor, 2),
            'grade' => calculateGrade($percentage)
        ]);
    }
    usort($rankers, function ($a, $b) {
        return ($b['percentage'] <=> $a['percentage'])
            ?: strnatcmp((string)$a['roll_no'], (string)$b['roll_no'])
            ?: strcmp((string)$a['student_id'], (string)$b['student_id']);
    });

    $rank = 0;
    $lastPercentage = null;
    foreach ($rankers as &$student) {
        $percentage = $student['percentage'];
        if ($lastPercentage === null || $percentage != $lastPercentage) {
            $rank++;
            $lastPercentage = $percentage;
        }
        $student['rank'] = $rank;
    }
    unset($student);
    return $rankers;
}

/** Accept the multi-select array, comma-separated IDs, or a legacy single exam ID. */
function getRankingExamIds(mixed $selection): array {
    $values = is_array($selection) ? $selection : explode(',', (string)$selection);
    $ids = [];
    foreach ($values as $value) {
        if (!is_scalar($value) || is_bool($value)) {
            return [];
        }
        $id = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($id === false) {
            return [];
        }
        $ids[] = $id;
    }
    $ids = array_values(array_unique($ids));
    sort($ids);
    return $ids;
}

/** Shared by the ranking page API and export, so both use identical rules. */
function getTopRankersForSelectedExams(PDO $pdo, array $examIds, mixed $classId, array $settings, $sectionId = null): array {
    $examIds = getRankingExamIds($examIds);
    if (!$examIds || !$classId) {
        return [];
    }
    $includeMinor = (bool)($settings['include_minor_subjects_marks'] ?? false);
    if (count($examIds) === 1) {
        // Do not cap historical results at the number of students currently in the class.
        return getTopRankersForSingleMarksheet($pdo, $classId, $examIds[0], $includeMinor, $sectionId, PHP_INT_MAX);
    }
    // Combined design 2 counts only major subjects in its displayed totals.
    if (($settings['combined_marksheet_design'] ?? '') === 'design-2') {
        $includeMinor = false;
    }
    return getTopRankersForCombinedMarksheet(
        $pdo, $examIds, $classId, $includeMinor,
        (bool)($settings['make_overall_average'] ?? false), $sectionId
    );
}

// Get Ordinal function
function getOrdinal(mixed $number) {
    $suffix = ['th', 'st', 'nd', 'rd'];
    $mod100 = $number % 100;
    return $number . ($suffix[($mod100 - 20) % 10] ?? $suffix[$mod100] ?? $suffix[0]);
}

// Get Pass/Fail status based on grade
function getPassFailStatus(string$grade) {
    if ($grade == 'D' || $grade == 'F') {
        return '<b style="color:#FF0000;">FAIL</b>';
    } else {
        return '<b style="color:#008000;">PASS</b>';
    }
}

// Calculate overall grade based on percentage
function calculateGrade(float $percentage)
{
    // Implement your grade calculation logic
    if ($percentage >= 90) return 'AA';
    if ($percentage >= 80) return 'A+';
    if ($percentage >= 70) return 'A';
    if ($percentage >= 60) return 'B+';
    if ($percentage >= 50) return 'B';
    if ($percentage >= 40) return 'C+';
    if ($percentage >= 35) return 'C';
    return 'D';
}

// Get remarks based on grade
function getRemarksByGrade(string $grade) {
    $remarks = [
        'AA' => 'Outstanding',
        'A+' => 'Excellent',
        'A' => 'Very Good',
        'B+' => 'Good',
        'B' => 'Satisfactory',
        'C+' => 'Acceptable',
        'C' => 'Basic',
        'D' => 'Disqualified'
    ];
    return $remarks[$grade] ?? '-';
}

// Get class name by ID
function getClassNameById(PDO $pdo, mixed $classId) {
    $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
    $stmt->execute([$classId]);
    return $stmt->fetchColumn() ?: 'Unknown Class';
}

// Get section name by ID
function getSectionNameById(PDO $pdo, mixed $sectionId) {
    $stmt = $pdo->prepare("SELECT section_name FROM sections WHERE id = ?");
    $stmt->execute([$sectionId]);
    return $stmt->fetchColumn() ?: 'Not Assigned';
}


/**
 * Generate unique student ID
 */
function generateUniqueStudentId(PDO $pdo, mixed $prefix)
{
    do {
        $student_id = $prefix . str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT);
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE student_id = ?");
        $stmt->execute([$student_id]);
    } while ($stmt->fetchColumn() > 0);

    return $student_id;
}

// Generate academic year
function generateAcademicYear() {
    $currentYear = date('Y');
    $data = array($currentYear, $currentYear + 1);
    return json_encode($data);
}


// Get top rankers for single marksheet
function getTopRankersForSingleMarksheet(PDO $pdo, mixed $classId, mixed $examId, bool $include_minor_subjects_marks = false, $section_id = null, $total_students = 5) {
    
    // ১. Typecasting for Security against SQL Injection
    $total_students = (int) $total_students;
    if ($total_students <= 0) {
        $total_students = 5;
    }

    // 2. Dynamic Column Selection
    $colPercentage = $include_minor_subjects_marks ? 'r.percentage' : 'r.percentage_without_minor';
    $colGrade      = $include_minor_subjects_marks ? 'r.grade' : 'r.grade_without_minor';

    // 3. Start Building SQL
    $sql = "SELECT s.name, s.roll_no, s.status as student_status, r.student_id, 
                   $colPercentage as percentage, $colGrade as grade, 
                   r.obtained_marks, r.obtained_minor_marks, c.class_name, sec.section_name 
            FROM results r 
            JOIN students s ON r.student_id = s.student_id 
            JOIN classes c ON r.class_id = c.id
            LEFT JOIN sections sec ON r.section_id = sec.id
            WHERE r.class_id = ? AND r.exam_id = ?";
            
    // 4. Dynamic Parameters Array
    $params = [$classId, $examId];

    if ($section_id) {
        $sql .= " AND r.section_id = ?";
        $params[] = $section_id;
    }

    // 5. Order and Limit (Safely appended integer)
    $sql .= " ORDER BY percentage DESC, s.roll_no ASC LIMIT " . $total_students;

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rankers_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $rankers = [];
    $rank = 0; 
    $prev_percentage = null;

    foreach ($rankers_data as $row) {
        
        // DENSE RANKING LOGIC
        if ($prev_percentage === null || (float)$row['percentage'] !== (float)$prev_percentage) {
            $rank++; 
        }

        // Cleaned up null/empty checks
        $roll_no = empty($row['roll_no']) ? '-' : $row['roll_no'];
        $section_name = empty($row['section_name']) ? '-' : $row['section_name'];
        
        // Default values using Null Coalescing Operator
        $obtained_minor = (float)($row['obtained_minor_marks'] ?? 0);
        $obtained_marks = (float)($row['obtained_marks'] ?? 0);

        // Logic for minus minor marks
        if (!$include_minor_subjects_marks && $obtained_marks > 0) {
             $obtained_marks -= $obtained_minor;
        }

        $rankers[] = [
            'name'                       => $row['name'],
            'student_status'             => $row['student_status'],
            'percentage'                 => $row['percentage'],
            'grade'                      => $row['grade'],
            'rank'                       => $rank,
            'roll_no'                    => $roll_no,
            'student_id'                 => $row['student_id'],
            'obtained_marks'             => $obtained_marks,
            'obtained_minor_marks'       => $obtained_minor,
            'class_name'                 => $row['class_name'],
            'section_name'               => $section_name
        ];

        $prev_percentage = $row['percentage'];
    }

    return $rankers;
}
