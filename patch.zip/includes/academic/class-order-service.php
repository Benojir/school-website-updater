<?php
// No application bootstrap: usable with offline fixtures as well as the admin API.
class ClassOrderConflict extends RuntimeException {}

function classOrderIds(mixed $input): array
{
    if (!is_array($input) || !array_is_list($input) || !$input) {
        throw new InvalidArgumentException('Send the complete class order.');
    }
    $ids=[];
    foreach ($input as $value) {
        if ((!is_int($value) && !is_string($value))
            || ($id=filter_var($value,FILTER_VALIDATE_INT,['options'=>['min_range'=>1,'max_range'=>2147483647]])) === false) {
            throw new InvalidArgumentException('Invalid class ID.');
        }
        $ids[]=$id;
    }
    if (count(array_unique($ids)) !== count($ids)) throw new InvalidArgumentException('A class cannot appear more than once.');
    return $ids;
}

function saveClassOrder(PDO $pdo, mixed $input): void
{
    $ids=classOrderIds($input);
    $pdo->beginTransaction();
    try {
        $existing=array_map('intval',$pdo->query('SELECT id FROM classes ORDER BY id FOR UPDATE')->fetchAll(PDO::FETCH_COLUMN));
        $requested=$ids; sort($requested,SORT_NUMERIC);
        if ($requested !== $existing) throw new ClassOrderConflict('The class list changed. Reload the page and arrange the classes again.');
        $stmt=$pdo->prepare('UPDATE classes SET sort_order = ? WHERE id = ?');
        foreach ($ids as $index=>$id) $stmt->execute([$index+1,$id]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}
