<?php
// Pure persistence helper: the caller owns the pending-enquiry row lock and transaction.
// Including this file never loads configuration or opens a database connection.
function admissionEnquiryRecordDecision(PDO $pdo, array $enquiry, string $status, ?string $studentID = null): void
{
    if (!$pdo->inTransaction()) {
        throw new LogicException('Application decisions must be recorded within the enquiry transaction.');
    }
    $id = $enquiry['id'] ?? null;
    if ((!is_int($id) && !is_string($id)) || !preg_match('/^[1-9][0-9]{0,9}$/D', (string)$id) || (int)$id > 2147483647) {
        throw new InvalidArgumentException('Invalid application reference.');
    }
    if (!in_array($status, ['approved', 'rejected'], true)) {
        throw new InvalidArgumentException('Invalid application decision.');
    }
    if ($studentID !== null) $studentID = trim($studentID);
    if ($status === 'approved' && ($studentID === null || $studentID === '' || mb_strlen($studentID) > 50)) {
        throw new InvalidArgumentException('An approved application requires a valid student ID.');
    }
    if ($status === 'rejected' && $studentID !== null) {
        throw new InvalidArgumentException('A rejected application cannot have a student ID.');
    }

    // A plain INSERT prevents another decision from overwriting a finalized application.
    // JSON failures must abort the caller's transaction before the pending row is deleted.
    $snapshot = json_encode($enquiry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    $stmt = $pdo->prepare('INSERT INTO student_application_history (enquiry_id, status, student_id, application_data, processed_at) VALUES (?, ?, ?, ?, ?)');
    $stmt->execute([(int)$id, $status, $studentID, $snapshot, date('Y-m-d H:i:s')]);
}
