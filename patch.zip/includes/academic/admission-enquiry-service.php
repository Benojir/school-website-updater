<?php
// Pure validation/file helpers: including this file does not connect to a database.
require_once __DIR__ . '/student-academic-service.php';

function admissionEnquiryYears(?int $calendarYear = null): array
{
    $year = $calendarYear ?? (int)date('Y');
    return [(string)$year, (string)($year + 1)];
}

function admissionEnquiryValidate(array $input, ?int $calendarYear = null): array
{
    $limits = [
        'name' => 100, 'gender' => 10, 'date_of_birth' => 10, 'class_id' => 10,
        'academic_year' => 4, 'father_name' => 100, 'phone_number' => 15,
        'mother_name' => 100, 'father_occupation' => 100, 'mother_occupation' => 100,
        'alternate_phone_number' => 15, 'email' => 100, 'blood_group' => 5,
        'preferred_by' => 100, 'religion' => 30, 'student_adhaar' => 20,
        'father_adhaar' => 20, 'mother_adhaar' => 20, 'village' => 50,
        'post_office' => 50, 'police_station' => 50, 'district' => 50, 'pin_code' => 10,
    ];
    $data = [];
    foreach ($limits as $field => $limit) {
        $value = $input[$field] ?? '';
        if (!is_string($value)) throw new InvalidArgumentException('Invalid ' . str_replace('_', ' ', $field) . '.');
        $value = trim($value);
        if (mb_strlen($value) > $limit) throw new InvalidArgumentException(str_replace('_', ' ', $field) . ' is too long.');
        $data[$field] = $value === '' ? null : $value;
    }
    foreach (['name', 'gender', 'date_of_birth', 'class_id', 'academic_year', 'father_name', 'phone_number'] as $field) {
        if ($data[$field] === null) throw new InvalidArgumentException('Please fill in ' . str_replace('_', ' ', $field) . '.');
    }
    $data['academic_year'] = academicNormalizeYear($data['academic_year']);
    if (!in_array($data['academic_year'], admissionEnquiryYears($calendarYear), true)) {
        throw new InvalidArgumentException('Please select the current or next academic year.');
    }
    if (!ctype_digit($data['class_id']) || (int)$data['class_id'] < 1) throw new InvalidArgumentException('Please select a valid class.');
    $data['class_id'] = (int)$data['class_id'];
    $data['gender'] = ucfirst(strtolower($data['gender']));
    if (!in_array($data['gender'], ['Male', 'Female', 'Other'], true)) throw new InvalidArgumentException('Please select a valid gender.');
    $data['date_of_birth'] = academicDate($data['date_of_birth']);
    if ($data['date_of_birth'] === null || $data['date_of_birth'] > date('Y-m-d')) throw new InvalidArgumentException('Please enter a valid date of birth that is not in the future.');
    foreach (['phone_number', 'alternate_phone_number'] as $field) {
        if ($data[$field] !== null && !preg_match('/^[0-9]{10}$/D', $data[$field])) {
            throw new InvalidArgumentException(str_replace('_', ' ', $field) . ' must contain 10 digits.');
        }
    }
    if ($data['phone_number'] === $data['alternate_phone_number']) throw new InvalidArgumentException('Primary and alternate phone numbers must be different.');
    if ($data['email'] !== null) {
        $data['email'] = strtolower($data['email']);
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) throw new InvalidArgumentException('Please enter a valid email address or leave it blank.');
    }
    if ($data['blood_group'] !== null) {
        $data['blood_group'] = strtoupper($data['blood_group']);
        if (!in_array($data['blood_group'], ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'], true)) throw new InvalidArgumentException('Invalid blood group.');
    }
    $address = [];
    foreach (['village' => 'Vill', 'post_office' => 'P.O', 'police_station' => 'P.S', 'district' => 'Dist', 'pin_code' => 'Pin'] as $field => $label) {
        if ($data[$field] !== null) $address[] = $label . '- ' . $data[$field];
    }
    $data['address'] = $address ? implode(', ', $address) : null;
    return $data;
}

function admissionEnquiryApprovalYear(array $enquiry, mixed $requestedYear): string
{
    $stored = academicNormalizeYear($enquiry['academic_year'] ?? null, true);
    $requested = academicNormalizeYear($requestedYear, true);
    if ($stored !== null && $requested !== null && $stored !== $requested) {
        throw new InvalidArgumentException('This application is for academic year ' . $stored . '. Please approve it for that year.');
    }
    $year = $stored ?? $requested;
    if ($year === null) throw new InvalidArgumentException('Select an academic year for this older application.');
    return $year;
}

function admissionEnquiryPhotoDirectory(): string
{
    return dirname(__DIR__, 2) . '/uploads/students';
}

// Always decode and re-encode public uploads; never keep a supplied filename or embedded payload.
function admissionEnquiryPhotoJpeg(string $path): string
{
    if (!is_file($path) || filesize($path) > 5 * 1024 * 1024) throw new InvalidArgumentException('Student photo must be at most 5 MB.');
    return admissionEnquiryPhotoBytesJpeg(file_get_contents($path));
}

function admissionEnquiryCroppedPhotoJpeg(mixed $crop): string
{
    if (!is_string($crop) || strlen($crop) > 7 * 1024 * 1024 || !str_starts_with($crop, 'data:image/jpeg;base64,')) {
        throw new InvalidArgumentException('Invalid cropped student photo. Please crop the photo again.');
    }
    $bytes = base64_decode(substr($crop, strlen('data:image/jpeg;base64,')), true);
    if ($bytes === false) throw new InvalidArgumentException('Invalid cropped student photo data.');
    return admissionEnquiryPhotoBytesJpeg($bytes, true);
}

function admissionEnquiryPhotoBytesJpeg(string $bytes, bool $isSavedCrop = false): string
{
    if (strlen($bytes) > 5 * 1024 * 1024) throw new InvalidArgumentException('Student photo must be at most 5 MB.');
    $info = @getimagesizefromstring($bytes);
    $mime = (new finfo(FILEINFO_MIME_TYPE))->buffer($bytes);
    if (!$info || !in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true) || $info['mime'] !== $mime) {
        throw new InvalidArgumentException('Upload a valid JPG, PNG or WebP student photo.');
    }
    if ($info[0] < 1 || $info[1] < 1 || $info[0] * $info[1] > 12000000) throw new InvalidArgumentException('Student photo must be at most 12 megapixels.');
    if ($isSavedCrop && ($mime !== 'image/jpeg' || $info[0] !== 500 || $info[1] !== 600)) {
        throw new InvalidArgumentException('Please crop the student photo to 500 by 600 pixels.');
    }
    if (!function_exists('imagecreatefromstring')) throw new RuntimeException('Photo uploads are unavailable. Please contact the school.');
    $source = @imagecreatefromstring($bytes);
    if (!$source) throw new InvalidArgumentException('The student photo could not be read.');
    // Match add-student's passport format. Legacy raw-file submissions use a centered crop.
    $sourceWidth = min($info[0], (int)round($info[1] * 5 / 6));
    $sourceHeight = min($info[1], (int)round($info[0] * 6 / 5));
    $sourceX = (int)floor(($info[0] - $sourceWidth) / 2);
    $sourceY = (int)floor(($info[1] - $sourceHeight) / 2);
    $output = imagecreatetruecolor(500, 600);
    imagefill($output, 0, 0, imagecolorallocate($output, 255, 255, 255));
    imagecopyresampled($output, $source, 0, 0, $sourceX, $sourceY, 500, 600, $sourceWidth, $sourceHeight);
    ob_start();
    try {
        if (!imagejpeg($output, null, 85)) throw new RuntimeException('Could not process student photo.');
        return ob_get_contents();
    } finally {
        ob_end_clean();
        imagedestroy($source);
        imagedestroy($output);
    }
}

function admissionEnquirySavePhoto(?array $upload, mixed $croppedData = ''): ?string
{
    // The admin admission page sends cropped_image_data too; prefer the saved crop.
    if ($croppedData !== '' && $croppedData !== null) {
        $jpeg = admissionEnquiryCroppedPhotoJpeg($croppedData);
    } else {
        if ($upload === null) return null;
        $error = $upload['error'] ?? null;
        if ($error === UPLOAD_ERR_NO_FILE) return null;
        if ($error !== UPLOAD_ERR_OK || !is_string($upload['tmp_name'] ?? null) || !is_uploaded_file($upload['tmp_name'])) {
            throw new InvalidArgumentException('Student photo upload failed. Choose a JPG, PNG or WebP file of at most 5 MB.');
        }
        $jpeg = admissionEnquiryPhotoJpeg($upload['tmp_name']);
    }
    $directory = admissionEnquiryPhotoDirectory();
    if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) throw new RuntimeException('Could not save student photo.');
    $filename = 'enquiry_' . bin2hex(random_bytes(16)) . '.jpg';
    if (file_put_contents($directory . '/' . $filename, $jpeg, LOCK_EX) !== strlen($jpeg)) {
        admissionEnquiryRemovePhoto($filename);
        throw new RuntimeException('Could not save student photo.');
    }
    return $filename;
}

function admissionEnquiryRemovePhoto(?string $filename): void
{
    if ($filename === null || !preg_match('/^enquiry_[a-f0-9]{32}\.jpg$/D', $filename)) return;
    $path = admissionEnquiryPhotoDirectory() . '/' . $filename;
    if (is_file($path) && !@unlink($path)) error_log('Could not remove unused enquiry photo: ' . $filename);
}
