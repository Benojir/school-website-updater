<?php
require_once __DIR__ . '/admission-enquiry-service.php';

class AdmissionEnquiryEditConflict extends RuntimeException {}

function admissionEnquiryVersion(array $enquiry): string
{
    // PDO can return numeric columns as either integers or strings.
    $values = array_map(static fn($value) => $value === null ? null : (string)$value, $enquiry);
    ksort($values);
    return hash('sha256', json_encode($values, JSON_THROW_ON_ERROR));
}

function admissionEnquiryEditData(array $input): array
{
    $data = admissionEnquiryValidate($input, null, true);
    // Older applications may only have a free-text address. Do not rebuild/erase it on unrelated edits.
    if (array_key_exists('address', $input)) {
        if (!is_string($input['address']) || strlen($input['address']) > 65535) {
            throw new InvalidArgumentException('Please enter a valid address.');
        }
        $address = trim($input['address']);
        $data['address'] = $address === '' ? null : $address;
    }
    foreach (['student', 'father', 'mother'] as $person) {
        $data[$person . '_adhaar_no'] = $data[$person . '_adhaar'];
        unset($data[$person . '_adhaar']);
    }
    return $data;
}

function admissionEnquiryEditCleanup(?string $photo, callable $removePhoto): void
{
    if ($photo === null) return;
    try {
        $removePhoto($photo);
    } catch (Throwable $e) {
        // A storage cleanup failure must not turn a committed edit into a reported save failure.
        error_log('Admission enquiry photo cleanup failed: ' . $e->getMessage());
    }
}

function admissionEnquiryUpdate(
    PDO $pdo, array $input, ?array $upload = null,
    ?callable $savePhoto = null, ?callable $removePhoto = null
): array {
    $id = $input['enquiry_id'] ?? null;
    if (!is_string($id) || !ctype_digit($id) || (int)$id < 1) {
        throw new InvalidArgumentException('Please select a valid application.');
    }
    $version = $input['original_version'] ?? null;
    if (!is_string($version) || !preg_match('/^[a-f0-9]{64}$/D', $version)) {
        throw new InvalidArgumentException('Please reload this application before saving.');
    }
    $remove = $input['remove_photo'] ?? '0';
    if (!is_string($remove) || !in_array($remove, ['0', '1'], true)) {
        throw new InvalidArgumentException('Invalid photo selection.');
    }
    $crop = $input['cropped_image_data'] ?? '';
    if (!is_string($crop)) throw new InvalidArgumentException('Invalid cropped student photo.');
    $hasUpload = $upload !== null && ($upload['error'] ?? null) !== UPLOAD_ERR_NO_FILE;
    if ($remove === '1' && ($crop !== '' || $hasUpload)) {
        throw new InvalidArgumentException('Choose either a replacement photo or remove the existing photo.');
    }
    $data = admissionEnquiryEditData($input);
    $savePhoto ??= 'admissionEnquirySavePhoto';
    $removePhoto ??= 'admissionEnquiryRemovePhoto';
    $newPhoto = null;
    $oldPhoto = null;
    try {
        // Store outside the row transaction: cloud photo storage can have its own transaction.
        $newPhoto = $savePhoto($upload, $crop);
        $pdo->beginTransaction();
        // Approve/reject/delete lock this same row. Only existing rows are pending applications.
        $stmt = $pdo->prepare('SELECT * FROM admission_enquiries WHERE id = ? FOR UPDATE');
        $stmt->execute([(int)$id]);
        $enquiry = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$enquiry) throw new AdmissionEnquiryEditConflict('This application has already been processed or deleted. Return to the application list.');
        if (!hash_equals(admissionEnquiryVersion($enquiry), $version)) {
            throw new AdmissionEnquiryEditConflict('This application was changed by another administrator. Reload it and review the latest information before saving.');
        }
        $class = $pdo->prepare('SELECT id FROM classes WHERE id = ?');
        $class->execute([$data['class_id']]);
        if (!$class->fetchColumn()) throw new InvalidArgumentException('Please select an existing class.');
        $duplicate = $pdo->prepare('SELECT COUNT(*) FROM admission_enquiries WHERE name = :name AND class_id = :class_id AND father_name = :father_name AND academic_year = :academic_year AND id != :id');
        $duplicate->execute(['name' => $data['name'], 'class_id' => $data['class_id'], 'father_name' => $data['father_name'], 'academic_year' => $data['academic_year'], 'id' => (int)$id]);
        if ($duplicate->fetchColumn() > 0) throw new InvalidArgumentException('Another application already exists for this student, class and academic year.');
        $phone = $pdo->prepare('SELECT COUNT(*) FROM students WHERE phone_number = :phone_number AND father_name != :father_name');
        $phone->execute(['phone_number' => $data['phone_number'], 'father_name' => $data['father_name']]);
        if ($phone->fetchColumn() > 0) throw new InvalidArgumentException('This phone number is already used by another father. Please provide a different phone number.');
        $oldPhoto = $enquiry['student_image'] ?? null;
        $data['student_image'] = $remove === '1' ? null : ($newPhoto ?? $oldPhoto);
        // All column names come from the fixed validated field list. ID/date/status are never editable.
        $assignments = array_map(static fn($column) => '`' . $column . '` = :' . $column, array_keys($data));
        $stmt = $pdo->prepare('UPDATE admission_enquiries SET ' . implode(', ', $assignments) . ' WHERE id = :id');
        $stmt->execute($data + ['id' => (int)$id]);
        // Re-read canonical DB values before committing (e.g. NULL versus empty strings).
        $stmt = $pdo->prepare('SELECT * FROM admission_enquiries WHERE id = ?');
        $stmt->execute([(int)$id]);
        $updated = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$updated) throw new RuntimeException('Could not read the saved application.');
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        admissionEnquiryEditCleanup($newPhoto, $removePhoto);
        throw $e;
    }
    if ($oldPhoto !== ($updated['student_image'] ?? null)) admissionEnquiryEditCleanup($oldPhoto, $removePhoto);
    return $updated;
}
