<?php
// Public applicant ownership and editing rules. This file never opens a database connection.
require_once __DIR__ . '/admission-enquiry-edit-service.php';

const STUDENT_APPLICATION_ACCESS_KEY = 'student_application_access';
const STUDENT_APPLICATION_ACCESS_TTL = 1800;
const STUDENT_APPLICATION_LOOKUP_MAX_ATTEMPTS = 5;
const STUDENT_APPLICATION_LOOKUP_WINDOW = 900;

class StudentApplicationAccessException extends RuntimeException {}

function studentApplicationSession(): void
{
    if (session_status() === PHP_SESSION_NONE) session_start();
}

function formatStudentApplicationRef(int $applicationId): string
{
    return 'SA' . str_pad((string)$applicationId, 6, '0', STR_PAD_LEFT);
}

function parseStudentApplicationRef(mixed $reference): ?int
{
    if (!is_string($reference) || !preg_match('/^(?:SA\s*)?([0-9]{1,18})$/iD', trim($reference), $match)) return null;
    $id = (int)$match[1];
    return $id > 0 ? $id : null;
}

function grantStudentApplicationAccess(int $applicationId): void
{
    if ($applicationId < 1) throw new InvalidArgumentException('Invalid application.');
    studentApplicationSession();
    session_regenerate_id(true);
    $_SESSION[STUDENT_APPLICATION_ACCESS_KEY] = ['application_id' => $applicationId, 'last_active_at' => time()];
}

function revokeStudentApplicationAccess(): void
{
    studentApplicationSession();
    unset($_SESSION[STUDENT_APPLICATION_ACCESS_KEY]);
}

function verifiedStudentApplicationId(): ?int
{
    studentApplicationSession();
    $access = $_SESSION[STUDENT_APPLICATION_ACCESS_KEY] ?? null;
    $lastActive = is_array($access) ? (int)($access['last_active_at'] ?? 0) : 0;
    $id = is_array($access) ? (int)($access['application_id'] ?? 0) : 0;
    if ($id < 1 || $lastActive <= 0 || $lastActive > time() + 60 || time() - $lastActive >= STUDENT_APPLICATION_ACCESS_TTL) {
        revokeStudentApplicationAccess();
        return null;
    }
    $_SESSION[STUDENT_APPLICATION_ACCESS_KEY]['last_active_at'] = time();
    return $id;
}

function studentApplicationRequireCsrf(array $input): void
{
    studentApplicationSession();
    $expected = $_SESSION['student_application_csrf'] ?? null;
    $provided = $input['csrf'] ?? null;
    if (!is_string($expected) || $expected === '' || !is_string($provided) || !hash_equals($expected, $provided)) {
        throw new StudentApplicationAccessException('Your session has expired. Reload this page and try again.', 403);
    }
}

/** Pending records stay in admission_enquiries; decisions are immutable snapshots. */
function fetchStudentApplicationById(PDO $pdo, int $applicationId): ?array
{
    $stmt = $pdo->prepare('SELECT * FROM admission_enquiries WHERE id = ? LIMIT 1');
    $stmt->execute([$applicationId]);
    $application = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($application) {
        $version = admissionEnquiryVersion($application);
        return array_replace($application, ['status' => 'pending', 'student_id' => null,
            'processed_at' => null, 'original_version' => $version]);
    }
    $stmt = $pdo->prepare('SELECT * FROM student_application_history WHERE enquiry_id = ? LIMIT 1');
    $stmt->execute([$applicationId]);
    $history = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$history || !in_array($history['status'] ?? null, ['approved', 'rejected'], true)) return null;
    $snapshot = json_decode($history['application_data'] ?? '', true);
    if (!is_array($snapshot) || (int)($snapshot['id'] ?? 0) !== $applicationId) return null;
    $application = array_replace($snapshot, ['status' => $history['status'], 'student_id' => $history['student_id'] ?? null,
        'processed_at' => $history['processed_at'] ?? null, 'original_version' => null]);
    // Rejection removes the pending student's photo; the retained snapshot is read-only history.
    if ($history['status'] === 'rejected') $application['student_image'] = null;
    return $application;
}

function fetchVerifiedStudentApplication(PDO $pdo): ?array
{
    $id = verifiedStudentApplicationId();
    if ($id === null) return null;
    $application = fetchStudentApplicationById($pdo, $id);
    if ($application === null) revokeStudentApplicationAccess();
    return $application;
}

function isStudentApplicationEditable(array $application, array $settings): bool
{
    return !empty($settings['allow_edit_student_application']) && ($application['status'] ?? null) === 'pending'
        && empty($application['student_id']);
}

function studentApplicationStatusMeta(?string $status): array
{
    return match ($status) {
        'pending' => ['label' => 'Under Review', 'badge' => 'warning', 'icon' => 'fa-hourglass-half',
            'description' => 'Your admission application has been received and is waiting for a decision from the school.'],
        'approved' => ['label' => 'Approved', 'badge' => 'success', 'icon' => 'fa-circle-check',
            'description' => 'Your admission application has been approved. Please contact the school office to complete the admission process.'],
        'rejected' => ['label' => 'Not Selected', 'badge' => 'danger', 'icon' => 'fa-circle-xmark',
            'description' => 'The school was unable to offer admission from this application. Please contact the school office for details.'],
        default => ['label' => 'Unavailable', 'badge' => 'secondary', 'icon' => 'fa-circle-question',
            'description' => 'The current application status is unavailable. Please contact the school office.'],
    };
}

function studentApplicationLookupAllowed(?int $now = null): void
{
    studentApplicationSession();
    $now ??= time();
    $attempts = $_SESSION['student_application_lookup'] ?? [];
    $started = (int)($attempts['started'] ?? 0);
    if ($started <= 0 || $now - $started >= STUDENT_APPLICATION_LOOKUP_WINDOW) {
        $_SESSION['student_application_lookup'] = ['started' => $now, 'count' => 0];
        return;
    }
    if ((int)($attempts['count'] ?? 0) >= STUDENT_APPLICATION_LOOKUP_MAX_ATTEMPTS) {
        $minutes = max(1, (int)ceil((STUDENT_APPLICATION_LOOKUP_WINDOW - ($now - $started)) / 60));
        throw new StudentApplicationAccessException('Too many failed attempts. Please try again after ' . $minutes . ' minute(s).', 429);
    }
}

function studentApplicationRecordLookupAttempt(): void
{
    $_SESSION['student_application_lookup']['count'] = (int)($_SESSION['student_application_lookup']['count'] ?? 0) + 1;
}

function studentApplicationVerifyCaptcha(array $input, array $websiteConfig, string $verifyUrl): void
{
    $token = $input['cf-turnstile-response'] ?? null;
    if (!is_string($token) || trim($token) === '' || strlen($token) > 2048) {
        throw new InvalidArgumentException('Please complete the captcha verification.');
    }
    $secret = $websiteConfig['captcha_secret_key'] ?? null;
    if (!is_string($secret) || $secret === '') throw new StudentApplicationAccessException('Application lookup is temporarily unavailable. Please contact the school.', 503);
    $context = stream_context_create(['http' => [
        'header' => "Content-type: application/x-www-form-urlencoded\r\n", 'method' => 'POST',
        'timeout' => 10, 'ignore_errors' => true, 'content' => http_build_query([
            'secret' => $secret, 'response' => $token, 'remoteip' => $_SERVER['REMOTE_ADDR'] ?? '',
        ]),
    ]]);
    $result = @file_get_contents($verifyUrl, false, $context);
    $captcha = $result === false ? null : json_decode($result, true);
    if (!is_array($captcha) || ($captcha['success'] ?? false) !== true) {
        throw new InvalidArgumentException('Captcha verification failed. Please try again.');
    }
}

/** No credential-specific error is exposed, including when the reference does not exist. */
function studentApplicationCredentials(array $input): array
{
    $id = parseStudentApplicationRef($input['application_ref'] ?? null);
    $phone = $input['phone_number'] ?? null;
    $dob = $input['date_of_birth'] ?? null;
    if ($id === null || !is_string($phone) || !preg_match('/^[0-9]{10}$/D', trim($phone))
        || !is_string($dob) || academicDate($dob) === null || $dob > date('Y-m-d')) {
        throw new InvalidArgumentException('Please enter a valid Application ID, registered phone number and date of birth.');
    }
    return ['id' => $id, 'phone_number' => trim($phone), 'date_of_birth' => $dob];
}

function studentApplicationCredentialsMatch(?array $application, array $credentials): bool
{
    return $application !== null && (int)($application['id'] ?? 0) === $credentials['id']
        && hash_equals((string)($application['phone_number'] ?? ''), $credentials['phone_number'])
        && hash_equals((string)($application['date_of_birth'] ?? ''), $credentials['date_of_birth']);
}

/** The verified session, never a posted enquiry_id, chooses the record to edit. */
function studentApplicationSaveVerified(PDO $pdo, array $input, ?array $upload, array $settings,
    ?callable $savePhoto = null, ?callable $removePhoto = null): array
{
    $application = fetchVerifiedStudentApplication($pdo);
    if ($application === null) throw new StudentApplicationAccessException('Your session has expired. Please look up your application again.', 401);
    if (empty($settings['allow_edit_student_application'])) {
        throw new StudentApplicationAccessException('Editing student applications is not allowed at the moment.', 403);
    }
    if (!isStudentApplicationEditable($application, $settings)) {
        throw new AdmissionEnquiryEditConflict('This application has already been processed by the school and can no longer be edited.');
    }
    $year = academicNormalizeYear($input['academic_year'] ?? null);
    if ($year !== (string)$application['academic_year'] && !in_array($year, admissionEnquiryYears(), true)) {
        throw new InvalidArgumentException('Keep the original academic year or select the current or next academic year.');
    }
    $input['enquiry_id'] = (string)$application['id'];
    // The shared service locks the pending row and checks its version. Approval/rejection
    // archives and removes the same locked row, so a school decision always wins a race.
    return admissionEnquiryUpdate($pdo, $input, $upload, $savePhoto, $removePhoto);
}
