<?php
// No bootstrap or database connection. A dedicated correction keeps ordinary yearly edits immutable.
require_once __DIR__ . '/student-academic-service.php';

class AdmissionYearCorrectionConflict extends RuntimeException {}

function admissionYearCorrectionRows(PDO $pdo, string $sql, array $params): array
{
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (count($rows) > 5000) throw new AdmissionYearCorrectionConflict('Too many linked records for an automatic correction. Please arrange a reviewed data correction.');
    return $rows;
}

function admissionYearCorrectionBackup(mixed $json): array
{
    if ($json === null || $json === '') return [];
    try { $rows = json_decode($json, true, 64, JSON_THROW_ON_ERROR); }
    catch (Throwable $e) { throw new AdmissionYearCorrectionConflict('A payment backup is unreadable. Review the payment history before correcting the year.'); }
    if (!is_array($rows) || !array_is_list($rows)) throw new AdmissionYearCorrectionConflict('A payment backup is invalid. Review the payment history before correcting the year.');
    return $rows;
}

function admissionYearCorrectionInput(array $input): array
{
    $row = academicPositiveId($input['student_row_id'] ?? null, 'Student');
    $record = academicPositiveId($input['record_id'] ?? null, 'Academic record');
    if (!$row || !$record) throw new InvalidArgumentException('Select a student and an existing academic record.');
    $from = academicNormalizeYear($input['source_year'] ?? null);
    $to = academicNormalizeYear($input['target_year'] ?? null);
    if ($from === $to) throw new InvalidArgumentException('Choose a different corrected academic year.');
    return ['student_row_id' => $row, 'record_id' => $record, 'source_year' => $from, 'target_year' => $to];
}

/** Settings and student locks serialize this operation with enrollment edits, payments and reversals. */
function admissionYearCorrectionState(PDO $pdo, int $rowId): array
{
    academicLockSettings($pdo);
    $students = admissionYearCorrectionRows($pdo, 'SELECT * FROM students WHERE id = ? FOR UPDATE', [$rowId]);
    if (!$students) throw new InvalidArgumentException('Student not found.');
    $student = $students[0];
    if (empty($student['student_id'])) throw new AdmissionYearCorrectionConflict('This student needs a valid Student ID before correcting the year.');
    $records = admissionYearCorrectionRows($pdo, 'SELECT * FROM student_academic_records WHERE student_row_id = ? ORDER BY id FOR UPDATE', [$rowId]);
    $tables = [];
    foreach (['admission_unpaid_fees', 'admission_full_paid_fees', 'admission_partial_fees_payments',
        'admission_fees_payment_history', 'student_unpaid_fees', 'student_full_paid_fees',
        'student_partial_payments', 'student_payment_history', 'monthly_fee_bills', 'results',
        'student_attendance', 'additional_fees_data'] as $table) {
        // Every identifier is from this fixed server list, never from request data.
        $tables[$table] = admissionYearCorrectionRows($pdo, "SELECT * FROM $table WHERE student_id = ? ORDER BY id FOR UPDATE", [$student['student_id']]);
    }
    $tables['online_fee_payment_orders'] = admissionYearCorrectionRows($pdo,
        "SELECT * FROM online_fee_payment_orders WHERE student_id = ? AND fee_type = 'admission-fee' ORDER BY id FOR UPDATE", [$student['student_id']]);
    return ['student' => $student, 'records' => $records, 'tables' => $tables, 'school_year' => academicCurrentYear($pdo)];
}

function admissionYearCorrectionPlan(PDO $pdo, array $input, array $state): array
{
    $request = admissionYearCorrectionInput($input);
    ['source_year' => $from, 'target_year' => $to, 'record_id' => $recordId] = $request;
    $record = null;
    foreach ($state['records'] as $item) if ((int)$item['id'] === $recordId) $record = $item;
    if (!$record || (string)$record['academic_year'] !== $from) {
        throw new AdmissionYearCorrectionConflict('This academic record changed. Reload Academic History and review its current year.');
    }
    $blocked = [];
    foreach ($state['records'] as $item) {
        if ((int)$item['id'] !== $recordId && (string)$item['academic_year'] === $to) $blocked[] = 'An enrollment already exists for ' . $to . '. Records cannot be merged automatically.';
    }
    if (!empty($record['promoted_date'])) $blocked[] = 'This record contains a promotion date. Review the promotion history before changing its year.';
    if ($record['class_id'] !== null && $record['roll_no'] !== null) {
        $conflicts = admissionYearCorrectionRows($pdo, 'SELECT id FROM student_academic_records WHERE academic_year = ? AND class_id = ? AND COALESCE(section_id, 0) = ? AND roll_no = ? AND id <> ? LIMIT 1',
            [$to, $record['class_id'], $record['section_id'] ?? 0, $record['roll_no'], $recordId]);
        if ($conflicts) $blocked[] = 'The roll number is already assigned in the target year, class and section.';
    }
    if ($record['registration_no'] !== null && $record['registration_no'] !== '') {
        $conflicts = admissionYearCorrectionRows($pdo, 'SELECT id FROM student_academic_records WHERE academic_year = ? AND registration_no = ? AND id <> ? LIMIT 1', [$to, $record['registration_no'], $recordId]);
        if ($conflicts) $blocked[] = 'The registration number is already assigned in the target year.';
    }
    $sid = $state['student']['student_id'];
    $tables = $state['tables'];
    $moves = [];
    foreach (['admission_unpaid_fees', 'admission_full_paid_fees', 'admission_partial_fees_payments'] as $table) {
        $moves[$table] = [];
        foreach ($tables[$table] as $fee) {
            $year = (string)($fee['academic_year'] ?? '');
            if ($year === $to) $blocked[] = 'Admission fee/payment records already exist for ' . $to . '. Review them before correcting the year.';
            if ($year === '') $blocked[] = 'An admission fee/payment has an unknown academic year. Review it first.';
            if ($year !== $from) continue;
            if ((string)($fee['class_id'] ?? '') !== (string)$record['class_id']) $blocked[] = 'An admission fee/payment class differs from this enrollment. Review it first.';
            $moves[$table][(int)$fee['id']] = array_replace($fee, ['academic_year' => $to]);
        }
    }
    foreach ($moves['admission_partial_fees_payments'] as $payment) {
        $paidId = (int)($payment['full_paid_admission_fees_id'] ?? 0);
        $unpaidId = (int)($payment['unpaid_admission_fees_id'] ?? 0);
        if ($paidId ? !isset($moves['admission_full_paid_fees'][$paidId]) : !$unpaidId || !isset($moves['admission_unpaid_fees'][$unpaidId])) {
            $blocked[] = 'An admission payment is not linked to the matching source-year fee. Review its fee/payment links first.';
        }
    }
    $backups = [];
    foreach ($tables['admission_fees_payment_history'] as $payment) {
        $rows = admissionYearCorrectionBackup($payment['unpaid_admission_fees_rows_backup'] ?? null);
        $changed = false;
        foreach ($rows as &$fee) {
            if (!is_array($fee) || ($fee['student_id'] ?? null) !== $sid || empty($fee['academic_year'])) {
                throw new AdmissionYearCorrectionConflict('An admission payment backup cannot be matched safely to this student. Review it first.');
            }
            if ((string)$fee['academic_year'] === $to) $blocked[] = 'An admission payment backup already references the target year.';
            if ((string)$fee['academic_year'] === $from) {
                if ((string)($fee['class_id'] ?? '') !== (string)$record['class_id']) $blocked[] = 'An admission payment backup has a different class. Review it first.';
                $fee['academic_year'] = $to; $changed = true;
            }
        }
        unset($fee);
        if ($changed) $backups[(int)$payment['id']] = json_encode($rows, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    }
    $orders = [];
    foreach ($tables['online_fee_payment_orders'] as $order) {
        try { $fee = json_decode($order['fee_snapshot'] ?? '', true, 64, JSON_THROW_ON_ERROR); }
        catch (Throwable $e) { throw new AdmissionYearCorrectionConflict('An online admission payment snapshot is invalid. Review Online Payments first.'); }
        if (!is_array($fee) || ($fee['student_id'] ?? null) !== $sid || empty($fee['academic_year'])) throw new AdmissionYearCorrectionConflict('An online admission payment snapshot cannot be matched safely. Review Online Payments first.');
        if ((string)$fee['academic_year'] === $to) $blocked[] = 'An online admission payment already references the target year.';
        if ((string)$fee['academic_year'] !== $from) continue;
        if (!in_array($order['payment_status'], ['paid', 'refunded', 'failed'], true)) $blocked[] = 'An online admission checkout or refund is still pending/requires review. Resolve it before correcting the year.';
        if ((string)($fee['class_id'] ?? '') !== (string)$record['class_id']) $blocked[] = 'An online admission payment has a different class. Review it first.';
        $fee['academic_year'] = $to;
        $orders[(int)$order['id']] = json_encode($fee, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    }
    $periodMatches = static function ($value) use ($from, $to): bool {
        if (!is_string($value) || !preg_match('/^(?:January|February|March|April|May|June|July|August|September|October|November|December) ([0-9]{4})$/iD', $value, $matches)) return true;
        return in_array($matches[1], [$from, $to], true);
    };
    foreach (['student_unpaid_fees', 'student_full_paid_fees', 'student_partial_payments', 'monthly_fee_bills'] as $table) {
        foreach ($tables[$table] as $bill) {
            if (empty($bill['month_year']) || $periodMatches($bill['month_year']) || in_array((string)($bill['academic_year'] ?? ''), [$from, $to], true)) {
                $blocked[] = 'Monthly fee records exist for the source/target year. Their calendar months need a separate review; they cannot be shifted automatically.'; break;
            }
        }
    }
    foreach ($tables['student_payment_history'] as $payment) {
        foreach (admissionYearCorrectionBackup($payment['unpaid_fee_rows_backup'] ?? null) as $fee) {
            if (!is_array($fee) || empty($fee['month_year']) || $periodMatches($fee['month_year'])) { $blocked[] = 'Monthly payment backups reference this year and need separate review.'; break; }
        }
        foreach (admissionYearCorrectionBackup($payment['monthly_bill_snapshots'] ?? null) as $bill) {
            if (!is_array($bill) || empty($bill['month_year']) || $periodMatches($bill['month_year'])) { $blocked[] = 'Monthly bill payment snapshots reference this year and need separate review.'; break; }
        }
    }
    foreach ($tables['results'] as $result) {
        if (empty($result['academic_year']) || in_array((string)$result['academic_year'], [$from, $to], true)) { $blocked[] = 'Exam results exist for this year (or an unknown year). Review the exam/enrollment relationship first.'; break; }
    }
    foreach ($tables['student_attendance'] as $attendance) {
        if (empty($attendance['date']) || in_array(substr($attendance['date'], 0, 4), [$from, $to], true)) { $blocked[] = 'Attendance exists in the source/target year. Its calendar dates need review before changing the enrollment year.'; break; }
    }
    foreach ($tables['additional_fees_data'] as $fee) {
        if (empty($fee['class_id']) || (string)$fee['class_id'] === (string)$record['class_id']) { $blocked[] = 'Additional fee entries have no academic-year link. Review these class-related entries before correcting the year.'; break; }
    }
    $hash = hash('sha256', json_encode([$request, $state], JSON_THROW_ON_ERROR));
    return $request + ['record' => $record, 'moves' => $moves, 'backups' => $backups, 'orders' => $orders,
        'preview_hash' => $hash, 'blockers' => array_values(array_unique($blocked)),
        'counts' => ['unpaid_admission_fees' => count($moves['admission_unpaid_fees']),
            'paid_admission_fees' => count($moves['admission_full_paid_fees']), 'partial_payments' => count($moves['admission_partial_fees_payments']),
            'payment_backups' => count($backups), 'online_snapshots' => count($orders)]];
}

function admissionYearCorrectionPreview(PDO $pdo, array $input): array
{
    $request = admissionYearCorrectionInput($input);
    return academicTransaction($pdo, function () use ($pdo, $request) {
        return admissionYearCorrectionPlan($pdo, $request, admissionYearCorrectionState($pdo, $request['student_row_id']));
    });
}

function admissionYearCorrectionApply(PDO $pdo, array $input, array $actor, bool $mayManageFees): array
{
    $request = admissionYearCorrectionInput($input);
    $reason = $input['reason'] ?? null;
    $hash = $input['preview_hash'] ?? null;
    if (!is_string($reason) || mb_strlen(trim($reason)) < 5 || mb_strlen($reason) > 1000 || !preg_match('//u', $reason)) throw new InvalidArgumentException('Enter a correction reason between 5 and 1000 characters.');
    if (($input['confirm'] ?? null) !== '1' || !is_string($hash) || !preg_match('/^[a-f0-9]{64}$/D', $hash)) throw new InvalidArgumentException('Preview the correction and confirm it before saving.');
    if (empty($actor['user_id']) || empty($actor['user_role'])) throw new InvalidArgumentException('A signed-in administrator is required.');
    return academicTransaction($pdo, function () use ($pdo, $request, $reason, $hash, $actor, $mayManageFees) {
        $before = admissionYearCorrectionState($pdo, $request['student_row_id']);
        $plan = admissionYearCorrectionPlan($pdo, $request, $before);
        if (!hash_equals($plan['preview_hash'], $hash)) throw new AdmissionYearCorrectionConflict('Linked records changed since the preview. Preview the correction again before saving.');
        if ($plan['blockers']) throw new AdmissionYearCorrectionConflict(implode(' ', $plan['blockers']));
        if (array_sum($plan['counts']) && !$mayManageFees) throw new AdmissionYearCorrectionConflict('This correction includes fee/payment records. An administrator with Manage Fees permission must complete it.');
        $run = static function (string $sql, array $params) use ($pdo): void { $stmt = $pdo->prepare($sql); $stmt->execute($params); };
        $run('UPDATE student_academic_records SET academic_year = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [$plan['target_year'], $plan['record_id']]);
        foreach ($plan['moves'] as $table => $rows) foreach ($rows as $id => $row) $run("UPDATE $table SET academic_year = ? WHERE id = ?", [$plan['target_year'], $id]);
        foreach ($plan['backups'] as $id => $json) $run('UPDATE admission_fees_payment_history SET unpaid_admission_fees_rows_backup = ? WHERE id = ?', [$json, $id]);
        foreach ($plan['orders'] as $id => $json) $run('UPDATE online_fee_payment_orders SET fee_snapshot = ? WHERE id = ?', [$json, $id]);
        academicSyncStudent($pdo, $plan['student_row_id']);
        // Store the financial/enrollment state before and after. An audit insert failure rolls everything back.
        $after = admissionYearCorrectionState($pdo, $plan['student_row_id']);
        $auditState = static fn($state) => ['records' => $state['records'],
            'admission_unpaid_fees' => $state['tables']['admission_unpaid_fees'], 'admission_full_paid_fees' => $state['tables']['admission_full_paid_fees'],
            'admission_partial_fees_payments' => $state['tables']['admission_partial_fees_payments'],
            'admission_fees_payment_history' => $state['tables']['admission_fees_payment_history'], 'online_fee_payment_orders' => $state['tables']['online_fee_payment_orders']];
        $run('INSERT INTO student_admission_year_corrections (student_row_id, student_id, academic_record_id, source_year, target_year, reason, actor_id, actor_role, actor_name, before_snapshot, after_snapshot, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [$plan['student_row_id'], $before['student']['student_id'], $plan['record_id'], $plan['source_year'], $plan['target_year'], trim($reason),
                (int)$actor['user_id'], $actor['user_role'], $actor['full_name'] ?? $actor['username'] ?? '',
                json_encode($auditState($before), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), json_encode($auditState($after), JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR), date('Y-m-d H:i:s')]);
        return ['counts' => $plan['counts'], 'source_year' => $plan['source_year'], 'target_year' => $plan['target_year']];
    });
}
