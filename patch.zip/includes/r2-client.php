<?php
/** Small S3 Signature V4 client. No database, sessions or configuration side effects. */
final class SchoolR2Client
{
    public function __construct(private array $config, private $transport = null) {}

    public static function signedRequest(string $endpoint, string $bucket, string $key, string $method, string $body, string $access, string $secret, string $date, array $extra = []): array
    {
        $host = parse_url($endpoint, PHP_URL_HOST);
        $path = '/' . rawurlencode($bucket) . '/' . implode('/', array_map('rawurlencode', explode('/', $key)));
        $headers = $extra + ['host' => $host, 'x-amz-content-sha256' => hash('sha256', $body), 'x-amz-date' => $date];
        ksort($headers);
        $canonicalHeaders = '';
        foreach ($headers as $name => $value) $canonicalHeaders .= $name . ':' . trim($value) . "\n";
        $signed = implode(';', array_keys($headers));
        $canonical = $method . "\n" . $path . "\n\n" . $canonicalHeaders . "\n" . $signed . "\n" . hash('sha256', $body);
        $day = substr($date, 0, 8);
        $scope = $day . '/auto/s3/aws4_request';
        $signing = hash_hmac('sha256', $day, 'AWS4' . $secret, true);
        foreach (['auto', 's3', 'aws4_request'] as $part) $signing = hash_hmac('sha256', $part, $signing, true);
        $signature = hash_hmac('sha256', "AWS4-HMAC-SHA256\n$date\n$scope\n" . hash('sha256', $canonical), $signing);
        $headers['authorization'] = "AWS4-HMAC-SHA256 Credential=$access/$scope, SignedHeaders=$signed, Signature=$signature";
        return ['url' => rtrim($endpoint, '/') . $path, 'method' => $method, 'headers' => $headers, 'body' => $body];
    }

    public function request(string $method, string $key, string $body = '', array $headers = []): array
    {
        $request = self::signedRequest($this->config['endpoint'], $this->config['bucket'], $key, $method, $body,
            $this->config['access'], $this->config['secret'], gmdate('Ymd\THis\Z'), $headers);
        for ($attempt = 0; $attempt < 3; $attempt++) {
            $response = $this->transport ? ($this->transport)($request) : $this->curl($request);
            $status = (int)$response['status'];
            if ($status >= 200 && $status < 300 || $method === 'DELETE' && $status === 404) return $response;
            if (!in_array($status, [0, 408, 429, 500, 502, 503, 504], true) || $attempt === 2) {
                // Never expose authorization, credentials, remote error bodies or cURL URLs.
                throw new RuntimeException('R2 ' . $method . ' failed (HTTP ' . $status . '). Check credentials, bucket, endpoint and server clock.');
            }
            if (!$this->transport) usleep((250000 * (2 ** $attempt)) + random_int(0, 100000));
        }
        throw new RuntimeException('R2 request failed.');
    }

    private function curl(array $request): array
    {
        if (!function_exists('curl_init')) throw new RuntimeException('PHP cURL is required for R2.');
        $headers = [];
        $responseHeaders = [];
        foreach ($request['headers'] as $name => $value) $headers[] = $name . ': ' . $value;
        $headers[] = 'Expect:';
        $ch = curl_init($request['url']);
        curl_setopt_array($ch, [CURLOPT_CUSTOMREQUEST => $request['method'], CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => false, CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => 35, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_PROTOCOLS => CURLPROTO_HTTPS, CURLOPT_HEADERFUNCTION => static function ($ch, $line) use (&$responseHeaders) {
                if (str_contains($line, ':')) { [$k, $v] = explode(':', $line, 2); $responseHeaders[strtolower(trim($k))] = trim($v); }
                return strlen($line);
            }]);
        if ($request['method'] === 'HEAD') curl_setopt($ch, CURLOPT_NOBODY, true);
        if ($request['method'] === 'PUT') curl_setopt($ch, CURLOPT_POSTFIELDS, $request['body']);
        $body = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        return ['status' => $status, 'headers' => $responseHeaders, 'body' => $body === false ? '' : $body];
    }

    public function putVerified(string $key, string $bytes, string $mime): void
    {
        $hash = hash('sha256', $bytes);
        $this->request('PUT', $key, $bytes, ['content-type' => $mime, 'x-amz-meta-sha256' => $hash]);
        // Verify actual stored bytes, rather than trusting a successful response or ETag.
        $remote = $this->request('GET', $key)['body'];
        if (!hash_equals($hash, hash('sha256', $remote))) throw new RuntimeException('R2 photo verification failed. The local photo was kept.');
    }
}
