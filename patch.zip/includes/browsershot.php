<?php

use Spatie\Browsershot\Browsershot;

$autoloadPath = __DIR__ . '/../vendor/autoload.php';

if (!file_exists($autoloadPath)) {
    die('Autoload file not found: ' . $autoloadPath);
}

include_once $autoloadPath;

function generatePDF($htmlContent, $outputFileName, $isLandscape = false)
{
    // Generate PDF from the combined HTML
    try {
        $browsershot = Browsershot::html($htmlContent);

        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            // Windows paths
            $browsershot->setNodeBinary('C:\Program Files\nodejs\node.exe');
            $browsershot->setNpmBinary('C:\Program Files\nodejs\npm.cmd');
            $browsershot->setOption('executablePath', 'C:\Program Files\Google\Chrome\Application\chrome.exe');
        } else {
            // Linux paths
            $browsershot->setNodeBinary('/usr/bin/node');
            $browsershot->setNpmBinary('/usr/bin/npm');
            $browsershot->setOption('executablePath', '/usr/bin/google-chrome');
        }

        $pdf_data = $browsershot
            ->format('A4')
            ->landscape($isLandscape) // Ensure portrait mode
            ->showBackground() // Important for background colors
            ->setOption('args', [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-gpu',
                '--single-process', // Reduces resource usage
                '--no-zygote',      // Reduces memory
                '--no-first-run',
                '--disable-extensions',
                '--disable-background-timer-throttling',
                '--disable-backgrounding-occluded-windows',
                '--disable-renderer-backgrounding',
                '--memory-pressure-off',
                '--max-old-space-size=4096' // Limit Node.js memory
            ])
            ->disableJavascript()
            ->emulateMedia('print')  // Add this line
            ->timeout(120)
            ->pdf();

        // Output PDF to browser
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $outputFileName . '.pdf"');
        echo $pdf_data;
    } catch (Exception $e) {
        die("Failed to generate PDF. Please try again or contact support. Error: " . safe_htmlspecialchars($e->getMessage()));
    }
}
