<?php
 /**
 * Send Firebase notification using a Node.js server
 * @param array $deviceTokens Array of device tokens
 * @param string $title Notification title
 * @param string $body Notification body
 * @param array $data Additional data to send with the notification
 * @return array Result of the notification send operation
 */
function sendFirebaseNotification(PDO $pdo, array $studentIds, $deviceTokens, $title, $body, array $data, bool $insertNotificationLogs = true) {
    global $websiteConfig;
    $serviceAccountKey = $websiteConfig['fbase_service_account_key'] ?? '';
    $nodeServerUrl = 'https://fcm-school-songi.dahukinfotech.com/send-notification-fast'; // Update with your Node server URL
    // $nodeServerUrl = 'http://localhost:3000/send-notification-fast';
    
    // 1. Prevent unnecessary requests if the service account key is missing
    if (empty($serviceAccountKey)) {
        return [
            'success' => false,
            'message' => 'Service account key is missing in configuration'
        ];
    }
    
    $studentIds = array_unique(array_map('trim', array_filter($studentIds, 'is_string')));
    
    // 2. Add 'service_account' to the payload so the Node server can initialize dynamically
    $payload = [
        'service_account' => $serviceAccountKey, 
        'device_tokens'   => $deviceTokens,
        'title'           => $title,
        'body'            => $body,
        'data'            => $data
    ];
    
    $options = [
        'http' => [
            'header'  => "Content-type: application/json\r\n",
            'method'  => 'POST',
            'content' => json_encode($payload),
            'ignore_errors' => true // Prevents PHP warnings for HTTP status codes >= 400
        ]
    ];
    
    $context  = stream_context_create($options);
    
    // The @ operator suppresses connection-level warnings (e.g., host not found, connection refused)
    $result = @file_get_contents($nodeServerUrl, false, $context);
    
    if ($result === false) {
        return [
            'success' => false,
            'message' => 'Failed to connect to notification server'
        ];
    } else {
        if ($insertNotificationLogs) {
            insertNotificationLog($pdo, $studentIds, $title, $body);
        }
    }
    
    return json_decode($result, true);
}

/**
 * Insert a notification log into the database
 * @param PDO $pdo Database connection
 * @param array $studentIds Array of student IDs
 * @param string $title Notification title
 * @param string $body Notification body
 */
function insertNotificationLog(PDO $pdo, array $studentIds, string $title, string $body): void {
    $stmt = $pdo->prepare("INSERT INTO student_notifications_log (student_ids, notification_title, notification_body, created_at) VALUES (:student_ids, :title, :body, NOW())");
    $stmt->execute([
        ':student_ids' => implode(',', $studentIds),
        ':title' => $title,
        ':body' => $body
    ]);
}

/**
 * Delete notification logs older than specified days
 * @param PDO $pdo Database connection
 * @param int $days Number of days to retain logs
 */
function deleteOlderNotificationLogs(PDO $pdo, int $days = 30): void {
    $stmt = $pdo->prepare("DELETE FROM student_notifications_log WHERE created_at < NOW() - INTERVAL :days DAY");
    $stmt->execute([':days' => $days]);
}

/**
 * Retrieve FCM tokens for parents based on student IDs
 * @param PDO $pdo Database connection
 * @param array $studentIds Array of student IDs
 * @return array Array of FCM tokens
 */
function getFCMTokensFromDatabase(PDO $pdo, array $studentIds): array {
    // ১. আইডিগুলো ফিল্টার করা (ফাঁকা ভ্যালু বাদ দেওয়া এবং ইউনিক করা)
    $studentIds = array_unique(array_filter($studentIds));
    
    if (empty($studentIds)) {
        return [];
    }

    // ২. সবগুলো শিক্ষার্থীর ফোন নম্বর এক কোয়েরিতে নিয়ে আসা
    // প্লেসহোল্ডার তৈরি করা (যেমন: ?, ?, ?)
    $placeholders = implode(',', array_fill(0, count($studentIds), '?'));
    $stmt = $pdo->prepare("SELECT phone_number, alternate_phone_number FROM students WHERE student_id IN ($placeholders)");
    $stmt->execute(array_values($studentIds));
    $studentsData = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $phoneNumbers = [];
    
    // ৩. ফোন নম্বরগুলো একটি সিঙ্গেল অ্যারেতে যুক্ত করা
    foreach ($studentsData as $data) {
        if (!empty($data['phone_number'])) {
            $phoneNumbers[] = trim($data['phone_number']);
        }
        if (!empty($data['alternate_phone_number'])) {
            $phoneNumbers[] = trim($data['alternate_phone_number']);
        }
    }

    // ডুপ্লিকেট ফোন নম্বর বাদ দেওয়া
    $phoneNumbers = array_unique(array_filter($phoneNumbers));

    if (empty($phoneNumbers)) {
        return [];
    }

    // ৪. সবগুলো ফোন নম্বরের FCM টোকেন এক কোয়েরিতে নিয়ে আসা
    $phonePlaceholders = implode(',', array_fill(0, count($phoneNumbers), '?'));
    $stmt2 = $pdo->prepare("SELECT fcm_token FROM parent_auth_sessions WHERE phone IN ($phonePlaceholders)");
    $stmt2->execute(array_values($phoneNumbers));
    $tokens = $stmt2->fetchAll(PDO::FETCH_COLUMN);

    // ৫. টোকেনগুলো ক্লিন করা এবং ডুপ্লিকেট বাদ দেওয়া
    if ($tokens) {
        $fcmTokens = array_unique(array_map('trim', array_filter($tokens)));
        return array_values($fcmTokens); // রি-ইনডেক্স করে রিটার্ন করা
    }

    return [];
}