<?php
// Shared document controls; no database queries or external upload is performed here.
require_once(__DIR__ . '/document-upload-limits.php');
$document_upload_config = [
    'maxPostBytes' => documentUploadIniBytes((string)ini_get('post_max_size')),
    'maxFileBytes' => min(2097152, documentUploadIniBytes((string)ini_get('upload_max_filesize')) ?: 2097152),
    'maxFiles' => (int)ini_get('max_file_uploads'),
];
?>
<div class="modal fade" id="documentCropModal" tabindex="-1" aria-labelledby="documentCropTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="documentCropTitle">Crop Document</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cancel"></button>
            </div>
            <div class="modal-body">
                <p class="small text-muted">Drag any edge or corner to crop freely. There is no fixed aspect ratio.</p>
                <div style="height: min(55vh, 520px); min-height:240px"><img id="documentCropImage" alt="Document to crop" style="display:block;max-width:100%"></div>
                <div class="d-flex flex-wrap gap-2 mt-3">
                    <button type="button" class="btn btn-outline-secondary btn-sm" data-document-crop="rotate-left">Rotate left</button>
                    <button type="button" class="btn btn-outline-secondary btn-sm" data-document-crop="rotate-right">Rotate right</button>
                    <button type="button" class="btn btn-outline-secondary btn-sm" data-document-crop="reset">Reset</button>
                </div>
                <p id="documentCropError" class="small text-danger mt-2" role="alert"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="documentCropConfirm">Crop &amp; Use</button>
            </div>
        </div>
    </div>
</div>
<script>window.DocumentUploadConfig = <?= json_encode($document_upload_config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;</script>
<script src="<?= BASE_URL ?>/assets/js/document-uploads.js?v=<?= filemtime(__DIR__ . '/../assets/js/document-uploads.js') ?>"></script>
