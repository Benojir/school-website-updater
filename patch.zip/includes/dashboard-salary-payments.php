<?php
// Salary administration follows the same access rules as Salary payments.
if (!$can_see_financial_data || !isSuperAdmin() || !hasPermission(PERM_MANAGE_TEACHERS_ATTENDANCE)) return;
require_once __DIR__.'/teacher/staff-attendance-service.php';
$dashboardSalaryNow=new DateTimeImmutable('now');
$dashboardSalaryZone=new DateTimeZone(date_default_timezone_get());
$dashboardSalaryPeriod=staffPaymentOverviewPeriod($dashboardSalaryNow,$dashboardSalaryZone);
$dashboardSalarySummary=null;
$dashboardSalaryError=false;
try {
    $dashboardSalarySummary=(new StaffAttendanceService($pdo))->paymentOverview($dashboardSalaryNow);
} catch (Throwable $e) {
    error_log('Dashboard salary payments: '.$e->getMessage());
    $dashboardSalaryError=true;
}
$dashboardSalaryAmount=static fn(string $field):string=>$dashboardSalarySummary===null?'—':safe_htmlspecialchars($currency_symbol).' '.number_format($dashboardSalarySummary[$field]/100,2);
$dashboardSalaryLastMonth=new DateTimeImmutable($dashboardSalaryPeriod['last_month'].'-01',$dashboardSalaryZone);
?>
<div class="col-12 col-md-6 col-xl-3" id="dashboardSalaryPayments">
    <section class="card border-start-3 border-start-info shadow-sm h-100" aria-labelledby="dashboardSalaryTitle" title="Recorded with Mark paid, by payment date. This year means January to today.">
        <div class="card-body">
            <div class="d-flex align-items-center mb-2">
                <div class="flex-grow-1">
                    <h4 id="dashboardSalaryTitle" class="small text-muted mb-0">Teacher Salaries Paid</h4>
                    <div class="h4 mb-0 text-break" data-salary-last-month><?= $dashboardSalaryAmount('last_month_paise') ?></div>
                    <div class="small text-muted">Last month · <?= $dashboardSalaryLastMonth->format('M Y') ?></div>
                </div>
                <i class="fas fa-money-check-alt fa-2x text-info ms-3" aria-hidden="true"></i>
            </div>
            <div class="small d-flex justify-content-between flex-wrap gap-1 mb-1">
                <span class="text-muted" title="January to today">This year · <?= $dashboardSalaryPeriod['year'] ?></span>
                <strong class="text-break" data-salary-year><?= $dashboardSalaryAmount('year_paise') ?></strong>
            </div>
            <?php if ($dashboardSalaryError): ?>
                <p class="small text-danger mb-1" role="status">Salary totals are unavailable.</p>
            <?php elseif ($dashboardSalarySummary['reconciliation_count']>0): ?>
                <p class="small text-warning-emphasis mb-1" role="status">Check payment history.</p>
            <?php endif; ?>
            <a class="small text-decoration-none" href="<?= safe_htmlspecialchars(BASE_URL) ?>/management/teacher/salary-payments.php">View salary payments</a>
        </div>
    </section>
</div>
