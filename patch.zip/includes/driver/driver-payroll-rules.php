<?php
declare(strict_types=1);

class DriverPayrollConflict extends RuntimeException {}
class DriverPayrollDenied extends RuntimeException {}

function driverPayrollDate(mixed $value): string
{
    if (!is_string($value) || !preg_match('/^(20\d{2}|2100)-\d{2}-\d{2}$/D', $value)) {
        throw new InvalidArgumentException('Choose a valid date between 2000 and 2100.');
    }
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    if (!$date || $date->format('Y-m-d') !== $value) throw new InvalidArgumentException('Invalid calendar date.');
    return $value;
}

function driverPayrollMonth(mixed $value): string
{
    if (!is_string($value) || !preg_match('/^(20\d{2}|2100)-\d{2}$/D', $value)) throw new InvalidArgumentException('Choose a salary month.');
    driverPayrollDate($value . '-01');
    return $value;
}

// Amounts travel as decimal strings and are stored/calculated as integer minor units.
function driverPayrollMoney(mixed $value, bool $positive = false): int
{
    if (!is_string($value) && !is_int($value)) throw new InvalidArgumentException('Enter money as a decimal amount with at most two decimal places.');
    $value = trim((string)$value);
    if (!preg_match('/^\d{1,8}(?:\.\d{1,2})?$/D', $value)) throw new InvalidArgumentException('Amount must be between 0 and 99,999,999.99 with at most two decimals.');
    [$whole, $fraction] = array_pad(explode('.', $value, 2), 2, '');
    $paise = (int)$whole * 100 + (int)str_pad($fraction, 2, '0');
    if ($positive && $paise <= 0) throw new InvalidArgumentException('Amount must be greater than zero.');
    return $paise;
}

function driverPayrollText(mixed $value, string $label, int $max = 500, bool $required = true): string
{
    if (!is_string($value)) throw new InvalidArgumentException($label . ' must be text.');
    $value = trim($value);
    if (($required && $value === '') || mb_strlen($value) > $max) throw new InvalidArgumentException($label . ' is required and must be at most ' . $max . ' characters.');
    return $value;
}

/** Latest dated version wins, including same-date corrections; expiry never resurrects older terms. */
function driverPayrollEstimate(string $month, array $terms): array
{
    driverPayrollMonth($month);
    usort($terms, fn($a, $b) => [$a['effective_date'], (int)$a['id']] <=> [$b['effective_date'], (int)$b['id']]);
    $first = new DateTimeImmutable($month . '-01');
    $days = (int)$first->format('t');
    $weighted = 0; $covered = 0; $segments = [];
    for ($i = 0; $i < $days; $i++) {
        $date = $first->modify('+' . $i . ' days')->format('Y-m-d');
        $term = null;
        foreach ($terms as $candidate) {
            if ($candidate['effective_date'] > $date) break;
            $term = $candidate;
        }
        if (!$term || (!empty($term['end_date']) && $date > $term['end_date'])) continue;
        $amount = (int)$term['monthly_paise'];
        $weighted += $amount; $covered++;
        $id = (int)$term['id'];
        if (!isset($segments[$id])) $segments[$id] = ['term_id' => $id, 'from' => $date, 'to' => $date, 'days' => 0, 'monthly_paise' => $amount];
        $segments[$id]['to'] = $date; $segments[$id]['days']++;
    }
    return ['base_paise' => intdiv($weighted + intdiv($days, 2), $days), 'covered_days' => $covered,
        'calendar_days' => $days, 'segments' => array_values($segments)];
}

function driverPayrollAdjustments(mixed $items): array
{
    if (!is_array($items) || !array_is_list($items) || count($items) > 30) throw new InvalidArgumentException('Use at most 30 adjustment lines.');
    $result = []; $addition = 0; $deduction = 0;
    foreach ($items as $item) {
        if (!is_array($item) || !in_array($item['type'] ?? '', ['addition', 'deduction'], true)) throw new InvalidArgumentException('Choose addition or deduction for every adjustment.');
        $amount = driverPayrollMoney($item['amount'] ?? null, true);
        $result[] = ['type' => $item['type'], 'label' => driverPayrollText($item['label'] ?? '', 'Adjustment description', 200), 'amount_paise' => $amount];
        if ($item['type'] === 'addition') $addition += $amount; else $deduction += $amount;
    }
    return ['items' => $result, 'addition_paise' => $addition, 'deduction_paise' => $deduction];
}

function driverPayrollBalance(int $net, int $paid, int $recovered): array
{
    if ($net < 0 || $paid < 0 || $recovered < 0 || $paid + $recovered > $net) throw new DriverPayrollConflict('Salary totals need reconciliation.');
    $due = $net - $paid - $recovered;
    return ['net_paise' => $net, 'paid_paise' => $paid, 'recovered_paise' => $recovered, 'due_paise' => $due,
        'status' => $due === 0 ? 'settled' : ($paid + $recovered > 0 ? 'partial' : 'unpaid')];
}

function driverPayrollCash(array $row): int
{
    $sign = empty($row['reversal_of_id']) ? 1 : -1;
    if ($row['kind'] === 'advance_return') $sign *= -1;
    return $sign * (int)$row['amount_paise'];
}

function driverPayrollAdvanceTimeline(array $events): void
{
    usort($events, fn($a, $b) => $a['date'] <=> $b['date']);
    $byDate = [];
    foreach ($events as $event) $byDate[$event['date']] = ($byDate[$event['date']] ?? 0) + (int)$event['delta'];
    $balance = 0;
    foreach ($byDate as $date => $delta) {
        $balance += $delta;
        if ($balance < 0) throw new DriverPayrollConflict('This date would use advance money before it was available (' . $date . '). Check advance, return and recovery dates.');
    }
}
