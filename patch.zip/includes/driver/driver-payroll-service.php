<?php
declare(strict_types=1);
require_once __DIR__ . '/driver-payroll-rules.php';

final class DriverPayrollService
{
    public function __construct(private PDO $pdo, private int $actor = 0) {}

    private function rows(string $sql, array $params = []): array
    {
        $s = $this->pdo->prepare($sql); $s->execute($params); return $s->fetchAll(PDO::FETCH_ASSOC);
    }
    private function one(string $sql, array $params = []): ?array { return $this->rows($sql, $params)[0] ?? null; }
    private function run(string $sql, array $params): void { $s = $this->pdo->prepare($sql); $s->execute($params); }
    private function json(mixed $value): string { return json_encode($value, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE); }
    private function decimal(int $paise): string { return intdiv($paise, 100) . '.' . str_pad((string)($paise % 100), 2, '0', STR_PAD_LEFT); }
    public function id(mixed $value): int
    {
        if (filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 2147483647]]) === false) throw new InvalidArgumentException('Choose a valid driver or entry.');
        return (int)$value;
    }
    private function driver(int $id): array
    {
        $row = $this->one('SELECT id, name, serial_number, status FROM drivers WHERE id = ?', [$id]);
        if (!$row) {
            $history = $this->one('SELECT driver_name FROM driver_salary_months WHERE driver_id = ? ORDER BY salary_month DESC LIMIT 1', [$id])
                ?? $this->one('SELECT driver_name FROM driver_salary_payments WHERE driver_id = ? ORDER BY id DESC LIMIT 1', [$id]);
            if (!$history) throw new InvalidArgumentException('Driver does not exist.');
            $row = ['id' => $id, 'name' => $history['driver_name'], 'serial_number' => '', 'status' => 'deleted'];
        }
        return $row;
    }
    private function terms(int $id): array { return $this->rows('SELECT * FROM driver_salary_terms WHERE driver_id = ? ORDER BY effective_date, id', [$id]); }
    private function statement(int $id, string $month): ?array { return $this->one('SELECT * FROM driver_salary_months WHERE driver_id = ? AND salary_month = ?', [$id, $month]); }
    private function allocations(int $id, string $month): array
    {
        return $this->rows('SELECT a.*, p.method, p.reference FROM driver_salary_allocations a LEFT JOIN driver_salary_payments p ON p.id = a.payment_id WHERE a.driver_id = ? AND a.salary_month = ? ORDER BY a.id', [$id, $month]);
    }
    private function balance(array $statement): array
    {
        $paid = 0; $recovered = 0;
        foreach ($this->allocations((int)$statement['driver_id'], $statement['salary_month']) as $a) {
            $amount = (int)$a['amount_paise'] * (empty($a['reversal_of_id']) ? 1 : -1);
            if ($a['kind'] === 'salary') $paid += $amount; else $recovered += $amount;
        }
        return driverPayrollBalance((int)$statement['net_paise'], $paid, $recovered);
    }
    private function credit(int $id): int
    {
        // Keep stored amounts unsigned, but allow negative correcting entries in SQL.
        $cash = $this->one("SELECT COALESCE(SUM(CASE WHEN kind = 'advance' THEN CAST(amount_paise AS SIGNED) ELSE -CAST(amount_paise AS SIGNED) END * CASE WHEN reversal_of_id IS NULL THEN 1 ELSE -1 END),0) AS total FROM driver_salary_payments WHERE driver_id = ? AND kind IN ('advance','advance_return')", [$id]);
        $recovery = $this->one("SELECT COALESCE(SUM(CAST(amount_paise AS SIGNED) * CASE WHEN reversal_of_id IS NULL THEN 1 ELSE -1 END),0) AS total FROM driver_salary_allocations WHERE driver_id = ? AND kind = 'advance_recovery'", [$id]);
        $credit = (int)$cash['total'] - (int)$recovery['total'];
        if ($credit < 0) throw new DriverPayrollConflict('Advance balance needs reconciliation.');
        return $credit;
    }
    private function bump(int $id, string $month): void { $this->run('UPDATE driver_salary_months SET version = version + 1 WHERE driver_id = ? AND salary_month = ?', [$id, $month]); }
    private function audit(int $id, string $action, string $reason, mixed $before, mixed $after): void
    {
        $this->run('INSERT INTO driver_salary_audit (driver_id, actor_id, action_name, reason, before_json, after_json, created_at) VALUES (?,?,?,?,?,?,?)', [$id, $this->actor, $action, $reason, $this->json($before), $this->json($after), gmdate('Y-m-d H:i:s')]);
    }
    // Serialize every payroll write, including multi-month allocations, reversal and retries.
    public function write(array $input): array
    {
        if ($this->actor < 1) throw new DriverPayrollDenied('Administrator access is required.');
        $key = $input['request_key'] ?? '';
        if (!is_string($key) || !preg_match('/^[a-zA-Z0-9_-]{20,80}$/D', $key)) throw new InvalidArgumentException('A valid request key is required. Reload the page.');
        $action = $input['action'] ?? '';
        if (!in_array($action, ['term','month','lock','reopen','payment','quick_payment','recover','reverse_payment','reverse_recovery'], true)) throw new InvalidArgumentException('Unknown payroll action.');
        $hash = hash('sha256', $this->json([$this->actor, $input]));
        $this->pdo->beginTransaction();
        try {
            if (!$this->one('SELECT id FROM driver_salary_control WHERE id = 1 FOR UPDATE')) throw new RuntimeException('Payroll migration is missing.');
            $prior = $this->one('SELECT payload_hash, result_json FROM driver_salary_requests WHERE request_key = ?', [$key]);
            if ($prior) {
                if (!hash_equals($prior['payload_hash'], $hash)) throw new DriverPayrollConflict('This request key belongs to another operation. Reload before saving.');
                $result = json_decode($prior['result_json'], true, 32, JSON_THROW_ON_ERROR);
                $this->pdo->commit(); return $result;
            }
            $id = $this->id($input['driver_id'] ?? null);
            $driver = $this->driver($id);
            if ($driver['status'] === 'deleted' && ($action === 'term' || ($action === 'payment' && ($input['kind'] ?? '') === 'advance'))) throw new DriverPayrollConflict('Archived drivers can only settle existing balances or correct historical records.');
            $reason = driverPayrollText($input['reason'] ?? '', 'Reason');
            $result = match ($action) {
                'term' => $this->saveTerm($id, $input, $reason),
                'month' => $this->saveMonth($driver, $input, $reason),
                'lock', 'reopen' => $this->lockMonth($id, $input, $reason, $action),
                'payment' => $this->payment($driver, $input, $reason),
                'quick_payment' => $this->quickPayment($driver, $input, $reason),
                'recover' => $this->recover($id, $input, $reason),
                'reverse_payment' => $this->reversePayment($id, $input, $reason),
                'reverse_recovery' => $this->reverseRecovery($id, $input, $reason),
            };
            $events = $this->rows("SELECT payment_date AS date, SUM(CAST(amount_paise AS SIGNED) * CASE WHEN kind = 'advance' THEN 1 ELSE -1 END * CASE WHEN reversal_of_id IS NULL THEN 1 ELSE -1 END) AS delta FROM driver_salary_payments WHERE driver_id = ? AND kind IN ('advance','advance_return') GROUP BY payment_date", [$id]);
            foreach ($this->rows("SELECT entry_date AS date, -SUM(CAST(amount_paise AS SIGNED) * CASE WHEN reversal_of_id IS NULL THEN 1 ELSE -1 END) AS delta FROM driver_salary_allocations WHERE driver_id = ? AND kind = 'advance_recovery' GROUP BY entry_date", [$id]) as $event) $events[] = $event;
            driverPayrollAdvanceTimeline($events);
            $this->run('INSERT INTO driver_salary_requests (request_key, payload_hash, result_json, created_at) VALUES (?,?,?,?)', [$key, $hash, $this->json($result), gmdate('Y-m-d H:i:s')]);
            $this->pdo->commit(); return $result;
        } catch (Throwable $e) { if ($this->pdo->inTransaction()) $this->pdo->rollBack(); throw $e; }
    }
    private function version(?array $statement, mixed $version): void
    {
        if (filter_var($version, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]) === false || (int)$version !== (int)($statement['version'] ?? 0)) throw new DriverPayrollConflict('This salary changed in another session. Reload and review the latest balance.');
    }
    private function payable(int $id, array $input): array
    {
        $month = driverPayrollMonth($input['month'] ?? null);
        $statement = $this->statement($id, $month);
        if (!$statement || $statement['state'] !== 'locked') throw new DriverPayrollConflict('Prepare and lock ' . $month . ' before settling salary.');
        $this->version($statement, $input['version'] ?? null);
        return $statement;
    }
    private function transactionDate(array $input): string
    {
        $date = driverPayrollDate($input['date'] ?? null);
        if ($date > date('Y-m-d')) throw new InvalidArgumentException('Payments and recoveries cannot have a future date.');
        return $date;
    }
    private function saveTerm(int $id, array $input, string $reason): array
    {
        $date = driverPayrollDate($input['effective_date'] ?? null);
        $end = empty($input['end_date']) ? null : driverPayrollDate($input['end_date']);
        if ($end && $end < $date) throw new InvalidArgumentException('Last employment date must be on or after the effective date.');
        $amount = driverPayrollMoney($input['amount'] ?? null);
        $this->run('INSERT INTO driver_salary_terms (driver_id, effective_date, end_date, monthly_paise, reason, actor_id, created_at) VALUES (?,?,?,?,?,?,?)', [$id, $date, $end, $amount, $reason, $this->actor, gmdate('Y-m-d H:i:s')]);
        $result = ['term_id' => (int)$this->pdo->lastInsertId()];
        $this->audit($id, 'salary_term', $reason, null, $input);
        return $result;
    }
    private function saveMonth(array $driver, array $input, string $reason): array
    {
        $id = (int)$driver['id']; $month = driverPayrollMonth($input['month'] ?? null);
        $old = $this->statement($id, $month);
        if (!$old && $driver['status'] === 'deleted') throw new DriverPayrollConflict('New salary months cannot be issued for an archived driver.');
        $this->version($old, $input['version'] ?? null);
        if ($old && $old['state'] === 'locked') throw new DriverPayrollConflict('Reopen this salary month before changing its calculation.');
        $estimate = driverPayrollEstimate($month, $this->terms($id));
        $override = isset($input['base_amount']) && $input['base_amount'] !== '';
        if (!$override && (!is_string($input['estimate_hash'] ?? null) || !hash_equals(hash('sha256', $this->json($estimate)), $input['estimate_hash']))) throw new DriverPayrollConflict('Salary terms changed after this preview. Reload before saving the calculation.');
        if (!$override && $estimate['covered_days'] === 0) throw new InvalidArgumentException('Set salary terms for this month or enter a reviewed manual base amount.');
        $base = $override ? driverPayrollMoney($input['base_amount']) : $estimate['base_paise'];
        $adjustments = driverPayrollAdjustments($input['adjustments'] ?? []);
        $net = $base + $adjustments['addition_paise'] - $adjustments['deduction_paise'];
        if ($net < 0 || $net > 9999999999) throw new InvalidArgumentException('Net salary must be between 0 and 99,999,999.99.');
        $previousBalance = $old ? $this->balance($old) : ['paid_paise' => 0, 'recovered_paise' => 0];
        driverPayrollBalance($net, $previousBalance['paid_paise'], $previousBalance['recovered_paise']);
        $snapshot = ['estimate' => $estimate, 'base_paise' => $base, 'manual_base' => $override, 'adjustments' => $adjustments['items'], 'reason' => $reason];
        if ($old) {
            $this->run('UPDATE driver_salary_months SET base_paise = ?, addition_paise = ?, deduction_paise = ?, net_paise = ?, snapshot_json = ?, version = version + 1 WHERE id = ?', [$base, $adjustments['addition_paise'], $adjustments['deduction_paise'], $net, $this->json($snapshot), $old['id']]);
        } else {
            $this->run("INSERT INTO driver_salary_months (driver_id, driver_name, salary_month, base_paise, addition_paise, deduction_paise, net_paise, snapshot_json, state, version, created_at) VALUES (?,?,?,?,?,?,?,?,'draft',1,?)", [$id, $driver['name'], $month, $base, $adjustments['addition_paise'], $adjustments['deduction_paise'], $net, $this->json($snapshot), gmdate('Y-m-d H:i:s')]);
        }
        $new = $this->statement($id, $month); $this->audit($id, 'month_saved', $reason, $old, $new);
        return ['month' => $month];
    }
    private function lockMonth(int $id, array $input, string $reason, string $action): array
    {
        $month = driverPayrollMonth($input['month'] ?? null); $old = $this->statement($id, $month);
        $this->version($old, $input['version'] ?? null);
        if (!$old || $old['state'] !== ($action === 'lock' ? 'draft' : 'locked')) throw new DriverPayrollConflict('Salary is not in the required state. Reload this month.');
        $state = $action === 'lock' ? 'locked' : 'draft';
        $this->run('UPDATE driver_salary_months SET state = ?, version = version + 1 WHERE id = ?', [$state, $old['id']]);
        $this->audit($id, $action, $reason, $old, $this->statement($id, $month));
        return ['month' => $month];
    }
    private function insertAllocation(int $id, string $month, ?int $payment, string $kind, int $amount, string $date, string $reason, ?int $reversal = null): int
    {
        $this->run('INSERT INTO driver_salary_allocations (driver_id, salary_month, payment_id, kind, amount_paise, entry_date, reason, reversal_of_id, actor_id, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)', [$id, $month, $payment, $kind, $amount, $date, $reason, $reversal, $this->actor, gmdate('Y-m-d H:i:s')]);
        $entry = (int)$this->pdo->lastInsertId(); $this->bump($id, $month); return $entry;
    }
    /** Prepare, lock, recover selected advance and record one salary payment atomically. */
    private function quickPayment(array $driver, array $input, string $reason): array
    {
        $id = (int)$driver['id']; $month = driverPayrollMonth($input['month'] ?? null);
        $old = $this->statement($id, $month);
        $this->version($old, $input['version'] ?? null);
        $amount = driverPayrollMoney($input['amount'] ?? null);
        $recovery = driverPayrollMoney($input['recovery_amount'] ?? '0');
        if ($amount + $recovery <= 0) throw new InvalidArgumentException('Enter a salary payment or an advance recovery greater than zero.');
        $date = $this->transactionDate($input);
        $setup = $input['monthly_salary'] ?? '';
        if (!$old) {
            if ($driver['status'] === 'deleted') throw new DriverPayrollConflict('New salary months cannot be issued for an archived driver.');
            $terms = $this->terms($id); $estimate = driverPayrollEstimate($month, $terms);
            if (!is_string($input['estimate_hash'] ?? null) || !hash_equals(hash('sha256', $this->json($estimate)), $input['estimate_hash'])) throw new DriverPayrollConflict('Salary terms changed after this preview. Reload before recording the payment.');
            if (!$terms) {
                // First-time setup is explicitly shown as recurring salary from this month.
                driverPayrollMoney($setup, true);
                $this->saveTerm($id, ['amount' => $setup, 'effective_date' => $month . '-01'], $reason);
                $estimate = driverPayrollEstimate($month, $this->terms($id));
            } elseif ($setup !== '') throw new InvalidArgumentException('Salary terms already exist. Use salary settings to change them.');
            $this->saveMonth($driver, ['month' => $month, 'version' => 0, 'estimate_hash' => hash('sha256', $this->json($estimate)), 'base_amount' => '', 'adjustments' => []], $reason);
        } elseif ($setup !== '') throw new InvalidArgumentException('This salary is already prepared. Quick payment uses its saved calculation.');
        // Existing drafts keep their reviewed base, bonus and deductions; never recalculate them.
        $s = $this->statement($id, $month); $due = $this->balance($s)['due_paise'];
        if ($amount + $recovery > $due) throw new DriverPayrollConflict('Payment plus advance recovery exceeds this month\'s outstanding salary.');
        if ($recovery > $this->credit($id)) throw new DriverPayrollConflict('Recovery exceeds the unrecovered advance balance.');
        if ($s['state'] === 'draft') $this->lockMonth($id, ['month' => $month, 'version' => $s['version']], $reason, 'lock');
        $result = ['month' => $month];
        if ($recovery > 0) {
            $s = $this->statement($id, $month);
            $result += $this->recover($id, ['month' => $month, 'version' => $s['version'], 'amount' => $this->decimal($recovery), 'date' => $date], $reason);
        }
        if ($amount > 0) {
            $s = $this->statement($id, $month);
            $result += $this->payment($driver, ['kind' => 'salary', 'amount' => $this->decimal($amount), 'date' => $date,
                'method' => $input['method'] ?? '', 'reference' => $input['reference'] ?? '',
                'allocations' => [['month' => $month, 'version' => $s['version'], 'amount' => $this->decimal($amount)]]], $reason);
        }
        $this->audit($id, 'quick_payment', $reason, $old, $result);
        return $result;
    }
    private function payment(array $driver, array $input, string $reason): array
    {
        $id = (int)$driver['id']; $kind = $input['kind'] ?? '';
        if (!in_array($kind, ['salary','advance','advance_return'], true)) throw new InvalidArgumentException('Choose salary, advance or advance return.');
        $amount = driverPayrollMoney($input['amount'] ?? null, true); $date = $this->transactionDate($input);
        $method = $input['method'] ?? '';
        if (!in_array($method, ['cash','bank','upi','cheque','other'], true)) throw new InvalidArgumentException('Choose a payment method.');
        $reference = driverPayrollText($input['reference'] ?? '', 'Payment reference', 150, $method !== 'cash');
        $allocations = $input['allocations'] ?? [];
        if (!is_array($allocations) || !array_is_list($allocations) || count($allocations) > 24) throw new InvalidArgumentException('Use at most 24 salary months per payment.');
        if ($kind !== 'salary' && $allocations) throw new InvalidArgumentException('An advance is unallocated until explicitly recovered against salary.');
        if ($kind === 'salary') {
            $total = 0; $seen = [];
            foreach ($allocations as $a) {
                if (!is_array($a)) throw new InvalidArgumentException('Invalid salary allocation.');
                $s = $this->payable($id, $a); $month = $s['salary_month'];
                if (isset($seen[$month])) throw new InvalidArgumentException('Use one allocation per salary month.');
                $seen[$month] = true; $part = driverPayrollMoney($a['amount'] ?? null, true);
                if ($part > $this->balance($s)['due_paise']) throw new DriverPayrollConflict('Payment exceeds the outstanding salary for ' . $month . '. Record excess separately as an advance.');
                $total += $part;
            }
            if (!$allocations || $total !== $amount) throw new InvalidArgumentException('Salary allocations must add up exactly to the payment amount.');
        }
        if ($kind === 'advance_return' && $amount > $this->credit($id)) throw new DriverPayrollConflict('Return exceeds the unrecovered advance balance.');
        $this->run('INSERT INTO driver_salary_payments (driver_id, driver_name, kind, amount_paise, payment_date, method, reference, reason, actor_id, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)', [$id, $driver['name'], $kind, $amount, $date, $method, $reference, $reason, $this->actor, gmdate('Y-m-d H:i:s')]);
        $payment = (int)$this->pdo->lastInsertId();
        foreach ($allocations as $a) $this->insertAllocation($id, $a['month'], $payment, 'salary', driverPayrollMoney($a['amount'], true), $date, $reason);
        $result = ['payment_id' => $payment, 'receipt' => 'DSP-' . $payment];
        $this->audit($id, 'payment_recorded', $reason, null, ['payment_id' => $payment, 'input' => $input]); return $result;
    }
    private function recover(int $id, array $input, string $reason): array
    {
        $s = $this->payable($id, $input); $amount = driverPayrollMoney($input['amount'] ?? null, true); $date = $this->transactionDate($input);
        if ($amount > $this->credit($id)) throw new DriverPayrollConflict('Recovery exceeds the unrecovered advance balance.');
        if ($amount > $this->balance($s)['due_paise']) throw new DriverPayrollConflict('Recovery exceeds this month\'s outstanding salary.');
        $entry = $this->insertAllocation($id, $s['salary_month'], null, 'advance_recovery', $amount, $date, $reason);
        $this->audit($id, 'advance_recovered', $reason, null, ['allocation_id' => $entry, 'input' => $input]); return ['allocation_id' => $entry];
    }
    private function reversePayment(int $id, array $input, string $reason): array
    {
        $old = $this->one('SELECT * FROM driver_salary_payments WHERE id = ? AND driver_id = ?', [$this->id($input['payment_id'] ?? null), $id]);
        if (!$old || $old['reversal_of_id'] || $this->one('SELECT id FROM driver_salary_payments WHERE reversal_of_id = ?', [$old['id']])) throw new DriverPayrollConflict('Payment is missing or already reversed.');
        if ($old['kind'] === 'advance' && (int)$old['amount_paise'] > $this->credit($id)) throw new DriverPayrollConflict('Undo affected advance recoveries/returns first. This advance is already in use.');
        $date = $this->transactionDate($input);
        if ($date < $old['payment_date']) throw new InvalidArgumentException('Reversal date cannot precede the original payment.');
        $this->run('INSERT INTO driver_salary_payments (driver_id, driver_name, kind, amount_paise, payment_date, method, reference, reason, reversal_of_id, actor_id, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)', [$id, $old['driver_name'], $old['kind'], $old['amount_paise'], $date, $old['method'], $old['reference'], $reason, $old['id'], $this->actor, gmdate('Y-m-d H:i:s')]);
        $entry = (int)$this->pdo->lastInsertId();
        foreach ($this->rows('SELECT * FROM driver_salary_allocations WHERE payment_id = ? AND reversal_of_id IS NULL', [$old['id']]) as $a) {
            $this->insertAllocation($id, $a['salary_month'], $entry, 'salary', (int)$a['amount_paise'], $date, $reason, (int)$a['id']);
        }
        $this->audit($id, 'payment_reversed', $reason, $old, ['payment_id' => $entry]); return ['payment_id' => $entry];
    }
    private function reverseRecovery(int $id, array $input, string $reason): array
    {
        $old = $this->one("SELECT * FROM driver_salary_allocations WHERE id = ? AND driver_id = ? AND kind = 'advance_recovery'", [$this->id($input['allocation_id'] ?? null), $id]);
        if (!$old || $old['reversal_of_id'] || $this->one('SELECT id FROM driver_salary_allocations WHERE reversal_of_id = ?', [$old['id']])) throw new DriverPayrollConflict('Recovery is missing or already reversed.');
        $date = $this->transactionDate($input);
        if ($date < $old['entry_date']) throw new InvalidArgumentException('Reversal date cannot precede the recovery.');
        $entry = $this->insertAllocation($id, $old['salary_month'], null, 'advance_recovery', (int)$old['amount_paise'], $date, $reason, (int)$old['id']);
        $this->audit($id, 'recovery_reversed', $reason, $old, ['allocation_id' => $entry]); return ['allocation_id' => $entry];
    }
    private function consistent(callable $read): array
    {
        $this->pdo->beginTransaction();
        try {
            // Share the same control lock as writers so all totals belong to one snapshot,
            // even when a server changes its default transaction isolation level.
            if (!$this->one('SELECT id FROM driver_salary_control WHERE id = 1 LOCK IN SHARE MODE')) throw new RuntimeException('Payroll migration is missing.');
            $result = $read(); $this->pdo->commit(); return $result;
        }
        catch (Throwable $e) { if ($this->pdo->inTransaction()) $this->pdo->rollBack(); throw $e; }
    }
    public function context(): array
    {
        return ['drivers' => $this->rows("SELECT id, name, serial_number, status, 0 AS archived FROM drivers UNION ALL SELECT h.driver_id AS id, MAX(h.driver_name) AS name, '' AS serial_number, 'deleted' AS status, 1 AS archived FROM (SELECT driver_id, driver_name FROM driver_salary_months UNION ALL SELECT driver_id, driver_name FROM driver_salary_payments) h LEFT JOIN drivers d ON d.id = h.driver_id WHERE d.id IS NULL GROUP BY h.driver_id ORDER BY archived, name, id"), 'today' => date('Y-m-d')];
    }
    public function ledger(int $id, string $month, bool $admin = true): array
    {
        driverPayrollMonth($month);
        return $this->consistent(function () use ($id, $month, $admin) {
            $driver = $this->one('SELECT id, name, serial_number, status FROM drivers WHERE id = ?', [$id]);
            $s = $this->statement($id, $month); $terms = $this->terms($id);
            if (!$driver && !$admin) throw new DriverPayrollDenied('Driver account is unavailable.');
            if (!$driver) $driver = $this->driver($id);
            if ($s) {
                $s = array_merge($s, $this->balance($s));
                $s['snapshot'] = json_decode($s['snapshot_json'], true, 32, JSON_THROW_ON_ERROR); unset($s['snapshot_json']);
                foreach (['id','driver_id','version','base_paise','addition_paise','deduction_paise'] as $key) $s[$key] = (int)$s[$key];
            }
            $history = $this->rows('SELECT * FROM driver_salary_months WHERE driver_id = ? ORDER BY salary_month DESC LIMIT 120', [$id]);
            $totals = $this->one('SELECT COALESCE(SUM(net_paise),0) AS net, COUNT(*) AS months FROM driver_salary_months WHERE driver_id = ?', [$id]);
            $settled = $this->one("SELECT COALESCE(SUM(CAST(amount_paise AS SIGNED) * CASE WHEN reversal_of_id IS NULL THEN 1 ELSE -1 END),0) AS total FROM driver_salary_allocations WHERE driver_id = ?", [$id]);
            foreach ($history as &$h) { $h = array_merge($h, $this->balance($h)); unset($h['snapshot_json']); } unset($h);
            $allocations = $this->allocations($id, $month);
            if (!$admin) {
                foreach ($terms as &$t) unset($t['actor_id']); unset($t);
                foreach ($allocations as &$a) unset($a['actor_id']); unset($a);
            }
            $estimate = driverPayrollEstimate($month, $terms);
            return ['driver' => $driver, 'month' => $month, 'statement' => $s, 'estimate' => $estimate, 'estimate_hash' => hash('sha256', $this->json($estimate)), 'terms' => $terms,
                'advance_paise' => $this->credit($id), 'all_due_paise' => (int)$totals['net'] - (int)$settled['total'], 'month_count' => (int)$totals['months'],
                'history' => $history, 'allocations' => $allocations,
                'audit' => $admin ? $this->rows('SELECT id, actor_id, action_name, reason, created_at FROM driver_salary_audit WHERE driver_id = ? ORDER BY id DESC LIMIT 50', [$id]) : []];
        });
    }
    public function report(string $from, string $to, ?int $id = null, ?string $month = null, int $page = 1, bool $admin = true): array
    {
        driverPayrollDate($from); driverPayrollDate($to);
        if ($from > $to || (new DateTimeImmutable($from))->diff(new DateTimeImmutable($to))->days > 365) throw new InvalidArgumentException('Choose an inclusive date range of at most 366 days.');
        if ($month !== null) driverPayrollMonth($month);
        if ($page < 1 || $page > 100000) throw new InvalidArgumentException('Invalid report page.');
        return $this->consistent(function () use ($from, $to, $id, $month, $page, $admin) {
            $where = 'p.payment_date BETWEEN ? AND ?'; $params = [$from, $to];
            if ($id !== null) { $where .= ' AND p.driver_id = ?'; $params[] = $id; }
            // Salary-month filter includes only salary cash entries attributed to that month.
            // Per-month portions are used when one receipt spans several months.
            $join = ''; $amount = 'p.amount_paise';
            if ($month !== null) {
                $join = ' JOIN driver_salary_allocations a ON a.payment_id = p.id AND a.salary_month = ?';
                array_unshift($params, $month); $amount = 'a.amount_paise';
                $where .= " AND p.kind = 'salary'";
            }
            $signed = "CAST($amount AS SIGNED) * CASE WHEN p.reversal_of_id IS NULL THEN 1 ELSE -1 END * CASE WHEN p.kind = 'advance_return' THEN -1 ELSE 1 END";
            $totals = $this->one("SELECT COUNT(*) AS entry_count, COALESCE(SUM($signed),0) AS net_paise, COALESCE(SUM(CASE WHEN p.reversal_of_id IS NULL AND p.kind <> 'advance_return' THEN $amount ELSE 0 END),0) AS outgoing_paise, COALESCE(SUM(CASE WHEN p.reversal_of_id IS NULL AND p.kind = 'advance_return' THEN $amount ELSE 0 END),0) AS returned_paise, COALESCE(SUM(CASE WHEN p.reversal_of_id IS NOT NULL THEN $signed ELSE 0 END),0) AS correction_paise FROM driver_salary_payments p $join WHERE $where", $params);
            $groups = $this->rows("SELECT p.driver_id, MAX(p.driver_name) AS driver_name, COUNT(*) AS entry_count, SUM($signed) AS net_paise FROM driver_salary_payments p $join WHERE $where GROUP BY p.driver_id ORDER BY driver_name, p.driver_id", $params);
            $offset = ($page - 1) * 50;
            $rows = $this->rows("SELECT p.*, $amount AS report_amount_paise, $signed AS signed_paise, r.id AS reversed_by_entry FROM driver_salary_payments p $join LEFT JOIN driver_salary_payments r ON r.reversal_of_id = p.id WHERE $where ORDER BY p.payment_date DESC, p.id DESC LIMIT 50 OFFSET $offset", $params);
            foreach ($rows as &$row) {
                $row['allocations'] = $this->rows('SELECT salary_month, amount_paise FROM driver_salary_allocations WHERE payment_id = ? ORDER BY salary_month', [$row['id']]);
                if (!$admin) unset($row['actor_id']);
            } unset($row);
            foreach ($totals as &$value) $value = (int)$value; unset($value);
            return ['from' => $from, 'to' => $to, 'salary_month' => $month, 'page' => $page, 'page_size' => 50, 'totals' => $totals, 'drivers' => $groups, 'entries' => $rows];
        });
    }
}
