<?php
require_once __DIR__ . '/../photo-storage.php';
require_once __DIR__ . '/../id-card-school-data.php';
// Driver card fields are shared by the toolbox, database projection and printer.
function driverIdCardFields(): array
{
    return [
        'Driver' => [
            'driver_name' => ['Driver Name', 'name'], 'driver_id' => ['Driver ID', 'id'],
            'serial_number' => ['Serial Number', 'serial_number'], 'vehicle_number' => ['Vehicle Number', 'vehicle_number'],
            'route_names' => ['Assigned Routes', null], 'aadhaar_no' => ['Aadhaar Number', 'aadhaar_number'],
            'pan_number' => ['PAN Number', 'pan_number'], 'voter_epic_number' => ['Voter EPIC Number', 'voter_epic_number'],
        ],
        'Family & Contact' => [
            'driver_contact' => ['Contact Number', 'phone'], 'driver_email' => ['Email', 'email'],
            'father_name' => ["Father's Name", 'father_name'], 'father_phone' => ["Father's Contact", 'father_phone'],
            'mother_name' => ["Mother's Name", 'mother_name'], 'mother_phone' => ["Mother's Contact", 'mother_phone'],
        ],
        'Address' => [
            'driver_address' => ['Full Address', null], 'village' => ['Village', 'village'],
            'post_office' => ['Post Office', 'post_office'], 'police_station' => ['Police Station', 'police_station'],
            'district' => ['District', 'district'], 'pin_code' => ['PIN Code', 'pincode'],
        ],
        'School' => idCardSchoolFields(),
    ];
}

function driverIdCardSelectedIds(array $request): array
{
    if (isset($request['driver_ids'])) {
        if (!is_string($request['driver_ids'])) throw new InvalidArgumentException('Invalid driver selection.');
        $ids = json_decode($request['driver_ids'], true);
    } else {
        $raw = $request['ids'] ?? '';
        if (!is_string($raw)) throw new InvalidArgumentException('Invalid driver selection.');
        $ids = $raw !== '' ? explode(',', $raw) : [];
    }
    if (!is_array($ids) || !array_is_list($ids) || !$ids || count($ids) > 1000) {
        throw new InvalidArgumentException('Select between 1 and 1000 drivers.');
    }
    $result = [];
    foreach ($ids as $value) {
        if (!is_int($value) && !is_string($value)) throw new InvalidArgumentException('Invalid driver ID.');
        $id = filter_var($value, FILTER_VALIDATE_INT);
        if ($id === false || $id < 1) throw new InvalidArgumentException('Invalid driver ID.');
        $result[$id] = $id;
    }
    return array_values($result);
}

function driverIdCardRouteIds(array $driver): array
{
    $raw = $driver['route_ids'] ?? '';
    $decoded = is_string($raw) && $raw !== '' ? json_decode($raw, true) : null;
    if (!is_array($decoded) || !array_is_list($decoded)) $decoded = [$driver['route_id'] ?? 0];
    $result = [];
    foreach ($decoded as $value) {
        if (!is_string($value) && !is_int($value)) continue;
        $id = filter_var($value, FILTER_VALIDATE_INT);
        if ($id !== false && $id > 0) $result[$id] = $id;
    }
    return array_values($result);
}

function driverIdCardColumns(): array
{
    $columns = ['id', 'driver_image', 'route_ids', 'route_id', 'route'];
    foreach (driverIdCardFields() as $fields) foreach ($fields as [, $column]) {
        if ($column !== null) $columns[] = $column;
    }
    return array_values(array_unique($columns));
}

function driverIdCardPayload(array $driver, array $school, string $baseUrl, array $routes = []): array
{
    $payload = [];
    foreach (driverIdCardFields() as $fields) foreach ($fields as $variable => [, $column]) {
        $payload[$variable] = $column === null ? '' : (string)($driver[$column] ?? '');
    }
    $names = [];
    foreach (driverIdCardRouteIds($driver) as $id) {
        if (isset($routes[$id]) && trim((string)$routes[$id]) !== '') $names[] = (string)$routes[$id];
    }
    $payload['route_names'] = $names ? implode(', ', $names) : (string)($driver['route'] ?? '');
    $payload['driver_address'] = implode(', ', array_filter([
        $payload['village'], $payload['post_office'], $payload['police_station'], $payload['district'], $payload['pin_code']
    ], static fn($value) => trim($value) !== ''));
    $payload = array_replace($payload, idCardSchoolPayload($school));
    $image = trim((string)($driver['driver_image'] ?? ''));
    $payload['driver_photo_url'] = schoolPhotoCanvasUrl('drivers', $image !== '' ? basename($image) : null, $baseUrl);
    $payload['qr_payload'] = json_encode(['type' => 'driver', 'driver_id' => (int)($driver['id'] ?? 0)], JSON_THROW_ON_ERROR);
    return $payload;
}
