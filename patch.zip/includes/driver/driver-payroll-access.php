<?php
function canViewDriverPayroll(): bool
{
    return isSuperAdmin() || (hasPermission(PERM_MANAGE_TRANSPORT) && hasPermission(PERM_CAN_SEE_FINANCIAL_REPORT));
}
function canManageDriverPayroll(): bool
{
    return canViewDriverPayroll() && (isSuperAdmin() || hasPermission(PERM_MANAGE_EXPENSES));
}
