<?php

// Older driver records may store one JSON ID instead of a JSON list.
// Keep both admission validation and the route dropdown on the same list format.
function driverRouteIds(mixed $raw): array
{
    $ids = is_string($raw) ? json_decode($raw) : $raw;
    if (is_int($ids) || is_string($ids)) $ids = [$ids];
    if (!is_array($ids) || !array_is_list($ids)) return [];

    $result = [];
    foreach ($ids as $value) {
        if (!is_int($value) && !is_string($value)) continue;
        $id = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($id !== false) $result[$id] = $id;
    }
    return array_values($result);
}
