<?php

/**
 * Sends an OTP via API using cURL.
 * * @param string $mobile  The 10-digit mobile number.
 * @param string|int $otp The OTP code (4-8 digits).
 * @param string $gateway The gateway identifier.
 * @param string $token   The API token (pass this in dynamically).
 * @return array          Result array with 'success' (bool) and 'message'/'error'.
 */
function sendOTPApiCall(string $mobile, string $otp, string $gateway, string $token = 'nuralam543210'): array
{
    // http_build_query automatically handles URL encoding and joining parameters
    $queryParams = [
        'token'   => $token,
        'mobile'  => $mobile,
        'otp'     => $otp,
        'gateway' => $gateway,
        'school_id'  => SCHOOL_ID
    ];
    
    $baseUrl = "https://schoolsongi.com/sms/otp/send-otp.php";
    $requestUrl = $baseUrl . '?' . http_build_query($queryParams);

    // 3. Initialize cURL
    $ch = curl_init();
    
    // Set options using an array for better readability
    curl_setopt_array($ch, [
        CURLOPT_URL            => $requestUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,        // Lowered timeout to 10s (30s is too long for an OTP)
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_HTTPHEADER     => ['Accept: application/json'] // Hint to server we expect JSON
    ]);

    // 4. Execute
    $response = curl_exec($ch);
    $error    = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // Note: In PHP 8.0+, $ch is an object and closes automatically here.
    
    // 5. Handle Network/Transport Errors
    if ($error) {
        return ['success' => false, 'message' => "cURL error: {$error}"];
    }

    if ($httpCode !== 200) {
        return ['success' => false, 'message' => "API returned HTTP code: {$httpCode}"];
    }

    // 6. Parse Response
    $responseData = json_decode($response, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        return ['success' => false, 'message' => 'Invalid JSON response from API'];
    }

    // 7. Normalize Response
    if ($responseData === null) {
        return ['success' => false, 'message' => 'Invalid JSON response from API'];
    }

    // 8. Validate Response
    if ($responseData['success']) {
        return [
            'success' => true,
            'message' => $responseData['message']
        ];
    } else {
        return ['success' => false, 'message' => $responseData['message']];
    }
}


// Send OTP to phone
function sendOTP(string $phone, string $otp): array
{   global $websiteConfig;
    $gateway = strtolower($websiteConfig['otp_messages_gateway'] ?? '');

    try {
        $result = sendOTPApiCall($phone, $otp, $gateway);

        if ($result['success']) {
            return ['success' => true, 'message' => 'New OTP sent to your phone number'];
        } else {
            return ['success' => false, 'message' => $result['message'] ?? 'Failed to send SMS OTP'];
        }
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'An unexpected error occurred while sending OTP. ' . $e->getMessage()];
    }
}

// Common error response function
function sendErrorResponse(string $message)
{
    echo json_encode([
        'success' => false,
        'message' => $message
    ]);
    exit;
}

// Common success response function
function sendSuccessResponse(string $message)
{
    echo json_encode([
        'success' => true,
        'message' => $message
    ]);
    exit;
}
