<?php
function sendWhatsAppMessage($phoneNumber, $message, $accessToken, $phoneNumberId) {
    // Validate parameters
    if (empty($phoneNumber) || empty($message) || empty($accessToken) || empty($phoneNumberId)) {
        return ['success' => false, 'error' => 'Missing required parameters'];
    }

    $url = "https://graph.facebook.com/v19.0/{$phoneNumberId}/messages";

    $data = [
        'messaging_product' => 'whatsapp',
        'to' => $phoneNumber,
        'type' => 'text',
        'text' => ['body' => $message]
    ];

    $headers = [
        "Authorization: Bearer $accessToken",
        "Content-Type: application/json"
    ];

    $jsonData = json_encode($data);
    if ($jsonData === false) {
        return ['success' => false, 'error' => 'Failed to encode JSON data'];
    }

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30); // 30-second timeout

    $response = curl_exec($ch);
    $error = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($error) {
        return ['success' => false, 'error' => $error];
    }

    $decodedResponse = json_decode($response, true);
    if ($httpCode >= 400) {
        $errorMsg = $decodedResponse['error']['message'] ?? 'Unknown error occurred';
        return ['success' => false, 'error' => $errorMsg, 'http_code' => $httpCode];
    }

    return ['success' => true, 'response' => $decodedResponse];
}

/**
 * Send OTP via BulkSMS API with proper JSON response handling
 * 
 * @param string $mobile The mobile number to send OTP to (without country code)
 * @param string $otp The OTP code to send
 * @param string $apiKey Your API key from BulkSMS
 * @return array Returns an array with success status and parsed API response
 */
function sendOTPViaBulkSMS($mobile, $otp, $apiKey) {
    // Validate inputs
    if (empty($mobile) || !preg_match('/^[0-9]{10}$/', $mobile)) {
        return ['success' => false, 'error' => 'Invalid mobile number (must be 10 digits)'];
    }
    
    if (empty($otp) || !preg_match('/^[0-9]{4,8}$/', $otp)) {
        return ['success' => false, 'error' => 'Invalid OTP (must be 4-8 digits)'];
    }

    // Prepare API URL
    $apiUrl = "https://otpsms.dahukinfotech.com/send-otp.php?token=nuralam543210&mobile=" . urlencode($mobile) . "&otp=" . urlencode($otp);

    // Initialize cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

    // Execute request
    $response = curl_exec($ch);
    $error = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    // Handle cURL errors
    if ($error) {
        return ['success' => false, 'error' => "cURL error: " . $error];
    }

    // Handle HTTP errors
    if ($httpCode != 200) {
        return ['success' => false, 'error' => "API returned HTTP code: " . $httpCode];
    }

    // Parse JSON response
    $responseData = json_decode($response, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        return ['success' => false, 'error' => 'Invalid JSON response from API'];
    }

    // Check API response status
    if (isset($responseData['status']) && strtolower($responseData['status']) === 'success') {
        return [
            'success' => true,
            'response' => [
                'status' => $responseData['status'],
                'message' => $responseData['remark']
            ]
        ];
    } else {
        $errorMsg = $responseData['remark'] ?? 'Unknown error occurred';
        return ['success' => false, 'error' => $errorMsg];
    }
}

/**
 * Defaul code block for many files
 */

 function sendOTP(array $websiteConfig, string $phone, string $otp): array {
    
    $gateway = strtolower($websiteConfig['otp_messages_gateway'] ?? '');
    
    try {
        switch ($gateway) {
            case 'sms':
                if (empty($websiteConfig['sms_api_key'])) {
                    return ['success' => false, 'message' => 'SMS gateway is not properly configured'];
                }

                $result = sendOTPViaBulkSMS($phone, $otp, $websiteConfig['sms_api_key']);
                if (!$result['success']) {
                    return ['success' => false, 'message' => $result['error'] ?? 'Failed to send SMS OTP'];
                }
                break;

            case 'whatsapp':
                if (empty($websiteConfig['whatsapp_access_token']) || empty($websiteConfig['whatsapp_phone_number_id'])) {
                    return ['success' => false, 'message' => 'WhatsApp gateway is not properly configured'];
                }

                $otpMessage = "Your OTP is $otp";
                $phone = $websiteConfig['country_code'] . $phone;
                
                $result = sendWhatsAppMessage(
                    $phone,
                    $otpMessage,
                    $websiteConfig['whatsapp_access_token'],
                    $websiteConfig['whatsapp_phone_number_id']
                );

                if (!$result['success']) {
                    return ['success' => false, 'message' => $result['error'] ?? 'Failed to send WhatsApp OTP'];
                }
                break;

            default:
                return ['success' => false, 'message' => 'No valid OTP gateway configured'];
        }

        return ['success' => true, 'message' => 'New OTP sent to your phone number'];
    } catch (Exception $e) {
        return ['success' => false, 'message' => 'An unexpected error occurred while sending OTP'];
    }
}

// Common error response function
function sendErrorResponse($message)
{
    http_response_code(400); // Bad Request
    echo json_encode([
        'success' => false,
        'message' => $message
    ]);
    exit;
}

// Common success response function
function sendSuccessResponse($message)
{
    echo json_encode([
        'success' => true,
        'message' => $message
    ]);
    exit;
}