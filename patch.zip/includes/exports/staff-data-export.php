<?php
// Shared allowlist, request validation and workbook generation. No bootstrap.
function staffExportConfig(string $type, bool $financial): array
{
    if (!in_array($type, ['teacher', 'driver'], true)) {
        throw new InvalidArgumentException('Invalid export type.');
    }
    $labels = ['id' => ucfirst($type) . ' ID', 'name' => ucfirst($type) . ' Name', 'phone' => 'Phone', 'email' => 'Email'];
    if ($type === 'teacher') {
        $labels += [
            'position_in_school'=>'Position in School', 'qualification'=>'Qualification',
            'subject_specialization'=>'Subject Specialization', 'joining_date'=>'Joining Date',
            'date_of_birth'=>'Date of Birth', 'gender'=>'Gender', 'blood_group'=>'Blood Group',
            'caste_category'=>'Caste Category', 'religion'=>'Religion', 'nationality'=>'Nationality',
            'has_experience'=>'Has Experience', 'previous_school'=>'Previous School', 'address'=>'Full Address'
        ];
        if ($financial) $labels['monthly_salary'] = 'Monthly Salary';
    } else {
        $labels += ['serial_number'=>'Serial Number', 'vehicle_number'=>'Vehicle Number'];
    }
    $labels += [
        'village'=>'Village/Town', 'post_office'=>'Post Office', 'police_station'=>'Police Station',
        'district'=>'District', 'pincode'=>'PIN Code', 'father_name'=>"Father's Name", 'father_phone'=>"Father's Phone",
        'mother_name'=>"Mother's Name", 'mother_phone'=>"Mother's Phone", 'aadhaar_number'=>'Aadhaar Number',
        'pan_number'=>'PAN Number', 'voter_epic_number'=>'Voter EPIC Number', 'bank_name'=>'Bank Name',
        'bank_branch'=>'Bank Branch', 'ifsc_code'=>'IFSC Code', 'account_number'=>'Account Number', 'status'=>'Status'
    ];
    return ['table'=>$type === 'teacher' ? 'teachers' : 'drivers', 'title'=>ucfirst($type) . ' Data', 'columns'=>$labels];
}

function staffExportRequest(array $input, array $config): array
{
    if (!is_string($input['staff_ids'] ?? null) || trim($input['staff_ids']) === '') {
        throw new InvalidArgumentException('Please select at least one person to export.');
    }
    $ids = explode(',', $input['staff_ids']);
    if (count($ids) > 10000) throw new InvalidArgumentException('Please export up to 10,000 people at a time.');
    foreach ($ids as &$id) {
        $id = filter_var(trim($id), FILTER_VALIDATE_INT, ['options'=>['min_range'=>1, 'max_range'=>2147483647]]);
        if ($id === false) throw new InvalidArgumentException('Invalid selection. Please select the people again.');
    }
    unset($id);
    if (!is_string($input['column_order'] ?? null) || trim($input['column_order']) === '') {
        throw new InvalidArgumentException('Please select at least one export column.');
    }
    $columns = array_values(array_unique(array_map('trim', explode(',', $input['column_order']))));
    foreach ($columns as $column) {
        if (!isset($config['columns'][$column])) throw new InvalidArgumentException('An export column is invalid or unavailable for your permissions.');
    }
    return [array_values(array_unique($ids)), $columns];
}

function staffExportRows(PDO $pdo, array $config, array $ids, array $columns): array
{
    $select = implode(', ', array_map(fn($key) => '`' . $key . '`', $columns));
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $table = $config['table'];
    $order = $table === 'teachers' ? 'name ASC, id ASC' : 'serial_number ASC, id ASC';
    $stmt = $pdo->prepare("SELECT $select FROM `$table` WHERE id IN ($placeholders) ORDER BY $order");
    $stmt->execute($ids);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function staffExportWorkbook(array $config, array $columns, array $rows): \PhpOffice\PhpSpreadsheet\Spreadsheet
{
    $book = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    $sheet = $book->getActiveSheet();
    $sheet->setTitle($config['title']);
    foreach ($columns as $index => $key) {
        $letter = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($index + 1);
        $sheet->setCellValueExplicit($letter . '1', $config['columns'][$key], \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
        foreach ($rows as $rowIndex => $row) {
            $value = $row[$key] ?? '';
            if (in_array($key, ['joining_date', 'date_of_birth'], true)) {
                $date = \DateTimeImmutable::createFromFormat('!Y-m-d', (string)$value);
                $value = $date && $date->format('Y-m-d') === $value ? $date->format('d-m-Y') : '';
            }
            // Explicit strings preserve leading zeros and prevent spreadsheet formula execution.
            $cell = $letter . ($rowIndex + 2);
            $sheet->setCellValueExplicit($cell, $key === 'monthly_salary' ? (float)$value : (string)$value,
                $key === 'monthly_salary' ? \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_NUMERIC : \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
            if ($key === 'monthly_salary') $sheet->getStyle($cell)->getNumberFormat()->setFormatCode('#,##0.00');
        }
        $sheet->getColumnDimension($letter)->setAutoSize(true);
    }
    $last = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex(count($columns));
    $sheet->getStyle("A1:{$last}1")->applyFromArray([
        'font'=>['bold'=>true, 'color'=>['rgb'=>'FFFFFF']],
        'fill'=>['fillType'=>\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, 'startColor'=>['rgb'=>'0D6EFD']]
    ]);
    $sheet->freezePane('A2');
    $sheet->setAutoFilter('A1:' . $last . (count($rows) + 1));
    return $book;
}
