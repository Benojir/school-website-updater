<?php
include_once(__DIR__ . "/config.php");

require_once(__DIR__ . '/imgbb-client.php');
require_once(__DIR__ . '/document-upload-limits.php');

// PHP discards oversized multipart bodies before the endpoint can validate them.
// Return a clear JSON error instead of reporting missing fields/captcha/documents.
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && documentUploadRequestTooLarge(
    (int)($_SERVER['CONTENT_LENGTH'] ?? 0), documentUploadIniBytes((string)ini_get('post_max_size'))
)) {
    http_response_code(413);
    header('Content-Type: application/json');
    echo json_encode(['success'=>false, 'message'=>'The form and files exceed the server upload limit. Reduce the images or save fewer documents at a time.']);
    exit;
}

function uploadToImgBB($image_path, $caption = '') {
    global $imgbb_api_key;
    if (!is_file($image_path) || !is_readable($image_path)) return ['success'=>false, 'error'=>'Unable to read image'];
    // Binary multipart avoids the extra memory and size of base64 document scans.
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($image_path) ?: 'application/octet-stream';
    return imgbbUploadWithRetry(['key'=>$imgbb_api_key, 'image'=>new CURLFile($image_path, $mime, basename($image_path)),
        'name'=>basename($image_path), 'description'=>$caption]);
}

/** Upload already validated camera bytes without retaining a local file. */
function uploadBytesToImgBB(string $image_data, string $name, string $caption = ''): array {
    global $imgbb_api_key;
    return imgbbUploadWithRetry(['key'=>$imgbb_api_key, 'image'=>base64_encode($image_data), 'name'=>$name, 'description'=>$caption]);
}

/**
 * Validate an uploaded document file ($_FILES['field_name']) and upload it to ImgBB.
 * Returns the direct image URL on success, or throws an Exception on failure.
 *
 * @param array  $file    A single entry from $_FILES (e.g. $_FILES['father_pan_image'])
 * @param string $caption Optional caption/description to attach to the ImgBB upload
 * @return string         Direct image URL returned by ImgBB
 * @throws Exception
 */
function uploadDocumentToImgBB(array $file, string $caption = '', ?callable $uploader = null): string
{
    // No file selected - nothing to do
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        throw new Exception("No file uploaded.");
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new Exception("File upload error code: " . $file['error']);
    }

    // Verify real MIME type
    $file_info = new finfo(FILEINFO_MIME_TYPE);
    $mime_type = $file_info->file($file['tmp_name']);

    $allowed_mimes = ['image/jpeg', 'image/png'];
    if (!in_array($mime_type, $allowed_mimes)) {
        throw new Exception("Invalid file type. Only JPG and PNG images are allowed for document uploads.");
    }

    // Verify it's really an image
    if (!getimagesize($file['tmp_name'])) {
        throw new Exception("Uploaded document is not a valid image.");
    }

    // Max 2MB per document image
    $max_size = 2 * 1024 * 1024;
    if ($file['size'] > $max_size) {
        throw new Exception("Document image size must be less than 2MB.");
    }

    // Reuse successful uploads on a short-lived form retry. If document 8 fails,
    // documents 1–7 do not have to be uploaded again. Cache is private to the PHP session.
    global $imgbb_api_key;
    $cacheKey = hash('sha256', hash_file('sha256', $file['tmp_name']) . "\0" . $caption . "\0" . (string)$imgbb_api_key);
    $canCache = session_status() === PHP_SESSION_ACTIVE;
    if ($canCache) {
        $cache = $_SESSION['document_imgbb_upload_cache'] ?? [];
        if (!is_array($cache)) $cache = [];
        $cache = array_filter($cache, static fn($entry) => is_array($entry) && ($entry['expires'] ?? 0) > time());
        $_SESSION['document_imgbb_upload_cache'] = $cache;
        if (isset($cache[$cacheKey]['url'])) return $cache[$cacheKey]['url'];
    }
    // A short gap between document requests avoids sending a rapid API burst.
    static $lastDocumentUpload = 0.0;
    $pause = max(0, 0.35 - (microtime(true) - $lastDocumentUpload));
    if ($pause > 0 && $uploader === null) usleep((int)round($pause * 1000000));
    $result = $uploader ? $uploader($file['tmp_name'], $caption) : uploadToImgBB($file['tmp_name'], $caption);
    $lastDocumentUpload = microtime(true);

    if (!$result['success']) {
        throw new Exception("Failed to upload document to ImgBB: " . ($result['error'] ?? 'Unknown error'));
    }

    if ($canCache) {
        if (count($_SESSION['document_imgbb_upload_cache']) >= 40) array_shift($_SESSION['document_imgbb_upload_cache']);
        $_SESSION['document_imgbb_upload_cache'][$cacheKey] = ['url'=>$result['url'], 'expires'=>time()+900];
    }
    return $result['url'];
}
?>
