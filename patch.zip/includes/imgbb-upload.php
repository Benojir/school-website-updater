<?php
include_once("config.php");

function uploadToImgBB($image_path, $caption = '') {
    global $imgbb_api_key;
    
    $url = 'https://api.imgbb.com/1/upload';
    $image_data = file_get_contents($image_path);
    $base64_image = base64_encode($image_data);
    
    $post_fields = [
        'key' => $imgbb_api_key,
        'image' => $base64_image,
        'name' => basename($image_path),
        'expiration' => 0 // 0 means never expire
    ];
    
    if (!empty($caption)) {
        $post_fields['description'] = $caption;
    }
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    $result = json_decode($response, true);
    
    if ($result && $result['success']) {
        return [
            'success' => true,
            'url' => $result['data']['url'],
            'thumbnail_url' => $result['data']['thumb']['url'] ?? $result['data']['url'],
            'delete_url' => $result['data']['delete_url'],
            'display_url' => $result['data']['display_url'] ?? $result['data']['url']
        ];
    }
    
    return ['success' => false, 'error' => $result['error']['message'] ?? 'Unknown error'];
}

/**
 * Validate an uploaded document file ($_FILES['field_name']) and upload it to ImgBB.
 * Returns the direct image URL on success, or throws an Exception on failure.
 *
 * @param array  $file    A single entry from $_FILES (e.g. $_FILES['father_pan_image'])
 * @param string $caption Optional caption/description to attach to the ImgBB upload
 * @return string         Direct image URL returned by ImgBB
 * @throws Exception
 */
function uploadDocumentToImgBB(array $file, string $caption = ''): string
{
    // No file selected - nothing to do
    if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        throw new Exception("No file uploaded.");
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new Exception("File upload error code: " . $file['error']);
    }

    // Verify real MIME type
    $file_info = new finfo(FILEINFO_MIME_TYPE);
    $mime_type = $file_info->file($file['tmp_name']);

    $allowed_mimes = ['image/jpeg', 'image/png'];
    if (!in_array($mime_type, $allowed_mimes)) {
        throw new Exception("Invalid file type. Only JPG and PNG images are allowed for document uploads.");
    }

    // Verify it's really an image
    if (!getimagesize($file['tmp_name'])) {
        throw new Exception("Uploaded document is not a valid image.");
    }

    // Max 2MB per document image
    $max_size = 2 * 1024 * 1024;
    if ($file['size'] > $max_size) {
        throw new Exception("Document image size must be less than 2MB.");
    }

    $result = uploadToImgBB($file['tmp_name'], $caption);

    if (!$result['success']) {
        throw new Exception("Failed to upload document to ImgBB: " . ($result['error'] ?? 'Unknown error'));
    }

    return $result['url'];
}
?>