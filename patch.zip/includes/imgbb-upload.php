<?php
include_once("config.php");

function uploadToImgBB($image_path, $caption = '') {
    global $imgbb_api_key;
    
    $url = 'https://api.imgbb.com/1/upload';
    $image_data = file_get_contents($image_path);
    $base64_image = base64_encode($image_data);
    
    $post_fields = [
        'key' => $imgbb_api_key,
        'image' => $base64_image,
        'name' => basename($image_path),
        'expiration' => 0 // 0 means never expire
    ];
    
    if (!empty($caption)) {
        $post_fields['description'] = $caption;
    }
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    $result = json_decode($response, true);
    
    if ($result && $result['success']) {
        return [
            'success' => true,
            'url' => $result['data']['url'],
            'thumbnail_url' => $result['data']['thumb']['url'] ?? $result['data']['url'],
            'delete_url' => $result['data']['delete_url'],
            'display_url' => $result['data']['display_url'] ?? $result['data']['url']
        ];
    }
    
    return ['success' => false, 'error' => $result['error']['message'] ?? 'Unknown error'];
}
?>