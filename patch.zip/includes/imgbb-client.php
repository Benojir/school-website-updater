<?php
// Pure HTTP client: tests can inject a transport and delay without touching a server.
function imgbbCurlUpload(array $fields): array
{
    $retryAfter = null;
    $ch = curl_init('https://api.imgbb.com/1/upload');
    curl_setopt_array($ch, [
        CURLOPT_POST => true, CURLOPT_POSTFIELDS => $fields, CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_TIMEOUT => 45, CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
        CURLOPT_HEADERFUNCTION => static function ($curl, string $header) use (&$retryAfter): int {
            if (stripos($header, 'Retry-After:') === 0) {
                $value = trim(substr($header, 12));
                $retryAfter = ctype_digit($value) ? (int)$value : max(0, (strtotime($value) ?: time()) - time());
            }
            return strlen($header);
        },
    ]);
    $body = curl_exec($ch);
    $result = ['body' => $body, 'status' => (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE),
        'errno' => curl_errno($ch), 'retry_after' => $retryAfter];
    curl_close($ch);
    return $result;
}

function imgbbUploadWithRetry(array $fields, ?callable $transport = null, ?callable $delay = null): array
{
    $transport ??= 'imgbbCurlUpload';
    $delay ??= static function (int $seconds): void { sleep($seconds); };
    if (!is_string($fields['key'] ?? null) || trim($fields['key']) === '') return ['success'=>false, 'error'=>'Image hosting is not configured.'];
    for ($attempt = 0; $attempt < 3; $attempt++) {
        // Long batches must not exhaust PHP's execution limit between documents.
        // Keep each HTTP attempt bounded; do not remove timeouts entirely.
        if ($transport === 'imgbbCurlUpload') @set_time_limit(90);
        $response = $transport($fields);
        $result = is_string($response['body'] ?? null) ? json_decode($response['body'], true) : null;
        $status = (int)($response['status'] ?? 0);
        $errno = (int)($response['errno'] ?? 0);
        if ($status === 200 && !empty($result['success']) && !empty($result['data']['url'])) {
            $data = $result['data'];
            return ['success'=>true, 'url'=>$data['url'], 'thumbnail_url'=>$data['thumb']['url'] ?? $data['url'],
                'delete_url'=>$data['delete_url'] ?? '', 'display_url'=>$data['display_url'] ?? $data['url']];
        }
        $message = $result['error']['message'] ?? ($errno ? 'Connection to image hosting timed out or failed.' : 'Image hosting returned an invalid response.');
        if (!is_string($message)) $message = 'Image hosting rejected the upload.';
        $message = str_replace($fields['key'], '[redacted]', $message);
        $transient = in_array($errno, [5, 6, 7, 18, 28, 52, 55, 56], true) || in_array($status, [408, 429, 500, 502, 503, 504], true) || ($status === 200 && !is_array($result));
        $wait = max(1 << $attempt, (int)($response['retry_after'] ?? 0));
        // Respect a long Retry-After by stopping, rather than retrying too early.
        if ($status === 429 && $wait > 10) return ['success'=>false, 'error'=>'Image hosting is temporarily rate-limited. Wait and retry the form.'];
        if (!$transient || $attempt === 2) return ['success'=>false, 'error'=>$message];
        $delay($wait);
    }
    return ['success'=>false, 'error'=>'Image upload failed.'];
}
