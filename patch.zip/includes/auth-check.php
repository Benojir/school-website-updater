<?php
require_once("config.php");

// Check if user is logged in via session
if (!isLoggedIn()) {
    // Check for remember me cookie
    if (isset($_COOKIE['remember_me'])) {
        $token = $_COOKIE['remember_me'];
        
        try {
            // Check token in database
            $stmt = $pdo->prepare("SELECT * FROM users WHERE remember_token = ? AND token_expiry > NOW() LIMIT 1");
            $stmt->execute([$token]);
            $user = $stmt->fetch();
            
            if ($user) {
                // Recreate session
                $_SESSION['user'] = [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'full_name' => $user['full_name'],
                    'role' => $user['user_role'],
                    'logged_in' => true
                ];
                
                // Refresh token expiry
                $expiry = time() + (86400 * 30); // 30 days
                $pdo->prepare("UPDATE users SET token_expiry = ? WHERE id = ?")
                    ->execute([date('Y-m-d H:i:s', $expiry), $user['id']]);
                
                setcookie('remember_me', $token, $expiry, "/");
            } else {
                // Invalid token, redirect to login
                echo '<script>location.replace("/");</script>';
                exit();
            }
        } catch (PDOException $e) {
            // Log error and redirect
            error_log("Remember me token error: " . $e->getMessage());
            echo '<script>location.replace("/");</script>';
            exit();
        }
    } else {
        // No session or cookie, redirect to login
        echo '<script>location.replace("/");</script>';
        exit();
    }
}
?>