<?php
include_once 'config.php';

// --- PERMISSION CONSTANTS ---
define('PERM_MANAGE_STUDENTS', 'manage_students');
define('PERM_MANAGE_TEACHERS', 'manage_teachers');
define('PERM_MANAGE_RESULTS', 'manage_results');
define('PERM_MANAGE_CLASS_ROUTINES', 'manage_class_routines');
define('PERM_MANAGE_FEES', 'manage_fees');
define('PERM_MANAGE_NOTICES', 'manage_notices');
define('PERM_MANAGE_EXAMS', 'manage_exams');
define('PERM_MANAGE_SCHOOL_GALLERY', 'manage_school_gallery');
define('PERM_MANAGE_STUDENTS_ATTENDANCE', 'manage_students_attendance');
define('PERM_MANAGE_TEACHERS_ATTENDANCE', 'manage_teachers_attendance');
define('PERM_MANAGE_TRANSPORT', 'manage_transport');
define('PERM_MANAGE_EXPENSES', 'manage_expenses');
define('PERM_CAN_SEE_FINANCIAL_REPORT', 'can_see_financial_report');

/**
 * Authenticates an admin request via Token or Cookie.
 * OPTIMIZED: Uses static caching to run DB queries only once per script execution.
 */
function getAuthenticatedAdmin($pdo) {
    // 1. MEMORY CACHE
    // If this function is called 5 times in one script, we only run the logic once.
    static $cachedResult = null;
    static $hasRun = false;

    if ($hasRun) {
        return $cachedResult;
    }

    $token = null;
    
    // 2. HEADER COMPATIBILITY (Polyfill for Nginx)
    $headers = [];
    if (function_exists('getallheaders')) {
        $headers = getallheaders();
    } else {
        foreach ($_SERVER as $name => $value) {
            if (substr($name, 0, 5) == 'HTTP_') {
                $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
            }
        }
    }

    // 3. RETRIEVE TOKEN
    // Check Mobile Bearer Token
    if (!empty($headers['Authentication']) && strpos($headers['Authentication'], 'Bearer ') === 0) {
        $token = str_replace('Bearer ', '', $headers['Authentication']);
    }
    // Check Web Cookie
    if (empty($token) && !empty($_COOKIE['admin_auth_token'])) {
        $token = $_COOKIE['admin_auth_token'];
    }

    if (empty($token)) {
        $hasRun = true; $cachedResult = null;
        return null; 
    }

    // 4. DB VALIDATION
    $tokenHash = hash('sha256', $token);
    $currentDateTime = date('Y-m-d H:i:s');

    try {
        $stmt = $pdo->prepare("SELECT * FROM admin_auth_sessions WHERE token_hash = ? AND expires_at > ?");
        $stmt->execute([$tokenHash, $currentDateTime]);
        $session = $stmt->fetch();
    } catch (PDOException $e) {
        // Fail gracefully if DB is down
        $hasRun = true; $cachedResult = null;
        return null; 
    }

    if (!$session) {
        $hasRun = true; $cachedResult = null;
        return null;
    }

    // 5. UPDATE LAST ACTIVITY (Throttled)
    // Only update DB if > 5 minutes have passed since last update
    $updateInterval = 300; 
    $lastActivityTime = strtotime($session['last_activity']);
    $currentTime = time();

    if (($currentTime - $lastActivityTime) > $updateInterval) {
        // We update the DB, but we don't wait for the result to speed up the UI
        $stmt = $pdo->prepare("UPDATE admin_auth_sessions SET last_activity = NOW(), ip_address = ? WHERE id = ?");
        $stmt->execute([getUserPublicIP(), $session['id']]);
        
        // Update local array so other functions see the new time
        $session['last_activity'] = date('Y-m-d H:i:s', $currentTime);
    }

    // 6. GARBAGE COLLECTION (Probabilistic)
    // 1% chance to delete expired sessions. Keeps the table clean without overhead.
    if (rand(1, 100) === 1) {
        $stmt = $pdo->prepare("DELETE FROM admin_auth_sessions WHERE expires_at < ?");
        $stmt->execute([$currentDateTime]);
    }

    // 7. SUCCESS RESULT
    $result = [
        'success' => true,
        'message' => 'Token successfully validated',
        'user_id' => $session['user_id'],
        'user_role' => $session['user_role'],
        'username' => $session['username'],
        'full_name' => $session['full_name'],
        'session_id' => $session['id'],
        'device_id' => $session['device_id'],
        'session_source' => $session['session_source']
    ];

    // Store in static cache
    $hasRun = true;
    $cachedResult = $result;

    return $result;
}

/**
 * Enforces authentication. Kills script with 401 if unauthorized.
 */
function authenticateAdminApiRequest($pdo) {
    $authData = getAuthenticatedAdmin($pdo);
    
    if (!$authData) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Unauthorized: Invalid or expired token']);
        exit;
    }
    
    return $authData;
}

/**
 * Boolean check for login status
 */
function isAnyAdminLoggedIn() {
    global $pdo;
    $authData = getAuthenticatedAdmin($pdo);
    return !empty($authData);
}

/**
 * Boolean check for Super Admin
 */
function isSuperAdmin() {
    global $pdo;
    $authData = getAuthenticatedAdmin($pdo);
    return ($authData && $authData['user_role'] === 'superadmin');
}

/**
 * Boolean check for specific permissions
 */
function hasPermission($permission) {
    global $pdo;
    $authData = getAuthenticatedAdmin($pdo);
    
    if (!$authData) return false;
    if ($authData['user_role'] === 'superadmin') return true;
    if ($authData['user_role'] !== 'admin') return false;
    
    // We do NOT cache this query statically because permission checks 
    // usually vary per call (checking 'student' then 'teacher', etc).
    try {
        $stmt = $pdo->prepare("
            SELECT 1 FROM admin_permissions p
            JOIN admin_roles r ON p.role_id = r.id
            JOIN users u ON u.role_id = r.id
            WHERE u.id = ? AND p.permission = ?
            LIMIT 1
        ");
        $stmt->execute([$authData['user_id'], $permission]);
        return (bool)$stmt->fetch();
    } catch (PDOException $e) {
        return false;
    }
}
?>