<?php
// Use the school's configured PHP timezone and the recorded payment date.
$todayFeesDate = date('Y-m-d');
if ($can_see_financial_data) {
    $todayFeesStatement = $pdo->prepare("SELECT
        (SELECT COALESCE(SUM(payment_amount), 0) FROM student_payment_history
         WHERE payment_date = ?) AS monthly,
        (SELECT COALESCE(SUM(payment_amount), 0) FROM admission_fees_payment_history
         WHERE payment_date = ?) AS admission");
    $todayFeesStatement->execute([$todayFeesDate, $todayFeesDate]);
    $todayFees = $todayFeesStatement->fetch(PDO::FETCH_ASSOC);
    $todayFeesTotal = (float)$todayFees['monthly'] + (float)$todayFees['admission'];
}
?>
<div class="col-6 col-md-6 col-xl-3 fees-info-card" title="Monthly and admission payments dated <?= $todayFeesDate ?>">
    <div class="card border-start-3 border-start-success shadow-sm h-100">
        <div class="card-body">
            <div class="d-flex align-items-center mb-2">
                <div class="flex-grow-1">
                    <div class="text-muted small">Fees Collected Today</div>
                    <div class="h4 mb-0"><?= $can_see_financial_data ? '₹' . number_format($todayFeesTotal, 2) : '-' ?></div>
                    <div class="text-muted small">Total (Monthly + Admission)</div>
                </div>
                <div class="ms-3">
                    <i class="fas fa-calendar-day fa-2x text-success opacity-100"></i>
                </div>
            </div>
            <div class="small d-flex justify-content-between flex-wrap gap-1">
                <span class="text-muted">Monthly</span>
                <span class="fw-semibold"><?= $can_see_financial_data ? '₹' . number_format($todayFees['monthly'], 2) : '-' ?></span>
            </div>
            <div class="small d-flex justify-content-between flex-wrap gap-1">
                <span class="text-muted">Admission</span>
                <span class="fw-semibold"><?= $can_see_financial_data ? '₹' . number_format($todayFees['admission'], 2) : '-' ?></span>
            </div>
        </div>
    </div>
</div>
