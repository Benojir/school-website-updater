<?php
require_once __DIR__ . '/photo-storage.php';
require_once __DIR__ . '/id-card-school-data.php';
/** Admit-card data is prepared only after examDocumentRequireDownload authorizes it. */
function admitCardBuilderDate($value, string $format = 'd M Y'): string
{
    if (!$value || str_starts_with((string) $value, '0000-00-00')) return '';
    $time = strtotime((string) $value);
    return $time === false ? '' : date($format, $time);
}

function admitCardBuilderTime($start, $end): string
{
    $from = admitCardBuilderDate($start, 'h:i A');
    $to = admitCardBuilderDate($end, 'h:i A');
    return $from . ($from && $to ? ' – ' : '') . $to;
}

function admitCardBuilderPrintGrid(float $width, float $height, bool $paired): array
{
    $unit = $paired ? $width * 2 : $width;
    $best = null;
    foreach (['portrait' => [210, 297], 'landscape' => [297, 210]] as $orientation => [$pageWidth, $pageHeight]) {
        $cols = (int) floor(($pageWidth + 0.001) / $unit);
        $rows = (int) floor(($pageHeight + 0.001) / $height);
        if ($cols > 0 && $rows > 0 && (!$best || $cols * $rows > $best['count'])) {
            $best = ['orientation' => $orientation, 'cols' => $cols, 'rows' => $rows, 'count' => $cols * $rows];
        }
    }
    if (!$best) throw new InvalidArgumentException($paired
        ? 'The front and back do not fit side-by-side on A4. Choose separate front and back sheets or reduce the card size.'
        : 'This card size does not fit on A4. Reduce its dimensions in the Admit Card Builder.');
    return $best;
}

function admitCardBuilderPayload(array $student, array $exam, array $school, array $routine): array
{
    $class = (string) ($student['class_name'] ?? '');
    $section = (string) ($student['section_name'] ?? '');
    return [
        'student_name' => $student['name'] ?? '', 'student_id' => $student['student_id'],
        'father_name' => $student['father_name'] ?? '', 'mother_name' => $student['mother_name'] ?? '',
        'roll_no' => $student['roll_no'] ?? '', 'class' => $class . ($section !== '' ? ' (' . $section . ')' : ''),
        'class_name' => $class, 'section' => $section, 'academic_year' => $exam['academic_year'],
        'dob' => admitCardBuilderDate($student['date_of_birth'] ?? null),
        'gender' => $student['gender'] ?? '', 'blood_group' => $student['blood_group'] ?? '',
        'registration_no' => $student['registration_no'] ?? '',
        'admission_date' => admitCardBuilderDate($student['admission_date'] ?? null),
        'aadhaar_no' => $student['student_adhaar_no'] ?? '',
        'village' => $student['village'] ?? '', 'post_office' => $student['post_office'] ?? '',
        'police_station' => $student['police_station'] ?? '', 'district' => $student['district'] ?? '', 'pin_code' => $student['pin_code'] ?? '',
        'student_contact' => $student['phone_number'] ?? '', 'alt_contact' => $student['alternate_phone_number'] ?? '',
        'student_address' => $student['address'] ?? '',
        'student_photo_url' => schoolPhotoCanvasUrl('students', $student['student_image'] ?? null),
        ...idCardSchoolPayload($school),
        'principal_name' => $school['principal_name'] ?? '',
        'principal_signature_url' => BASE_URL . '/uploads/school/principle_sign.png',
        'headmaster_name' => $school['headmaster_name'] ?? '',
        'headmaster_signature_url' => BASE_URL . '/uploads/school/headmaster_sign.png',
        'school_stamp_url' => BASE_URL . '/uploads/school/school_stamp.png',
        'exam_name' => $exam['exam_name'] ?? '', 'exam_date' => admitCardBuilderDate($exam['exam_date'] ?? null),
        'exam_center' => ($school['name'] ?? '') . (!empty($school['campus_name']) ? ' - ' . $school['campus_name'] : ''),
        'exam_routine' => array_map(static function ($row, $index) {
            return [
                'routine_serial' => $index + 1, 'routine_subject' => $row['subject_name'] ?? '',
                'routine_written_date' => admitCardBuilderDate($row['theory_exam_date'] ?? null),
                'routine_written_time' => admitCardBuilderTime($row['theory_start_time'] ?? null, $row['theory_end_time'] ?? null),
                'routine_oral_date' => admitCardBuilderDate($row['practical_exam_date'] ?? null),
                'routine_oral_time' => admitCardBuilderTime($row['practical_start_time'] ?? null, $row['practical_end_time'] ?? null),
            ];
        }, $routine, array_keys($routine)),
        'qr_payload' => json_encode(['student_id' => $student['student_id'], 'exam_id' => $exam['id'], 'academic_year' => $exam['academic_year']]),
    ];
}

function admitCardBuilderLoad($pdo, array $request, array $school): array
{
    if (isset($request['exam_id'])) {
        $stmt = $pdo->prepare('SELECT e.* FROM exams e WHERE e.id = ?');
        $stmt->execute([$request['exam_id']]);
    } else {
        $stmt = $pdo->prepare('SELECT e.*, a.class_id AS release_class_id FROM exam_admit_releases a JOIN exams e ON e.id = a.exam_id WHERE a.id = ?');
        $stmt->execute([$request['admit_id']]);
    }
    $exam = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$exam) throw new InvalidArgumentException('The selected examination was not found.');
    if (empty($exam['academic_year'])) throw new InvalidArgumentException('Set the academic year of this exam in Manage Examinations before downloading admit cards.');
    $year = academicNormalizeYear($exam['academic_year']);
    $routines = []; $cards = [];
    foreach ($request['student_ids'] as $studentId) {
        // Use enrollment for the EXAM year, including historical class, section and roll.
        $student = academicGetStudent($pdo, $studentId, $year);
        if (!$student || (isset($exam['release_class_id']) && (int) $student['class_id'] !== (int) $exam['release_class_id'])) {
            throw new InvalidArgumentException('A selected student is not enrolled in the class and academic year of this exam.');
        }
        $classId = (int) $student['class_id'];
        if (!array_key_exists($classId, $routines)) {
            $stmt = $pdo->prepare('SELECT er.*, sub.subject_name FROM exam_routines er JOIN subjects sub ON sub.id = er.subject_id
                WHERE er.exam_id = ? AND er.class_id = ?
                ORDER BY COALESCE(er.theory_exam_date, er.practical_exam_date), COALESCE(er.theory_start_time, er.practical_start_time), er.id');
            $stmt->execute([$exam['id'], $classId]);
            $routines[$classId] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        $cards[] = admitCardBuilderPayload($student, $exam, $school, $routines[$classId]);
    }
    return $cards;
}
