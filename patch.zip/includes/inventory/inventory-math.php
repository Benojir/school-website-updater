<?php
// Pure validation and stock-cost calculations. This file never connects to a database.
function inventoryText(mixed $value, int $max, string $label, bool $required = false): string {
    if (!is_string($value) && !is_numeric($value)) throw new InvalidArgumentException("$label is invalid.");
    $value = trim((string)$value);
    if (($required && $value === '') || mb_strlen($value) > $max) throw new InvalidArgumentException("Please enter a valid $label (up to $max characters).");
    return $value;
}
function inventoryInteger(mixed $value, string $label, int $min = 1, int $max = 100000): int {
    $value = filter_var($value, FILTER_VALIDATE_INT);
    if ($value === false || $value < $min || $value > $max) throw new InvalidArgumentException("$label must be a whole number between $min and $max.");
    return $value;
}
function inventoryMoney(mixed $value, string $label = 'Amount'): int {
    if (!is_scalar($value) || is_bool($value) || !preg_match('/^\d{1,8}(?:\.\d{1,2})?$/D', (string)$value)) {
        throw new InvalidArgumentException("$label must be a positive amount or zero, with up to 2 decimal places.");
    }
    $parts = explode('.', (string)$value);
    return ((int)$parts[0] * 100) + (int)str_pad($parts[1] ?? '', 2, '0');
}
function inventoryBoundedTotal(int $amount): int {
    if ($amount < 0 || $amount > 1000000000000) throw new InvalidArgumentException('The total is too large. Please split this entry into smaller entries.');
    return $amount;
}
function inventoryStockIssue(int $stock, int $value, int $quantity): array {
    if ($quantity < 1 || $quantity > $stock) throw new InvalidArgumentException('Not enough stock. Add stock first or reduce the quantity.');
    // Integer arithmetic preserves all paise when the last item is issued.
    $cost = intdiv($value * $quantity + intdiv($stock, 2), $stock);
    return ['quantity' => $stock - $quantity, 'value' => $value - $cost, 'cost' => $cost];
}
function inventoryStockReceive(int $stock, int $value, int $quantity, int $cost): array {
    if ($quantity < 1 || $stock + $quantity > 1000000) throw new InvalidArgumentException('Stock quantity is outside the supported range.');
    return ['quantity' => $stock + $quantity, 'value' => inventoryBoundedTotal($value + $cost)];
}
function inventoryBalance(int $total, int $paid, string $status): int {
    return $status === 'returned' ? 0 : max(0, $total - $paid);
}
function inventoryPaymentAmount(int $amount, int $balance): int {
    if ($amount <= 0 || $amount > $balance) throw new InvalidArgumentException('Enter an amount greater than zero and no more than the balance due.');
    return $amount;
}
function inventoryDateRange(array $input): array {
    $start = (string)($input['from'] ?? date('Y-m-01'));
    $end = (string)($input['to'] ?? date('Y-m-d'));
    foreach ([$start, $end] as $date) {
        $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
        if (!$parsed || $parsed->format('Y-m-d') !== $date) throw new InvalidArgumentException('Please select valid dates.');
    }
    if ($start > $end) throw new InvalidArgumentException('The start date must be before the end date.');
    return [$start . ' 00:00:00', (new DateTimeImmutable($end))->modify('+1 day')->format('Y-m-d 00:00:00')];
}
