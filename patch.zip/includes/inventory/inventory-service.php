<?php
require_once __DIR__ . '/inventory-math.php';

class InventoryService {
    private string $postedAt = '';
    public function __construct(private PDO $pdo, private int $adminId) {}

    private function query(string $sql, array $params = []): PDOStatement {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public function mutate(string $action, array $input): array {
        if (!in_array($action, ['product', 'purchase', 'sale', 'gift', 'damage', 'collect', 'settle', 'return'], true)) {
            throw new InvalidArgumentException('Unknown inventory action.');
        }
        $key = $input['request_key'] ?? '';
        if (!is_string($key) || !preg_match('/^[a-f0-9-]{36}$/iD', $key)) throw new InvalidArgumentException('Please reopen the form and try again.');
        $hash = hash('sha256', $action . json_encode($input, JSON_THROW_ON_ERROR));
        $ownsTransaction = !$this->pdo->inTransaction();
        if ($ownsTransaction) $this->pdo->beginTransaction();
        // Use the school's configured PHP timezone for all accounting dates.
        $this->postedAt = date('Y-m-d H:i:s');
        try {
            // The unique key serializes concurrent retries before any stock is touched.
            $this->query('INSERT INTO inventory_requests (request_key, payload_hash, created_by) VALUES (?, ?, ?)', [$key, $hash, $this->adminId]);
            $result = match ($action) {
                'product' => $this->saveProduct($input),
                'collect' => $this->collect($input),
                'settle' => $this->settle($input),
                'return' => $this->returnSale($input),
                default => $this->postDocument($action, $input)
            };
            $this->query('UPDATE inventory_requests SET result_json = ? WHERE request_key = ?', [json_encode($result, JSON_THROW_ON_ERROR), $key]);
            if ($ownsTransaction) $this->pdo->commit();
            return $result;
        } catch (Throwable $e) {
            // A store fulfillment owns the outer transaction, including its reservation and order.
            if (!$ownsTransaction) throw $e;
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            if ($e instanceof PDOException && ($e->errorInfo[1] ?? null) == 1062) {
                $previous = $this->query('SELECT * FROM inventory_requests WHERE request_key = ?', [$key])->fetch(PDO::FETCH_ASSOC);
                if ($previous) {
                    if ((int)$previous['created_by'] !== $this->adminId || !hash_equals($previous['payload_hash'], $hash)) {
                        throw new InvalidArgumentException('This request was already used. Close and reopen the form.');
                    }
                    return json_decode($previous['result_json'], true, 512, JSON_THROW_ON_ERROR);
                }
                throw new InvalidArgumentException('This product code or return already exists. Please refresh and check.');
            }
            throw $e;
        }
    }

    private function saveProduct(array $input): array {
        $values = [
            inventoryText($input['name'] ?? '', 150, 'product name', true),
            inventoryText($input['sku'] ?? '', 60, 'product code') ?: null,
            inventoryText($input['category'] ?? '', 80, 'category'),
            inventoryText($input['unit'] ?? 'piece', 30, 'unit', true),
            inventoryMoney($input['selling_price'] ?? '0', 'Selling price'),
            inventoryInteger($input['low_stock_level'] ?? 5, 'Low stock alert', 0),
            inventoryInteger($input['is_active'] ?? 1, 'Product status', 0, 1)
        ];
        $id = inventoryInteger($input['id'] ?? 0, 'Product', 0, PHP_INT_MAX);
        if ($id) {
            $version = inventoryInteger($input['version'] ?? 0, 'Product version', 1, PHP_INT_MAX);
            $stmt = $this->query('UPDATE inventory_products SET name=?, sku=?, category=?, unit=?, selling_price_paise=?, low_stock_level=?, is_active=?, version=version+1 WHERE id=? AND version=?', [...$values, $id, $version]);
            if ($stmt->rowCount() !== 1) throw new InvalidArgumentException('This product changed while you were editing. Refresh and try again.');
        } else {
            $this->query('INSERT INTO inventory_products (name, sku, category, unit, selling_price_paise, low_stock_level, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)', $values);
            $id = (int)$this->pdo->lastInsertId();
        }
        return ['id' => $id, 'message' => 'Product saved. Use Add stock to record the quantity you have.'];
    }

    private function lockProduct(int $id): array {
        $product = $this->query('SELECT * FROM inventory_products WHERE id = ? FOR UPDATE', [$id])->fetch(PDO::FETCH_ASSOC);
        if (!$product) throw new InvalidArgumentException('A selected product no longer exists. Please refresh.');
        return $product;
    }

    private function updateStock(int $id, array $stock): void {
        $this->query('UPDATE inventory_products SET stock_quantity=?, stock_value_paise=?, version=version+1 WHERE id=?', [$stock['quantity'], $stock['value'], $id]);
    }

    private function addItem(int $documentId, array $product, int $quantity, int $delta, int $price, int $total, int $cost, int $after): void {
        $this->query('INSERT INTO inventory_document_items (document_id, product_id, product_name, unit, quantity, stock_delta, unit_price_paise, line_total_paise, line_cost_paise, stock_after) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [$documentId, $product['id'], $product['name'], $product['unit'], $quantity, $delta, $price, $total, $cost, $after]);
    }

    private function method(array $input): string {
        $method = $input['method'] ?? 'cash';
        if (!in_array($method, ['cash', 'online', 'bank'], true)) throw new InvalidArgumentException('Please select a payment method.');
        return $method;
    }

    private function recordPayment(int $saleId, int $amount, array $input, ?int $returnId = null): void {
        $this->query('INSERT INTO inventory_payments (document_id, return_document_id, amount_paise, method, reference, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [$saleId, $returnId, $amount, $this->method($input), inventoryText($input['reference'] ?? '', 100, 'payment reference'), $this->adminId, $this->postedAt]);
    }

    private function postDocument(string $kind, array $input): array {
        $rows = $input['items'] ?? [];
        if (!is_array($rows) || count($rows) < 1 || count($rows) > 50) throw new InvalidArgumentException('Add between 1 and 50 products.');
        $items = [];
        foreach ($rows as $row) {
            if (!is_array($row)) throw new InvalidArgumentException('Invalid product row.');
            $id = inventoryInteger($row['product_id'] ?? 0, 'Product', 1, PHP_INT_MAX);
            if (isset($items[$id])) throw new InvalidArgumentException('Each product should appear once. Increase its quantity instead.');
            $items[$id] = [
                'quantity' => inventoryInteger($row['quantity'] ?? 0, 'Quantity'),
                'price' => in_array($kind, ['gift', 'damage'], true) ? 0 : inventoryMoney($row['price'] ?? '', 'Price per item')
            ];
        }
        ksort($items, SORT_NUMERIC); // All stock transactions lock products in the same order.
        $studentId = null;
        $name = '';
        $class = '';
        if (in_array($kind, ['sale', 'gift'], true)) {
            $studentId = inventoryText($input['student_id'] ?? '', 50, 'student', true);
            $student = $this->query("SELECT s.name, c.class_name FROM students s LEFT JOIN classes c ON c.id=s.class_id WHERE s.student_id=? AND s.status IN ('Active', 'Alumni')", [$studentId])->fetch(PDO::FETCH_ASSOC);
            if (!$student) throw new InvalidArgumentException('Please select a valid student.');
            $name = $student['name'];
            $class = $student['class_name'] ?? '';
        }
        $supplier = inventoryText($input['supplier'] ?? '', 150, 'supplier', $kind === 'purchase');
        $note = inventoryText($input['note'] ?? '', 500, 'note', $kind === 'damage');
        $reference = inventoryText($input['reference'] ?? '', 100, 'reference');
        $this->query('INSERT INTO inventory_documents (kind, student_id, customer_name, class_name, supplier, reference, note, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [$kind, $studentId, $name, $class, $supplier, $reference, $note, $this->adminId, $this->postedAt]);
        $documentId = (int)$this->pdo->lastInsertId();
        $total = 0;
        $cost = 0;
        foreach ($items as $id => $item) {
            $product = $this->lockProduct($id);
            if (!(int)$product['is_active']) throw new InvalidArgumentException($product['name'] . ' is inactive. Activate it before using it.');
            $quantity = $item['quantity'];
            $lineTotal = inventoryBoundedTotal($item['price'] * $quantity);
            if ($kind === 'purchase') {
                $stock = inventoryStockReceive((int)$product['stock_quantity'], (int)$product['stock_value_paise'], $quantity, $lineTotal);
                $lineCost = $lineTotal;
            } else {
                if ($quantity > (int)$product['stock_quantity'] - (int)$product['reserved_quantity']) {
                    throw new InvalidArgumentException('Not enough available stock. Some items are reserved for parent store orders.');
                }
                $stock = inventoryStockIssue((int)$product['stock_quantity'], (int)$product['stock_value_paise'], $quantity);
                $lineCost = $stock['cost'];
                $cost = inventoryBoundedTotal($cost + $lineCost);
            }
            $total = inventoryBoundedTotal($total + $lineTotal);
            $this->updateStock($id, $stock);
            $this->addItem($documentId, $product, $quantity, $kind === 'purchase' ? $quantity : -$quantity, $item['price'], $lineTotal, $lineCost, $stock['quantity']);
        }
        $paid = $kind === 'purchase' ? $total : 0;
        if ($kind === 'sale') {
            $paid = inventoryMoney($input['paid'] ?? '0', 'Amount received');
            if ($paid > $total) throw new InvalidArgumentException('Amount received cannot exceed the bill total.');
            if ($paid > 0) $this->recordPayment($documentId, $paid, $input);
        }
        $this->query('UPDATE inventory_documents SET total_paise=?, cost_paise=?, paid_paise=? WHERE id=?', [$total, $cost, $paid, $documentId]);
        if ($kind === 'sale' && ($input['settle_remaining'] ?? false) === true) {
            $waived = $total - $paid;
            if ($waived <= 0) throw new InvalidArgumentException('There is no remaining balance to waive.');
            $this->recordWaiver($documentId, $waived, inventoryText($input['settlement_reason'] ?? '', 500, 'settlement reason', true));
        }
        return ['id' => $documentId, 'message' => match ($kind) {
            'purchase' => 'Stock added. Your quantities and purchase costs are updated.',
            'gift' => 'Free distribution recorded. Stock and its cost are updated.',
            'damage' => 'Stock loss recorded.',
            default => ($input['settle_remaining'] ?? false) === true ? 'Sale settled. Actual payment and waived balance recorded separately.' : ($paid < $total ? 'Sale saved. The unpaid amount is in Sales & dues.' : 'Sale saved and payment recorded.')
        }];
    }

    private function lockSale(array $input): array {
        $id = inventoryInteger($input['document_id'] ?? 0, 'Sale', 1, PHP_INT_MAX);
        $sale = $this->query("SELECT * FROM inventory_documents WHERE id=? AND kind='sale' FOR UPDATE", [$id])->fetch(PDO::FETCH_ASSOC);
        if (!$sale || $sale['status'] !== 'posted') throw new InvalidArgumentException('This sale is unavailable or has already been returned.');
        return $sale;
    }

    private function collect(array $input): array {
        $sale = $this->lockSale($input);
        $amount = inventoryPaymentAmount(inventoryMoney($input['amount'] ?? '', 'Amount received'), inventoryBalance((int)$sale['total_paise'], (int)$sale['paid_paise'], $sale['status'], (int)$sale['waived_paise']));
        $this->recordPayment((int)$sale['id'], $amount, $input);
        $this->query('UPDATE inventory_documents SET paid_paise=paid_paise+? WHERE id=?', [$amount, $sale['id']]);
        return ['id' => (int)$sale['id'], 'message' => 'Payment received. The balance due has been updated.'];
    }

    private function recordWaiver(int $saleId, int $amount, string $reason, ?int $returnId = null): void {
        $this->query('INSERT INTO inventory_bill_adjustments (document_id, return_document_id, amount_paise, reason, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?)',
            [$saleId, $returnId, $amount, $reason, $this->adminId, $this->postedAt]);
        $this->query('UPDATE inventory_documents SET waived_paise=waived_paise+? WHERE id=?', [$amount, $returnId ?? $saleId]);
    }

    private function settle(array $input): array {
        $sale = $this->lockSale($input);
        // Razorpay Store orders are paid in full and must never be settled offline.
        if ($this->query("SELECT id FROM inventory_orders WHERE document_id=? AND payment_method='online'", [$sale['id']])->fetchColumn()) {
            throw new InvalidArgumentException('Online Store payments cannot be settled at the school counter.');
        }
        $balance = inventoryBalance((int)$sale['total_paise'], (int)$sale['paid_paise'], $sale['status'], (int)$sale['waived_paise']);
        $amount = inventoryMoney($input['amount'] ?? '0', 'Amount received');
        if ($balance <= 0 || $amount >= $balance) throw new InvalidArgumentException('Enter less than the balance due to waive the remainder; use Collect due for full payment.');
        $reason = inventoryText($input['settlement_reason'] ?? '', 500, 'settlement reason', true);
        if ($amount > 0) {
            $this->recordPayment((int)$sale['id'], $amount, $input);
            $this->query('UPDATE inventory_documents SET paid_paise=paid_paise+? WHERE id=?', [$amount, $sale['id']]);
        }
        $this->recordWaiver((int)$sale['id'], $balance - $amount, $reason);
        return ['id'=>(int)$sale['id'], 'message'=>'Bill settled. Actual payment and waived balance recorded separately.'];
    }

    private function returnSale(array $input): array {
        $sale = $this->lockSale($input);
        $note = inventoryText($input['note'] ?? '', 500, 'return reason', true);
        $this->query("INSERT INTO inventory_documents (kind, student_id, customer_name, class_name, note, total_paise, cost_paise, paid_paise, original_document_id, created_by, created_at) VALUES ('return', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [$sale['student_id'], $sale['customer_name'], $sale['class_name'], $note, -(int)$sale['total_paise'], -(int)$sale['cost_paise'], -(int)$sale['paid_paise'], $sale['id'], $this->adminId, $this->postedAt]);
        $returnId = (int)$this->pdo->lastInsertId();
        if ((int)$sale['waived_paise'] > 0) $this->recordWaiver((int)$sale['id'], -(int)$sale['waived_paise'], 'Full return: reverse previous settlement', $returnId);
        $items = $this->query('SELECT * FROM inventory_document_items WHERE document_id=? ORDER BY product_id', [$sale['id']])->fetchAll(PDO::FETCH_ASSOC);
        foreach ($items as $item) {
            $product = $this->lockProduct((int)$item['product_id']);
            $stock = inventoryStockReceive((int)$product['stock_quantity'], (int)$product['stock_value_paise'], (int)$item['quantity'], (int)$item['line_cost_paise']);
            $this->updateStock((int)$product['id'], $stock);
            // Preserve the original receipt's name and cost, even if the product was edited.
            $product['name'] = $item['product_name'];
            $product['unit'] = $item['unit'];
            $this->addItem($returnId, $product, (int)$item['quantity'], (int)$item['quantity'], (int)$item['unit_price_paise'], (int)$item['line_total_paise'], (int)$item['line_cost_paise'], $stock['quantity']);
        }
        if ((int)$sale['paid_paise'] > 0) $this->recordPayment((int)$sale['id'], -(int)$sale['paid_paise'], $input, $returnId);
        $this->query("UPDATE inventory_documents SET status='returned' WHERE id=?", [$sale['id']]);
        return ['id' => $returnId, 'message' => 'Full return recorded. Stock is restored, the due is cleared and the refund is recorded.'];
    }

    public function products(array $input): array {
        $search = '%' . inventoryText($input['search'] ?? '', 100, 'search') . '%';
        $page = inventoryInteger($input['page'] ?? 1, 'Page', 1, 100000);
        $where = '(name LIKE ? OR sku LIKE ? OR category LIKE ?)';
        $status = $input['status'] ?? 'active';
        if ($status === 'active') $where .= ' AND is_active=1';
        elseif ($status === 'inactive') $where .= ' AND is_active=0';
        elseif ($status !== 'all') throw new InvalidArgumentException('Invalid product status.');
        if (($input['low'] ?? '') === '1') $where .= ' AND stock_quantity <= low_stock_level';
        $params = [$search, $search, $search];
        $total = (int)$this->query("SELECT COUNT(*) FROM inventory_products WHERE $where", $params)->fetchColumn();
        $rows = $this->query("SELECT * FROM inventory_products WHERE $where ORDER BY name, id LIMIT 30 OFFSET " . (($page - 1) * 30), $params)->fetchAll(PDO::FETCH_ASSOC);
        $overview = $this->query('SELECT COALESCE(SUM(is_active=1),0) AS products, COALESCE(SUM(stock_quantity),0) AS units, COALESCE(SUM(is_active=1 AND stock_quantity <= low_stock_level),0) AS low FROM inventory_products')->fetch(PDO::FETCH_ASSOC);
        return ['rows' => $rows, 'total' => $total, 'page' => $page, 'overview' => $overview];
    }

    public function students(string $search): array {
        $search = inventoryText($search, 80, 'student search');
        if (mb_strlen($search) < 2) return [];
        $like = '%' . $search . '%';
        // Match the same student fields as the student management list.
        return $this->query("SELECT s.student_id, s.name, s.roll_no, s.student_image, s.father_name, s.mother_name,
                c.class_name, sec.section_name
            FROM students s
            LEFT JOIN classes c ON c.id=s.class_id
            LEFT JOIN sections sec ON sec.id=s.section_id
            WHERE s.status IN ('Active','Alumni') AND (
                s.student_id LIKE ? OR s.name LIKE ? OR s.father_name LIKE ? OR s.mother_name LIKE ?
                OR s.registration_no LIKE ? OR s.phone_number LIKE ? OR s.alternate_phone_number LIKE ? OR s.address LIKE ?)
            ORDER BY s.name LIMIT 20", array_fill(0, 8, $like))->fetchAll(PDO::FETCH_ASSOC);
    }

    public function documents(array $input): array {
        $page = inventoryInteger($input['page'] ?? 1, 'Page', 1, 100000);
        $search = '%' . inventoryText($input['search'] ?? '', 100, 'search') . '%';
        $where = '(customer_name LIKE ? OR student_id LIKE ? OR supplier LIKE ? OR CAST(id AS CHAR) LIKE ?)';
        $params = [$search, $search, $search, $search];
        $group = $input['group'] ?? 'sales';
        $where .= $group === 'purchases' ? " AND kind='purchase'" : " AND kind IN ('sale','gift','damage','return')";
        if (($input['due'] ?? '') === '1') $where .= " AND kind='sale' AND status='posted' AND total_paise>paid_paise+waived_paise";
        if (!empty($input['from']) || !empty($input['to'])) {
            [$from, $to] = inventoryDateRange($input);
            $where .= ' AND created_at>=? AND created_at<?';
            $params[] = $from;
            $params[] = $to;
        }
        $total = (int)$this->query("SELECT COUNT(*) FROM inventory_documents WHERE $where", $params)->fetchColumn();
        $rows = $this->query("SELECT * FROM inventory_documents WHERE $where ORDER BY id DESC LIMIT 30 OFFSET " . (($page - 1) * 30), $params)->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as &$row) $row['due_paise'] = $row['kind'] === 'sale' ? inventoryBalance((int)$row['total_paise'], (int)$row['paid_paise'], $row['status'], (int)$row['waived_paise']) : 0;
        return ['rows' => $rows, 'total' => $total, 'page' => $page];
    }

    public function detail(int $id): array {
        $doc = $this->query('SELECT d.*, u.full_name AS admin_name FROM inventory_documents d LEFT JOIN users u ON u.id=d.created_by WHERE d.id=?', [$id])->fetch(PDO::FETCH_ASSOC);
        if (!$doc) throw new InvalidArgumentException('Entry not found.');
        $doc['items'] = $this->query('SELECT * FROM inventory_document_items WHERE document_id=? ORDER BY id', [$id])->fetchAll(PDO::FETCH_ASSOC);
        $doc['payments'] = $this->query('SELECT p.*, u.full_name AS admin_name FROM inventory_payments p LEFT JOIN users u ON u.id=p.created_by WHERE p.document_id=? ORDER BY p.id', [$doc['original_document_id'] ?: $id])->fetchAll(PDO::FETCH_ASSOC);
        $doc['due_paise'] = $doc['kind'] === 'sale' ? inventoryBalance((int)$doc['total_paise'], (int)$doc['paid_paise'], $doc['status'], (int)$doc['waived_paise']) : 0;
        $doc['adjustments'] = $this->query('SELECT a.*, u.full_name AS admin_name FROM inventory_bill_adjustments a LEFT JOIN users u ON u.id=a.created_by WHERE a.document_id=? ORDER BY a.id', [$doc['original_document_id'] ?: $id])->fetchAll(PDO::FETCH_ASSOC);
        return $doc;
    }

    public function movements(array $input): array {
        $id = inventoryInteger($input['product_id'] ?? 0, 'Product', 1, PHP_INT_MAX);
        $page = inventoryInteger($input['page'] ?? 1, 'Page', 1, 100000);
        $total = (int)$this->query('SELECT COUNT(*) FROM inventory_document_items WHERE product_id=?', [$id])->fetchColumn();
        $rows = $this->query('SELECT i.stock_delta, i.stock_after, i.document_id, d.kind, d.created_at, d.customer_name, d.supplier, d.note FROM inventory_document_items i JOIN inventory_documents d ON d.id=i.document_id WHERE i.product_id=? ORDER BY i.id DESC LIMIT 30 OFFSET ' . (($page - 1) * 30), [$id])->fetchAll(PDO::FETCH_ASSOC);
        return ['rows' => $rows, 'total' => $total, 'page' => $page];
    }

    // Shared by the dashboard and detailed report, without loading product rows.
    public function profitAndLossSummary(array $input): array {
        [$from, $to] = inventoryDateRange($input);
        // Original sales remain in their original period; returns reverse them on the return date.
        $summary = $this->query("SELECT
            COALESCE(SUM(CASE WHEN kind IN ('sale','return') THEN total_paise ELSE 0 END),0) AS sales_paise,
            COALESCE(SUM(CASE WHEN kind IN ('sale','return') THEN cost_paise ELSE 0 END),0) AS sold_cost_paise,
            COALESCE(SUM(CASE WHEN kind='gift' THEN cost_paise ELSE 0 END),0) AS gifts_paise,
            COALESCE(SUM(CASE WHEN kind='damage' THEN cost_paise ELSE 0 END),0) AS loss_paise,
            COALESCE(SUM(CASE WHEN kind='purchase' THEN total_paise ELSE 0 END),0) AS purchases_paise
            FROM inventory_documents WHERE created_at>=? AND created_at<?", [$from, $to])->fetch(PDO::FETCH_ASSOC);
        $summary['gross_sales_paise'] = (int)$summary['sales_paise'];
        $summary['waived_paise'] = (int)$this->query('SELECT COALESCE(SUM(amount_paise),0) FROM inventory_bill_adjustments WHERE created_at>=? AND created_at<?', [$from, $to])->fetchColumn();
        $summary['sales_paise'] = $summary['gross_sales_paise'] - $summary['waived_paise'];
        $summary['profit_paise'] = (int)$summary['sales_paise'] - (int)$summary['sold_cost_paise'] - (int)$summary['gifts_paise'] - (int)$summary['loss_paise'];
        return $summary;
    }

    public function report(array $input): array {
        [$from, $to] = inventoryDateRange($input);
        $summary = $this->profitAndLossSummary($input);
        // Online store advances/refunds are counted at provider confirmation, not again at handover.
        $summary['received_paise'] = (int)$this->query("SELECT COALESCE(SUM(p.amount_paise),0) FROM inventory_payments p WHERE p.created_at>=? AND p.created_at<? AND (NOT EXISTS (SELECT 1 FROM inventory_orders o WHERE o.document_id=p.document_id AND o.payment_method='online') OR (p.amount_paise<0 AND p.method<>'online'))", [$from, $to])->fetchColumn();
        $summary['received_paise'] += (int)$this->query('SELECT COALESCE(SUM(amount_paise),0) FROM inventory_order_payment_events WHERE created_at>=? AND created_at<?', [$from, $to])->fetchColumn();
        $summary['store_advance_paise'] = (int)$this->query("SELECT COALESCE(SUM(e.amount_paise),0) FROM inventory_order_payment_events e JOIN inventory_orders o ON o.id=e.order_id WHERE o.order_status<>'delivered'", [])->fetchColumn();
        $summary['cash_flow_paise'] = $summary['received_paise'] - (int)$summary['purchases_paise'];
        $summary['stock_value_paise'] = (int)$this->query('SELECT COALESCE(SUM(stock_value_paise),0) FROM inventory_products')->fetchColumn();
        $summary['due_paise'] = (int)$this->query("SELECT COALESCE(SUM(total_paise-paid_paise-waived_paise),0) FROM inventory_documents WHERE kind='sale' AND status='posted'")->fetchColumn();
        $rows = $this->query("SELECT i.product_id, i.product_name,
            SUM(CASE WHEN d.kind='sale' THEN i.quantity WHEN d.kind='return' THEN -i.quantity ELSE 0 END) AS sold_quantity,
            SUM(CASE WHEN d.kind='sale' THEN i.line_total_paise WHEN d.kind='return' THEN -i.line_total_paise ELSE 0 END) AS sales_paise,
            SUM(CASE WHEN d.kind='return' THEN -i.line_cost_paise ELSE i.line_cost_paise END) AS cost_paise
            FROM inventory_document_items i JOIN inventory_documents d ON d.id=i.document_id
            WHERE d.kind IN ('sale','return','gift','damage') AND d.created_at>=? AND d.created_at<?
            GROUP BY i.product_id, i.product_name ORDER BY sales_paise DESC, i.product_name", [$from, $to])->fetchAll(PDO::FETCH_ASSOC);
        return ['summary' => $summary, 'rows' => $rows, 'from' => substr($from, 0, 10), 'to' => (new DateTimeImmutable($to))->modify('-1 day')->format('Y-m-d')];
    }
}
