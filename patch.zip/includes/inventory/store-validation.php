<?php
require_once __DIR__ . '/inventory-math.php';
require_once __DIR__ . '/../financial/payment-charges.php';

function storeOrderTotals(int $subtotal, string $method, array $config): array {
    if (!in_array($method, ['online', 'pay_at_school'], true)) throw new InvalidArgumentException('Choose a payment method.');
    if ($subtotal <= 0) throw new InvalidArgumentException('The selected products do not have a store price yet. Please contact the school.');
    $charges = $method === 'online'
        ? schoolPaymentCharges($subtotal, $config['razorpay_charge_percentage'] ?? 0, $config['gst_on_razorpay_charge'] ?? 0)
        : ['gateway_charge_paise'=>0, 'gst_paise'=>0, 'total_paise'=>$subtotal, 'gateway_percentage'=>0, 'gst_percentage'=>0];
    if ($charges['total_paise'] > 9999999999) throw new InvalidArgumentException('Please split this order into smaller orders.');
    return ['subtotal_paise'=>$subtotal] + $charges;
}

function storeSavedTotals(array $order): array {
    // NULL subtotal identifies an order created before charge support: keep its original amount.
    $fields = ['subtotal_paise'=>(int)($order['subtotal_paise'] ?? $order['total_paise']),
        'gateway_charge_paise'=>(int)($order['gateway_charge_paise'] ?? 0), 'gst_paise'=>(int)($order['gst_paise'] ?? 0),
        'gateway_percentage'=>(float)($order['gateway_percentage'] ?? 0), 'gst_percentage'=>(float)($order['gst_percentage'] ?? 0)];
    foreach (['subtotal', 'gateway_charge', 'gst'] as $field) $fields[$field . '_amount'] = number_format($fields[$field . '_paise']/100, 2, '.', '');
    return $fields;
}

function storeItems(mixed $rows): array {
    if (!is_array($rows) || count($rows) < 1 || count($rows) > 30) {
        throw new InvalidArgumentException('Select between 1 and 30 different products.');
    }
    $items = [];
    foreach ($rows as $row) {
        if (!is_array($row)) throw new InvalidArgumentException('Invalid product row.');
        $id = inventoryInteger($row['product_id'] ?? 0, 'Product', 1, PHP_INT_MAX);
        if (isset($items[$id])) throw new InvalidArgumentException('Each product must appear once. Increase its quantity instead.');
        $items[$id] = inventoryInteger($row['quantity'] ?? 0, 'Quantity', 1, 1000);
    }
    ksort($items, SORT_NUMERIC);
    return $items;
}

function storeRequestKey(mixed $key): string {
    if (!is_string($key) || !preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/iD', $key)) {
        throw new InvalidArgumentException('Please reopen your cart and try again.');
    }
    return strtolower($key);
}

function storePaymentMatches(array $order, array $payment): bool {
    return $order['payment_method'] === 'online'
        && !empty($order['razorpay_order_id'])
        && ($payment['order_id'] ?? '') === $order['razorpay_order_id']
        && preg_match('/^pay_[a-zA-Z0-9]+$/D', (string)($payment['id'] ?? ''))
        && (string)($payment['amount'] ?? '') === (string)$order['total_paise']
        && ($payment['currency'] ?? '') === 'INR';
}

function storePaymentState(array $payment): ?string {
    if (($payment['status'] ?? '') === 'refunded' && (int)($payment['amount_refunded'] ?? 0) === (int)$payment['amount']) return 'refunded';
    if (($payment['status'] ?? '') !== 'captured') return null;
    if ((int)($payment['amount_refunded'] ?? 0) > 0 || !empty($payment['refund_status'])) return 'refund_pending';
    return 'paid';
}
