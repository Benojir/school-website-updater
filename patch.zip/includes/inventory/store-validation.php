<?php
require_once __DIR__ . '/inventory-math.php';

function storeItems(mixed $rows): array {
    if (!is_array($rows) || count($rows) < 1 || count($rows) > 30) {
        throw new InvalidArgumentException('Select between 1 and 30 different products.');
    }
    $items = [];
    foreach ($rows as $row) {
        if (!is_array($row)) throw new InvalidArgumentException('Invalid product row.');
        $id = inventoryInteger($row['product_id'] ?? 0, 'Product', 1, PHP_INT_MAX);
        if (isset($items[$id])) throw new InvalidArgumentException('Each product must appear once. Increase its quantity instead.');
        $items[$id] = inventoryInteger($row['quantity'] ?? 0, 'Quantity', 1, 1000);
    }
    ksort($items, SORT_NUMERIC);
    return $items;
}

function storeRequestKey(mixed $key): string {
    if (!is_string($key) || !preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/iD', $key)) {
        throw new InvalidArgumentException('Please reopen your cart and try again.');
    }
    return strtolower($key);
}

function storePaymentMatches(array $order, array $payment): bool {
    return $order['payment_method'] === 'online'
        && !empty($order['razorpay_order_id'])
        && ($payment['order_id'] ?? '') === $order['razorpay_order_id']
        && preg_match('/^pay_[a-zA-Z0-9]+$/D', (string)($payment['id'] ?? ''))
        && (string)($payment['amount'] ?? '') === (string)$order['total_paise']
        && ($payment['currency'] ?? '') === 'INR';
}

function storePaymentState(array $payment): ?string {
    if (($payment['status'] ?? '') === 'refunded' && (int)($payment['amount_refunded'] ?? 0) === (int)$payment['amount']) return 'refunded';
    if (($payment['status'] ?? '') !== 'captured') return null;
    if ((int)($payment['amount_refunded'] ?? 0) > 0 || !empty($payment['refund_status'])) return 'refund_pending';
    return 'paid';
}
