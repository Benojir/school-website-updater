<?php
require_once __DIR__ . '/inventory-service.php';
require_once __DIR__ . '/store-validation.php';
require_once __DIR__ . '/store-gateway.php';

class InventoryOrderService {
    public function __construct(private PDO $pdo, private ?int $adminId = null, private ?StoreGateway $gateway = null) {}

    private function query(string $sql, array $params = []): PDOStatement {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public function getStoreProducts(array $input = []): array {
        $search = inventoryText($input['search'] ?? '', 100, 'search');
        $category = inventoryText($input['category'] ?? '', 80, 'category');
        $where = 'is_active=1';
        $params = [];
        if ($search !== '') {
            $where .= ' AND (name LIKE ? OR sku LIKE ? OR category LIKE ?)';
            $params = array_fill(0, 3, '%' . $search . '%');
        }
        if ($category !== '' && $category !== 'all') { $where .= ' AND category=?'; $params[] = $category; }
        $rows = $this->query("SELECT id, name, sku, category, unit, selling_price_paise,
            GREATEST(0, stock_quantity-reserved_quantity) AS stock_quantity FROM inventory_products
            WHERE $where ORDER BY category, name", $params)->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as &$row) {
            foreach (['id', 'selling_price_paise', 'stock_quantity'] as $field) $row[$field] = (int)$row[$field];
            $row['selling_price'] = number_format($row['selling_price_paise'] / 100, 2, '.', '');
        }
        unset($row);
        $categories = $this->query("SELECT DISTINCT category FROM inventory_products WHERE is_active=1 AND category<>'' ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);
        return ['products' => $rows, 'categories' => $categories];
    }

    private function response(array $order): array {
        return [
            'order_id' => (int)$order['id'], 'order_number' => $order['order_number'],
            'total_paise' => (int)$order['total_paise'], 'total_amount' => number_format($order['total_paise'] / 100, 2, '.', ''),
            'payment_method' => $order['payment_method'], 'payment_status' => $order['payment_status'],
            'order_status' => $order['order_status'], 'razorpay_order_id' => $order['razorpay_order_id'],
            'razorpay_key_id' => $order['payment_method'] === 'online' ? ($this->gateway?->keyId() ?? '') : '',
            'currency' => 'INR', 'message' => 'Order saved. View My Orders for the latest status.'
        ];
    }

    private function retry(array $order, string $hash): array {
        if (!hash_equals($order['payload_hash'], $hash)) throw new InvalidArgumentException('This request was used for a different cart. Reopen the cart.');
        return $this->response($order);
    }

    public function createOrder(string $studentId, string $phone, mixed $rows, string $method, string $note, string $requestKey, int $expectedTotal): array {
        if (!in_array($method, ['online', 'pay_at_school'], true)) throw new InvalidArgumentException('Choose a payment method.');
        $studentId = inventoryText($studentId, 50, 'student ID', true);
        $note = inventoryText($note, 500, 'note');
        $items = storeItems($rows);
        $key = storeRequestKey($requestKey);
        $hash = hash('sha256', json_encode([$studentId, $items, $method, $note, $expectedTotal], JSON_THROW_ON_ERROR));
        $previous = $this->query('SELECT * FROM inventory_orders WHERE parent_phone=? AND request_key=?', [$phone, $key])->fetch(PDO::FETCH_ASSOC);
        if ($previous) return $this->retry($previous, $hash);
        if ($method === 'online' && !$this->gateway) throw new InvalidArgumentException('Online payment is currently unavailable. Choose Pay at School.');
        $this->pdo->beginTransaction();
        try {
            // Serializes new orders for one child, and validates ownership independently of client data.
            $student = $this->query("SELECT id FROM students WHERE student_id=? AND (phone_number=? OR alternate_phone_number=?) AND status='Active' FOR UPDATE", [$studentId, $phone, $phone])->fetch(PDO::FETCH_ASSOC);
            if (!$student) throw new InvalidArgumentException('You can only order for your own active child.');
            $previous = $this->query('SELECT * FROM inventory_orders WHERE parent_phone=? AND request_key=?', [$phone, $key])->fetch(PDO::FETCH_ASSOC);
            if ($previous) { $this->pdo->commit(); return $this->retry($previous, $hash); }
            $open = (int)$this->query("SELECT COUNT(*) FROM inventory_orders WHERE student_id=? AND order_status NOT IN ('delivered','cancelled')", [$studentId])->fetchColumn();
            if ($open >= 10) throw new InvalidArgumentException('There are already 10 open orders for this child. Please contact the school before placing more.');
            $number = 'ORD-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(6)));
            $this->query("INSERT INTO inventory_orders (order_number, student_id, parent_phone, payment_method, note, request_key, payload_hash, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", [$number, $studentId, $phone, $method, $note, $key, $hash, date('Y-m-d H:i:s')]);
            $id = (int)$this->pdo->lastInsertId();
            $total = 0;
            foreach ($items as $productId => $quantity) {
                $p = $this->query('SELECT * FROM inventory_products WHERE id=? FOR UPDATE', [$productId])->fetch(PDO::FETCH_ASSOC);
                if (!$p || !(int)$p['is_active']) throw new InvalidArgumentException('A selected product is no longer available. Refresh the store.');
                $available = (int)$p['stock_quantity'] - (int)$p['reserved_quantity'];
                if ($available < $quantity) throw new InvalidArgumentException("Only $available {$p['unit']} of {$p['name']} are available. Refresh your cart.");
                $line = inventoryBoundedTotal((int)$p['selling_price_paise'] * $quantity);
                $total = inventoryBoundedTotal($total + $line);
                $this->query('INSERT INTO inventory_order_items (order_id, product_id, product_name, unit, quantity, unit_price_paise, line_total_paise) VALUES (?, ?, ?, ?, ?, ?, ?)', [$id, $productId, $p['name'], $p['unit'], $quantity, $p['selling_price_paise'], $line]);
                $this->query('UPDATE inventory_products SET reserved_quantity=reserved_quantity+?, version=version+1 WHERE id=?', [$quantity, $productId]);
            }
            // Existing inventory sale validation supports amounts up to 99,999,999.99.
            if ($total <= 0) throw new InvalidArgumentException('The selected products do not have a store price yet. Please contact the school.');
            if ($total > 9999999999) throw new InvalidArgumentException('Please split this order into smaller orders.');
            if ($total !== $expectedTotal) throw new InvalidArgumentException('Product prices have changed. Refresh the store and review the new total before ordering.');
            $gatewayId = $method === 'online' ? $this->gateway->createOrder($number, $total) : null;
            $this->query('UPDATE inventory_orders SET total_paise=?, razorpay_order_id=? WHERE id=?', [$total, $gatewayId, $id]);
            $order = $this->query('SELECT * FROM inventory_orders WHERE id=?', [$id])->fetch(PDO::FETCH_ASSOC);
            $this->pdo->commit();
            return $this->response($order);
        } catch (Throwable $e) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            if ($e instanceof PDOException && ($e->errorInfo[1] ?? null) == 1062) {
                $previous = $this->query('SELECT * FROM inventory_orders WHERE parent_phone=? AND request_key=?', [$phone, $key])->fetch(PDO::FETCH_ASSOC);
                if ($previous) return $this->retry($previous, $hash);
            }
            throw $e;
        }
    }

    public function parentOrder(string $number, string $phone): array {
        // Payment operations belong only to the parent who placed the order.
        $order = $this->query('SELECT * FROM inventory_orders WHERE order_number=? AND parent_phone=?', [$number, $phone])->fetch(PDO::FETCH_ASSOC);
        if (!$order) throw new InvalidArgumentException('Order not found for this account.');
        return $order;
    }

    public function verifyRazorpayPayment(string $number, string $phone, string $gatewayId, string $paymentId, string $signature): array {
        $order = $this->parentOrder($number, $phone);
        if (!$this->gateway || $order['payment_method'] !== 'online' || !$order['razorpay_order_id'] || !hash_equals($order['razorpay_order_id'], $gatewayId)) {
            throw new InvalidArgumentException('Payment does not belong to this order.');
        }
        $expected = hash_hmac('sha256', $order['razorpay_order_id'] . '|' . $paymentId, $this->gateway->secret());
        if (!hash_equals($expected, $signature)) throw new InvalidArgumentException('Payment signature could not be verified. Check payment from My Orders.');
        $payment = $this->gateway->payment($paymentId);
        if (!storePaymentMatches($order, $payment) || storePaymentState($payment) === null) {
            throw new InvalidArgumentException('Payment is awaiting confirmation. Check payment from My Orders; do not pay again if money was deducted.');
        }
        $this->applyProviderPayment($payment);
        return $this->response($this->parentOrder($number, $phone));
    }

    // Used by signature-verified webhooks and server-to-server reconciliation.
    public function applyProviderPayment(array $payment): bool {
        $this->pdo->beginTransaction();
        try {
            $order = $this->query('SELECT * FROM inventory_orders WHERE razorpay_order_id=? FOR UPDATE', [$payment['order_id'] ?? ''])->fetch(PDO::FETCH_ASSOC);
            if (!$order) { $this->pdo->commit(); return false; }
            if (!storePaymentMatches($order, $payment)) throw new InvalidArgumentException('Payment amount, currency or order does not match.');
            $state = storePaymentState($payment);
            if ($state !== null) {
                if ($order['razorpay_payment_id'] && $order['razorpay_payment_id'] !== $payment['id']) throw new InvalidArgumentException('A different payment is already linked to this order.');
                $paidAt = isset($payment['created_at']) ? date('Y-m-d H:i:s', (int)$payment['created_at']) : $order['created_at'];
                $this->query('INSERT IGNORE INTO inventory_order_payment_events (order_id, event_key, amount_paise, created_at) VALUES (?, ?, ?, ?)', [$order['id'], 'capture:' . $payment['id'], $order['total_paise'], $paidAt]);
                $refunded = min((int)$order['total_paise'], max(0, (int)($payment['amount_refunded'] ?? 0)));
                $previousRefund = (int)$order['refunded_paise'];
                if ($refunded > $previousRefund) {
                    $this->query('INSERT INTO inventory_order_payment_events (order_id, event_key, amount_paise, created_at) VALUES (?, ?, ?, ?)', [$order['id'], 'refund:' . $payment['id'] . ':' . $refunded, $previousRefund - $refunded, date('Y-m-d H:i:s')]);
                    $this->query('UPDATE inventory_orders SET refunded_paise=? WHERE id=?', [$refunded, $order['id']]);
                }
                if ($order['payment_status'] === 'refunded' && $state !== 'refunded') { $this->pdo->commit(); return true; }
                if ($order['payment_status'] === 'refund_pending' && $state === 'paid') $state = 'refund_pending';
                $status = $order['order_status'];
                if ($state === 'paid' && $status === 'placed') $status = 'confirmed';
                if ($state === 'paid' && $status === 'cancelled') $state = 'refund_pending';
                if ($state === 'refunded' && !in_array($status, ['cancelled', 'delivered'], true)) {
                    $this->releaseReservation((int)$order['id']);
                    $status = 'cancelled';
                }
                $this->query('UPDATE inventory_orders SET payment_status=?, order_status=?, razorpay_payment_id=? WHERE id=?', [$state, $status, $payment['id'], $order['id']]);
            }
            $this->pdo->commit();
            return true;
        } catch (Throwable $e) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            throw $e;
        }
    }

    public function reconcile(array $order): array {
        if ($order['payment_method'] === 'online' && $order['razorpay_order_id']) {
            if (!$this->gateway) throw new RuntimeException('Payment confirmation is temporarily unavailable.');
            foreach ($this->gateway->payments($order['razorpay_order_id']) as $payment) {
                if (storePaymentState($payment) !== null) $this->applyProviderPayment($payment);
            }
        }
        return $this->query('SELECT * FROM inventory_orders WHERE id=?', [$order['id']])->fetch(PDO::FETCH_ASSOC);
    }

    public function resumePayment(string $number, string $phone, bool $allowOnline): array {
        $order = $this->reconcile($this->parentOrder($number, $phone));
        if ($order['payment_status'] === 'paid') return $this->response($order);
        if (!$allowOnline || $order['payment_method'] !== 'online' || !in_array($order['order_status'], ['placed','confirmed','ready_for_pickup'], true)
            || !in_array($order['payment_status'], ['pending','failed'], true)) throw new InvalidArgumentException('Online payment cannot be started for this order. Please contact the school.');
        return $this->response($order);
    }

    private function releaseReservation(int $orderId): void {
        $items = $this->query('SELECT * FROM inventory_order_items WHERE order_id=? ORDER BY product_id', [$orderId])->fetchAll(PDO::FETCH_ASSOC);
        foreach ($items as $item) {
            $p = $this->query('SELECT * FROM inventory_products WHERE id=? FOR UPDATE', [$item['product_id']])->fetch(PDO::FETCH_ASSOC);
            if (!$p || (int)$p['reserved_quantity'] < (int)$item['quantity']) throw new RuntimeException('Stock reservation is inconsistent. Please contact the school owner.');
            $this->query('UPDATE inventory_products SET reserved_quantity=reserved_quantity-?, version=version+1 WHERE id=?', [$item['quantity'], $item['product_id']]);
        }
    }

    public function getParentOrders(string $phone): array {
        $orders = $this->query("SELECT o.*, s.name AS student_name, c.class_name, sec.section_name,
                d.paid_paise AS bill_paid_paise, d.waived_paise AS bill_waived_paise, d.status AS bill_status
            FROM inventory_orders o LEFT JOIN students s ON s.student_id COLLATE utf8mb4_unicode_ci=o.student_id COLLATE utf8mb4_unicode_ci
            LEFT JOIN classes c ON c.id=s.class_id LEFT JOIN sections sec ON sec.id=s.section_id
            LEFT JOIN inventory_documents d ON d.id=o.document_id WHERE o.parent_phone=? ORDER BY o.id DESC LIMIT 100", [$phone])->fetchAll(PDO::FETCH_ASSOC);
        $itemsByOrder = [];
        if ($orders) {
            $ids = array_column($orders, 'id');
            $marks = implode(',', array_fill(0, count($ids), '?'));
            $items = $this->formatItems($this->query("SELECT * FROM inventory_order_items WHERE order_id IN ($marks) ORDER BY order_id, product_id", $ids)->fetchAll(PDO::FETCH_ASSOC));
            foreach ($items as $item) $itemsByOrder[$item['order_id']][] = $item;
        }
        foreach ($orders as &$order) {
            $order = $this->displayOrder($order);
            $order['items'] = $itemsByOrder[$order['id']] ?? [];
            // No phone, request hash or provider credentials in the history response.
            unset($order['parent_phone'], $order['request_key'], $order['payload_hash'], $order['bill_paid_paise'], $order['bill_waived_paise']);
        }
        unset($order);
        return $orders;
    }

    private function items(int $id): array {
        return $this->formatItems($this->query('SELECT oi.*, p.stock_quantity AS current_stock FROM inventory_order_items oi LEFT JOIN inventory_products p ON p.id=oi.product_id WHERE oi.order_id=? ORDER BY oi.product_id', [$id])->fetchAll(PDO::FETCH_ASSOC));
    }

    private function formatItems(array $items): array {
        foreach ($items as &$item) {
            foreach (['product_id','quantity','unit_price_paise','line_total_paise','current_stock'] as $f) $item[$f] = (int)($item[$f] ?? 0);
            $item['unit_price'] = number_format($item['unit_price_paise']/100, 2, '.', '');
            $item['line_total'] = number_format($item['line_total_paise']/100, 2, '.', '');
        }
        return $items;
    }

    private function displayOrder(array $order): array {
        $order['paid_paise'] = (int)($order['bill_paid_paise'] ?? ($order['payment_status'] === 'paid' ? $order['total_paise'] : 0));
        $order['waived_paise'] = (int)($order['bill_waived_paise'] ?? 0);
        if ($order['payment_method'] === 'pay_at_school' && $order['document_id']) {
            $order['payment_status'] = ($order['bill_status'] ?? '') === 'returned' ? 'refunded'
                : ($order['paid_paise'] + $order['waived_paise'] >= (int)$order['total_paise'] ? ($order['waived_paise'] > 0 ? 'settled' : 'paid') : 'pending');
        }
        $order['id'] = (int)$order['id']; $order['total_paise'] = (int)$order['total_paise'];
        $order['total_amount'] = number_format($order['total_paise']/100, 2, '.', '');
        $order['due_paise'] = in_array($order['payment_status'], ['paid','settled'], true) || $order['order_status'] === 'cancelled' || ($order['bill_status'] ?? '') === 'returned'
            ? 0 : max(0, $order['total_paise'] - $order['paid_paise'] - $order['waived_paise']);
        return $order;
    }

    public function getAdminOrders(array $input): array {
        $page = inventoryInteger($input['page'] ?? 1, 'Page', 1, 100000);
        $status = inventoryText($input['status'] ?? '', 30, 'status');
        $search = inventoryText($input['search'] ?? '', 100, 'search');
        $where = '1=1'; $params = [];
        if ($status !== '' && $status !== 'all') { $where .= ' AND o.order_status=?'; $params[] = $status; }
        if ($search !== '') { $where .= ' AND (o.order_number LIKE ? OR o.student_id LIKE ? OR s.name LIKE ? OR o.parent_phone LIKE ?)'; $params = [...$params, ...array_fill(0, 4, '%'.$search.'%')]; }
        $join = ' FROM inventory_orders o LEFT JOIN students s ON s.student_id COLLATE utf8mb4_unicode_ci=o.student_id COLLATE utf8mb4_unicode_ci';
        $total = (int)$this->query("SELECT COUNT(*) $join WHERE $where", $params)->fetchColumn();
        $page = min($page, max(1, (int)ceil($total/25)));
        $rows = $this->query("SELECT o.*, s.name AS student_name, c.class_name, sec.section_name, d.paid_paise AS bill_paid_paise, d.waived_paise AS bill_waived_paise, d.status AS bill_status $join LEFT JOIN classes c ON c.id=s.class_id LEFT JOIN sections sec ON sec.id=s.section_id LEFT JOIN inventory_documents d ON d.id=o.document_id WHERE $where ORDER BY o.id DESC LIMIT 25 OFFSET " . (($page-1)*25), $params)->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as &$row) {
            $row = $this->displayOrder($row);
            unset($row['payload_hash'], $row['request_key']);
        }
        $summary = $this->query("SELECT COALESCE(SUM(order_status IN ('placed','confirmed')),0) AS pending_count,
            COALESCE(SUM(order_status='ready_for_pickup'),0) AS ready_count,
            COALESCE(SUM(order_status='delivered'),0) AS delivered_count,
            COALESCE(SUM(order_status='cancelled'),0) AS cancelled_count,
            COALESCE(SUM(payment_status='refund_pending'),0) AS refund_pending_count FROM inventory_orders")->fetch(PDO::FETCH_ASSOC);
        return ['rows'=>$rows, 'total'=>$total, 'page'=>$page, 'pages'=>max(1,(int)ceil($total/25)), 'summary'=>$summary];
    }

    public function getOrderDetail(int $id): array {
        $order = $this->query('SELECT o.*, s.name AS student_name, s.roll_no, c.class_name, sec.section_name, u.full_name AS delivered_by_name, d.paid_paise AS bill_paid_paise, d.waived_paise AS bill_waived_paise, d.status AS bill_status FROM inventory_orders o LEFT JOIN students s ON s.student_id COLLATE utf8mb4_unicode_ci=o.student_id COLLATE utf8mb4_unicode_ci LEFT JOIN classes c ON c.id=s.class_id LEFT JOIN sections sec ON sec.id=s.section_id LEFT JOIN users u ON u.id=o.delivered_by LEFT JOIN inventory_documents d ON d.id=o.document_id WHERE o.id=?', [$id])->fetch(PDO::FETCH_ASSOC);
        if (!$order) throw new InvalidArgumentException('Order not found.');
        $order = $this->displayOrder($order);
        $order['items'] = $this->items($id);
        unset($order['payload_hash'], $order['request_key']);
        return $order;
    }

    public function updateOrderStatus(int $id, string $status, array $options = []): array {
        if (!$this->adminId || !in_array($status, ['ready_for_pickup','delivered','cancelled'], true)) throw new InvalidArgumentException('Invalid order action.');
        // Recover missed app callbacks before handover or cancellation; never collect cash on an unpaid online order.
        $initial = $this->getOrderDetail($id);
        if ($initial['payment_method'] === 'online' && $initial['order_status'] !== 'delivered') $this->reconcile($initial);
        $this->pdo->beginTransaction();
        try {
            $order = $this->query('SELECT * FROM inventory_orders WHERE id=? FOR UPDATE', [$id])->fetch(PDO::FETCH_ASSOC);
            if (!$order) throw new InvalidArgumentException('Order not found.');
            if ($order['order_status'] === $status) {
                $this->pdo->commit();
                return ['order_id'=>$id, 'status'=>$status, 'document_id'=>$order['document_id'], 'message'=>'This order was already updated.'];
            }
            if (in_array($order['order_status'], ['delivered','cancelled'], true)) throw new InvalidArgumentException('This order is already closed. Refresh the order list.');
            if ($status === 'cancelled') {
                $this->releaseReservation($id);
                $paymentStatus = $order['payment_status'] === 'paid' ? 'refund_pending' : $order['payment_status'];
                $this->query("UPDATE inventory_orders SET order_status='cancelled', payment_status=? WHERE id=?", [$paymentStatus, $id]);
                $message = $paymentStatus === 'refund_pending' ? 'Order cancelled and stock released. Refund the payment in Razorpay; confirmation will sync from Razorpay.' : 'Order cancelled and reserved stock released.';
            } else {
                if ($order['payment_method'] === 'online' && $order['payment_status'] !== 'paid') throw new InvalidArgumentException('Confirm online payment before preparing or delivering this order.');
                if ($status === 'ready_for_pickup') {
                    $this->query("UPDATE inventory_orders SET order_status='ready_for_pickup' WHERE id=?", [$id]);
                    $message = 'Order ready for pickup. Parents can see this in My Orders.';
                } else {
                    $online = $order['payment_method'] === 'online';
                    $settle = ($options['settle_remaining'] ?? false) === true;
                    $received = array_key_exists('received_amount', $options) ? inventoryMoney($options['received_amount'], 'Amount received')
                        : (($online || ($options['collect_now'] ?? false)) ? (int)$order['total_paise'] : 0);
                    if ($online && ($settle || $received !== (int)$order['total_paise'])) throw new InvalidArgumentException('Online orders require full payment and cannot be settled offline.');
                    if ($received > (int)$order['total_paise']) throw new InvalidArgumentException('Amount received cannot exceed the order total.');
                    $closed = $settle || $received === (int)$order['total_paise'];
                    $items = array_map(fn($i) => ['product_id'=>$i['product_id'], 'quantity'=>$i['quantity'], 'price'=>$i['unit_price']], $this->items($id));
                    $this->releaseReservation($id);
                    $service = new InventoryService($this->pdo, $this->adminId);
                    $result = $service->mutate('sale', [
                        'request_key'=>substr(hash('sha256', 'store-order-'.$id),0,8).'-'.substr(hash('sha256','store-order-'.$id),8,4).'-'.substr(hash('sha256','store-order-'.$id),12,4).'-'.substr(hash('sha256','store-order-'.$id),16,4).'-'.substr(hash('sha256','store-order-'.$id),20,12),
                        'items'=>$items, 'student_id'=>$order['student_id'],
                        'paid'=>number_format($received/100,2,'.',''),
                        'settle_remaining'=>$settle, 'settlement_reason'=>$options['settlement_reason'] ?? '',
                        'method'=>$order['payment_method']==='online' ? 'online' : ($options['method'] ?? 'cash'),
                        'reference'=>$order['razorpay_payment_id'] ?: $order['order_number'],
                        'note'=>'Parent store order '.$order['order_number']
                    ]);
                    $this->query("UPDATE inventory_orders SET order_status='delivered', payment_status=?, document_id=?, delivered_by=?, delivered_at=? WHERE id=?", [$closed?'paid':'pending', $result['id'], $this->adminId, date('Y-m-d H:i:s'), $id]);
                    $message = $settle ? 'Order delivered and settled. Payment and waived balance recorded separately.' : 'Order delivered. Actual payment and remaining student due were recorded.';
                }
            }
            $this->pdo->commit();
            return ['order_id'=>$id, 'status'=>$status, 'message'=>$message];
        } catch (Throwable $e) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            throw $e;
        }
    }
}
