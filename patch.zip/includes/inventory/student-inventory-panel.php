<?php $canViewStudentInventory = $navbar_type !== 'admin' || hasPermission(PERM_MANAGE_INVENTORY); ?>
<section id="studentInventoryPanel" class="card border-0 shadow-sm">
    <div class="card-header info-card-header info-card-header--green py-3">
        <h5 class="fw-bold mb-1"><i class="fas fa-bag-shopping me-2"></i>School store account</h5>
        <p class="small mb-0">Items bought from school, free items, returns and payments. This balance is separate from school fees and wallet.</p>
    </div>
    <div class="card-body">
        <div class="row g-3 mb-4" aria-label="Lifetime inventory account summary">
            <?php foreach (['purchases_paise' => 'Purchases after returns', 'paid_paise' => 'Paid after refunds', 'waived_paise' => 'Balance waived', 'refunded_paise' => 'Money refunded', 'due_paise' => 'Balance due'] as $key => $label): ?>
                <div class="col-6 col-xl-3"><div class="border rounded-3 p-3 h-100 <?= $key === 'due_paise' ? 'bg-warning bg-opacity-10' : 'bg-light' ?>">
                    <div class="small text-muted"><?= $label ?></div><div class="h4 mt-1 mb-0 text-break" data-inventory-summary="<?= $key ?>">-</div>
                </div></div>
            <?php endforeach; ?>
        </div>
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3 d-print-none">
            <label class="form-check mb-0"><input id="studentInventoryDue" type="checkbox" class="form-check-input" <?= $canViewStudentInventory ? '' : 'disabled' ?>> <span class="form-check-label">Only bills with a balance due</span></label>
            <button id="studentInventoryRefresh" class="btn btn-sm btn-outline-primary" type="button" <?= $canViewStudentInventory ? '' : 'disabled' ?>><i class="fas fa-rotate me-1"></i>Refresh</button>
        </div>
        <div id="studentInventoryMessage" class="small text-muted mb-3" role="status" aria-live="polite"></div>
        <div class="table-responsive"><table class="table table-hover align-middle">
            <thead class="table-light"><tr><th>Entry / date</th><th>Type</th><th>Bill amount</th><th>Paid / refunded</th><th>Balance due</th><th class="d-none d-md-table-cell d-print-none">Details</th></tr></thead>
            <tbody id="studentInventoryRows"><tr><td colspan="6" class="text-muted text-center py-4">Loading inventory account…</td></tr></tbody>
        </table></div>
        <div id="studentInventoryPagination" class="d-flex flex-wrap justify-content-between align-items-center gap-2 d-print-none"></div>
        <p class="small text-muted mt-3 mb-0">Open a bill to see product quantities and every payment or refund. To pay a balance or correct an entry, please contact the school.</p>
    </div>
</section>
<div class="modal fade" id="studentInventoryDetail" tabindex="-1" aria-labelledby="studentInventoryDetailTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content">
        <div class="modal-header"><h5 class="modal-title" id="studentInventoryDetailTitle">Inventory bill details</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
        <div class="modal-body" id="studentInventoryDetailBody"></div>
        <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button></div>
    </div></div>
</div>
<script>
window.studentInventoryConfig = <?= json_encode([
    'api' => BASE_URL . '/api/parent/get/inventory/get-student-inventory.php',
    'studentId' => $student_id,
    'allowed' => $canViewStudentInventory,
    'currency' => $currency_symbol
], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
</script>
<script defer src="<?= BASE_URL ?>/assets/js/student/student-inventory.js?v=<?= substr(hash_file('sha256', __DIR__ . '/../../assets/js/student/student-inventory.js'), 0, 16) ?>"></script>
