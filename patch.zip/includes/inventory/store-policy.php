<?php

function storeIsOpen(array $settings): bool {
    // Preserve existing schools' Store until they explicitly close it in settings.
    return in_array($settings['store_open'] ?? 1, [1, '1', true], true);
}
