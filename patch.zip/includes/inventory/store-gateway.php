<?php
// This class performs provider HTTPS requests only; credentials never leave the server.
class StoreGateway {
    public function __construct(private string $keyId, private string $keySecret) {}

    public function keyId(): string { return $this->keyId; }
    public function secret(): string { return $this->keySecret; }

    private function request(string $path, ?array $body = null): array {
        if ($this->keyId === '' || $this->keySecret === '') throw new RuntimeException('Online payment is not configured.');
        $ch = curl_init('https://api.razorpay.com/v1/' . $path);
        curl_setopt_array($ch, [
            CURLOPT_USERPWD => $this->keyId . ':' . $this->keySecret,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        ]);
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body, JSON_THROW_ON_ERROR));
        }
        try {
            $raw = curl_exec($ch);
            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($raw === false || $code < 200 || $code >= 300) throw new RuntimeException('The payment provider is temporarily unavailable. Please try again.');
            $result = json_decode($raw, true, 64, JSON_THROW_ON_ERROR);
            if (!is_array($result)) throw new RuntimeException('Invalid payment provider response.');
            return $result;
        } finally {
            curl_close($ch);
        }
    }

    public function createOrder(string $number, int $amount): string {
        $order = $this->request('orders', ['receipt' => $number, 'amount' => $amount, 'currency' => 'INR']);
        $id = $order['id'] ?? '';
        if (!is_string($id) || !preg_match('/^order_[a-zA-Z0-9]+$/D', $id)
            || (int)($order['amount'] ?? 0) !== $amount || ($order['currency'] ?? '') !== 'INR') {
            throw new RuntimeException('Unable to start payment. Please try again.');
        }
        return $id;
    }

    public function payment(string $id): array {
        if (!preg_match('/^pay_[a-zA-Z0-9]+$/D', $id)) throw new InvalidArgumentException('Invalid payment reference.');
        return $this->request('payments/' . $id);
    }

    public function payments(string $orderId): array {
        if (!preg_match('/^order_[a-zA-Z0-9]+$/D', $orderId)) throw new InvalidArgumentException('Invalid order reference.');
        return $this->request('orders/' . $orderId . '/payments')['items'] ?? [];
    }
}
