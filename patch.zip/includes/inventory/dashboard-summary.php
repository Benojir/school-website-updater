<?php
// Included after dashboard authentication; never load amounts without both permissions.
require_once __DIR__ . '/inventory-service.php';
$canSeeInventorySummary = hasPermission(PERM_MANAGE_INVENTORY) && hasPermission(PERM_CAN_SEE_FINANCIAL_REPORT);
$inventorySummary = null;
$inventorySummaryError = null;
$inventoryPeriod = ['from' => date('Y-m-01'), 'to' => date('Y-m-d')];
if ($canSeeInventorySummary) {
    try {
        $inventoryService = new InventoryService($pdo, (int)getAuthenticatedAdmin($pdo)['user_id']);
        $inventorySummary = $inventoryService->profitAndLossSummary($inventoryPeriod);
    } catch (PDOException $e) {
        error_log('Dashboard inventory summary: ' . $e->getMessage());
        $inventorySummaryError = $e->getCode() === '42S02'
            ? 'Inventory is not ready yet. Ask the school owner to finish setup.'
            : 'Inventory totals are temporarily unavailable. Please try again later.';
    }
}
$inventoryAmount = static fn(string $key): string => $inventorySummary === null
    ? '-'
    : htmlspecialchars($currency_symbol, ENT_QUOTES, 'UTF-8') . number_format((int)$inventorySummary[$key] / 100, 2);
$inventoryProfit = $inventorySummary === null ? null : (int)$inventorySummary['profit_paise'];
$inventoryProfitClass = $inventoryProfit === null || $inventoryProfit === 0 ? 'text-secondary' : ($inventoryProfit < 0 ? 'text-danger' : 'text-success');
?>
<section class="card shadow-sm" aria-labelledby="inventory-summary-title">
    <div class="card-header bg-white border-bottom-0 py-3">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
            <div>
                <h5 id="inventory-summary-title" class="mb-1"><i class="fas fa-boxes-stacked me-2"></i>Inventory Profit &amp; Loss</h5>
                <div class="small text-muted">This month: <?= date('j M', strtotime($inventoryPeriod['from'])) ?> &ndash; <?= date('j M Y', strtotime($inventoryPeriod['to'])) ?></div>
            </div>
            <?php if ($canSeeInventorySummary): ?>
                <a class="btn btn-sm btn-outline-primary" href="<?= BASE_URL ?>/management/inventory/?view=report">View full report</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="card-body pt-0">
        <?php if ($inventorySummaryError !== null): ?>
            <div class="alert alert-warning py-2 small" role="status"><?= htmlspecialchars($inventorySummaryError, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>
        <div class="row g-3">
            <div class="col-12 col-md-6 col-xl-3">
                <div class="rounded border bg-light p-3 h-100">
                    <div class="small text-muted">Net sales</div>
                    <div class="h4 mb-1 text-break"><?= $inventoryAmount('sales_paise') ?></div>
                    <div class="small text-muted">Sales after returns, including credit sales</div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-xl-3">
                <div class="rounded border bg-light p-3 h-100">
                    <div class="small text-muted">Cost of items sold</div>
                    <div class="h4 mb-1 text-break"><?= $inventoryAmount('sold_cost_paise') ?></div>
                    <div class="small text-muted">Buying cost of sold items, after returns</div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-xl-3">
                <div class="rounded border bg-light p-3 h-100">
                    <div class="small text-muted">Free distribution / stock loss</div>
                    <div class="small mt-2 d-flex flex-wrap justify-content-between gap-1"><span>Free distribution</span><strong class="text-break"><?= $inventoryAmount('gifts_paise') ?></strong></div>
                    <div class="small mt-1 d-flex flex-wrap justify-content-between gap-1"><span>Damaged / lost</span><strong class="text-break"><?= $inventoryAmount('loss_paise') ?></strong></div>
                </div>
            </div>
            <div class="col-12 col-md-6 col-xl-3">
                <div class="rounded border p-3 h-100 <?= $inventoryProfit === null || $inventoryProfit === 0 ? 'bg-light' : ($inventoryProfit < 0 ? 'bg-danger bg-opacity-10 border-danger' : 'bg-success bg-opacity-10 border-success') ?>">
                    <div class="small fw-bold <?= $inventoryProfitClass ?>"><?= $inventoryProfit === null ? 'Net profit / loss' : ($inventoryProfit < 0 ? 'Net loss' : ($inventoryProfit > 0 ? 'Net profit' : 'No profit or loss')) ?></div>
                    <div class="h4 mb-1 text-break <?= $inventoryProfitClass ?>"><?= $inventoryProfit === null ? '-' : htmlspecialchars($currency_symbol, ENT_QUOTES, 'UTF-8') . number_format(abs($inventoryProfit) / 100, 2) ?></div>
                    <div class="small text-muted">After sold, free and damaged / lost item costs</div>
                </div>
            </div>
        </div>
        <p class="small text-muted mt-3 mb-0">School store only. Profit includes credit sales; it is different from money collected. School fees and other school expenses are separate.</p>
    </div>
</section>
