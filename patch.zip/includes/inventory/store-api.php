<?php
require_once __DIR__ . '/../parent/auth/parent-auth-check.php';
require_once __DIR__ . '/inventory-order-service.php';
require_once __DIR__ . '/store-policy.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function storeInput(): array {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        header('Allow: POST');
        echo json_encode(['success'=>false, 'message'=>'Use POST.']);
        exit;
    }
    // Cookie-authenticated browser requests must originate on the school's own site.
    $headers = array_change_key_case(getallheaders(), CASE_LOWER);
    if (empty($headers['authentication']) || !str_starts_with($headers['authentication'], 'Bearer ')) {
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        $base = parse_url(BASE_URL);
        $expected = ($base['scheme'] ?? '') . '://' . ($base['host'] ?? '') . (isset($base['port']) ? ':' . $base['port'] : '');
        if ($origin !== $expected) {
            http_response_code(403);
            echo json_encode(['success'=>false, 'message'=>'Open the school app or website to place an order.']);
            exit;
        }
    }
    $raw = file_get_contents('php://input', false, null, 0, 65537);
    if (strlen($raw) > 65536) throw new InvalidArgumentException('This request is too large.');
    $input = json_decode($raw, true, 32, JSON_THROW_ON_ERROR);
    if (!is_array($input)) throw new InvalidArgumentException('Invalid request.');
    return $input;
}

function storeOpen(): bool {
    global $schoolSettings;
    return storeIsOpen($schoolSettings);
}

function storeOnlineEnabled(): bool {
    global $schoolSettings, $websiteConfig;
    return storeOpen() && (int)($schoolSettings['allow_online_payment'] ?? 0) === 1
        && !empty($websiteConfig['razorpay_key_id']) && !empty($websiteConfig['razorpay_key_secret']);
}

function storeGateway(): StoreGateway {
    global $websiteConfig;
    return new StoreGateway($websiteConfig['razorpay_key_id'] ?? '', $websiteConfig['razorpay_key_secret'] ?? '');
}

function storeError(Throwable $e): void {
    if ($e instanceof InvalidArgumentException || $e instanceof JsonException) {
        http_response_code(422);
        $message = $e instanceof JsonException ? 'Invalid request. Please try again.' : $e->getMessage();
    } else {
        error_log('Parent store: ' . $e->getMessage());
        $missing = $e instanceof PDOException && in_array($e->getCode(), ['42S02', '42S22'], true);
        http_response_code($missing ? 503 : 500);
        $message = $missing ? 'The school store is being set up. Please try again later.'
            : 'Unable to complete the request. Check My Orders before retrying. If money was deducted, check payment there before paying again.';
    }
    echo json_encode(['success'=>false, 'message'=>$message]);
}
