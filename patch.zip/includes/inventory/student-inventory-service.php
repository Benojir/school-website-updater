<?php
require_once __DIR__ . '/inventory-math.php';

// Read-only student account. Callers must authorize access to the student first.
// Explicit column lists keep supplier details, stock costs and staff notes private.
class StudentInventoryService {
    public function __construct(private PDO $pdo) {}

    private function query(string $sql, array $params): PDOStatement {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    private function document(array $row): array {
        foreach (['id', 'total_paise', 'paid_paise', 'waived_paise'] as $key) $row[$key] = (int)$row[$key];
        $row['original_document_id'] = $row['original_document_id'] === null ? null : (int)$row['original_document_id'];
        $row['due_paise'] = $row['kind'] === 'sale' ? inventoryBalance($row['total_paise'], $row['paid_paise'], $row['status'], $row['waived_paise']) : 0;
        $row['net_paid_paise'] = $row['status'] === 'returned' ? 0 : $row['paid_paise'];
        $row['refund_paise'] = $row['kind'] === 'return' || $row['status'] === 'returned' ? abs($row['paid_paise']) : 0;
        return $row;
    }

    public function history(string $studentId, array $input): array {
        $page = inventoryInteger($input['page'] ?? 1, 'Page', 1, 100000);
        $onlyDue = inventoryInteger($input['due'] ?? 0, 'Due filter', 0, 1) === 1;
        $summary = $this->query("SELECT
            COALESCE(SUM(CASE WHEN kind IN ('sale','return') THEN total_paise ELSE 0 END),0) AS purchases_paise,
            COALESCE(SUM(CASE WHEN kind IN ('sale','return') THEN paid_paise ELSE 0 END),0) AS paid_paise,
            COALESCE(SUM(CASE WHEN kind IN ('sale','return') THEN waived_paise ELSE 0 END),0) AS waived_paise,
            COALESCE(SUM(CASE WHEN kind='return' THEN -paid_paise ELSE 0 END),0) AS refunded_paise,
            COALESCE(SUM(CASE WHEN kind='sale' AND status='posted' THEN total_paise-paid_paise-waived_paise ELSE 0 END),0) AS due_paise
            FROM inventory_documents WHERE student_id=? AND kind IN ('sale','gift','return')", [$studentId])->fetch(PDO::FETCH_ASSOC);
        $summary = array_map('intval', $summary);
        $where = "student_id=? AND kind IN ('sale','gift','return')";
        if ($onlyDue) $where .= " AND kind='sale' AND status='posted' AND total_paise>paid_paise+waived_paise";
        $total = (int)$this->query("SELECT COUNT(*) FROM inventory_documents WHERE $where", [$studentId])->fetchColumn();
        $pages = max(1, (int)ceil($total / 10));
        $page = min($page, $pages);
        $rows = $this->query("SELECT id, kind, status, created_at, total_paise, paid_paise, waived_paise, original_document_id
            FROM inventory_documents WHERE $where ORDER BY id DESC LIMIT 10 OFFSET " . (($page - 1) * 10), [$studentId])->fetchAll(PDO::FETCH_ASSOC);
        $rows = array_map(fn(array $row) => $this->document($row), $rows);
        return ['summary' => $summary, 'rows' => $rows, 'page' => $page, 'pages' => $pages, 'total' => $total];
    }

    public function detail(string $studentId, int $id): ?array {
        $row = $this->query("SELECT id, kind, status, created_at, total_paise, paid_paise, waived_paise, original_document_id
            FROM inventory_documents WHERE id=? AND student_id=? AND kind IN ('sale','gift','return')", [$id, $studentId])->fetch(PDO::FETCH_ASSOC);
        if (!$row) return null;
        $row = $this->document($row);
        $row['items'] = $this->query("SELECT i.product_name, i.unit, i.quantity, i.unit_price_paise, i.line_total_paise
            FROM inventory_document_items i JOIN inventory_documents d ON d.id=i.document_id
            WHERE d.id=? AND d.student_id=? AND d.kind IN ('sale','gift','return') ORDER BY i.id", [$id, $studentId])->fetchAll(PDO::FETCH_ASSOC);
        foreach ($row['items'] as &$item) {
            foreach (['quantity', 'unit_price_paise', 'line_total_paise'] as $key) $item[$key] = (int)$item[$key];
        }
        unset($item);
        $row['payments'] = [];
        if (in_array($row['kind'], ['sale', 'return'], true)) {
            $params = [$row['original_document_id'] ?? $id, $studentId];
            $returnFilter = '';
            if ($row['kind'] === 'return') {
                $returnFilter = ' AND p.return_document_id=?';
                $params[] = $id;
            }
            $row['payments'] = $this->query("SELECT p.created_at, p.amount_paise, p.method, p.reference
                FROM inventory_payments p JOIN inventory_documents d ON d.id=p.document_id
                WHERE d.id=? AND d.student_id=? AND d.kind='sale'$returnFilter ORDER BY p.id", $params)->fetchAll(PDO::FETCH_ASSOC);
            foreach ($row['payments'] as &$payment) $payment['amount_paise'] = (int)$payment['amount_paise'];
            unset($payment);
        }
        return $row;
    }
}
