<?php
require_once __DIR__ . '/photo-storage.php';

/** @return resource|null Null only when another process already holds the lock. */
function schoolPhotoMaintenanceLock(string $path)
{
    $lock = @fopen($path, 'c');
    if ($lock === false) {
        throw new RuntimeException('Cannot open photo maintenance lock: ' . $path . '. Run the CLI as the website PHP user with write access to includes/ and read access to the R2 encryption key.');
    }
    $wouldBlock = 0;
    if (!@flock($lock, LOCK_EX | LOCK_NB, $wouldBlock)) {
        fclose($lock);
        if ($wouldBlock) return null;
        throw new RuntimeException('Cannot acquire photo maintenance lock: ' . $path . '. Check filesystem permissions and support for file locking.');
    }
    return $lock;
}

/** Safe to repeat: filename/reference stays unchanged; copy is checked byte for byte. */
function schoolPhotoMigrateOne(string $category, string $filename, bool $removeLocal, ?SchoolR2Client $client = null): string
{
    if (!schoolPhotoValidName($category, $filename)) throw new RuntimeException('Invalid legacy photo filename; kept for manual review.');
    if (schoolPhotoIsDefault($filename)) return 'default';
    $path = schoolPhotoLocalPath($category, $filename);
    if (!is_file($path) || is_link($path)) {
        if ((schoolPhotoObject($category, $filename)['status'] ?? '') !== 'ready') return 'missing';
        schoolPhotoRead($category, $filename, $client); // report missing/corrupt remote objects instead of false success
        return 'remote';
    }
    if (!schoolPhotoReferenced($category, $filename)) return 'unused';
    $bytes = file_get_contents($path);
    if ($bytes === false || strlen($bytes) > 10 * 1024 * 1024 || !$info = @getimagesizefromstring($bytes)) throw new RuntimeException('Invalid local photo; kept for manual review.');
    if (!in_array($info['mime'], ['image/jpeg', 'image/png', 'image/gif', 'image/webp'], true)) throw new RuntimeException('Unsupported photo; local file kept.');
    $config = schoolR2Config();
    $object = schoolPhotoObject($category, $filename);
    $hash = hash('sha256', $bytes);
    if ($object && $object['sha256'] !== $hash) throw new RuntimeException('Local photo differs from its R2 registry. Neither copy was changed.');
    if (!$object) {
        $object = ['category' => $category, 'filename' => $filename, 'object_key' => $config['prefix'] . '/' . $category . '/' . $filename,
            'endpoint' => $config['endpoint'], 'bucket' => $config['bucket'], 'sha256' => $hash, 'mime' => $info['mime'], 'bytes' => strlen($bytes)];
        $stmt = $GLOBALS['pdo']->prepare('INSERT INTO school_photo_objects (category, filename, object_key, endpoint, bucket, sha256, mime, bytes, status) VALUES (:category, :filename, :object_key, :endpoint, :bucket, :sha256, :mime, :bytes, \'uploading\')');
        $stmt->execute($object);
        $object['status'] = 'uploading';
    }
    $client ??= schoolR2Client($object);
    schoolPhotoJournal($object); // also covers a concurrent record deletion or worker crash
    try {
        if ($object['status'] !== 'ready') $client->putVerified($object['object_key'], $bytes, $info['mime']);
        else {
            $remote = $client->request('GET', $object['object_key'])['body'];
            if (!hash_equals($hash, hash('sha256', $remote))) throw new RuntimeException('R2 verification failed; local photo kept.');
        }
        $stmt = $GLOBALS['pdo']->prepare("UPDATE school_photo_objects SET status = 'ready', last_error = NULL, delete_requested = 0 WHERE category = ? AND filename = ?");
        if (!$stmt->execute([$category, $filename])) throw new RuntimeException('Could not save migration registry.');
        $saved = schoolPhotoObject($category, $filename);
        if (!$saved || $saved['status'] !== 'ready' || $saved['sha256'] !== $hash) throw new RuntimeException('Photo registry changed during migration; recovery journal and local source kept.');
        if ($removeLocal) {
            // The file might have changed while network I/O was running.
            if (is_link($path) || !hash_equals($hash, hash_file('sha256', $path))) throw new RuntimeException('Local photo changed during migration; local copy kept.');
            if (!unlink($path)) throw new RuntimeException('R2 copy verified; could not remove local copy.');
            schoolPhotoForgetJournal($object);
            return 'moved';
        }
        schoolPhotoForgetJournal($object);
        return 'copied';
    } catch (Throwable $e) {
        $stmt = $GLOBALS['pdo']->prepare('UPDATE school_photo_objects SET last_error = ? WHERE category = ? AND filename = ?');
        $stmt->execute([substr($e->getMessage(), 0, 500), $category, $filename]);
        throw $e;
    }
}

function schoolPhotoMigrationCandidates(string $cursor, int $limit): array
{
    $queries = [];
    foreach (schoolPhotoCategories() as $category => [$table, $field]) $queries[] = "SELECT '$category' AS category, $field AS filename FROM $table WHERE $field IS NOT NULL AND $field <> ''";
    $queries[] = "SELECT 'students' AS category, student_image AS filename FROM admission_enquiries WHERE student_image IS NOT NULL AND student_image <> ''";
    $sql = 'SELECT category, filename FROM (' . implode(' UNION ', $queries) . ') photos WHERE CAST(CONCAT(category, \'/\', filename) AS BINARY) > ? ORDER BY CAST(CONCAT(category, \'/\', filename) AS BINARY) LIMIT ' . max(1, min(100, $limit));
    $stmt = $GLOBALS['pdo']->prepare($sql);
    $stmt->execute([$cursor]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function schoolPhotoRecoverJournals(int $limit): array
{
    $result = ['recovered' => 0, 'errors' => []];
    $paths = glob(__DIR__ . '/.r2-pending/*.php') ?: [];
    foreach (array_slice($paths, 0, $limit) as $path) {
        if (filemtime($path) > time() - 3600) continue; // avoid a live form
        try {
            $object = json_decode(substr(file_get_contents($path), strlen("<?php exit; ?>\n")), true, 16, JSON_THROW_ON_ERROR);
            if (!schoolPhotoValidName($object['category'], $object['filename'])) throw new RuntimeException('Invalid recovery journal.');
            if (schoolPhotoReferenced($object['category'], $object['filename'])) {
                $remote = schoolR2Client($object)->request('GET', $object['object_key'])['body'];
                if (!hash_equals($object['sha256'], hash('sha256', $remote))) throw new RuntimeException('Recovery verification failed.');
                $stmt = $GLOBALS['pdo']->prepare('INSERT INTO school_photo_objects (category, filename, object_key, endpoint, bucket, sha256, mime, bytes, status) VALUES (:category, :filename, :object_key, :endpoint, :bucket, :sha256, :mime, :bytes, \'ready\') ON DUPLICATE KEY UPDATE status = \'ready\'');
                $stmt->execute($object);
            } else {
                schoolR2Client($object)->request('DELETE', $object['object_key']);
                $stmt = $GLOBALS['pdo']->prepare('DELETE FROM school_photo_objects WHERE category = ? AND filename = ?');
                $stmt->execute([$object['category'], $object['filename']]);
            }
            schoolPhotoForgetJournal($object);
            $result['recovered']++;
        } catch (Throwable $e) { $result['errors'][] = basename($path) . ': ' . $e->getMessage(); }
    }
    return $result;
}

function schoolPhotoCleanupBatch(int $limit): array
{
    $result = ['deleted' => 0, 'errors' => []];
    // Rotating cursor avoids starvation when the oldest photos are still in use.
    $statePath = __DIR__ . '/.r2-pending/cleanup-cursor.txt';
    $cursor = is_file($statePath) ? (int)file_get_contents($statePath) : 0;
    $stmt = $GLOBALS['pdo']->prepare('SELECT * FROM school_photo_objects WHERE id > ? AND (delete_requested = 1 OR created_at < DATE_SUB(NOW(), INTERVAL 1 DAY)) ORDER BY id LIMIT ' . max(1, min(100, $limit)));
    $stmt->execute([$cursor]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $row) {
        $cursor = (int)$row['id'];
        try {
            if (schoolPhotoDeleteUnused($row['category'], $row['filename'])) $result['deleted']++;
            elseif ($row['last_error'] || $row['status'] !== 'ready') schoolPhotoMigrateOne($row['category'], $row['filename'], false);
        } catch (Throwable $e) { $result['errors'][] = $row['category'] . '/' . $row['filename'] . ': ' . $e->getMessage(); }
    }
    if (!is_dir(dirname($statePath))) mkdir(dirname($statePath), 0700, true);
    file_put_contents($statePath, $rows ? (string)$cursor : '0', LOCK_EX);
    return $result;
}
