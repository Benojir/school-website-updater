<?php
// This file has no bootstrap, database connection or network side effects.
class ContactMessageCaptchaException extends RuntimeException {}

function contactMessageText(array $input, string $key, int $maximum, bool $required = true): string
{
    $value = $input[$key] ?? '';
    if (!is_string($value) || !preg_match('//u', $value)) {
        throw new InvalidArgumentException('Please enter valid text in all fields.');
    }
    $value = trim($value);
    if (($required && $value === '') || strlen($value) > $maximum * 4 || preg_match_all('/./us', $value) > $maximum) {
        throw new InvalidArgumentException('Please check the required fields and their maximum lengths.');
    }
    if (preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $value)) {
        throw new InvalidArgumentException('Please remove invalid characters from the form.');
    }
    return $value;
}

function contactMessageData(array $input): array
{
    $data = [
        'name' => contactMessageText($input, 'name', 100),
        'phone' => contactMessageText($input, 'phone-number', 32),
        'subject' => contactMessageText($input, 'subject', 200, false),
        'message' => contactMessageText($input, 'message', 5000),
    ];
    $digits = preg_replace('/\D/', '', $data['phone']);
    if (!preg_match('/^[+0-9(). -]+$/D', $data['phone']) || strlen($digits) < 7 || strlen($digits) > 15) {
        throw new InvalidArgumentException('Please enter a valid phone number with 7 to 15 digits.');
    }
    return $data;
}

function contactMessageCsrfValid(mixed $expected, mixed $received): bool
{
    return is_string($expected) && $expected !== '' && is_string($received) && hash_equals($expected, $received);
}

/** The optional transport allows offline verification tests without network access. */
function verifyContactMessageCaptcha(string $token, string $secret, string $hostname, ?callable $transport = null): void
{
    if ($token === '' || strlen($token) > 2048) {
        throw new ContactMessageCaptchaException('Please complete the captcha verification.');
    }
    if ($secret === '' || $hostname === '') {
        throw new RuntimeException('Contact captcha is not configured.');
    }
    $context = stream_context_create(['http' => [
        'method' => 'POST',
        'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
        'content' => http_build_query(['secret' => $secret, 'response' => $token]),
        'timeout' => 10,
        'ignore_errors' => true,
        'follow_location' => 0,
    ]]);
    $url = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';
    $raw = $transport ? $transport($url, $context) : @file_get_contents($url, false, $context);
    $result = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($result) || ($result['success'] ?? false) !== true
        || ($result['action'] ?? '') !== 'contact_message'
        || !is_string($result['hostname'] ?? null)
        || strtolower(rtrim($result['hostname'], '.')) !== strtolower(rtrim($hostname, '.'))) {
        throw new ContactMessageCaptchaException('Captcha verification failed or expired. Please verify again.');
    }
}

function submitContactMessage(PDO $pdo, array $input, string $secret, string $hostname, ?callable $transport = null): void
{
    $data = contactMessageData($input);
    $token = contactMessageText($input, 'cf-turnstile-response', 2048, false);
    verifyContactMessageCaptcha($token, $secret, $hostname, $transport);
    // No caller can insert a message through this service before verification succeeds.
    $statement = $pdo->prepare('INSERT INTO contact_messages (name, phone, subject, message, created_at) VALUES (?, ?, ?, ?, ?)');
    $statement->execute([$data['name'], $data['phone'], $data['subject'], $data['message'], date('Y-m-d H:i:s')]);
}
