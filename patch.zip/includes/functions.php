<?php
// Function to sanitize user input
function sanitize_input($data)
{
    return trim(safe_htmlspecialchars($data));
}

// Generate hex token for remember me feature
function generateToken()
{
    return bin2hex(random_bytes(32));
}

// Function to get the ratio of two numbers
function getRatioArray($num1, $num2)
{
    if ($num2 == 0) {
        return null; // or throw an error, depending on your use case
    }

    $gcd = function ($a, $b) use (&$gcd) {
        return ($b == 0) ? $a : $gcd($b, $a % $b);
    };

    $divisor = $gcd($num1, $num2);

    $ratio1 = $num1 / $divisor;
    $ratio2 = $num2 / $divisor;

    return [$ratio1, $ratio2];
}

// Function to check valid phone number
function isValidPhoneNumber($phone)
{
    // Check if the phone number is valid (example: 10 digits)
    return preg_match('/^\d{10}$/', $phone);
}

function isValidEmail($email)
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}


// Function to get color shades
function adjustColorShades($hex, $percent)
{
    // Remove "#" if present
    $hex = ltrim($hex, '#');

    // Convert hex to RGB
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));

    // Darken: decrease RGB values
    $dr = max(0, $r - ($r * $percent / 100));
    $dg = max(0, $g - ($g * $percent / 100));
    $db = max(0, $b - ($b * $percent / 100));
    $darker = sprintf("#%02x%02x%02x", $dr, $dg, $db);

    // Lighten: increase RGB values toward 255
    $lr = min(255, $r + ($percent / 100) * (255 - $r));
    $lg = min(255, $g + ($percent / 100) * (255 - $g));
    $lb = min(255, $b + ($percent / 100) * (255 - $b));
    $lighter = sprintf("#%02x%02x%02x", $lr, $lg, $lb);

    return [
        'darker' => $darker,
        'lighter' => $lighter
    ];
}

// Function to check if a value is integer-like
function isIntegerLike($value) {
    // Check if it's an integer or a string that represents an integer
    return is_numeric($value) && (int)$value == $value && strpos((string)$value, '.') === false;
}


/**
 * Generate unique student ID
 */
function generateUniqueStudentId($pdo)
{
    do {
        $student_id = 'STU' . date('Y') . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE student_id = ?");
        $stmt->execute([$student_id]);
    } while ($stmt->fetchColumn() > 0);

    return $student_id;
}

// Validate image file function
function isValidateImageFile($imageFile)
{
    if (empty($imageFile) || !file_exists($imageFile)) {
        return false;
    }
    
    $imageInfo = @getimagesize($imageFile);
    if ($imageInfo == false) {
        return false; // Not a valid image or corrupted
    }

    switch ($imageInfo['mime']) {
        case 'image/jpeg':
            $img = @imagecreatefromjpeg($imageFile);
            break;
        case 'image/png':
            $img = @imagecreatefrompng($imageFile);
            break;
        default:
            return false; // Unsupported image type
    }

    if (!$img) {
        return false; // Failed to create image resource: likely corrupted
    }

    // Clean up
    imagedestroy($img);

    return true; // Passed all checks
}



/**
 * Get the current version of the application
 * @return string Current version
 */
function getCurrentVersion(): string {
    $versionFile = __DIR__ . '/../updates/version.json';
    if (!file_exists($versionFile)) {
        return 'unknown';
    }

    $versionData = json_decode(file_get_contents($versionFile), true);
    return $versionData['version-code'] ?? 'unknown';
}
/**
 * Check for updates by comparing current version with the latest version
 * @return array Result of the update check
 */
function checkForUpdates(): array {
    $versionFile = __DIR__ . '/../updates/version.json';
    if (!file_exists($versionFile)) {
        return [
            'is_update_available' => false,
            'message' => 'Version file not found'
        ];
    }

    $versionData = json_decode(file_get_contents($versionFile), true);
    $currentVersion = $versionData['version-code'] ?? 'unknown';
    $versionCheckUrl = $versionData['version-check'] ?? null;

    if (!$versionCheckUrl) {
        return [
            'is_update_available' => false,
            'message' => 'Version check URL not defined'
        ];
    }

    $latestVersionData = json_decode(file_get_contents($versionCheckUrl), true);
    if (!$latestVersionData || !isset($latestVersionData['version-code'])) {
        return [
            'is_update_available' => false,
            'message' => 'Failed to fetch latest version data'
        ];
    }

    $latestVersion = $latestVersionData['version-code'];

    return [
        'current_version' => $currentVersion,
        'latest_version' => $latestVersion,
        'is_update_available' => version_compare($currentVersion, $latestVersion, '<'),
        'patch_url' => $latestVersionData['patch-url'] ?? null,
        'description' => $latestVersionData['description'] ?? 'No description available'
    ];
}

/**
 * Safely escape HTML special characters
 * @param string $input Input string to escape
 * @return string Escaped string
 */
function safe_htmlspecialchars($input = null) {
    if (empty($input)) {
        return '';
    }
    return str_replace("&amp;", "&", htmlspecialchars($input, ENT_QUOTES, 'UTF-8'));
}

// Function to get base64 of an image
function imageToBase64($path) {
    $realPath = realpath($path);
    if (!$realPath || !file_exists($realPath)) {
        error_log("Image not found: " . $path);
        return '';
    }
    
    $type = pathinfo($realPath, PATHINFO_EXTENSION);
    $data = file_get_contents($realPath);
    if ($data === false) {
        error_log("Failed to read image: " . $realPath);
        return '';
    }
    
    return 'data:image/' . $type . ';base64,' . base64_encode($data);
}

/**
 * Students results rank function
 */
function getStudentPositionInClass(PDO $pdo, int $examId, int $classId, string $studentId): ?int {
    // Step 1: Fetch all results for the given exam and class
    $stmt = $pdo->prepare("SELECT student_id, percentage 
                           FROM results 
                           WHERE exam_id = ? AND class_id = ? 
                           ORDER BY percentage DESC");
    $stmt->execute([$examId, $classId]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Step 2: Rank students with tie handling
    $position = 0;
    $rank = 0;
    $lastMarks = null;

    foreach ($results as $row) {
        $position++;

        if ($lastMarks === null || $row['percentage'] != $lastMarks) {
            $rank = $position;
            $lastMarks = $row['percentage'];
        }

        if ($row['student_id'] === $studentId) {
            return $rank;
        }
    }

    // If student not found in results
    return null;
}

// Get Ordinal function
function getOrdinal($number) {
    $suffix = ['th', 'st', 'nd', 'rd'];
    $mod100 = $number % 100;
    return $number . ($suffix[($mod100 - 20) % 10] ?? $suffix[$mod100] ?? $suffix[0]);
}

// Get Pass/Fail status based on grade
function getPassFailStatus($grade) {
    if ($grade == 'D' || $grade == 'F') {
        return '<b style="color:#FF0000;">FAIL</b>';
    } else {
        return '<b style="color:#008000;">PASS</b>';
    }
}

// Calculate overall grade based on percentage
function calculateGrade($percentage)
{
    // Implement your grade calculation logic
    if ($percentage >= 90) return 'AA';
    if ($percentage >= 80) return 'A+';
    if ($percentage >= 70) return 'A';
    if ($percentage >= 60) return 'B+';
    if ($percentage >= 50) return 'B';
    if ($percentage >= 40) return 'C+';
    if ($percentage >= 35) return 'C';
    return 'D';
}

// Get remarks based on grade
function getRemarksByGrade($grade) {
    $remarks = [
        'AA' => 'Outstanding',
        'A+' => 'Excellent',
        'A' => 'Very Good',
        'B+' => 'Good',
        'B' => 'Satisfactory',
        'C+' => 'Acceptable',
        'C' => 'Basic',
        'D' => 'Disqualified'
    ];
    return $remarks[$grade] ?? '-';
}


// Get class name by ID
function getClassNameById(PDO $pdo, $classId) {
    $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
    $stmt->execute([$classId]);
    return $stmt->fetchColumn() ?: 'Unknown Class';
}