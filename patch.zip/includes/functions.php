<?php
include_once __DIR__ . '/academic/fun-academic-functions.php';
include_once __DIR__ . '/financial/fun-admission-fees-entry.php';
include_once __DIR__ . '/financial/fun-basic-financials.php';
include_once __DIR__ . '/notification/fun-notification-helpers.php';
include_once __DIR__ . '/student/fun-student-related.php';

// Function to sanitize user input
function sanitize_input(mixed $data)
{
    if ($data === NULL || $data === '') {
        return NULL;
    }

    if (is_array($data)) {
        return array_map('sanitize_input', $data);
    }
    return trim(safe_htmlspecialchars($data));
}

// Generate hex token for remember me feature
function generateToken()
{
    return bin2hex(random_bytes(32));
}

// Function to get the ratio of two numbers
function getRatioArray(int $num1, int $num2)
{
    if ($num2 == 0) {
        return null; // or throw an error, depending on your use case
    }

    $gcd = function ($a, $b) use (&$gcd) {
        return ($b == 0) ? $a : $gcd($b, $a % $b);
    };

    $divisor = $gcd($num1, $num2);

    $ratio1 = $num1 / $divisor;
    $ratio2 = $num2 / $divisor;

    return [$ratio1, $ratio2];
}

// Function to check valid phone number
function isValidPhoneNumber(string $phone)
{
    // Check if the phone number is valid (example: 10 digits)
    return preg_match('/^\d{10}$/', $phone);
}

function isValidEmail(string $email)
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}


// Function to get color shades
function adjustColorShades(mixed $hex, mixed $percent)
{
    // Remove "#" if present
    $hex = ltrim($hex, '#');

    // Convert hex to RGB
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));

    // Darken: decrease RGB values
    $dr = max(0, $r - ($r * $percent / 100));
    $dg = max(0, $g - ($g * $percent / 100));
    $db = max(0, $b - ($b * $percent / 100));
    $darker = sprintf("#%02x%02x%02x", $dr, $dg, $db);

    // Lighten: increase RGB values toward 255
    $lr = min(255, $r + ($percent / 100) * (255 - $r));
    $lg = min(255, $g + ($percent / 100) * (255 - $g));
    $lb = min(255, $b + ($percent / 100) * (255 - $b));
    $lighter = sprintf("#%02x%02x%02x", $lr, $lg, $lb);

    return [
        'darker' => $darker,
        'lighter' => $lighter
    ];
}

// Function to check if a value is integer-like
function isIntegerLike(mixed $value)
{
    // Check if it's an integer or a string that represents an integer
    return is_numeric($value) && (int)$value == $value && strpos((string)$value, '.') === false;
}

// Validate image file function
function isValidImageFile(string $imageFile): bool
{
    try {
        // 1. Basic sanity and read checks
        if (empty($imageFile) || !file_exists($imageFile) || !is_readable($imageFile)) {
            return false;
        }

        // 2. Secure MIME type detection
        // Using @ to suppress any rare warnings from finfo
        $finfo = @new finfo(FILEINFO_MIME_TYPE);
        if (!$finfo) {
            return false;
        }
        
        $mimeType = @$finfo->file($imageFile);

        // 3. Attempt to recreate the image
        $img = false;
        switch ($mimeType) {
            case 'image/jpeg':
                // @ suppresses warnings if the JPEG is corrupted
                $img = @imagecreatefromjpeg($imageFile);
                break;
            case 'image/png':
                // @ suppresses warnings if the PNG is corrupted
                $img = @imagecreatefrompng($imageFile);
                break;
            default:
                return false; // Unsupported image type
        }

        // 4. Verify successful creation
        if (!($img instanceof \GdImage) && !is_resource($img)) {
            return false; // Corrupted or fake image file
        }

        // 5. Clean up
        unset($img);

        return true;

    } catch (\Throwable $e) {
        // Catch ANY exception or fatal error (e.g., memory limit exhaustion)
        // and silently return false.
        return false;
    }
}



/**
 * Get the current version of the application
 * @return string Current version
 */
function getCurrentVersion(): string
{
    $versionFile = __DIR__ . '/../updates/version.json';
    if (!file_exists($versionFile)) {
        return 'unknown';
    }

    $versionData = json_decode(file_get_contents($versionFile), true);
    return $versionData['version-code'] ?? 'unknown';
}

/**
 * Check for updates by comparing current version with the latest version
 * @return array Result of the update check
 */
function checkForUpdates(): array
{
    $versionFile = __DIR__ . '/../updates/version.json';
    if (!file_exists($versionFile)) {
        return [
            'is_update_available' => false,
            'message' => 'Version file not found'
        ];
    }

    $versionData = json_decode(file_get_contents($versionFile), true);
    $currentVersion = $versionData['version-code'] ?? 'unknown';
    $versionCheckUrl = $versionData['version-check'] ?? null;

    if (!$versionCheckUrl) {
        return [
            'is_update_available' => false,
            'message' => 'Version check URL not defined'
        ];
    }

    $context = stream_context_create([
        'http' => [
            'timeout' => 5
        ]
    ]);

    $response = file_get_contents($versionCheckUrl, false, $context);

    if ($response === false) {
        return [
            'is_update_available' => false,
            'message' => 'Unable to connect to version server'
        ];
    }

    $latestVersionData = json_decode($response, true);

    if (json_last_error() !== JSON_ERROR_NONE || !isset($latestVersionData['version-code'])) {
        return [
            'is_update_available' => false,
            'message' => 'Invalid version data received'
        ];
    }


    $latestVersion = $latestVersionData['version-code'];

    return [
        'current_version' => $currentVersion,
        'latest_version' => $latestVersion,
        'is_update_available' => version_compare($currentVersion, $latestVersion, '<'),
        'patch_url' => $latestVersionData['patch-url'] ?? null,
        'description' => $latestVersionData['description'] ?? 'No description available'
    ];
}

/**
 * Safely escape HTML special characters
 * @param string $input Input string to escape
 * @return string Escaped string
 */
function safe_htmlspecialchars($input = null)
{
    if (empty($input)) {
        return '';
    }
    return str_replace("&amp;", "&", htmlspecialchars($input, ENT_QUOTES, 'UTF-8'));
}

// Function to get base64 of an image
function imageToBase64(string $path)
{
    $realPath = realpath($path);
    if (!$realPath || !file_exists($realPath)) {
        error_log("Image not found: " . $path);
        return '';
    }

    $type = pathinfo($realPath, PATHINFO_EXTENSION);
    $data = file_get_contents($realPath);
    if ($data === false) {
        error_log("Failed to read image: " . $realPath);
        return '';
    }

    return 'data:image/' . $type . ';base64,' . base64_encode($data);
}



// Get user real ip
function getUserPublicIP()
{
    // List of headers to check in order of priority
    $headers = [
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'REMOTE_ADDR'
    ];

    foreach ($headers as $header) {
        if (array_key_exists($header, $_SERVER) === true) {
            foreach (explode(',', $_SERVER[$header]) as $ip) {
                $ip = trim($ip); // Remove whitespace

                // Validate the IP is a valid IPv4 or IPv6 and NOT a private/reserved range
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                    return $ip;
                }
            }
        }
    }

    // Fallback: If all else fails or we are on localhost, return REMOTE_ADDR
    return $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
}

// Function to format date
function formatDate(string $date)
{
    return date('d M Y', strtotime($date));
}

// Function to generate OTP
function generateOTP($length = 6)
{
    $otp = '';
    for ($i = 0; $i < $length; $i++) {
        $otp .= random_int(0, 9);  // cryptographically secure random digit
    }
    return $otp;
}

function encryptString(string $plainText, string $password): string
{
    $salt = random_bytes(16);

    // Password থেকে 32-byte key তৈরি
    $key = hash_pbkdf2(
        'sha256',
        $password,
        $salt,
        100000,
        32,
        true
    );

    $iv = random_bytes(16);

    $encrypted = openssl_encrypt(
        $plainText,
        'AES-256-CBC',
        $key,
        OPENSSL_RAW_DATA,
        $iv
    );

    // salt + iv + ciphertext
    return base64_encode($salt . $iv . $encrypted);
}

function decryptString(string $encryptedData, string $password): string|false
{
    $data = base64_decode($encryptedData);

    $salt = substr($data, 0, 16);
    $iv   = substr($data, 16, 16);
    $ciphertext = substr($data, 32);

    $key = hash_pbkdf2(
        'sha256',
        $password,
        $salt,
        100000,
        32,
        true
    );

    return openssl_decrypt(
        $ciphertext,
        'AES-256-CBC',
        $key,
        OPENSSL_RAW_DATA,
        $iv
    );
}


function convertNumberToWords(float $number) {
    $hyphen      = '-';
    $conjunction = ' and ';
    $separator   = ', ';
    $negative    = 'negative ';
    $decimal     = ' point ';
    $dictionary  = [
        0                   => 'zero',
        1                   => 'one',
        2                   => 'two',
        3                   => 'three',
        4                   => 'four',
        5                   => 'five',
        6                   => 'six',
        7                   => 'seven',
        8                   => 'eight',
        9                   => 'nine',
        10                  => 'ten',
        11                  => 'eleven',
        12                  => 'twelve',
        13                  => 'thirteen',
        14                  => 'fourteen',
        15                  => 'fifteen',
        16                  => 'sixteen',
        17                  => 'seventeen',
        18                  => 'eighteen',
        19                  => 'nineteen',
        20                  => 'twenty',
        30                  => 'thirty',
        40                  => 'forty',
        50                  => 'fifty',
        60                  => 'sixty',
        70                  => 'seventy',
        80                  => 'eighty',
        90                  => 'ninety',
        100                 => 'hundred',
        1000                => 'thousand',
        1000000             => 'million',
        1000000000          => 'billion',
        1000000000000       => 'trillion'
    ];

    if (!is_numeric($number)) {
        return false;
    }

    if ($number < 0) {
        return $negative . convertNumberToWords(abs($number));
    }

    $string = $fraction = null;

    if (strpos($number, '.') !== false) {
        list($number, $fraction) = explode('.', $number);
    }

    switch (true) {
        case $number < 21:
            $string = $dictionary[(int)$number];
            break;
        case $number < 100:
            $tens   = ((int)($number / 10)) * 10;
            $units  = $number % 10;
            $string = $dictionary[$tens];
            if ($units) {
                $string .= $hyphen . $dictionary[$units];
            }
            break;
        case $number < 1000:
            $hundreds  = $number / 100;
            $remainder = $number % 100;
            $string = $dictionary[(int)$hundreds] . ' ' . $dictionary[100];
            if ($remainder) {
                $string .= $conjunction . convertNumberToWords($remainder);
            }
            break;
        default:
            $baseUnit = pow(1000, floor(log($number, 1000)));
            $numBaseUnits = (int)($number / $baseUnit);
            $remainder = $number % $baseUnit;
            $string = convertNumberToWords($numBaseUnits) . ' ' . $dictionary[$baseUnit];
            if ($remainder) {
                $string .= $remainder < 100 ? $conjunction : $separator;
                $string .= convertNumberToWords($remainder);
            }
            break;
    }

    // Handle fractional part
    if (null !== $fraction && is_numeric($fraction) && (int)$fraction > 0) {
        $string .= $decimal;
        $words = [];
        foreach (str_split((string)$fraction) as $num) {
            $words[] = $dictionary[$num];
        }
        $string .= implode(' ', $words);
    }

    // Return string with first letter capitalized
    return $string;
}