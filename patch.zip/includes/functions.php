<?php
// Function to sanitize user input
function sanitize_input($data)
{
    return safe_htmlspecialchars(trim($data));
}

// Generate hex token for remember me feature
function generateToken()
{
    return bin2hex(random_bytes(32));
}

// Function to get the ratio of two numbers
function getRatioArray($num1, $num2)
{
    if ($num2 == 0) {
        return null; // or throw an error, depending on your use case
    }

    $gcd = function ($a, $b) use (&$gcd) {
        return ($b == 0) ? $a : $gcd($b, $a % $b);
    };

    $divisor = $gcd($num1, $num2);

    $ratio1 = $num1 / $divisor;
    $ratio2 = $num2 / $divisor;

    return [$ratio1, $ratio2];
}

// Function to check valid phone number
function isValidPhoneNumber($phone)
{
    // Check if the phone number is valid (example: 10 digits)
    return preg_match('/^\d{10}$/', $phone);
}

function isValidEmail($email)
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}


// Function to get color shades
function adjustColorShades($hex, $percent)
{
    // Remove "#" if present
    $hex = ltrim($hex, '#');

    // Convert hex to RGB
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));

    // Darken: decrease RGB values
    $dr = max(0, $r - ($r * $percent / 100));
    $dg = max(0, $g - ($g * $percent / 100));
    $db = max(0, $b - ($b * $percent / 100));
    $darker = sprintf("#%02x%02x%02x", $dr, $dg, $db);

    // Lighten: increase RGB values toward 255
    $lr = min(255, $r + ($percent / 100) * (255 - $r));
    $lg = min(255, $g + ($percent / 100) * (255 - $g));
    $lb = min(255, $b + ($percent / 100) * (255 - $b));
    $lighter = sprintf("#%02x%02x%02x", $lr, $lg, $lb);

    return [
        'darker' => $darker,
        'lighter' => $lighter
    ];
}


/**
 * Generate unique student ID
 */
function generateUniqueStudentId($pdo)
{
    do {
        $student_id = 'STU' . date('Y') . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE student_id = ?");
        $stmt->execute([$student_id]);
    } while ($stmt->fetchColumn() > 0);

    return $student_id;
}

// Validate image file function
function isValidateImageFile($imageFile)
{
    if (empty($imageFile) || !file_exists($imageFile)) {
        return false;
    }
    
    $imageInfo = @getimagesize($imageFile);
    if ($imageInfo == false) {
        return false; // Not a valid image or corrupted
    }

    switch ($imageInfo['mime']) {
        case 'image/jpeg':
            $img = @imagecreatefromjpeg($imageFile);
            break;
        case 'image/png':
            $img = @imagecreatefrompng($imageFile);
            break;
        default:
            return false; // Unsupported image type
    }

    if (!$img) {
        return false; // Failed to create image resource: likely corrupted
    }

    // Clean up
    imagedestroy($img);

    return true; // Passed all checks
}

/**
 * Students results rank function
 */
function getStudentPositionInClass(PDO $pdo, int $examId, int $classId, string $studentId): ?int {
    // Step 1: Fetch all results for the given exam and class
    $stmt = $pdo->prepare("SELECT student_id, obtained_marks 
                           FROM results 
                           WHERE exam_id = ? AND class_id = ? 
                           ORDER BY obtained_marks DESC");
    $stmt->execute([$examId, $classId]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Step 2: Rank students with tie handling
    $position = 0;
    $rank = 0;
    $lastMarks = null;

    foreach ($results as $row) {
        $position++;

        if ($lastMarks === null || $row['obtained_marks'] != $lastMarks) {
            $rank = $position;
            $lastMarks = $row['obtained_marks'];
        }

        if ($row['student_id'] === $studentId) {
            return $rank;
        }
    }

    // If student not found in results
    return null;
}

 /**
 * Send Firebase notification using a Node.js server
 * @param array $deviceTokens Array of device tokens
 * @param string $title Notification title
 * @param string $body Notification body
 * @param array $data Additional data to send with the notification
 * @return array Result of the notification send operation
 */
function sendFirebaseNotification($deviceTokens, $title, $body, $data = []) {
    $nodeServerUrl = 'https://fcm.dahukinfotech.com/send-notification-fast'; // Update with your Node server URL
    
    $payload = [
        'device_tokens' => $deviceTokens,
        'title' => $title,
        'body' => $body,
        'data' => $data
    ];
    
    $options = [
        'http' => [
            'header'  => "Content-type: application/json\r\n",
            'method'  => 'POST',
            'content' => json_encode($payload),
        ]
    ];
    
    $context  = stream_context_create($options);
    $result = file_get_contents($nodeServerUrl, false, $context);
    
    if ($result === FALSE) {
        return [
            'success' => false,
            'message' => 'Failed to connect to notification server'
        ];
    }
    
    return json_decode($result, true);
}

function getFCMTokensFromDatabase(PDO $pdo, array $studentIds): array {
    $fcmTokens = [];
    
    if (empty($studentIds) || !is_array($studentIds)) {
        return $fcmTokens;
    }

    foreach ($studentIds as $studentId) {
        $stmt = $pdo->prepare("SELECT phone_number FROM students WHERE student_id = ?");
        $stmt->execute([$studentId]);
        $phoneNumber = $stmt->fetchColumn();

        if (!$phoneNumber) {
            continue;
        }

        $stmt = $pdo->prepare("SELECT id FROM parent_accounts WHERE phone_number = ?");
        $stmt->execute([$phoneNumber]);
        $parent_id = $stmt->fetchColumn();

        if (!$parent_id) {
            continue;
        }

        $stmt = $pdo->prepare("SELECT fcm_token FROM parent_mobile_sessions WHERE parent_id = ?");
        $stmt->execute([$parent_id]);
        $tokens = $stmt->fetchAll(PDO::FETCH_COLUMN);

        if ($tokens) {
            $trimmedTokens = array_map('trim', $tokens);
            $fcmTokens = array_merge($fcmTokens, $trimmedTokens);
        }
    }

    // Remove any duplicates
    $fcmTokens = array_unique($fcmTokens);
    
    return array_values($fcmTokens); // Re-index the array
}

/**
 * Get the current version of the application
 * @return string Current version
 */
function getCurrentVersion(): string {
    $versionFile = __DIR__ . '/../updates/version.json';
    if (!file_exists($versionFile)) {
        return 'unknown';
    }

    $versionData = json_decode(file_get_contents($versionFile), true);
    return $versionData['version-code'] ?? 'unknown';
}
/**
 * Check for updates by comparing current version with the latest version
 * @return array Result of the update check
 */
function checkForUpdates(): array {
    $versionFile = __DIR__ . '/../updates/version.json';
    if (!file_exists($versionFile)) {
        return [
            'is_update_available' => false,
            'message' => 'Version file not found'
        ];
    }

    $versionData = json_decode(file_get_contents($versionFile), true);
    $currentVersion = $versionData['version-code'] ?? 'unknown';
    $versionCheckUrl = $versionData['version-check'] ?? null;

    if (!$versionCheckUrl) {
        return [
            'is_update_available' => false,
            'message' => 'Version check URL not defined'
        ];
    }

    $latestVersionData = json_decode(file_get_contents($versionCheckUrl), true);
    if (!$latestVersionData || !isset($latestVersionData['version-code'])) {
        return [
            'is_update_available' => false,
            'message' => 'Failed to fetch latest version data'
        ];
    }

    $latestVersion = $latestVersionData['version-code'];

    return [
        'current_version' => $currentVersion,
        'latest_version' => $latestVersion,
        'is_update_available' => version_compare($currentVersion, $latestVersion, '<'),
        'patch_url' => $latestVersionData['patch-url'] ?? null,
        'description' => $latestVersionData['description'] ?? 'No description available'
    ];
}

/**
 * Safely escape HTML special characters
 * @param string $input Input string to escape
 * @return string Escaped string
 */
function safe_htmlspecialchars($input = null) {
    if (empty($input)) {
        return '';
    }
    return str_replace("&amp;", "&", htmlspecialchars($input, ENT_QUOTES, 'UTF-8'));
}

// Function to get base64 of an image
function imageToBase64($path) {
    $realPath = realpath($path);
    if (!$realPath || !file_exists($realPath)) {
        error_log("Image not found: " . $path);
        return '';
    }
    
    $type = pathinfo($realPath, PATHINFO_EXTENSION);
    $data = file_get_contents($realPath);
    if ($data === false) {
        error_log("Failed to read image: " . $realPath);
        return '';
    }
    
    return 'data:image/' . $type . ';base64,' . base64_encode($data);
}