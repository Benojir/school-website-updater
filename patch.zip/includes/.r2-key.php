<?php
// Private encryption key; preserve with database backups.
return 'huDMvC3IAEwZU9LFlCc4KCWhqwqp3mAT24YMSVq5LJ4=';
