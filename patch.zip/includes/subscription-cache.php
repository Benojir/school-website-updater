<?php
require_once __DIR__ . '/subscription-policy.php';

function schoolSongiValidOverview($data, string $schoolId): bool
{
    return is_array($data)
        && ($data['school_id'] ?? null) === $schoolId
        && schoolSongiSubscriptionDate($data['subscription_end_at'] ?? null) !== null
        && isset($data['status']) && is_string($data['status'])
        && isset($data['current_subscription_total']) && is_numeric($data['current_subscription_total'])
        && (empty($data['subscription_payment_due_at'])
            || schoolSongiSubscriptionDate($data['subscription_payment_due_at']) !== null);
}

function schoolSongiFetchOverview(string $schoolId): ?array
{
    $key = defined('SCHOOLSONGI_PORTAL_KEY') ? SCHOOLSONGI_PORTAL_KEY : getenv('SCHOOLSONGI_PORTAL_KEY');
    if (!is_string($key) || !preg_match('/^[a-f0-9]{64}$/D', $key)) { return null; }
    $ch = curl_init('https://schoolsongi.com/api/get/fetch-school-overview.php?id=' . rawurlencode($schoolId));
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 10,
        CURLOPT_HTTPHEADER => ['X-Schoolsongi-Portal-Key: ' . $key]]);
    $response = curl_exec($ch);
    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $decoded = is_string($response) ? json_decode($response, true) : null;
    if ($status === 200 && is_array($decoded) && ($decoded['success'] ?? false) === true
        && schoolSongiValidOverview($decoded['data'] ?? null, $schoolId)) {
        return $decoded['data'];
    }
    return null;
}

/** Shared server cache: never read subscription state or timestamps from browser cookies. */
function schoolSongiCachedOverview(string $schoolId, string $cacheFile, ?callable $fetch = null, ?int $now = null): ?array
{
    $now = $now ?? time();
    $fetch = $fetch ?? 'schoolSongiFetchOverview';
    $handle = @fopen($cacheFile, 'c+');
    if (!$handle) {
        $data = $fetch($schoolId);
        return schoolSongiValidOverview($data, $schoolId) ? $data : null;
    }
    @chmod($cacheFile, 0600);
    if (!flock($handle, LOCK_EX)) {
        fclose($handle);
        $data = $fetch($schoolId);
        return schoolSongiValidOverview($data, $schoolId) ? $data : null;
    }
    try {
        $cache = json_decode(stream_get_contents($handle), true);
        $cache = is_array($cache) ? $cache : [];
        $data = $cache['data'] ?? null;
        $valid = schoolSongiValidOverview($data, $schoolId);
        $age = $now - (int) ($cache['fetched_at'] ?? 0);
        if (!$valid || $age < 0 || $age >= 60) {
            // On an outage, one retry every 15 seconds across all visitors.
            $attemptAge = $now - (int) ($cache['attempted_at'] ?? 0);
            if ($attemptAge < 0 || $attemptAge >= 15) {
                $fresh = $fetch($schoolId);
                $cache['attempted_at'] = $now;
                if (schoolSongiValidOverview($fresh, $schoolId)) {
                    $data = $fresh;
                    $cache['data'] = $data;
                    $cache['fetched_at'] = $now;
                    $valid = true;
                    $age = 0;
                }
                rewind($handle);
                ftruncate($handle, 0);
                fwrite($handle, json_encode($cache));
                fflush($handle);
            }
        }
        // Preserve known blocks even during an outage. Active schools have 24 hours of grace.
        $policyNow = new DateTimeImmutable('@' . $now);
        if ($valid && $age >= 0 && ($age <= 86400 || schoolSongiSubscriptionPolicy($data, $policyNow)['access_blocked'])) {
            return $data;
        }
        return null;
    } finally {
        flock($handle, LOCK_UN);
        fclose($handle);
    }
}
