<?php

require_once __DIR__ . '/../academic/student-academic-service.php';

function getStudentInfo(PDO $pdo, string $student_id, ?string $academic_year = null)
{
    $student_info = academicGetStudent($pdo, $student_id, $academic_year);

    if ($student_info) {
        $class_id = $student_info['class_id'];
        $class_fee = getClassFee($class_id);
        $custom_fee = $student_info['custom_class_fee'] ?? 0;
        $tution_fee = $custom_fee > 0 ? $custom_fee : $class_fee;

        $student_info['class_fee'] = (string) $class_fee;
        $student_info['tution_fee'] = (string) $tution_fee;

        return $student_info;
    } else {
        return null;
    }
}
