<?php

function getStudentInfo(PDO $pdo, string $student_id)
{
    $stmt = $pdo->prepare("SELECT s.*, c.class_name, sec.section_name
                            FROM students s
                            LEFT JOIN classes c ON s.class_id = c.id
                            LEFT JOIN sections sec ON s.section_id = sec.id
                            WHERE s.student_id = ?");

    $stmt->execute([$student_id]);
    $student_info = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($student_info) {
        $class_id = $student_info['class_id'];
        $class_fee = getClassFee($class_id);
        $custom_fee = $student_info['custom_class_fee'] ?? 0;
        $tution_fee = $custom_fee > 0 ? $custom_fee : $class_fee;

        $student_info['class_fee'] = (string) $class_fee;
        $student_info['tution_fee'] = (string) $tution_fee;

        return $student_info;
    } else {
        return null;
    }
}
