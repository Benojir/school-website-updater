<?php
require_once __DIR__ . '/../academic/student-academic-service.php';

/**
 * Permanently remove student profiles and their operational records.
 *
 * Academic records use a restrictive foreign key, so they must be removed
 * explicitly. Attendance, results, fees, wallet data and permissions are then
 * removed by their existing ON DELETE CASCADE constraints. Immutable migration
 * snapshots and independent audit/stock ledgers are intentionally retained.
 *
 * @return array{deleted_count:int, images:array<int,string>}
 */
function deleteStudentsCompletely(PDO $pdo, array $studentIds): array
{
    $studentIds = array_values(array_unique(array_filter(array_map(
        static fn($id) => is_scalar($id) ? trim((string)$id) : '',
        $studentIds
    ), static fn($id) => $id !== '')));

    if (!$studentIds) throw new InvalidArgumentException('No valid student IDs provided.');

    return academicTransaction($pdo, function () use ($pdo, $studentIds) {
        academicLockSettings($pdo);

        $selectStudent = $pdo->prepare('SELECT id, student_id, student_image FROM students WHERE student_id = ? FOR UPDATE');
        $deleteAcademicRecords = $pdo->prepare('DELETE FROM student_academic_records WHERE student_row_id = ?');
        $deleteStudent = $pdo->prepare('DELETE FROM students WHERE id = ?');
        $imageStillUsed = $pdo->prepare('SELECT COUNT(*) FROM students WHERE student_image = ?');

        $deletedCount = 0;
        $images = [];

        foreach ($studentIds as $studentId) {
            $selectStudent->execute([$studentId]);
            $student = $selectStudent->fetch(PDO::FETCH_ASSOC);
            if (!$student) continue;

            $deleteAcademicRecords->execute([(int)$student['id']]);
            $deleteStudent->execute([(int)$student['id']]);
            if ($deleteStudent->rowCount() !== 1) {
                throw new RuntimeException('Student ' . $studentId . ' could not be deleted. No changes were saved.');
            }
            $deletedCount++;

            $image = trim((string)($student['student_image'] ?? ''));
            if ($image === '' || strcasecmp($image, 'default_student_dp.jpg') === 0 || basename($image) !== $image) continue;
            $imageStillUsed->execute([$image]);
            if ((int)$imageStillUsed->fetchColumn() === 0) $images[] = $image;
        }

        return ['deleted_count' => $deletedCount, 'images' => array_values(array_unique($images))];
    });
}

