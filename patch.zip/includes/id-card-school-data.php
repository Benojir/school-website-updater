<?php
// School Info fields shared by the student, teacher, driver and admit-card builders.
function idCardSchoolFields(): array
{
    return [
        'school_name' => ['School Name', null],
        'school_address' => ['School Address', null],
        'school_contact_no' => ['School Contact No', null],
        'school_village' => ['School Village / Town', null],
        'school_post_office' => ['School Post Office', null],
        'school_police_station' => ['School Police Station', null],
        'school_district' => ['School District', null],
        'school_pin_code' => ['School PIN Code', null],
        'school_phone' => ['School Phone Number', null],
        'school_alternate_phone' => ['School Alternative Phone Number', null],
    ];
}

function idCardSchoolPayload(array $school): array
{
    $parts = [
        'school_village' => trim((string) ($school['village'] ?? '')),
        'school_post_office' => trim((string) ($school['post_office'] ?? '')),
        'school_police_station' => trim((string) ($school['police_station'] ?? '')),
        'school_district' => trim((string) ($school['district'] ?? '')),
        'school_pin_code' => trim((string) ($school['pincode'] ?? '')),
    ];
    $phone = trim((string) ($school['phone'] ?? ''));
    $alternatePhone = trim((string) ($school['alternate_phone'] ?? ''));
    $address = implode(', ', array_filter($parts, static fn($value) => $value !== ''));
    return [
        'school_name' => (string) ($school['name'] ?? ''),
        'school_address' => $address !== '' ? $address : trim((string) ($school['address'] ?? '')),
        'school_contact_no' => implode(' / ', array_filter([$phone, $alternatePhone], static fn($value) => $value !== '')),
        ...$parts,
        'school_phone' => $phone,
        'school_alternate_phone' => $alternatePhone,
    ];
}
