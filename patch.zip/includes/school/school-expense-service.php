<?php
// Standalone service: callers provide their authenticated PDO connection and uploader.
class SchoolExpenseConflict extends RuntimeException {}
class SchoolExpenseNotFound extends RuntimeException {}
class SchoolExpenseUploadError extends RuntimeException {}

function schoolExpenseText(mixed $value, int $length, string $label, bool $required = false): string
{
    if (!is_string($value) || preg_match('//u', $value) !== 1) throw new InvalidArgumentException("Invalid {$label}.");
    $value = trim($value);
    if (($required && $value === '') || mb_strlen($value, 'UTF-8') > $length) {
        throw new InvalidArgumentException("{$label} " . ($value === '' ? 'is required.' : "must be at most {$length} characters."));
    }
    return $value;
}

function schoolExpenseInteger(mixed $value, string $label, int $min = 1, int $max = 4294967295): int
{
    if ((!is_int($value) && !is_string($value)) || !preg_match('/^\d{1,10}$/D', (string)$value)) {
        throw new InvalidArgumentException("Invalid {$label}.");
    }
    $number = (int)$value;
    if ($number < $min || $number > $max) throw new InvalidArgumentException("Invalid {$label}.");
    return $number;
}

function schoolExpenseMoney(mixed $value): int
{
    // Never parse accounting amounts through floating point.
    if (!is_string($value) || !preg_match('/^(\d{1,9})(?:\.(\d{1,2}))?$/D', trim($value), $parts)) {
        throw new InvalidArgumentException('Enter a valid amount with at most two decimal places (maximum 999999999.99).');
    }
    $paise = (int)$parts[1] * 100 + (int)str_pad($parts[2] ?? '', 2, '0');
    if ($paise < 1) throw new InvalidArgumentException('Amount must be greater than zero.');
    return $paise;
}

function schoolExpenseDate(mixed $value, bool $required = false): string
{
    $value = schoolExpenseText($value, 10, 'Date', $required);
    if ($value === '') return '';
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    if (!$date || $date->format('Y-m-d') !== $value || $value < '1900-01-01') {
        throw new InvalidArgumentException('Choose a valid date in YYYY-MM-DD format.');
    }
    return $value;
}

function schoolExpenseReceipt(array $file): ?array
{
    $error = $file['error'] ?? UPLOAD_ERR_NO_FILE;
    if ($error === UPLOAD_ERR_NO_FILE) return null;
    if ($error !== UPLOAD_ERR_OK) throw new InvalidArgumentException('The bill image could not be received. Upload an image up to 5 MB.');
    $path = $file['tmp_name'] ?? null;
    if (!is_string($path) || !is_file($path)) throw new InvalidArgumentException('Invalid bill image.');
    $size = filesize($path);
    if ($size === false || $size < 1 || $size > 5 * 1024 * 1024) throw new InvalidArgumentException('Bill images must be no larger than 5 MB.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($path);
    if (!in_array($mime, ['image/jpeg', 'image/png', 'image/gif', 'image/webp'], true) || @getimagesize($path) === false) {
        throw new InvalidArgumentException('Choose a valid JPG, PNG, GIF or WebP bill image.');
    }
    return ['path' => $path, 'hash' => hash_file('sha256', $path), 'mime' => $mime];
}

function schoolExpenseBillUrl(mixed $url): ?string
{
    if (!is_string($url) || strlen($url) > 1000) return null;
    $parts = parse_url($url);
    return is_array($parts) && ($parts['scheme'] ?? '') === 'https' &&
        in_array(strtolower($parts['host'] ?? ''), ['i.ibb.co', 'ibb.co'], true) &&
        !isset($parts['user']) && !isset($parts['pass']) ? $url : null;
}

function schoolExpenseCsvCell(string $value): string
{
    // Prevent spreadsheet formulas in user-controlled category, payee and note text.
    return preg_match('/^[\s\x00-\x1f]*[=+@-]/u', $value) ? "'" . $value : $value;
}

class SchoolExpenseService
{
    public function __construct(private PDO $pdo, private int $actorId, private string $actorName, private mixed $uploader = null) {}

    private function query(string $sql, array $params = []): PDOStatement
    {
        $statement = $this->pdo->prepare($sql);
        $statement->execute($params);
        return $statement;
    }

    public function categories(): array
    {
        $rows = $this->query('SELECT c.id, c.name, c.is_active, c.version, COUNT(e.id) AS expense_count
            FROM school_expense_categories c LEFT JOIN school_expenses e ON e.category_id=c.id AND e.deleted_at IS NULL
            GROUP BY c.id, c.name, c.is_active, c.version ORDER BY c.is_active DESC, c.name ASC')->fetchAll(PDO::FETCH_ASSOC);
        return array_map(function ($row) {
            foreach (['id', 'is_active', 'version', 'expense_count'] as $key) $row[$key] = (int)$row[$key];
            return $row;
        }, $rows);
    }

    private function filters(array $input): array
    {
        $from = schoolExpenseDate($input['from'] ?? '');
        $to = schoolExpenseDate($input['to'] ?? '');
        if ($from !== '' && $to !== '' && $from > $to) throw new InvalidArgumentException('From date must be on or before To date.');
        $category = schoolExpenseInteger($input['category_id'] ?? 0, 'category', 0);
        $search = schoolExpenseText($input['search'] ?? '', 150, 'Search');
        $sort = $input['sort'] ?? 'date_desc';
        $orders = ['date_desc' => 'e.expense_date DESC, e.id DESC', 'date_asc' => 'e.expense_date ASC, e.id ASC',
            'amount_desc' => 'e.amount_paise DESC, e.id DESC', 'amount_asc' => 'e.amount_paise ASC, e.id DESC'];
        if (!is_string($sort) || !isset($orders[$sort])) throw new InvalidArgumentException('Choose a valid sort order.');
        $where = ['e.deleted_at IS NULL'];
        $params = [];
        if ($from !== '') { $where[] = 'e.expense_date >= ?'; $params[] = $from; }
        if ($to !== '') { $where[] = 'e.expense_date <= ?'; $params[] = $to; }
        if ($category) { $where[] = 'e.category_id = ?'; $params[] = $category; }
        if ($search !== '') {
            $where[] = "(c.name LIKE ? ESCAPE '=' OR e.payee LIKE ? ESCAPE '=' OR e.note LIKE ? ESCAPE '='
                OR CAST(e.expense_date AS CHAR) LIKE ? ESCAPE '=' OR CAST(e.amount_paise / 100 AS DECIMAL(12,2)) LIKE ? ESCAPE '=')";
            $needle = '%' . strtr($search, ['=' => '==', '%' => '=%', '_' => '=_']) . '%';
            array_push($params, $needle, $needle, $needle, $needle, $needle);
        }
        return ['where' => implode(' AND ', $where), 'params' => $params, 'order' => $orders[$sort],
            'applied' => ['from' => $from, 'to' => $to, 'category_id' => $category, 'search' => $search, 'sort' => $sort]];
    }

    private function row(array $row): array
    {
        foreach (['id', 'category_id', 'version'] as $key) $row[$key] = (int)$row[$key];
        $row['amount_paise'] = (string)$row['amount_paise'];
        $row['bill_url'] = schoolExpenseBillUrl($row['bill_url'] ?? null);
        return $row;
    }

    private function selectRows(): string
    {
        return 'SELECT e.id, e.category_id, c.name AS category_name, c.is_active AS category_active,
            e.amount_paise, e.expense_date, e.payee, e.note, e.bill_url, e.version,
            e.created_by_name, e.created_at, e.updated_at, e.deleted_at
            FROM school_expenses e JOIN school_expense_categories c ON c.id=e.category_id';
    }

    public function report(array $input): array
    {
        // Keep the filtered totals, category breakdown and page in one read snapshot.
        $this->pdo->beginTransaction();
        try {
            $report = $this->readReport($input);
            $this->pdo->commit();
            return $report;
        } catch (Throwable $error) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            throw $error;
        }
    }

    private function readReport(array $input): array
    {
        $filter = $this->filters($input);
        $join = ' FROM school_expenses e JOIN school_expense_categories c ON c.id=e.category_id WHERE ' . $filter['where'];
        $summary = $this->query("SELECT COUNT(*) AS entry_count, COALESCE(SUM(e.amount_paise),0) AS total_paise,
            COALESCE(MAX(e.amount_paise),0) AS largest_paise, COALESCE(SUM(e.bill_url IS NOT NULL AND e.bill_url <> ''),0) AS receipt_count" . $join, $filter['params'])->fetch(PDO::FETCH_ASSOC);
        $summary['entry_count'] = (int)$summary['entry_count'];
        $summary['receipt_count'] = (int)$summary['receipt_count'];
        $summary['total_paise'] = (string)$summary['total_paise'];
        $summary['largest_paise'] = (string)$summary['largest_paise'];
        $perPage = schoolExpenseInteger($input['per_page'] ?? 25, 'page size', 1, 100);
        if (!in_array($perPage, [10, 25, 50, 100], true)) throw new InvalidArgumentException('Choose 10, 25, 50 or 100 entries per page.');
        $pages = max(1, (int)ceil($summary['entry_count'] / $perPage));
        $page = min(schoolExpenseInteger($input['page'] ?? 1, 'page'), $pages);
        $offset = ($page - 1) * $perPage;
        $rows = $this->query($this->selectRows() . ' WHERE ' . $filter['where'] . ' ORDER BY ' . $filter['order'] . " LIMIT {$perPage} OFFSET {$offset}", $filter['params'])->fetchAll(PDO::FETCH_ASSOC);
        $breakdown = $this->query('SELECT c.id AS category_id, c.name AS category_name, COUNT(*) AS entry_count, SUM(e.amount_paise) AS total_paise' .
            $join . ' GROUP BY c.id, c.name ORDER BY total_paise DESC, c.name ASC', $filter['params'])->fetchAll(PDO::FETCH_ASSOC);
        foreach ($breakdown as &$group) {
            $group['category_id'] = (int)$group['category_id'];
            $group['entry_count'] = (int)$group['entry_count'];
            $group['total_paise'] = (string)$group['total_paise'];
        }
        unset($group);
        return ['rows' => array_map(fn($row) => $this->row($row), $rows), 'summary' => $summary, 'breakdown' => $breakdown,
            'page' => $page, 'pages' => $pages, 'per_page' => $perPage, 'filters' => $filter['applied']];
    }

    public function export(array $input): PDOStatement
    {
        $filter = $this->filters($input);
        return $this->query($this->selectRows() . ' WHERE ' . $filter['where'] . ' ORDER BY ' . $filter['order'], $filter['params']);
    }

    public function detail(int $id): array
    {
        $row = $this->query($this->selectRows() . ' WHERE e.id=?', [$id])->fetch(PDO::FETCH_ASSOC);
        if (!$row) throw new SchoolExpenseNotFound('This expense no longer exists. Refresh the list.');
        $history = $this->query('SELECT action_name, actor_name, before_json, after_json, created_at
            FROM school_expense_audit WHERE expense_id=? ORDER BY id DESC', [$id])->fetchAll(PDO::FETCH_ASSOC);
        foreach ($history as &$event) {
            $event['before'] = $event['before_json'] ? json_decode($event['before_json'], true, 32, JSON_THROW_ON_ERROR) : null;
            $event['after'] = json_decode($event['after_json'], true, 32, JSON_THROW_ON_ERROR);
            unset($event['before_json'], $event['after_json']);
        }
        unset($event);
        return ['expense' => $this->row($row), 'history' => $history];
    }

    public function write(array $input, ?array $receipt = null): array
    {
        $action = $input['action'] ?? '';
        if (!in_array($action, ['category_save', 'category_status', 'expense_save', 'expense_remove'], true)) throw new InvalidArgumentException('Unknown expense action.');
        $key = $input['request_key'] ?? '';
        if (!is_string($key) || !preg_match('/^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/iD', $key)) {
            throw new InvalidArgumentException('Please reopen the form and try again.');
        }
        if ($receipt !== null && $action !== 'expense_save') throw new InvalidArgumentException('Bill images belong to expenses only.');
        ksort($input);
        $hash = hash('sha256', json_encode([$input, $receipt['hash'] ?? null], JSON_THROW_ON_ERROR));
        $this->pdo->beginTransaction();
        try {
            // This unique claim serializes simultaneous retries, including bill uploads.
            $this->query('INSERT INTO school_expense_requests (request_key, actor_id, payload_hash, created_at) VALUES (?, ?, ?, ?)',
                [$key, $this->actorId, $hash, date('Y-m-d H:i:s')]);
            $result = match ($action) {
                'category_save', 'category_status' => $this->saveCategory($input, $action),
                'expense_save' => $this->saveExpense($input, $receipt),
                'expense_remove' => $this->removeExpense($input)
            };
            $this->query('UPDATE school_expense_requests SET result_json=? WHERE request_key=?', [json_encode($result, JSON_THROW_ON_ERROR), $key]);
            $this->pdo->commit();
            return $result;
        } catch (Throwable $error) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            if ($error instanceof PDOException && ($error->errorInfo[1] ?? null) == 1062) {
                $previous = $this->query('SELECT actor_id, payload_hash, result_json FROM school_expense_requests WHERE request_key=?', [$key])->fetch(PDO::FETCH_ASSOC);
                if ($previous) {
                    if ((int)$previous['actor_id'] !== $this->actorId || !hash_equals($previous['payload_hash'], $hash)) {
                        throw new SchoolExpenseConflict('This form was already saved with different details. Refresh the list before adding another expense.');
                    }
                    return json_decode($previous['result_json'], true, 32, JSON_THROW_ON_ERROR);
                }
                throw new InvalidArgumentException('A category with this name already exists. Choose a different name.');
            }
            throw $error;
        }
    }

    private function category(int $id): array
    {
        $category = $this->query('SELECT id, name, is_active, version FROM school_expense_categories WHERE id=? FOR UPDATE', [$id])->fetch(PDO::FETCH_ASSOC);
        if (!$category) throw new InvalidArgumentException('Select a valid expense category.');
        return $category;
    }

    private function saveCategory(array $input, string $action): array
    {
        $id = schoolExpenseInteger($input['id'] ?? 0, 'category', $action === 'category_status' ? 1 : 0);
        $now = date('Y-m-d H:i:s');
        $category = $id ? $this->category($id) : null;
        if ($category && (int)$category['version'] !== schoolExpenseInteger($input['version'] ?? 0, 'category version')) {
            throw new SchoolExpenseConflict('This category changed while you were editing. Refresh and try again.');
        }
        $name = $action === 'category_status' ? $category['name'] : schoolExpenseText($input['name'] ?? '', 120, 'Category name', true);
        $name = preg_replace('/\s+/u', ' ', $name);
        $active = $action === 'category_status' ? schoolExpenseInteger($input['is_active'] ?? 1, 'category status', 0, 1) : (int)($category['is_active'] ?? 1);
        if ($id) {
            $this->query('UPDATE school_expense_categories SET name=?, is_active=?, version=version+1, updated_at=? WHERE id=?', [$name, $active, $now, $id]);
        } else {
            $this->query('INSERT INTO school_expense_categories (name, is_active, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?)', [$name, $active, $this->actorId, $now, $now]);
            $id = (int)$this->pdo->lastInsertId();
        }
        return ['id' => $id, 'message' => $action === 'category_status' ? ($active ? 'Category restored.' : 'Category archived. Existing expenses stay in reports.') : 'Category saved.'];
    }

    private function lockExpense(array $input): array
    {
        $id = schoolExpenseInteger($input['id'] ?? 0, 'expense');
        $expense = $this->query($this->selectRows() . ' WHERE e.id=? FOR UPDATE', [$id])->fetch(PDO::FETCH_ASSOC);
        if (!$expense || $expense['deleted_at'] !== null) throw new SchoolExpenseNotFound('This expense has already been removed. Refresh the list.');
        if ((int)$expense['version'] !== schoolExpenseInteger($input['version'] ?? 0, 'expense version')) {
            throw new SchoolExpenseConflict('This expense changed while you were editing. Refresh the list before saving.');
        }
        return $this->row($expense);
    }

    private function saveExpense(array $input, ?array $receipt): array
    {
        $id = schoolExpenseInteger($input['id'] ?? 0, 'expense', 0);
        $amount = schoolExpenseMoney($input['amount'] ?? '');
        $date = schoolExpenseDate($input['date'] ?? '', true);
        if ($date > date('Y-m-d')) throw new InvalidArgumentException('Expense date cannot be in the future.');
        $payee = schoolExpenseText($input['payee'] ?? '', 150, 'Paid to / place');
        $note = schoolExpenseText($input['note'] ?? '', 2000, 'Note');
        $remove = schoolExpenseInteger($input['remove_receipt'] ?? 0, 'bill removal', 0, 1);
        if ($remove && $receipt) throw new InvalidArgumentException('Choose either a replacement bill or Remove bill.');
        $before = $id ? $this->lockExpense($input) : null;
        $categoryId = schoolExpenseInteger($input['category_id'] ?? 0, 'category');
        $category = $this->category($categoryId);
        if (!(int)$category['is_active'] && (!$before || $before['category_id'] !== $categoryId)) {
            throw new InvalidArgumentException('This category is archived. Restore it or choose an active category.');
        }
        $bill = $remove ? null : ($before['bill_url'] ?? null);
        if ($receipt) {
            if (!is_callable($this->uploader)) throw new SchoolExpenseUploadError('Bill upload is unavailable. Try again or save without an image.');
            try {
                $uploaded = ($this->uploader)($receipt['path']);
            } catch (Throwable $error) {
                throw new SchoolExpenseUploadError('The bill could not be uploaded to ImgBB. Try again or save without an image.', 0, $error);
            }
            $bill = !empty($uploaded['success']) ? schoolExpenseBillUrl($uploaded['url'] ?? null) : null;
            if (!$bill) throw new SchoolExpenseUploadError('The bill could not be uploaded to ImgBB. Try again or save without an image.');
        }
        $now = date('Y-m-d H:i:s');
        $values = [$categoryId, $amount, $date, $payee, $note, $bill];
        if ($id) {
            $this->query('UPDATE school_expenses SET category_id=?, amount_paise=?, expense_date=?, payee=?, note=?, bill_url=?, version=version+1, updated_at=? WHERE id=?', [...$values, $now, $id]);
        } else {
            $this->query('INSERT INTO school_expenses (category_id, amount_paise, expense_date, payee, note, bill_url, created_by, created_by_name, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [...$values, $this->actorId, $this->actorName, $now, $now]);
            $id = (int)$this->pdo->lastInsertId();
        }
        $after = ['id' => $id, 'category_id' => $categoryId, 'category_name' => $category['name'], 'amount_paise' => (string)$amount,
            'expense_date' => $date, 'payee' => $payee, 'note' => $note, 'bill_url' => $bill,
            'version' => ($before['version'] ?? 0) + 1, 'updated_at' => $now, 'deleted_at' => null];
        $this->audit($id, $before ? 'updated' : 'created', $before, $after);
        return ['id' => $id, 'message' => $before ? 'Expense updated.' : 'Expense saved.'];
    }

    private function removeExpense(array $input): array
    {
        $before = $this->lockExpense($input);
        $now = date('Y-m-d H:i:s');
        $this->query('UPDATE school_expenses SET deleted_at=?, deleted_by=?, version=version+1, updated_at=? WHERE id=?', [$now, $this->actorId, $now, $before['id']]);
        $after = $before;
        $after['deleted_at'] = $now;
        $after['updated_at'] = $now;
        $after['version']++;
        $this->audit($before['id'], 'removed', $before, $after);
        return ['id' => $before['id'], 'message' => 'Expense removed from totals. Its history has been retained.'];
    }

    private function audit(int $id, string $action, ?array $before, array $after): void
    {
        $this->query('INSERT INTO school_expense_audit (expense_id, action_name, actor_id, actor_name, before_json, after_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [$id, $action, $this->actorId, $this->actorName, $before ? json_encode($before, JSON_THROW_ON_ERROR) : null,
                json_encode($after, JSON_THROW_ON_ERROR), date('Y-m-d H:i:s')]);
    }
}
