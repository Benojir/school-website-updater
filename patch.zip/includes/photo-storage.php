<?php
require_once __DIR__ . '/r2-client.php';

function schoolPhotoCategories(): array
{
    return ['students' => ['students', 'student_image', 'default_student_dp.jpg'],
        'fathers' => ['students', 'father_image', 'default_father_dp.jpg'],
        'mothers' => ['students', 'mother_image', 'default_mother_dp.jpg'],
        'teachers' => ['teachers', 'teacher_image', 'default_teacher_dp.jpg'],
        'drivers' => ['drivers', 'driver_image', 'default_driver_dp.jpg']];
}

function schoolPhotoValidName(string $category, string $filename): bool
{
    return isset(schoolPhotoCategories()[$category]) && preg_match('/^[a-zA-Z0-9_-][a-zA-Z0-9_.-]{0,190}\.(?:jpe?g|png|gif|webp)$/iD', $filename)
        && !str_contains($filename, '..');
}

function schoolPhotoIsDefault(string $filename): bool { return str_starts_with(strtolower($filename), 'default_'); }

function schoolPhotoPathParts(string $path): ?array
{
    if (!preg_match('~/uploads/(students|fathers|mothers|teachers|drivers)/([^/]+)$~', str_replace('\\', '/', $path), $match)) return null;
    return schoolPhotoValidName($match[1], $match[2]) ? [$match[1], $match[2]] : null;
}

function schoolPhotoLocalPath(string $category, string $filename): string
{
    if (!schoolPhotoValidName($category, $filename)) throw new InvalidArgumentException('Invalid photo filename.');
    return dirname(__DIR__) . '/uploads/' . $category . '/' . $filename;
}

function schoolR2Key(): string
{
    $env = getenv('SCHOOL_R2_ENCRYPTION_KEY');
    if ($env !== false && $env !== '') {
        $key = base64_decode($env, true);
        if ($key === false || strlen($key) !== 32) throw new RuntimeException('SCHOOL_R2_ENCRYPTION_KEY must contain a base64 encoded 32 byte key.');
        return $key;
    }
    $path = __DIR__ . '/.r2-key.php';
    $handle = @fopen($path, 'c+');
    if (!$handle || !flock($handle, LOCK_EX)) throw new RuntimeException('Set SCHOOL_R2_ENCRYPTION_KEY or make the R2 key file writable to save credentials.');
    try {
        $content = stream_get_contents($handle);
        if ($content === '') {
            $content = "<?php\n// Private encryption key; preserve with database backups.\nreturn '" . base64_encode(random_bytes(32)) . "';\n";
            if (fwrite($handle, $content) !== strlen($content)) throw new RuntimeException('Could not save R2 encryption key.');
            fflush($handle);
            @chmod($path, 0600);
        }
    } finally { flock($handle, LOCK_UN); fclose($handle); }
    if (!preg_match("/return '([a-zA-Z0-9+\/=]+)';/", $content, $match)) throw new RuntimeException('Invalid R2 encryption key file. Restore it from your backup.');
    $key = base64_decode($match[1], true);
    if ($key === false || strlen($key) !== 32) throw new RuntimeException('Invalid R2 encryption key file. Restore it from your backup.');
    return $key;
}

function schoolR2Encrypt(string $secret): string
{
    $iv = random_bytes(12);
    $encrypted = openssl_encrypt($secret, 'aes-256-gcm', schoolR2Key(), OPENSSL_RAW_DATA, $iv, $tag);
    if ($encrypted === false) throw new RuntimeException('Could not encrypt R2 credentials.');
    return base64_encode($iv . $tag . $encrypted);
}

function schoolR2Decrypt(string $encrypted): string
{
    $bytes = base64_decode($encrypted, true);
    if ($bytes === false || strlen($bytes) < 29) throw new RuntimeException('R2 secret is missing. Save the R2 secret in Website Configuration.');
    $plain = openssl_decrypt(substr($bytes, 28), 'aes-256-gcm', schoolR2Key(), OPENSSL_RAW_DATA, substr($bytes, 0, 12), substr($bytes, 12, 16));
    if ($plain === false) throw new RuntimeException('Cannot decrypt R2 secret. Restore the original encryption key or save the secret again.');
    return $plain;
}

/** Preserve the complete tenant ID; never slugify/truncate distinct school IDs. */
function schoolR2SchoolPrefix(?string $fullSchoolId = null): string
{
    if ($fullSchoolId === null) {
        if (!defined('FULL_SCHOOL_ID')) throw new RuntimeException('FULL_SCHOOL_ID must be defined in includes/db.php before using R2.');
        $fullSchoolId = (string)FULL_SCHOOL_ID;
    }
    if (!preg_match('/^[a-zA-Z0-9_-][a-zA-Z0-9_.-]*$/D', $fullSchoolId) || str_contains($fullSchoolId, '..') || strlen($fullSchoolId) > 512) {
        throw new RuntimeException('FULL_SCHOOL_ID must contain letters, numbers, dots, hyphens or underscores and be at most 512 characters.');
    }
    return $fullSchoolId;
}

function schoolR2Validate(array $input): array
{
    $account = trim((string)($input['r2_account_id'] ?? ''));
    $bucket = trim((string)($input['r2_bucket'] ?? ''));
    $prefix = trim((string)($input['r2_prefix'] ?? ''), " /\t\r\n");
    $endpoint = rtrim(trim((string)($input['r2_endpoint'] ?? '')), '/');
    if (!preg_match('/^[a-f0-9]{32}$/iD', $account)) throw new InvalidArgumentException('Enter a valid 32 character R2 Account ID.');
    if (!preg_match('/^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$/D', $bucket)) throw new InvalidArgumentException('Enter a valid R2 bucket name.');
    if (!preg_match('~^[a-zA-Z0-9_-][a-zA-Z0-9_.-]*(?:/[a-zA-Z0-9_-][a-zA-Z0-9_.-]*)*$~D', $prefix) || str_contains($prefix, '..') || strlen($prefix) > 512) throw new InvalidArgumentException('Invalid R2 school prefix (maximum 512 characters).');
    if ($endpoint === '') $endpoint = 'https://' . $account . '.r2.cloudflarestorage.com';
    if (!preg_match('~^https://' . preg_quote($account, '~') . '(?:\.(?:eu|fedramp|us))?\.r2\.cloudflarestorage\.com$~iD', $endpoint)) throw new InvalidArgumentException('Use the R2 S3 endpoint for this Account ID.');
    $access = trim((string)($input['r2_access_key_id'] ?? ''));
    if (!preg_match('/^[a-zA-Z0-9]{16,128}$/D', $access)) throw new InvalidArgumentException('Enter the R2 S3 Access Key ID.');
    $secret = (string)($input['secret'] ?? '');
    if ($secret === '' || strlen($secret) > 256 || preg_match('/\s/', $secret)) throw new InvalidArgumentException('Enter the R2 S3 Secret Access Key.');
    return compact('account', 'bucket', 'prefix', 'endpoint', 'access', 'secret');
}

function schoolR2Config(): array
{
    $config = $GLOBALS['websiteConfig'] ?? [];
    // Saved object keys retain their original prefix; all new keys use this tenant ID.
    $config['r2_prefix'] = schoolR2SchoolPrefix();
    $config['secret'] = schoolR2Decrypt((string)($config['r2_secret_access_key'] ?? ''));
    return schoolR2Validate($config);
}

function schoolR2Client(?array $object = null): SchoolR2Client
{
    $config = schoolR2Config();
    if ($object) { $config['endpoint'] = $object['endpoint']; $config['bucket'] = $object['bucket']; }
    return new SchoolR2Client($config);
}

function schoolPhotoObject(string $category, string $filename): ?array
{
    if (!schoolPhotoValidName($category, $filename) || schoolPhotoIsDefault($filename)) return null;
    $stmt = $GLOBALS['pdo']->prepare('SELECT * FROM school_photo_objects WHERE category = ? AND filename = ?');
    if (!$stmt->execute([$category, $filename])) throw new RuntimeException('Could not load photo registry.');
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

function schoolPhotoReferenced(string $category, string $filename): bool
{
    [$table, $field] = schoolPhotoCategories()[$category];
    $stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM $table WHERE $field = ?");
    $stmt->execute([$filename]);
    if ((int)$stmt->fetchColumn() > 0) return true;
    if ($category === 'students') {
        $stmt = $GLOBALS['pdo']->prepare('SELECT COUNT(*) FROM admission_enquiries WHERE student_image = ?');
        $stmt->execute([$filename]);
        return (int)$stmt->fetchColumn() > 0;
    }
    return false;
}

/** New files are unique; failed forms are cleaned after their transaction ends. */
function schoolPhotoStoreBytes(string $destination, string $bytes, ?SchoolR2Client $client = null): int
{
    $parts = schoolPhotoPathParts($destination);
    if (!$parts || schoolPhotoIsDefault($parts[1])) throw new InvalidArgumentException('Invalid photo destination.');
    if (strlen($bytes) > 10 * 1024 * 1024 || !$info = @getimagesizefromstring($bytes)) throw new InvalidArgumentException('Photo must be a valid image of at most 10 MB.');
    if (!in_array($info['mime'], ['image/jpeg', 'image/png', 'image/gif', 'image/webp'], true)) throw new InvalidArgumentException('Unsupported photo format.');
    [$category, $filename] = $parts;
    if (empty($GLOBALS['websiteConfig']['r2_enabled'])) {
        $path = schoolPhotoLocalPath($category, $filename);
        if (!is_dir(dirname($path))) mkdir(dirname($path), 0755, true);
        $written = file_put_contents($path, $bytes, LOCK_EX);
        if ($written !== strlen($bytes)) throw new RuntimeException('Could not save photo.');
        return $written;
    }
    $config = schoolR2Config();
    $key = $config['prefix'] . '/' . $category . '/' . $filename;
    $object = ['category' => $category, 'filename' => $filename, 'object_key' => $key, 'endpoint' => $config['endpoint'],
        'bucket' => $config['bucket'], 'sha256' => hash('sha256', $bytes), 'mime' => $info['mime'], 'bytes' => strlen($bytes)];
    schoolPhotoJournal($object);
    // Register before remote I/O; crash recovery can retry/delete deterministic keys.
    $stmt = $GLOBALS['pdo']->prepare('INSERT INTO school_photo_objects (category, filename, object_key, endpoint, bucket, sha256, mime, bytes, status) VALUES (:category, :filename, :object_key, :endpoint, :bucket, :sha256, :mime, :bytes, \'uploading\')');
    $stmt->execute($object);
    $GLOBALS['school_new_photos'][] = $object;
    schoolPhotoRegisterShutdown();
    ($client ?? schoolR2Client($object))->putVerified($key, $bytes, $info['mime']);
    $stmt = $GLOBALS['pdo']->prepare("UPDATE school_photo_objects SET status = 'ready', last_error = NULL WHERE category = ? AND filename = ?");
    if (!$stmt->execute([$category, $filename])) throw new RuntimeException('Could not save R2 photo registry.');
    return strlen($bytes);
}

function schoolPhotoStoreFile(string $source, string $destination): bool
{
    $bytes = file_get_contents($source, false, null, 0, 10 * 1024 * 1024 + 1);
    if ($bytes === false) throw new RuntimeException('Could not read uploaded photo.');
    schoolPhotoStoreBytes($destination, $bytes);
    return true;
}

function schoolPhotoRegisterShutdown(): void
{
    if (!empty($GLOBALS['school_photo_shutdown'])) return;
    $GLOBALS['school_photo_shutdown'] = true;
    register_shutdown_function('schoolPhotoFinishRequest');
}

/** Defer deletion until AFTER a form succeeds or rolls back; never trust a posted filename. */
function schoolPhotoScheduleDelete(string $path): void
{
    $parts = schoolPhotoPathParts($path);
    if (!$parts || schoolPhotoIsDefault($parts[1])) return;
    $GLOBALS['school_old_photos'][implode('/', $parts)] = $parts;
    schoolPhotoRegisterShutdown();
}

function schoolPhotoFinishRequest(?SchoolR2Client $client = null): void
{
    $pdo = $GLOBALS['pdo'] ?? null;
    if (!$pdo || $pdo->inTransaction()) return; // a maintenance run recovers durable entries
    foreach ($GLOBALS['school_new_photos'] ?? [] as $object) {
        try {
            // Restore the registry if the business transaction rolled it back.
            $stmt = $pdo->prepare('INSERT IGNORE INTO school_photo_objects (category, filename, object_key, endpoint, bucket, sha256, mime, bytes, status) VALUES (:category, :filename, :object_key, :endpoint, :bucket, :sha256, :mime, :bytes, \'uploading\')');
            $stmt->execute($object);
            if (!schoolPhotoReferenced($object['category'], $object['filename'])) schoolPhotoDeleteUnused($object['category'], $object['filename'], $client);
            schoolPhotoForgetJournal($object);
        } catch (Throwable $e) { error_log('R2 pending photo cleanup failed: ' . $e->getMessage()); }
    }
    foreach ($GLOBALS['school_old_photos'] ?? [] as [$category, $filename]) {
        try { schoolPhotoDeleteUnused($category, $filename, $client); }
        catch (Throwable $e) { error_log('R2 old photo cleanup queued: ' . $e->getMessage()); }
    }
    $GLOBALS['school_new_photos'] = $GLOBALS['school_old_photos'] = [];
}

function schoolPhotoJournalPath(array $object): string
{
    return __DIR__ . '/.r2-pending/' . hash('sha256', $object['category'] . '/' . $object['filename']) . '.php';
}

function schoolPhotoJournal(array $object): void
{
    $object = array_intersect_key($object, array_flip(['category', 'filename', 'object_key', 'endpoint', 'bucket', 'sha256', 'mime', 'bytes']));
    $path = schoolPhotoJournalPath($object);
    if (!is_dir(dirname($path)) && !mkdir(dirname($path), 0700, true)) throw new RuntimeException('Could not create R2 recovery journal.');
    $data = "<?php exit; ?>\n" . json_encode($object, JSON_THROW_ON_ERROR);
    if (file_put_contents($path, $data, LOCK_EX) !== strlen($data)) throw new RuntimeException('Could not save R2 recovery journal.');
}

function schoolPhotoForgetJournal(array $object): void
{
    $path = schoolPhotoJournalPath($object);
    if (is_file($path)) unlink($path);
}

function schoolPhotoDeleteUnused(string $category, string $filename, ?SchoolR2Client $client = null): bool
{
    if (!schoolPhotoValidName($category, $filename) || schoolPhotoIsDefault($filename) || schoolPhotoReferenced($category, $filename)) return false;
    $object = schoolPhotoObject($category, $filename);
    if ($object) {
        $stmt = $GLOBALS['pdo']->prepare('UPDATE school_photo_objects SET delete_requested = 1 WHERE id = ?');
        $stmt->execute([$object['id']]);
        try { ($client ?? schoolR2Client($object))->request('DELETE', $object['object_key']); }
        catch (Throwable $e) {
            $stmt = $GLOBALS['pdo']->prepare('UPDATE school_photo_objects SET last_error = ? WHERE id = ?');
            $stmt->execute([substr($e->getMessage(), 0, 500), $object['id']]);
            throw $e;
        }
        $stmt = $GLOBALS['pdo']->prepare('DELETE FROM school_photo_objects WHERE id = ?');
        $stmt->execute([$object['id']]);
    }
    $local = schoolPhotoLocalPath($category, $filename);
    if (is_file($local) && !is_link($local) && !unlink($local)) throw new RuntimeException('Could not remove unused local photo.');
    return true;
}

function schoolPhotoRead(string $category, string $filename, ?SchoolR2Client $client = null): string
{
    $path = schoolPhotoLocalPath($category, $filename);
    if (is_file($path) && !is_link($path)) return file_get_contents($path);
    $object = schoolPhotoObject($category, $filename);
    if (!$object || $object['status'] !== 'ready') throw new RuntimeException('Photo not found.');
    $bytes = ($client ?? schoolR2Client($object))->request('GET', $object['object_key'])['body'];
    if (!hash_equals($object['sha256'], hash('sha256', $bytes))) throw new RuntimeException('Stored photo verification failed.');
    return $bytes;
}

function schoolPhotoExists(string $path): bool
{
    if (is_file($path)) return true;
    $parts = schoolPhotoPathParts($path);
    if (!$parts) return false;
    $local = schoolPhotoLocalPath(...$parts);
    if (is_file($local) && !is_link($local)) return true;
    try { return (schoolPhotoObject(...$parts)['status'] ?? '') === 'ready'; }
    catch (Throwable $e) { return false; }
}

function schoolPhotoDataUri(string $category, ?string $filename): string
{
    $filename = $filename ?: schoolPhotoCategories()[$category][2];
    try { $bytes = schoolPhotoRead($category, $filename); }
    catch (Throwable $e) { $bytes = schoolPhotoRead($category, schoolPhotoCategories()[$category][2]); }
    $info = getimagesizefromstring($bytes);
    return 'data:' . $info['mime'] . ';base64,' . base64_encode($bytes);
}

function schoolR2PublicBaseUrl(?array $config = null): string
{
    $config ??= $GLOBALS['websiteConfig'] ?? [];
    // Existing R2 installations get the requested CDN without depending on a new
    // database column being applied first; an explicitly blank setting uses the gateway.
    $url = $config['r2_public_base_url'] ?? (!empty($config['r2_enabled']) ? 'https://cdn.schoolsongi.com' : '');
    if (!is_string($url)) throw new InvalidArgumentException('Enter a valid HTTPS Public CDN Base URL.');
    $url = rtrim(trim($url), '/');
    if ($url === '') return '';
    $parts = parse_url($url);
    if (strlen($url) > 255 || !filter_var($url, FILTER_VALIDATE_URL) || preg_match('/[\x00-\x20\x22\x27\x3C\x3E\x60]/', $url) || !$parts || ($parts['scheme'] ?? '') !== 'https'
        || empty($parts['host']) || isset($parts['user']) || isset($parts['pass']) || isset($parts['query']) || isset($parts['fragment'])) {
        throw new InvalidArgumentException('Public CDN Base URL must be an HTTPS URL without credentials, query parameters or fragments.');
    }
    return $url;
}

function schoolPhotoGatewayUrl(string $category, string $filename, ?string $base = null): string
{
    return rtrim($base ?? BASE_URL, '/') . '/api/photo.php?category=' . rawurlencode($category) . '&filename=' . rawurlencode($filename);
}

function schoolPhotoUrl(string $category, ?string $filename, ?string $base = null): string
{
    if (!$filename || !schoolPhotoValidName($category, $filename)) $filename = schoolPhotoCategories()[$category][2];
    $localUrl = rtrim($base ?? BASE_URL, '/') . '/uploads/' . $category . '/' . rawurlencode($filename);
    if (schoolPhotoIsDefault($filename) || is_file(schoolPhotoLocalPath($category, $filename))) return $localUrl;
    $config = $GLOBALS['websiteConfig'] ?? [];
    if (empty($config['r2_enabled']) && empty($config['r2_account_id'])) return $localUrl;
    $cdn = schoolR2PublicBaseUrl($config);
    if ($cdn !== '') {
        // Preserve any previous manually selected prefix in the stored object key.
        $object = isset($GLOBALS['pdo']) ? schoolPhotoObject($category, $filename) : null;
        $key = $object['object_key'] ?? (schoolR2SchoolPrefix() . '/' . $category . '/' . $filename);
        return $cdn . '/' . implode('/', array_map('rawurlencode', explode('/', $key)));
    }
    if (!empty($config['r2_enabled']) || !empty($config['r2_account_id'])) return schoolPhotoGatewayUrl($category, $filename, $base);
    return $localUrl;
}

/** Fabric uses anonymous canvas images; the same-origin gateway avoids CDN CORS dependence. */
function schoolPhotoCanvasUrl(string $category, ?string $filename, ?string $base = null): string
{
    $url = schoolPhotoUrl($category, $filename, $base);
    $appBase = rtrim($base ?? BASE_URL, '/');
    return str_starts_with($url, $appBase . '/') ? $url : schoolPhotoGatewayUrl($category, $filename, $base);
}
