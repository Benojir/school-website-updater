<?php
// No need to close PHP tag yet
echo '
<div style="
    position: fixed; 
    top: 0; 
    left: 0; 
    width: 100%; 
    height: 100%; 
    background: rgba(255, 255, 255, 0.5); 
    z-index: 9999; 
    display: flex; 
    align-items: center; 
    justify-content: center;
    backdrop-filter: blur(5px);
">
    <div class="text-center p-5 animate__animated animate__fadeIn">
        <div class="mb-4 text-danger">
            <i class="fa-solid fa-lock fa-5x"></i>
        </div>
        <h1 class="display-4 fw-bold text-dark">Access Denied</h1>
        <h2 class="h4 mb-4 text-secondary">Subscription Expired!</h2>
        <p class="lead text-muted mb-5" style="max-width: 500px; margin: 0 auto;">
            If you are the owner of this website, your subscription has expired. Please renew your subscription.
        </p>
        <a href="https://wa.me/+918348313317?text=I%20want%20to%20renew%20my%20subscription" class="btn btn-dark btn-lg px-5 rounded-pill shadow-sm">
            <i class="fa-brands fa-whatsapp me-2"></i> Contact Support
        </a>
    </div>
</div>
</body>
</html>';

if (ob_get_level() > 0) {
    ob_end_flush();
}

die();
?>