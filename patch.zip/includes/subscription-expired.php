<?php
$reason = $subscription_access['access_reason'] ?? 'expired';
$title = 'Subscription Expired';
$message = 'Your website subscription has expired. Please contact School Songi to renew your subscription.';
if ($reason === 'payment_overdue') {
    $title = 'Subscription Payment Overdue';
    $deadline = schoolSongiSubscriptionDate($subscriptions['subscription_payment_due_at'] ?? null);
    $message = 'The payment deadline (' . ($deadline ? $deadline->format('d/m/Y') : '')
        . ') has passed. Outstanding subscription balance: INR '
        . number_format($subscription_access['subscription_due_amount'], 2)
        . '. Please clear the outstanding balance to restore access.';
} elseif ($reason === 'inactive') {
    $title = 'Website Inactive';
    $message = 'This website has been deactivated. Please contact School Songi for assistance.';
} elseif ($reason === 'unavailable') {
    $title = 'Subscription Check Temporarily Unavailable';
    $message = 'We could not verify the subscription at this time. Please try again shortly or contact support.';
    http_response_code(503);
    header('Retry-After: 60');
}
$detailsUrl = BASE_URL . '/management/dashboard/subscription-account.php';
?>
<div class="d-flex align-items-center justify-content-center bg-body-tertiary" style="min-height:100vh">
    <div class="card border-0 shadow-sm rounded-4 text-center m-3 p-4 p-md-5" style="max-width:640px">
        <div class="text-danger mb-4"><i class="fa-solid fa-lock fa-4x"></i></div>
        <h1 class="h3 fw-bold mb-3"><?= htmlspecialchars($title, ENT_QUOTES, 'UTF-8') ?></h1>
        <p class="text-body-secondary mb-4"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></p>
        <?php if ($reason !== 'unavailable'): ?>
            <a href="<?= htmlspecialchars($detailsUrl, ENT_QUOTES, 'UTF-8') ?>" class="btn btn-primary rounded-pill mb-2">View Subscription Account</a>
        <?php endif; ?>
        <a href="https://wa.me/918348313317?text=Please%20help%20restore%20our%20school%20website" class="btn btn-outline-dark rounded-pill">
            <i class="fa-brands fa-whatsapp me-2"></i> Contact Support
        </a>
    </div>
</div>
</body>
</html>
<?php
if (ob_get_level() > 0) {
    ob_end_flush();
}
exit;
