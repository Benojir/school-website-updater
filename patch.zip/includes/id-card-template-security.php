<?php
/**
 * Call only after the normal admin authentication/permission check.
 * Bind CSRF to that login credential, not PHP's shorter-lived session storage.
 * The credential itself is never sent to JavaScript or returned by the API.
 */
function idCardTemplateCsrfToken(string $audience = 'student'): string
{
    $credential = $_COOKIE['admin_auth_token'] ?? '';
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $authentication = $headers['Authentication'] ?? ($_SERVER['HTTP_AUTHENTICATION'] ?? '');
    // Use the same bearer-over-cookie precedence as getAuthenticatedAdmin().
    if (is_string($authentication) && strpos($authentication, 'Bearer ') === 0) {
        $bearer = str_replace('Bearer ', '', $authentication);
        if ($bearer !== '') $credential = $bearer;
    }
    if (!is_string($credential) || $credential === '') {
        throw new RuntimeException('Your login expired. Sign in again before saving.');
    }
    return hash_hmac('sha256', $audience . '-id-card-templates:csrf:v1', $credential);
}
