<?php
require_once __DIR__ . '/photo-storage.php';
require_once __DIR__ . '/id-card-template-security.php';

function schoolR2RequireConfigRequest(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isSuperAdmin()) throw new RuntimeException('Permission denied.');
    $token = $_POST['r2_csrf'] ?? '';
    if (!is_string($token) || !hash_equals(idCardTemplateCsrfToken('r2-config'), $token)) throw new RuntimeException('Your login changed. Refresh Website Configuration before saving.');
}

function schoolR2SubmittedConfig(array $input, array $current): array
{
    $input['r2_prefix'] = schoolR2SchoolPrefix(); // never trust the submitted school prefix
    $secret = trim((string)($input['r2_secret_access_key'] ?? ''));
    if ($secret === '') $secret = schoolR2Decrypt((string)($current['r2_secret_access_key'] ?? ''));
    return schoolR2Validate($input + ['secret' => $secret]);
}

function schoolR2TestConfig(array $config): void
{
    $client = new SchoolR2Client($config);
    $key = $config['prefix'] . '/connection-tests/' . bin2hex(random_bytes(16)) . '.txt';
    try { $client->putVerified($key, 'School R2 connection test', 'text/plain'); }
    finally { $client->request('DELETE', $key); }
}

function schoolR2SettingsForSave(array $input, array $current): array
{
    $fields = ['r2_account_id', 'r2_bucket', 'r2_prefix', 'r2_endpoint', 'r2_access_key_id', 'r2_secret_access_key'];
    $data = ['r2_enabled' => array_key_exists('r2_account_id', $input) ? (empty($input['r2_enabled']) ? 0 : 1) : (int)($current['r2_enabled'] ?? 0)];
    // Disabling new uploads retains credentials so existing R2 photos still load.
    foreach ($fields as $field) $data[$field] = $current[$field] ?? null;
    $data['r2_public_base_url'] = schoolR2PublicBaseUrl(array_key_exists('r2_public_base_url', $input)
        ? ['r2_public_base_url' => $input['r2_public_base_url']] : $current);
    if (!array_key_exists('r2_account_id', $input)) return $data;
    $input['r2_prefix'] = $data['r2_prefix'] = schoolR2SchoolPrefix();
    $changed = trim((string)($input['r2_secret_access_key'] ?? '')) !== '';
    foreach (array_slice($fields, 0, -1) as $field) {
        if ($field === 'r2_prefix') continue; // deriving the tenant prefix needs no connection retest
        if (trim((string)($input[$field] ?? '')) !== trim((string)($current[$field] ?? ''))) $changed = true;
    }
    if (!$changed && $data['r2_enabled'] === (int)($current['r2_enabled'] ?? 0)) return $data;
    if (!$changed && !$data['r2_enabled']) return $data;
    if (!$data['r2_enabled'] && empty($input['r2_account_id'])) return $data;
    $config = schoolR2SubmittedConfig($input, $current);
    if (!empty($current['r2_account_id'])) {
        $stmt = $GLOBALS['pdo']->query('SELECT COUNT(*) FROM school_photo_objects');
        if ((int)$stmt->fetchColumn() > 0 || (glob(__DIR__ . '/.r2-pending/*.php') ?: [])) {
            $old = schoolR2Validate($current + ['secret' => $config['secret']]);
            foreach (['account', 'bucket', 'endpoint'] as $field) {
                if ($old[$field] !== $config[$field]) throw new InvalidArgumentException('Existing R2 photos use this Account ID, bucket and endpoint. Keep these values unchanged; credentials may be rotated.');
            }
        }
    }
    schoolR2TestConfig($config);
    foreach (['account_id' => 'account', 'bucket' => 'bucket', 'prefix' => 'prefix', 'endpoint' => 'endpoint', 'access_key_id' => 'access'] as $field => $key) $data['r2_' . $field] = $config[$key];
    $data['r2_secret_access_key'] = schoolR2Encrypt($config['secret']);
    return $data;
}
