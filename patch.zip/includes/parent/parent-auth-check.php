<?php
include_once __DIR__ . '/../config.php';

/**
 * Authenticates a parent request from either Mobile (Bearer Token) or Web (Cookie).
 *
 * @param PDO $pdo The database connection.
 * @return array|null The authenticated parent/session data, or null if not authenticated.
 */
function getAuthenticatedParent($pdo) {
    $token = null;
    $headers = getallheaders();

    // 1. Check for Mobile App's Bearer Token
    if (!empty($headers['Authentication']) && strpos($headers['Authentication'], 'Bearer ') === 0) {
        $token = str_replace('Bearer ', '', $headers['Authentication']);
    }
    
    // 2. If no Bearer token, check for Web's Auth Cookie
    if (empty($token) && !empty($_COOKIE['auth_token'])) {
        $token = $_COOKIE['auth_token'];
    }

    // 3. If no token found, user is not logged in
    if (empty($token)) {
        return null; 
    }

    // 4. Validate the token against the database
    $tokenHash = hash('sha256', $token);
    $currentDateTime = date('Y-m-d H:i:s');

    // Use the NEW table name 'parent_auth_sessions'
    $stmt = $pdo->prepare("SELECT s.*, p.phone_number 
                          FROM parent_auth_sessions s
                          JOIN parent_accounts p ON s.parent_id = p.id
                          WHERE s.token_hash = ? AND s.expires_at > ?");
    $stmt->execute([$tokenHash, $currentDateTime]);
    $session = $stmt->fetch();

    if (!$session) {
        return null; // Invalid or expired token
    }

    // 5. Refresh session expiry on activity
    $newExpiry = date('Y-m-d H:i:s', strtotime('+30 days')); // Keep sessions long-lived
    $stmt = $pdo->prepare("UPDATE parent_auth_sessions SET expires_at = ?, last_activity = NOW() WHERE id = ?");
    $stmt->execute([$newExpiry, $session['id']]);

    // Return all relevant parent and session data
    return [
        'success' => true,
        'message' => 'Token successfully validated',
        'parent_id' => $session['parent_id'],
        'phone_number' => $session['phone_number'],
        'session_id' => $session['id'],
        'device_id' => $session['device_id'],
        'fcm_token' => $session['fcm_token'] ?? null,
        'session_source' => $session['session_source']
    ];
}

/**
 * A helper function for protected API endpoints (Mobile or Web AJAX).
 * It calls getAuthenticatedParent and exits with a 401 error if auth fails.
 *
 * @param PDO $pdo
 * @return array The authenticated parent data.
 */
function authenticateApiRequest($pdo) {
    $authData = getAuthenticatedParent($pdo);
    
    if (!$authData) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Unauthorized: Invalid or expired token']);
        exit;
    }
    
    return $authData;
}

/**
 * A helper function for protected WEB pages (not APIs).
 * It redirects to a login page if authentication fails.
 *
 * @param PDO $pdo
 * @param string $loginPageUrl The URL to redirect to if not logged in.
 * @return array The authenticated parent data.
 */
function authenticateWebPageRequest($pdo, $loginPageUrl = '/parent') {
    $authData = getAuthenticatedParent($pdo);
    
    if (!$authData) {
        // Redirect to the login page
        header('Location: ' . $loginPageUrl);
        exit;
    }
    
    return $authData;
}

/**
 * Check if parent has access to the requested student
 * (This function is from your old mobile-auth.php, no changes needed)
 */
function hasParentAccessToStudent($parentId, $studentId) {
    global $pdo; // Assumes $pdo is global or passed in
    
    $stmt = $pdo->prepare("SELECT 1 FROM students 
                          WHERE student_id = ? 
                          AND (phone_number = (SELECT phone_number FROM parent_accounts WHERE id = ?))
                          LIMIT 1");
    $stmt->execute([$studentId, $parentId]);
    
    if ($stmt->fetch()) {
        return true;
    }
    
    $stmt = $pdo->prepare("SELECT 1 FROM parent_accounts 
                          WHERE id = ? 
                          AND FIND_IN_SET(?, student_ids)");
    $stmt->execute([$parentId, $studentId]);
    
    return (bool)$stmt->fetch();
}