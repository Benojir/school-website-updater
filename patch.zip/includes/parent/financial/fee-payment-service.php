<?php
// No application bootstrap here: services can be tested without a database connection.
require_once __DIR__ . '/../../../../vendor/autoload.php';
require_once __DIR__ . '/../../financial/payment-charges.php';

class FeePaymentGateway
{
    private Razorpay\Api\Api $api;

    public function __construct(string $key, string $secret) { $this->api = new Razorpay\Api\Api($key, $secret); }
    public function create(array $data): array { return $this->api->order->create($data)->toArray(); }
    public function payment(string $id): array { return $this->api->payment->fetch($id)->toArray(); }
    public function payments(string $id): array { return $this->api->order->fetch($id)->payments()->toArray()['items'] ?? []; }
    public function verify(string $order, string $payment, string $signature): void {
        $this->api->utility->verifyPaymentSignature([
            'razorpay_order_id' => $order, 'razorpay_payment_id' => $payment, 'razorpay_signature' => $signature,
        ]);
    }
}

class FeePaymentService
{
    public function __construct(private PDO $pdo, private FeePaymentGateway $gateway, private array $config, private bool $enabled) {}

    public static function charges($amount, $percentage, $gstPercentage): array {
        foreach ([$amount, $percentage, $gstPercentage] as $value) {
            if (!is_numeric($value) || !is_finite((float)$value) || (float)$value < 0 || (float)$value > 10000000) {
                throw new InvalidArgumentException('Invalid fee or payment charge configuration.');
            }
        }
        $fee = (int)round((float)$amount * 100);
        if ($fee <= 0) throw new InvalidArgumentException('No unpaid fee remains.');
        return ['fee_paise' => $fee] + schoolPaymentCharges($fee, $percentage, $gstPercentage);
    }

    private function tables(string $type): array {
        if ($type === 'monthly-fee') return ['student_unpaid_fees', 'student_payment_history'];
        if ($type === 'admission-fee') return ['admission_unpaid_fees', 'admission_fees_payment_history'];
        throw new InvalidArgumentException('Invalid fee type.');
    }

    private function student(string $student, string $phone, bool $lock = false): array {
        $stmt = $this->pdo->prepare('SELECT * FROM students WHERE student_id = ?' . ($lock ? ' FOR UPDATE' : ''));
        $stmt->execute([$student]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row || ($phone !== (string)$row['phone_number'] && $phone !== (string)($row['alternate_phone_number'] ?? ''))) {
            throw new InvalidArgumentException('You do not have access to this student.');
        }
        return $row;
    }

    private function fee(string $student, string $type, int $id, bool $lock = false): array {
        [$table] = $this->tables($type);
        $stmt = $this->pdo->prepare("SELECT * FROM $table WHERE id = ? AND student_id = ?" . ($lock ? ' FOR UPDATE' : ''));
        $stmt->execute([$id, $student]);
        $fee = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$fee || (float)$fee['unpaid_amount'] <= 0) throw new InvalidArgumentException('This fee has already been paid or is no longer available.');
        return $fee;
    }

    private function requireEnabled(): void {
        if (!$this->enabled || empty($this->config['razorpay_key_id']) || empty($this->config['razorpay_key_secret'])) {
            throw new InvalidArgumentException('Online payment is not enabled. Please contact the school.');
        }
    }

    private function summary(array $fee, array $student): array {
        return self::charges($fee['unpaid_amount'], $this->config['razorpay_charge_percentage'] ?? 0, $this->config['gst_on_razorpay_charge'] ?? 0)
            + ['student_name' => $student['name'], 'description' => ($fee['month_year'] ?? $fee['academic_year']) . ' - ' . ($fee['remark'] ?? 'School fee')];
    }

    private function pending(string $student, string $type, int $id): ?array {
        $stmt = $this->pdo->prepare("SELECT * FROM online_fee_payment_orders WHERE student_id = ? AND fee_type = ? AND fee_id = ? AND payment_status IN ('pending', 'review') ORDER BY id DESC LIMIT 1");
        $stmt->execute([$student, $type, $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function quote(string $student, string $phone, string $type, int $id): array {
        $this->tables($type);
        $info = $this->student($student, $phone);
        // Return an existing order even when the setting has since been disabled: it still needs checking.
        $pending = $this->pending($student, $type, $id);
        if ($pending) return $this->checkout($pending, $info) + ['existing_order' => true];
        try { $fee = $this->fee($student, $type, $id); }
        catch (InvalidArgumentException $e) {
            // A webhook may have settled this fee before a lost callback/reopened screen.
            $stmt = $this->pdo->prepare('SELECT * FROM online_fee_payment_orders WHERE student_id = ? AND fee_type = ? AND fee_id = ? ORDER BY id DESC LIMIT 1');
            $stmt->execute([$student, $type, $id]);
            $completed = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($completed && $completed['payment_status'] === 'paid') return $this->checkout($completed, $info) + ['existing_order' => true];
            throw $e;
        }
        $this->requireEnabled();
        return $this->summary($fee, $info) + ['existing_order' => false];
    }

    private function checkout(array $order, array $student): array {
        $snapshot = json_decode($order['fee_snapshot'], true, 32, JSON_THROW_ON_ERROR);
        return array_intersect_key($order, array_flip(['fee_paise', 'gateway_charge_paise', 'gst_paise', 'total_paise', 'gateway_percentage', 'gst_percentage', 'razorpay_order_id', 'payment_status']))
            + ['razorpay_key_id' => $this->config['razorpay_key_id'], 'school_name' => $this->config['school_name'] ?? 'School',
                'student_name' => $student['name'], 'description' => ($snapshot['month_year'] ?? $snapshot['academic_year']) . ' - ' . ($snapshot['remark'] ?? 'School fee')];
    }

    public function start(string $student, string $phone, string $type, int $id, int $expectedFee, int $expectedTotal): array {
        $this->tables($type);
        $this->requireEnabled();
        $this->student($student, $phone);
        $pending = $this->pending($student, $type, $id);
        if ($pending) {
            $state = $this->reconcile($pending);
            if ($state['payment_status'] !== 'pending') return $state;
            if (!$state['can_retry']) throw new InvalidArgumentException($state['message']);
        }
        $this->pdo->beginTransaction();
        try {
            // Serialize starts across devices/parents for the same student.
            $info = $this->student($student, $phone, true);
            $fee = $this->fee($student, $type, $id, true);
            $existing = $this->pending($student, $type, $id);
            if ($existing) {
                if ($existing['payment_status'] !== 'pending' || !self::sameFee($fee, json_decode($existing['fee_snapshot'], true))) {
                    throw new InvalidArgumentException('This fee changed after payment was started. Check payment status and contact the school before paying again.');
                }
                if ((int)$existing['fee_paise'] !== $expectedFee || (int)$existing['total_paise'] !== $expectedTotal) {
                    throw new InvalidArgumentException('Reopen this fee to review the existing payment total.');
                }
                $this->pdo->commit();
                return $this->checkout($existing, $info);
            }
            $summary = $this->summary($fee, $info);
            if ($summary['fee_paise'] !== $expectedFee || $summary['total_paise'] !== $expectedTotal) {
                throw new InvalidArgumentException('The fee or charges changed. Reopen this payment to review the updated total.');
            }
            $provider = $this->gateway->create(['receipt' => 'FEE_' . bin2hex(random_bytes(12)), 'amount' => $summary['total_paise'],
                'currency' => 'INR', 'payment_capture' => 1,
                'notes' => ['purpose' => 'parent_app_fee', 'student_id' => $student, 'fee_type' => $type, 'fee_id' => (string)$id]]);
            if (!preg_match('/^order_[a-zA-Z0-9]+$/D', $provider['id'] ?? '') || (int)($provider['amount'] ?? 0) !== $summary['total_paise'] || ($provider['currency'] ?? '') !== 'INR') {
                throw new RuntimeException('Invalid gateway order response.');
            }
            $order = $summary + ['student_id' => $student, 'parent_phone' => $phone, 'fee_type' => $type, 'fee_id' => $id,
                'fee_snapshot' => json_encode($fee, JSON_THROW_ON_ERROR), 'razorpay_order_id' => $provider['id'], 'payment_status' => 'pending'];
            $fields = ['student_id', 'parent_phone', 'fee_type', 'fee_id', 'fee_snapshot', 'fee_paise', 'gateway_charge_paise', 'gst_paise', 'total_paise', 'gateway_percentage', 'gst_percentage', 'razorpay_order_id'];
            $stmt = $this->pdo->prepare('INSERT INTO online_fee_payment_orders (' . implode(', ', $fields) . ') VALUES (' . implode(', ', array_fill(0, count($fields), '?')) . ')');
            $stmt->execute(array_map(static fn($field) => $order[$field], $fields));
            $this->pdo->commit();
            return $this->checkout($order, $info);
        } catch (Throwable $e) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            throw $e;
        }
    }

    public function order(string $id): ?array {
        if (!preg_match('/^order_[a-zA-Z0-9]+$/D', $id)) throw new InvalidArgumentException('Invalid payment order.');
        $stmt = $this->pdo->prepare('SELECT * FROM online_fee_payment_orders WHERE razorpay_order_id = ?');
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function check(string $id, string $phone, ?string $payment = null, ?string $signature = null): array {
        $order = $this->order($id);
        if (!$order) throw new InvalidArgumentException('Payment order not found.');
        $this->student($order['student_id'], $phone);
        if (in_array($order['payment_status'], ['paid', 'review'], true)) return $this->status($order);
        if ($payment !== null) {
            if (!preg_match('/^pay_[a-zA-Z0-9]+$/D', $payment) || !preg_match('/^[a-f0-9]{64}$/D', $signature ?? '')) throw new InvalidArgumentException('Invalid payment verification data.');
            // Use the stored order ID, never a fee/order association supplied by the client.
            $this->gateway->verify($order['razorpay_order_id'], $payment, $signature);
            $payments = [$this->gateway->payment($payment)];
        } else $payments = $this->gateway->payments($id);
        return $this->reconcile($order, $payments);
    }

    public function reconcile(array $order, ?array $payments = null): array {
        if ($order['payment_status'] === 'paid' || $order['payment_status'] === 'review') return $this->status($order);
        $payments ??= $this->gateway->payments($order['razorpay_order_id']);
        foreach ($payments as $payment) {
            if (($payment['order_id'] ?? '') !== $order['razorpay_order_id'] || ($payment['status'] ?? '') !== 'captured') continue;
            if ((int)($payment['amount'] ?? 0) !== (int)$order['total_paise'] || ($payment['currency'] ?? '') !== 'INR'
                || (int)($payment['amount_refunded'] ?? 0) !== 0 || !preg_match('/^pay_[a-zA-Z0-9]+$/D', $payment['id'] ?? '')) {
                throw new RuntimeException('Payment amount, currency, or refund status does not match the fee order.');
            }
            return $this->settle($order, $payment['id']);
        }
        $authorized = false;
        foreach ($payments as $payment) {
            if (($payment['order_id'] ?? '') === $order['razorpay_order_id'] && ($payment['status'] ?? '') === 'authorized') $authorized = true;
        }
        [$table] = $this->tables($order['fee_type']);
        $stmt = $this->pdo->prepare("SELECT * FROM $table WHERE id = ? AND student_id = ?");
        $stmt->execute([$order['fee_id'], $order['student_id']]);
        $fee = $stmt->fetch(PDO::FETCH_ASSOC);
        $unchanged = $fee && self::sameFee($fee, json_decode($order['fee_snapshot'], true, 32, JSON_THROW_ON_ERROR));
        $state = $this->status($order);
        $state['can_retry'] = $this->enabled && !empty($this->config['razorpay_key_id']) && !empty($this->config['razorpay_key_secret']) && !$authorized && $unchanged;
        if ($authorized) $state['message'] = 'Payment is authorized and awaiting capture. Check again later; do not pay again.';
        elseif (!$unchanged) $state['message'] = 'This fee changed after checkout was started. Contact the school before making another payment.';
        elseif (!$this->enabled) $state['message'] = 'Online payment is disabled. You can still check the status of this payment.';
        return $state;
    }

    public static function sameFee(array $fee, array $snapshot): bool {
        foreach (['id', 'student_id', 'month_year', 'academic_year', 'class_id', 'actual_amount', 'discount_amount', 'unpaid_amount'] as $field) {
            if (($fee[$field] ?? null) != ($snapshot[$field] ?? null)) return false;
        }
        return true;
    }

    private function settle(array $order, string $payment): array {
        $this->pdo->beginTransaction();
        try {
            // Same lock order as start(), followed by the durable order lock.
            $stmt = $this->pdo->prepare('SELECT student_id FROM students WHERE student_id = ? FOR UPDATE');
            $stmt->execute([$order['student_id']]);
            $stmt = $this->pdo->prepare('SELECT * FROM online_fee_payment_orders WHERE id = ? FOR UPDATE');
            $stmt->execute([$order['id']]);
            $order = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($order['payment_status'] !== 'pending') {
                $this->pdo->commit();
                return $this->status($order);
            }
            [$table] = $this->tables($order['fee_type']);
            $stmt = $this->pdo->prepare("SELECT * FROM $table WHERE id = ? AND student_id = ? FOR UPDATE");
            $stmt->execute([$order['fee_id'], $order['student_id']]);
            $fee = $stmt->fetch(PDO::FETCH_ASSOC);
            $snapshot = json_decode($order['fee_snapshot'], true, 32, JSON_THROW_ON_ERROR);
            $status = $fee && self::sameFee($fee, $snapshot) ? 'paid' : 'review';
            if ($status === 'paid') $this->recordFee($fee, $order, $payment);
            $stmt = $this->pdo->prepare('UPDATE online_fee_payment_orders SET payment_status = ?, razorpay_payment_id = ? WHERE id = ?');
            $stmt->execute([$status, $payment, $order['id']]);
            $this->pdo->commit();
            return $this->status(array_replace($order, ['payment_status' => $status, 'razorpay_payment_id' => $payment]));
        } catch (Throwable $e) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            throw $e;
        }
    }

    private function recordFee(array $fee, array $order, string $payment): void {
        $monthly = $order['fee_type'] === 'monthly-fee';
        $paidTable = $monthly ? 'student_full_paid_fees' : 'admission_full_paid_fees';
        $partialTable = $monthly ? 'student_partial_payments' : 'admission_partial_fees_payments';
        [$unpaidTable, $historyTable] = $this->tables($order['fee_type']);
        $period = $monthly ? 'month_year' : 'academic_year';
        $unpaidKey = $monthly ? 'unpaid_fees_id' : 'unpaid_admission_fees_id';
        $paidKey = $monthly ? 'full_paid_fees_id' : 'full_paid_admission_fees_id';
        $amount = (int)$order['fee_paise'] / 100; // Charges are not credited as school fees.
        $date = date('Y-m-d');
        $remark = '₹' . $amount . ' paid online for ' . $fee[$period] . '. Razorpay: ' . $payment
            . '; gateway charge ₹' . ((int)$order['gateway_charge_paise'] / 100) . '; GST ₹' . ((int)$order['gst_paise'] / 100) . '.';
        $paid = ['student_id' => $fee['student_id'], $period => $fee[$period], 'actual_amount' => $fee['actual_amount'],
            'discount_amount' => $fee['discount_amount'], 'total_paid_amount' => $fee['actual_amount'] - $fee['discount_amount'],
            'last_paid_amount' => $amount, 'remark' => $fee['remark'], 'created_at' => $date];
        if (!$monthly) $paid['class_id'] = $fee['class_id'];
        $paidId = $this->insert($paidTable, $paid);
        $partial = ['student_id' => $fee['student_id'], $period => $fee[$period], $unpaidKey => $fee['id'], $paidKey => $paidId,
            'partial_paid_amount' => $amount, 'method' => 'online', 'remark' => $remark, 'created_at' => $date];
        if (!$monthly) $partial['class_id'] = $fee['class_id'];
        $partialId = $this->insert($partialTable, $partial);
        $stmt = $this->pdo->prepare("UPDATE $partialTable SET $paidKey = ? WHERE $unpaidKey = ?");
        $stmt->execute([$paidId, $fee['id']]);
        $stmt = $this->pdo->prepare("DELETE FROM $unpaidTable WHERE id = ?");
        $stmt->execute([$fee['id']]);
        $history = ['student_id' => $fee['student_id'], 'payment_amount' => $amount, 'payment_date' => $date, 'remark' => $remark,
            ($monthly ? 'full_paid_payment_ids' : 'full_paid_admission_payment_ids') => json_encode([$paidId]),
            'partial_payment_ids_backup' => json_encode([$partialId]), 'wallet_affected_balance' => 0, 'wallet_transaction_id' => null,
            ($monthly ? 'unpaid_fee_rows_backup' : 'unpaid_admission_fees_rows_backup') => json_encode([$fee], JSON_THROW_ON_ERROR), 'method' => 'online'];
        $this->insert($historyTable, $history);
    }

    private function insert(string $table, array $values): string {
        $stmt = $this->pdo->prepare("INSERT INTO $table (" . implode(', ', array_keys($values)) . ') VALUES (' . implode(', ', array_fill(0, count($values), '?')) . ')');
        $stmt->execute(array_values($values));
        return $this->pdo->lastInsertId();
    }

    private function status(array $order): array {
        return ['payment_status' => $order['payment_status'], 'razorpay_order_id' => $order['razorpay_order_id'],
            'razorpay_payment_id' => $order['razorpay_payment_id'] ?? null,
            'message' => $order['payment_status'] === 'paid' ? 'Payment confirmed. Your fee records have been updated.'
                : ($order['payment_status'] === 'review' ? 'Payment received, but the fee changed. Contact the school with this payment reference for adjustment or refund.'
                    : 'Payment is not yet confirmed. Check again before retrying if money was deducted.')];
    }
}
