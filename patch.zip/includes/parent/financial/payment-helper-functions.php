<?php
require_once __DIR__ . '/../../financial/monthly-fee-ledger.php';
function updateMonthlyPaymentRecords($pdo, $unpaid_fee_data)
{
    try {
        $pdo->beginTransaction();
        $studentLock = $pdo->prepare('SELECT student_id FROM students WHERE student_id = ? FOR UPDATE');
        $studentLock->execute([$unpaid_fee_data['student_id']]);
        $feeLock = $pdo->prepare('SELECT * FROM student_unpaid_fees WHERE id = ? AND student_id = ? FOR UPDATE');
        $feeLock->execute([$unpaid_fee_data['id'], $unpaid_fee_data['student_id']]);
        $currentFee = $feeLock->fetch(PDO::FETCH_ASSOC);
        if (!$currentFee || MonthlyFeeLedger::cents($currentFee['unpaid_amount']) !== MonthlyFeeLedger::cents($unpaid_fee_data['unpaid_amount'])) {
            throw new DomainException('The fee changed before this payment was recorded.');
        }
        $unpaid_fee_data = $currentFee;
        $monthlyLedger = new MonthlyFeeLedger($pdo);
        $bill = $monthlyLedger->ensure($unpaid_fee_data);
        $snapshots = [['month_year' => $unpaid_fee_data['month_year'], 'snapshot' => $monthlyLedger->snapshot($bill)]];
        $allocationIds = $monthlyLedger->allocate($bill, $unpaid_fee_data['unpaid_amount'], 'payment', date('Y-m-d'), 'online');

        $unpaid_amount = $unpaid_fee_data['unpaid_amount'];

        $student_id = $unpaid_fee_data['student_id'];
        $unpaid_fee_rows_backup[] = $unpaid_fee_data; // backup unpaid fee row

        $unpaid_fee_id = $unpaid_fee_data['id'];
        $month_year = $unpaid_fee_data['month_year'];
        $actual_amount = $unpaid_fee_data['actual_amount'];
        $remark = $unpaid_fee_data['remark'];
        $discount_amount = $unpaid_fee_data['discount_amount'];
        $unpaid_amount = $unpaid_fee_data['unpaid_amount'];
        $payment_date = date("Y-m-d");

        $paid_amount = $unpaid_amount;

        // Insert into full_paid_fees table
        $stmt = $pdo->prepare("
                    INSERT INTO student_full_paid_fees
                    (
                    student_id, 
                    month_year, 
                    actual_amount, 
                    discount_amount, 
                    total_paid_amount, 
                    last_paid_amount, 
                    remark, 
                    created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
                ");
        $stmt->execute([$student_id, $month_year, $actual_amount, $discount_amount, ($actual_amount - $discount_amount), $paid_amount, $remark]);
        $full_paid_fees_id = $pdo->lastInsertId();

        $full_paid_payment_ids[] = $full_paid_fees_id;

        // Insert partial payment record
        $partial_remark = "₹" . $paid_amount . "/- was paid for fee payment " . $month_year . " through online transaction. (" . $payment_date . ")";
        $payment_history_remarks[] = "₹" . $paid_amount . " was paid for payment " . $month_year . " through online transaction.";

        $stmt = $pdo->prepare("
                    INSERT INTO student_partial_payments
                    (
                    student_id, 
                    month_year, 
                    unpaid_fees_id, 
                    full_paid_fees_id, 
                    partial_paid_amount, 
                    method, 
                    remark,
                    created_at
                    ) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");

        $stmt->execute([$student_id, $month_year, $unpaid_fee_id, $full_paid_fees_id, $paid_amount, 'online', $partial_remark, $payment_date]);

        $partial_payment_ids_backup[] = $pdo->lastInsertId();

        // Update partial payments table for inserting full paid fees id  
        $stmt = $pdo->prepare("UPDATE student_partial_payments SET full_paid_fees_id = ? WHERE unpaid_fees_id = ?");
        $stmt->execute([$full_paid_fees_id, $unpaid_fee_id]);

        // Delete unpaid fees table data
        $stmt = $pdo->prepare("DELETE FROM student_unpaid_fees WHERE id = ?");
        $stmt->execute([$unpaid_fee_id]);

        // Insert payment history
        $payment_history_remark = implode(' & ', $payment_history_remarks);

        $stmt = $pdo->prepare("
            INSERT INTO student_payment_history
            (
            student_id, 
            payment_amount, 
            payment_date, 
            remark, 
            full_paid_payment_ids, 
            partial_payment_ids_backup,
            wallet_affected_balance,
            wallet_transaction_id,
            unpaid_fee_rows_backup,
            method,
            monthly_bill_snapshots
            ) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $student_id,
            $unpaid_amount,
            $payment_date,
            $payment_history_remark,
            json_encode($full_paid_payment_ids),
            json_encode($partial_payment_ids_backup),
            0,
            null,
            json_encode($unpaid_fee_rows_backup),
            'online',
            json_encode($snapshots, JSON_THROW_ON_ERROR)
        ]);
        $monthlyLedger->link($allocationIds, (int)$pdo->lastInsertId());

        $pdo->commit(); // ✅ All good
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

// Update the records in student_admission_fees table
function updateAdmissionPaymentRecords($pdo, $unpaid_fee_data) {
    $id = $unpaid_fee_data['id'];
    $unpaid_amount = 0;
    $payment_status = 'paid';
    $remark = 'Admission fee is cleared and fully paid.';

    $stmt = $pdo->prepare("UPDATE student_admission_fees SET unpaid_amount = ?, payment_status = ?, remark = ? WHERE id = ?");
    $stmt->execute([$unpaid_amount, $payment_status, $remark, $id]);
}
