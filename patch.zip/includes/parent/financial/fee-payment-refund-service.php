<?php
require_once __DIR__ . '/fee-payment-service.php';

/** Processes only refund intents already committed by an authenticated reversal. */
class FeePaymentRefundService
{
    public function __construct(private PDO $pdo, private FeePaymentGateway $gateway) {}

    public function process(int $id, bool $submit = false): array
    {
        if ($this->pdo->inTransaction()) throw new LogicException('Refunds must run after the reversal transaction commits.');
        $stmt = $this->pdo->prepare('SELECT * FROM online_fee_payment_orders WHERE id = ?');
        $stmt->execute([$id]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$order || !in_array($order['payment_status'], ['refund_pending', 'refund_failed', 'refunded'], true)) {
            throw new InvalidArgumentException('No reversed online payment was found.');
        }
        if ($order['payment_status'] === 'refunded') return $order;
        $state = $order['payment_status'];
        $refundId = $order['razorpay_refund_id'] ?? null;
        $error = null;
        try {
            $paymentId = $order['razorpay_payment_id'] ?? '';
            $key = $order['refund_idempotency_key'] ?? '';
            $amount = (int)($order['refund_amount_paise'] ?? 0);
            if (!preg_match('/^pay_[a-zA-Z0-9]+$/D', $paymentId) || !preg_match('/^[a-zA-Z0-9_-]{10,100}$/D', $key)
                || $amount <= 0 || $amount > (int)$order['total_paise']) {
                throw new RuntimeException('Invalid stored refund request. Contact technical support.');
            }
            $payment = $this->gateway->payment($paymentId);
            if (($payment['id'] ?? '') !== $paymentId || ($payment['order_id'] ?? '') !== $order['razorpay_order_id']
                || ($payment['currency'] ?? '') !== 'INR' || (int)($payment['amount'] ?? 0) !== (int)$order['total_paise']
                || !in_array($payment['status'] ?? '', ['captured', 'refunded'], true)) {
                throw new RuntimeException('Provider payment does not match this reversed order.');
            }
            $refund = null;
            // Check dashboard refunds too, including manual resolution of a failed request.
            $refunds = $this->gateway->refunds($paymentId);
            $processed = 0;
            $processedId = null;
            foreach ($refunds as $existing) {
                if (!preg_match('/^rfnd_[a-zA-Z0-9]+$/D', $existing['id'] ?? '')
                    || ($existing['payment_id'] ?? '') !== $paymentId || ($existing['currency'] ?? '') !== 'INR'
                    || (int)($existing['amount'] ?? 0) <= 0) {
                    throw new RuntimeException('Provider refund does not match this payment.');
                }
                if (($existing['receipt'] ?? '') === $key) $refund = $existing;
                if (($existing['status'] ?? '') === 'processed') {
                    $processed += (int)$existing['amount'];
                    $processedId = $existing['id'];
                }
            }
            if ($processed === $amount && (int)($payment['amount_refunded'] ?? 0) === $amount) {
                $state = 'refunded';
                $refundId = $processedId;
                $refund = null;
            } elseif ($refundId) {
                $refund = $this->gateway->refundById($refundId);
                if (($refund['id'] ?? '') !== $refundId) throw new RuntimeException('Provider refund ID does not match the stored reference.');
            } else {
                if (!$refund && ((int)($payment['amount_refunded'] ?? 0) > 0 || $refunds !== [])) {
                    throw new RuntimeException('An external or partial refund exists. Resolve it in Razorpay, then check status again.');
                } elseif (!$refund && $submit) {
                    $refund = $this->gateway->refund($paymentId, $amount, $key);
                }
            }
            if ($refund) {
                if (!preg_match('/^rfnd_[a-zA-Z0-9]+$/D', $refund['id'] ?? '')
                    || ($refund['payment_id'] ?? '') !== $paymentId || ($refund['currency'] ?? '') !== 'INR'
                    || (int)($refund['amount'] ?? 0) !== $amount
                    || !in_array($refund['status'] ?? '', ['pending', 'processed', 'failed'], true)) {
                    throw new RuntimeException('Provider refund response does not match the stored request.');
                }
                $refundId = $refund['id'];
                $state = ['pending' => 'refund_pending', 'processed' => 'refunded', 'failed' => 'refund_failed'][$refund['status']];
                if ($state === 'refund_failed') $error = 'Razorpay reports that this refund failed. Resolve it in Razorpay, then check status again.';
            }
        } catch (Throwable $e) {
            // A timeout may mean the provider accepted the request. Keep the same key and intent.
            $error = substr($e->getMessage(), 0, 1000);
        }

        $this->pdo->beginTransaction();
        try {
            $stmt = $this->pdo->prepare('SELECT * FROM online_fee_payment_orders WHERE id = ? FOR UPDATE');
            $stmt->execute([$id]);
            $current = $stmt->fetch(PDO::FETCH_ASSOC);
            // Delayed responses cannot undo a completed refund or forget a known provider reference.
            if ($current['payment_status'] !== 'refunded') {
                $refundId = $refundId ?: ($current['razorpay_refund_id'] ?? null);
                if ($state === 'refund_pending' && $current['payment_status'] === 'refund_failed') {
                    $state = 'refund_failed';
                    $error = $current['refund_error'] ?? $error;
                }
                $stmt = $this->pdo->prepare('UPDATE online_fee_payment_orders SET payment_status = ?, razorpay_refund_id = ?, refund_error = ? WHERE id = ?');
                $stmt->execute([$state, $refundId, $error, $id]);
                $current = array_replace($current, ['payment_status' => $state, 'razorpay_refund_id' => $refundId, 'refund_error' => $error]);
            }
            $this->pdo->commit();
            return $current;
        } catch (Throwable $e) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            throw $e;
        }
    }
}
