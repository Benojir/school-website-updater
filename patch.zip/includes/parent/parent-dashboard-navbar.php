<div class="container">
    <div class="row mx-1 mt-3 p-3 shadow-sm bg-primary rounded">
        <!-- Left Column -->
        <div class="col-6 text-start">
            <a href="parent-dashboard.php" class="btn btn-outline-light">
                <i class="fa-solid fa-home"></i> Home
            </a>
        </div>

        <!-- Right Column -->
        <div class="col-6 text-end">
            <a href="../auth/logout-parent.php" class="btn btn-outline-light">
                <i class="fa-solid fa-arrow-right-from-bracket"></i> Logout
            </a>
        </div>
    </div>
</div>
