<?php
include_once __DIR__ . '/../../config.php';

/**
 * Authenticates a parent request from either Mobile (Bearer Token) or Web (Cookie).
 *
 * @param PDO $pdo The database connection.
 * @return array|null The authenticated parent/session data, or null if not authenticated.
 */
function getAuthenticatedParent($pdo) {
    $token = null;
    $headers = getallheaders();

    // 1. Check for Mobile App's Bearer Token
    if (!empty($headers['Authentication']) && strpos($headers['Authentication'], 'Bearer ') === 0) {
        $token = str_replace('Bearer ', '', $headers['Authentication']);
    }
    
    // 2. If no Bearer token, check for Web's Auth Cookie
    if (empty($token) && !empty($_COOKIE['parent_auth_token'])) {
        $token = $_COOKIE['parent_auth_token'];
    }

    // 3. If no token found, user is not logged in
    if (empty($token)) {
        return null; 
    }

    // 4. Validate the token against the database
    $tokenHash = hash('sha256', $token);

    // Use the NEW table name 'parent_auth_sessions'
    $stmt = $pdo->prepare("SELECT * FROM parent_auth_sessions WHERE token_hash = ?");
    $stmt->execute([$tokenHash]);
    $session = $stmt->fetch();

    if (!$session) {
        return null; // Invalid or expired token
    }

    // 5. Update the last activity timestamp
    $stmt = $pdo->prepare("UPDATE parent_auth_sessions SET last_activity = NOW() WHERE id = ?");
    $stmt->execute([$session['id']]);

    // Return all relevant parent and session data
    return [
        'success' => true,
        'message' => 'Token successfully validated',
        'phone_number' => $session['phone'],
        'session_id' => $session['id'],
        'device_id' => $session['device_id'],
        'fcm_token' => $session['fcm_token'] ?? null,
        'session_source' => $session['session_source']
    ];
}

/**
 * A helper function for protected API endpoints (Mobile or Web AJAX).
 * It calls getAuthenticatedParent and exits with a 401 error if auth fails.
 *
 * @param PDO $pdo
 * @return array The authenticated parent data.
 */
function authenticateApiRequest($pdo) {
    $authData = getAuthenticatedParent($pdo);
    
    if (!$authData) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Unauthorized: Invalid or expired token']);
        exit;
    }
    
    return $authData;
}

/**
 * A helper function for protected WEB pages (not APIs).
 * It redirects to a login page if authentication fails.
 *
 * @param PDO $pdo
 * @param string $loginPageUrl The URL to redirect to if not logged in.
 * @return array The authenticated parent data.
 */
function authenticateWebPageRequest($pdo, $loginPageUrl = '/parent') {
    $authData = getAuthenticatedParent($pdo);
    
    if (!$authData) {
        // Redirect to the login page
        header('Location: ' . $loginPageUrl);
        exit;
    }
    
    return $authData;
}

/**
 * Check if parent has access to the requested student
 * (This function is from your old mobile-auth.php, no changes needed)
 */
function hasParentAccessToStudent(string $phoneNumber, string $studentId) {
    global $pdo; // Assumes $pdo is global or passed in
    
    $stmt = $pdo->prepare("SELECT 1 FROM students WHERE (phone_number = ? OR alternate_phone_number = ?) AND student_id = ? LIMIT 1");
    $stmt->execute([$phoneNumber, $phoneNumber, $studentId]);
    
    if ($stmt->fetch()) {
        return true;
    } else {
        return false;
    }
}