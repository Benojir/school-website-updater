<?php
 /**
 * Send Firebase notification using a Node.js server
 * @param array $deviceTokens Array of device tokens
 * @param string $title Notification title
 * @param string $body Notification body
 * @param array $data Additional data to send with the notification
 * @return array Result of the notification send operation
 */
function sendFirebaseNotification(PDO $pdo, array $studentIds, $deviceTokens, $title, $body, array $data) {
    $nodeServerUrl = 'https://fcm.dahukinfotech.com/send-notification-fast'; // Update with your Node server URL
    
    $payload = [
        'device_tokens' => $deviceTokens,
        'title' => $title,
        'body' => $body,
        'data' => $data
    ];
    
    $options = [
        'http' => [
            'header'  => "Content-type: application/json\r\n",
            'method'  => 'POST',
            'content' => json_encode($payload),
        ]
    ];
    
    $context  = stream_context_create($options);
    $result = file_get_contents($nodeServerUrl, false, $context);
    
    if ($result === false) {
        return [
            'success' => false,
            'message' => 'Failed to connect to notification server'
        ];
    } else {
        // If notification sent successfully, log it
        insertNotificationLog($pdo, $studentIds, $title, $body);
    }
    
    return json_decode($result, true);
}

/**
 * Insert a notification log into the database
 * @param PDO $pdo Database connection
 * @param array $studentIds Array of student IDs
 * @param string $title Notification title
 * @param string $body Notification body
 */
function insertNotificationLog(PDO $pdo, array $studentIds, string $title, string $body): void {
    $stmt = $pdo->prepare("INSERT INTO mobile_notification_logs (student_ids, notification_title, notification_body, created_at) VALUES (:student_ids, :title, :body, NOW())");
    $stmt->execute([
        ':student_ids' => implode(',', $studentIds),
        ':title' => $title,
        ':body' => $body
    ]);
}

/**
 * Delete notification logs older than specified days
 * @param PDO $pdo Database connection
 * @param int $days Number of days to retain logs
 */
function deleteOlderNotificationLogs(PDO $pdo, int $days = 30): void {
    $stmt = $pdo->prepare("DELETE FROM mobile_notification_logs WHERE created_at < NOW() - INTERVAL :days DAY");
    $stmt->execute([':days' => $days]);
}

/**
 * Retrieve FCM tokens for parents based on student IDs
 * @param PDO $pdo Database connection
 * @param array $studentIds Array of student IDs
 * @return array Array of FCM tokens
 */
function getFCMTokensFromDatabase(PDO $pdo, array $studentIds): array {
    $fcmTokens = [];
    
    if (empty($studentIds) || !is_array($studentIds)) {
        return $fcmTokens;
    }

    foreach ($studentIds as $studentId) {
        $stmt = $pdo->prepare("SELECT phone_number FROM students WHERE student_id = ?");
        $stmt->execute([$studentId]);
        $phoneNumber = $stmt->fetchColumn();

        if (!$phoneNumber) {
            continue;
        }

        $stmt = $pdo->prepare("SELECT id FROM parent_accounts WHERE phone_number = ?");
        $stmt->execute([$phoneNumber]);
        $parent_id = $stmt->fetchColumn();

        if (!$parent_id) {
            continue;
        }

        $stmt = $pdo->prepare("SELECT fcm_token FROM parent_auth_sessions WHERE parent_id = ?");
        $stmt->execute([$parent_id]);
        $tokens = $stmt->fetchAll(PDO::FETCH_COLUMN);

        if ($tokens) {
            $trimmedTokens = array_map('trim', array_filter($tokens, 'is_string'));
            $fcmTokens = array_merge($fcmTokens, $trimmedTokens);
        }
    }

    // Remove any duplicates
    $fcmTokens = array_unique($fcmTokens);
    
    return array_values($fcmTokens); // Re-index the array
}