<div class="container">
    <nav class="navbar gradient-heading-bg navbar-expand-lg mt-4 mb-3 p-3 shadow rounded" data-bs-theme="dark">
        <a class="navbar-brand" href="../../management/dashboard/"><i class="fa-solid fa-gauge-high"></i> Dashboard</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav me-auto">
                <li class="nav-item dropdown dropdown-hover">
                    <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-users"></i> Students</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="../../management/view/students-list.php"><i class="fa-solid fa-list-check"></i> Students List</a></li>
                        <li><a class="dropdown-item" href="../../management/form/add-student.php"><i class="fa-solid fa-user-plus"></i> Add Student</a></li>
                        <li><a class="dropdown-item" href="../../management/form/bulk-import-students.php"><i class="fa-solid fa-users"></i> Import Bulk Students</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown dropdown-hover">
                    <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-book-open"></i> Academics</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="../../management/view/manage-classes.php"><i class="fa-solid fa-layer-group"></i> Classes & Sections</a></li>
                        <li><a class="dropdown-item" href="../../management/view/manage-subjects.php"><i class="fa-solid fa-book"></i> Subjects</a></li>
                        <li><a class="dropdown-item" href="../../management/view/view-class-routine.php"><i class="fa-solid fa-calendar-days"></i> Class Routines</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="../../management/form/assign-sections.php"><i class="fa-solid fa-circle-plus"></i> Assign Sections</a></li>
                        <li><a class="dropdown-item" href="../../management/form/assign-roll-numbers.php"><i class="fa-solid fa-circle-plus"></i> Assign Roll Numbers</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown dropdown-hover">
                    <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-file-pen"></i> Examinations</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="../../management/view/list-exams.php"><i class="fa-solid fa-clipboard-list"></i> Exams</a></li>
                        <li><a class="dropdown-item" href="../../management/view/list-exam-routines.php"><i class="fa-solid fa-calendar-check"></i> Exam Routines</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="../../management/form/admit-release.php"><i class="fa-solid fa-address-card"></i> Admit Card Release</a></li>
                        <li><a class="dropdown-item" href="../../management/form/marksheet-release.php"><i class="fa-solid fa-square-poll-horizontal"></i> Marksheet Release</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown dropdown-hover">
                    <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-gears"></i> General</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="../../management/view/list-teachers.php"><i class="fa-solid fa-chalkboard-user"></i> Teachers</a></li>
                        <li><a class="dropdown-item" href="../../management/view/list-drivers.php"><i class="fa-solid fa-van-shuttle"></i> Drivers</a></li>
                        <li><a class="dropdown-item" href="../../management/view/manage-school-notices.php"><i class="fa-solid fa-bullhorn"></i> Notices</a></li>
                        <li><a class="dropdown-item" href="../../management/settings/admin-management.php"><i class="fa-solid fa-users"></i> Manage Admins</a></li>
                        <li><a class="dropdown-item" href="../../management/view/manage-gallery-images.php"><i class="fa-solid fa-images"></i> Image Gallery</a></li>
                        <li><a class="dropdown-item" href="../../management/view/manage-gallery-videos.php"><i class="fa-solid fa-video"></i> Video Gallery</a></li>
                        <li><a class="dropdown-item" href="../../management/view/manage-fees.php"><i class="fa-solid fa-indian-rupee-sign"></i> Class-Wise Fees</a></li>
                        <li><a class="dropdown-item" href="../../management/view/manage-admission-fees.php"><i class="fa-solid fa-indian-rupee-sign"></i> Admission Fees</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown dropdown-hover">
                    <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-sliders"></i> Settings</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="../../management/settings/school-information.php"><i class="fa-solid fa-school"></i> School Details</a></li>
                        <li><a class="dropdown-item" href="../../management/settings/school-logo.php"><i class="fa-solid fa-image"></i> School Logo</a></li>
                        <li><a class="dropdown-item" href="../../management/settings/id-card-style.php"><i class="fa-solid fa-address-card"></i> ID Card Styles</a></li>
                        <li><a class="dropdown-item" href="../../management/settings/carousel-management.php"><i class="fa-solid fa-table-cells-large"></i> Carousels</a></li>
                        <li><a class="dropdown-item" href="../../management/settings/website-designs.php"><i class="fa-solid fa-palette"></i> Website Template</a></li>
                        <li><a class="dropdown-item" href="../../management/settings/website-theme.php"><i class="fa-solid fa-paintbrush"></i> Website Theme Color</a></li>
                        <li><a class="dropdown-item" href="../../management/settings/website-config.php"><i class="fa-solid fa-gear"></i> Configuration</a></li>
                    </ul>
                </li>
            </ul>
            
            <!-- User dropdown with logout -->
            <ul class="navbar-nav">
                <li class="nav-item dropdown dropdown-hover">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <span class="me-2"><i class="fa-solid fa-user-circle"></i> <?=$_SESSION['user']['full_name'];?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="../../management/settings/admin-profile.php"><i class="fa-solid fa-user me-2"></i> Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="../../management/action/logout.php"><i class="fa-solid fa-right-from-bracket me-2"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</div>

<style>
    .gradient-heading-bg {
        background: #020024;
        /* background: linear-gradient(90deg, rgba(2, 0, 36, 1) 0%, rgba(9, 9, 121, 1) 43%, rgba(0, 212, 255, 1) 100%); */
        background: linear-gradient(90deg, var(--primary-dark) 0%, var(--primary-color) 43%, var(--primary-light) 100%);
        border-left: 5px solid var(--primary-light) !important;
    }
    
    /* Hover functionality for dropdowns */
    @media (min-width: 992px) {
        .dropdown-hover:hover .dropdown-menu {
            display: block;
            margin-top: 0;
        }
    }
    
    /* User dropdown styling */
    .navbar-nav .dropdown-menu-end {
        right: 0;
        left: auto;
    }
    
    /* Improve dropdown item spacing and icons */
    .dropdown-item {
        padding: 0.5rem 1.5rem;
    }
    
    .dropdown-item i {
        width: 20px;
        text-align: center;
        margin-right: 10px;
    }
    
    /* User name styling */
    .nav-link span {
        color: rgba(255, 255, 255, 0.85);
    }
    
    /* Logout button styling */
    .dropdown-item.text-danger {
        color: #dc3545 !important;
    }
    
    .dropdown-item.text-danger:hover {
        background-color: #dc3545;
        color: white !important;
    }
</style>