<?php
// Before including admin nav, check admin login validation
if (!isAnyAdminLoggedIn()) {
    echo '<script>location.replace("/");</script>';
    exit();
}
?>

<div class="container">
    <nav class="navbar gradient-heading-bg navbar-expand-lg mt-4 mb-3 p-3 shadow rounded" data-bs-theme="dark">
        <a class="navbar-brand" href="../../management/dashboard/"><i class="fa-solid fa-gauge-high"></i> Dashboard</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav me-auto">
                <li class="nav-item dropdown dropdown-hover">
                    <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-users"></i> Students</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="../../management/student/list-students.php"><i class="fa-solid fa-list-check"></i> Students List</a></li>
                        <li><a class="dropdown-item" href="../../management/student/add-student.php"><i class="fa-solid fa-user-plus"></i> New Admission</a></li>
                        <li><a class="dropdown-item" href="../../management/student/bulk-import-students.php"><i class="fa-solid fa-users"></i> Import Bulk Students</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown dropdown-hover">
                    <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-book-open"></i> Academics</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="../../management/class/manage-classes.php"><i class="fa-solid fa-layer-group"></i> Classes & Sections</a></li>
                        <li><a class="dropdown-item" href="../../management/academic/manage-subjects.php"><i class="fa-solid fa-book"></i> Subjects</a></li>
                        <li><a class="dropdown-item" href="../../management/class/view-class-routine.php"><i class="fa-solid fa-calendar-days"></i> Class Routines</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="../../management/academic/assign-sections.php"><i class="fa-solid fa-circle-plus"></i> Assign Sections</a></li>
                        <li><a class="dropdown-item" href="../../management/academic/assign-roll-numbers.php"><i class="fa-solid fa-circle-plus"></i> Assign Roll Numbers</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown dropdown-hover">
                    <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-file-pen"></i> Examinations</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="../../management/exam/list-exams.php"><i class="fa-solid fa-clipboard-list"></i> Exams</a></li>
                        <li><a class="dropdown-item" href="../../management/exam/list-exam-routines.php"><i class="fa-solid fa-calendar-check"></i> Exam Routines</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="../../management/exam/admit-release.php"><i class="fa-solid fa-address-card"></i> Admit Card Release</a></li>
                        <li><a class="dropdown-item" href="../../management/marksheet/marksheet-release.php"><i class="fa-solid fa-square-poll-horizontal"></i> Marksheet Release</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="../../management/marksheet/students-ranking.php"><i class="fa-solid fa-ranking-star"></i> Students Ranking</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown dropdown-hover">
                    <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false"><i class="fa-solid fa-gears"></i> General</a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="../../management/teacher/list-teachers.php"><i class="fa-solid fa-chalkboard-user"></i> Teachers</a></li>
                        <li><a class="dropdown-item" href="../../management/driver/list-drivers.php"><i class="fa-solid fa-van-shuttle"></i> Drivers</a></li>
                        <li><a class="dropdown-item" href="../../management/notice/manage-school-notices.php"><i class="fa-solid fa-bullhorn"></i> Notices</a></li>
                        <li><a class="dropdown-item" href="../../management/school/school-expenses.php"><i class="fa-solid fa-coins"></i> Expenses</a></li>
                        <li class="dropdown">
                            <a class="dropdown-item dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fa-solid fa-images"></i> Gallery
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="../../management/gallery/carousel-management.php"><i class="fa-solid fa-table-cells-large"></i> Carousels</a></li>
                                <li><a class="dropdown-item" href="../../management/gallery/manage-gallery-images.php"><i class="fa-solid fa-images"></i> Image Gallery</a></li>
                                <li><a class="dropdown-item" href="../../management/gallery/manage-gallery-videos.php"><i class="fa-solid fa-video"></i> Video Gallery</a></li>
                            </ul>
                        </li>
                        <li><a class="dropdown-item" href="../../management/settings/admin-management.php"><i class="fa-solid fa-users"></i> Manage Admins</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown dropdown-hover">
                    <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
                        <i class="fa-solid fa-sliders"></i> Settings
                    </a>
                    <ul class="dropdown-menu">
                        <li class="dropdown">
                            <a class="dropdown-item dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fa-solid fa-rupee-sign"></i> School Fees Setup
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="../../management/fees-x-payments/manage-additional-fees.php"><i class="fa-solid fa-indian-rupee-sign"></i> Additional School Fees</a></li>
                                <li><a class="dropdown-item" href="../../management/fees-x-payments/manage-monthly-fees.php"><i class="fa-solid fa-indian-rupee-sign"></i> Class-Wise Fees</a></li>
                                <li><a class="dropdown-item" href="../../management/fees-x-payments/manage-admission-fees.php"><i class="fa-solid fa-indian-rupee-sign"></i> Admission Fees</a></li>
                            </ul>
                        </li>
                        <li><a class="dropdown-item" href="../../management/settings/school-settings.php"><i class="fa-solid fa-school"></i> School Settings</a></li>
                        <li><a class="dropdown-item" href="../../management/settings/school-logo.php"><i class="fa-solid fa-image"></i> School Logo</a></li>
                        <li class="dropdown">
                            <a class="dropdown-item dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fa-solid fa-gears"></i> Additional Settings
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="../../management/settings/student-id-card-settings.php"><i class="fa-solid fa-address-card"></i> Student ID Card Settings</a></li>
                                <li><a class="dropdown-item" href="../../management/settings/marksheet-settings.php"><i class="fa-solid fa-file-alt"></i> Marksheet Settings</a></li>
                                <li><a class="dropdown-item" href="../../management/settings/admission-form-settings.php"><i class="fa-solid fa-file-alt"></i> Admission Form Settings</a></li>
                                <li><a class="dropdown-item" href="../../management/settings/website-designs.php"><i class="fa-solid fa-palette"></i> Website Template</a></li>
                                <li><a class="dropdown-item" href="../../management/settings/404-page-settings.php"><i class="fa-solid fa-palette"></i> Error Page Template</a></li>
                                <li><a class="dropdown-item" href="../../management/settings/website-theme.php"><i class="fa-solid fa-paintbrush"></i> Website Theme Color</a></li>
                            </ul>
                        </li>
                        <li><a class="dropdown-item" href="../../management/settings/website-config.php"><i class="fa-solid fa-gear"></i> Configuration</a></li>
                    </ul>
                </li>
            </ul>

            <!-- User dropdown with logout -->
            <ul class="navbar-nav">
                <li class="nav-item dropdown dropdown-hover">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <span class="me-2"><i class="fa-solid fa-user-circle"></i> <?= $_COOKIE['full_name']; ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="../../management/settings/admin-profile.php"><i class="fa-solid fa-user me-2"></i> Profile</a></li>
                        <li><a class="dropdown-item" href="<?= BASE_URL ?>" target="_blank"><i class="fa-solid fa-globe me-2"></i> Website</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item text-danger" href="../../api/admin/auth/logout.php"><i class="fa-solid fa-right-from-bracket me-2"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</div>

<style>
    .gradient-heading-bg {
        background: #020024;
        /* background: linear-gradient(90deg, rgba(2, 0, 36, 1) 0%, rgba(9, 9, 121, 1) 43%, rgba(0, 212, 255, 1) 100%); */
        background: linear-gradient(90deg, var(--primary-dark) 0%, var(--primary-color) 43%, var(--primary-light) 100%);
        border-left: 5px solid var(--primary-light) !important;
    }

    /* Hover functionality for dropdowns */
    @media (min-width: 992px) {

        /* Only show the direct child dropdown on hover */
        .dropdown-hover:hover>.dropdown-menu {
            display: block;
            margin-top: 0;
        }

        /* Show the nested dropdown when hovering its parent list item */
        .dropdown-menu>.dropdown>.dropdown-menu {
            display: none;
        }

        .dropdown-menu>.dropdown:hover>.dropdown-menu {
            display: block;
        }

        /* Adjust nested dropdown position */
        .dropdown-menu .dropdown-menu {
            left: 100%;
            top: -7px;
            /* Adjust as needed */
        }
    }

    /* User dropdown styling */
    .navbar-nav .dropdown-menu-end {
        right: 0;
        left: auto;
    }

    /* Improve dropdown item spacing and icons */
    .dropdown-item {
        padding: 0.5rem 1.5rem;
    }

    .dropdown-item i {
        width: 20px;
        text-align: center;
        margin-right: 10px;
    }

    /* User name styling */
    .nav-link span {
        color: rgba(255, 255, 255, 0.85);
    }

    /* Logout button styling */
    .dropdown-item.text-danger {
        color: #dc3545 !important;
    }

    .dropdown-item.text-danger:hover {
        background-color: #dc3545;
        color: white !important;
    }
</style>