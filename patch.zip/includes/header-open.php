<?php

/** @var array $websiteConfig
 * @var array $schoolInfo
 * @var string $school_name
 * @var string $theme_color
 * @var string $theme_color_dark
 * @var string $theme_color_light
 */
ob_start();

include_once("config.php");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$assets_version = (isset($_SESSION['assets_version']) ? $_SESSION['assets_version'] : '1.10.1');

$seo_title = $school_name . ' - ' . (!empty($schoolInfo['campus_name']) ? $schoolInfo['campus_name'] . ' ' : '') . 'Official Website';
$seo_description = $schoolInfo['meta_description'];
$seo_keywords = $school_name . ', School, Education, Learning, Classes, Teachers, Admissions, Gallery, Notices, +91' . $schoolInfo['phone'] . ', ' . $schoolInfo['email'];

$currentUrl = (isset($_SERVER['HTTPS']) ? 'https' : 'http')
    . '://' . $_SERVER['HTTP_HOST']
    . $_SERVER['REQUEST_URI'];

$logo_square_path = __DIR__ . '/../uploads/school/logo-square.png';
$logo_square_mod_time = file_exists($logo_square_path) ? filemtime($logo_square_path) : 0;
$logo_square = BASE_URL . '/uploads/school/logo-square.png?v=' . $logo_square_mod_time;

$logo_rectangle_path = __DIR__ . '/../uploads/school/logo-rectangle.png';
$logo_rectangle_mod_time = file_exists($logo_rectangle_path) ? filemtime($logo_rectangle_path) : 0;
$logo_rectangle = BASE_URL . '/uploads/school/logo-rectangle.png?v=' . $logo_rectangle_mod_time;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="content-language" content="en-IN">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="robots" content="index, follow">
    <meta name="author" content="<?= $school_name; ?>">
    <meta name="theme-color" content="<?= $theme_color; ?>">
    <meta name="description" content="<?= $seo_description; ?>">
    <meta name="keywords" content="<?= $seo_keywords; ?>">
    <meta name="copyright" content="© <?= date('Y'); ?> <?= $school_name; ?>">
    <meta name="distribution" content="global">
    <meta name="rating" content="General">

    <link rel="canonical" href="<?= safe_htmlspecialchars($currentUrl); ?>">

    <meta property="og:title" content="<?= $seo_title; ?>">
    <meta property="og:description" content="<?= $seo_description; ?>">
    <meta property="og:url" content="<?= safe_htmlspecialchars($currentUrl); ?>">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="<?= $school_name; ?>">
    <meta property="og:image" content="<?= $logo_square; ?>">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= $seo_title; ?>">
    <meta name="twitter:description" content="<?= $seo_description; ?>">
    <meta name="twitter:image" content="<?= $logo_square; ?>">

    <meta property="og:image:width" content="512">
    <meta property="og:image:height" content="512">
    <meta property="og:image:alt" content="<?= safe_htmlspecialchars($school_name); ?>">

    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "School",
            "@id": <?= json_encode(rtrim(BASE_URL, '/') . '/#school'); ?>,
            "name": <?= json_encode($school_name); ?>,
            "alternateName": <?= json_encode($school_name); ?>,
            "url": <?= json_encode(BASE_URL); ?>,

            "logo": <?= json_encode($logo_square); ?>,
            "image": <?= json_encode($logo_square); ?>,

            "description": <?= json_encode($schoolInfo['meta_description']); ?>,

            "telephone": <?= json_encode('+91' . $schoolInfo['phone']); ?>,
            "email": <?= json_encode($schoolInfo['email']); ?>,

            "contactPoint": {
                "@type": "ContactPoint",
                "telephone": <?= json_encode('+91' . $schoolInfo['phone']); ?>,
                "contactType": "school office",
                "areaServed": "IN",
                "availableLanguage": ["Bengali", "English"]
            },

            "address": {
                "@type": "PostalAddress",
                "streetAddress": <?= json_encode($schoolInfo['address']); ?>,
                "addressLocality": <?= json_encode($schoolInfo['village'] ?? ''); ?>,
                "addressRegion": <?= json_encode($schoolInfo['state'] ?? 'West Bengal'); ?>,
                "postalCode": <?= json_encode($schoolInfo['pincode'] ?? ''); ?>,
                "addressCountry": "IN"
            },

            "sameAs": [
                <?= json_encode($schoolInfo['facebook']); ?>,
                <?= json_encode($schoolInfo['instagram']); ?>,
                <?= json_encode($schoolInfo['youtube'] ?? ''); ?>
            ],

            "hasMap": <?= json_encode($schoolInfo['google_map_link']); ?>,

            "foundingDate": <?= json_encode($schoolInfo['established_year'] ?? ''); ?>,

            "areaServed": {
                "@type": "Country",
                "name": "India"
            },

            "keywords": <?= json_encode("school, education, students, admissions, results, routines, notices"); ?>,

            "mainEntityOfPage": {
                "@type": "WebPage",
                "@id": <?= json_encode($currentUrl); ?>
            }
        }
    </script>

    <!-- Fav Icon -->
    <link rel="icon" href="<?= BASE_URL ?>/uploads/school/favicon.png">
    <link rel="apple-touch-icon" href="<?= BASE_URL ?>/uploads/school/favicon.png">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- JQuery -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>

    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" />

    <!-- Slick -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>

    <!-- Fancybox -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.css" />
    <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.umd.js"></script>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&family=Nunito:wght@400;700;900&family=Balsamiq+Sans:wght@700&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

    <!-- DataTables -->
    <!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script> -->

    <!-- Image Cropper -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.js"></script>

    <!-- Toastr -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastr@2.1.4/build/toastr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/toastr@2.1.4/toastr.min.js"></script>

    <!-- Load hCaptcha script WITH callback -->
    <script src="https://js.hcaptcha.com/1/api.js?onload=onHcaptchaLoad&render=explicit" async defer></script>

    <!-- Sweetalert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Select 2 -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <!-- Tippy.js (Popper.js is a dependency) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/tippy.js@6.3.7/dist/tippy.umd.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tippy.js@6.3.7/dist/tippy.min.css" />

    <!-- Flatpickr -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/1.1.2/css/bootstrap-multiselect.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/1.1.2/js/bootstrap-multiselect.min.js"></script>

    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/animate.css@4.1.1/animate.min.css" />

    <!-- Sortable.js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.0/Sortable.min.js"></script>

    <!-- Universal CSS & JS -->
    <script defer src="<?php echo BASE_URL; ?>/assets/js/universal-functions.js?v=<?= $assets_version ?>"></script>
    <script defer src="<?php echo BASE_URL; ?>/assets/js/universal-events.js?v=<?= $assets_version ?>"></script>
    <link href="<?php echo BASE_URL; ?>/assets/css/universal.css?v=<?= $assets_version ?>" rel="stylesheet" />

    <script>
        $(document).ready(() => {

            initTooltips();

            // Toastr Configuration
            toastr.options = {
                "closeButton": true,
                "progressBar": true,
                "positionClass": "toast-bottom-right",
                "timeOut": "5000",
                "extendedTimeOut": "2000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            };
        });
    </script>

    <style>
        :root {
            --primary-color: <?php echo $theme_color; ?>;
            --primary-dark: <?php echo $theme_color_dark; ?>;
            --primary-light: <?php echo $theme_color_light; ?>;
            --secondary-color: #333333;
            --light-color: #f8f9fa;
            --dark-color: #212529;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        #website-main-content {
            display: none;
            /* Hide body by default */
        }

        .noscript-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: #111;
            color: #fff;
            font-family: sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 20px;
            z-index: 9999;
        }

        .bg-primary {
            background-color: var(--primary-color) !important;
        }

        .text-primary {
            color: var(--primary-color) !important;
        }

        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
        }

        .btn-primary:active {
            background-color: var(--primary-dark) !important;
            border-color: var(--primary-dark) !important;
        }

        .btn-outline-primary {
            color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .btn-outline-primary:hover {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .btn-outline-primary:active {
            background-color: var(--primary-dark) !important;
            border-color: var(--primary-dark) !important;
        }

        /* Fullscreen overlay */
        #preloader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: radial-gradient(ellipse at center, #1a1a2e 0%, #16213e 100%);
            z-index: 99999;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
        }

        .preloader-wrapper {
            display: flex;
            gap: 10px;
        }

        .dot {
            width: 18px;
            height: 18px;
            background: #00f5d4;
            border-radius: 50%;
            animation: bounce 0.6s infinite ease-in-out;
        }

        .dot2 {
            animation-delay: 0.1s;
            background: #00bbf9;
        }

        .dot3 {
            animation-delay: 0.2s;
            background: #9b5de5;
        }

        .dot4 {
            animation-delay: 0.3s;
            background: #f15bb5;
        }

        @keyframes bounce {

            0%,
            100% {
                transform: translateY(0);
            }

            50% {
                transform: translateY(-20px);
            }
        }
    </style>

    <script>
        // Hide body initially (you should set this in CSS too)
        document.documentElement.style.overflow = "hidden";

        window.addEventListener('load', function() {
            // Show the main content
            document.getElementById('website-main-content').style.display = "block";
            document.documentElement.style.overflow = "";

            // Hide the preloader
            const preloader = document.getElementById('preloader');
            preloader.style.opacity = '0';
            preloader.style.visibility = 'hidden';
            preloader.style.transition = 'opacity 0.5s ease';
            setTimeout(() => preloader.remove(), 600);
        });

        $(document).ready(function() {
            // Applying select2 which element has class select2
            $('.select2').select2({
                theme: 'bootstrap-5',
                width: '100%'
            });

            flatpickr('input[type="date"]', {
                // এটি হলো আসল ভ্যালু যা PHP এবং ডেটাবেসে যাবে (লুকানো থাকবে)
                dateFormat: "Y-m-d",

                // এটি ব্যবহারকারীকে অন্য একটি সুন্দর ফরম্যাট দেখানোর জন্য
                altInput: true,

                // ব্যবহারকারী স্ক্রিনে এই ফরম্যাটটি দেখতে পাবেন (যেমন: 25/12/2026)
                altFormat: "d/m/Y",

                allowInput: true
            });
        })
    </script>