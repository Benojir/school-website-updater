</head>

<body>
    <!-- Message for users without JavaScript -->
    <noscript>
        <div class="noscript-overlay">
            <h2>JavaScript is Disabled</h2>
            <p>Please enable JavaScript in your browser to view this website.</p>
        </div>
    </noscript>

    <?php
    require_once __DIR__ . '/subscription-cache.php';
    $subscriptionCacheFile = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR
        . 'schoolsongi-subscription-' . hash('sha256', __DIR__ . ':' . SCHOOL_ID) . '.json';
    $subscriptions = schoolSongiCachedOverview((string) SCHOOL_ID, $subscriptionCacheFile) ?? [];
    $subscription_access = $subscriptions
        ? schoolSongiSubscriptionPolicy($subscriptions)
        : ['access_blocked' => true, 'access_reason' => 'unavailable'];
    $subscription_days_left = $subscription_access['subscription_days_left'] ?? null;
    // Keep only authentication pages available so an expired school owner can sign in and settle/renew.
    $subscriptionAuthScript = realpath($_SERVER['SCRIPT_FILENAME'] ?? '') ?: '';
    $subscriptionAuthPages = [realpath(__DIR__ . '/../management/auth/login.php'), realpath(__DIR__ . '/../management/auth/admin-forgot-password.php')];
    if ($subscription_access['access_blocked'] && !in_array($subscriptionAuthScript, $subscriptionAuthPages, true)) {
        include_once __DIR__ . '/subscription-expired.php';
    }
    ?>

    <div id="preloader">
        <div class="preloader-wrapper">
            <div class="dot dot1"></div>
            <div class="dot dot2"></div>
            <div class="dot dot3"></div>
            <div class="dot dot4"></div>
        </div>
    </div>

    <div id="website-main-content">
