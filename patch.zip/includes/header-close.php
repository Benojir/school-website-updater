</head>

<body>
    <!-- Message for users without JavaScript -->
    <noscript>
        <div class="noscript-overlay">
            <h2>JavaScript is Disabled</h2>
            <p>Please enable JavaScript in your browser to view this website.</p>
        </div>
    </noscript>

    <?php
    // Fetch subscription details
    $current_time = time();
    $last_sub_fetch_time = $_COOKIE['last_sub_fetch_time'] ?? 0; // In seconds
    $subscriptions = []; // Default empty array
    $is_dashboard_page = strpos($_SERVER['REQUEST_URI'], 'dashboard') !== false;

    // If it's been more than 2 hours since the last fetch or we're on the dashboard page but it's been more than 1 minutes have passed
    if ((!$is_dashboard_page && $current_time - $last_sub_fetch_time > 3600 * 2) || ($is_dashboard_page && $current_time - $last_sub_fetch_time > 60 * 1)) {
        $api_url = 'https://schoolsongi.com/api/get/fetch-school-overview.php?id=' . SCHOOL_ID;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10); // 10 seconds timeout
        $response = curl_exec($ch);

        // Check for cURL errors
        if (!curl_errno($ch) && $response !== false) {
            $decoded_response = json_decode($response, true);

            if (isset($decoded_response['data'])) {
                $subscriptions = $decoded_response['data'];
            } else {
                // Set cookie value to empty when there is no data
                setcookie('subscriptions_data', '[]', $current_time + 60 * 60 * 24, "/");
            }
        }

        // Set cookies with correct values and 1-day expiration ("/" makes it available across the domain)
        setcookie('subscriptions_data', json_encode($subscriptions), $current_time + 60 * 60 * 24, "/");
        setcookie('last_sub_fetch_time', $current_time, $current_time + 60 * 60 * 24, "/");
    } else {
        // Read from cookie ONLY if we didn't just fetch new data
        $subscriptions = json_decode($_COOKIE['subscriptions_data'] ?? '{}', true) ?? [];
    }

    if (!empty($subscriptions)) {
        $subscriptions_ends_at = new DateTime($subscriptions['subscription_end_at'] ?? '');
        $today = new DateTime();
        $diff = $today->diff($subscriptions_ends_at);
        $subscription_days_left = (int)$diff->format('%r%a');

        if ($subscription_days_left <= 0 || $subscriptions['status'] !== 'active') {
            include_once __DIR__ . '/subscription-expired.php';
        }
    }
    ?>

    <div id="preloader">
        <div class="preloader-wrapper">
            <div class="dot dot1"></div>
            <div class="dot dot2"></div>
            <div class="dot dot3"></div>
            <div class="dot dot4"></div>
        </div>
    </div>

    <div id="website-main-content">