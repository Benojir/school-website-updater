</head>

<body>
    <!-- Message for users without JavaScript -->
    <noscript>
        <div class="noscript-overlay">
            <h2>JavaScript is Disabled</h2>
            <p>Please enable JavaScript in your browser to view this website.</p>
        </div>
    </noscript>
    
    <div id="preloader">
        <div class="preloader-wrapper">
            <div class="dot dot1"></div>
            <div class="dot dot2"></div>
            <div class="dot dot3"></div>
            <div class="dot dot4"></div>
        </div>
    </div>

    <div id="website-main-content">

    