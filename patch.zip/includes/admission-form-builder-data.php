<?php
// Pure document helpers. Authentication/bootstrap belongs to the calling page.
require_once __DIR__ . '/id-card-school-data.php';
require_once __DIR__ . '/photo-storage.php';

function admissionFormFields(): array
{
    return [
        'Student' => [
            'student_name'=>['Student Name','name'], 'student_id'=>['Student ID','student_id'],
            'dob'=>['Date of Birth','date_of_birth','date'], 'gender'=>['Gender','gender'],
            'blood_group'=>['Blood Group','blood_group'], 'religion'=>['Religion','religion'],
            'caste'=>['Caste / Category','caste'], 'aadhaar_no'=>['Student Aadhaar Number','student_adhaar_no'],
            'banglar_shiksha_code'=>['Banglar Shiksha Code','banglar_shiksha_code'],
            'email'=>['Email','email'], 'hostel_status'=>['Hostel Student','is_hosteler','yesno'],
            'first_admission_date'=>['First Admission Date','first_admission_date','date'],
        ],
        'Academic — selected year' => [
            'academic_year'=>['Academic Year','academic_year'], 'class'=>['Class & Section',null],
            'class_name'=>['Class Name','class_name'], 'section'=>['Section Name','section_name'],
            'roll_no'=>['Roll Number','roll_no'], 'registration_no'=>['Registration Number','registration_no'],
            'admission_date'=>['Admission Date','admission_date','date'], 'promoted_date'=>['Promotion Date','promoted_date','date'],
            'enrollment_status'=>['Enrollment Status','status'],
        ],
        'Family & Contact' => [
            'father_name'=>["Father's Name",'father_name'], 'mother_name'=>["Mother's Name",'mother_name'],
            'father_occupation'=>["Father's Occupation",'father_occupation'], 'mother_occupation'=>["Mother's Occupation",'mother_occupation'],
            'student_contact'=>['Contact Number','phone_number'], 'alt_contact'=>['Alternative Contact Number','alternate_phone_number'],
            'father_annual_income'=>["Father's Annual Income",'father_annual_income'], 'mother_annual_income'=>["Mother's Annual Income",'mother_annual_income'],
            'father_aadhaar_no'=>["Father's Aadhaar Number",'father_adhaar_no'], 'mother_aadhaar_no'=>["Mother's Aadhaar Number",'mother_adhaar_no'],
            'father_pan_no'=>["Father's PAN Number",'father_pan_no'], 'mother_pan_no'=>["Mother's PAN Number",'mother_pan_no'],
            'father_voter_no'=>["Father's Voter Number",'father_voter_no'], 'mother_voter_no'=>["Mother's Voter Number",'mother_voter_no'],
        ],
        'Address' => [
            'student_address'=>['Full Address','address'], 'landmark'=>['Landmark','landmark'],
            'village'=>['Village / Town','village'], 'post_office'=>['Post Office','post_office'],
            'police_station'=>['Police Station','police_station'], 'district'=>['District','district'], 'pin_code'=>['PIN Code','pin_code'],
        ],
        'Transport' => [
            'transport_driver_name'=>['Driver Name',null], 'driving_route_name'=>['Driving Route Name',null],
        ],
        'Bank' => [
            'bank_name'=>['Bank Name','bank_name'], 'bank_branch_name'=>['Bank Branch','bank_branch_name'],
            'bank_account_no'=>['Bank Account Number','bank_account_no'], 'ifsc_code'=>['IFSC Code','ifsc_code'],
        ],
        'Financial — selected year' => [
            'admission_actual_amount'=>['Admission Fee Before Discount',null], 'admission_discount_amount'=>['Admission Discount',null],
            'admission_agreed_amount'=>['Agreed Admission Fee / Deal Amount',null], 'admission_paid_amount'=>['Admission Amount Paid So Far',null],
            'admission_due_amount'=>['Admission Amount Due',null],
            'regular_class_fee'=>['Regular Monthly Class Fee',null], 'custom_class_fee'=>['Custom Monthly Class Fee',null],
            'monthly_tuition_fee'=>['Monthly Tuition Fee (Custom / Regular)',null],
            'car_fee'=>['Monthly Car Fee',null], 'hostel_fee'=>['Monthly Hostel Fee',null],
            'tiffin_fee'=>['Monthly Tiffin Fee',null], 'coaching_fee'=>['Monthly Coaching Fee',null], 'other_fee'=>['Monthly Other Fee',null],
            'total_monthly_fee'=>['Total Monthly Fee',null],
            'monthly_fee_status'=>['Monthly Fee Availability',null], 'admission_fee_status'=>['Admission Fee Availability',null],
        ],
        'School' => idCardSchoolFields() + [
            'school_email'=>['School Email',null], 'principal_name'=>['Principal Name',null],
            'headmaster_name'=>['Head Master Name',null], 'currency_symbol'=>['Currency Symbol',null],
        ],
    ];
}

function admissionFormSelectedIds(mixed $input): array
{
    if (is_string($input)) {
        $input = trim($input);
        $input = str_starts_with($input, '[') ? json_decode($input, true) : explode(',', $input);
    }
    if (!is_array($input) || !$input || count($input) > 30) throw new InvalidArgumentException('Select between 1 and 30 students.');
    $ids = [];
    foreach ($input as $id) {
        if (!is_string($id) || !preg_match('/^[^\p{C},]{1,50}$/u', trim($id))) throw new InvalidArgumentException('Invalid student ID.');
        $id = trim($id); $ids[$id] = $id;
    }
    return array_values($ids);
}

function admissionFormNeedsFinancialData(array ...$designs): bool
{
    $keys = array_keys(admissionFormFields()['Financial — selected year']);
    $walk = static function ($value) use (&$walk, $keys): bool {
        if (is_array($value)) {
            foreach ($value as $child) if ($walk($child)) return true;
        } elseif (is_string($value) && preg_match_all('/\{\{\s*([a-z_]+)\s*\}\}/', $value, $matches)) {
            return (bool) array_intersect($matches[1], $keys);
        }
        return false;
    };
    return $walk($designs);
}

function admissionFormCents(mixed $value): int
{
    $value = (string)($value ?? '0');
    if (!preg_match('/^(\d{1,12})(?:\.(\d{1,2}))?$/D', $value, $matches)) throw new InvalidArgumentException('A saved admission fee amount needs review.');
    return (int)$matches[1] * 100 + (int)str_pad($matches[2] ?? '', 2, '0');
}

function admissionFormMoney(int $cents): string
{
    return intdiv($cents, 100) . '.' . str_pad((string)($cents % 100), 2, '0', STR_PAD_LEFT);
}

function admissionFormFeeSummary(array $rows): array
{
    $totals = ['admission_actual_amount'=>0,'admission_discount_amount'=>0,'admission_agreed_amount'=>0,
        'admission_paid_amount'=>0,'admission_due_amount'=>0];
    foreach ($rows as $row) {
        $actual = admissionFormCents($row['actual_amount']); $discount = admissionFormCents($row['discount_amount']);
        $agreed = $actual - $discount;
        $due = $row['fee_state'] === 'unpaid' ? admissionFormCents($row['unpaid_amount']) : 0;
        $paid = $row['fee_state'] === 'unpaid' ? $agreed - $due : admissionFormCents($row['total_paid_amount'] ?? admissionFormMoney($agreed));
        if ($agreed < 0 || $paid < 0 || $due > $agreed || $paid + $due !== $agreed) {
            throw new InvalidArgumentException('The admission fee balance needs review before printing.');
        }
        foreach (['admission_actual_amount'=>$actual,'admission_discount_amount'=>$discount,'admission_agreed_amount'=>$agreed,
            'admission_paid_amount'=>$paid,'admission_due_amount'=>$due] as $key=>$value) $totals[$key] += $value;
    }
    return array_map(static fn($value) => $rows ? admissionFormMoney($value) : '', $totals)
        + ['admission_fee_status'=>$rows ? 'Recorded' : 'Not recorded for selected academic year'];
}

function admissionFormMonthlySummary(array $student, mixed $regularRate): array
{
    $custom = admissionFormCents($student['custom_class_fee'] ?? 0);
    $regular = $regularRate === null ? null : admissionFormCents($regularRate);
    $tuition = $custom > 0 ? $custom : $regular;
    $fees = ['monthly_tuition_fee'=>$tuition];
    foreach (['car','hostel','tiffin','coaching','other'] as $code) {
        $key = $code . '_fee';
        $fees[$key] = admissionFormCents($student[$key] ?? 0);
    }
    return array_map(static fn($amount) => $amount === null ? '' : admissionFormMoney($amount), $fees) + [
        'regular_class_fee'=>$regular === null ? '' : admissionFormMoney($regular),
        'custom_class_fee'=>admissionFormMoney($custom),
        'total_monthly_fee'=>$tuition === null ? '' : admissionFormMoney(array_sum($fees)),
        'monthly_fee_status'=>$tuition === null ? 'Class monthly fee not set' : 'Recorded',
    ];
}

function admissionFormPayload(array $student, array $school, array $financial = [], string $currency = ''): array
{
    $stampPath = __DIR__ . '/../uploads/school/school_stamp.png';
    $stampExists = is_file($stampPath);
    $stampVersion = $stampExists ? (string)filemtime($stampPath) : '0';
    $payload = [];
    foreach (admissionFormFields() as $fields) foreach ($fields as $key=>$field) {
        $column = $field[1];
        if ($column === null) continue;
        $value = $student[$column] ?? '';
        if (($field[2] ?? '') === 'date') {
            $timestamp = $value && !str_starts_with((string)$value, '0000-00-00') ? strtotime((string)$value) : false;
            $value = $timestamp === false ? '' : date('d M Y', $timestamp);
        } elseif (($field[2] ?? '') === 'yesno') $value = (int)$value ? 'Yes' : 'No';
        $payload[$key] = (string)$value;
    }
    $section = $payload['section'];
    return $payload + [
        'class'=>$payload['class_name'] . ($section !== '' ? ' (' . $section . ')' : ''),
        ...idCardSchoolPayload($school), 'school_email'=>$school['email'] ?? '',
        'principal_name'=>$school['principal_name'] ?? '', 'headmaster_name'=>$school['headmaster_name'] ?? '', 'currency_symbol'=>$currency,
        'student_photo_url'=>schoolPhotoCanvasUrl('students', $student['student_image'] ?? null),
        'father_photo_url'=>!empty($student['father_image']) && schoolPhotoValidName('fathers', $student['father_image']) && !schoolPhotoIsDefault($student['father_image']) ? schoolPhotoCanvasUrl('fathers', $student['father_image']) : '',
        'mother_photo_url'=>!empty($student['mother_image']) && schoolPhotoValidName('mothers', $student['mother_image']) && !schoolPhotoIsDefault($student['mother_image']) ? schoolPhotoCanvasUrl('mothers', $student['mother_image']) : '',
        'principal_signature_url'=>BASE_URL . '/uploads/school/principle_sign.png',
        'headmaster_signature_url'=>BASE_URL . '/uploads/school/headmaster_sign.png',
        'school_stamp_url'=>$stampExists ? BASE_URL . '/uploads/school/school_stamp.png?v=' . $stampVersion : '',
        'qr_payload'=>json_encode(['student_id'=>$student['student_id'],'academic_year'=>$student['academic_year']]),
    ] + $financial;
}

function admissionFormLoad($pdo, array $ids, string $year, array $school, bool $financial, string $currency = ''): array
{
    $year = academicNormalizeYear($year);
    $source = academicStudentSourceSql($pdo, $year);
    $marks = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("SELECT s.*, c.class_name, sec.section_name FROM {$source} s
        LEFT JOIN classes c ON c.id = s.class_id LEFT JOIN sections sec ON sec.id = s.section_id WHERE s.student_id IN ({$marks})");
    $stmt->execute($ids); $students = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), null, 'student_id');
    foreach ($ids as $id) if (!isset($students[$id]) || (string)$students[$id]['academic_year'] !== $year) {
        throw new InvalidArgumentException('A selected student has no enrollment in ' . $year . '. Select students enrolled in that year.');
    }
    $fees = []; $classFees = [];
    if ($financial) {
        // Full-paid rows already contain the complete payment; do not add partial-payment history again.
        $stmt = $pdo->prepare("SELECT student_id, actual_amount, discount_amount, unpaid_amount, NULL AS total_paid_amount, 'unpaid' AS fee_state
            FROM admission_unpaid_fees WHERE academic_year = ? AND student_id IN ({$marks})
            UNION ALL SELECT student_id, actual_amount, discount_amount, 0 AS unpaid_amount, total_paid_amount, 'paid' AS fee_state
            FROM admission_full_paid_fees WHERE academic_year = ? AND student_id IN ({$marks})");
        $stmt->execute([$year, ...$ids, $year, ...$ids]);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) $fees[$row['student_id']][] = $row;
        $stmt = $pdo->query('SELECT class_id, amount FROM class_wise_monthly_fees');
        $classFees = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'amount', 'class_id');
    }
    $forms = [];
    foreach ($ids as $id) {
        $student = $students[$id]; $amounts = [];
        if ($financial) {
            $amounts = admissionFormFeeSummary($fees[$id] ?? [])
                + admissionFormMonthlySummary($student, $classFees[$student['class_id']] ?? null);
        }
        $forms[] = admissionFormPayload($student, $school, $amounts, $currency);
    }
    return $forms;
}
