<?php
require_once __DIR__ . '/auth-check.php';
require_once __DIR__ . '/parent/auth/parent-auth-check.php';
require_once __DIR__ . '/exam-document-access.php';

function examDocumentRequireDownload(string $type): array
{
    global $pdo;
    header('Cache-Control: private, no-store');
    header('Referrer-Policy: no-referrer');
    try {
        // The app's ticket signs the URL query. PHP can merge POST fields or
        // cookies over those fields in $_REQUEST, depending on request_order.
        $hasTicket = array_key_exists('download_signature', $_GET);
        $input = $hasTicket ? $_GET : $_REQUEST;
        $request = examDocumentRequest($type, $input);
        $admin = isAnyAdminLoggedIn();
        $parent = null;
        if (!$admin) {
            if ($hasTicket) $parent = examDocumentTicketParent($pdo, $request, $input);
            else {
                $parent = getAuthenticatedParent($pdo);
                if ($parent) examDocumentParentSession($pdo, (int) $parent['session_id']);
            }
        }
        examDocumentAuthorize($pdo, $request, $parent, $admin);
        if ($hasTicket) $_REQUEST = $input;
        // Keep legacy renderers and their student_id/student_ids aliases consistent.
        foreach (examDocumentParams($request) as $key => $value) $_GET[$key] = $_REQUEST[$key] = (string) $value;
        return $request;
    } catch (InvalidArgumentException | ExamDocumentDenied $error) {
        http_response_code($error instanceof ExamDocumentDenied ? ($error->getCode() ?: 403) : 422);
        $message = htmlspecialchars($error->getMessage(), ENT_QUOTES, 'UTF-8');
    } catch (Throwable $error) {
        error_log('Exam document download: ' . $error->getMessage());
        http_response_code(503);
        $message = 'Document downloads are temporarily unavailable. Please try again later or contact the school.';
    }
    header('Content-Type: text/html; charset=utf-8');
    exit('<!doctype html><html lang="en"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Document Download</title><body style="font-family:Arial,sans-serif;max-width:620px;margin:60px auto;padding:20px"><h1>Download unavailable</h1><p>' . $message . '</p></body></html>');
}

function examDocumentRedirectParams(array $request): string
{
    $params = examDocumentParams($request);
    if (array_key_exists('download_signature', $_GET)) {
        foreach (['parent_session', 'download_expires', 'download_signature'] as $key) {
            if (isset($_GET[$key]) && is_scalar($_GET[$key])) $params[$key] = (string) $_GET[$key];
        }
    }
    return http_build_query($params, '', '&', PHP_QUERY_RFC3986);
}
