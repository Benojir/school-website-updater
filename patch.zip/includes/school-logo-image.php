<?php
// Image processing only; no application bootstrap or database access.
function schoolLogoRules(string $field): array
{
    return match ($field) {
        'schoolLogo' => ['label' => 'Square logo', 'minWidth' => 300, 'minHeight' => 300, 'width' => 512, 'height' => 512],
        'logoRectangle' => ['label' => 'Rectangle logo', 'minWidth' => 600, 'minHeight' => 170, 'width' => 600, 'height' => 170],
        default => throw new InvalidArgumentException('Unknown logo type.'),
    };
}

function schoolLogoCrop(string $path, string $field, mixed $crop): array
{
    $rules = schoolLogoRules($field);
    $size = @getimagesize($path);
    if (!$size || $size[2] !== IMAGETYPE_PNG || filesize($path) > 2 * 1024 * 1024) {
        throw new InvalidArgumentException($rules['label'] . ': Please upload a valid PNG up to 2MB.');
    }
    [$width, $height] = $size;
    if ($width < $rules['minWidth'] || $height < $rules['minHeight']) {
        throw new InvalidArgumentException($rules['label'] . ': Original image must be at least ' . $rules['minWidth'] . '×' . $rules['minHeight'] . ' pixels.');
    }
    // Bound decoded memory even for highly compressed PNGs.
    if ($width * $height > 16000000) {
        throw new InvalidArgumentException($rules['label'] . ': Please use an image up to 16 megapixels.');
    }
    foreach (['x', 'y', 'width', 'height'] as $key) {
        if (!is_array($crop) || !isset($crop[$key]) || !is_numeric($crop[$key]) || !is_finite((float)$crop[$key])) {
            throw new InvalidArgumentException($rules['label'] . ': Please crop the image before uploading.');
        }
        $crop[$key] = (float)$crop[$key];
    }
    if ($crop['x'] < 0 || $crop['y'] < 0 || $crop['width'] < 1 || $crop['height'] < 1
        || $crop['x'] + $crop['width'] > $width + 0.01
        || $crop['y'] + $crop['height'] > $height + 0.01
        || abs($crop['width'] - $crop['height'] * $rules['width'] / $rules['height']) > 0.01) {
        throw new InvalidArgumentException($rules['label'] . ': Invalid crop area or aspect ratio. Please crop again.');
    }
    $source = @imagecreatefrompng($path);
    if (!$source) {
        throw new InvalidArgumentException($rules['label'] . ': The PNG image could not be read.');
    }
    try {
        $images = ['logo' => schoolLogoRender($source, $crop, $rules['width'], $rules['height'])];
        if ($field === 'schoolLogo') {
            $images['favicon'] = schoolLogoRender($source, $crop, 48, 48);
        }
        return $images;
    } finally {
        imagedestroy($source);
    }
}

function schoolLogoRender(GdImage $source, array $crop, int $width, int $height): string
{
    $image = imagecreatetruecolor($width, $height);
    try {
        imagealphablending($image, false);
        imagesavealpha($image, true);
        imagefill($image, 0, 0, imagecolorallocatealpha($image, 0, 0, 0, 127));
        imagecopyresampled($image, $source, 0, 0, (int)round($crop['x']), (int)round($crop['y']),
            $width, $height, (int)round($crop['width']), (int)round($crop['height']));
        ob_start();
        try {
            if (!imagepng($image)) {
                throw new RuntimeException('Unable to encode logo.');
            }
            return ob_get_contents();
        } finally {
            ob_end_clean();
        }
    } finally {
        imagedestroy($image);
    }
}
