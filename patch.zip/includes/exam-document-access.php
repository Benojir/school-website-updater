<?php
// Pure services: no bootstrap, connection, request handling or network side effects.
class ExamDocumentDenied extends RuntimeException {}

function examDocumentDate(mixed $value): ?string
{
    if (!is_string($value) || $value === '') return null;
    $value = str_replace('T', ' ', trim($value));
    if (strlen($value) === 16) $value .= ':00';
    if (strlen($value) === 10) $value .= ' 00:00:00';
    $date = DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $value);
    return $date && $date->format('Y-m-d H:i:s') === $value ? $value : null;
}

function examDocumentMoneyPaise(mixed $amount): int
{
    $amount = (string) $amount;
    if (!preg_match('/^(\d{1,12})(?:\.(\d{1,2}))?$/D', $amount, $match)) {
        throw new RuntimeException('Invalid fee balance.');
    }
    return (int) $match[1] * 100 + (int) str_pad($match[2] ?? '', 2, '0');
}

function examDocumentMoney(int $paise): string
{
    return intdiv($paise, 100) . '.' . str_pad((string) ($paise % 100), 2, '0', STR_PAD_LEFT);
}

function examDocumentFeeBalance(PDO $pdo, string $studentId): array
{
    $queries = [
        'monthly' => 'SELECT COALESCE(SUM(unpaid_amount), 0) FROM student_unpaid_fees WHERE student_id = ? AND unpaid_amount > 0',
        'admission' => 'SELECT COALESCE(SUM(unpaid_amount), 0) FROM admission_unpaid_fees WHERE student_id = ? AND unpaid_amount > 0',
        'additional' => "SELECT COALESCE(SUM(f.amount), 0) FROM additional_fees_data d JOIN class_wise_additional_fees f ON f.id = d.additional_fee_setup_id WHERE d.student_id = ? AND d.additional_fee_status = 'unpaid' AND f.amount > 0",
    ];
    $balance = ['total_paise' => 0];
    foreach ($queries as $type => $query) {
        $statement = $pdo->prepare($query);
        $statement->execute([$studentId]);
        $paise = examDocumentMoneyPaise($statement->fetchColumn());
        $balance[$type . '_paise'] = $paise;
        $balance[$type . '_amount'] = examDocumentMoney($paise);
        $balance['total_paise'] += $paise;
    }
    $balance['total_amount'] = examDocumentMoney($balance['total_paise']);
    return $balance;
}

function examDocumentOverrideActive(array $permission, string $type, string $now): bool
{
    $expiry = examDocumentDate($permission[$type . '_expires_at'] ?? null);
    // Legacy grants without an end date never become indefinite fee exemptions.
    return !empty($permission['override_' . $type . '_check']) && $expiry !== null && $expiry > $now;
}

function examDocumentPermissions(PDO $pdo, string $studentId, ?string $now = null): array
{
    $now ??= date('Y-m-d H:i:s');
    $fees = examDocumentFeeBalance($pdo, $studentId);
    $statement = $pdo->prepare('SELECT * FROM student_download_permissions WHERE student_id = ?');
    $statement->execute([$studentId]);
    $permission = $statement->fetch(PDO::FETCH_ASSOC) ?: [];
    $admit = examDocumentOverrideActive($permission, 'admit', $now);
    $marksheet = examDocumentOverrideActive($permission, 'marksheet', $now);
    $paid = $fees['total_paise'] === 0;
    return [
        'can_download_admit' => $admit ? !empty($permission['allow_admit_card']) : $paid,
        'can_download_marksheet' => $marksheet ? !empty($permission['allow_marksheet']) : $paid,
        'has_override' => $admit || $marksheet,
        'admit_override_active' => $admit,
        'marksheet_override_active' => $marksheet,
        'admit_expires_at' => $permission['admit_expires_at'] ?? null,
        'marksheet_expires_at' => $permission['marksheet_expires_at'] ?? null,
        'all_fees_paid' => $paid,
        'fees' => $fees,
    ];
}

function examDocumentFeeMessage(array $permissions, string $type): string
{
    $label = $type === 'admit' ? 'admit card' : 'marksheet';
    if ($permissions['all_fees_paid']) return 'The school has temporarily restricted this ' . $label . ' download. Please contact the school.';
    $currency = $GLOBALS['currency_symbol'] ?? '₹';
    return 'Please pay all outstanding monthly, admission and additional fees (' . $currency . $permissions['fees']['total_amount'] . ') before downloading the ' . $label . '.';
}

function examDocumentCsv(mixed $input, bool $numeric = false): array
{
    if (!is_string($input) || $input === '' || strlen($input) > 10000) throw new InvalidArgumentException('Invalid document selection.');
    $values = array_values(array_unique(array_map('trim', explode(',', $input))));
    if (count($values) > 100) throw new InvalidArgumentException('Select up to 100 documents or students at a time.');
    foreach ($values as &$value) {
        if ($value === '' || strlen($value) > 50 || preg_match('/[\x00-\x1F\x7F]/', $value)) throw new InvalidArgumentException('Invalid document selection.');
        if ($numeric) {
            $id = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            if ($id === false) throw new InvalidArgumentException('Invalid document ID.');
            $value = $id;
        }
    }
    unset($value);
    return $values;
}

function examDocumentRequest(string $type, array $input): array
{
    if ($type === 'admit') {
        if (isset($input['exam_id']) && $input['exam_id'] !== '') {
            $exam = filter_var($input['exam_id'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            if ($exam === false || !empty($input['admit_id'])) throw new InvalidArgumentException('Choose one valid exam or admit release.');
            return ['type' => $type, 'exam_id' => $exam, 'student_ids' => examDocumentCsv($input['student_ids'] ?? $input['student_id'] ?? null)];
        }
        $id = filter_var($input['admit_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($id === false) throw new InvalidArgumentException('A valid admit card ID is required.');
        return ['type' => $type, 'admit_id' => $id, 'student_ids' => examDocumentCsv($input['student_ids'] ?? $input['student_id'] ?? null)];
    }
    if ($type === 'marksheet') return ['type' => $type, 'result_ids' => examDocumentCsv($input['result_ids'] ?? null, true)];
    if ($type === 'combined') {
        $class = $input['class_id'] ?? '';
        if ($class !== '' && filter_var($class, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) === false) throw new InvalidArgumentException('Invalid class.');
        return ['type' => $type, 'exam_ids' => examDocumentCsv($input['exam_ids'] ?? null, true),
            'student_ids' => examDocumentCsv($input['student_ids'] ?? null), 'class_id' => $class === '' ? '' : (int) $class];
    }
    throw new InvalidArgumentException('Invalid document type.');
}

function examDocumentParams(array $request): array
{
    unset($request['type']);
    return array_map(static fn($value) => is_array($value) ? implode(',', $value) : $value, $request);
}

function examDocumentRequireReleased(array $release, string $now, string $label): void
{
    $date = examDocumentDate($release['release_date'] ?? null);
    if (($release['status'] ?? '') !== 'released' || !$date || $date > $now) {
        throw new ExamDocumentDenied('The ' . $label . ' has not been released yet. Please check after the school\'s scheduled release time.', 403);
    }
}

function examDocumentRequireStudent(PDO $pdo, string $studentId, string $phone): array
{
    $statement = $pdo->prepare('SELECT id, student_id, phone_number, alternate_phone_number FROM students WHERE student_id = ?');
    $statement->execute([$studentId]);
    $student = $statement->fetch(PDO::FETCH_ASSOC);
    if (!$student || $phone === '' || !in_array($phone, [$student['phone_number'], $student['alternate_phone_number']], true)) {
        throw new ExamDocumentDenied('You do not have permission to download documents for this student.', 403);
    }
    return $student;
}

function examDocumentAuthorize(PDO $pdo, array $request, ?array $parent, bool $admin, ?string $now = null): void
{
    if ($admin) return; // Admin downloads never depend on release dates, fees or parent exemptions.
    if ($request['type'] === 'combined') throw new ExamDocumentDenied('Combined marksheets are available from the admin panel only.', 403);
    if (!$parent) throw new ExamDocumentDenied('Please sign in to the parent portal or open the download from the parent app.', 401);
    $now ??= date('Y-m-d H:i:s');
    $students = [];
    if ($request['type'] === 'admit') {
        if (isset($request['exam_id'])) throw new ExamDocumentDenied('The admit card has not been released yet.', 403);
        $statement = $pdo->prepare('SELECT a.*, e.academic_year FROM exam_admit_releases a JOIN exams e ON e.id = a.exam_id WHERE a.id = ?');
        $statement->execute([$request['admit_id']]);
        $release = $statement->fetch(PDO::FETCH_ASSOC) ?: [];
        examDocumentRequireReleased($release, $now, 'admit card');
        foreach ($request['student_ids'] as $studentId) {
            $student = examDocumentRequireStudent($pdo, $studentId, $parent['phone_number']);
            $statement = $pdo->prepare('SELECT 1 FROM student_academic_records WHERE student_row_id = ? AND academic_year = ? AND class_id = ? LIMIT 1');
            $statement->execute([$student['id'], $release['academic_year'], $release['class_id']]);
            if (!$statement->fetchColumn()) throw new ExamDocumentDenied('This admit card is not available for the student\'s class in that academic year.', 403);
            $students[] = $studentId;
        }
    } else {
        $ids = $request['result_ids'];
        $statement = $pdo->prepare('SELECT id, student_id, exam_id, class_id FROM results WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')');
        $statement->execute($ids);
        $results = $statement->fetchAll(PDO::FETCH_ASSOC);
        if (count($results) !== count($ids)) throw new ExamDocumentDenied('One or more requested marksheets could not be found.', 404);
        foreach ($results as $result) {
            examDocumentRequireStudent($pdo, $result['student_id'], $parent['phone_number']);
            $statement = $pdo->prepare('SELECT status, release_date FROM exam_marksheet_releases WHERE exam_id = ? AND class_id = ?');
            $statement->execute([$result['exam_id'], $result['class_id']]);
            examDocumentRequireReleased($statement->fetch(PDO::FETCH_ASSOC) ?: [], $now, 'marksheet');
            $students[] = $result['student_id'];
        }
    }
    foreach (array_unique($students) as $studentId) {
        $permission = examDocumentPermissions($pdo, $studentId, $now);
        $key = $request['type'] === 'admit' ? 'can_download_admit' : 'can_download_marksheet';
        if (!$permission[$key]) throw new ExamDocumentDenied(examDocumentFeeMessage($permission, $request['type']), 403);
    }
}

function examDocumentParentSession(PDO $pdo, int $id, ?string $now = null): array
{
    $statement = $pdo->prepare('SELECT id, phone, token_hash, expires_at FROM parent_auth_sessions WHERE id = ?');
    $statement->execute([$id]);
    $session = $statement->fetch(PDO::FETCH_ASSOC);
    $now ??= date('Y-m-d H:i:s');
    if (!$session || (!empty($session['expires_at']) && $session['expires_at'] <= $now)) {
        throw new ExamDocumentDenied('Your parent session expired. Please sign in again.', 401);
    }
    return $session;
}

function examDocumentSignature(array $request, int $sessionId, int $expires, string $tokenHash): string
{
    return hash_hmac('sha256', json_encode([$request, $sessionId, $expires], JSON_THROW_ON_ERROR), $tokenHash);
}

function examDocumentIssueLink(PDO $pdo, array $request, array $parent, string $base, ?int $now = null): string
{
    $now ??= time();
    $session = examDocumentParentSession($pdo, (int) $parent['session_id'], date('Y-m-d H:i:s', $now));
    if ($session['phone'] !== $parent['phone_number']) throw new ExamDocumentDenied('Invalid parent session.', 401);
    examDocumentAuthorize($pdo, $request, $parent, false, date('Y-m-d H:i:s', $now));
    $expires = $now + 300;
    $params = examDocumentParams($request) + ['parent_session' => (int) $session['id'], 'download_expires' => $expires,
        'download_signature' => examDocumentSignature($request, (int) $session['id'], $expires, $session['token_hash'])];
    $path = $request['type'] === 'admit' ? '/api/download/download-admit-card.php' : '/api/download/marksheet/download-single-marksheet.php';
    return rtrim($base, '/') . $path . '?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
}

function examDocumentTicketParent(PDO $pdo, array $request, array $input, ?int $now = null): array
{
    $now ??= time();
    $id = filter_var($input['parent_session'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $expiry = filter_var($input['download_expires'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $signature = $input['download_signature'] ?? null;
    if ($id === false || $expiry === false || $expiry <= $now || $expiry > $now + 300 || !is_string($signature) || !preg_match('/^[a-f0-9]{64}$/D', $signature)) {
        throw new ExamDocumentDenied('This download link expired or is invalid. Please open a new download from the parent app.', 403);
    }
    $session = examDocumentParentSession($pdo, $id, date('Y-m-d H:i:s', $now));
    if (!hash_equals(examDocumentSignature($request, $id, $expiry, $session['token_hash']), $signature)) {
        throw new ExamDocumentDenied('Invalid download link. Please open it again from the parent app.', 403);
    }
    return ['phone_number' => $session['phone'], 'session_id' => $session['id']];
}

function examDocumentPermissionInput(array $input, ?string $now = null): array
{
    $now ??= date('Y-m-d H:i:s');
    $values = ['student_ids' => examDocumentCsv($input['student_ids'] ?? null)];
    foreach (['admit', 'marksheet'] as $type) {
        $override = isset($input['override_' . $type . '_check']);
        $allowKey = $type === 'admit' ? 'allow_admit_card' : 'allow_marksheet';
        $expiry = $override ? examDocumentDate($input[$type . '_expires_at'] ?? null) : null;
        if ($override && (!$expiry || $expiry <= $now)) throw new InvalidArgumentException('Choose a future expiry date and time for each enabled override.');
        $values['override_' . $type . '_check'] = $override ? 1 : 0;
        $values[$allowKey] = $override && isset($input[$allowKey]) ? 1 : 0;
        $values[$type . '_expires_at'] = $expiry;
    }
    $notes = $input['notes'] ?? '';
    if (!is_string($notes) || strlen($notes) > 4000 || !preg_match('//u', $notes)) throw new InvalidArgumentException('Enter notes of at most 4000 bytes.');
    $values['notes'] = trim($notes);
    return $values;
}

function examDocumentSavePermissions(PDO $pdo, array $input, ?string $now = null): array
{
    $values = examDocumentPermissionInput($input, $now);
    $pdo->beginTransaction();
    try {
        $find = $pdo->prepare('SELECT name FROM students WHERE student_id = ?');
        $save = $pdo->prepare('INSERT INTO student_download_permissions (student_id, override_admit_check, allow_admit_card, admit_expires_at, override_marksheet_check, allow_marksheet, marksheet_expires_at, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE override_admit_check = VALUES(override_admit_check), allow_admit_card = VALUES(allow_admit_card), admit_expires_at = VALUES(admit_expires_at), override_marksheet_check = VALUES(override_marksheet_check), allow_marksheet = VALUES(allow_marksheet), marksheet_expires_at = VALUES(marksheet_expires_at), notes = VALUES(notes), updated_at = CURRENT_TIMESTAMP');
        $results = [];
        foreach ($values['student_ids'] as $studentId) {
            $find->execute([$studentId]);
            $name = $find->fetchColumn();
            if ($name === false) throw new InvalidArgumentException('One or more selected students no longer exist. Reload the student list.');
            $save->execute([$studentId, $values['override_admit_check'], $values['allow_admit_card'], $values['admit_expires_at'],
                $values['override_marksheet_check'], $values['allow_marksheet'], $values['marksheet_expires_at'], $values['notes']]);
            $results[] = ['student_id' => $studentId, 'success' => true, 'message' => $name . '\'s download permissions updated.'];
        }
        $pdo->commit();
        return $results;
    } catch (Throwable $error) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $error;
    }
}
