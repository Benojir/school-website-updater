<?php
if (!$can_see_financial_data) return;
require_once __DIR__ . '/financial/monthly-fee-ledger.php';

// Allocation dates follow the school's configured PHP timezone. Bill month can
// differ for arrears or advance; signed reversal entries retain the receipt date.
$dashboardCategoryStart = new DateTimeImmutable('first day of this month midnight');
$dashboardCategoryToday = date('Y-m-d');
$dashboardCategoryAmounts = ['tuition' => 0, 'car' => 0];
$dashboardCategoryError = false;
try {
    $dashboardCategoryStatement = $pdo->prepare("SELECT fee_code, SUM(amount) AS collected
        FROM monthly_fee_payment_allocations
        WHERE payment_date >= ? AND payment_date <= ?
          AND allocation_type = 'payment'
          AND method IN ('cash', 'online')
          AND fee_code IN ('tuition', 'car')
        GROUP BY fee_code");
    $dashboardCategoryStatement->execute([$dashboardCategoryStart->format('Y-m-d'), $dashboardCategoryToday]);
    foreach ($dashboardCategoryStatement->fetchAll(PDO::FETCH_ASSOC) as $dashboardCategoryRow) {
        $dashboardCategoryAmounts[$dashboardCategoryRow['fee_code']] = MonthlyFeeLedger::cents($dashboardCategoryRow['collected']);
    }
} catch (Throwable $e) {
    error_log('Dashboard monthly fee categories: ' . $e->getMessage());
    $dashboardCategoryError = true;
}
$dashboardCategoryAmount = static fn(string $code): string => $dashboardCategoryError
    ? '—' : safe_htmlspecialchars($currency_symbol) . ' ' . number_format($dashboardCategoryAmounts[$code] / 100, 2);
?>
<div class="col-12 col-md-6 col-xl-3" id="dashboardMonthlyFeeCategories">
    <a class="card border-start-3 border-start-success shadow-sm h-100 text-decoration-none text-body" aria-labelledby="dashboardMonthlyCategoryTitle"
       href="<?= safe_htmlspecialchars(BASE_URL) ?>/management/fees-x-payments/monthly/category-report.php"
             title="Collections by payment date, including arrears and advance.">
        <div class="card-body">
            <div class="d-flex align-items-center mb-3">
                <div class="flex-grow-1">
                    <h4 id="dashboardMonthlyCategoryTitle" class="small text-muted mb-1">Fees Collected This Month</h4>
                    <div class="small fw-semibold"><?= $dashboardCategoryStart->format('F Y') ?></div>
                </div>
                <i class="fa-solid fa-coins fa-2x text-success ms-3" aria-hidden="true"></i>
            </div>
            <div class="small d-flex justify-content-between align-items-center flex-wrap gap-1 mb-2">
                <span class="text-muted"><i class="fa-solid fa-graduation-cap me-1" aria-hidden="true"></i>Tuition Fee</span>
                <span class="fw-semibold text-break" data-category-tuition><?= $dashboardCategoryAmount('tuition') ?></span>
            </div>
            <div class="small d-flex justify-content-between align-items-center flex-wrap gap-1 mb-3">
                <span class="text-muted"><i class="fa-solid fa-bus me-1" aria-hidden="true"></i>Car Fee</span>
                <span class="fw-semibold text-break" data-category-car><?= $dashboardCategoryAmount('car') ?></span>
            </div>
            <?php if ($dashboardCategoryError): ?>
                <p class="small text-danger mb-1" role="status">Category totals are unavailable.</p>
            <?php endif; ?>
        </div>
    </a>
</div>
