<?php
// No application bootstrap: reversal tests use arrays, never a database or provider.
require_once __DIR__ . '/../parent/financial/fee-payment-refund-service.php';

class FeePaymentReversalService
{
    public function __construct(private PDO $pdo, private bool $gatewayConfigured = true) {}

    public function reverse(string $type, array $ids, int $admin, bool $confirmOnlineRefund = false): array
    {
        $configs = [
            'monthly' => ['student_payment_history', 'student_unpaid_fees', 'student_partial_payments',
                'student_full_paid_fees', 'unpaid_fee_rows_backup', 'full_paid_payment_ids', 'month_year', 'unpaid_fees_id', 'full_paid_fees_id'],
            'admission' => ['admission_fees_payment_history', 'admission_unpaid_fees', 'admission_partial_fees_payments',
                'admission_full_paid_fees', 'unpaid_admission_fees_rows_backup', 'full_paid_admission_payment_ids', 'academic_year', 'unpaid_admission_fees_id', 'full_paid_admission_fees_id'],
        ];
        if (!isset($configs[$type]) || !$ids || count($ids) > 100) throw new InvalidArgumentException('Select up to 100 valid payments.');
        foreach ($ids as $id) {
            if (!filter_var($id, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]])) throw new InvalidArgumentException('Invalid payment ID.');
        }
        $ids = array_values(array_unique(array_map('intval', $ids)));
        [$history, $unpaid, $partial, $paid, $backupKey, $paidIdsKey, $period, $unpaidFk, $paidFk] = $configs[$type];
        $feeType = $type . '-fee';
        $placeholders = implode(', ', array_fill(0, count($ids), '?'));
        $refundOrders = [];
        $this->pdo->beginTransaction();
        try {
            $payments = $this->rows("SELECT * FROM $history WHERE id IN ($placeholders) ORDER BY id DESC", $ids);
            $students = array_unique(array_column($payments, 'student_id'));
            sort($students, SORT_STRING);
            foreach ($students as $student) $this->rows('SELECT student_id FROM students WHERE student_id = ? FOR UPDATE', [$student]);
            $payments = $this->rows("SELECT * FROM $history WHERE id IN ($placeholders) ORDER BY id DESC FOR UPDATE", $ids);
            $found = array_map('intval', array_column($payments, 'id'));
            foreach (array_diff($ids, $found) as $missing) {
                // A lost HTTP response can be retried without restoring fees or issuing a second refund.
                $orders = $this->rows('SELECT * FROM online_fee_payment_orders WHERE fee_type = ? AND payment_history_id = ? FOR UPDATE', [$feeType, $missing]);
                if (count($orders) !== 1 || !in_array($orders[0]['payment_status'], ['refund_pending', 'refund_failed', 'refunded'], true)) {
                    throw new InvalidArgumentException('Payment record not found. Refresh the payment list.');
                }
                $refundOrders[] = (int)$orders[0]['id'];
            }
            // Preflight the entire selection before changing records or contacting Razorpay.
            foreach ($payments as $payment) {
                $newer = $this->rows("SELECT id FROM $history WHERE student_id = ? AND id > ?", [$payment['student_id'], $payment['id']]);
                foreach ($newer as $row) {
                    if (!in_array((int)$row['id'], $ids, true)) {
                        throw new InvalidArgumentException('This payment cannot be deleted because there are newer payments recorded for this student. Please delete the most recent payments first.');
                    }
                }
                $this->decode($payment[$backupKey] ?? null);
                $this->decode($payment['partial_payment_ids_backup'] ?? null);
                $this->decode($payment[$paidIdsKey] ?? null);
            }
            foreach ($payments as $payment) {
                $refundOrder = null;
                if (($payment['method'] ?? '') === 'online') {
                    if (!$confirmOnlineRefund) throw new InvalidArgumentException('Confirm the full online checkout refund before reversing this payment.');
                    $refundOrder = $this->queueOnline($feeType, $payment, $backupKey, $admin);
                    $refundOrders[] = (int)$refundOrder['id'];
                }
                foreach ($this->decode($payment[$backupKey] ?? null) as $fee) {
                    if (($fee['student_id'] ?? '') !== $payment['student_id'] || empty($fee[$period])) {
                        throw new InvalidArgumentException('Invalid fee backup. Contact technical support.');
                    }
                    $this->run("DELETE FROM $unpaid WHERE $period = ? AND student_id = ?", [$fee[$period], $fee['student_id']]);
                    $columns = ['student_id', $period];
                    if ($type === 'admission') $columns[] = 'class_id';
                    $columns = array_merge($columns, ['actual_amount', 'unpaid_amount', 'discount_amount', 'remark', 'created_at']);
                    $values = [];
                    foreach ($columns as $column) $values[] = $column === 'created_at' ? date('Y-m-d H:i:s') : $fee[$column];
                    $this->insert($unpaid, $columns, $values);
                    $newId = $this->pdo->lastInsertId();
                    if (isset($fee['id'])) {
                        // A newer reversal may already have replaced the original unpaid row ID.
                        $this->run("UPDATE $partial SET $unpaidFk = ?, $paidFk = ? WHERE student_id = ? AND $period = ?", [$newId, null, $fee['student_id'], $fee[$period]]);
                    }
                }
                foreach ($this->decode($payment['partial_payment_ids_backup'] ?? null) as $id) $this->run("DELETE FROM $partial WHERE id = ?", [$id]);
                foreach ($this->decode($payment[$paidIdsKey] ?? null) as $id) $this->run("DELETE FROM $paid WHERE id = ?", [$id]);
                $walletAmount = (float)($payment['wallet_affected_balance'] ?? 0);
                if ($walletAmount != 0) {
                    $wallet = $this->rows('SELECT * FROM student_wallet WHERE student_id = ? FOR UPDATE', [$payment['student_id']])[0] ?? null;
                    if (!$wallet) throw new InvalidArgumentException('The wallet needed for reversal was not found.');
                    $balance = ($payment['method'] === 'wallet') ? $wallet['balance'] + $walletAmount : $wallet['balance'] - $walletAmount;
                    if ($balance < 0) throw new InvalidArgumentException('The credited wallet balance has been spent. Resolve the wallet balance before reversing this payment.');
                    $this->run('UPDATE student_wallet SET balance = ? WHERE id = ?', [$balance, $wallet['id']]);
                }
                if (!empty($payment['wallet_transaction_id'])) $this->run('DELETE FROM wallet_transactions WHERE transaction_id = ?', [$payment['wallet_transaction_id']]);
                if ($type === 'monthly') (new MonthlyFeeLedger($this->pdo))->reverse($payment, $admin);
                $snapshot = $payment;
                if ($refundOrder) $snapshot['online_refund'] = ['order_id' => $refundOrder['id'], 'refund_amount_paise' => $refundOrder['refund_amount_paise']];
                $this->insert('deleted_payment_logs', ['payment_type', 'original_payment_id', 'student_id', 'payment_amount',
                    'payment_date', 'payment_remark', 'method', 'wallet_affected_balance', 'wallet_transaction_id',
                    'payment_entry_by', 'payment_recorded_at', 'payment_snapshot', 'deleted_by', 'deleted_at'],
                    [$type, $payment['id'], $payment['student_id'], $payment['payment_amount'], $payment['payment_date'],
                        $payment['remark'], $payment['method'], $payment['wallet_affected_balance'] ?? 0, $payment['wallet_transaction_id'] ?? null,
                        $payment['entry_by'] ?? null, $payment['updated_at'] ?? null, json_encode($snapshot, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE), $admin, date('Y-m-d H:i:s')]);
                $this->run("DELETE FROM $history WHERE id = ?", [$payment['id']]);
            }
            $this->pdo->commit();
            return ['count' => count($ids), 'refund_order_ids' => array_values(array_unique($refundOrders))];
        } catch (Throwable $e) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            throw $e;
        }
    }

    private function queueOnline(string $type, array $payment, string $backupKey, int $admin): array
    {
        if (!$this->gatewayConfigured) throw new InvalidArgumentException('Configure Razorpay before reversing an online payment.');
        $orders = $this->rows('SELECT * FROM online_fee_payment_orders WHERE fee_type = ? AND payment_history_id = ? FOR UPDATE', [$type, $payment['id']]);
        if (!$orders && preg_match('/\bRazorpay: (pay_[a-zA-Z0-9]+);/', $payment['remark'] ?? '', $match)) {
            // Existing native payments predate the explicit history link; verify their saved snapshots.
            $orders = $this->rows('SELECT * FROM online_fee_payment_orders WHERE razorpay_payment_id = ? AND fee_type = ? AND student_id = ? FOR UPDATE', [$match[1], $type, $payment['student_id']]);
        }
        $order = count($orders) === 1 ? $orders[0] : null;
        $backups = $this->decode($payment[$backupKey] ?? null);
        if (!$order || $order['payment_status'] !== 'paid' || $order['student_id'] !== $payment['student_id']
            || !preg_match('/^pay_[a-zA-Z0-9]+$/D', $order['razorpay_payment_id'] ?? '')
            || (!empty($order['payment_history_id']) && (int)$order['payment_history_id'] !== (int)$payment['id'])
            || (int)round((float)$payment['payment_amount'] * 100) !== (int)$order['fee_paise']
            || count($backups) !== 1 || (int)($backups[0]['id'] ?? 0) !== (int)$order['fee_id']
            || !FeePaymentService::sameFee($backups[0], json_decode($order['fee_snapshot'], true, 32, JSON_THROW_ON_ERROR))) {
            throw new InvalidArgumentException('This online payment cannot be safely matched to a paid Razorpay order. Contact technical support before refunding or deleting it.');
        }
        $key = 'fee_refund_' . bin2hex(random_bytes(12));
        $amount = (int)$order['total_paise'];
        $this->run('UPDATE online_fee_payment_orders SET payment_status = ?, payment_history_id = ?, refund_amount_paise = ?, refund_idempotency_key = ?, reversed_by = ?, reversed_at = ? WHERE id = ?',
            ['refund_pending', $payment['id'], $amount, $key, $admin, date('Y-m-d H:i:s'), $order['id']]);
        return array_replace($order, ['payment_status' => 'refund_pending', 'refund_amount_paise' => $amount]);
    }

    private function decode(?string $value): array
    {
        if ($value === null || $value === '') return [];
        $rows = json_decode($value, true, 32, JSON_THROW_ON_ERROR);
        if (!is_array($rows) || !array_is_list($rows)) throw new InvalidArgumentException('Invalid payment backup. Contact technical support.');
        return $rows;
    }

    private function rows(string $sql, array $params): array {
        $stmt = $this->pdo->prepare($sql); $stmt->execute($params); return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    private function run(string $sql, array $params): void {
        $stmt = $this->pdo->prepare($sql); $stmt->execute($params);
    }
    private function insert(string $table, array $columns, array $values): void {
        $this->run("INSERT INTO $table (" . implode(', ', $columns) . ') VALUES (' . implode(', ', array_fill(0, count($columns), '?')) . ')', $values);
    }
}
