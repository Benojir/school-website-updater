<?php

/**
 * Shared row template for the monthly "Collect Fees" table.
 *
 * This is included from two places, which is the whole point of it existing:
 *   1. management/fees-x-payments/monthly/monthly-payments-entry.php - the initial page render
 *   2. api/admin/get/fees-x-payments/monthly/search-students-for-payment.php - rows added by search
 *
 * Both must emit byte-identical markup, because the page's JavaScript reads the data-* attributes
 * below (data-monthly-fee, data-unpaid-months, data-advance-start, ...) to drive the live payment
 * projection, the discount validation and the sorting. Keeping one template avoids those two call
 * sites drifting apart.
 *
 * Expects in scope:
 * @var PDO    $pdo
 * @var string $student_id       Student to render
 * @var int    $row_index        Value for data-original-index (drives "Default (Requested Order)" sort)
 * @var string $currency_symbol
 *
 * Sets for the caller:
 *   $row_rendered             bool  - false when the student id does not exist (nothing was echoed)
 *   $row_is_no_due            bool  - true when the student has no pending monthly fee at all
 *   $row_no_due_info          array - summary used to build the "students without dues" list
 *   $row_total_unpaid_amount  float - total pending amount (used to pre-fill Pay Amount on search)
 */

$row_rendered = false;
$row_is_no_due = false;
$row_no_due_info = null;
$row_total_unpaid_amount = 0;

$student_info = getStudentInfo($pdo, $student_id);

if (!$student_info) {
    return;
}

// Fetch the monthly fees of this student
$class_id = $student_info['class_id'];
$class_fee = getClassFee($class_id);
$custom_fee = $student_info['custom_class_fee'] ?? 0;
$car_fee = $student_info['car_fee'] ?? 0;
$hostel_fee = $student_info['hostel_fee'] ?? 0;
$coaching_fee = $student_info['coaching_fee'] ?? 0;
$tiffin_fee = $student_info['tiffin_fee'] ?? 0;

$monthly_fee = ($custom_fee > 0 ? $custom_fee : $class_fee) + $car_fee + $hostel_fee + $coaching_fee + $tiffin_fee;
$total_amount = 0;
$total_discount_amount = 0;
$total_offer_amount = 0;
$total_unpaid_amount = 0;

$unpaid_fees = getUnpaidMonthlyFeesData($pdo, $student_id);
$unpaid_months_list = [];
$unpaid_months_name = [];

if ($unpaid_fees) {
    foreach ($unpaid_fees as $fee) {
        $total_amount += $fee['actual_amount'] ?? 0;
        $total_discount_amount += $fee['discount_amount'] ?? 0;
        $total_unpaid_amount += $fee['unpaid_amount'] ?? 0;

        // মাসের নাম ও বকেয়া সেভ করে রাখুন
        $unpaid_months_list[] = [
            'month' => $fee['month_year'],
            'due' => $fee['unpaid_amount'] ?? 0
        ];

        $unpaid_months_name[] = $fee['month_year'];
    }
} else {
    $row_is_no_due = true;
    $row_no_due_info = [
        'student_id' => $student_id,
        'name' => $student_info['name'],
        'class_name' => $student_info['class_name'],
        'section_name' => $student_info['section_name'],
        'roll_no' => $student_info['roll_no']
    ];
}

$total_offer_amount = $total_amount - $total_discount_amount;
$average_monthly_fee = $total_offer_amount / max(count($unpaid_fees), 1);

$last_payment = getLastMonthlyPayment($pdo, $student_id);

// Sort the $unpaid_months_name array lower to higher
if (count($unpaid_months_name) > 0) {
    usort($unpaid_months_name, function ($a, $b) {
        return strtotime("1 " . $a) <=> strtotime("1 " . $b);
    });
}

// Determine the month from which the advance (auto-generated) entries will start.
// This mirrors processSingleStudentPayment(): the month right after the student's
// latest recorded month (unpaid or fully paid), or the current month if none exists.
$last_recorded_month_ts = 0;
foreach (array_merge($unpaid_fees, getPaidMonthlyFeesData($pdo, $student_id)) as $recorded_fee) {
    $recorded_ts = strtotime($recorded_fee['month_year']);
    if ($recorded_ts > $last_recorded_month_ts) {
        $last_recorded_month_ts = $recorded_ts;
    }
}

$advance_start_month = $last_recorded_month_ts == 0
    ? date('Y-m')
    : date('Y-m', strtotime('+1 month', $last_recorded_month_ts));

// PREPARE DATA FOR SORTING
$sort_name = strtolower($student_info['name']);
$sort_pending = $total_unpaid_amount;
// Convert date to timestamp for easy sorting (0 if no date)
$sort_date = ($last_payment) ? strtotime($last_payment['payment_date']) : 0;

$row_rendered = true;
$row_total_unpaid_amount = $total_unpaid_amount;
?>
<tr id="trow-<?= $student_id ?>"
    class="student-row"
    data-original-index="<?= $row_index ?>"
    data-student-id="<?= $student_id ?>"
    data-name="<?= safe_htmlspecialchars($sort_name) ?>"
    data-pending="<?= $sort_pending ?>"
    data-last-payment="<?= $sort_date ?>"
    data-roll-no="<?= $student_info['roll_no'] ?? '0' ?>"
    data-class-name="<?= $student_info['class_name'] ?? '' ?>"
    data-monthly-fee="<?= $monthly_fee ?? '0' ?>"
    data-advance-start="<?= $advance_start_month ?>"
    data-unpaid-months='<?= json_encode($unpaid_months_list, JSON_HEX_APOS | JSON_HEX_QUOT) ?>'>

    <td>
        <button tabindex="-1" class="btn btn-sm btn-outline-primary more-details-btn" title="View More Details" data-student-id="<?= $student_id ?>">
            <i class="fas fa-plus-circle"></i>
        </button>
    </td>
    <td
        title="View Image"
        data-fancybox="student-images"
        data-caption="<?= $student_info['name'] ?>"
        data-src="<?= BASE_URL . "/uploads/students/" . $student_info['student_image']; ?>">
        <img
            src="<?= BASE_URL . "/uploads/students/" . $student_info['student_image']; ?>"
            alt="Img"
            loading="lazy" />
    </td>
    <td>
        <a tabindex="-1"
            class="text-decoration-none"
            href="<?= BASE_URL ?>/parent/dashboard/student-details.php?student_id=<?= $student_id ?>"
            target="_blank">
            <?= safe_htmlspecialchars($student_info['name']); ?>
        </a>
        <br>
        <small class="text-muted" style="font-size: 0.8rem;"><?= $student_id ?></small>
        <br>
        <small class="text-muted small-text">
            <?= $student_info['class_name'] . ' (' . $student_info['section_name'] . ')' ?> · Roll: <?= $student_info['roll_no'] ?>
        </small>
    </td>
    <td class="small">
        <div class="w-100 text-start" title="This is the monthly fee of the student. Included car fees, hostel fees if applicable, and other fees.">
            Monthly:
            <span class="text-dark fw-bold row-monthly-fee">
                <?= $currency_symbol . $monthly_fee; ?>
            </span>
        </div>
        <div class="w-100 text-start" title="This is the average monthly fee of the student.">
            Average Monthly:
            <span class="text-dark fw-bold row-average-monthly">
                <?= $currency_symbol . number_format($average_monthly_fee, 2, '.', ''); ?>
            </span>
        </div>
        <div class="w-100 text-start" title="Actual fee means the original total amount before any discount is applied.">
            Total:
            <span class="text-dark fw-bold row-total-actual">
                <?= $currency_symbol . $total_amount; ?>
            </span>
        </div>
        <div class="w-100 text-start">
            Discount:
            <span class="text-danger fw-bold row-total-discount">
                <?= $currency_symbol . $total_discount_amount; ?>
            </span>
        </div>
    </td>
    <td>
        <span class="text-success fw-bold row-offer-amount" title="Offer amount is the total amount after the discount has been applied.">
            <?= $currency_symbol . $total_offer_amount ?>
        </span>
    </td>
    <td>
        <div class="text-danger fw-bold w-100 row-pending-amount" title="Pending amount is the amount that is still due and needs to be paid.">
            <?= $currency_symbol . $total_unpaid_amount ?>
        </div>
        <span class="small text-dark mt-1 row-pending-months">
            <?php
            if (count($unpaid_months_name) > 0) {
                if (count($unpaid_months_name) == 1) {
                    echo $unpaid_months_name[0];
                } else {
                    echo $unpaid_months_name[0] . ' to ' . end($unpaid_months_name);
                }
            }
            ?>
        </span>
    </td>
    <td>
        <input type="text"
            class="form-control form-control-sm total-month-input text-center"
            placeholder="Total month"
            value="0">
    </td>
    <td>
        <input type="text"
            class="form-control form-control-sm payment-amount-input text-center"
            placeholder="Enter Amount"
            value="0">
        <div class="payment-projection text-start mt-2 border rounded p-1 bg-light shadow-sm" style="display: none; font-size: 0.75rem; line-height: 1.4;"></div>
    </td>
    <td>
        <input type="text"
            class="form-control form-control-sm discount-amount-input text-center"
            title="Discount is applied to the oldest pending month only, and must be less than that month's due."
            placeholder="Discount"
            value="0">
    </td>
    <td>
        <input type="date"
            class="form-control form-control-sm payment-date-input"
            value="<?= date('Y-m-d') ?>">
    </td>
    <td>
        <?php if ($last_payment): ?>
            <div class="w-100 text-center">
                <?php echo "<span class='fw-bold badge rounded-pill bg-success'>" . $currency_symbol . $last_payment['payment_amount'] . "</span>"; ?>
            </div>
            <div class="w-100 text-center my-1">
                <?php echo "<span class='fw-bold'>" . formatDate($last_payment['payment_date']) . "</span>"; ?>
            </div>
        <?php else: ?>
            -
        <?php endif; ?>
    </td>
    <td>
        <div class="d-flex justify-content-center align-items-center gap-1">
            <button
                tabindex="-1"
                title="Collect this student's fee right now (saves only this row)"
                class="btn btn-sm btn-success collect-single-btn"
                data-student-id="<?= $student_id ?>">
                <i class="fas fa-hand-holding-dollar"></i>
            </button>
            <button
                tabindex="-1"
                title="Remove student from list"
                class="btn btn-sm btn-danger remove-student-btn"
                data-student-id="<?= $student_id ?>">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    </td>
</tr>
