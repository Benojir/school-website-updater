<?php
// No bootstrap: authenticated admin data and school settings come from the caller.
function requireCollectionSecurityPin(array $schoolSettings, array $admin, mixed $submittedPin): void
{
    if ((int)($schoolSettings['need_security_pin_for_payment_entry'] ?? 0) !== 1) return;

    $storedPin = $admin['security_pin'] ?? null;
    if (!is_string($storedPin) || $storedPin === '' || !is_string($submittedPin)
        || $submittedPin === '' || !hash_equals($storedPin, $submittedPin)) {
        throw new DomainException('Invalid security PIN. Enter your security PIN to submit this payment.');
    }
}
