<?php
// No bootstrap: receipt data can also be tested without a database connection.
function admissionReceiptIds(mixed $value): array
{
    if (!is_string($value) || !preg_match('/^[1-9]\d*(?:,[1-9]\d*)*$/D', $value)) {
        throw new InvalidArgumentException('Provide valid comma-separated payment IDs.');
    }
    $ids = array_values(array_unique(explode(',', $value)));
    if (count($ids) > 100) throw new InvalidArgumentException('Print up to 100 receipts at a time.');
    foreach ($ids as $id) {
        if (!filter_var($id, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]])) {
            throw new InvalidArgumentException('Invalid payment ID.');
        }
    }
    return $ids;
}

function admissionReceiptJson(mixed $value): array
{
    if (!is_string($value)) return [];
    $decoded = json_decode($value, true);
    return is_array($decoded) && array_is_list($decoded) ? $decoded : [];
}

function admissionReceiptCents(mixed $value): int
{
    if (!is_numeric($value) || !is_finite((float)$value) || (float)$value < 0 || (float)$value > 9999999999) {
        throw new UnexpectedValueException('Invalid receipt amount.');
    }
    return (int)round((float)$value * 100);
}

function admissionReceiptNumber(int $cents): string
{
    return $cents % 100 === 0 ? (string)intdiv($cents, 100) : number_format($cents / 100, 2, '.', '');
}

function admissionReceiptBreakdown(array $payment, array $allocations = []): array
{
    $total = admissionReceiptCents($payment['payment_amount']);
    $advance = ($payment['method'] ?? '') === 'wallet' ? 0 : admissionReceiptCents($payment['wallet_affected_balance'] ?? 0);
    if ($advance > $total) throw new UnexpectedValueException('Wallet credit exceeds the payment.');
    $feeAmount = $total - $advance;
    $full = [];
    $partial = [];
    $remaining = $feeAmount;

    // Use the balances recorded with THIS payment, never today's due or full-paid
    // flags. Later payments must not rewrite an older partial-payment receipt.
    foreach (admissionReceiptJson($payment['unpaid_admission_fees_rows_backup'] ?? null) as $fee) {
        if ($remaining === 0) break;
        if (!is_array($fee) || ($fee['student_id'] ?? '') !== $payment['student_id']
            || !preg_match('/^\d{4}$/D', (string)($fee['academic_year'] ?? ''))) {
            $remaining = -1;
            break;
        }
        $due = admissionReceiptCents($fee['unpaid_amount'] ?? null);
        if ($due === 0) continue;
        $used = min($due, $remaining);
        $entry = ['year' => (string)$fee['academic_year'], 'cents' => $used];
        if ($used === $due) $full[] = $entry;
        else $partial[] = $entry + ['remaining_cents' => $due - $used];
        $remaining -= $used;
    }

    // Older history without a usable balance snapshot can use only the allocation
    // IDs belonging to this payment. A later full-paid FK alone is not proof that
    // the older payment fully settled that year.
    if ($remaining !== 0) {
        $full = $partial = [];
        $remaining = $feeAmount;
        $completedIds = array_map('strval', array_filter(admissionReceiptJson($payment['full_paid_admission_payment_ids'] ?? null), 'is_scalar'));
        $allocationIds = array_map('strval', array_filter(admissionReceiptJson($payment['partial_payment_ids_backup'] ?? null), 'is_scalar'));
        foreach ($allocations as $allocation) {
            if (($allocation['student_id'] ?? '') !== $payment['student_id']
                || !in_array((string)$allocation['id'], $allocationIds, true)
                || !preg_match('/^\d{4}$/D', (string)($allocation['academic_year'] ?? ''))) continue;
            $used = admissionReceiptCents($allocation['partial_paid_amount']);
            $entry = ['year' => (string)$allocation['academic_year'], 'cents' => $used];
            if (in_array((string)($allocation['full_paid_admission_fees_id'] ?? ''), $completedIds, true)) $full[] = $entry;
            // An allocation alone cannot establish the historical balance due.
            else $partial[] = $entry + ['remaining_cents' => null];
            $remaining -= $used;
        }
    }
    $available = $remaining === 0 && count($partial) <= 1 && !($partial && $advance > 0);
    if (!$available) $full = $partial = [];
    usort($full, static fn($a, $b) => $a['year'] <=> $b['year']);
    return ['total' => $total, 'advance' => $advance, 'fee_amount' => $feeAmount,
        'full' => $full, 'partial' => $partial, 'available' => $available];
}

function admissionReceiptLoad(PDO $pdo, array $ids): array
{
    $placeholders = implode(', ', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("SELECT ph.*, s.name AS student_name, s.student_image, s.roll_no,
        c.class_name, sec.section_name, u.full_name AS collector_name
        FROM admission_fees_payment_history ph
        LEFT JOIN students s ON s.student_id = ph.student_id
        LEFT JOIN classes c ON c.id = s.class_id
        LEFT JOIN sections sec ON sec.id = s.section_id
        LEFT JOIN users u ON u.id = ph.entry_by
        WHERE ph.id IN ($placeholders)");
    $stmt->execute($ids);
    $byId = [];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $payment) {
        $breakdown = admissionReceiptBreakdown($payment);
        if (!$breakdown['available']) {
            $allocationIds = admissionReceiptJson($payment['partial_payment_ids_backup'] ?? null);
            $allocationIds = array_values(array_filter($allocationIds, static fn($id) => is_scalar($id)
                && filter_var($id, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]])));
            if ($allocationIds && count($allocationIds) <= 500) {
                $marks = implode(', ', array_fill(0, count($allocationIds), '?'));
                $partial = $pdo->prepare("SELECT * FROM admission_partial_fees_payments WHERE student_id = ? AND id IN ($marks) ORDER BY academic_year, id");
                $partial->execute(array_merge([$payment['student_id']], $allocationIds));
                $breakdown = admissionReceiptBreakdown($payment, $partial->fetchAll(PDO::FETCH_ASSOC));
            }
        }
        $payment['breakdown'] = $breakdown;
        $byId[(string)$payment['id']] = $payment;
    }
    $ordered = [];
    foreach ($ids as $id) if (isset($byId[$id])) $ordered[] = $byId[$id];
    return $ordered;
}

function admissionReceiptYears(array $years): string
{
    $years = array_values(array_unique(array_map('intval', $years)));
    sort($years);
    $groups = [];
    for ($i = 0; $i < count($years); $i++) {
        $start = $end = $years[$i];
        while (isset($years[$i + 1]) && $years[$i + 1] === $end + 1) $end = $years[++$i];
        $groups[] = $start === $end ? (string)$start : "$start to $end";
    }
    return implode(', ', $groups);
}

function admissionReceiptRender(array $receipts, array $school, string $baseUrl, string $currency, callable $photoUrl, callable $words, int $missing = 0): string
{
    $escape = static fn($value) => htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $money = static fn($cents) => $escape($currency . admissionReceiptNumber($cents) . '/-');
    $directory = __DIR__ . '/../../assets/templates/payment-receipts/admission/design-1/';
    $template = file_get_contents($directory . 'content.html');
    $main = file_get_contents($directory . 'main.html');
    $html = '';
    foreach ($receipts as $payment) {
        $data = $payment['breakdown'];
        $rows = '';
        if ($data['full']) {
            $sum = array_sum(array_column($data['full'], 'cents'));
            $calculation = $money($sum);
            if (count($data['full']) > 1) {
                $calculation = implode(' + ', array_map(static fn($row) => admissionReceiptNumber($row['cents']), $data['full'])) . ' = ' . $money($sum);
            }
            $rows .= '<tr><td class="years">' . $escape(admissionReceiptYears(array_column($data['full'], 'year')))
                . '</td><td class="status-paid">Paid</td><td class="amount">' . $calculation . '</td></tr>';
        }
        foreach ($data['partial'] as $row) {
            $remainingDue = isset($row['remaining_cents']) ? $money($row['remaining_cents']) : 'N/A';
            $rows .= '<tr><td class="years">' . $escape($row['year']) . '</td><td class="status-partial">Partial</td><td class="amount">'
                . $money($row['cents']) . '<span class="remaining-due">Due after payment: <strong>' . $remainingDue . '</strong></span></td></tr>';
        }
        if (!$data['available'] && $data['fee_amount'] > 0) {
            $rows .= '<tr><td>Admission fee</td><td>Received</td><td class="amount">' . $money($data['fee_amount']) . '</td></tr>';
        }
        if ($data['advance'] > 0) {
            $rows .= '<tr><td>Wallet Credit</td><td class="status-paid">Advance</td><td class="amount">' . $money($data['advance']) . '</td></tr>';
        }
        $date = strtotime((string)$payment['payment_date']);
        $method = ['cash' => 'Cash', 'online' => 'Online', 'wallet' => 'Wallet', 'bank' => 'Bank'][$payment['method'] ?? 'cash'] ?? ucfirst((string)$payment['method']);
        $html .= strtr($template, [
            '{receipt_no}' => $escape($payment['id']),
            '{school_name}' => $escape($school['name'] ?? ''),
            '{school_contact}' => $escape(implode(' | ', array_filter([$school['phone'] ?? '', $school['alternate_phone'] ?? '']))),
            '{school_logo}' => $escape($baseUrl . '/uploads/school/logo-square.png'),
            '{student_name}' => $escape($payment['student_name'] ?? $payment['student_id']),
            '{student_id}' => $escape($payment['student_id']),
            '{class_name}' => $escape($payment['class_name'] ?? '-'),
            '{section_name}' => $escape($payment['section_name'] ?? '-'),
            '{roll_no}' => $escape($payment['roll_no'] ?? '-'),
            '{student_image}' => $escape($photoUrl($payment['student_image'] ?? 'default_student_dp.jpg')),
            '{tbody_rows}' => $rows,
            '{total_payment_amount}' => $money($data['total']),
            '{paid_amount_in_words}' => $escape(ucfirst($words($data['total'] / 100)) . ' only'),
            '{payment_date}' => $escape($date === false ? '-' : date('d-m-Y', $date)),
            '{collector_name}' => $escape($payment['collector_name'] ?? 'N/A'),
            '{method}' => $escape($method),
            '{breakdown_note}' => $data['available'] ? '' : 'Year-wise details are unavailable for this older payment.',
        ]);
    }
    return strtr($main, ['{receipts}' => $html,
        '{stylesheet}' => $escape($baseUrl . '/assets/templates/payment-receipts/admission/design-1/styles.css'),
        '{receipt_count}' => (string)count($receipts),
        '{missing_note}' => $missing > 0 ? $escape("$missing selected receipt(s) are no longer available.") : '',
    ]);
}
