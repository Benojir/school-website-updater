<?php
include_once __DIR__ . '/../config.php';
include_once __DIR__ . '/../functions.php';

// Function to fees entry or update for admission
function fun_admission_fees_entry(PDO $pdo, $student_ids_with_comma, $academic_year, $admission_class_id = null, $discount = 0, $is_re_admission = false)
{
    $return_response = [];

    try {
        $student_ids_string = sanitize_input($student_ids_with_comma);
        $academic_year = sanitize_input($academic_year);
        $admission_class_id = sanitize_input($admission_class_id);
        $discount = sanitize_input($discount);

        // Check required fields
        if (empty($student_ids_string)) {
            $return_response['success'] = false;
            $return_response['message'] = 'Student IDs are required.';
            return $return_response;
        }

        if (empty($academic_year)) {
            $return_response['success'] = false;
            $return_response['message'] = 'Academic year is required.';
            return $return_response;
        }

        if (!isIntegerLike($academic_year)) {
            $return_response['success'] = false;
            $return_response['message'] = 'Invalid academic year format.';
            return $return_response;
        }

        if (empty($discount)) {
            $discount = 0;
        }

        if (!is_numeric(($discount))) {
            $return_response['success'] = false;
            $return_response['message'] = 'Invalid discount input.';
            return $return_response;
        }

        $table_name = "class_wise_new_admission_fees";

        if ($is_re_admission) {
            $table_name = "class_wise_re_admission_fees";
        }

        // Get Student IDs Array
        $studentIDs = explode(',', $student_ids_string);

        if (count($studentIDs) <= 0) {
            $return_response['success'] = false;
            $return_response['message'] = 'No valid student IDs provided.';
            return $return_response;
        }

        $results = [];
        $processedCount = 0;
        $skippedCount = 0;
        $last_proccessed_sid = null;
        $processedStudentIds = [];

        foreach ($studentIDs as $student_id) {
            // Start transaction for each student
            $pdo->beginTransaction();

            try {
                // Fetch student info
                $stmt = $pdo->prepare("SELECT * FROM students WHERE student_id = ?");
                $stmt->execute([$student_id]);
                $student_info = $stmt->fetch(PDO::FETCH_ASSOC);

                // Skip if not found or student has left
                if (!$student_info || strtolower($student_info['status']) == 'left' || strtolower($student_info['status']) == 'alumni') {
                    $results[] = [
                        'student_id' => $student_id,
                        'success' => false,
                        'message' => 'Student not found or has left or alumni',
                        'action' => 'skipped'
                    ];
                    $skippedCount++;
                    $pdo->commit();
                    continue;
                }

                $class_id = $student_info['class_id'];

                if (!empty($admission_class_id) && is_numeric($admission_class_id)) {
                    $class_id = $admission_class_id;
                }

                $remark = "Admission fee";

                if ($is_re_admission) {
                    $remark .= " (Re-Admission)";
                } else {
                    $remark .= " (New Admission)";
                }

                if ($discount > 0) {
                    $remark = $remark . ' with ' . $discount . '/- discount applied ';
                }

                // Fetch admission fee class wise
                $stmt = $pdo->prepare("SELECT amount FROM {$table_name} WHERE class_id = ?");
                $stmt->execute([$class_id]);
                $admission_fee_row = $stmt->fetch(PDO::FETCH_ASSOC);

                if (!$admission_fee_row) {
                    $results[] = [
                        'student_id' => $student_id,
                        'success' => false,
                        'message' => 'Admission fee not found for the selected class (' . getClassNameById($pdo, $class_id) . '). Maybe the admission fee is not set for this class?',
                        'action' => 'skipped'
                    ];
                    $skippedCount++;
                    $pdo->commit();
                    continue;
                }

                $admission_fee = $admission_fee_row['amount'];

                // Calculate total fees
                $actual_fees = $admission_fee;
                $total_fees_with_discount = $actual_fees - $discount;

                if ($actual_fees <= $discount) {
                    $results[] = [
                        'student_id' => $student_id,
                        'success' => false,
                        'message' => "Discount of $discount exceeds or equals the total fees of $actual_fees",
                        'action' => 'skipped'
                    ];
                    $skippedCount++;
                    $pdo->commit();
                    continue;
                }

                // Check if this academic year's fee already exists in full_paid_fees
                $stmt = $pdo->prepare("SELECT id FROM admission_full_paid_fees WHERE student_id = ? AND academic_year = ?");
                $stmt->execute([$student_id, $academic_year]);
                if ($stmt->fetch()) {
                    $results[] = [
                        'student_id' => $student_id,
                        'success' => false,
                        'message' => "Admission fee for $academic_year already marked as fully paid",
                        'action' => 'skipped'
                    ];
                    $skippedCount++;
                    $pdo->commit();
                    continue;
                }

                // Check for existing unpaid fee for this year
                $stmt = $pdo->prepare("SELECT * FROM admission_unpaid_fees WHERE student_id = ? AND academic_year = ? LIMIT 1");
                $stmt->execute([$student_id, $academic_year]);
                $existing_fee = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($existing_fee) {
                    // If existing unpaid fee found, check if it's the same amount
                    if ($existing_fee['unpaid_amount'] == $total_fees_with_discount && $existing_fee['discount_amount'] == $discount && $existing_fee['actual_amount'] == $actual_fees) {
                        $results[] = [
                            'student_id' => $student_id,
                            'success' => false,
                            'message' => "Unpaid admission fee for $academic_year already exists with same amount",
                            'action' => 'skipped'
                        ];
                        $skippedCount++;
                        $pdo->commit();
                        continue;
                    }

                    // Fetch total partially paid amount
                    $stmt = $pdo->prepare("SELECT SUM(partial_paid_amount) as total_partial_paid FROM admission_partial_fees_payments WHERE unpaid_admission_fees_id = ?");
                    $stmt->execute([$existing_fee['id']]);
                    $total_partial_paid = $stmt->fetchColumn();

                    $unpaid_amount_after_discount = $total_fees_with_discount - $total_partial_paid;

                    if ($unpaid_amount_after_discount < 0) {
                        $results[] = [
                            'student_id' => $student_id,
                            'success' => false,
                            'message' => "The new unpaid amount after discount is less than the total partially paid amount. Please review the discount or fees. To fix this delete the payment history and re-add the unpaid fee.",
                            'action' => 'skipped'
                        ];
                        $skippedCount++;
                        $pdo->commit();
                        continue;
                    }

                    // Update existing record
                    $updateStmt = $pdo->prepare("UPDATE admission_unpaid_fees SET class_id = ?, actual_amount = ?, unpaid_amount = ?, discount_amount = ?, remark = ? WHERE id = ?");
                    $updateStmt->execute([
                        $class_id,
                        $actual_fees,
                        $unpaid_amount_after_discount,
                        $discount,
                        $remark,
                        $existing_fee['id']
                    ]);

                    $action = 'updated';
                    $processedStudentIds[] = $student_id;
                } else {
                    // Insert new record
                    $insertStmt = $pdo->prepare("
                        INSERT INTO admission_unpaid_fees
                        (student_id, academic_year, class_id, actual_amount, unpaid_amount, discount_amount, remark, created_at) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
                    ");
                    $insertStmt->execute([
                        $student_id,
                        $academic_year,
                        $class_id,
                        $actual_fees,
                        $total_fees_with_discount,
                        $discount,
                        $remark
                    ]);

                    $action = 'created';
                    $processedStudentIds[] = $student_id;
                }

                $results[] = [
                    'student_id' => $student_id,
                    'success' => true,
                    'message' => "Admission fee record {$action} successfully",
                    'action' => $action,
                    'amount' => $total_fees_with_discount
                ];
                $processedCount++;
                $last_proccessed_sid = $student_id;

                $pdo->commit();
            } catch (Exception $e) {
                $pdo->rollBack();
                $results[] = [
                    'student_id' => $student_id,
                    'success' => false,
                    'message' => "Error processing student ID $student_id: " . $e->getMessage(),
                    'action' => 'skipped'
                ];
                $skippedCount++;
                // Continue to next student without throwing the exception
                continue;
            }
        }

        // Send notification to processed students
        if (count($processedStudentIds) > 0) {
            $fcmTokens = getFCMTokensFromDatabase($pdo, $processedStudentIds);
            if ($fcmTokens) {
                $notificationTitle = 'Unpaid Admission Fee (' . $academic_year . ')';
                $notificationBody = 'Your admission fee has been updated successfully. Please check your account for details.';
                $data = [
                    'title' => $notificationTitle,
                    'message' => $notificationBody
                ];
                try {
                    sendFirebaseNotification($pdo, $processedStudentIds, $fcmTokens, $notificationTitle, $notificationBody, $data);
                } catch (Exception $e) {
                    // Log the error if needed
                    // error_log("Failed to send notification: " . $e->getMessage());
                }
            }
        }

        $return_response['success'] = true;
        $return_response['message'] = "Processed {$processedCount} students, skipped {$skippedCount}";
        $return_response['total_students'] = count($studentIDs);
        $return_response['processed'] = $processedCount;
        $return_response['skipped'] = $skippedCount;
        $return_response['results'] = $results;
        return $return_response;

    } catch (Exception $e) {
        $return_response['success'] = false;
        $return_response['message'] = $e->getMessage();
        $return_response['error'] = true;
        $return_response['processed_up_to'] = $last_proccessed_sid ?? null;
        return $return_response;
    }
}
