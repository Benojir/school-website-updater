<?php
// Read-only lookup shared by the report endpoint and isolated array-based tests.
final class MonthlyFeeStudentSearch
{
    public const PAGE_SIZE = 20;
    public const FIELDS = ['s.student_id', 's.name', 's.father_name', 's.mother_name',
        's.registration_no', 'ar.registration_no', 's.phone_number', 's.alternate_phone_number',
        's.address', 's.email', 's.roll_no', 'ar.roll_no'];

    public function __construct(private PDO $pdo) {}

    public function search(string $term, string $month, int $page = 1): array
    {
        $term = trim($term);
        if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/D', $month)) throw new InvalidArgumentException('Select a valid billing month.');
        if (strlen($term) > 300) throw new InvalidArgumentException('Please use a shorter search term.');
        if ($page < 1 || $page > 10000) throw new InvalidArgumentException('Invalid search page.');
        if ($term === '') return ['results' => [], 'pagination' => ['more' => false]];

        // Keep LIKE metacharacters literal; only the surrounding wildcards broaden the search.
        $pattern = '%' . str_replace(['=', '%', '_'], ['==', '=%', '=_'], $term) . '%';
        $where = implode(' OR ', array_map(static fn($field) => "$field LIKE ? ESCAPE '='", self::FIELDS));
        $stmt = $this->pdo->prepare("SELECT s.student_id, s.name, s.father_name, s.phone_number,
            s.alternate_phone_number,
            CASE WHEN ar.id IS NULL THEN s.roll_no ELSE ar.roll_no END AS roll_no,
            CASE WHEN ar.id IS NULL THEN s.registration_no ELSE ar.registration_no END AS registration_no,
            c.class_name, sec.section_name
            FROM students s LEFT JOIN student_academic_records ar ON ar.student_row_id = s.id AND ar.academic_year = ?
            LEFT JOIN classes c ON c.id = CASE WHEN ar.id IS NULL THEN s.class_id ELSE ar.class_id END
            LEFT JOIN sections sec ON sec.id = CASE WHEN ar.id IS NULL THEN s.section_id ELSE ar.section_id END
            WHERE ($where) ORDER BY s.name, s.student_id LIMIT ? OFFSET ?");
        $values = [substr($month, 0, 4), ...array_fill(0, count(self::FIELDS), $pattern), self::PAGE_SIZE + 1, ($page - 1) * self::PAGE_SIZE];
        foreach ($values as $index => $value) $stmt->bindValue($index + 1, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
        $stmt->execute();
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $more = count($students) > self::PAGE_SIZE;
        return ['results' => array_slice($students, 0, self::PAGE_SIZE), 'pagination' => ['more' => $more]];
    }
}
