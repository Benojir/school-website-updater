<?php
// Additive category ledger. Call mutations inside the caller's student transaction.
// Existing bills without a verified breakdown use the unclassified category.
final class MonthlyFeeLedger
{
    public const FEES = ['tuition' => 'Tuition Fee', 'car' => 'Car Fee', 'hostel' => 'Hostel Fee',
        'coaching' => 'Coaching Fee', 'tiffin' => 'Tiffin Fee', 'other' => 'Other Fee',
        'unclassified' => 'Legacy / unclassified'];

    public function __construct(private PDO $pdo) {}

    public static function cents(mixed $amount): int
    {
        if (!is_numeric($amount) || !is_finite((float)$amount) || abs((float)$amount) > 99999999.99) {
            throw new InvalidArgumentException('Invalid monthly fee amount.');
        }
        return (int)round((float)$amount * 100);
    }

    public static function money(int $cents): string { return number_format($cents / 100, 2, '.', ''); }

    public static function amounts(array $amounts): array
    {
        $result = [];
        foreach (self::FEES as $code => $label) {
            if ($code === 'unclassified') continue;
            $value = self::cents($amounts[$code] ?? 0);
            if ($value < 0) throw new InvalidArgumentException('Fee components cannot be negative.');
            $result[$code] = self::money($value);
        }
        return $result;
    }

    // Integer paise avoids rounding drift across partial payments and reversals.
    public static function split(array $balances, int $amount): array
    {
        if ($amount < 0) throw new InvalidArgumentException('Allocation cannot be negative.');
        $parts = [];
        foreach (self::FEES as $code => $label) {
            $part = min($amount, max(0, $balances[$code] ?? 0));
            if ($part > 0) $parts[$code] = $part;
            $amount -= $part;
        }
        if ($amount !== 0) throw new DomainException('Payment exceeds the saved component balances.');
        return $parts;
    }

    private function rows(string $sql, array $params = []): array
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    private function run(string $sql, array $params): void
    {
        if (!$this->pdo->inTransaction()) throw new LogicException('Monthly ledger mutation requires a transaction.');
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
    }

    private function insert(string $table, array $values): int
    {
        $this->run('INSERT INTO ' . $table . ' (' . implode(', ', array_keys($values)) . ') VALUES ('
            . implode(', ', array_fill(0, count($values), '?')) . ')', array_values($values));
        return (int)$this->pdo->lastInsertId();
    }

    public function bill(string $student, string $month, bool $lock = false): ?array
    {
        return $this->rows('SELECT * FROM monthly_fee_bills WHERE student_id = ? AND month_year = ?'
            . ($lock ? ' FOR UPDATE' : ''), [$student, $month])[0] ?? null;
    }

    public function components(int $bill): array
    {
        return $this->rows('SELECT * FROM monthly_fee_bill_components WHERE bill_id = ?', [$bill]);
    }

    public function balances(int $bill): array
    {
        $result = [];
        foreach ($this->components($bill) as $row) {
            $result[$row['fee_code']] = ['billed' => self::cents($row['billed_amount']),
                'discount' => self::cents($row['discount_amount']), 'opening_paid' => self::cents($row['opening_paid_amount']), 'paid' => 0];
        }
        foreach ($this->rows('SELECT * FROM monthly_fee_payment_allocations WHERE bill_id = ?', [$bill]) as $row) {
            if (!isset($result[$row['fee_code']])) throw new DomainException('Monthly component is missing.');
            $key = $row['allocation_type'] === 'discount' ? 'discount' : 'paid';
            $result[$row['fee_code']][$key] += self::cents($row['amount']);
        }
        foreach ($result as &$row) {
            $row['due'] = $row['billed'] - $row['discount'] - $row['opening_paid'] - $row['paid'];
            if ($row['due'] < 0 || $row['discount'] < 0 || $row['paid'] < 0) {
                throw new DomainException('Monthly category balances do not reconcile.');
            }
        }
        unset($row);
        return $result;
    }

    public function assertFee(array $bill, array $fee): void
    {
        $balances = $this->balances((int)$bill['id']);
        if ($bill['status'] !== 'active' || array_sum(array_column($balances, 'billed')) !== self::cents($fee['actual_amount'])
            || array_sum(array_column($balances, 'discount')) !== self::cents($fee['discount_amount'])
            || array_sum(array_column($balances, 'due')) !== self::cents($fee['unpaid_amount'])) {
            throw new DomainException('Monthly bill and category balances differ. Review the bill before collecting payment.');
        }
    }

    private function create(string $student, string $month, string $state): array
    {
        $time = strtotime('1 ' . $month);
        if ($time === false || date('F Y', $time) !== $month) throw new InvalidArgumentException('Invalid billing month.');
        $this->insert('monthly_fee_bills', ['student_id' => $student, 'month_year' => $month,
            'billing_month' => date('Y-m', $time), 'academic_year' => date('Y', $time),
            'breakdown_state' => $state, 'status' => 'active', 'revision' => 1,
            'audit_history' => '[]', 'created_at' => date('Y-m-d H:i:s')]);
        return $this->bill($student, $month, true) ?? throw new LogicException('Monthly bill was not created.');
    }

    private function setComponents(int $bill, array $components): void
    {
        $existing = [];
        foreach ($this->components($bill) as $row) $existing[$row['fee_code']] = $row;
        foreach (self::FEES as $code => $label) {
            $values = $components[$code] ?? ['billed_amount' => '0.00', 'discount_amount' => '0.00', 'opening_paid_amount' => '0.00'];
            if (isset($existing[$code])) {
                $this->run('UPDATE monthly_fee_bill_components SET billed_amount = ?, discount_amount = ?, opening_paid_amount = ? WHERE id = ?',
                    [$values['billed_amount'], $values['discount_amount'], $values['opening_paid_amount'], $existing[$code]['id']]);
            } else {
                $this->insert('monthly_fee_bill_components', ['bill_id' => $bill, 'fee_code' => $code,
                    'priority' => array_search($code, array_keys(self::FEES), true) + 1] + $values);
            }
        }
    }

    public function snapshot(array $bill): array
    {
        return ['bill' => $bill, 'components' => $this->components((int)$bill['id'])];
    }

    private function revise(array $bill, string $state, string $status, string $reason): void
    {
        $audit = json_decode($bill['audit_history'], true, 64, JSON_THROW_ON_ERROR);
        $audit[] = ['at' => date('Y-m-d H:i:s'), 'reason' => $reason,
            'revision' => $bill['revision'], 'status' => $bill['status'], 'breakdown_state' => $bill['breakdown_state'],
            'components' => $this->components((int)$bill['id'])];
        $this->run('UPDATE monthly_fee_bills SET breakdown_state = ?, status = ?, revision = ?, audit_history = ? WHERE id = ?',
            [$state, $status, (int)$bill['revision'] + 1, json_encode($audit, JSON_THROW_ON_ERROR), $bill['id']]);
    }

    public function ensure(array $fee): array
    {
        $bill = $this->bill($fee['student_id'], $fee['month_year'], true);
        if (!$bill) {
            $bill = $this->create($fee['student_id'], $fee['month_year'], 'legacy');
            $gross = self::cents($fee['actual_amount']); $discount = self::cents($fee['discount_amount']);
            $paid = $gross - $discount - self::cents($fee['unpaid_amount']);
            if ($paid < 0) throw new DomainException('Legacy bill totals do not reconcile.');
            $this->setComponents((int)$bill['id'], ['unclassified' => ['billed_amount' => self::money($gross),
                'discount_amount' => self::money($discount), 'opening_paid_amount' => self::money($paid)]]);
        }
        $this->assertFee($bill, $fee);
        return $bill;
    }

    // A reviewed bill edit preserves allocations already collected in each category.
    // Older partially paid bills remain unclassified until their remaining due is verified explicitly.
    public function saveBill(string $student, string $month, array $gross, mixed $discount, ?array $oldFee = null): array
    {
        if ($oldFee) $this->requireEditable($oldFee);
        $gross = self::amounts($gross);
        $bill = $this->bill($student, $month, true);
        if ($bill && $bill['status'] === 'active' && $oldFee) $this->assertFee($bill, $oldFee);
        if ($bill && $bill['status'] === 'active' && !$oldFee) {
            throw new DomainException('A category bill already exists for this month. Review its existing aggregate record before replacing it.');
        }
        if (!$bill && $oldFee && self::cents($oldFee['actual_amount']) - self::cents($oldFee['discount_amount']) - self::cents($oldFee['unpaid_amount']) > 0) {
            $bill = $this->ensure($oldFee);
        }
        $bill ??= $this->create($student, $month, 'complete');
        if ($bill['status'] === 'active' && $bill['breakdown_state'] === 'opening_reviewed') {
            throw new DomainException('This legacy opening balance was verified separately. Change future student fees instead of replacing its historical bill.');
        }
        $oldBalances = $this->balances((int)$bill['id']);
        $events = $this->rows('SELECT * FROM monthly_fee_payment_allocations WHERE bill_id = ?', [$bill['id']]);
        $eventDiscount = [];
        foreach ($events as $event) if ($event['allocation_type'] === 'discount') {
            $eventDiscount[$event['fee_code']] = ($eventDiscount[$event['fee_code']] ?? 0) + self::cents($event['amount']);
        }
        $baseDiscount = self::cents($discount) - array_sum($eventDiscount);
        if ($baseDiscount < 0) throw new DomainException('Reverse the collection discount before reducing the bill discount.');
        $state = $bill['status'] === 'void' ? 'complete' : $bill['breakdown_state'];
        if ($bill['status'] === 'void' && (array_sum(array_column($oldBalances, 'paid')) !== 0 || array_sum($eventDiscount) !== 0)) {
            throw new DomainException('Reverse previous allocations before recreating this bill.');
        }
        if ($bill['status'] === 'void') $oldBalances = [];
        if ($state !== 'complete' && $oldBalances) {
            // Tariff edits cannot manufacture a category history for legacy receipts.
            $gross = ['unclassified' => self::money(array_sum(array_map([self::class, 'cents'], $gross)))];
        }
        $capacity = [];
        foreach ($gross as $code => $value) {
            $capacity[$code] = self::cents($value) - ($oldBalances[$code]['paid'] ?? 0)
                - ($oldBalances[$code]['opening_paid'] ?? 0) - ($eventDiscount[$code] ?? 0);
            if ($capacity[$code] < 0) throw new DomainException('A fee cannot be reduced below its existing payments and collection discounts. Reverse the payment first.');
        }
        $discountParts = self::split($capacity, $baseDiscount);
        $components = [];
        foreach ($gross as $code => $value) $components[$code] = ['billed_amount' => $value,
            'discount_amount' => self::money($discountParts[$code] ?? 0),
            'opening_paid_amount' => self::money($oldBalances[$code]['opening_paid'] ?? 0)];
        $this->revise($bill, $state, 'active', 'Reviewed monthly bill');
        $this->setComponents((int)$bill['id'], $components);
        return $this->bill($student, $month, true);
    }

    public function allocate(array $bill, mixed $amount, string $type, string $date, string $method): array
    {
        if (!in_array($type, ['payment', 'discount'], true)) throw new InvalidArgumentException('Invalid allocation type.');
        $balances = $this->balances((int)$bill['id']);
        $parts = self::split(array_map(static fn($row) => $row['due'], $balances), self::cents($amount));
        $ids = [];
        foreach ($parts as $code => $part) $ids[] = $this->insert('monthly_fee_payment_allocations', [
            'bill_id' => $bill['id'], 'student_id' => $bill['student_id'], 'payment_history_id' => null,
            'fee_code' => $code, 'allocation_type' => $type, 'amount' => self::money($part),
            'payment_date' => $date, 'method' => $method, 'reversal_of_id' => null, 'created_at' => date('Y-m-d H:i:s')]);
        return $ids;
    }

    public function link(array $ids, int $history): void
    {
        foreach ($ids as $id) $this->run('UPDATE monthly_fee_payment_allocations SET payment_history_id = ? WHERE id = ?', [$history, $id]);
    }

    public function reverse(array $payment, int $admin): void
    {
        $events = $this->rows('SELECT * FROM monthly_fee_payment_allocations WHERE payment_history_id = ? FOR UPDATE', [$payment['id']]);
        foreach ($events as $event) {
            if ($event['reversal_of_id'] !== null) continue;
            $already = $this->rows('SELECT * FROM monthly_fee_payment_allocations WHERE reversal_of_id = ?', [$event['id']]);
            if ($already) throw new DomainException('Monthly allocation was already reversed.');
        }
        foreach ($events as $event) {
            if ($event['reversal_of_id'] !== null) continue;
            $originalId = $event['id']; unset($event['id']);
            $event['amount'] = self::money(-self::cents($event['amount']));
            $event['reversal_of_id'] = $originalId; $event['created_at'] = date('Y-m-d H:i:s');
            $this->insert('monthly_fee_payment_allocations', $event);
        }
        $snapshots = json_decode($payment['monthly_bill_snapshots'] ?? '[]', true, 64, JSON_THROW_ON_ERROR);
        if (!is_array($snapshots)) throw new DomainException('Invalid monthly bill backup.');
        if (!$snapshots && !$events) {
            // A pre-migration receipt can be reversed after newer category receipts were reversed.
            // Reconcile the unknown opening balance to the aggregate rows restored by the caller.
            $oldFees = json_decode($payment['unpaid_fee_rows_backup'] ?? '[]', true, 64, JSON_THROW_ON_ERROR);
            foreach ($oldFees as $oldFee) {
                $bill = $this->bill($payment['student_id'], $oldFee['month_year'], true);
                if (!$bill) continue;
                $fee = $this->rows('SELECT * FROM student_unpaid_fees WHERE student_id = ? AND month_year = ?',
                    [$payment['student_id'], $oldFee['month_year']])[0] ?? null;
                if (!$fee) throw new DomainException('Restored legacy bill was not found.');
                $balances = $this->balances((int)$bill['id']);
                if (array_sum(array_column($balances, 'paid')) !== 0) {
                    throw new DomainException('Reverse newer category payments before reversing this legacy payment.');
                }
                $this->revise($bill, 'legacy', 'active', 'Pre-migration payment reversed by ' . $admin);
                $this->setComponents((int)$bill['id'], ['unclassified' => [
                    'billed_amount' => self::money(self::cents($fee['actual_amount'])),
                    'discount_amount' => self::money(self::cents($fee['discount_amount'])),
                    'opening_paid_amount' => self::money(self::cents($fee['actual_amount']) - self::cents($fee['discount_amount']) - self::cents($fee['unpaid_amount']))]]);
            }
        }
        foreach ($snapshots as $entry) {
            $bill = $this->bill($payment['student_id'], $entry['month_year'], true);
            if (!$bill) throw new DomainException('Monthly bill backup cannot be matched.');
            $snapshot = $entry['snapshot'];
            if ($snapshot === null) {
                $this->revise($bill, $bill['breakdown_state'], 'void', 'Advance payment reversed by ' . $admin);
                $this->run('DELETE FROM student_unpaid_fees WHERE month_year = ? AND student_id = ?', [$entry['month_year'], $payment['student_id']]);
            } else {
                if ($snapshot['bill']['student_id'] !== $payment['student_id'] || (int)$snapshot['bill']['id'] !== (int)$bill['id']) {
                    throw new DomainException('Invalid monthly component backup.');
                }
                $this->revise($bill, $snapshot['bill']['breakdown_state'], $snapshot['bill']['status'], 'Payment reversed by ' . $admin);
                $components = [];
                foreach ($snapshot['components'] as $component) $components[$component['fee_code']] = $component;
                $this->setComponents((int)$bill['id'], $components);
            }
        }
    }

    public function cancel(array $fee): void
    {
        $this->requireEditable($fee);
        if (self::cents($fee['actual_amount']) - self::cents($fee['discount_amount']) !== self::cents($fee['unpaid_amount'])) {
            throw new DomainException('Reverse existing payments before deleting this bill.');
        }
        $bill = $this->bill($fee['student_id'], $fee['month_year'], true);
        if ($bill) {
            $this->assertFee($bill, $fee);
            $this->revise($bill, $bill['breakdown_state'], 'void', 'Unpaid bill deleted');
        }
    }

    public function verifyRemaining(array $fee, array $remaining, int $admin): void
    {
        $this->requireEditable($fee);
        $remaining = self::amounts($remaining);
        if (array_sum(array_map([self::class, 'cents'], $remaining)) !== self::cents($fee['unpaid_amount'])) {
            throw new DomainException('The reviewed components must equal the existing remaining due.');
        }
        $bill = $this->ensure($fee);
        if ($bill['breakdown_state'] !== 'legacy') throw new DomainException('This bill already has a reviewed breakdown.');
        $balances = $this->balances((int)$bill['id']);
        $unknown = $balances['unclassified'];
        $components = [];
        foreach ($remaining as $code => $amount) $components[$code] = ['billed_amount' => $amount,
            'discount_amount' => '0.00', 'opening_paid_amount' => '0.00'];
        // Only the unpaid opening balance is categorized. Historical collections remain unknown.
        $unknownComponent = array_values(array_filter($this->components((int)$bill['id']), static fn($row) => $row['fee_code'] === 'unclassified'))[0];
        $components['unclassified'] = ['billed_amount' => self::money($unknown['billed'] - $unknown['due']),
            'discount_amount' => $unknownComponent['discount_amount'],
            'opening_paid_amount' => self::money($unknown['opening_paid'])];
        $this->revise($bill, 'opening_reviewed', 'active', 'Remaining legacy due verified by ' . $admin);
        $this->setComponents((int)$bill['id'], $components);
        $this->assertFee($this->bill($fee['student_id'], $fee['month_year']), $fee);
    }

    private function requireEditable(array $fee): void
    {
        if (empty($fee['id'])) return;
        $orders = $this->rows('SELECT * FROM online_fee_payment_orders WHERE student_id = ? AND fee_type = ? AND fee_id = ?',
            [$fee['student_id'], 'monthly-fee', $fee['id']]);
        foreach ($orders as $order) if (in_array($order['payment_status'], ['pending', 'review'], true)) {
            throw new DomainException('Check the pending online payment before editing or deleting this bill.');
        }
    }
}
