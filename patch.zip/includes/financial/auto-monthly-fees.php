<?php
require_once __DIR__ . '/monthly-fee-ledger.php';

/** @return resource|null Keep the handle open until the entire job has finished. */
function autoMonthlyFeesAcquireLock(?string $path = null)
{
    // Each installation gets its own lock without requiring writable source files.
    $path ??= rtrim(sys_get_temp_dir(), '/\\') . '/school-monthly-fees-' . hash('sha256', __DIR__) . '.lock';
    $handle = @fopen($path, 'c');
    if ($handle === false) throw new RuntimeException('Cannot open the monthly fee cron lock. Check access to the PHP temporary directory.');
    if (!@flock($handle, LOCK_EX | LOCK_NB, $wouldBlock)) {
        fclose($handle);
        if ($wouldBlock) return null;
        throw new RuntimeException('Cannot acquire the monthly fee cron lock.');
    }
    return $handle;
}

// No bootstrap or network side effects. Each student's aggregate fee and category
// ledger commit together; only committed students are passed to the notifier.
final class AutoMonthlyFeesJob
{
    public function __construct(private PDO $pdo, private int $batchSize = 100, private int $reportLimit = 200)
    {
        if ($batchSize < 1 || $batchSize > 1000 || $reportLimit < 0 || $reportLimit > 1000) {
            throw new InvalidArgumentException('Invalid monthly fee batch or report limit.');
        }
    }

    public function run(DateTimeImmutable $billingDate, string $currency, ?callable $notify = null, ?callable $log = null): array
    {
        $month = $billingDate->format('F Y');
        $report = ['success' => true, 'billing_success' => true, 'month' => $month,
            'total' => 0, 'processed' => 0, 'skipped' => 0, 'errors' => 0,
            'notification_batches_failed' => 0, 'results' => [], 'results_omitted' => 0];
        $record = function (array $result) use (&$report, $log): void {
            $report['total']++;
            $report[$result['success'] ? 'processed' : 'skipped']++;
            if ($result['action'] === 'error') {
                $report['errors']++;
                if ($log) $log($result['student_id'] . ': ' . $result['message']);
            }
            if (count($report['results']) < $this->reportLimit) $report['results'][] = $result;
            else $report['results_omitted']++;
        };

        try {
            if ($this->pdo->inTransaction()) throw new LogicException('Monthly fee job must own its transactions.');
            $currentYear = academicRequireCurrentYear($this->pdo);
            if ($currentYear !== $billingDate->format('Y')) {
                throw new RuntimeException('The current academic year must match this billing month before automatic fees can be generated.');
            }
            $source = academicStudentSourceSql($this->pdo, $currentYear);
            // Freeze the upper bound so new admissions cannot extend a running job indefinitely.
            $maxStatement = $this->pdo->prepare('SELECT COALESCE(MAX(id), 0) FROM students');
            $maxStatement->execute();
            $lastId = (int)$maxStatement->fetchColumn();
            $page = $this->pdo->prepare("SELECT s.*, c.class_name FROM {$source} s
                JOIN classes c ON s.class_id = c.id WHERE s.status = 'Active'
                AND s.id > ? AND s.id <= ? ORDER BY s.id ASC LIMIT {$this->batchSize}");
            $lock = $this->pdo->prepare('SELECT student_id FROM students WHERE student_id = ? FOR UPDATE');
            $class = $this->pdo->prepare('SELECT amount FROM class_wise_monthly_fees WHERE class_id = ?');
            $paid = $this->pdo->prepare('SELECT id FROM student_full_paid_fees WHERE student_id = ? AND month_year = ?');
            $unpaid = $this->pdo->prepare('SELECT id FROM student_unpaid_fees WHERE student_id = ? AND month_year = ? LIMIT 1');
            $insert = $this->pdo->prepare('INSERT INTO student_unpaid_fees
                (student_id, month_year, actual_amount, unpaid_amount, discount_amount, remark, created_at)
                VALUES (?, ?, ?, ?, ?, ?, NOW())');
            $ledger = new MonthlyFeeLedger($this->pdo);
            $classFees = [];
            $cursor = 0;
            while ($cursor < $lastId) {
                $page->execute([$cursor, $lastId]);
                $students = $page->fetchAll(PDO::FETCH_ASSOC);
                $page->closeCursor();
                if (!$students) break;
                $committed = [];
                foreach ($students as $student) {
                    $nextId = (int)$student['id'];
                    if ($nextId <= $cursor) throw new LogicException('Monthly fee batch did not advance.');
                    $cursor = $nextId;
                    $result = ['student_id' => $student['student_id'], 'name' => $student['name'],
                        'success' => false, 'action' => 'skipped', 'message' => ''];
                    try {
                        if (!$this->pdo->beginTransaction()) throw new RuntimeException('Cannot start the monthly fee transaction.');
                        $lock->execute([$student['student_id']]);
                        if (!$lock->fetch(PDO::FETCH_ASSOC)) throw new RuntimeException('Student no longer exists.');
                        $lock->closeCursor();
                        $classId = $student['class_id'];
                        if (!array_key_exists($classId, $classFees)) {
                            $class->execute([$classId]);
                            $classFees[$classId] = $class->fetch(PDO::FETCH_ASSOC) ?: null;
                            $class->closeCursor();
                        }
                        $custom = $student['custom_class_fee'] ?? 0;
                        if (!$classFees[$classId] && $custom <= 0) {
                            $result['message'] = 'Class monthly fee not setup.';
                        } else {
                            $gross = MonthlyFeeLedger::amounts([
                                'tuition' => $custom > 0 ? $custom : $classFees[$classId]['amount'],
                                'car' => $student['car_fee'] ?? 0, 'hostel' => $student['hostel_fee'] ?? 0,
                                'coaching' => $student['coaching_fee'] ?? 0, 'tiffin' => $student['tiffin_fee'] ?? 0,
                                'other' => $student['other_fee'] ?? 0]);
                            $discount = MonthlyFeeLedger::cents($student['monthly_discount'] ?? 0);
                            if ($discount < 0) throw new InvalidArgumentException('Monthly discount cannot be negative.');
                            $actual = array_sum(array_map([MonthlyFeeLedger::class, 'cents'], $gross));
                            if ($discount > 0 && $actual <= $discount) {
                                $result['message'] = 'Discount exceeds total fees.';
                            } else {
                                $paid->execute([$student['student_id'], $month]);
                                $fullyPaid = (bool)$paid->fetch();
                                $paid->closeCursor();
                                $alreadyRequested = false;
                                if (!$fullyPaid) {
                                    $unpaid->execute([$student['student_id'], $month]);
                                    $alreadyRequested = (bool)$unpaid->fetch();
                                    $unpaid->closeCursor();
                                }
                                if ($fullyPaid) $result['message'] = 'Already marked as fully paid.';
                                elseif ($alreadyRequested) $result['message'] = 'Unpaid fee record already exists.';
                                else {
                                    $remark = $student['class_name'] . ' monthly fees';
                                    if ($discount > 0) $remark .= ' with ' . $currency . ($student['monthly_discount'] ?? 0) . ' discount applied ';
                                    $includes = [];
                                    if ($custom > 0) $includes[] = 'custom class (' . $currency . $custom . ')';
                                    foreach (['car', 'hostel', 'coaching', 'tiffin', 'other'] as $code) {
                                        if (MonthlyFeeLedger::cents($gross[$code]) > 0) {
                                            $includes[] = $code . ' (' . $currency . $student[$code . '_fee'] . ')';
                                        }
                                    }
                                    if ($includes) $remark .= ' [included ' . implode(' and ', $includes) . ' fees]';
                                    $insert->execute([$student['student_id'], $month, MonthlyFeeLedger::money($actual),
                                        MonthlyFeeLedger::money($actual - $discount), MonthlyFeeLedger::money($discount), $remark]);
                                    $ledger->saveBill($student['student_id'], $month, $gross, MonthlyFeeLedger::money($discount));
                                    if (!$this->pdo->commit()) throw new RuntimeException('Cannot commit the monthly fee transaction.');
                                    $result['success'] = true;
                                    $result['action'] = 'created';
                                    $result['message'] = 'Generated successfully.';
                                    $committed[] = $student['student_id'];
                                }
                            }
                        }
                        if ($this->pdo->inTransaction() && !$this->pdo->rollBack()) {
                            throw new RuntimeException('Cannot roll back the monthly fee transaction.');
                        }
                    } catch (Throwable $error) {
                        // If rollback itself fails, the outer handler stops the job.
                        if ($this->pdo->inTransaction() && !$this->pdo->rollBack()) {
                            throw new RuntimeException('Cannot roll back the monthly fee transaction.', 0, $error);
                        }
                        $result['action'] = 'error';
                        $result['message'] = $error->getMessage();
                    }
                    $record($result);
                }
                // Bound token queries/payloads and send before starting the next page.
                // Failed delivery is retried once and reported without undoing bills.
                if ($committed && $notify) {
                    $delivered = false;
                    for ($attempt = 0; $attempt < 2; $attempt++) {
                        try {
                            $delivery = $notify($committed, $month);
                            if (is_array($delivery) && !empty($delivery['success'])) { $delivered = true; break; }
                            $deliveryError = is_array($delivery) ? ($delivery['message'] ?? 'Notification failed.') : 'Invalid notification response.';
                        } catch (Throwable $error) { $deliveryError = $error->getMessage(); }
                    }
                    if (!$delivered) {
                        $report['notification_batches_failed']++;
                        if ($log) $log('Notification failed: ' . $deliveryError);
                    }
                }
                unset($students, $committed);
            }
        } catch (Throwable $error) {
            $report['fatal_error'] = $error->getMessage();
            if ($log) $log('Job failed: ' . $error->getMessage());
        }
        $report['billing_success'] = $report['errors'] === 0 && !isset($report['fatal_error']);
        $report['success'] = $report['billing_success'] && $report['notification_batches_failed'] === 0;
        return $report;
    }
}
