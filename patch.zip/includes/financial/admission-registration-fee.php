<?php
// No application bootstrap: the registration endpoint owns the transaction.
require_once __DIR__ . '/fun-admission-payments-entry.php';

function admissionRegistrationMoney(mixed $value, string $label): int
{
    if (!is_scalar($value) || !preg_match('/^\d{1,8}(?:\.\d{1,2})?$/D', trim((string)$value))) {
        throw new InvalidArgumentException($label . ' must be a non-negative amount with at most two decimal places (maximum 99999999.99).');
    }
    $parts = explode('.', trim((string)$value));
    return (int)$parts[0] * 100 + (int)str_pad($parts[1] ?? '', 2, '0');
}

function admissionRegistrationAmount(int $cents): string
{
    return intdiv($cents, 100) . '.' . str_pad((string)($cents % 100), 2, '0', STR_PAD_LEFT);
}

function admissionRegistrationFeeInput(array $input): ?array
{
    if (!isset($input['auto_include_admission_fee'])) return null;

    $agreed = $input['admission_fee_amount'] ?? '';
    $paid = $input['admission_fee_paid'] ?? '';
    $agreedCents = $agreed === '' ? null : admissionRegistrationMoney($agreed, 'Agreed admission fee');
    $paidCents = $paid === '' ? 0 : admissionRegistrationMoney($paid, 'Payment at admission');
    if ($agreedCents !== null && $agreedCents <= 0) {
        throw new InvalidArgumentException('Agreed admission fee must be greater than zero.');
    }
    if ($agreedCents !== null && $paidCents > $agreedCents) {
        throw new InvalidArgumentException('Payment at admission cannot exceed the agreed admission fee.');
    }
    return ['agreed_cents' => $agreedCents, 'paid_cents' => $paidCents];
}

function admissionRegistrationFeeQuote(PDO $pdo, int $classId, array $input): array
{
    $stmt = $pdo->prepare('SELECT amount FROM class_wise_new_admission_fees WHERE class_id = ? FOR UPDATE');
    $stmt->execute([$classId]);
    $default = $stmt->fetchColumn();
    if ($default === false || admissionRegistrationMoney($default, 'Default admission fee') <= 0) {
        throw new InvalidArgumentException('Set a positive new admission fee for the selected class in Fee Settings first.');
    }
    $defaultCents = admissionRegistrationMoney($default, 'Default admission fee');
    $agreedCents = $input['agreed_cents'] ?? $defaultCents;
    $paidCents = $input['paid_cents'];
    if ($agreedCents <= 0 || $paidCents < 0 || $paidCents > $agreedCents) {
        throw new InvalidArgumentException('Payment at admission cannot exceed the agreed admission fee.');
    }

    // Keep existing ledger arithmetic (actual - discount) valid for higher deals too.
    return [
        'default_amount' => admissionRegistrationAmount($defaultCents),
        'agreed_amount' => admissionRegistrationAmount($agreedCents),
        'actual_amount' => admissionRegistrationAmount(max($defaultCents, $agreedCents)),
        'discount_amount' => admissionRegistrationAmount(max(0, $defaultCents - $agreedCents)),
        'paid_amount' => admissionRegistrationAmount($paidCents),
        'due_amount' => admissionRegistrationAmount($agreedCents - $paidCents),
    ];
}

function admissionRegistrationFeeCreate(PDO $pdo, string $studentId, string $year, int $classId, array $quote, string $paymentDate, mixed $adminId): void
{
    if (!$pdo->inTransaction()) throw new LogicException('Admission registration fees require an active transaction.');

    $remark = 'Admission fee (New Admission); default fee ' . $quote['default_amount']
        . '; agreed fee ' . $quote['agreed_amount'] . '; discount ' . $quote['discount_amount'];
    if ($quote['agreed_amount'] > $quote['default_amount']) {
        $remark .= '; agreed fee is above the default class fee';
    }
    $stmt = $pdo->prepare('INSERT INTO admission_unpaid_fees
        (student_id, academic_year, class_id, actual_amount, unpaid_amount, discount_amount, remark, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW())');
    $stmt->execute([$studentId, $year, $classId, $quote['actual_amount'], $quote['agreed_amount'], $quote['discount_amount'], $remark]);

    if ((float)$quote['paid_amount'] > 0) {
        // Reuse the standard cash ledger, history and reversal backups.
        $result = processSingleStudentAdmissionPayment($pdo, $studentId, (float)$quote['paid_amount'], $paymentDate, $adminId);
        if (!$result['success'] || (float)($result['wallet_credit'] ?? 0) !== 0.0) {
            throw new RuntimeException('Admission payment could not be recorded: ' . ($result['message'] ?? 'Unexpected excess payment.'));
        }
    }
}
