<?php
require_once __DIR__ . '/monthly-fee-ledger.php';

final class MonthlyFeeCategoryReport
{
    public function __construct(private PDO $pdo) {}

    private function rows(string $sql, array $params): array
    {
        $stmt = $this->pdo->prepare($sql); $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function read(string $month, string $from, string $to, string $student = ''): array
    {
        if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/D', $month)) throw new InvalidArgumentException('Select a valid billing month.');
        foreach ([$from, $to] as $date) {
            $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
            if (!$parsed || $parsed->format('Y-m-d') !== $date) throw new InvalidArgumentException('Select valid collection dates.');
        }
        if ($from > $to) throw new InvalidArgumentException('Start date must be before the end date.');
        $billMonth = DateTimeImmutable::createFromFormat('!Y-m', $month)->format('F Y');
        $billParams = [$month]; $legacyParams = [$billMonth]; $historyParams = [$from, $to];
        $billStudent = $student === '' ? '' : ' AND b.student_id = ?';
        $legacyStudent = $student === '' ? '' : ' AND f.student_id = ?';
        $historyStudent = $student === '' ? '' : ' AND h.student_id = ?';
        $eventStudent = $student === '' ? '' : ' AND a.student_id = ?';
        if ($student !== '') { $billParams[] = $student; $legacyParams[] = $student; $historyParams[] = $student; }
        $categories = [];
        foreach (MonthlyFeeLedger::FEES as $code => $label) $categories[$code] = ['code' => $code, 'label' => $label,
            'billed' => 0, 'discount' => 0, 'paid' => 0, 'due' => 0, 'cash' => 0, 'online' => 0, 'wallet' => 0];

        $summary = $this->rows("SELECT c.fee_code, SUM(c.billed_amount) AS billed,
            SUM(c.discount_amount) AS base_discount, SUM(c.opening_paid_amount) AS opening_paid,
            SUM(COALESCE(e.paid, 0)) AS paid, SUM(COALESCE(e.discount, 0)) AS event_discount
            FROM monthly_fee_bills b JOIN monthly_fee_bill_components c ON c.bill_id = b.id
            LEFT JOIN (SELECT bill_id, fee_code,
                SUM(CASE WHEN allocation_type = 'payment' THEN amount ELSE 0 END) AS paid,
                SUM(CASE WHEN allocation_type = 'discount' THEN amount ELSE 0 END) AS discount
                FROM monthly_fee_payment_allocations GROUP BY bill_id, fee_code) e ON e.bill_id = c.bill_id AND e.fee_code = c.fee_code
            WHERE b.billing_month = ? AND b.status = 'active' $billStudent GROUP BY c.fee_code", $billParams);
        foreach ($summary as $row) {
            $category = &$categories[$row['fee_code']];
            $category['billed'] = MonthlyFeeLedger::cents($row['billed']);
            $category['discount'] = MonthlyFeeLedger::cents($row['base_discount']) + MonthlyFeeLedger::cents($row['event_discount']);
            $category['paid'] = MonthlyFeeLedger::cents($row['opening_paid']) + MonthlyFeeLedger::cents($row['paid']);
            $category['due'] = $category['billed'] - $category['discount'] - $category['paid'];
            unset($category);
        }
        // Untouched historical paid/unpaid tables stay visible without manufacturing category data.
        foreach (['student_unpaid_fees', 'student_full_paid_fees'] as $table) {
            $dueColumn = $table === 'student_unpaid_fees' ? 'f.unpaid_amount' : '0';
            $legacy = $this->rows("SELECT COALESCE(SUM(f.actual_amount), 0) AS billed,
                COALESCE(SUM(f.discount_amount), 0) AS discount, COALESCE(SUM($dueColumn), 0) AS due
                FROM $table f WHERE f.month_year = ? $legacyStudent
                AND NOT EXISTS (SELECT 1 FROM monthly_fee_bills b WHERE b.student_id = f.student_id
                    AND b.month_year = f.month_year AND b.status = 'active')", $legacyParams)[0];
            foreach (['billed', 'discount', 'due'] as $key) $categories['unclassified'][$key] += MonthlyFeeLedger::cents($legacy[$key]);
            $categories['unclassified']['paid'] += MonthlyFeeLedger::cents($legacy['billed'])
                - MonthlyFeeLedger::cents($legacy['discount']) - MonthlyFeeLedger::cents($legacy['due']);
        }

        $eventParams = $historyParams;
        $collections = $this->rows("SELECT a.fee_code, a.method, SUM(a.amount) AS amount
            FROM monthly_fee_payment_allocations a WHERE a.payment_date >= ? AND a.payment_date <= ?
            AND a.allocation_type = 'payment' $eventStudent GROUP BY a.fee_code, a.method", $eventParams);
        foreach ($collections as $row) if (isset($categories[$row['fee_code']][$row['method']])) {
            $categories[$row['fee_code']][$row['method']] += MonthlyFeeLedger::cents($row['amount']);
        }
        $histories = $this->rows("SELECT h.method, h.payment_amount, h.wallet_affected_balance,
            COALESCE(e.allocated, 0) AS allocated FROM student_payment_history h
            LEFT JOIN (SELECT payment_history_id, SUM(amount) AS allocated FROM monthly_fee_payment_allocations
                WHERE allocation_type = 'payment' GROUP BY payment_history_id) e ON e.payment_history_id = h.id
            WHERE h.payment_date >= ? AND h.payment_date <= ? $historyStudent", $historyParams);
        $walletDeposits = 0;
        foreach ($histories as $row) {
            $method = $row['method'] ?: 'cash';
            $walletCredit = $method === 'wallet' ? 0 : MonthlyFeeLedger::cents($row['wallet_affected_balance'] ?? 0);
            $walletDeposits += $walletCredit;
            $unclassified = MonthlyFeeLedger::cents($row['payment_amount']) - $walletCredit - MonthlyFeeLedger::cents($row['allocated']);
            if (isset($categories['unclassified'][$method])) $categories['unclassified'][$method] += $unclassified;
        }

        $bills = $this->rows("SELECT b.*, s.name AS student_name FROM monthly_fee_bills b
            LEFT JOIN students s ON s.student_id = b.student_id WHERE b.billing_month = ?
            AND b.status = 'active' $billStudent ORDER BY b.student_id LIMIT 100", $billParams);
        $ledger = new MonthlyFeeLedger($this->pdo);
        foreach ($bills as &$bill) {
            $bill['components'] = $ledger->balances((int)$bill['id']);
            foreach ($bill['components'] as &$component) foreach ($component as &$amount) $amount = MonthlyFeeLedger::money($amount);
            unset($component, $amount);
        }
        unset($bill);
        $legacyPending = $this->rows("SELECT f.*, s.name AS student_name FROM student_unpaid_fees f
            LEFT JOIN students s ON s.student_id = f.student_id WHERE f.month_year = ? $legacyStudent
            AND NOT EXISTS (SELECT 1 FROM monthly_fee_bills b WHERE b.student_id = f.student_id
                AND b.month_year = f.month_year AND b.status = 'active' AND b.breakdown_state <> 'legacy')
            ORDER BY f.student_id LIMIT 100", $legacyParams);
        foreach ($categories as &$category) foreach ($category as $key => &$amount) {
            if (!in_array($key, ['code', 'label'], true)) $amount = MonthlyFeeLedger::money($amount);
        }
        unset($category, $amount);
        return ['categories' => array_values($categories), 'bills' => $bills, 'legacy_pending' => $legacyPending,
            'wallet_deposits' => MonthlyFeeLedger::money($walletDeposits), 'billing_month' => $month,
            'from' => $from, 'to' => $to];
    }
}
