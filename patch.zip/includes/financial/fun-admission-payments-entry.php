<?php
function processSingleStudentAdmissionPayment($pdo, $student_id, $provided_payment_amount, $payment_date)
{

    global $currency_symbol;

    try {

        if (empty($provided_payment_amount)) {
            return ['success' => false, 'name' => "Unknown ID: $student_id", 'message' => "Payment amount should be greater than 0"];
        }

        $payment_amount = $provided_payment_amount;

        // 1. Fetch student info
        $stmt = $pdo->prepare("SELECT * FROM students WHERE student_id = ?");
        $stmt->execute([$student_id]);
        $student_info = $stmt->fetch(PDO::FETCH_ASSOC);

        // Check: Student Existence and Status
        if (!$student_info || strtolower($student_info['status']) === 'left' || strtolower($student_info['status']) === 'alumni') {
            $name = $student_info ? $student_info['name'] : "Unknown ID: $student_id";
            $reason = !$student_info ? "Student ID not found" : "Status is " . $student_info['status'];
            return ['success' => false, 'name' => $name, 'message' => $reason];
        }

        $student_name = $student_info['name'];
        $payment_history_remarks = [];

        // 2. Fetch Unpaid Fees
        $stmt = $pdo->prepare("SELECT * FROM admission_unpaid_fees WHERE student_id = ? ORDER BY academic_year ASC");
        $stmt->execute([$student_id]);
        $unpaid_fees_data = $stmt->fetchAll();

        if (count($unpaid_fees_data) <= 0) {
            return ['success' => false, 'name' => $student_name, 'message' => "No unpaid admission fees pending"];
        }

        // 3. Process Fees
        $partial_payment_ids_backup = [];
        $full_paid_admission_payment_ids = [];
        $unpaid_admission_fees_rows_backup = [];

        foreach ($unpaid_fees_data as $unpaid_fee_data) {
            $unpaid_admission_fees_rows_backup[] = $unpaid_fee_data;

            $unpaid_fee_id = $unpaid_fee_data['id'];
            $academic_year = $unpaid_fee_data['academic_year'];
            $class_id = $unpaid_fee_data['class_id'];
            $actual_amount = $unpaid_fee_data['actual_amount'];
            $remark = $unpaid_fee_data['remark'];
            $discount_amount = $unpaid_fee_data['discount_amount'];
            $unpaid_amount = $unpaid_fee_data['unpaid_amount'];

            if ($payment_amount <= 0) break;

            if ($payment_amount < $unpaid_amount) {
                // Partial Payment
                $unpaid_amount = $unpaid_amount - $payment_amount;

                $stmt = $pdo->prepare("UPDATE admission_unpaid_fees SET unpaid_amount = ? WHERE id = ?");
                $stmt->execute([$unpaid_amount, $unpaid_fee_id]);

                $partial_remark = $currency_symbol . $payment_amount . "/- has been used for admission fee payment session " . $academic_year . " from payment amount " . $currency_symbol . $provided_payment_amount . "/- (" . $payment_date . ")";
                $payment_history_remarks[] = $currency_symbol . $payment_amount . " used for admission fee payment " . $academic_year . " academic year (Partial)";

                $stmt = $pdo->prepare("INSERT INTO admission_partial_fees_payments (student_id, academic_year, class_id, unpaid_admission_fees_id, partial_paid_amount, method, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$student_id, $academic_year, $class_id, $unpaid_fee_id, $payment_amount, 'cash', $partial_remark, $payment_date]);
                $partial_payment_ids_backup[] = $pdo->lastInsertId();

                $payment_amount = 0;
                break;
            } else {
                // Full Payment for this specific fee row
                $paid_amount = $unpaid_amount;

                $stmt = $pdo->prepare("INSERT INTO admission_full_paid_fees (student_id, academic_year, actual_amount, class_id, discount_amount, total_paid_amount, last_paid_amount, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
                $stmt->execute([$student_id, $academic_year, $actual_amount, $class_id, $discount_amount, ($actual_amount - $discount_amount), $paid_amount, $remark]);
                $full_paid_admission_fees_id = $pdo->lastInsertId();
                $full_paid_admission_payment_ids[] = $full_paid_admission_fees_id;

                $partial_remark = $currency_symbol . $paid_amount . "/- has been used for admission fee payment " . $academic_year . " academic year from payment amount " . $currency_symbol . $provided_payment_amount . "/- (" . $payment_date . ")";
                $payment_history_remarks[] = $currency_symbol . $paid_amount . " used for admission fee payment " . $academic_year . " academic year";

                $stmt = $pdo->prepare("INSERT INTO admission_partial_fees_payments (student_id, academic_year, class_id, unpaid_admission_fees_id, full_paid_admission_fees_id, partial_paid_amount, method, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$student_id, $academic_year, $class_id, $unpaid_fee_id, $full_paid_admission_fees_id, $paid_amount, 'cash', $partial_remark, $payment_date]);
                $partial_payment_ids_backup[] = $pdo->lastInsertId();

                $stmt = $pdo->prepare("UPDATE admission_partial_fees_payments SET full_paid_admission_fees_id = ? WHERE unpaid_admission_fees_id = ?");
                $stmt->execute([$full_paid_admission_fees_id, $unpaid_fee_id]);

                $stmt = $pdo->prepare("DELETE FROM admission_unpaid_fees WHERE id = ?");
                $stmt->execute([$unpaid_fee_id]);

                $payment_amount -= $unpaid_amount;
            }
        }

        // 4. Handle Wallet (Excess Amount)
        $transaction_id = NULL;
        $wallet_credited_amount = 0;

        if ($payment_amount > 0) {
            $stmt = $pdo->prepare("SELECT * FROM student_wallet WHERE student_id = ?");
            $stmt->execute([$student_id]);
            $student_wallet = $stmt->fetch(PDO::FETCH_ASSOC);

            $transaction_type = 'deposit';
            $transaction_id = uniqid('tran');
            $description = 'Credited to wallet (Excess Admission Fee Payment)';

            try {
                $pdo->beginTransaction();
                if (!$student_wallet) {
                    $stmt = $pdo->prepare("INSERT INTO student_wallet(student_id, balance) VALUES (?, ?)");
                    $stmt->execute([$student_id, $payment_amount]);
                    $wallet_id = $pdo->lastInsertId();
                } else {
                    $wallet_id = $student_wallet['id'];
                    $new_balance = $student_wallet['balance'] + $payment_amount;
                    $stmt = $pdo->prepare("UPDATE student_wallet SET balance = ? WHERE id = ?");
                    $stmt->execute([$new_balance, $wallet_id]);
                }

                $stmt = $pdo->prepare("INSERT INTO wallet_transactions (wallet_id, student_id, amount, transaction_type, transaction_id, description) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$wallet_id, $student_id, $payment_amount, $transaction_type, $transaction_id, $description]);
                $pdo->commit();

                $wallet_credited_amount = $payment_amount;
                $payment_history_remarks[] = $currency_symbol . $payment_amount . " credited to wallet";
            } catch (Exception $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                // Log error but don't fail the whole payment record if wallet fails, or handle as needed
                error_log("Wallet Error: " . $e->getMessage());
            }
        }

        // 5. Insert Payment History
        $payment_history_remark = implode(' & ', $payment_history_remarks);
        $stmt = $pdo->prepare("
            INSERT INTO admission_fees_payment_history
            (student_id, payment_amount, payment_date, remark, full_paid_admission_payment_ids, partial_payment_ids_backup, wallet_affected_balance, wallet_transaction_id, unpaid_admission_fees_rows_backup) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $student_id,
            $provided_payment_amount,
            $payment_date,
            $payment_history_remark,
            json_encode($full_paid_admission_payment_ids),
            json_encode($partial_payment_ids_backup),
            $wallet_credited_amount,
            $transaction_id,
            json_encode($unpaid_admission_fees_rows_backup)
        ]);

        return [
            'success' => true,
            'name' => $student_name,
            'wallet_credit' => $wallet_credited_amount,
            'message' => 'Processed successfully'
        ];
    } catch (Exception $e) {
        return ['success' => false, 'name' => "ID: $student_id", 'message' => $e->getMessage()];
    }
}
