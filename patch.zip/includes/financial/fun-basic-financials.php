<?php
  //-----------------------------------------------------------//
 //                  Admission Fees Functions                 //
//-----------------------------------------------------------//

function getLastAdmissionPayment(PDO $pdo, $student_id)
{
    $stmt = $pdo->prepare("SELECT payment_amount, payment_date, remark, method 
                            FROM admission_fees_payment_history 
                            WHERE student_id = ? 
                            ORDER BY updated_at DESC 
                            LIMIT 1");

    $stmt->execute([$student_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function getUnpaidAdmissionFeesData(PDO $pdo, $student_id)
{
    $stmt = $pdo->prepare("SELECT auf.academic_year, auf.actual_amount, auf.unpaid_amount, auf.discount_amount, c.class_name
                            FROM admission_unpaid_fees AS auf
                            LEFT JOIN classes c ON auf.class_id = c.id
                            WHERE student_id = ? AND auf.unpaid_amount > 0
                            ORDER BY auf.academic_year ASC");

    $stmt->execute([$student_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getPaidAdmissionFeesData(PDO $pdo, $student_id)
{
    $stmt = $pdo->prepare("SELECT ap.academic_year, ap.actual_amount, ap.discount_amount, ap.total_paid_amount, ap.updated_at, c.class_name
                            FROM admission_full_paid_fees AS ap
                            LEFT JOIN classes c ON ap.class_id = c.id
                            WHERE student_id = ? 
                            ORDER BY ap.academic_year ASC");

    $stmt->execute([$student_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}



  //-----------------------------------------------------------//
 //                    Monthly Fees Functions                 //
//-----------------------------------------------------------//

function getLastMonthlyPayment(PDO $pdo, $student_id)
{
    $stmt = $pdo->prepare("SELECT payment_amount, payment_date, remark, method 
                            FROM student_payment_history 
                            WHERE student_id = ? 
                            ORDER BY updated_at DESC 
                            LIMIT 1");

    $stmt->execute([$student_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function getUnpaidMonthlyFeesData(PDO $pdo, $student_id)
{
    $stmt = $pdo->prepare("SELECT * FROM student_unpaid_fees WHERE student_id = ? ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC");
    $stmt->execute([$student_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getPaidMonthlyFeesData(PDO $pdo, $student_id)
{
    $stmt = $pdo->prepare("SELECT * FROM student_full_paid_fees WHERE student_id = ? ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC");
    $stmt->execute([$student_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}