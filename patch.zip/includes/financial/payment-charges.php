<?php
// Shared by native fee payments and online Store checkout. Amounts are in paise.
function schoolPaymentCharges(int $basePaise, $percentage, $gstPercentage): array {
    if ($basePaise <= 0) throw new InvalidArgumentException('Payment amount must be greater than zero.');
    foreach ([$percentage, $gstPercentage] as $value) {
        if (!is_numeric($value) || !is_finite((float)$value) || (float)$value < 0 || (float)$value > 10000000) {
            throw new InvalidArgumentException('Invalid payment charge configuration.');
        }
    }
    $rawCharge = $basePaise * (float)$percentage / 100;
    $rawGst = $rawCharge * (float)$gstPercentage / 100;
    if (!is_finite($basePaise + $rawCharge + $rawGst) || $basePaise + $rawCharge + $rawGst >= PHP_INT_MAX) {
        throw new InvalidArgumentException('Payment amount is outside the supported range.');
    }
    $charge = (int)round($rawCharge);
    $total = (int)round($basePaise + $rawCharge + $rawGst);
    return ['gateway_charge_paise' => $charge, 'gst_paise' => $total - $basePaise - $charge,
        'total_paise' => $total, 'gateway_percentage' => (float)$percentage, 'gst_percentage' => (float)$gstPercentage];
}
