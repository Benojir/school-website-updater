<?php
require_once __DIR__ . "/../academic/academic-context.php";
require_once __DIR__ . '/monthly-fee-ledger.php';
function processSingleStudentPayment(PDO $pdo, string $student_id, float $amount, string $payment_date, $admin_id = null, float $discount = 0)
{
    global $currency_symbol;

    // Initialize return data
    $result = [
        'success' => false,
        'message' => '',
        'auto_generated_months' => [],
        'wallet_credited' => 0,
        'discount_applied' => 0
    ];

    if (!is_finite($amount) || !is_finite($discount) || $amount < 0 || $discount < 0) {
        $result['message'] = 'Payment amount and discount cannot be negative.';
        return $result;
    }

    // A row the admin left untouched (no money, no discount) has nothing to record
    if ($amount <= 0 && $discount <= 0) {
        $result['message'] = 'Payment amount must be greater than 0.';
        return $result;
    }

    $transaction_started = false;
    $amount = round($amount, 2);
    $discount = round($discount, 2);
    try {
        // Each student in a bulk collection commits independently, after every ledger write.
        $pdo->beginTransaction();
        $transaction_started = true;
        $monthlyLedger = new MonthlyFeeLedger($pdo);
        $monthlySnapshots = [];
        $allocationIds = [];

        // 1. Fetch student info
        $stmt = $pdo->prepare("SELECT * FROM students WHERE student_id = ? FOR UPDATE");
        $stmt->execute([$student_id]);
        $student_info = $stmt->fetch(PDO::FETCH_ASSOC);

        // Check if student exists or is active
        if (!$student_info) {
            throw new InvalidArgumentException('Student not found.');
        }

        $original_payment_amount = (float) $amount;
        $current_payment_amount = (float) $amount; // This variable will decrease as fees are paid

        $payment_history_remarks = [];
        $partial_payment_ids_backup = [];
        $full_paid_payment_ids = [];
        $unpaid_fee_rows_backup = [];
        $auto_generated_months = [];
        $wallet_deposit_amount = 0;
        $transaction_id = NULL;
        $discount_granted_month = null;

        // ---------------------------------------------------------
        // PART 1: CLEAR EXISTING UNPAID FEES
        // ---------------------------------------------------------

        $stmt = $pdo->prepare("SELECT * FROM student_unpaid_fees WHERE student_id = ? ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC FOR UPDATE");
        $stmt->execute([$student_id]);
        $unpaid_fees_data = $stmt->fetchAll();

        // A collection-time discount is only ever granted on the OLDEST pending month, and it must
        // stay strictly below that month's remaining due. Two reasons for that rule:
        //   1. Money already collected for the month cannot be discounted retroactively, so the
        //      remaining due is the natural ceiling.
        //   2. Keeping it strictly below the due means the month always retains a balance, so a
        //      discount alone can never settle a month. That matches the rule already applied when
        //      requesting fees, and keeps the unpaid/paid ledgers consistent.
        // The UI blocks this before submit - the checks below are the server-side safety net.
        if ($discount > 0) {
            $oldest_pending_due = isset($unpaid_fees_data[0]) ? (float) $unpaid_fees_data[0]['unpaid_amount'] : 0;

            if ($oldest_pending_due <= 0) {
                throw new InvalidArgumentException('No pending due found for this student, so no discount can be applied.');
            }

            if ($discount >= $oldest_pending_due) {
                throw new InvalidArgumentException('Discount (' . $currency_symbol . $discount . ') cannot be equal to or greater than the pending due of '
                    . $unpaid_fees_data[0]['month_year'] . ' (' . $currency_symbol . $oldest_pending_due . ').');
            }
        }

        $discount_pending = $discount; // consumed by the oldest pending month on the first pass below

        foreach ($unpaid_fees_data as $unpaid_fee_data) {
            if ($current_payment_amount <= 0 && $discount_pending <= 0) break;
            $categoryBill = $monthlyLedger->ensure($unpaid_fee_data);
            $monthlySnapshots[] = ['month_year' => $unpaid_fee_data['month_year'], 'snapshot' => $monthlyLedger->snapshot($categoryBill)];
            $unpaid_fee_rows_backup[] = $unpaid_fee_data; // Backup existing state (pre-discount, so deleting the payment restores it)

            $unpaid_fee_id = $unpaid_fee_data['id'];
            $month_year = $unpaid_fee_data['month_year'];
            $actual_amount = $unpaid_fee_data['actual_amount'];
            $remark = $unpaid_fee_data['remark'];
            $discount_amount = $unpaid_fee_data['discount_amount'];
            $unpaid_amount = $unpaid_fee_data['unpaid_amount'];

            // Grant the discount before any money is applied. This runs on the first iteration only
            // (the oldest month), and was validated above to be strictly less than $unpaid_amount -
            // so the month keeps a positive balance for the payment waterfall below to work against.
            if ($discount_pending > 0) {
                $allocationIds = array_merge($allocationIds, $monthlyLedger->allocate($categoryBill, $discount_pending, 'discount', $payment_date, 'cash'));
                $discount_amount = $discount_amount + $discount_pending;
                $unpaid_amount = $unpaid_amount - $discount_pending;

                $stmt = $pdo->prepare("UPDATE student_unpaid_fees SET discount_amount = ?, unpaid_amount = ? WHERE id = ?");
                $stmt->execute([$discount_amount, $unpaid_amount, $unpaid_fee_id]);

                $discount_granted_month = $month_year;
                $result['discount_applied'] = $discount_pending;
                $payment_history_remarks[] = $currency_symbol . $discount_pending . " discount given on " . $month_year;
                $discount_pending = 0;
            }

            if ($current_payment_amount <= 0) break;
            $allocationIds = array_merge($allocationIds, $monthlyLedger->allocate($categoryBill,
                min($current_payment_amount, $unpaid_amount), 'payment', $payment_date, 'cash'));

            if ($current_payment_amount < $unpaid_amount) {
                // --- Partial Payment ---
                $new_unpaid_amount = $unpaid_amount - $current_payment_amount;

                $stmt = $pdo->prepare("UPDATE student_unpaid_fees SET unpaid_amount = ? WHERE id = ?");
                $stmt->execute([$new_unpaid_amount, $unpaid_fee_id]);

                $partial_remark = $currency_symbol . $current_payment_amount . "/- has been used for fee payment " . $month_year . " from payment amount " . $currency_symbol . $original_payment_amount . "/- (" . $payment_date . ")";
                $payment_history_remarks[] = $currency_symbol . $current_payment_amount . " used for payment " . $month_year;

                $stmt = $pdo->prepare("INSERT INTO student_partial_payments (student_id, month_year, unpaid_fees_id, partial_paid_amount, method, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$student_id, $month_year, $unpaid_fee_id, $current_payment_amount, 'cash', $partial_remark, $payment_date]);

                $partial_payment_ids_backup[] = $pdo->lastInsertId();
                $current_payment_amount = 0;
                break;
            } else {
                // --- Full Payment ---
                $paid_amount_this_row = $unpaid_amount;

                $stmt = $pdo->prepare("INSERT INTO student_full_paid_fees (student_id, month_year, actual_amount, discount_amount, total_paid_amount, last_paid_amount, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$student_id, $month_year, $actual_amount, $discount_amount, ($actual_amount - $discount_amount), $paid_amount_this_row, $remark, $payment_date]);
                $full_paid_fees_id = $pdo->lastInsertId();
                $full_paid_payment_ids[] = $full_paid_fees_id;

                $partial_remark = $currency_symbol . $paid_amount_this_row . "/- has been used for fee payment " . $month_year . " from payment amount " . $currency_symbol . $original_payment_amount . "/- (" . $payment_date . ")";
                $payment_history_remarks[] = $currency_symbol . $paid_amount_this_row . " used for payment " . $month_year;

                $stmt = $pdo->prepare("INSERT INTO student_partial_payments (student_id, month_year, unpaid_fees_id, full_paid_fees_id, partial_paid_amount, method, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$student_id, $month_year, $unpaid_fee_id, $full_paid_fees_id, $paid_amount_this_row, 'cash', $partial_remark, $payment_date]);

                $partial_payment_ids_backup[] = $pdo->lastInsertId();

                $stmt = $pdo->prepare("UPDATE student_partial_payments SET full_paid_fees_id = ? WHERE unpaid_fees_id = ?");
                $stmt->execute([$full_paid_fees_id, $unpaid_fee_id]);

                $stmt = $pdo->prepare("DELETE FROM student_unpaid_fees WHERE id = ?");
                $stmt->execute([$unpaid_fee_id]);

                $current_payment_amount -= $unpaid_amount;
            }
        }

        // ---------------------------------------------------------
        // PART 2: ADVANCE PAYMENT (AUTO-ENTRY)
        // ---------------------------------------------------------

        $currentAcademicYear = academicCurrentYear($pdo);
        $currentEnrollment = $currentAcademicYear ? academicGetStudent($pdo, $student_id, $currentAcademicYear) : null;
        if ($current_payment_amount > 0 && academicCanGenerateAutomaticFee($currentAcademicYear, date('Y'), $currentEnrollment)) {
            $student_info = $currentEnrollment;
            $car_fee = $student_info['car_fee'] ?? 0;
            $hostel_fee = $student_info['hostel_fee'] ?? 0;
            $coaching_fee = $student_info['coaching_fee'] ?? 0;
            $tiffin_fee = $student_info['tiffin_fee'] ?? 0;
            $other_fee = $student_info['other_fee'] ?? 0;
            $custom_class_fee = $student_info['custom_class_fee'] ?? 0;
            $class_id = $student_info['class_id'];

            $stmt = $pdo->prepare("SELECT amount FROM class_wise_monthly_fees WHERE class_id = ?");
            $stmt->execute([$class_id]);
            $class_fee_row = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($class_fee_row) {
                $class_fee = $custom_class_fee > 0 ? $custom_class_fee : $class_fee_row['amount'];

                $gen_remark = "Monthly fee";
                $includes = [];
                if ($custom_class_fee > 0) $includes[] = 'custom class fee';
                if ($car_fee > 0) $includes[] = 'car';
                if ($hostel_fee > 0) $includes[] = 'hostel';
                if ($coaching_fee > 0) $includes[] = 'coaching'; // Added Coaching Fee
                if ($tiffin_fee > 0) $includes[] = 'tiffin';
                if ($other_fee > 0) $includes[] = 'other';
                if ($includes) $gen_remark .= ' (included ' . implode(' and ', $includes) . ' fees)';
                $gen_remark .= " [Auto-generated]";

                $monthly_total_fee = ($class_fee + $car_fee + $hostel_fee + $coaching_fee + $tiffin_fee + $other_fee);

                // Find Last Recorded Month
                $last_month_timestamp = 0;
                $stmt = $pdo->prepare("SELECT month_year FROM student_unpaid_fees WHERE student_id = ?");
                $stmt->execute([$student_id]);
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $ts = strtotime($row['month_year']);
                    if ($ts > $last_month_timestamp) $last_month_timestamp = $ts;
                }
                $stmt = $pdo->prepare("SELECT month_year FROM student_full_paid_fees WHERE student_id = ?");
                $stmt->execute([$student_id]);
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $ts = strtotime($row['month_year']);
                    if ($ts > $last_month_timestamp) $last_month_timestamp = $ts;
                }

                if ($last_month_timestamp == 0) {
                    $current_cursor_date = strtotime(date('F Y'));
                } else {
                    $current_cursor_date = strtotime('+1 month', $last_month_timestamp);
                }

                // Keep the existing rate for every advance month, including January and beyond.
                // The $monthly_total_fee guard prevents an endless loop when a class has no fee configured
                while ($current_payment_amount > 0 && $monthly_total_fee > 0) {
                    $target_month_year = date('F Y', $current_cursor_date);
                    $categoryBill = $monthlyLedger->saveBill($student_id, $target_month_year, [
                        'tuition' => $class_fee, 'car' => $car_fee, 'hostel' => $hostel_fee,
                        'coaching' => $coaching_fee, 'tiffin' => $tiffin_fee, 'other' => $other_fee], 0);
                    $monthlySnapshots[] = ['month_year' => $target_month_year, 'snapshot' => null];
                    $allocationIds = array_merge($allocationIds, $monthlyLedger->allocate($categoryBill,
                        min($current_payment_amount, $monthly_total_fee), 'payment', $payment_date, 'cash'));
                    // Store generated month for return message
                    $auto_generated_months[] = $target_month_year;

                    // Virtual backup for reversal
                    $unpaid_fee_rows_backup[] = [
                        'student_id' => $student_id,
                        'month_year' => $target_month_year,
                        'actual_amount' => $monthly_total_fee,
                        'unpaid_amount' => $monthly_total_fee,
                        'discount_amount' => 0,
                        'remark' => $gen_remark
                    ];

                    if ($current_payment_amount >= $monthly_total_fee) {
                        // Full Payment Advance
                        $stmt = $pdo->prepare("INSERT INTO student_full_paid_fees (student_id, month_year, actual_amount, discount_amount, total_paid_amount, last_paid_amount, remark, created_at) VALUES (?, ?, ?, 0, ?, ?, ?, ?)");
                        $stmt->execute([$student_id, $target_month_year, $monthly_total_fee, $monthly_total_fee, $monthly_total_fee, $gen_remark, $payment_date]);
                        $new_full_id = $pdo->lastInsertId();
                        $full_paid_payment_ids[] = $new_full_id;

                        $partial_remark = $currency_symbol . $monthly_total_fee . " (Advance) for " . $target_month_year;
                        $payment_history_remarks[] = $partial_remark;

                        $stmt = $pdo->prepare("INSERT INTO student_partial_payments (student_id, month_year, full_paid_fees_id, partial_paid_amount, method, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$student_id, $target_month_year, $new_full_id, $monthly_total_fee, 'cash', $partial_remark, $payment_date]);
                        $partial_payment_ids_backup[] = $pdo->lastInsertId();

                        $current_payment_amount -= $monthly_total_fee;
                    } else {
                        // Partial Payment Advance
                        $unpaid_balance = $monthly_total_fee - $current_payment_amount;
                        $stmt = $pdo->prepare("INSERT INTO student_unpaid_fees (student_id, month_year, actual_amount, unpaid_amount, discount_amount, remark, created_at) VALUES (?, ?, ?, ?, 0, ?, NOW())");
                        $stmt->execute([$student_id, $target_month_year, $monthly_total_fee, $unpaid_balance, $gen_remark]);
                        $new_unpaid_id = $pdo->lastInsertId();

                        $partial_remark = $currency_symbol . $current_payment_amount . " (Advance Partial) for " . $target_month_year;
                        $payment_history_remarks[] = $partial_remark;

                        $stmt = $pdo->prepare("INSERT INTO student_partial_payments (student_id, month_year, unpaid_fees_id, partial_paid_amount, method, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$student_id, $target_month_year, $new_unpaid_id, $current_payment_amount, 'cash', $partial_remark, $payment_date]);
                        $partial_payment_ids_backup[] = $pdo->lastInsertId();

                        $current_payment_amount = 0;
                    }
                    $current_cursor_date = strtotime('+1 month', $current_cursor_date);
                }
            }
        }

        // ---------------------------------------------------------
        // PART 3: WALLET DEPOSIT
        // ---------------------------------------------------------

        if ($current_payment_amount > 0) {
            $wallet_deposit_amount = $current_payment_amount;

            $stmt = $pdo->prepare("SELECT * FROM student_wallet WHERE student_id = ? FOR UPDATE");
            $stmt->execute([$student_id]);
            $student_wallet = $stmt->fetch(PDO::FETCH_ASSOC);

            $wallet_id = null;
            $transaction_id = uniqid('tran'); // Unique ID for wallet transaction

            if (!$student_wallet) {
                $stmt = $pdo->prepare("INSERT INTO student_wallet(student_id, balance) VALUES (?, ?)");
                $stmt->execute([$student_id, $wallet_deposit_amount]);
                $wallet_id = $pdo->lastInsertId();
            } else {
                $wallet_id = $student_wallet['id'];
                $new_balance = $student_wallet['balance'] + $wallet_deposit_amount;
                $stmt = $pdo->prepare("UPDATE student_wallet SET balance = ? WHERE id = ?");
                $stmt->execute([$new_balance, $wallet_id]);
            }

            $stmt = $pdo->prepare("INSERT INTO wallet_transactions (wallet_id, student_id, amount, transaction_type, transaction_id, description, created_at) VALUES (?, ?, ?, 'deposit', ?, 'Credited to wallet (Excess Payment / Next Academic Year)', ?)");
            $stmt->execute([$wallet_id, $student_id, $wallet_deposit_amount, $transaction_id, $payment_date]);

            $payment_history_remarks[] = $currency_symbol . $wallet_deposit_amount . " credited to wallet";
        }

        // ---------------------------------------------------------
        // FINAL: LOG HISTORY
        // ---------------------------------------------------------

        $payment_history_remark = implode(' & ', $payment_history_remarks);

        $stmt = $pdo->prepare("
            INSERT INTO student_payment_history
            (student_id, payment_amount, payment_date, remark, full_paid_payment_ids, partial_payment_ids_backup, wallet_affected_balance, wallet_transaction_id, unpaid_fee_rows_backup, entry_by, monthly_bill_snapshots)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $student_id,
            $original_payment_amount,
            $payment_date,
            $payment_history_remark,
            json_encode($full_paid_payment_ids),
            json_encode($partial_payment_ids_backup),
            $wallet_deposit_amount,
            $transaction_id,
            json_encode($unpaid_fee_rows_backup),
            $admin_id,
            json_encode($monthlySnapshots, JSON_THROW_ON_ERROR)
        ]);

        $payment_history_id = $pdo->lastInsertId();
        $monthlyLedger->link($allocationIds, (int)$payment_history_id);

        // ---------------------------------------------------------
        // CONSTRUCT MESSAGE
        // ---------------------------------------------------------

        $msg = "Payment updated successfully";

        if ($discount > 0 && $discount_granted_month) {
            $msg .= " with " . $currency_symbol . $discount . " discount on " . $discount_granted_month;
        }

        if ($wallet_deposit_amount > 0) {
            $msg .= " and " . $currency_symbol . $wallet_deposit_amount . " credited to the student wallet";
        }

        if (!empty($auto_generated_months)) {
            $msg .= " and these Months fees record generated automatically for advanced payment (" . implode(', ', $auto_generated_months) . ")";
        }

        $pdo->commit();

        $result['payment_history_id'] = $payment_history_id;
        $result['success'] = true;
        $result['message'] = $msg;
        $result['auto_generated_months'] = $auto_generated_months;
        $result['wallet_credited'] = $wallet_deposit_amount;
    } catch (Throwable $e) {
        if ($transaction_started && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $result['success'] = false;
        $result['message'] = $e->getMessage();
        $result['discount_applied'] = 0;
    }

    return $result;
}
