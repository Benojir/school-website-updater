<?php
function processSingleStudentPayment(PDO $pdo, string $student_id, float $amount, string $payment_date, $admin_id = null)
{
    global $currency_symbol;

    // Initialize return data
    $result = [
        'success' => false,
        'message' => '',
        'auto_generated_months' => [],
        'wallet_credited' => 0
    ];

    if ($amount <= 0) {
        $result['message'] = 'Payment amount must be greater than 0.';
        return $result;
    }

    try {
        // 1. Fetch student info
        $stmt = $pdo->prepare("SELECT * FROM students WHERE student_id = ?");
        $stmt->execute([$student_id]);
        $student_info = $stmt->fetch(PDO::FETCH_ASSOC);

        // Check if student exists or is active
        if (!$student_info || strtolower($student_info['status']) === 'left' || strtolower($student_info['status']) === 'alumni') {
            $result['message'] = 'Student not found or status is Left/Alumni.';
            return $result;
        }

        $original_payment_amount = (float) $amount;
        $current_payment_amount = (float) $amount; // This variable will decrease as fees are paid

        $payment_history_remarks = [];
        $partial_payment_ids_backup = [];
        $full_paid_payment_ids = [];
        $unpaid_fee_rows_backup = [];
        $auto_generated_months = [];
        $wallet_deposit_amount = 0;
        $transaction_id = NULL;

        // ---------------------------------------------------------
        // PART 1: CLEAR EXISTING UNPAID FEES
        // ---------------------------------------------------------

        $stmt = $pdo->prepare("SELECT * FROM student_unpaid_fees WHERE student_id = ? ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC");
        $stmt->execute([$student_id]);
        $unpaid_fees_data = $stmt->fetchAll();

        foreach ($unpaid_fees_data as $unpaid_fee_data) {
            $unpaid_fee_rows_backup[] = $unpaid_fee_data; // Backup existing state

            $unpaid_fee_id = $unpaid_fee_data['id'];
            $month_year = $unpaid_fee_data['month_year'];
            $actual_amount = $unpaid_fee_data['actual_amount'];
            $remark = $unpaid_fee_data['remark'];
            $discount_amount = $unpaid_fee_data['discount_amount'];
            $unpaid_amount = $unpaid_fee_data['unpaid_amount'];

            if ($current_payment_amount <= 0) break;

            if ($current_payment_amount < $unpaid_amount) {
                // --- Partial Payment ---
                $new_unpaid_amount = $unpaid_amount - $current_payment_amount;

                $stmt = $pdo->prepare("UPDATE student_unpaid_fees SET unpaid_amount = ? WHERE id = ?");
                $stmt->execute([$new_unpaid_amount, $unpaid_fee_id]);

                $partial_remark = $currency_symbol . $current_payment_amount . "/- has been used for fee payment " . $month_year . " from payment amount " . $currency_symbol . $original_payment_amount . "/- (" . $payment_date . ")";
                $payment_history_remarks[] = $currency_symbol . $current_payment_amount . " used for payment " . $month_year;

                $stmt = $pdo->prepare("INSERT INTO student_partial_payments (student_id, month_year, unpaid_fees_id, partial_paid_amount, method, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$student_id, $month_year, $unpaid_fee_id, $current_payment_amount, 'cash', $partial_remark, $payment_date]);

                $partial_payment_ids_backup[] = $pdo->lastInsertId();
                $current_payment_amount = 0;
                break;
            } else {
                // --- Full Payment ---
                $paid_amount_this_row = $unpaid_amount;

                $stmt = $pdo->prepare("INSERT INTO student_full_paid_fees (student_id, month_year, actual_amount, discount_amount, total_paid_amount, last_paid_amount, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$student_id, $month_year, $actual_amount, $discount_amount, ($actual_amount - $discount_amount), $paid_amount_this_row, $remark, $payment_date]);
                $full_paid_fees_id = $pdo->lastInsertId();
                $full_paid_payment_ids[] = $full_paid_fees_id;

                $partial_remark = $currency_symbol . $paid_amount_this_row . "/- has been used for fee payment " . $month_year . " from payment amount " . $currency_symbol . $original_payment_amount . "/- (" . $payment_date . ")";
                $payment_history_remarks[] = $currency_symbol . $paid_amount_this_row . " used for payment " . $month_year;

                $stmt = $pdo->prepare("INSERT INTO student_partial_payments (student_id, month_year, unpaid_fees_id, full_paid_fees_id, partial_paid_amount, method, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$student_id, $month_year, $unpaid_fee_id, $full_paid_fees_id, $paid_amount_this_row, 'cash', $partial_remark, $payment_date]);

                $partial_payment_ids_backup[] = $pdo->lastInsertId();

                $stmt = $pdo->prepare("UPDATE student_partial_payments SET full_paid_fees_id = ? WHERE unpaid_fees_id = ?");
                $stmt->execute([$full_paid_fees_id, $unpaid_fee_id]);

                $stmt = $pdo->prepare("DELETE FROM student_unpaid_fees WHERE id = ?");
                $stmt->execute([$unpaid_fee_id]);

                $current_payment_amount -= $unpaid_amount;
            }
        }

        // ---------------------------------------------------------
        // PART 2: ADVANCE PAYMENT (AUTO-ENTRY)
        // ---------------------------------------------------------

        if ($current_payment_amount > 0) {
            $car_fee = $student_info['car_fee'] ?? 0;
            $hostel_fee = $student_info['hostel_fee'] ?? 0;
            $coaching_fee = $student_info['coaching_fee'] ?? 0;
            $tiffin_fee = $student_info['tiffin_fee'] ?? 0;
            $custom_class_fee = $student_info['custom_class_fee'] ?? 0;
            $class_id = $student_info['class_id'];

            $stmt = $pdo->prepare("SELECT amount FROM class_wise_monthly_fees WHERE class_id = ?");
            $stmt->execute([$class_id]);
            $class_fee_row = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($class_fee_row) {
                $class_fee = $custom_class_fee > 0 ? $custom_class_fee : $class_fee_row['amount'];

                $gen_remark = "Monthly fee";
                $includes = [];
                if ($custom_class_fee > 0) $includes[] = 'custom class fee';
                if ($car_fee > 0) $includes[] = 'car';
                if ($hostel_fee > 0) $includes[] = 'hostel';
                if ($coaching_fee > 0) $includes[] = 'coaching'; // Added Coaching Fee
                if ($tiffin_fee > 0) $includes[] = 'tiffin';
                if ($includes) $gen_remark .= ' (included ' . implode(' and ', $includes) . ' fees)';
                $gen_remark .= " [Auto-generated]";

                $monthly_total_fee = ($class_fee + $car_fee + $hostel_fee + $coaching_fee + $tiffin_fee);

                // Find Last Recorded Month
                $last_month_timestamp = 0;
                $stmt = $pdo->prepare("SELECT month_year FROM student_unpaid_fees WHERE student_id = ?");
                $stmt->execute([$student_id]);
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $ts = strtotime($row['month_year']);
                    if ($ts > $last_month_timestamp) $last_month_timestamp = $ts;
                }
                $stmt = $pdo->prepare("SELECT month_year FROM student_full_paid_fees WHERE student_id = ?");
                $stmt->execute([$student_id]);
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $ts = strtotime($row['month_year']);
                    if ($ts > $last_month_timestamp) $last_month_timestamp = $ts;
                }

                if ($last_month_timestamp == 0) {
                    $current_cursor_date = strtotime(date('F Y'));
                } else {
                    $current_cursor_date = strtotime('+1 month', $last_month_timestamp);
                }

                while ($current_payment_amount > 0) {
                    $target_month_year = date('F Y', $current_cursor_date);
                    $target_month_name = date('F', $current_cursor_date);

                    if ($target_month_name === 'January') break; // End of Academic Year Check

                    // Store generated month for return message
                    $auto_generated_months[] = $target_month_year;

                    // Virtual backup for reversal
                    $unpaid_fee_rows_backup[] = [
                        'student_id' => $student_id,
                        'month_year' => $target_month_year,
                        'actual_amount' => $monthly_total_fee,
                        'unpaid_amount' => $monthly_total_fee,
                        'discount_amount' => 0,
                        'remark' => $gen_remark
                    ];

                    if ($current_payment_amount >= $monthly_total_fee) {
                        // Full Payment Advance
                        $stmt = $pdo->prepare("INSERT INTO student_full_paid_fees (student_id, month_year, actual_amount, discount_amount, total_paid_amount, last_paid_amount, remark, created_at) VALUES (?, ?, ?, 0, ?, ?, ?, ?)");
                        $stmt->execute([$student_id, $target_month_year, $monthly_total_fee, $monthly_total_fee, $monthly_total_fee, $gen_remark, $payment_date]);
                        $new_full_id = $pdo->lastInsertId();
                        $full_paid_payment_ids[] = $new_full_id;

                        $partial_remark = $currency_symbol . $monthly_total_fee . " (Advance) for " . $target_month_year;
                        $payment_history_remarks[] = $partial_remark;

                        $stmt = $pdo->prepare("INSERT INTO student_partial_payments (student_id, month_year, full_paid_fees_id, partial_paid_amount, method, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$student_id, $target_month_year, $new_full_id, $monthly_total_fee, 'cash', $partial_remark, $payment_date]);
                        $partial_payment_ids_backup[] = $pdo->lastInsertId();

                        $current_payment_amount -= $monthly_total_fee;
                    } else {
                        // Partial Payment Advance
                        $unpaid_balance = $monthly_total_fee - $current_payment_amount;
                        $stmt = $pdo->prepare("INSERT INTO student_unpaid_fees (student_id, month_year, actual_amount, unpaid_amount, discount_amount, remark, created_at) VALUES (?, ?, ?, ?, 0, ?, NOW())");
                        $stmt->execute([$student_id, $target_month_year, $monthly_total_fee, $unpaid_balance, $gen_remark]);
                        $new_unpaid_id = $pdo->lastInsertId();

                        $partial_remark = $currency_symbol . $current_payment_amount . " (Advance Partial) for " . $target_month_year;
                        $payment_history_remarks[] = $partial_remark;

                        $stmt = $pdo->prepare("INSERT INTO student_partial_payments (student_id, month_year, unpaid_fees_id, partial_paid_amount, method, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$student_id, $target_month_year, $new_unpaid_id, $current_payment_amount, 'cash', $partial_remark, $payment_date]);
                        $partial_payment_ids_backup[] = $pdo->lastInsertId();

                        $current_payment_amount = 0;
                    }
                    $current_cursor_date = strtotime('+1 month', $current_cursor_date);
                }
            }
        }

        // ---------------------------------------------------------
        // PART 3: WALLET DEPOSIT
        // ---------------------------------------------------------

        if ($current_payment_amount > 0) {
            $wallet_deposit_amount = $current_payment_amount;

            $stmt = $pdo->prepare("SELECT * FROM student_wallet WHERE student_id = ?");
            $stmt->execute([$student_id]);
            $student_wallet = $stmt->fetch(PDO::FETCH_ASSOC);

            $wallet_id = null;
            $transaction_id = uniqid('tran'); // Unique ID for wallet transaction

            if (!$student_wallet) {
                $stmt = $pdo->prepare("INSERT INTO student_wallet(student_id, balance) VALUES (?, ?)");
                $stmt->execute([$student_id, $wallet_deposit_amount]);
                $wallet_id = $pdo->lastInsertId();
            } else {
                $wallet_id = $student_wallet['id'];
                $new_balance = $student_wallet['balance'] + $wallet_deposit_amount;
                $stmt = $pdo->prepare("UPDATE student_wallet SET balance = ? WHERE id = ?");
                $stmt->execute([$new_balance, $wallet_id]);
            }

            $stmt = $pdo->prepare("INSERT INTO wallet_transactions (wallet_id, student_id, amount, transaction_type, transaction_id, description, created_at) VALUES (?, ?, ?, 'deposit', ?, 'Credited to wallet (Excess Payment / Next Academic Year)', ?)");
            $stmt->execute([$wallet_id, $student_id, $wallet_deposit_amount, $transaction_id, $payment_date]);

            $payment_history_remarks[] = $currency_symbol . $wallet_deposit_amount . " credited to wallet";
        }

        // ---------------------------------------------------------
        // FINAL: LOG HISTORY
        // ---------------------------------------------------------

        $payment_history_remark = implode(' & ', $payment_history_remarks);

        $stmt = $pdo->prepare("
            INSERT INTO student_payment_history
            (student_id, payment_amount, payment_date, remark, full_paid_payment_ids, partial_payment_ids_backup, wallet_affected_balance, wallet_transaction_id, unpaid_fee_rows_backup, entry_by) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $student_id,
            $original_payment_amount,
            $payment_date,
            $payment_history_remark,
            json_encode($full_paid_payment_ids),
            json_encode($partial_payment_ids_backup),
            $wallet_deposit_amount,
            $transaction_id,
            json_encode($unpaid_fee_rows_backup),
            $admin_id
        ]);

        $payment_history_id = $pdo->lastInsertId();
        $result['payment_history_id'] = $payment_history_id;

        // ---------------------------------------------------------
        // CONSTRUCT MESSAGE
        // ---------------------------------------------------------

        $msg = "Payment updated successfully";

        if ($wallet_deposit_amount > 0) {
            $msg .= " and " . $currency_symbol . $wallet_deposit_amount . " credited to the student wallet";
        }

        if (!empty($auto_generated_months)) {
            $msg .= " and these Months fees record generated automatically for advanced payment (" . implode(', ', $auto_generated_months) . ")";
        }

        $result['success'] = true;
        $result['message'] = $msg;
        $result['auto_generated_months'] = $auto_generated_months;
        $result['wallet_credited'] = $wallet_deposit_amount;
    } catch (Exception $e) {
        $result['success'] = false;
        $result['message'] = $e->getMessage();
    }

    return $result;
}
