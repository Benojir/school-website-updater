<?php
function hasPermission($permission) {
    if (!isset($_SESSION['user'])) {
        return false;
    }
    
    // Super admin has all permissions
    if ($_SESSION['user']['role'] === 'superadmin') {
        return true;
    }
    
    // Check if user is admin
    if ($_SESSION['user']['role'] !== 'admin') {
        return false;
    }
    
    // Check permissions in database
    global $pdo;
    try {
        $stmt = $pdo->prepare("
            SELECT 1 FROM admin_permissions p
            JOIN admin_roles r ON p.role_id = r.id
            JOIN users u ON u.role_id = r.id
            WHERE u.id = ? AND p.permission = ?
            LIMIT 1
        ");
        $stmt->execute([$_SESSION['user']['id'], $permission]);
        return (bool)$stmt->fetch();
    } catch (PDOException $e) {
        error_log("Permission check error: " . $e->getMessage());
        return false;
    }
}

// Common permission constants
define('PERM_MANAGE_STUDENTS', 'manage_students');
define('PERM_MANAGE_TEACHERS', 'manage_teachers');
define('PERM_MANAGE_RESULTS', 'manage_results');
define('PERM_MANAGE_CLASS_ROUTINES', 'manage_class_routines');
define('PERM_MANAGE_FEES', 'manage_fees');
define('PERM_MANAGE_NOTICES', 'manage_notices');
define('PERM_MANAGE_EXAMS', 'manage_exams');
define('PERM_MANAGE_SCHOOL_GALLERY', 'manage_school_gallery');
define('PERM_MANAGE_STUDENTS_ATTENDANCE', 'manage_students_attendance');
define('PERM_MANAGE_TEACHERS_ATTENDANCE', 'manage_teachers_attendance');
define('PERM_MANAGE_TRANSPORT', 'manage_transport');