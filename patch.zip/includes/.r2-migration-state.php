<?php exit; ?>
{"cursor":"students\/stu_68e604e35b810.jpeg","complete":false,"counts":{"default":3,"copied":4,"moved":23},"recent_errors":[],"updated_at":"2026-10-12T20:16:15+00:00"}