<?php
// Pure size helpers shared by the document UI and the upload endpoint guard.
function documentUploadIniBytes(string $value): int
{
    $value = trim($value);
    if ($value === '' || (float)$value <= 0) return 0;
    $multipliers = ['g'=>1073741824, 'm'=>1048576, 'k'=>1024];
    return (int)((float)$value * ($multipliers[strtolower(substr($value, -1))] ?? 1));
}

function documentUploadRequestTooLarge(int $length, int $limit): bool
{
    return $limit > 0 && $length > $limit;
}
