<?php
// Read-only daily attendance projection. No bootstrap, database or payroll writes.
require_once __DIR__ . '/staff-attendance-rules.php';

function staffDailyAttendanceRow(array $teacher, string $date, ?array $day, ?array $policy,
    ?array $calendar, ?array $term, DateTimeImmutable $now, DateTimeZone $defaultZone): array
{
    $rules=$policy['rules']??null;
    $zone=$rules?new DateTimeZone($rules['timezone']):$defaultZone;
    $today=$now->setTimezone($zone)->format('Y-m-d');
    $schedule=$rules?staffSchedule($rules,$date,$calendar):null;
    $punch=static function(?string $value): ?DateTimeImmutable {
        if(!$value) return null;
        $time=DateTimeImmutable::createFromFormat('!Y-m-d H:i:s',$value,new DateTimeZone('UTC'));
        if(!$time || $time->format('Y-m-d H:i:s')!==$value) throw new RuntimeException('A saved attendance time is invalid.');
        return $time;
    };
    $in=$punch($day['check_in']??null); $out=$punch($day['check_out']??null);
    $review=$day['review_status']??null; $override=$day['override_status']??null;
    $row=['teacher_id'=>(int)$teacher['id'],'teacher_name'=>$teacher['name'],
        'position'=>$teacher['position_in_school']??'', 'status'=>'absent','detail'=>'No arrival recorded.',
        'arrival_time'=>$in?->setTimezone($zone)->format('H:i:s'), 'departure_time'=>$out?->setTimezone($zone)->format('H:i:s'),
        'arrival_at'=>$in?->format(DATE_ATOM),'departure_at'=>$out?->format(DATE_ATOM),
        'timezone'=>$zone->getName(),'shift_start'=>$schedule['start_time']??null,'shift_end'=>$schedule['end_time']??null,
        'working'=>$schedule['working']??false,'rule_source'=>$policy['rule_source']??null,
        'schedule_note'=>!$rules?'Rules not configured.':(!$rules['enabled']?'Digital attendance is disabled.':
            (!$schedule['working']?($calendar['reason']??'Non-working day.') : '')),
        'late_minutes'=>null,'early_minutes'=>null,'short_day'=>false,
        'review_status'=>$review,'manual'=>$override!==null];
    if($schedule && $schedule['working']) {
        $start=new DateTimeImmutable("$date {$schedule['start_time']}",$zone);
        $end=new DateTimeImmutable("$date {$schedule['end_time']}",$zone);
        // Match staffDayCharges, including rounding partial minutes after grace.
        if($in) $row['late_minutes']=max(0,(int)ceil(($in->getTimestamp()-$start->getTimestamp())/60)-$rules['late_grace_min']);
        if($out) $row['early_minutes']=max(0,(int)ceil(($end->getTimestamp()-$out->getTimestamp())/60)-$rules['early_grace_min']);
        if($in && $out) {
            $worked=max(0,(int)floor((min($out->getTimestamp(),$end->getTimestamp())-max($in->getTimestamp(),$start->getTimestamp()))/60));
            $row['short_day']=$worked<$schedule['minimum_work_min'];
        }
    }
    $set=static function(string $status,string $detail) use (&$row): void { $row['status']=$status; $row['detail']=$detail; };
    if($date<($teacher['joining_date']?:'2000-01-01') || (!empty($term['employment_end']) && $date>$term['employment_end'])) {
        $set('not_employed','Outside the teacher’s employment dates.');
    } elseif($date>$today) {
        $set('upcoming','This date has not occurred yet.');
    } elseif($review==='rejected') {
        $set('absent','Attendance was rejected during review. Saved punch times are shown for reference.');
    } elseif(in_array($override,['absent','paid_leave','unpaid_leave'],true)) {
        $set($override,match($override) {'paid_leave'=>'Paid leave recorded by an administrator.',
            'unpaid_leave'=>'Unpaid leave recorded by an administrator.',default=>'Marked absent by an administrator.'});
    } elseif($in && $out) {
        $set($out>$in?'present':'needs_attention',$out>$in?'Arrival and departure recorded.':'Departure does not follow arrival. Review this record.');
    } elseif($in) {
        $close=$schedule?new DateTimeImmutable("$date {$schedule['checkout_close']}:59",$zone):null;
        $open=$date===$today && (!$close || $now<=$close);
        $set($open?'on_campus':'missing_checkout',$open?'Arrival recorded; departure has not been recorded yet.':'Arrival recorded; departure is missing.');
    } elseif($out) {
        $set('needs_attention','Departure recorded without an arrival.');
    } elseif(!$rules) {
        $set('not_configured','No attendance rules cover this date.');
    } elseif(!$rules['enabled']) {
        $set('disabled','Digital attendance is disabled for this date.');
    } elseif(!$schedule['working']) {
        $set('off',$calendar['reason']??'Non-working day.');
    } elseif($date===$today && $now<=new DateTimeImmutable("$date {$schedule['checkin_close']}:59",$zone)) {
        $set('awaiting_arrival','No arrival yet; check-in remains open until '.$schedule['checkin_close'].'.');
    }
    if(in_array($row['status'],['upcoming','not_employed'],true) || $review==='rejected') {
        $row['late_minutes']=$row['early_minutes']=null;
        $row['short_day']=false;
    }
    return $row;
}

function staffDailyAttendanceReport(string $date, array $teachers, array $days, array $policies,
    array $personalRules, ?array $calendar, array $terms, DateTimeImmutable $now, DateTimeZone $zone): array
{
    staffDate($date);
    $dayMap=$rulesByTeacher=$termsByTeacher=[];
    foreach($days as $day) if($day['work_date']===$date) $dayMap[$day['teacher_id']]=$day;
    foreach($personalRules as $rule) $rulesByTeacher[$rule['teacher_id']][]=$rule;
    foreach($terms as $term) $termsByTeacher[$term['teacher_id']][]=$term;
    $rows=[]; $summary=['total'=>0,'present'=>0,'absent'=>0,'late'=>0,'early'=>0,'awaiting'=>0,'pending_review'=>0];
    foreach($teachers as $teacher) {
        if($teacher['status']!=='active') continue;
        $id=$teacher['id'];
        $row=staffDailyAttendanceRow($teacher,$date,$dayMap[$id]??null,
            staffEffectivePolicy($policies,$rulesByTeacher[$id]??[],$date),$calendar,
            staffVersionAt($termsByTeacher[$id]??[],$date),$now,$zone);
        $rows[]=$row; $summary['total']++;
        if(in_array($row['status'],['present','on_campus','missing_checkout'],true)) $summary['present']++;
        if($row['status']==='absent') $summary['absent']++;
        if(($row['late_minutes']??0)>0) $summary['late']++;
        if(($row['early_minutes']??0)>0) $summary['early']++;
        if($row['status']==='awaiting_arrival') $summary['awaiting']++;
        if($row['review_status']==='pending') $summary['pending_review']++;
    }
    return ['date'=>$date,'today'=>$now->setTimezone($zone)->format('Y-m-d'),'timezone'=>$zone->getName(),
        'generated_at'=>$now->setTimezone(new DateTimeZone('UTC'))->format(DATE_ATOM),'summary'=>$summary,'teachers'=>$rows];
}
