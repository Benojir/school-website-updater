<?php
require_once __DIR__ . '/../photo-storage.php';
// Teacher ID card fields shared by the toolbox, database projection and print payload.
// Financial details, credentials and internal teacher permissions are not card fields.
function teacherIdCardFields(): array
{
    return [
        'Teacher' => [
            'teacher_name' => ['Teacher Name', 'name'], 'teacher_id' => ['Teacher ID', 'id'],
            'position_in_school' => ['Position / Designation', 'position_in_school'],
            'joining_date' => ['Joining Date', 'joining_date'], 'qualification' => ['Qualification', 'qualification'],
            'subject_specialization' => ['Subject Specialization', 'subject_specialization'],
            'dob' => ['Date of Birth', 'date_of_birth'], 'gender' => ['Gender', 'gender'],
            'blood_group' => ['Blood Group', 'blood_group'], 'nationality' => ['Nationality', 'nationality'],
            'aadhaar_no' => ['Aadhaar Number', 'aadhaar_number'], 'pan_number' => ['PAN Number', 'pan_number'],
            'voter_epic_number' => ['Voter EPIC Number', 'voter_epic_number'],
        ],
        'Family & Contact' => [
            'teacher_contact' => ['Contact Number', 'phone'], 'teacher_email' => ['Email', 'email'],
            'father_name' => ["Father's Name", 'father_name'], 'father_phone' => ["Father's Contact", 'father_phone'],
            'mother_name' => ["Mother's Name", 'mother_name'], 'mother_phone' => ["Mother's Contact", 'mother_phone'],
        ],
        'Address' => [
            'teacher_address' => ['Full Address', 'address'], 'village' => ['Village', 'village'],
            'post_office' => ['Post Office', 'post_office'], 'police_station' => ['Police Station', 'police_station'],
            'district' => ['District', 'district'], 'pin_code' => ['PIN Code', 'pincode'],
        ],
        'School' => [
            'school_name' => ['School Name', null], 'school_address' => ['School Address', null],
            'school_contact_no' => ['School Contact Number', null],
        ],
    ];
}

function teacherIdCardSelectedIds(array $request): array
{
    if (isset($request['teacher_ids'])) {
        if (!is_string($request['teacher_ids'])) throw new InvalidArgumentException('Invalid teacher selection.');
        $ids = json_decode($request['teacher_ids'], true);
    } else {
        $raw = $request['ids'] ?? '';
        if (!is_string($raw)) throw new InvalidArgumentException('Invalid teacher selection.');
        $ids = $raw !== '' ? explode(',', $raw) : [];
    }
    if (!is_array($ids) || !array_is_list($ids) || !$ids || count($ids) > 1000) {
        throw new InvalidArgumentException('Select between 1 and 1000 teachers.');
    }
    $result = [];
    foreach ($ids as $value) {
        if (!is_int($value) && !is_string($value)) throw new InvalidArgumentException('Invalid teacher ID.');
        $id = filter_var($value, FILTER_VALIDATE_INT);
        if ($id === false || $id < 1) throw new InvalidArgumentException('Invalid teacher ID.');
        $result[$id] = $id;
    }
    return array_values($result);
}

function teacherIdCardColumns(): array
{
    $columns = ['id', 'teacher_image'];
    foreach (teacherIdCardFields() as $fields) foreach ($fields as [, $column]) {
        if ($column !== null) $columns[] = $column;
    }
    return array_values(array_unique($columns));
}

function teacherIdCardPayload(array $teacher, array $school, string $baseUrl): array
{
    $payload = [];
    foreach (teacherIdCardFields() as $fields) foreach ($fields as $variable => [, $column]) {
        $payload[$variable] = $column === null ? '' : (string)($teacher[$column] ?? '');
    }
    foreach (['dob', 'joining_date'] as $field) {
        $value = $payload[$field];
        $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
        $payload[$field] = $date && $date->format('Y-m-d') === $value ? $date->format('d M, Y') : '';
    }
    if (trim($payload['teacher_address']) === '') {
        $payload['teacher_address'] = implode(', ', array_filter([
            $payload['village'], $payload['post_office'], $payload['police_station'], $payload['district'], $payload['pin_code']
        ], static fn($value) => trim($value) !== ''));
    }
    $payload['school_name'] = (string)($school['name'] ?? '');
    $payload['school_address'] = (string)($school['address'] ?? '');
    $payload['school_contact_no'] = implode(' / ', array_filter([(string)($school['phone'] ?? ''), (string)($school['alternate_phone'] ?? '')], static fn($value) => $value !== ''));
    $image = trim((string)($teacher['teacher_image'] ?? ''));
    $payload['teacher_photo_url'] = schoolPhotoCanvasUrl('teachers', $image !== '' ? basename($image) : null, $baseUrl);
    // Same numeric ID used by the existing teacher QR cards/scanners.
    $payload['qr_payload'] = $payload['teacher_id'];
    return $payload;
}
