<?php

function homeworkIniBytes(string $value): int
{
    $value = trim($value);
    if ((float)$value <= 0) return 0;
    $unit = strtolower(substr($value, -1));
    return (int)((float)$value * match ($unit) { 'g' => 1024 ** 3, 'm' => 1024 ** 2, 'k' => 1024, default => 1 });
}

function homeworkUploadLimits(?string $fileLimit = null, ?string $requestLimit = null): array
{
    $file = homeworkIniBytes($fileLimit ?? (string)ini_get('upload_max_filesize'));
    $request = homeworkIniBytes($requestLimit ?? (string)ini_get('post_max_size'));
    return ['file_bytes' => $file, 'request_bytes' => $request];
}

function homeworkPhotoError(int $bytes, int $width, int $height): ?string
{
    if ($bytes <= 0 || $width <= 0 || $height <= 0) return 'The photo could not be read. Choose another photo.';
    if ($bytes > 10 * 1024 * 1024) return 'Photos must be 10 MB or smaller. Choose a smaller photo.';
    if ($width + $height > 10000) return 'The photo width and height together must not exceed 10000 pixels.';
    if (max($width, $height) > 20 * min($width, $height)) return 'The photo is too narrow or wide. Its aspect ratio must be 20:1 or less.';
    return null;
}

// One response shape for history and a newly saved post, including albums.
function homeworkPostsFromRows(array $rows): array
{
    $posts = [];
    foreach ($rows as $row) {
        $key = (string)($row['media_group_id'] ?: $row['id']);
        if (!isset($posts[$key])) {
            $posts[$key] = ['post_id' => $key, 'cursor' => (int)$row['id'],
                'type' => empty($row['media_group_id']) ? 'single' : 'album',
                'text' => $row['message_text'] ?? '',
                'date' => date('j F Y, h:i:s A', strtotime($row['created_at'])), 'media' => []];
        }
        $posts[$key]['cursor'] = max($posts[$key]['cursor'], (int)$row['id']);
        if ($posts[$key]['text'] === '' && !empty($row['message_text'])) $posts[$key]['text'] = $row['message_text'];
        if (!empty($row['file_id'])) {
            $media = [];
            foreach (['file_type', 'file_id', 'file_name', 'file_size', 'file_width', 'file_height',
                'thumb_id', 'thumb_width', 'thumb_height'] as $field) $media[$field] = $row[$field] ?? null;
            $posts[$key]['media'][] = $media;
        }
    }
    return array_filter($posts, fn($post) => $post['text'] !== '' || $post['media'] !== []);
}
