<nav class="nav nav-pills gap-2 mb-3" aria-label="Teacher attendance pages">
    <a class="nav-link <?= $attendanceView==='daily'?'active':'' ?>" href="<?= BASE_URL ?>/management/teacher/daily-attendance.php" <?= $attendanceView==='daily'?'aria-current="page"':'' ?>>Daily attendance</a>
    <a class="nav-link <?= $attendanceView==='review'?'active':'' ?>" href="<?= BASE_URL ?>/management/teacher/attendance-payroll.php" <?= $attendanceView==='review'?'aria-current="page"':'' ?>>Attendance &amp; payroll</a>
    <a class="nav-link <?= $attendanceView==='school'?'active':'' ?>" href="<?= BASE_URL ?>/management/teacher/school-attendance-settings.php" <?= $attendanceView==='school'?'aria-current="page"':'' ?>>School attendance settings</a>
    <?php if(isSuperAdmin()): ?>
    <a class="nav-link <?= $attendanceView==='payments'?'active':'' ?>" href="<?= BASE_URL ?>/management/teacher/salary-payments.php" <?= $attendanceView==='payments'?'aria-current="page"':'' ?>>Salary payments</a>
    <a class="nav-link <?= $attendanceView==='teacher'?'active':'' ?>" href="<?= BASE_URL ?>/management/teacher/teacher-attendance-settings.php" <?= $attendanceView==='teacher'?'aria-current="page"':'' ?>>Teacher settings</a>
    <?php endif; ?>
</nav>
