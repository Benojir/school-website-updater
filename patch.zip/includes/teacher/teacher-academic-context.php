<?php
require_once __DIR__ . '/../academic/student-academic-service.php';

class TeacherAcademicYearRequired extends RuntimeException {}

function teacherRequireAcademicYear(PDO $pdo): string
{
    try {
        $year = academicCurrentYear($pdo);
    } catch (InvalidArgumentException $e) {
        $year = null;
    }
    if ($year === null) {
        throw new TeacherAcademicYearRequired('School academic year is not configured. Administrator: open the school website > Settings > School Settings, select Current academic year and save. Then retry in the Teacher App. Student search and attendance require this setting.');
    }
    return $year;
}

// Older Teacher Apps send YYYY-M-D. Normalize only this API input; keep
// academicDate strict for all other workflows and reject impossible dates.
function teacherAttendanceDate(mixed $value): string
{
    if (!is_string($value) || !preg_match('/^([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})$/D', $value, $parts)) {
        throw new InvalidArgumentException('Use a valid attendance date in YYYY-MM-DD format.');
    }
    return academicDate(sprintf('%04d-%02d-%02d', (int)$parts[1], (int)$parts[2], (int)$parts[3]));
}
