<?php
// Pure rules: no configuration include, database connection or network calls.
class StaffAttendanceDenied extends RuntimeException {}
class StaffAttendanceConflict extends RuntimeException {}

function staffDate(mixed $value): string
{
    if (!is_string($value) || !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $value)
        || !($d = DateTimeImmutable::createFromFormat('!Y-m-d', $value)) || $d->format('Y-m-d') !== $value
        || $value < '2000-01-01' || $value > '2100-12-31') {
        throw new InvalidArgumentException('Enter a valid date (YYYY-MM-DD, 2000–2100).');
    }
    return $value;
}

function staffMonth(mixed $value): string
{
    if (!is_string($value) || !preg_match('/^\d{4}-\d{2}$/D', $value)) throw new InvalidArgumentException('Select a month.');
    staffDate($value . '-01');
    return $value;
}

function staffNumber(mixed $value, float $min, float $max, string $label): float
{
    if ((!is_int($value) && !is_float($value) && !is_string($value)) || !is_numeric($value)
        || !is_finite((float)$value) || (float)$value < $min || (float)$value > $max) {
        throw new InvalidArgumentException("$label must be between $min and $max.");
    }
    return (float)$value;
}

function staffMoney(mixed $value): int
{
    if ((!is_int($value) && !is_string($value)) || !preg_match('/^\d{1,7}(?:\.\d{1,2})?$/D', (string)$value)) {
        throw new InvalidArgumentException('Enter a non-negative amount with at most two decimal places.');
    }
    [$whole, $fraction] = array_pad(explode('.', (string)$value), 2, '');
    return (int)$whole * 100 + (int)str_pad($fraction, 2, '0');
}

function staffInteger(mixed $value, int $min, int $max, string $label): int
{
    $number=staffNumber($value,$min,$max,$label);
    if(floor($number) !== $number) throw new InvalidArgumentException("$label must be a whole number.");
    return (int)$number;
}

function staffDefaults(): array
{
    return ['enabled'=>false, 'timezone'=>'Asia/Kolkata', 'latitude'=>0, 'longitude'=>0,
        'radius_m'=>100, 'max_accuracy_m'=>30, 'selfie_mode'=>'blink_turn', 'spot_instructions'=>'Stand at the school attendance point with its background visible.',
        'working_days'=>[1,2,3,4,5,6], 'start_time'=>'09:00', 'end_time'=>'16:00', 'day_schedules'=>[],
        'checkin_open'=>'06:00', 'checkin_close'=>'12:00', 'checkout_close'=>'23:00',
        'late_grace_min'=>10, 'early_grace_min'=>5, 'minimum_work_min'=>240,
        'late_mode'=>'flat', 'late_amount_paise'=>0, 'late_days_per_deduction'=>4, 'late_partial_mode'=>'flat', 'late_partial_amount_paise'=>0,
        'early_mode'=>'flat', 'early_amount_paise'=>0,
        'absence_percent'=>100, 'short_day_percent'=>50, 'salary_divisor'=>'working_days', 'fixed_divisor'=>30];
}

function staffShiftFields(): array
{
    return ['start_time','end_time','checkin_open','checkin_close','checkout_close','minimum_work_min'];
}

function staffValidateShift(array $shift): void
{
    foreach (array_diff(staffShiftFields(),['minimum_work_min']) as $key) staffTime($shift[$key]);
    if ($shift['start_time'] >= $shift['end_time'] || $shift['checkin_open'] > $shift['start_time']
        || $shift['checkin_close'] < $shift['start_time'] || $shift['checkin_close'] >= $shift['end_time']
        || $shift['checkout_close'] < $shift['end_time']) {
        throw new InvalidArgumentException('Use a same-day shift with valid arrival/departure windows.');
    }
    $minutes=static fn(string $time)=>(int)substr($time,0,2)*60+(int)substr($time,3,2);
    if ($shift['minimum_work_min'] > $minutes($shift['end_time'])-$minutes($shift['start_time'])) {
        throw new InvalidArgumentException('Minimum work must fit inside the configured shift.');
    }
}

function staffPolicy(array $input): array
{
    $p = array_replace(staffDefaults(), array_intersect_key($input, staffDefaults()));
    if (!in_array($p['enabled'], [true,false,0,1], true)) throw new InvalidArgumentException('Invalid enabled setting.');
    $p['enabled'] = (bool)$p['enabled'];
    if (!in_array($p['selfie_mode'], ['blink_only','blink_turn','manual_selfie'], true)) throw new InvalidArgumentException('Choose a valid selfie capture mode.');
    if (!is_string($p['timezone']) || !in_array($p['timezone'], DateTimeZone::listIdentifiers(), true)) throw new InvalidArgumentException('Choose a valid time zone.');
    foreach (['latitude'=>[-90,90], 'longitude'=>[-180,180], 'radius_m'=>[10,2000], 'max_accuracy_m'=>[1,100],
        'late_grace_min'=>[0,180], 'early_grace_min'=>[0,180], 'minimum_work_min'=>[0,1440],
        'absence_percent'=>[0,100], 'short_day_percent'=>[0,100], 'fixed_divisor'=>[1,31], 'late_days_per_deduction'=>[1,31],
        'late_amount_paise'=>[0,100000000], 'late_partial_amount_paise'=>[0,100000000], 'early_amount_paise'=>[0,100000000]] as $key=>$range) {
        $p[$key] = staffNumber($p[$key], $range[0], $range[1], $key);
        if (!in_array($key, ['latitude','longitude','radius_m','max_accuracy_m','absence_percent','short_day_percent'], true)) {
            if (floor($p[$key]) !== $p[$key]) throw new InvalidArgumentException("$key must be a whole number.");
            $p[$key] = (int)$p[$key];
        }
    }
    if ($p['max_accuracy_m'] >= $p['radius_m']) throw new InvalidArgumentException('GPS accuracy limit must be smaller than the school radius.');
    if (!is_string($p['spot_instructions']) || trim($p['spot_instructions']) === '' || strlen($p['spot_instructions']) > 1000) throw new InvalidArgumentException('Enter attendance-point instructions (up to 1000 bytes).');
    if (!is_array($p['working_days']) || !$p['working_days']) throw new InvalidArgumentException('Choose working weekdays.');
    foreach ($p['working_days'] as $day) if (!is_int($day) || $day < 1 || $day > 7) throw new InvalidArgumentException('Invalid weekday.');
    $p['working_days'] = array_values(array_unique($p['working_days']));
    staffValidateShift($p);
    if (!is_array($p['day_schedules'])) throw new InvalidArgumentException('Invalid weekday schedules.');
    foreach ($p['day_schedules'] as $day=>$times) {
        if (!preg_match('/^[1-7]$/D',(string)$day) || !is_array($times)
            || array_diff(array_keys($times),staffShiftFields())) throw new InvalidArgumentException('Invalid weekday shift.');
        $clean=[];
        foreach ($times as $key=>$value) {
            $clean[$key]=$key === 'minimum_work_min'
                ? staffInteger($value,0,1440,'Weekday minimum work') : staffTime($value);
        }
        try { staffValidateShift(array_replace($p,$clean)); }
        catch (InvalidArgumentException $e) {
            $name=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'][(int)$day-1];
            throw new InvalidArgumentException($name.': '.$e->getMessage());
        }
        // Keep only explicit overrides: omitted fields inherit the common shift.
        // Off-day schedules may be used by a later extra-working-day calendar entry.
        $p['day_schedules'][$day] = $clean;
    }
    if (!in_array($p['late_mode'], ['flat','per_minute','monthly_count'], true)
        || !in_array($p['early_mode'], ['flat','per_minute'], true)
        || !in_array($p['late_partial_mode'], ['flat','per_minute'], true)) throw new InvalidArgumentException('Invalid deduction mode.');
    if (!in_array($p['salary_divisor'], ['calendar_days','working_days','fixed'], true)) throw new InvalidArgumentException('Invalid salary divisor.');
    return $p;
}

function staffTime(mixed $value): string
{
    if (!is_string($value) || !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/D', $value)) throw new InvalidArgumentException('Enter a valid time (HH:MM).');
    return $value;
}

function staffOverrideGroups(): array
{
    return [
        'schedule'=>['working_days','start_time','end_time','day_schedules','checkin_open','checkin_close','checkout_close','minimum_work_min'],
        'grace'=>['late_grace_min','early_grace_min'],
        'deductions'=>['late_mode','late_amount_paise','late_days_per_deduction','late_partial_mode','late_partial_amount_paise','early_mode','early_amount_paise','absence_percent','short_day_percent','salary_divisor','fixed_divisor']
    ];
}

// Only these groups may vary by teacher. Location, liveness and school enablement stay shared.
function staffTeacherOverrides(array $input, array $school): array
{
    $groups=staffOverrideGroups(); $flat=[];
    foreach($input as $group=>$values) {
        // Versions saved before the per-minute option keep their flat partial charges.
        if ($group === 'deductions' && is_array($values) && !array_key_exists('late_partial_mode',$values)) {
            $values['late_partial_mode']=staffDefaults()['late_partial_mode'];
        }
        // Existing monthly/flat versions keep zero partial-group charges unless configured.
        if ($group === 'deductions' && is_array($values) && !array_key_exists('late_partial_amount_paise',$values)) {
            $values['late_partial_amount_paise']=staffDefaults()['late_partial_amount_paise'];
        }
        // Older complete deduction groups predate the optional monthly late rule.
        if ($group === 'deductions' && is_array($values) && !array_key_exists('late_days_per_deduction',$values)
            && in_array($values['late_mode']??null,['flat','per_minute'],true)) {
            $values['late_days_per_deduction']=staffDefaults()['late_days_per_deduction'];
        }
        if(!isset($groups[$group]) || !is_array($values)
            || array_diff(array_keys($values),$groups[$group]) || array_diff($groups[$group],array_keys($values))) {
            throw new InvalidArgumentException('Choose complete schedule, grace or deduction settings only.');
        }
        $flat=array_replace($flat,$values);
    }
    $rules=staffPolicy(array_replace($school,$flat)); $clean=[];
    foreach($input as $group=>$values) $clean[$group]=array_intersect_key($rules,array_flip($groups[$group]));
    return $clean;
}

function staffVersionAt(array $versions, string $date): ?array
{
    $found=null;
    foreach($versions as $v) if($v['effective_date'] <= $date
        && (!$found || [$v['effective_date'],(int)($v['id']??0)] >= [$found['effective_date'],(int)($found['id']??0)])) $found=$v;
    return $found;
}

function staffEffectivePolicy(array $policies, array $versions, string $date): ?array
{
    $school=staffVersionAt($policies,$date);
    if(!$school) return null;
    $v=staffVersionAt($versions,$date);
    $active=$v && (!$v['end_date'] || $date <= $v['end_date']) && !empty($v['overrides']);
    $school['teacher_rule_id']=$active?(int)$v['id']:null;
    $school['rule_source']=$active?'teacher':'school';
    if($active) {
        $overrides=staffTeacherOverrides($v['overrides'],$school['rules']);
        foreach($overrides as $values) $school['rules']=array_replace($school['rules'],$values);
    }
    return $school;
}

// Check every date on which either school rules or personal versions can change.
function staffValidateRuleTimeline(array $policies, array $versions): void
{
    $dates=array_column($policies,'effective_date');
    foreach($versions as $v) {
        $dates[]=$v['effective_date'];
        if($v['end_date']) $dates[]=(new DateTimeImmutable($v['end_date']))->modify('+1 day')->format('Y-m-d');
    }
    foreach(array_unique($dates) as $date) staffEffectivePolicy($policies,$versions,$date);
}

function staffPaymentReference(mixed $value, int $teacherId, string $month): string
{
    if ($value !== null && !is_string($value)) throw new InvalidArgumentException('Payment reference must be text.');
    $reference = trim($value ?? '');
    if (strlen($reference) > 200) throw new InvalidArgumentException('Payment reference must be at most 200 bytes.');
    // This is an internal tracking reference, not a receipt or bank transaction ID.
    return $reference !== '' ? $reference : 'SYS-SAL-' . $month . '-T' . $teacherId . '-' . strtoupper(bin2hex(random_bytes(8)));
}

/** Optional administrator note; always retain a useful reason in the audit history. */
function staffChangeReason(mixed $value, string $default): string
{
    if ($value === null) return $default;
    if (!is_string($value) || strlen($value) > 1000) throw new InvalidArgumentException('Reason must be text of at most 1000 bytes.');
    $reason = trim($value);
    return $reason === '' ? $default : $reason;
}

function staffDistance(float $lat1, float $lon1, float $lat2, float $lon2): float
{
    $a = sin(deg2rad($lat2 - $lat1)/2)**2 + cos(deg2rad($lat1))*cos(deg2rad($lat2))*sin(deg2rad($lon2 - $lon1)/2)**2;
    return 6371000 * 2 * atan2(sqrt(min(1,$a)), sqrt(max(0,1-$a)));
}

function staffLocation(array $input, array $policy): array
{
    if (($input['mock'] ?? null) !== false) throw new StaffAttendanceDenied('Mock locations are not accepted.');
    $lat = staffNumber($input['latitude'] ?? null, -90, 90, 'Latitude');
    $lon = staffNumber($input['longitude'] ?? null, -180, 180, 'Longitude');
    $accuracy = staffNumber($input['accuracy_m'] ?? null, 0.1, $policy['max_accuracy_m'], 'GPS accuracy');
    $age=staffInteger($input['age_ms'] ?? null, 0, 15000, 'Location age');
    $distance = staffDistance($lat, $lon, $policy['latitude'], $policy['longitude']);
    // The entire reported uncertainty circle must fit inside the configured fence.
    if ($distance + $accuracy > $policy['radius_m']) throw new StaffAttendanceDenied('You must be inside the school boundary. Wait for a more accurate location and retry.');
    return ['latitude'=>$lat,'longitude'=>$lon,'accuracy_m'=>$accuracy,'distance_m'=>round($distance,2),'age_ms'=>$age,'mock'=>false];
}

function staffSteps(int $blinks, int $direction, string $mode = 'blink_turn'): array
{
    if ($mode === 'manual_selfie') return ['selfie'];
    if (!in_array($mode, ['blink_only','blink_turn'], true) || !in_array($blinks,[1,2],true) || !in_array($direction,[0,1],true)) throw new InvalidArgumentException('Invalid camera challenge settings.');
    $steps = ['open'];
    for ($i=0;$i<$blinks;$i++) array_push($steps, 'closed', 'open');
    if ($mode === 'blink_turn') array_push($steps, $direction === 1 ? 'turn_positive' : 'turn_negative', 'center');
    return $steps;
}

function staffProof(array $proof, array $steps, int $serverElapsedMs, string $mode = 'blink_turn'): array
{
    // This validates the protocol, NOT the authenticity of client ML measurements.
    // Only an administrator's review can approve this free on-device mode for payroll.
    $allowed=false;
    foreach ([1,2] as $blinks) foreach ([0,1] as $direction) if ($steps === staffSteps($blinks,$direction,$mode)) $allowed=true;
    if (!$allowed) throw new StaffAttendanceDenied('The camera challenge does not match school rules. Start again.');
    if (($proof['camera_protocol'] ?? null) !== 2) throw new StaffAttendanceDenied('Update the teacher app to use the current camera checks.');
    $samples = $proof['samples'] ?? null;
    if (!is_array($samples) || count($samples) !== count($steps)) throw new StaffAttendanceDenied('Complete every live-camera challenge.');
    $previous = -1; $tracking = null; $clean=[];
    foreach ($samples as $i=>$s) {
        if (!is_array($s) || ($s['step'] ?? '') !== $steps[$i] || ($s['face_count'] ?? null) !== 1) throw new StaffAttendanceDenied('Invalid camera challenge sequence.');
        $ms = staffInteger($s['elapsed_ms'] ?? null, 0, 120000, 'Capture time');
        if ($ms - $previous < 80 || $ms > $serverElapsedMs + 1000) throw new StaffAttendanceDenied('Invalid challenge timing.');
        $previous = $ms;
        $id = staffInteger($s['tracking_id'] ?? null, 0, 2147483647, 'Face tracking');
        if ($tracking !== null && $tracking !== $id) throw new StaffAttendanceDenied('Keep the same face visible throughout the challenge.');
        $tracking = $id;
        $yaw = staffNumber($s['yaw'] ?? null, -90, 90, 'Head angle');
        $left = staffNumber($s['left_eye'] ?? null, 0, 1, 'Left eye');
        $right = staffNumber($s['right_eye'] ?? null, 0, 1, 'Right eye');
        if (($s['cover_model'] ?? null) !== 'aizoo_v1' || ($s['face_uncovered'] ?? null) !== true) throw new StaffAttendanceDenied('Keep your face uncovered. Remove any mask and retry.');
        $uncovered=staffNumber($s['no_mask_score'] ?? null,0,1,'Uncovered face confidence');
        if ($uncovered < .8) throw new StaffAttendanceDenied('Your face must be clearly uncovered. Remove any mask, improve the light and retry.');
        $ok = match($steps[$i]) {
            'open','center','selfie' => abs($yaw) <= 15 && $left >= .65 && $right >= .65,
            'closed' => abs($yaw) <= 15 && $left <= .25 && $right <= .25,
            'turn_positive' => $yaw >= 22,
            'turn_negative' => $yaw <= -22,
            default => false
        };
        if (!$ok) throw new StaffAttendanceDenied('Camera challenge did not pass. Please retry.');
        if ($steps[$i] === 'selfie' && ($s['manual_capture'] ?? null) !== true) throw new StaffAttendanceDenied('Tap Take selfie to capture a fresh camera image.');
        $clean[]=['step'=>$steps[$i],'elapsed_ms'=>$ms,'tracking_id'=>$id,'face_count'=>1,'left_eye'=>$left,'right_eye'=>$right,'yaw'=>$yaw,
            'cover_model'=>'aizoo_v1','face_uncovered'=>true,'no_mask_score'=>$uncovered,'manual_capture'=>$steps[$i] === 'selfie'];
    }
    $minimum=match($mode) {'manual_selfie'=>300,'blink_only'=>600,default=>1200};
    if ($previous < $minimum) throw new StaffAttendanceDenied('Challenge completed too quickly.');
    return ['mode'=>'on_device_review_required','selfie_mode'=>$mode,'camera_protocol'=>2,'samples'=>$clean];
}

function staffSchedule(array $policy, string $date, ?array $calendar = null): array
{
    $weekday = (int)(new DateTimeImmutable($date))->format('N');
    $working = $policy['enabled'] && in_array($weekday, $policy['working_days'], true);
    if ($calendar) $working = $policy['enabled'] && $calendar['kind'] === 'working';
    $times = array_replace($policy,$policy['day_schedules'][$weekday] ?? []);
    return ['working'=>$working] + array_intersect_key($times,array_flip(staffShiftFields()));
}

/** Read-only reminder plan. It never records attendance or changes payroll. */
function staffDepartureReminder(string $date, ?array $policy, ?array $day, ?array $calendar = null, ?DateTimeImmutable $now = null): array
{
    $now ??= new DateTimeImmutable('now', new DateTimeZone('UTC'));
    $result = ['eligible'=>false, 'work_date'=>$date, 'server_now_ms'=>(int)$now->format('Uv'),
        'remind_at_ms'=>null, 'expires_at_ms'=>null];
    if (!$policy) return $result;
    $schedule = staffSchedule($policy, $date, $calendar);
    if (!$schedule['working'] || !$day || empty($day['check_in']) || !empty($day['check_out'])
        || !empty($day['override_status']) || ($day['review_status'] ?? '') === 'rejected') return $result;
    $zone = new DateTimeZone($policy['timezone']);
    $end = new DateTimeImmutable("$date {$schedule['end_time']}", $zone);
    $close = new DateTimeImmutable("$date {$schedule['checkout_close']}", $zone);
    $result['remind_at_ms'] = $end->getTimestamp() * 1000;
    // Punch windows compare H:i, so the configured closing minute is inclusive.
    $result['expires_at_ms'] = $close->getTimestamp() * 1000 + 59999;
    $result['eligible'] = $result['server_now_ms'] <= $result['expires_at_ms'];
    return $result;
}

function staffDayCharges(array $policy, string $date, ?array $day, int $salary, int $divisor, ?array $calendar = null): array
{
    $schedule = staffSchedule($policy,$date,$calendar);
    $r = ['absence_paise'=>0,'late_paise'=>0,'early_paise'=>0,'short_day_paise'=>0,'late_minutes'=>0,'early_minutes'=>0,'worked_minutes'=>0,'status'=>'off','review_required'=>false];
    if (!$schedule['working']) return $r;
    $rate = $salary / max(1,$divisor);
    $r['review_required'] = $day && $day['review_status'] === 'pending';
    $status = ($day['review_status'] ?? '') === 'rejected' ? 'absent' : ($day['override_status'] ?? null);
    if ($status === 'paid_leave') { $r['status']='paid_leave'; return $r; }
    if (!$day || ($day['review_status'] ?? '') === 'rejected' || in_array($status,['absent','unpaid_leave'],true)
        || empty($day['check_in']) || empty($day['check_out'])) {
        $r['status'] = $status === 'unpaid_leave' ? 'unpaid_leave' : ($day && !empty($day['check_in']) && empty($day['check_out']) ? 'missing_checkout' : 'absent');
        $r['absence_paise'] = (int)round($rate * ($status === 'unpaid_leave' ? 1 : $policy['absence_percent']/100));
        return $r;
    }
    $zone = new DateTimeZone($policy['timezone']); $utc = new DateTimeZone('UTC');
    $in = new DateTimeImmutable($day['check_in'], $utc); $out = new DateTimeImmutable($day['check_out'], $utc);
    $start = new DateTimeImmutable("$date {$schedule['start_time']}", $zone);
    $end = new DateTimeImmutable("$date {$schedule['end_time']}", $zone);
    $r['status']='present';
    $r['late_minutes'] = max(0,(int)ceil(($in->getTimestamp()-$start->getTimestamp())/60)-$policy['late_grace_min']);
    $r['early_minutes'] = max(0,(int)ceil(($end->getTimestamp()-$out->getTimestamp())/60)-$policy['early_grace_min']);
    // Work outside the shift cannot compensate for a short scheduled day.
    $r['worked_minutes'] = max(0,(int)floor((min($out->getTimestamp(),$end->getTimestamp())-max($in->getTimestamp(),$start->getTimestamp()))/60));
    foreach (['late','early'] as $type) if ($r[$type.'_minutes'] > 0) {
        // Monthly late deductions need the month's running count, computed below.
        if ($type === 'late' && $policy['late_mode'] === 'monthly_count') continue;
        $r[$type.'_paise'] = $policy[$type.'_amount_paise'] * ($policy[$type.'_mode'] === 'per_minute' ? $r[$type.'_minutes'] : 1);
    }
    if ($r['worked_minutes'] < $schedule['minimum_work_min']) {
        $r['status']='short_day'; $r['short_day_paise']=(int)round($rate*$policy['short_day_percent']/100);
    }
    // Avoid stacking penalties beyond one day's salary, preserving itemized amounts.
    $remaining=(int)round($rate);
    foreach (['short_day_paise','late_paise','early_paise'] as $key) { $r[$key]=min($remaining,$r[$key]); $remaining-=$r[$key]; }
    return $r;
}

function staffPayrollMode(array $versions, string $month): array
{
    staffMonth($month);
    $found=['id'=>null,'mode'=>'attendance'];
    foreach($versions as $v) {
        if($v['effective_month'] <= $month) $found=$v;
    }
    if(!in_array($found['mode'],['manual','attendance'],true)) throw new InvalidArgumentException('Invalid salary calculation mode.');
    return $found;
}

function staffPayrollCalculate(string $month, array $teacher, array $policies, array $terms, array $days, array $calendar, array $adjustments, string $asOf, array $teacherRules = [], string $payrollMode = 'attendance'): array
{
    staffMonth($month); staffDate($asOf);
    if(!in_array($payrollMode,['manual','attendance'],true)) throw new InvalidArgumentException('Choose manual or attendance-based salary.');
    $manual=$payrollMode==='manual';
    $first=new DateTimeImmutable($month.'-01'); $count=(int)$first->format('t');
    $result=['month'=>$month,'teacher_id'=>(int)$teacher['id'],'teacher_name'=>$teacher['name'], 'state'=>'estimate',
        'payroll_mode'=>$payrollMode,
        'gross_paise'=>0,'absence_paise'=>0,'late_paise'=>0,'early_paise'=>0,'short_day_paise'=>0,'adjustments_paise'=>0,
        'net_paise'=>0,'review_pending'=>0,'future_working_days'=>0,'days'=>[], 'adjustments'=>$adjustments,
        'monthly_late_days'=>0,'late_salary_days'=>0,
        'formula'=>'Gross salary is weighted by calendar days, salary revisions and joining date. Attendance deductions use the configured divisor. Future days have no deductions.'];
    if($manual) $result['formula']='Manual salary: gross is weighted by calendar days, dated salary terms, joining date and employment end. Add approved bonuses/allowances and enter deductions/advance recovery yourself. Digital attendance does not change this salary or require review for settlement.';
    $policyAt = fn(string $date): ?array => staffEffectivePolicy($policies,$teacherRules,$date);
    $termAt = function(string $date) use ($terms): ?array {
        $found=null; foreach($terms as $t) if($t['effective_date'] <= $date) $found=$t; return $found;
    };
    $workingCount=0;
    for($i=0;!$manual && $i<$count;$i++) {
        $date=$first->modify("+$i days")->format('Y-m-d'); $p=$policyAt($date);
        if($p && staffSchedule($p['rules'],$date,$calendar[$date]??null)['working']) $workingCount++;
    }
    $gross=0.0; $lateGroup=null; $monthlyLateCount=0; $lateGroupDays=[];
    for($i=0;$i<$count;$i++) {
        $date=$first->modify("+$i days")->format('Y-m-d'); $p=$manual?null:$policyAt($date); $t=$termAt($date); $day=$days[$date]??null;
        // Unrelated policy/salary revisions keep progress; changing late mode or N resets it.
        $group=$p && $p['rules']['late_mode']==='monthly_count' ? (int)$p['rules']['late_days_per_deduction'] : null;
        if ($group !== $lateGroup) { $monthlyLateCount=0; $lateGroupDays=[]; $lateGroup=$group; }
        $employed=$date >= ($teacher['joining_date'] ?: '2000-01-01') && (!$t || empty($t['employment_end']) || $date <= $t['employment_end']);
        if(!$t || !$employed || (!$manual && (!$p || !$p['rules']['enabled']))) { $result['days'][]=['date'=>$date,'status'=>'not_covered']; continue; }
        $salary=(int)$t['salary_paise']; $gross += $salary/$count;
        if($manual) {
            $result['days'][]=['date'=>$date,'status'=>'manual_salary','salary_paise'=>$salary,
                'absence_paise'=>0,'late_paise'=>0,'early_paise'=>0,'short_day_paise'=>0,'review_required'=>false];
            continue;
        }
        $rules=$p['rules']; $divisor=match($rules['salary_divisor']) {'calendar_days'=>$count,'fixed'=>$rules['fixed_divisor'],default=>max(1,$workingCount)};
        $charges=staffDayCharges($rules,$date,$day,$salary,$divisor,$calendar[$date]??null);
        if($date === $asOf && staffSchedule($rules,$date,$calendar[$date]??null)['working']
            && (!$day || empty($day['check_out'])) && empty($day['override_status'])
            && (!$day || $day['review_status'] !== 'rejected')) {
            $charges['absence_paise']=0; $charges['status']='awaiting_attendance';
        }
        if($date > $asOf) {
            if(staffSchedule($rules,$date,$calendar[$date]??null)['working']) $result['future_working_days']++;
            $charges=array_replace($charges,['absence_paise'=>0,'late_paise'=>0,'early_paise'=>0,'short_day_paise'=>0,'status'=>'upcoming','review_required'=>false]);
        }
        if ($group !== null && $date <= $asOf && $charges['late_minutes'] > 0
            && in_array($charges['status'],['present','short_day'],true)) {
            $monthlyLateCount++; $result['monthly_late_days']++;
            $charges['monthly_late_number']=$monthlyLateCount;
            $charges['late_days_per_deduction']=$group;
            $charges['monthly_late_group_complete']=$monthlyLateCount % $group === 0;
            if ($monthlyLateCount % $group === 0) {
                // A complete group replaces its provisional daily late charges, never stacks them.
                foreach ($lateGroupDays as $previous) {
                    $index=$previous['index'];
                    foreach (['late_paise','early_paise','short_day_paise'] as $key) {
                        $result[$key]+=$previous['charges'][$key]-$result['days'][$index][$key];
                        $result['days'][$index][$key]=$previous['charges'][$key];
                    }
                    $result['days'][$index]['monthly_late_group_complete']=true;
                }
                $lateGroupDays=[];
                // Charge one full daily rate on every Nth late day, within the daily cap.
                $charges['late_paise']=(int)round($salary/max(1,$divisor));
                $charges['early_paise']=0; $charges['short_day_paise']=0;
                $result['late_salary_days']++;
            } else {
                // Save the non-late charges so any early deduction trimmed by the cap can be restored.
                $lateGroupDays[]=['index'=>count($result['days']),'charges'=>$charges];
                $remaining=max(0,(int)round($salary/max(1,$divisor))-$charges['short_day_paise']);
                $partialCharge=(int)($rules['late_partial_amount_paise']??0)
                    * (($rules['late_partial_mode']??'flat')==='per_minute' ? $charges['late_minutes'] : 1);
                $charges['late_paise']=min($remaining,$partialCharge);
                $charges['early_paise']=min($charges['early_paise'],$remaining-$charges['late_paise']);
            }
        }
        foreach(['absence_paise','late_paise','early_paise','short_day_paise'] as $key) $result[$key]+=$charges[$key];
        if($charges['review_required']) $result['review_pending']++;
        $result['days'][]=array_merge(['date'=>$date,'policy_id'=>(int)$p['id'],'salary_paise'=>$salary,'divisor'=>$divisor,
            'teacher_rule_id'=>$p['teacher_rule_id'],'rule_source'=>$p['rule_source'],
            'shift_start'=>$rules['day_schedules'][(int)(new DateTimeImmutable($date))->format('N')]['start_time']??$rules['start_time'],
            'shift_end'=>$rules['day_schedules'][(int)(new DateTimeImmutable($date))->format('N')]['end_time']??$rules['end_time'],
            'check_in'=>$day['check_in']??null,'check_out'=>$day['check_out']??null,'timezone'=>$rules['timezone'],
            'review_status'=>$day['review_status']??null,'override_status'=>$day['override_status']??null,
            'version'=>(int)($day['version']??0),'in_event_id'=>$day['in_event_id']??null,'out_event_id'=>$day['out_event_id']??null],$charges);
    }
    $result['gross_paise']=(int)round($gross);
    foreach($adjustments as $a) $result['adjustments_paise'] += (int)$a['amount_paise'];
    $result['net_paise']=max(0,$result['gross_paise']-$result['absence_paise']-$result['late_paise']-$result['early_paise']-$result['short_day_paise']+$result['adjustments_paise']);
    if ($result['monthly_late_days'] > 0) $result['formula'].=' Monthly late rule: each complete group of N arrivals after grace deducts one full daily rate, replacing that group\'s provisional late charges. Incomplete groups use the configured flat daily amount or per-minute rate after grace, within the daily cap. Counts reset each month and when the late mode or N changes. The full-day charge replaces early/short-day charges on the Nth date.';
    return $result;
}
