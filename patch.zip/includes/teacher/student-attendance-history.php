<?php

// Pure projection of attendance rows; no database connection or queries here.
function teacherStudentAttendanceSummary(array $students, array $rows, string $today): array
{
    $day = new DateTimeImmutable($today);
    $previousDates = [$day->modify('-1 day')->format('Y-m-d'), $day->modify('-2 days')->format('Y-m-d')];
    $roster = array_fill_keys(array_map(fn($student) => (string)$student['student_id'], $students), true);
    $byStudent = [];
    // Rows arrive in date/id order. A later Leave record must not hide the fact
    // that the student was present earlier that day.
    foreach ($rows as $row) {
        $id = (string)$row['student_id'];
        $date = (string)$row['date'];
        $status = (string)$row['status'];
        if (!isset($roster[$id]) || !in_array($date, [$today, ...$previousDates], true)
            || !in_array($status, ['present', 'absent', 'leave'], true)) continue;
        $summary = $byStudent[$id][$date] ?? ['status' => null, 'was_present' => false];
        $summary['status'] = $status;
        $summary['was_present'] = $summary['was_present'] || $status === 'present';
        $byStudent[$id][$date] = $summary;
    }

    $present = 0;
    $absent = 0;
    foreach ($students as &$student) {
        $days = $byStudent[(string)$student['student_id']] ?? [];
        $current = $days[$today] ?? ['status' => null, 'was_present' => false];
        $student['attendance'] = $current['status'];
        $student['recent_attendance'] = array_map(fn($date) => ['date' => $date]
            + ($days[$date] ?? ['status' => null, 'was_present' => false]), $previousDates);
        if ($current['was_present']) $present++;
        if ($current['status'] === 'absent') $absent++;
    }
    unset($student);
    return ['students' => $students, 'total_students' => count($students),
        'total_present' => $present, 'total_absent' => $absent, 'attendance_date' => $today];
}
