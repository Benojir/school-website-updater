<?php
// Pure payment-report rules. No database connection or network calls.
require_once __DIR__ . '/staff-attendance-rules.php';

function staffPaymentPeriod(string $month, string $basis, DateTimeZone $zone): array
{
    staffMonth($month);
    if (!in_array($basis, ['salary_month','payment_month'], true)) throw new InvalidArgumentException('Choose salary month or payment month.');
    $first=new DateTimeImmutable($month.'-01 00:00:00',$zone);
    return ['start_utc'=>$first->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s'),
        'end_utc'=>$first->modify('+1 month')->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s')];
}

function staffPaymentOverviewPeriod(DateTimeImmutable $asOf, DateTimeZone $zone): array
{
    $local=$asOf->setTimezone($zone);
    $lastMonth=$local->modify('first day of this month')->setTime(0,0)->modify('-1 month');
    $yearStart=$local->setDate((int)$local->format('Y'),1,1)->setTime(0,0);
    $first=$lastMonth<$yearStart?$lastMonth:$yearStart;
    return ['last_month'=>$lastMonth->format('Y-m'),'year'=>$local->format('Y'),
        'start_utc'=>$first->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s'),
        'as_of_utc'=>$asOf->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s')];
}

function staffPaymentOverview(array $entries, DateTimeImmutable $asOf, DateTimeZone $zone): array
{
    $period=staffPaymentOverviewPeriod($asOf,$zone);
    $groups=[];
    foreach ($entries as $entry) {
        $paid=DateTimeImmutable::createFromFormat('!Y-m-d H:i:s',$entry['created_at'],new DateTimeZone('UTC'));
        if (!$paid || $paid->format('Y-m-d H:i:s')!==$entry['created_at']) throw new RuntimeException('A saved payment date is invalid.');
        if ($entry['created_at']<$period['start_utc'] || $entry['created_at']>$period['as_of_utc']) continue;
        $groups[$paid->setTimezone($zone)->format('Y-m')][]=$entry;
    }
    $summary=['last_month'=>$period['last_month'],'year'=>$period['year'],'last_month_paise'=>0,'year_paise'=>0,'reconciliation_count'=>0];
    foreach ($groups as $month=>$payments) {
        $report=staffPaymentReport($payments,$month,'payment_month',$zone,$period['as_of_utc']);
        if ($month===$summary['last_month']) $summary['last_month_paise']=$report['total_paise'];
        if (substr($month,0,4)===$summary['year']) $summary['year_paise']+=$report['total_paise'];
        $summary['reconciliation_count']+=$report['reconciliation_count'];
    }
    return $summary;
}

function staffPaymentReport(array $entries, string $month, string $basis, DateTimeZone $zone, string $generatedAt): array
{
    staffPaymentPeriod($month,$basis,$zone);
    $rows=[]; $teachers=[]; $salaryCounts=[]; $total=0;
    foreach ($entries as $entry) {
        // Read the immutable snapshot at Mark paid, not a recalculated/current salary.
        try {
            $before=json_decode($entry['before_json'],true,512,JSON_THROW_ON_ERROR);
            $after=json_decode($entry['after_json'],true,32,JSON_THROW_ON_ERROR);
            if (!is_array($before) || !is_array($after)) throw new RuntimeException('A saved payment record is incomplete.');
            $snapshot=json_decode($before['snapshot_json']??'',true,512,JSON_THROW_ON_ERROR);
            $salaryMonth=staffMonth($entry['reference_key']??'');
        } catch (JsonException|TypeError|InvalidArgumentException $e) {
            throw new RuntimeException('A saved salary payment record is invalid. Ask the administrator to inspect payment history.',0,$e);
        }
        $id=(int)($entry['teacher_id']??0);
        $amount=$snapshot['net_paise']??null;
        $paid=DateTimeImmutable::createFromFormat('!Y-m-d H:i:s',$entry['created_at'],new DateTimeZone('UTC'));
        if ($id<1 || (int)($snapshot['teacher_id']??0)!==$id || ($snapshot['month']??'')!==$salaryMonth
            || ($before['state']??'')!=='finalized' || !is_int($amount) || $amount<0
            || !$paid || $paid->format('Y-m-d H:i:s')!==$entry['created_at']
            || !is_string($after['reference']??null) || trim($after['reference'])==='') {
            throw new RuntimeException('A saved salary payment record is incomplete. Ask the administrator to inspect payment history.');
        }
        $local=$paid->setTimezone($zone);
        // Keep selection rules enforced even when an offline caller supplies extra rows.
        if (($basis==='salary_month'?$salaryMonth:$local->format('Y-m'))!==$month) continue;
        $name=is_string($snapshot['teacher_name']??null) && trim($snapshot['teacher_name'])!==''?$snapshot['teacher_name']:'Teacher #'.$id;
        $key=$id.':'.$salaryMonth; $salaryCounts[$key]=($salaryCounts[$key]??0)+1;
        $rows[]=['payment_id'=>(string)$entry['id'],'teacher_id'=>$id,'teacher_name'=>$name,'salary_month'=>$salaryMonth,
            'amount_paise'=>$amount,'paid_at'=>$entry['created_at'],'paid_at_local'=>$local->format('Y-m-d H:i'),
            'reference'=>$after['reference'],'reason'=>$entry['reason'],'salary_state'=>$entry['current_state']??'historical',
            'needs_reconciliation'=>array_key_exists('current_reference',$entry) && $entry['current_reference']!==$after['reference']];
        if (!isset($teachers[$id])) $teachers[$id]=['teacher_id'=>$id,'teacher_name'=>$name,'salary_months'=>[],
            'payment_count'=>0,'amount_paise'=>0,'needs_reconciliation'=>false];
        $teachers[$id]['salary_months'][$salaryMonth]=$salaryMonth;
        $teachers[$id]['payment_count']++; $teachers[$id]['amount_paise']+=$amount; $total+=$amount;
    }
    $attention=0;
    foreach ($rows as &$row) {
        $row['needs_reconciliation']=$row['needs_reconciliation'] || $salaryCounts[$row['teacher_id'].':'.$row['salary_month']]>1
            || $row['salary_state']!=='paid';
        if ($row['needs_reconciliation']) { $attention++; $teachers[$row['teacher_id']]['needs_reconciliation']=true; }
    }
    unset($row);
    foreach ($teachers as &$teacher) {sort($teacher['salary_months']);$teacher['salary_months']=array_values($teacher['salary_months']);}
    unset($teacher);
    usort($teachers,fn($a,$b)=>strnatcasecmp($a['teacher_name'],$b['teacher_name']) ?: $a['teacher_id']<=>$b['teacher_id']);
    usort($rows,fn($a,$b)=>[$a['paid_at'],$a['payment_id']]<=>[$b['paid_at'],$b['payment_id']]);
    return ['month'=>$month,'basis'=>$basis,'timezone'=>$zone->getName(),
        'generated_at_local'=>(new DateTimeImmutable($generatedAt,new DateTimeZone('UTC')))->setTimezone($zone)->format('Y-m-d H:i'),
        'rows'=>$rows,'teachers'=>$teachers,'teacher_count'=>count($teachers),'payment_count'=>count($rows),
        'total_paise'=>$total,'reconciliation_count'=>$attention];
}
