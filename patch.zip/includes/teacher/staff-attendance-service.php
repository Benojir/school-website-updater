<?php
require_once __DIR__ . '/staff-attendance-rules.php';
require_once __DIR__ . '/staff-payroll-payment-report.php';

function staffCameraImage(mixed $encoded, bool $evidence = false): string
{
    if (!is_string($encoded) || strlen($encoded) > 1400000 || !($bytes=base64_decode($encoded,true))
        || strlen($bytes) > 1024*1024 || !($size=@getimagesizefromstring($bytes)) || $size[2] !== IMAGETYPE_JPEG
        || min($size[0],$size[1]) < ($evidence ? 200 : 360) || max($size[0],$size[1]) > 1600) {
        throw new InvalidArgumentException('Upload valid, compressed live-camera JPG images (up to 1MB each).');
    }
    return $bytes;
}

class StaffAttendanceService
{
    private DateTimeZone $zone;
    public function __construct(private PDO $pdo, private int $actorId = 0, private $uploader = null)
    {
        $this->zone=new DateTimeZone(date_default_timezone_get());
    }
    private function q(string $sql, array $p=[]): PDOStatement
    {
        $s=$this->pdo->prepare($sql); $s->execute($p); return $s;
    }
    private function utc(): string { return gmdate('Y-m-d H:i:s'); }
    public function today(): string { return (new DateTimeImmutable('now',$this->zone))->format('Y-m-d'); }
    private function transaction(callable $fn): mixed
    {
        $this->pdo->beginTransaction();
        try {
            if (!$this->q('SELECT id FROM staff_attendance_control WHERE id = 1 FOR UPDATE')->fetchColumn()) throw new RuntimeException('Attendance migration missing.');
            $r=$fn(); $this->pdo->commit(); return $r;
        } catch(Throwable $e) { if($this->pdo->inTransaction()) $this->pdo->rollBack(); throw $e; }
    }
    public function policies(): array
    {
        $rows=$this->q('SELECT * FROM staff_attendance_policies ORDER BY effective_date, id')->fetchAll(PDO::FETCH_ASSOC);
        foreach($rows as &$r) { $r['rules']=staffPolicy(json_decode($r['rules_json'],true,512,JSON_THROW_ON_ERROR)); unset($r['rules_json']); }
        return $rows;
    }
    private function policy(string $date, ?int $teacherId=null): array
    {
        $found=staffEffectivePolicy($this->policies(),$teacherId?$this->teacherRules($teacherId):[],$date);
        if(!$found) throw new StaffAttendanceDenied('The school has not configured attendance rules for this date.');
        return $found;
    }
    public function teacherRules(?int $id=null): array
    {
        $rows=$this->q('SELECT * FROM staff_attendance_teacher_rules'.($id?' WHERE teacher_id = ?':'').' ORDER BY effective_date, id',$id?[$id]:[])->fetchAll(PDO::FETCH_ASSOC);
        foreach($rows as &$r) { $r['overrides']=json_decode($r['overrides_json'],true,32,JSON_THROW_ON_ERROR); unset($r['overrides_json']); }
        return $rows;
    }
    public function teacherSettings(int $id, string $date): array
    {
        $teacher=$this->teacher($id); $p=$this->policy($date,$id);
        $calendar=$this->q('SELECT * FROM staff_attendance_calendar WHERE work_date = ?',[$date])->fetch(PDO::FETCH_ASSOC) ?: null;
        return ['teacher_id'=>$id,'teacher_name'=>$teacher['name'],'date'=>$date,'policy'=>$p,
            'schedule'=>staffSchedule($p['rules'],$date,$calendar),
            'school_policy'=>$this->policy($date),'teacher_rules'=>$this->teacherRules($id),
            'salary_terms'=>$this->q('SELECT * FROM staff_salary_terms WHERE teacher_id = ? AND effective_date <= ? ORDER BY effective_date, id',[$id,'2100-12-31'])->fetchAll(PDO::FETCH_ASSOC)];
    }
    public function saveTeacherRules(array $input): void
    {
        $id=$this->id($input); $date=staffDate($input['effective_date']??null);
        $end=empty($input['end_date'])?null:staffDate($input['end_date']); $reason=staffReason($input['reason']??null);
        if($end && $end < $date) throw new InvalidArgumentException('The last date must not precede the first date.');
        if(!isset($input['overrides']) || !is_array($input['overrides'])) throw new InvalidArgumentException('Choose personal settings or use school defaults.');
        $this->transaction(function() use($input,$id,$date,$end,$reason) {
            $this->teacher($id);
            // A version supersedes the previous version from its start, including after expiry.
            if($this->q("SELECT 1 FROM staff_payroll_months WHERE teacher_id = ? AND payroll_month >= ? AND state <> 'reopened' LIMIT 1",[$id,substr($date,0,7)])->fetchColumn()) throw new StaffAttendanceConflict('Reopen affected salary months before changing personal attendance rules.');
            $school=$this->policy($date); $overrides=staffTeacherOverrides($input['overrides'],$school['rules']);
            $old=$this->teacherRules($id);
            $next=['id'=>PHP_INT_MAX,'teacher_id'=>$id,'effective_date'=>$date,'end_date'=>$end,'overrides'=>$overrides];
            staffValidateRuleTimeline($this->policies(),array_merge($old,[$next]));
            $this->q('INSERT INTO staff_attendance_teacher_rules (teacher_id,effective_date,end_date,overrides_json,created_by,reason,created_at) VALUES (?,?,?,?,?,?,?)',[$id,$date,$end,json_encode($overrides,JSON_THROW_ON_ERROR),$this->actorId,$reason,$this->utc()]);
            $next['id']=(int)$this->pdo->lastInsertId();
            $this->q("UPDATE staff_attendance_days SET review_status = 'pending', version = version + 1 WHERE teacher_id = ? AND work_date >= ?",[$id,$date]);
            $this->q("UPDATE staff_attendance_challenges SET state = 'cancelled' WHERE teacher_id = ? AND state IN ('issued','processing')",[$id]);
            $this->audit('teacher_rules_created',$id,(string)$next['id'],$reason,$old,$next);
        });
    }
    private function teacher(int $id, bool $active=false): array
    {
        $t=$this->q('SELECT id, name, monthly_salary, joining_date, status FROM teachers WHERE id = ?',[$id])->fetch(PDO::FETCH_ASSOC);
        if(!$t || in_array($t['status'],['pending','reject'],true) || ($active && $t['status'] !== 'active')) throw new StaffAttendanceDenied('Teacher account is not active or is unavailable.');
        return $t;
    }
    private function openMonth(int $id, string $month): void
    {
        $r=$this->q('SELECT state FROM staff_payroll_months WHERE teacher_id = ? AND payroll_month = ?',[$id,$month])->fetchColumn();
        if($r && $r !== 'reopened') throw new StaffAttendanceConflict('This salary month is locked. Reopen it before making changes.');
    }
    private function day(int $id, string $date): ?array
    {
        return $this->q('SELECT * FROM staff_attendance_days WHERE teacher_id = ? AND work_date = ?',[$id,$date])->fetch(PDO::FETCH_ASSOC) ?: null;
    }
    private function audit(string $action, ?int $id, string $ref, string $reason, mixed $before, mixed $after): void
    {
        $this->q('INSERT INTO staff_attendance_audit (actor_id,action_name,teacher_id,reference_key,reason,before_json,after_json,created_at) VALUES (?,?,?,?,?,?,?,?)',
            [$this->actorId,$action,$id,$ref,$reason,json_encode($before,JSON_THROW_ON_ERROR),json_encode($after,JSON_THROW_ON_ERROR),$this->utc()]);
    }
    public function adminContext(): array
    {
        $teachers=$this->q("SELECT id,name,joining_date,status FROM teachers WHERE status NOT IN ('pending','reject') ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
        return ['teachers'=>$teachers,'policies'=>$this->policies(),'defaults'=>staffDefaults(), 'timezone'=>$this->zone->getName(), 'today'=>$this->today(),
            'calendar'=>$this->q('SELECT * FROM staff_attendance_calendar ORDER BY work_date DESC LIMIT 200')->fetchAll(PDO::FETCH_ASSOC)];
    }
    public function savePolicy(array $input): array
    {
        $date=staffDate($input['effective_date']??null); $rules=staffPolicy($input['rules']??[]); $reason=staffReason($input['reason']??null);
        if($rules['timezone'] !== $this->zone->getName()) throw new InvalidArgumentException('Use the time zone configured in Website Configuration.');
        return $this->transaction(function() use($date,$rules,$reason) {
            $old=$this->policies();
            // Immutable forward-dated revisions prevent silent changes to historical pay.
            if($old && $date <= $this->today()) throw new InvalidArgumentException('New rule versions must start tomorrow or later. Only the initial version may be backdated for manually entered attendance.');
            $next=array_merge($old,[['id'=>PHP_INT_MAX,'effective_date'=>$date,'rules'=>$rules]]);
            $byTeacher=[]; foreach($this->teacherRules() as $v) $byTeacher[$v['teacher_id']][]=$v;
            foreach($byTeacher as $versions) staffValidateRuleTimeline($next,$versions);
            $this->q('INSERT INTO staff_attendance_policies (effective_date,rules_json,created_by,reason,created_at) VALUES (?,?,?,?,?)',[$date,json_encode($rules),$this->actorId,$reason,$this->utc()]);
            $id=(int)$this->pdo->lastInsertId(); $this->audit('policy_created',null,(string)$id,$reason,null,['effective_date'=>$date,'rules'=>$rules]);
            return ['id'=>$id];
        });
    }
    public function saveCalendar(array $input): void
    {
        $date=staffDate($input['date']??null); $kind=$input['kind']??''; $reason=staffReason($input['reason']??null);
        if(!in_array($kind,['working','holiday','default'],true)) throw new InvalidArgumentException('Invalid calendar day.');
        $this->transaction(function() use($date,$kind,$reason) {
            if($this->q("SELECT 1 FROM staff_payroll_months WHERE payroll_month = ? AND state <> 'reopened' LIMIT 1",[substr($date,0,7)])->fetchColumn()) throw new StaffAttendanceConflict('A teacher salary is locked for this month. Reopen all affected salaries first.');
            $old=$this->q('SELECT * FROM staff_attendance_calendar WHERE work_date = ?',[$date])->fetch(PDO::FETCH_ASSOC);
            if($kind === 'default') $this->q('DELETE FROM staff_attendance_calendar WHERE work_date = ?',[$date]);
            else $this->q('INSERT INTO staff_attendance_calendar (work_date,kind,reason) VALUES (?,?,?) ON DUPLICATE KEY UPDATE kind=VALUES(kind), reason=VALUES(reason)',[$date,$kind,$reason]);
            // Changes require a new review of any existing punches for the date.
            $this->q("UPDATE staff_attendance_days SET review_status = 'pending', version = version + 1 WHERE work_date = ?",[$date]);
            $this->audit('calendar_changed',null,$date,$reason,$old,['kind'=>$kind]);
        });
    }
    public function saveSalary(array $input): void
    {
        $id=$this->id($input); $date=staffDate($input['effective_date']??null); $salary=staffMoney($input['salary']??null); $reason=staffReason($input['reason']??null);
        $end=empty($input['employment_end'])?null:staffDate($input['employment_end']);
        if($end && $end < $date) throw new InvalidArgumentException('Employment end must not precede the term start.');
        $this->transaction(function() use($id,$date,$salary,$reason,$end) {
            $this->teacher($id);
            if($this->q("SELECT 1 FROM staff_payroll_months WHERE teacher_id = ? AND payroll_month >= ? AND state <> 'reopened' LIMIT 1",[$id,substr($date,0,7)])->fetchColumn()) throw new StaffAttendanceConflict('Reopen affected salary months before changing historical salary terms.');
            $this->q('INSERT INTO staff_salary_terms (teacher_id,effective_date,salary_paise,employment_end,created_by,reason,created_at) VALUES (?,?,?,?,?,?,?)',[$id,$date,$salary,$end,$this->actorId,$reason,$this->utc()]);
            $this->audit('salary_term_created',$id,$date,$reason,null,['salary_paise'=>$salary,'employment_end'=>$end]);
        });
    }
    public function id(array $input): int { return staffInteger($input['teacher_id']??null,1,2147483647,'Teacher ID'); }
    public function resetDevice(array $input): void
    {
        $id=$this->id($input); $reason=staffReason($input['reason']??null);
        $this->transaction(function() use($id,$reason) {
            $this->teacher($id); $old=$this->q('SELECT * FROM staff_attendance_devices WHERE teacher_id = ?',[$id])->fetch(PDO::FETCH_ASSOC);
            $this->q('DELETE FROM staff_attendance_devices WHERE teacher_id = ?',[$id]);
            $this->q("UPDATE staff_attendance_challenges SET state = 'cancelled' WHERE teacher_id = ? AND state IN ('issued','processing')",[$id]);
            $this->audit('device_reset',$id,(string)$id,$reason,$old,null);
        });
    }
    private function mobile(array $auth): string
    {
        if(($auth['session_source']??'') !== 'mobile' || empty($auth['device_id'])) throw new StaffAttendanceDenied('Use the signed-in Teacher App to mark attendance.');
        return hash('sha256',(string)$auth['device_id']);
    }
    private function punchAllowed(int $id, string $date, string $type, array $policy): void
    {
        if(!in_array($type,['in','out'],true)) throw new InvalidArgumentException('Choose arrival or departure.');
        if($policy['rules']['timezone'] !== $this->zone->getName()) throw new StaffAttendanceDenied('The school time zone changed. Ask the administrator to configure a matching attendance rule version.');
        $this->teacher($id,true); $this->openMonth($id,substr($date,0,7));
        $calendar=$this->q('SELECT * FROM staff_attendance_calendar WHERE work_date = ?',[$date])->fetch(PDO::FETCH_ASSOC) ?: null;
        $r=staffSchedule($policy['rules'],$date,$calendar);
        if(!$r['working']) throw new StaffAttendanceDenied('Attendance is disabled or this is a non-working day.');
        $day=$this->day($id,$date); $time=(new DateTimeImmutable('now',$this->zone))->format('H:i');
        if($day && ($day['override_status'] || $day['review_status'] === 'rejected')) throw new StaffAttendanceConflict('Ask the administrator to resolve this day before punching again.');
        if($type === 'in') {
            if(!empty($day['check_in'])) throw new StaffAttendanceConflict('Arrival is already recorded.');
            if($time < $r['checkin_open'] || $time > $r['checkin_close']) throw new StaffAttendanceDenied('Arrival is outside the school attendance window.');
        } else {
            if(empty($day['check_in'])) throw new StaffAttendanceConflict('Record arrival before departure.');
            if(!empty($day['check_out'])) throw new StaffAttendanceConflict('Departure is already recorded.');
            if($time > $r['checkout_close']) throw new StaffAttendanceDenied('The departure window has closed. Ask the administrator for a correction.');
        }
    }
    public function begin(array $auth, array $input): array
    {
        if (($input['camera_protocol'] ?? null) !== 2) throw new StaffAttendanceDenied('Update the teacher app before recording attendance. The current camera checks are required.');
        $device=$this->mobile($auth); $id=(int)$auth['teacher_id']; $date=$this->today(); $type=$input['punch_type']??'';
        return $this->transaction(function() use($auth,$input,$id,$date,$type,$device) {
            $p=$this->policy($date,$id); $this->punchAllowed($id,$date,$type,$p); $location=staffLocation($input['location']??[],$p['rules']);
            $enrolled=$this->q('SELECT device_hash FROM staff_attendance_devices WHERE teacher_id = ?',[$id])->fetchColumn();
            if($enrolled && !hash_equals($enrolled,$device)) throw new StaffAttendanceDenied('Your attendance phone has changed. Ask the administrator to reset it.');
            if(!$enrolled) {
                if($this->q('SELECT teacher_id FROM staff_attendance_devices WHERE device_hash = ?',[$device])->fetchColumn()) throw new StaffAttendanceDenied('This attendance phone is already registered to another teacher.');
                $this->q('INSERT INTO staff_attendance_devices (teacher_id,device_hash,enrolled_at) VALUES (?,?,?)',[$id,$device,$this->utc()]);
            }
            $minute=gmdate('Y-m-d H:i:s',time()-60); $dayStart=gmdate('Y-m-d H:i:s',time()-86400);
            if((int)$this->q('SELECT COUNT(*) FROM staff_attendance_challenges WHERE teacher_id = ? AND issued_at >= ?',[$id,$minute])->fetchColumn() >= 3
                || (int)$this->q('SELECT COUNT(*) FROM staff_attendance_challenges WHERE teacher_id = ? AND issued_at >= ?',[$id,$dayStart])->fetchColumn() >= 40) throw new StaffAttendanceDenied('Too many capture attempts. Wait before retrying or contact the administrator.');
            if($this->q("SELECT 1 FROM staff_attendance_challenges WHERE teacher_id = ? AND state = 'processing' AND processing_at > ? LIMIT 1",[$id,gmdate('Y-m-d H:i:s',time()-90)])->fetchColumn()) throw new StaffAttendanceConflict('A selfie upload is still processing. Reload your attendance first.');
            $this->q("UPDATE staff_attendance_challenges SET state = 'cancelled' WHERE teacher_id = ? AND state IN ('issued','processing')",[$id]);
            $mode=$p['rules']['selfie_mode'];
            $steps=staffSteps(random_int(1,2),random_int(0,1),$mode); $challenge=bin2hex(random_bytes(16)); $expires=gmdate('Y-m-d H:i:s',time()+120);
            $this->q('INSERT INTO staff_attendance_challenges (id,teacher_id,auth_session_id,policy_id,work_date,punch_type,steps_json,location_json,issued_at,expires_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
                [$challenge,$id,$auth['session_id'],$p['id'],$date,$type,json_encode($steps),json_encode($location),$this->utc(),$expires]);
            return ['challenge_id'=>$challenge,'steps'=>$steps,'selfie_mode'=>$mode,'camera_protocol'=>2,'face_uncovered_required'=>true,'expires_in_seconds'=>120,'spot_instructions'=>$p['rules']['spot_instructions']];
        });
    }
    public function finish(array $auth, array $input): array
    {
        $device=$this->mobile($auth); $id=(int)$auth['teacher_id']; $nonce=$input['challenge_id']??'';
        if(!is_string($nonce) || !preg_match('/^[a-f0-9]{32}$/D',$nonce)) throw new InvalidArgumentException('Invalid capture challenge.');
        $reserved=$this->transaction(function() use($auth,$input,$nonce,$id,$device) {
            $c=$this->q('SELECT * FROM staff_attendance_challenges WHERE id = ? AND teacher_id = ?',[$nonce,$id])->fetch(PDO::FETCH_ASSOC);
            if(!$c || (int)$c['auth_session_id'] !== (int)$auth['session_id']) throw new StaffAttendanceDenied('This challenge belongs to a different login. Start again.');
            if($c['state'] === 'consumed' && $c['event_id']) return ['already_saved'=>true,'event_id'=>(int)$c['event_id']];
            if($c['state'] !== 'issued' || $c['expires_at'] < $this->utc() || $c['work_date'] !== $this->today()) throw new StaffAttendanceConflict('This challenge expired or is already processing. Reload attendance and start a new capture if needed.');
            if($this->q('SELECT device_hash FROM staff_attendance_devices WHERE teacher_id = ?',[$id])->fetchColumn() !== $device) throw new StaffAttendanceDenied('Attendance phone registration changed.');
            $p=$this->policy($c['work_date'],$id);
            if((int)$p['id'] !== (int)$c['policy_id']) throw new StaffAttendanceConflict('School rules changed. Start again.');
            $this->punchAllowed($id,$c['work_date'],$c['punch_type'],$p);
            $loc=staffLocation($input['location']??[],$p['rules']);
            $elapsed=(time()-(new DateTimeImmutable($c['issued_at'],new DateTimeZone('UTC')))->getTimestamp())*1000;
            $proof=staffProof($input['proof']??[],json_decode($c['steps_json'],true),$elapsed,$p['rules']['selfie_mode']);
            $selfie=staffCameraImage($input['selfie']??null); $evidence=staffCameraImage($input['evidence']??null,true);
            $hash=hash('sha256',$selfie);
            if(hash_equals($hash,hash('sha256',$evidence))) throw new StaffAttendanceDenied('The selfie and challenge evidence must be distinct images.');
            if($this->q('SELECT 1 FROM staff_attendance_events WHERE selfie_hash = ? LIMIT 1',[$hash])->fetchColumn()) throw new StaffAttendanceDenied('This exact selfie has already been used. Capture a new live selfie.');
            $occurredAt=$this->utc();
            $this->q("UPDATE staff_attendance_challenges SET state = 'processing', processing_at = ? WHERE id = ?",[$occurredAt,$nonce]);
            return compact('c','loc','proof','selfie','evidence','hash') + ['occurred_at'=>$occurredAt];
        });
        if(isset($reserved['already_saved'])) return $reserved;
        $selfResult=$evidenceResult=null;
        try {
            $upload=$this->uploader ?? 'uploadBytesToImgBB';
            $selfResult=$upload($reserved['selfie'],'attendance-'.bin2hex(random_bytes(12)).'.jpg');
            $this->validUpload($selfResult);
            $evidenceResult=$upload($reserved['evidence'],'challenge-'.bin2hex(random_bytes(12)).'.jpg');
            $this->validUpload($evidenceResult);
            return $this->transaction(function() use($auth,$id,$nonce,$device,$reserved,$selfResult,$evidenceResult) {
                $c=$this->q('SELECT * FROM staff_attendance_challenges WHERE id = ?',[$nonce])->fetch(PDO::FETCH_ASSOC);
                if(!$c || $c['state'] !== 'processing' || $c['processing_at'] !== $reserved['occurred_at']) throw new StaffAttendanceConflict('Capture was cancelled. Start again.');
                $p=$this->policy($c['work_date'],$id); $this->teacher($id,true); $this->openMonth($id,substr($c['work_date'],0,7));
                if($this->q('SELECT device_hash FROM staff_attendance_devices WHERE teacher_id = ?',[$id])->fetchColumn() !== $device) throw new StaffAttendanceConflict('Phone registration changed during upload.');
                if((int)$p['id'] !== (int)$c['policy_id']) throw new StaffAttendanceConflict('Rules changed during upload.');
                $day=$this->day($id,$c['work_date']);
                if($day && ($day['override_status'] || $day['review_status'] === 'rejected')) throw new StaffAttendanceConflict('Administrator changed this day during upload.');
                if(!empty($day[$c['punch_type'] === 'in' ? 'check_in' : 'check_out'])) throw new StaffAttendanceConflict('This attendance was already recorded.');
                if($c['punch_type'] === 'out' && (empty($day['check_in']) || $day['check_in'] >= $reserved['occurred_at'])) throw new StaffAttendanceConflict('Arrival must precede departure.');
                $this->q('INSERT INTO staff_attendance_events (challenge_id,teacher_id,work_date,punch_type,occurred_at,selfie_url,evidence_url,selfie_delete_url,evidence_delete_url,selfie_hash,evidence_hash,proof_json,location_json,device_hash) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                    [$nonce,$id,$c['work_date'],$c['punch_type'],$reserved['occurred_at'],$selfResult['url'],$evidenceResult['url'],$selfResult['delete_url'],$evidenceResult['delete_url'],$reserved['hash'],hash('sha256',$reserved['evidence']),json_encode($reserved['proof']),json_encode($reserved['loc']),$device]);
                $event=(int)$this->pdo->lastInsertId();
                if($c['punch_type'] === 'in') $this->q("INSERT INTO staff_attendance_days (teacher_id,work_date,policy_id,check_in,in_event_id) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE check_in=VALUES(check_in),in_event_id=VALUES(in_event_id),review_status='pending',version=version+1",[$id,$c['work_date'],$c['policy_id'],$reserved['occurred_at'],$event]);
                else $this->q("UPDATE staff_attendance_days SET check_out = ?, out_event_id = ?, review_status = 'pending', version = version + 1 WHERE teacher_id = ? AND work_date = ?",[$reserved['occurred_at'],$event,$id,$c['work_date']]);
                $this->q("UPDATE staff_attendance_challenges SET state = 'consumed', event_id = ? WHERE id = ?",[$event,$nonce]);
                return ['event_id'=>$event,'review_status'=>'pending'];
            });
        } catch(Throwable $e) {
            // Keep orphan deletion links private for the administrator; never retain image bytes.
            $this->transaction(function() use($id,$nonce,$selfResult,$evidenceResult) {
                $this->q("UPDATE staff_attendance_challenges SET state = 'failed' WHERE id = ? AND state = 'processing'",[$nonce]);
                if(!empty($selfResult['success']) || !empty($evidenceResult['success'])) $this->audit('orphan_upload',$id,$nonce,'Upload succeeded but attendance could not be saved',null,['selfie'=>$selfResult,'evidence'=>$evidenceResult]);
            });
            throw $e;
        }
    }
    private function validUpload(array $r): void
    {
        foreach(['url','delete_url'] as $key) {
            $url=$r[$key]??''; $host=parse_url($url,PHP_URL_HOST);
            if(empty($r['success']) || parse_url($url,PHP_URL_SCHEME) !== 'https' || !is_string($host)
                || !($host === 'ibb.co' || str_ends_with($host,'.ibb.co'))) throw new RuntimeException('ImgBB upload failed. Attendance was not recorded. Please retry.');
        }
    }
    private function teacherDayContext(int $id): array
    {
        $this->teacher($id,true); $date=$this->today(); $p=null;
        $calendar=null;
        try { $p=$this->policy($date,$id); } catch(StaffAttendanceDenied $e) {}
        if($p) {
            $calendar=$this->q('SELECT * FROM staff_attendance_calendar WHERE work_date = ?',[$date])->fetch(PDO::FETCH_ASSOC) ?: null;
            $schedule=staffSchedule($p['rules'],$date,$calendar);
            // This response is today's display policy, not a persisted revision.
            $p['rules']=array_replace($p['rules'],array_intersect_key($schedule,array_flip(staffShiftFields())));
            $p['rules']['enabled']=$schedule['working'];
        }
        $day=$this->day($id,$date);
        return ['teacher_id'=>$id,'today'=>$date,'policy'=>$p,'day'=>$day,
            'departure_reminder'=>staffDepartureReminder($date,$p['rules']??null,$day,$calendar)];
    }
    public function teacherReminderContext(int $id): array
    {
        $data=$this->teacherDayContext($id);
        // Background checks do not calculate payroll or return attendance photos.
        return array_intersect_key($data,array_flip(['teacher_id','today','departure_reminder']));
    }
    public function teacherContext(int $id, string $month): array
    {
        return $this->teacherDayContext($id)+['payroll'=>$this->payroll($id,$month)];
    }
    public function payroll(int $id, string $month, bool $live=false): array
    {
        staffMonth($month); $t=$this->teacher($id);
        $locked=$this->q('SELECT * FROM staff_payroll_months WHERE teacher_id = ? AND payroll_month = ?',[$id,$month])->fetch(PDO::FETCH_ASSOC);
        if(!$live && $locked && $locked['state'] !== 'reopened') {
            $r=json_decode($locked['snapshot_json'],true,512,JSON_THROW_ON_ERROR);
            return array_replace($r,['state'=>$locked['state'],'finalized_at'=>$locked['finalized_at'],'paid_at'=>$locked['paid_at'],'paid_reference'=>$locked['paid_reference']]);
        }
        $last=(new DateTimeImmutable($month.'-01'))->format('Y-m-t');
        $terms=$this->q('SELECT * FROM staff_salary_terms WHERE teacher_id = ? AND effective_date <= ? ORDER BY effective_date, id',[$id,$last])->fetchAll(PDO::FETCH_ASSOC);
        $days=[]; foreach($this->q('SELECT * FROM staff_attendance_days WHERE teacher_id = ? AND work_date BETWEEN ? AND ?',[$id,$month.'-01',$last])->fetchAll(PDO::FETCH_ASSOC) as $d) $days[$d['work_date']]=$d;
        $calendar=[]; foreach($this->q('SELECT * FROM staff_attendance_calendar WHERE work_date BETWEEN ? AND ?',[$month.'-01',$last])->fetchAll(PDO::FETCH_ASSOC) as $d) $calendar[$d['work_date']]=$d;
        $adjustments=$this->q('SELECT id,amount_paise,reason FROM staff_payroll_adjustments WHERE teacher_id = ? AND payroll_month = ? ORDER BY id',[$id,$month])->fetchAll(PDO::FETCH_ASSOC);
        $r=staffPayrollCalculate($month,$t,$this->policies(),$terms,$days,$calendar,$adjustments,$this->today(),$this->teacherRules($id));
        $r['review_pending']=count(array_filter($days,fn($day)=>$day['review_status']==='pending'));
        $r['salary_terms']=$terms; $r['state']=$locked?'reopened':'estimate';
        $r['calculation_hash']=hash('sha256',json_encode($r,JSON_THROW_ON_ERROR));
        return $r;
    }
    public function report(int $id, string $month): array
    {
        $r=$this->payroll($id,$month);
        $r['records']=$this->q('SELECT * FROM staff_attendance_days WHERE teacher_id = ? AND work_date BETWEEN ? AND ? ORDER BY work_date',[$id,$month.'-01',(new DateTimeImmutable($month.'-01'))->format('Y-m-t')])->fetchAll(PDO::FETCH_ASSOC);
        $r['events']=$this->q('SELECT id,work_date,punch_type,occurred_at,selfie_url,evidence_url,proof_json,location_json FROM staff_attendance_events WHERE teacher_id = ? AND work_date BETWEEN ? AND ? ORDER BY work_date,id',[$id,$month.'-01',(new DateTimeImmutable($month.'-01'))->format('Y-m-t')])->fetchAll(PDO::FETCH_ASSOC);
        $r['audit']=$this->q('SELECT * FROM staff_attendance_audit WHERE teacher_id = ? OR teacher_id IS NULL ORDER BY id DESC LIMIT 100',[$id])->fetchAll(PDO::FETCH_ASSOC);
        $r['review_locked']=(bool)$this->q("SELECT 1 FROM staff_payroll_months WHERE teacher_id = ? AND payroll_month = ? AND state <> 'reopened'",[$id,$month])->fetchColumn();
        $notes=[];
        foreach($this->q("SELECT reference_key,reason FROM staff_attendance_audit WHERE teacher_id = ? AND action_name = 'attendance_corrected' AND reference_key BETWEEN ? AND ? ORDER BY id",[$id,$month.'-01',(new DateTimeImmutable($month.'-01'))->format('Y-m-t')])->fetchAll(PDO::FETCH_ASSOC) as $note) $notes[$note['reference_key']]=$note['reason'];
        foreach($r['records'] as &$day) {
            $day['review_issue']=$this->batchReviewIssue($day,$r['events']);
            $day['correction_reason']=$notes[$day['work_date']]??null;
        }
        unset($day);
        return $r;
    }
    public function reviewQueue(string $month): array
    {
        $month=staffMonth($month); $last=(new DateTimeImmutable($month.'-01'))->format('Y-m-t');
        $teachers=$this->q("SELECT id,name,joining_date,status FROM teachers WHERE status NOT IN ('pending','reject') ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
        $queue=[];
        foreach($teachers as $t) $queue[$t['id']]=['teacher_id'=>(int)$t['id'],'teacher_name'=>$t['name'],'pending'=>0,'reviewed'=>0,'needs_attention'=>0,'locked'=>false];
        foreach($this->q('SELECT teacher_id,review_status,check_in,check_out,override_status FROM staff_attendance_days WHERE work_date BETWEEN ? AND ?',[$month.'-01',$last])->fetchAll(PDO::FETCH_ASSOC) as $day) {
            if(!isset($queue[$day['teacher_id']])) continue;
            $item=&$queue[$day['teacher_id']];
            if($day['review_status']==='pending') {
                $item['pending']++;
                if($day['override_status'] || !$day['check_in'] || !$day['check_out']) $item['needs_attention']++;
            } else $item['reviewed']++;
            unset($item);
        }
        foreach($this->q("SELECT teacher_id FROM staff_payroll_months WHERE payroll_month = ? AND state <> 'reopened'",[$month])->fetchAll(PDO::FETCH_ASSOC) as $locked) if(isset($queue[$locked['teacher_id']])) $queue[$locked['teacher_id']]['locked']=true;
        return ['month'=>$month,'teachers'=>array_values($queue)];
    }
    // Batch approval is reserved for complete app punches. Exceptions remain an individual review.
    private function batchReviewIssue(array $day, array $events): string
    {
        if($day['override_status']) return 'Admin correction / leave: review this day individually.';
        if(empty($day['check_in']) || empty($day['check_out'])) return 'Missing arrival / departure: correct this day first.';
        foreach(['in'=>'check_in','out'=>'check_out'] as $type=>$field) {
            $found=false;
            foreach($events as $event) {
                if($event['work_date']!==$day['work_date'] || $event['punch_type']!==$type || $event['occurred_at']!==$day[$field]) continue;
                foreach(['selfie_url','evidence_url'] as $key) {
                    $url=parse_url($event[$key]??''); $host=strtolower($url['host']??'');
                    if(($url['scheme']??'')!=='https' || !($host==='ibb.co' || str_ends_with($host,'.ibb.co')) || isset($url['user']) || isset($url['pass'])) continue 2;
                }
                $found=true; break;
            }
            if(!$found) return 'Missing app photo / evidence: review this day individually.';
        }
        return '';
    }
    public function reviewBatch(array $input): void
    {
        $id=$this->id($input); $month=staffMonth($input['month']??null); $reason=staffReason($input['reason']??null);
        $days=$input['days']??null;
        if(!is_array($days) || !array_is_list($days) || !count($days) || count($days)>31) throw new InvalidArgumentException('Select between 1 and 31 checked attendance days.');
        $dates=[];
        foreach($days as $day) {
            if(!is_array($day)) throw new InvalidArgumentException('Invalid review day.');
            $date=staffDate($day['date']??null);
            if(substr($date,0,7)!==$month || $date>$this->today() || isset($dates[$date])) throw new InvalidArgumentException('Select unique, non-future dates in the chosen month.');
            $dates[$date]=$day;
        }
        $this->transaction(function() use($id,$month,$reason,$dates) {
            $this->teacher($id); $this->openMonth($id,$month);
            $events=$this->q('SELECT work_date,punch_type,occurred_at,selfie_url,evidence_url FROM staff_attendance_events WHERE teacher_id = ? AND work_date BETWEEN ? AND ? ORDER BY id',[$id,$month.'-01',(new DateTimeImmutable($month.'-01'))->format('Y-m-t')])->fetchAll(PDO::FETCH_ASSOC);
            $checked=[];
            foreach($dates as $date=>$inputDay) {
                $old=$this->day($id,$date);
                if(!$old || $old['review_status']!=='pending') throw new StaffAttendanceConflict('A selected day is no longer pending. Reload before reviewing.');
                $this->revision($old,$inputDay);
                if($issue=$this->batchReviewIssue($old,$events)) throw new InvalidArgumentException($date.': '.$issue);
                $checked[$date]=$old;
            }
            foreach($checked as $date=>$old) {
                $this->q('UPDATE staff_attendance_days SET review_status = ?, version = version + 1 WHERE teacher_id = ? AND work_date = ?',['approved',$id,$date]);
                $this->audit('attendance_reviewed',$id,$date,$reason,$old,$this->day($id,$date));
            }
        });
    }
    public function correct(array $input): void
    {
        $id=$this->id($input); $date=staffDate($input['date']??null); $reason=staffReason($input['reason']??null);
        if($date > $this->today()) throw new InvalidArgumentException('Cannot correct future attendance.');
        $status=$input['status']??'';
        if(!in_array($status,['present','absent','paid_leave','unpaid_leave','restore'],true)) throw new InvalidArgumentException('Invalid attendance correction.');
        $this->transaction(function() use($input,$id,$date,$status,$reason) {
            $this->teacher($id); $this->openMonth($id,substr($date,0,7)); $p=$this->policy($date,$id); $old=$this->day($id,$date);
            $this->revision($old,$input);
            if($status === 'restore') {
                $events=$this->q('SELECT id,punch_type,occurred_at FROM staff_attendance_events WHERE teacher_id = ? AND work_date = ? ORDER BY id',[$id,$date])->fetchAll(PDO::FETCH_ASSOC);
                $in=$out=null; foreach($events as $event) { if($event['punch_type']==='in') $in=$event['occurred_at']; else $out=$event['occurred_at']; }
                $status=null;
            } else {
                $in=$out=null;
                if($status === 'present') {
                    $in=staffTime($input['check_in']??null); $out=staffTime($input['check_out']??null);
                    if($in >= $out) throw new InvalidArgumentException('Departure must be later than arrival.');
                    $in=(new DateTimeImmutable("$date $in",new DateTimeZone($p['rules']['timezone'])))->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
                    $out=(new DateTimeImmutable("$date $out",new DateTimeZone($p['rules']['timezone'])))->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
                    if($out > $this->utc()) throw new InvalidArgumentException('Cannot record a future departure time.');
                }
            }
            $this->q("INSERT INTO staff_attendance_days (teacher_id,work_date,policy_id,check_in,check_out,override_status,review_status) VALUES (?,?,?,?,?,?,'pending') ON DUPLICATE KEY UPDATE check_in=VALUES(check_in),check_out=VALUES(check_out),override_status=VALUES(override_status),review_status='pending',version=version+1",[$id,$date,$p['id'],$in,$out,$status]);
            $this->q("UPDATE staff_attendance_challenges SET state='cancelled' WHERE teacher_id=? AND work_date=? AND state IN ('issued','processing')",[$id,$date]);
            $this->audit('attendance_corrected',$id,$date,$reason,$old,$this->day($id,$date));
        });
    }
    private function revision(?array $old,array $input): void
    {
        $version=staffInteger($input['version']??null,0,2147483647,'Record version');
        if((int)$version !== (int)($old['version']??0)) throw new StaffAttendanceConflict('This record changed. Reload it before saving.');
    }
    public function review(array $input): void
    {
        $id=$this->id($input); $date=staffDate($input['date']??null); $reason=staffReason($input['reason']??null); $decision=$input['decision']??'';
        if(!in_array($decision,['approved','rejected'],true)) throw new InvalidArgumentException('Invalid review decision.');
        $this->transaction(function() use($input,$id,$date,$decision,$reason) {
            $this->openMonth($id,substr($date,0,7)); $old=$this->day($id,$date);
            if(!$old) throw new InvalidArgumentException('No attendance record to review.');
            $this->revision($old,$input);
            if($decision === 'approved' && !$old['override_status'] && (empty($old['check_in']) || empty($old['check_out']))) throw new InvalidArgumentException('Correct the missing arrival/departure before approving this day.');
            $this->q('UPDATE staff_attendance_days SET review_status = ?, version = version + 1 WHERE teacher_id = ? AND work_date = ?',[$decision,$id,$date]);
            $this->audit('attendance_reviewed',$id,$date,$reason,$old,$this->day($id,$date));
        });
    }
    public function adjust(array $input): void
    {
        $id=$this->id($input); $month=staffMonth($input['month']??null); $reason=staffReason($input['reason']??null); $amount=staffMoney($input['amount']??null);
        if(!in_array($input['kind']??'', ['addition','deduction'],true) || !$amount) throw new InvalidArgumentException('Choose an addition or deduction with a positive amount.');
        if($input['kind']==='deduction') $amount=-$amount;
        $this->transaction(function() use($id,$month,$reason,$amount) {
            $this->teacher($id); $this->openMonth($id,$month);
            $this->q('INSERT INTO staff_payroll_adjustments (teacher_id,payroll_month,amount_paise,reason,created_by,created_at) VALUES (?,?,?,?,?,?)',[$id,$month,$amount,$reason,$this->actorId,$this->utc()]);
            $this->audit('pay_adjustment',$id,$month,$reason,null,['amount_paise'=>$amount]);
        });
    }
    public function salaryAction(array $input): void
    {
        $id=$this->id($input); $month=staffMonth($input['month']??null); $reason=staffReason($input['reason']??null); $action=$input['action']??'';
        $this->transaction(function() use($input,$id,$month,$reason,$action) {
            $old=$this->q('SELECT * FROM staff_payroll_months WHERE teacher_id = ? AND payroll_month = ?',[$id,$month])->fetch(PDO::FETCH_ASSOC);
            if($action === 'finalize') {
                $this->openMonth($id,$month);
                if($month >= substr($this->today(),0,7)) throw new InvalidArgumentException('Finalize only after the month has ended.');
                $r=$this->payroll($id,$month,true);
                if(!is_string($input['calculation_hash']??null) || !hash_equals($r['calculation_hash'],$input['calculation_hash'])) throw new StaffAttendanceConflict('The salary calculation changed. Reload and review it before finalizing.');
                $pending=$this->q("SELECT COUNT(*) FROM staff_attendance_days WHERE teacher_id=? AND work_date BETWEEN ? AND ? AND review_status='pending'",[$id,$month.'-01',(new DateTimeImmutable($month.'-01'))->format('Y-m-t')])->fetchColumn();
                if($pending) throw new StaffAttendanceConflict('Review every saved attendance day, including corrections, before finalizing salary.');
                if(!$r['salary_terms'] || !array_filter($r['days'],fn($d)=>$d['status']!=='not_covered')) throw new InvalidArgumentException('Configure salary terms and attendance rules before finalization.');
                if($this->q("SELECT 1 FROM staff_attendance_challenges WHERE teacher_id=? AND work_date BETWEEN ? AND ? AND state='processing' AND processing_at > ? LIMIT 1",[$id,$month.'-01',(new DateTimeImmutable($month.'-01'))->format('Y-m-t'),gmdate('Y-m-d H:i:s',time()-90)])->fetchColumn()) throw new StaffAttendanceConflict('Wait for an attendance upload to finish.');
                $r['state']='finalized'; $snapshot=json_encode($r,JSON_THROW_ON_ERROR);
                $this->q("INSERT INTO staff_payroll_months (teacher_id,payroll_month,state,snapshot_json,finalized_by,finalized_at) VALUES (?,?,'finalized',?,?,?) ON DUPLICATE KEY UPDATE state='finalized',snapshot_json=VALUES(snapshot_json),finalized_by=VALUES(finalized_by),finalized_at=VALUES(finalized_at),paid_at=NULL,paid_reference=NULL",[$id,$month,$snapshot,$this->actorId,$this->utc()]);
                $this->audit('payroll_finalized',$id,$month,$reason,$old,$r);
            } elseif($action === 'reopen') {
                if(!$old || $old['state']==='reopened') throw new InvalidArgumentException('No locked salary to reopen.');
                $this->q("UPDATE staff_payroll_months SET state='reopened' WHERE teacher_id=? AND payroll_month=?",[$id,$month]);
                $this->audit('payroll_reopened',$id,$month,$reason,$old,['state'=>'reopened']);
            } elseif($action === 'paid') {
                if(!$old || $old['state'] !== 'finalized') throw new InvalidArgumentException('Finalize this salary before marking it paid.');
                $reference=staffReason($input['reference']??null);
                if(strlen($reference)>200) throw new InvalidArgumentException('Payment reference is too long.');
                $this->q("UPDATE staff_payroll_months SET state='paid',paid_reference=?,paid_at=? WHERE teacher_id=? AND payroll_month=?",[$reference,$this->utc(),$id,$month]);
                $this->audit('payroll_paid',$id,$month,$reason,$old,['reference'=>$reference]);
            } else throw new InvalidArgumentException('Invalid salary action.');
        });
    }
    public function paymentReport(string $month, string $basis = 'salary_month'): array
    {
        $period=staffPaymentPeriod($month,$basis,$this->zone);
        $where=$basis==='salary_month'?'a.reference_key = ?':'a.created_at >= ? AND a.created_at < ?';
        $params=$basis==='salary_month'?[$month]:[$period['start_utc'],$period['end_utc']];
        $entries=$this->q("SELECT a.id,a.teacher_id,a.reference_key,a.reason,a.before_json,a.after_json,a.created_at,p.state AS current_state,p.paid_reference AS current_reference
            FROM staff_attendance_audit a LEFT JOIN staff_payroll_months p ON p.teacher_id=a.teacher_id AND p.payroll_month=a.reference_key
            WHERE a.action_name='payroll_paid' AND $where ORDER BY a.created_at,a.id",$params)->fetchAll(PDO::FETCH_ASSOC);
        return staffPaymentReport($entries,$month,$basis,$this->zone,$this->utc());
    }
    public function paymentOverview(?DateTimeImmutable $asOf = null): array
    {
        $asOf??=new DateTimeImmutable('now',new DateTimeZone('UTC'));
        $period=staffPaymentOverviewPeriod($asOf,$this->zone);
        $entries=$this->q("SELECT a.id,a.teacher_id,a.reference_key,a.reason,a.before_json,a.after_json,a.created_at,p.state AS current_state,p.paid_reference AS current_reference
            FROM staff_attendance_audit a LEFT JOIN staff_payroll_months p ON p.teacher_id=a.teacher_id AND p.payroll_month=a.reference_key
            WHERE a.action_name='payroll_paid' AND a.created_at >= ? AND a.created_at <= ? ORDER BY a.created_at,a.id",
            [$period['start_utc'],$period['as_of_utc']])->fetchAll(PDO::FETCH_ASSOC);
        return staffPaymentOverview($entries,$asOf,$this->zone);
    }
}
