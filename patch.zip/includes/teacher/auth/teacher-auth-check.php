<?php
include_once __DIR__ . '/../../config.php';

/**
 * Authenticates a teacher request from either Mobile (Bearer Token) or Web (Cookie).
 *
 * @param PDO $pdo The database connection.
 * @return array|null The authenticated teacher/session data, or null if not authenticated.
 */
function getAuthenticatedTeacher($pdo)
{
    $token = null;
    $headers = getallheaders();

    // 1. Check for Mobile App's Bearer Token
    if (!empty($headers['Authentication']) && strpos($headers['Authentication'], 'Bearer ') === 0) {
        $token = str_replace('Bearer ', '', $headers['Authentication']);
    }

    // 2. If no Bearer token, check for Web's Auth Cookie
    if (empty($token) && !empty($_COOKIE['teacher_auth_token'])) {
        $token = $_COOKIE['teacher_auth_token'];
    }

    // 3. If no token found, user is not logged in
    if (empty($token)) {
        return null;
    }

    // 4. Validate the token against the database
    $tokenHash = hash('sha256', $token);
    $currentDateTime = date('Y-m-d H:i:s');

    // Use the NEW table name 'teacher_auth_sessions'
    $stmt = $pdo->prepare("SELECT 
                                t.*, 
                                tas.id AS session_id, 
                                tas.teacher_id, 
                                tas.token_hash, 
                                tas.device_id, 
                                tas.device_name, 
                                tas.fcm_token, 
                                tas.session_source, 
                                tas.ip_address, 
                                tas.app_version, 
                                tas.created_at AS session_created_at,
                                tas.last_activity
                            FROM teachers t
                            JOIN teacher_auth_sessions tas ON t.id = tas.teacher_id
                            WHERE tas.token_hash = ?;");
    $stmt->execute([$tokenHash]);
    $session = $stmt->fetch();

    if (!$session) {
        return null; // Invalid or expired token
    }

    // Return all relevant teacher and session data
    return [
        'success' => true,
        'message' => 'Token successfully validated',
        'teacher_id' => $session['teacher_id'],
        'phone_number' => $session['phone'],
        'session_id' => $session['session_id'],
        'device_id' => $session['device_id'],
        'device_name' => $session['device_name'] ?? "Unknown Device",
        'ip_address' => $session['ip_address'],
        'session_source' => $session['session_source']
    ];
}

/**
 * A helper function for protected API endpoints (Mobile or Web AJAX).
 * It calls getAuthenticatedTeacher and exits with a 401 error if auth fails.
 *
 * @param PDO $pdo
 * @return array The authenticated teacher data.
 */
function authenticateApiRequest($pdo)
{
    $authData = getAuthenticatedTeacher($pdo);

    if (!$authData) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Unauthorized: Invalid or expired token']);
        exit;
    }

    return $authData;
}