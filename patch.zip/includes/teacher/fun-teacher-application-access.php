<?php

/**
 * Helpers shared by the public "track / edit my teacher application" flow.
 *
 * Teacher applications live in the `teachers` table (status = pending | reject |
 * archive until an admin decides). An applicant proves ownership of a row with
 * three matching values - application id + email + date of birth - and that
 * grants a short-lived session for viewing the status and, while the
 * application is still pending, editing it.
 */

// How long a verified applicant session stays usable without activity.
if (!defined('TEACHER_APPLICATION_ACCESS_TTL')) {
    define('TEACHER_APPLICATION_ACCESS_TTL', 1800); // 30 minutes
}

// Session key holding the verified application id + last activity timestamp.
if (!defined('TEACHER_APPLICATION_ACCESS_KEY')) {
    define('TEACHER_APPLICATION_ACCESS_KEY', 'teacher_application_access');
}

/**
 * Human-facing reference the applicant sees and types back in (e.g. TA0039).
 */
function formatTeacherApplicationRef(int $applicationId): string
{
    return 'TA' . str_pad((string) $applicationId, 4, '0', STR_PAD_LEFT);
}

/**
 * Turn whatever the applicant typed ("TA0039", "ta 39", "39") into a plain id.
 * Returns null when nothing usable was supplied.
 */
function parseTeacherApplicationRef(?string $reference): ?int
{
    if ($reference === null) {
        return null;
    }

    $digits = preg_replace('/\D+/', '', $reference);

    if ($digits === '' || $digits === null) {
        return null;
    }

    $applicationId = (int) $digits;

    return $applicationId > 0 ? $applicationId : null;
}

/**
 * Mark the current visitor as the owner of this application.
 */
function grantTeacherApplicationAccess(int $applicationId): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $_SESSION[TEACHER_APPLICATION_ACCESS_KEY] = [
        'application_id' => $applicationId,
        'last_active_at' => time(),
    ];
}

/**
 * Drop the applicant session (explicit sign-out, or a failed re-check).
 */
function revokeTeacherApplicationAccess(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    unset($_SESSION[TEACHER_APPLICATION_ACCESS_KEY]);
}

/**
 * Id of the application the visitor has already verified, or null when there is
 * no live session. Sliding expiry: every successful call extends the window.
 */
function verifiedTeacherApplicationId(): ?int
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $access = $_SESSION[TEACHER_APPLICATION_ACCESS_KEY] ?? null;

    if (!is_array($access) || empty($access['application_id'])) {
        return null;
    }

    $lastActive = (int) ($access['last_active_at'] ?? 0);

    if ($lastActive <= 0 || (time() - $lastActive) > TEACHER_APPLICATION_ACCESS_TTL) {
        revokeTeacherApplicationAccess();
        return null;
    }

    $_SESSION[TEACHER_APPLICATION_ACCESS_KEY]['last_active_at'] = time();

    return (int) $access['application_id'];
}

/**
 * Load the verified application row, or null when the session is dead / the row
 * has since been deleted by the admin.
 *
 * @return array<string, mixed>|null
 */
function fetchVerifiedTeacherApplication(PDO $pdo): ?array
{
    $applicationId = verifiedTeacherApplicationId();

    if ($applicationId === null) {
        return null;
    }

    $stmt = $pdo->prepare("SELECT * FROM teachers WHERE id = ? LIMIT 1");
    $stmt->execute([$applicationId]);
    $application = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$application) {
        revokeTeacherApplicationAccess();
        return null;
    }

    $documents = json_decode($application['documents'] ?? '[]', true);
    $application['documents'] = is_array($documents) ? $documents : [];

    return $application;
}

/**
 * Only a pending application is still the applicant's to change - once the
 * school has acted on it, the record is theirs to read but not to rewrite.
 */
function isTeacherApplicationEditable(?string $status): bool
{
    return $status === 'pending';
}

/**
 * Applicant-facing presentation for every status the record can hold.
 *
 * @return array{label: string, badge: string, icon: string, description: string}
 */
function teacherApplicationStatusMeta(?string $status): array
{
    switch ($status) {
        case 'pending':
            return [
                'label' => 'Under Review',
                'badge' => 'warning',
                'icon' => 'fa-hourglass-half',
                'description' => 'Your application has been received and is waiting for a decision from the school. You can still correct any detail while it stays in this stage.',
            ];

        case 'archive':
            return [
                'label' => 'On Hold',
                'badge' => 'info',
                'icon' => 'fa-box-archive',
                'description' => 'The school has kept your application on file for future consideration. It can no longer be edited, but it has not been rejected.',
            ];

        case 'reject':
            return [
                'label' => 'Not Selected',
                'badge' => 'danger',
                'icon' => 'fa-circle-xmark',
                'description' => 'The school was unable to offer you a position from this application. You are welcome to apply again when a new opening is announced.',
            ];

        case 'active':
            return [
                'label' => 'Approved',
                'badge' => 'success',
                'icon' => 'fa-circle-check',
                'description' => 'Congratulations! Your application was approved and you are now on the teaching staff. Please contact the school office to complete your onboarding.',
            ];

        case 'inactive':
            return [
                'label' => 'Approved (Currently Inactive)',
                'badge' => 'secondary',
                'icon' => 'fa-user-slash',
                'description' => 'Your application was approved earlier, but your staff record is currently marked inactive. Please contact the school office for details.',
            ];

        default:
            return [
                'label' => 'Unknown',
                'badge' => 'secondary',
                'icon' => 'fa-circle-question',
                'description' => 'The current stage of this application could not be determined. Please contact the school office.',
            ];
    }
}
