<?php
require_once __DIR__ . '/teacher-academic-context.php';
require_once __DIR__ . '/../academic/fun-academic-functions.php';

class TeacherMarksDenied extends RuntimeException {}

function teacherMarksNumber(mixed $value, float $maximum): float
{
    if ((!is_string($value) && !is_int($value) && !is_float($value))
        || !preg_match('/^\d{1,4}(?:\.\d{1,2})?$/D', (string)$value)
        || (float)$value > $maximum) {
        throw new InvalidArgumentException('Enter a mark between 0 and ' . $maximum . ' with at most two decimal places.');
    }
    return (float)$value;
}

function teacherMarksTotals(array $marks): array
{
    $total = $obtained = $minorTotal = $minorObtained = 0.0;
    foreach ($marks as $mark) {
        if ((int)$mark['is_excluded'] === 1) continue;
        $total += (float)$mark['total_marks'];
        $obtained += (float)$mark['obtained_marks'];
        if (strtolower($mark['subject_type']) === 'minor') {
            $minorTotal += (float)$mark['total_marks'];
            $minorObtained += (float)$mark['obtained_marks'];
        }
    }
    $percentage = $total > 0 ? $obtained / $total * 100 : 0;
    $majorPercentage = $total > $minorTotal ? ($obtained - $minorObtained) / ($total - $minorTotal) * 100 : 0;
    $grade = calculateGrade($percentage);
    $majorGrade = calculateGrade($majorPercentage);
    return [$total, $obtained, $percentage, $grade, getRemarksByGrade($grade),
        $minorTotal, $minorObtained, $majorPercentage, $majorGrade, getRemarksByGrade($majorGrade)];
}

class TeacherMarksService
{
    public function __construct(private PDO $pdo, private int $teacherId) {}

    private function query(string $sql, array $params = []): PDOStatement
    {
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public function context(int $sectionId, int $examId = 0, bool $lock = false): array
    {
        $suffix = $lock ? ' FOR UPDATE' : '';
        // SELECT * keeps old deployments readable; a missing permission column means denied.
        $teacher = $this->query('SELECT * FROM teachers WHERE id = ?' . $suffix, [$this->teacherId])->fetch(PDO::FETCH_ASSOC);
        if (!$teacher || $teacher['status'] !== 'active' || (int)($teacher['can_enter_marks'] ?? 0) !== 1) {
            throw new TeacherMarksDenied('Mark entry is not enabled for your account. Ask an administrator to open Teachers > Edit > Website & Access and enable Can Enter Student Marks.');
        }
        $assigned = json_decode($teacher['assigned_sections'] ?? '[]', true);
        if (!is_array($assigned) || !in_array($sectionId, array_map('intval', $assigned), true)) {
            throw new TeacherMarksDenied('This section is not assigned to you. Ask your administrator to update your assigned sections.');
        }
        $year = teacherRequireAcademicYear($this->pdo);
        $section = $this->query('SELECT sec.id, sec.class_id, sec.section_name, c.class_name FROM sections sec JOIN classes c ON c.id = sec.class_id WHERE sec.id = ?', [$sectionId])->fetch(PDO::FETCH_ASSOC);
        if (!$section) throw new InvalidArgumentException('Section not found. Please refresh the Classes tab.');
        $context = ['academic_year'=>$year, 'section'=>$section, 'subjects'=>[], 'routine_error'=>''];
        if (!$examId) {
            $context['exams'] = $this->query("SELECT id, exam_name FROM exams WHERE academic_year = ? AND status = 'active' ORDER BY id DESC", [$year])->fetchAll(PDO::FETCH_ASSOC);
            $context['students'] = $this->query("SELECT s.student_id, s.name, ar.roll_no FROM students s JOIN student_academic_records ar ON ar.student_row_id = s.id WHERE ar.academic_year = ? AND ar.class_id = ? AND ar.section_id = ? AND ar.status = 'Active' ORDER BY ar.roll_no, s.name", [$year, $section['class_id'], $sectionId])->fetchAll(PDO::FETCH_ASSOC);
            return $context;
        }
        $exam = $this->query('SELECT id, exam_name, academic_year, status FROM exams WHERE id = ?' . $suffix, [$examId])->fetch(PDO::FETCH_ASSOC);
        if (!$exam || $exam['status'] !== 'active' || $exam['academic_year'] !== $year) {
            throw new InvalidArgumentException('Choose an active exam with the current school academic year. Ask the administrator to set the exam year if it is missing.');
        }
        $subjects = $this->query('SELECT id, subject_name, subject_type FROM subjects WHERE class_id = ? ORDER BY mark_entry_order_by, id' . $suffix, [$section['class_id']])->fetchAll(PDO::FETCH_ASSOC);
        $routines = $this->query('SELECT id, subject_id, theory_marks, practical_marks FROM exam_routines WHERE exam_id = ? AND class_id = ? ORDER BY id' . $suffix, [$examId, $section['class_id']])->fetchAll(PDO::FETCH_ASSOC);
        $missing = [];
        foreach ($subjects as &$subject) {
            $matches = array_values(array_filter($routines, fn($row)=>(int)$row['subject_id'] === (int)$subject['id']));
            $routine = $matches[0] ?? [];
            $theory = $routine['theory_marks'] ?? 0;
            $practical = $routine['practical_marks'] ?? 0;
            if (count($matches) !== 1 || !is_numeric($theory) || !is_numeric($practical)
                || (float)$theory < 0 || (float)$practical < 0 || (float)$theory + (float)$practical <= 0
                || (float)$theory + (float)$practical > 9999.99) {
                $missing[] = $subject['subject_name'];
            }
            $subject['theory_max'] = (float)$theory;
            $subject['practical_max'] = (float)$practical;
        }
        unset($subject);
        if (!$subjects) $missing[] = 'No subjects assigned to this class';
        $context['subjects'] = $subjects;
        $context['exam'] = $exam;
        $context['routine_error'] = $missing ? 'Mark entry is blocked. Administrator: complete Exam Routine with valid Written/Oral full marks for: ' . implode(', ', $missing) . '. Then tap Reload.' : '';
        $context['routine_version'] = hash('sha256', json_encode([$year, $section, $exam, $subjects, $routines]));
        return $context;
    }

    public function students(array $context, int $subjectId): array
    {
        if (!in_array($subjectId, array_map('intval', array_column($context['subjects'], 'id')), true)) throw new InvalidArgumentException('Choose a subject in this class.');
        $section = $context['section'];
        $year = $context['academic_year'];
        $rows = $this->query("SELECT s.student_id, s.name, ar.roll_no, r.id AS result_id,
            r.class_id AS result_class, r.section_id AS result_section, r.academic_year AS result_year,
            sm.id AS mark_id, sm.theory_marks, sm.practical_marks, sm.total_marks, sm.is_absent, sm.is_excluded,
            (SELECT fm.is_excluded FROM subject_marks fm WHERE fm.subject_id = ? AND fm.result_id =
                (SELECT fr.id FROM results fr WHERE fr.student_id = s.student_id AND fr.class_id = ? AND fr.academic_year = ? ORDER BY fr.exam_id LIMIT 1)
            ) AS first_excluded
            FROM students s JOIN student_academic_records ar ON ar.student_row_id = s.id
            LEFT JOIN results r ON r.student_id = s.student_id AND r.exam_id = ?
            LEFT JOIN subject_marks sm ON sm.result_id = r.id AND sm.subject_id = ?
            WHERE ar.academic_year = ? AND ar.class_id = ? AND ar.section_id = ? AND ar.status = 'Active'
            ORDER BY ar.roll_no, s.name" . ($this->pdo->inTransaction() ? ' FOR UPDATE' : ''), [$subjectId, $section['class_id'], $year, $context['exam']['id'], $subjectId, $year, $section['class_id'], $section['id']])->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as &$row) {
            $row['revision'] = hash('sha256', json_encode($row));
            $row['locked'] = (int)$row['is_excluded'] === 1 || (int)$row['first_excluded'] === 1
                || ($row['result_id'] && ((int)$row['result_class'] !== (int)$section['class_id']
                    || (int)$row['result_section'] !== (int)$section['id'] || $row['result_year'] !== $year));
            $row['saved'] = $row['mark_id'] !== null;
        }
        return $rows;
    }

    public function save(int $sectionId, int $examId, int $subjectId, array $payload): int
    {
        $entries = $payload['students'] ?? null;
        if (!is_array($entries) || !$entries || count($entries) > 500) throw new InvalidArgumentException('Submit between 1 and 500 changed students.');
        $this->pdo->beginTransaction();
        try {
            $context = $this->context($sectionId, $examId, true);
            if ($context['routine_error']) throw new InvalidArgumentException($context['routine_error']);
            if (($payload['academic_year'] ?? '') !== $context['academic_year'] || ($payload['routine_version'] ?? '') !== $context['routine_version']) {
                throw new InvalidArgumentException('Exam settings or full marks changed. Reload and check the marks before saving.');
            }
            $subject = null;
            foreach ($context['subjects'] as $candidate) if ((int)$candidate['id'] === $subjectId) $subject = $candidate;
            if (!$subject) throw new InvalidArgumentException('Invalid subject for this class.');
            // Lock students in a stable order, including students without result rows yet.
            $ids = [];
            foreach ($entries as $entry) {
                if (!is_array($entry) || !is_string($entry['student_id'] ?? null) || $entry['student_id'] === '' || isset($ids[$entry['student_id']])) throw new InvalidArgumentException('Invalid or duplicate student selection.');
                $ids[$entry['student_id']] = true;
            }
            $sortedIds = array_keys($ids); sort($sortedIds, SORT_STRING);
            foreach ($sortedIds as $id) {
                $this->query('SELECT id FROM students WHERE student_id = ? FOR UPDATE', [$id])->fetchColumn();
                $this->query('SELECT id FROM results WHERE student_id = ? AND exam_id = ? FOR UPDATE', [$id, $examId])->fetchColumn();
            }
            $roster = array_column($this->students($context, $subjectId), null, 'student_id');
            foreach ($entries as $entry) {
                $student = $roster[$entry['student_id']] ?? null;
                if (!$student || $student['locked']) throw new InvalidArgumentException('A selected student is outside this section/year or excluded by the administrator. Reload the list.');
                // A locking read also sees a concurrently changed first-exam exclusion.
                $firstResult = $this->query('SELECT id FROM results WHERE student_id = ? AND class_id = ? AND academic_year = ? ORDER BY exam_id LIMIT 1 FOR UPDATE', [$entry['student_id'], $context['section']['class_id'], $context['academic_year']])->fetchColumn();
                if ($firstResult) {
                    $firstExcluded = $this->query('SELECT is_excluded FROM subject_marks WHERE result_id = ? AND subject_id = ? FOR UPDATE', [$firstResult, $subjectId])->fetchColumn();
                    if ((int)$firstExcluded === 1) throw new InvalidArgumentException($student['name'] . ': this subject is excluded by the administrator. Reload the list.');
                }
                if (($entry['revision'] ?? '') !== $student['revision']) throw new InvalidArgumentException($student['name'] . ': marks were changed by another user. Reload before saving.');
                if (!is_bool($entry['absent'] ?? null)) throw new InvalidArgumentException('Select a valid attendance state.');
                $theory = teacherMarksNumber($entry['theory'] ?? '', $subject['theory_max']);
                $practical = teacherMarksNumber($entry['practical'] ?? '', $subject['practical_max']);
                if ($entry['absent']) $theory = $practical = 0.0;
                $total = $subject['theory_max'] + $subject['practical_max'];
                $obtained = $theory + $practical;
                $grade = calculateGrade($obtained / $total * 100);
                $resultId = $student['result_id'];
                if (!$resultId) {
                    $this->query("INSERT INTO results (student_id, exam_id, class_id, section_id, result_roll_no, academic_year, total_marks, obtained_marks, percentage, grade, remarks) VALUES (?, ?, ?, ?, ?, ?, 0, 0, 0, 'D', 'Disqualified')",
                        [$entry['student_id'], $examId, $context['section']['class_id'], $sectionId, $student['roll_no'], $context['academic_year']]);
                    $resultId = $this->pdo->lastInsertId();
                }
                $values = [$theory, $practical, $total, $obtained, $grade, getRemarksByGrade($grade), (int)$entry['absent']];
                if ($student['mark_id']) {
                    $this->query('UPDATE subject_marks SET theory_marks = ?, practical_marks = ?, total_marks = ?, obtained_marks = ?, grade = ?, remarks = ?, is_absent = ? WHERE id = ?', [...$values, $student['mark_id']]);
                } else {
                    $this->query('INSERT INTO subject_marks (theory_marks, practical_marks, total_marks, obtained_marks, grade, remarks, is_absent, result_id, subject_id, is_excluded) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)', [...$values, $resultId, $subjectId]);
                }
                $marks = $this->query('SELECT sm.total_marks, sm.obtained_marks, sm.is_excluded, s.subject_type FROM subject_marks sm JOIN subjects s ON s.id = sm.subject_id WHERE sm.result_id = ?', [$resultId])->fetchAll(PDO::FETCH_ASSOC);
                $this->query('UPDATE results SET total_marks = ?, obtained_marks = ?, percentage = ?, grade = ?, remarks = ?, total_minor_marks = ?, obtained_minor_marks = ?, percentage_without_minor = ?, grade_without_minor = ?, remarks_without_minor = ?, updated_at = NOW() WHERE id = ?', [...teacherMarksTotals($marks), $resultId]);
            }
            $this->pdo->commit();
            return count($entries);
        } catch (Throwable $e) {
            if ($this->pdo->inTransaction()) $this->pdo->rollBack();
            throw $e;
        }
    }
}
