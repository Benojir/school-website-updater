<!-- Bulk student manage wallet -->
<div class="modal fade" id="manageWalletModal" tabindex="-1" aria-labelledby="manageWalletModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" id="manageWalletForm">
                <div class="modal-header bg-primary text-white">
                    <h1 class="modal-title fs-5" id="manageWalletModalLabel">Manage Wallet</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="wallet_action" class="form-label">Action: </label>
                        <select class="form-select exclude-from-load" name="wallet_action" id="wallet_action" required>
                            <option selected value="">-- Select Action --</option>
                            <option value="add_funds">Add Funds</option>
                            <option value="deduct_funds">Deduct Funds</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="wallet_amount" class="form-label">Amount: </label>
                        <input class="form-control" type="number" name="wallet_amount" id="wallet_amount" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>