<!-- Student Inventory Collect Due Modal -->
<div class="modal fade" id="studentInventoryCollectModal" tabindex="-1" aria-labelledby="studentInventoryCollectModalTitle" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header bg-light py-3 px-4">
                <h5 class="modal-title fw-bold text-success" id="studentInventoryCollectModalTitle">
                    <i class="fas fa-hand-holding-dollar me-2"></i>School Store: Collect Inventory Due
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4">
                <!-- Error Alert -->
                <div id="invCollectError" class="alert alert-danger d-none mb-3" role="alert"></div>

                <!-- Student summary banner -->
                <div class="p-3 border rounded-3 bg-light mb-3 d-flex align-items-center justify-content-between">
                    <div class="inventory-student-summary" id="invCollectStudentDetails">
                        <strong id="invCollectStudentName" class="fs-6 text-dark d-block"></strong>
                        <span id="invCollectStudentMeta" class="text-muted small"></span>
                    </div>
                    <div class="text-end">
                        <span class="text-muted small d-block">Total Inventory Due</span>
                        <span id="invCollectTotalDueBadge" class="badge bg-danger fs-6">₹0.00</span>
                    </div>
                </div>

                <!-- Loading Spinner -->
                <div id="invCollectLoading" class="text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading dues...</span>
                    </div>
                    <p class="text-muted mt-2 mb-0">Fetching unpaid store bills...</p>
                </div>

                <!-- No Dues View -->
                <div id="invCollectEmpty" class="text-center py-5 d-none">
                    <i class="fas fa-check-circle text-success fa-3x mb-3"></i>
                    <h5 class="fw-bold text-dark">No Pending Dues!</h5>
                    <p class="text-muted">All inventory and store purchases for this student are fully settled.</p>
                </div>

                <!-- Dues & Payment Form Container -->
                <div id="invCollectContent" class="d-none">
                    <!-- Unpaid Bills Selection -->
                    <div class="mb-4">
                        <label class="form-label fw-bold text-dark">
                            <i class="fas fa-file-invoice me-1 text-primary"></i> Select Unpaid Bill
                        </label>
                        <div class="table-responsive border rounded-3">
                            <table class="table table-hover table-sm align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th style="width: 45px;" class="text-center">#</th>
                                        <th>Bill #</th>
                                        <th>Date</th>
                                        <th>Total</th>
                                        <th>Paid</th>
                                        <th>Due</th>
                                    </tr>
                                </thead>
                                <tbody id="invCollectBillsTableBody">
                                    <!-- Populated dynamically -->
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Selected Bill Items Preview -->
                    <div id="invCollectBillItemsWrap" class="mb-4 p-3 border rounded-3 bg-light d-none">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="fw-bold small text-muted text-uppercase">Items on Selected Bill</span>
                            <span id="invCollectBillItemsSummary" class="small text-muted"></span>
                        </div>
                        <div id="invCollectBillItemsList" class="small text-dark">
                            <!-- Items listed here -->
                        </div>
                    </div>

                    <!-- Payment Form -->
                    <form id="studentInventoryCollectForm" autocomplete="off">
                        <input type="hidden" id="invCollectDocumentId" name="document_id" value="">
                        
                        <div class="card border-success border-opacity-25 bg-success bg-opacity-10 p-3 rounded-3 mb-3">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold text-dark" for="invCollectAmount">
                                        Amount Received Now <span class="text-danger">*</span>
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-white"><?= htmlspecialchars($websiteConfig['currency_symbol'] ?? '₹', ENT_QUOTES, 'UTF-8') ?></span>
                                        <input type="number" class="form-control" id="invCollectAmount" name="amount" min="0.01" step="0.01" required>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center mt-1">
                                        <small class="text-muted" id="invCollectDueNotice">Balance due: ₹0.00</small>
                                        <button type="button" class="btn btn-sm btn-link p-0 text-decoration-none" id="btnInvCollectPayFull">
                                            Pay full due
                                        </button>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-bold text-dark" for="invCollectMethod">
                                        Payment Method <span class="text-danger">*</span>
                                    </label>
                                    <select class="form-select exclude-from-load" id="invCollectMethod" name="method" required>
                                        <option value="cash" selected>Cash</option>
                                        <option value="online">UPI / Online</option>
                                        <option value="bank">Bank Transfer</option>
                                    </select>
                                </div>

                                <div class="col-12">
                                    <label class="form-label text-muted small" for="invCollectReference">
                                        Payment Reference / Note (Optional)
                                    </label>
                                    <input type="text" class="form-control form-control-sm" id="invCollectReference" name="reference" placeholder="e.g. UPI transaction ID, Cheque number or remark" maxlength="100">
                                </div>
                            </div>
                        </div>

                        <div class="d-flex justify-content-end gap-2 pt-2 border-top">
                            <button type="button" class="btn btn-secondary px-4" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-success px-4" id="btnSubmitInvCollect">
                                <i class="fas fa-check-circle me-1"></i> Collect Payment
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
