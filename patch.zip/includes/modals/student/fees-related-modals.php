<!-- Manage unpaid fees modal for single student -->
<div class="modal fade" id="manageUnpaidFeesModal" tabindex="-1" aria-labelledby="manageUnpaidFeesModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content rounded-4 shadow-lg overflow-hidden">
            <div class="modal-header bg-primary text-white">
                <h1 class="modal-title fs-5" id="manageUnpaidFeesModalLabel">All Unpaid Fees</h1>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="manageUnpaidFeesModalBody">
                <!-- Data will be loaded via ajax -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Extra additional fees management modal -->
<div class="modal fade" id="additionalFeesManagementModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content rounded-4 shadow-lg overflow-hidden">
            <form id="formAdditionalFeesModal">
                <div class="modal-header bg-primary text-white">
                    <h1 class="modal-title fs-5">Additional Fees Manage <b id="additionalFeesManagementModalFor"></b></h1>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="student_ids" id="additionalFeesManagementModalFormStudentIds">
                    <div class="mb-3">
                        <label for="additional_fees_setup_id" class="form-label">Additional Fee:</label>
                        <select id="additional_fees_setup_id" name="additional_fees_setup_id" class="form-control exclude-from-load" required>
                            <!-- Load via ajax -->
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="additional_fee_status" class="form-label">Status:</label>
                        <select id="additional_fee_status" name="additional_fee_status" class="form-control exclude-from-load" required onchange="additionalFeesDueAndPaymentDateShowHide()">
                            <option value="" selected disabled>-- Select Fee Status --</option>
                            <option value="paid">Paid</option>
                            <option value="unpaid">Unpaid</option>
                        </select>
                    </div>
                    <div class="mb-3" style="display: none;">
                        <label for="additional_fee_paid_date" class="form-label">Payment Date:</label>
                        <input type="date" id="additional_fee_paid_date" name="additional_fee_paid_date" class="form-control">
                    </div>
                    <div class="mb-3" style="display: none;">
                        <label for="additional_fee_due_date" class="form-label">Due Date:</label>
                        <input type="date" id="additional_fee_due_date" name="additional_fee_due_date" class="form-control">
                    </div>
                </div>
                <div class="modal-footer d-flex justify-content-center">
                    <button class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Manage additional fees modal for single student -->
<div class="modal fade" id="listAllAdditionalFeesModal" tabindex="-1" aria-labelledby="listAllAdditionalFeesModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content rounded-4 shadow-lg overflow-hidden">
            <div class="modal-header bg-primary text-white">
                <h1 class="modal-title fs-5" id="listAllAdditionalFeesModalLabel">All Additional Fees</h1>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-light table-striped table-hover">
                        <thead>
                            <tr class="text-center align-middle">
                                <th>Class</th>
                                <th>Fee Type</th>
                                <th>Amount</th>
                                <th>Paid Status</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="listAllAdditionalFeesModalTableBody">
                            <!-- Load dynamically -->
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>