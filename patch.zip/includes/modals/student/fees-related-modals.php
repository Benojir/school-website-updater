<!-- Bulk Admission Fees and Payments Modal -->
<div class="modal fade" id="bulkAdmissionFeeModal" data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="bulkAdmissionFeeModalLabel" aria-hidden="true" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Admission Fees & Payments <b><span class="studentNameInModal"></span></b></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <ul class="nav nav-tabs nav-fill mb-3" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="admissionTab1-tab" data-bs-toggle="tab" data-bs-target="#admissionTab1" type="button" role="tab">Admission Payments Entry</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="admissionTab2-tab" data-bs-toggle="tab" data-bs-target="#admissionTab2" type="button" role="tab">Admission Fees Entry</button>
                    </li>
                </ul>

                <div class="tab-content mt-4">
                    <div class="tab-pane fade show active" id="admissionTab1" role="tabpanel">
                        <div class="payment-entry-info-alert-container"></div>
                        <form id="admissionPaymentsEntryForm" autocomplete="off">
                            <div class="mb-3">
                                <label for="admission_fee_amount" class="form-label">Amount:</label>
                                <input type="number" id="admission_fee_amount" name="amount" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="admission_payment_date" class="form-label">Payment Date:</label>
                                <input type="date" id="admission_payment_date" name="payment_date" class="form-control" required>
                            </div>
                            <div class="mt-3 mb-2 d-flex justify-content-end">
                                <button type="submit" class="btn btn-primary">Save Payments Entry</button>
                            </div>
                        </form>
                    </div>
                    <div class="tab-pane fade" id="admissionTab2" role="tabpanel">
                        <form id="admissionFeesEntryForm" autocomplete="off">
                            <div class="mb-3">
                                <label for="admission_fees_type" class="form-label">Admission Fees Type:</label>
                                <select name="admission_fees_type" id="admission_fees_type" class="form-control exclude-from-load" required>
                                    <option value="new-admission-fees" selected>New Admission Fees</option>
                                    <option value="re-admission-fees">Re-Admission Fees</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="academic_year" class="form-label">Academic Year:</label>
                                <select name="academic_year" id="academic_year" class="form-control exclude-from-load academicYearSelect" required></select>
                            </div>
                            <div class="mb-3">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <label for="admission_class" class="form-label mb-0">
                                        Admission Class (Optional):
                                    </label>
                                    <label class="text-small" for="enable_admission_class_selection">
                                        Enable selection:
                                        <input type="checkbox" id="enable_admission_class_selection" class="form-check-input ms-2">
                                    </label>
                                </div>
                                <select name="admission_class" id="admission_class_selector" class="form-control exclude-from-load" disabled>
                                    <option value="">Current Class</option>
                                    <?php foreach ($classes as $class): ?>
                                        <option value="<?php echo $class['id']; ?>"><?php echo $class['class_name']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="discount" class="form-label">Discount:</label>
                                <input type="number" id="discount" name="discount" class="form-control">
                            </div>
                            <div class="mt-3 mb-2 d-flex justify-content-end">
                                <button type="submit" class="btn btn-primary">Save Fees Entry</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bulk Student Monthly Payments and Fees Modal -->
<div class="modal fade" id="bulkFeeModal" data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="bulkFeeModalLabel" aria-hidden="true" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Monthly Fees & Payments <b><span class="studentNameInModal"></span></b></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <ul class="nav nav-tabs nav-fill mb-3" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="monthlyTab1-tab" data-bs-toggle="tab" data-bs-target="#monthlyFeesTab1" type="button" role="tab">Payments Entry</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="monthlyTab2-tab" data-bs-toggle="tab" data-bs-target="#monthlyFeesTab2" type="button" role="tab">Fees Entry</button>
                    </li>
                </ul>

                <div class="tab-content mt-4">
                    <div class="tab-pane fade show active" id="monthlyFeesTab1" role="tabpanel">
                        <div class="payment-entry-info-alert-container"></div>
                        <form id="monthlyPaymentsEntryForm" autocomplete="off">
                            <div class="mb-3">
                                <label for="monthly_fee_amount" class="form-label">Amount:</label>
                                <input type="number" id="monthly_fee_amount" name="amount" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="monthly_fee_payment_date" class="form-label">Payment Date:</label>
                                <input type="date" id="monthly_fee_payment_date" name="payment_date" class="form-control" required>
                            </div>
                            <div class="mt-3 mb-2 d-flex justify-content-end">
                                <button type="submit" class="btn btn-primary">Save Payments Entry</button>
                            </div>
                        </form>
                    </div>
                    <div class="tab-pane fade" id="monthlyFeesTab2" role="tabpanel">
                        <form id="monthlyFeesEntryForm" autocomplete="off">
                            <div class="mb-3">
                                <label for="month_year" class="form-label">Month:</label>
                                <select name="month_year" id="month_year" class="form-control exclude-from-load feeMonthSelect" required></select>
                            </div>
                            <div class="mb-3">
                                <label for="discount" class="form-label">Discount:</label>
                                <input type="number" id="discount" name="discount" class="form-control">
                            </div>
                            <div class="mt-3 mb-2 d-flex justify-content-end">
                                <button type="submit" class="btn btn-primary">Save Fees Entry</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Manage unpaid fees modal for single student -->
<div class="modal fade" id="manageUnpaidFeesModal" tabindex="-1" aria-labelledby="manageUnpaidFeesModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h1 class="modal-title fs-5" id="manageUnpaidFeesModalLabel">All Unpaid Fees</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="manageUnpaidFeesModalBody">
                <!-- Data will be loaded via ajax -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Extra additional fees management modal -->
<div class="modal fade" id="additionalFeesManagementModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="formAdditionalFeesModal">
                <div class="modal-header bg-primary text-white">
                    <h1 class="modal-title fs-5">Additional Fees Manage <b id="additionalFeesManagementModalFor"></b></h1>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="student_ids" id="additionalFeesManagementModalFormStudentIds">
                    <div class="mb-3">
                        <label for="additional_fees_setup_id" class="form-label">Additional Fee:</label>
                        <select id="additional_fees_setup_id" name="additional_fees_setup_id" class="form-control exclude-from-load" required>
                            <!-- Load via ajax -->
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="additional_fee_status" class="form-label">Status:</label>
                        <select id="additional_fee_status" name="additional_fee_status" class="form-control exclude-from-load" required onchange="additionalFeesDueAndPaymentDateShowHide()">
                            <option value="" selected disabled>-- Select Fee Status --</option>
                            <option value="paid">Paid</option>
                            <option value="unpaid">Unpaid</option>
                        </select>
                    </div>
                    <div class="mb-3" style="display: none;">
                        <label for="additional_fee_paid_date" class="form-label">Payment Date:</label>
                        <input type="date" id="additional_fee_paid_date" name="additional_fee_paid_date" class="form-control">
                    </div>
                    <div class="mb-3" style="display: none;">
                        <label for="additional_fee_due_date" class="form-label">Due Date:</label>
                        <input type="date" id="additional_fee_due_date" name="additional_fee_due_date" class="form-control">
                    </div>
                </div>
                <div class="modal-footer d-flex justify-content-center">
                    <button class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Manage unpaid fees modal for single student -->
<div class="modal fade" id="listAllAdditionalFeesModal" tabindex="-1" aria-labelledby="listAllAdditionalFeesModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h1 class="modal-title fs-5" id="listAllAdditionalFeesModalLabel">All Additional Fees</h1>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-light table-striped table-hover">
                        <thead>
                            <tr class="text-center align-middle">
                                <th>Class</th>
                                <th>Fee Type</th>
                                <th>Amount</th>
                                <th>Paid Status</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="listAllAdditionalFeesModalTableBody">
                            <!-- Load dynamically -->
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>