<?php $_SESSION['student_download_permissions_csrf'] ??= bin2hex(random_bytes(32)); ?>
<!-- Permission Modal -->
<div class="modal fade" id="permissionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content rounded-4 overflow-hidden shadow-lg">
            <form id="downloadPermissionsForm" data-school-now="<?= date('Y-m-d\TH:i:s') ?>" data-timezone="<?= safe_htmlspecialchars(date_default_timezone_get()) ?>">
                <input type="hidden" name="csrf_token" value="<?= safe_htmlspecialchars($_SESSION['student_download_permissions_csrf']) ?>">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Manage Permissions for <span id="permStudentName"></span></h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="student_ids" id="permStudentIds">

                    <!-- Add this alert for bulk operations -->
                    <div class="alert alert-info mb-3" id="bulkPermissionAlert" style="display: none;">
                        <i class="fas fa-users me-2"></i> You are editing permissions for <strong><span id="selectedStudentsCount">0</span></strong> selected students.
                    </div>

                    <div class="alert alert-info mb-3">
                        <strong>Current Fee Status:</strong> <span id="currentFeeStatus">N/A for bulk operations</span>
                    </div>
                    <p class="small text-muted">After the scheduled release, parents with no outstanding fees can download. A temporary Allow also permits downloading with unpaid fees until its expiry. All expiry times use <?= safe_htmlspecialchars(date_default_timezone_get()) ?>.</p>

                    <!-- Admit Card Section -->
                    <div class="card mb-3">
                        <div class="card-header bg-primary text-white">
                            Admit Card Permissions
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="overrideAdmitCheck" name="override_admit_check">
                                    <label class="form-check-label" for="overrideAdmitCheck">Override Fee Requirements for Admit Card</label>
                                </div>
                            </div>

                            <div class="mb-3" id="admitCardOverrideContainer" style="display:none;">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="allowAdmitCard" name="allow_admit_card">
                                    <label class="form-check-label" for="allowAdmitCard">Allow Admit Card Download</label>
                                </div>
                                <label class="form-label mt-3" for="admitOverrideDays">Set duration (days)</label>
                                <input class="form-control mb-2" type="number" id="admitOverrideDays" data-override-days="admit" min="1" max="365" value="1">
                                <label class="form-label" for="admitExpiresAt">Override expires at</label>
                                <input class="form-control" type="datetime-local" step="1" id="admitExpiresAt" name="admit_expires_at" disabled>
                                <small class="text-muted">After this time the normal fee rules apply automatically. The release date still applies.</small>
                            </div>
                        </div>
                    </div>

                    <!-- Marksheet Section -->
                    <div class="card mb-3">
                        <div class="card-header bg-success text-white">
                            Marksheet Permissions
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="overrideMarksheetCheck" name="override_marksheet_check">
                                    <label class="form-check-label" for="overrideMarksheetCheck">Override Requirements for Marksheet</label>
                                </div>
                            </div>

                            <div class="mb-3" id="marksheetOverrideContainer" style="display:none;">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="allowMarksheet" name="allow_marksheet">
                                    <label class="form-check-label" for="allowMarksheet">Allow Marksheet Download</label>
                                </div>
                                <label class="form-label mt-3" for="marksheetOverrideDays">Set duration (days)</label>
                                <input class="form-control mb-2" type="number" id="marksheetOverrideDays" data-override-days="marksheet" min="1" max="365" value="1">
                                <label class="form-label" for="marksheetExpiresAt">Override expires at</label>
                                <input class="form-control" type="datetime-local" step="1" id="marksheetExpiresAt" name="marksheet_expires_at" disabled>
                                <small class="text-muted">After this time the normal fee rules apply automatically. The release date still applies.</small>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="permissionNotes" class="form-label">Notes:</label>
                        <textarea class="form-control" id="permissionNotes" name="notes" rows="3" placeholder="Reason for override"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Permissions</button>
                </div>
            </form>
        </div>
    </div>
</div>
