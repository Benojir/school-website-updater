<!-- Marksheet download chooser modal -->
<div class="modal fade" id="marksheetsDownloadModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h1 class="modal-title fs-5">Download Marksheets</h1>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                    <tbody id="marksheetDownloadModalTableBody">
                        <!-- Dynamically populated -->
                    </tbody>
                </table>
            </div>
            <div class="modal-footer d-flex justify-content-center">
                <button type="button" class="btn btn-primary" onclick="downloadCombinedMarksheets()"><i class="fas fa-download"></i> Download Combined Marksheet</button>
            </div>
        </div>
    </div>
</div>