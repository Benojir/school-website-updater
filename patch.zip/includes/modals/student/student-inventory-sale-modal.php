<!-- Student Inventory Sale / Gift Modal -->
<div class="modal fade" id="studentInventorySaleModal" tabindex="-1" aria-labelledby="studentInventoryModalTitle" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header bg-light py-3 px-4">
                <h5 class="modal-title fw-bold text-success" id="studentInventoryModalTitle">
                    <i class="fas fa-bag-shopping me-2"></i>School Store: Sell / Give Items
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4">
                <form id="studentInventorySaleForm" autocomplete="off">
                    <div id="studentInventoryError" class="alert alert-danger d-none mb-3" role="alert"></div>

                    <!-- Step 1: Student Selection / Pre-selected Student -->
                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="inventory-step mt-0 mb-0">1. Student</span>
                            <button type="button" class="btn btn-sm btn-link text-decoration-none p-0 d-none" id="btnChangeStudentInventory">
                                <i class="fas fa-user-pen me-1"></i>Change student
                            </button>
                        </div>

                        <!-- Selected student banner -->
                        <div id="studentInventorySelectedBox" class="p-3 border rounded-3 bg-light d-none align-items-center justify-content-between">
                            <div class="inventory-student-summary" id="studentInventorySelectedDetails">
                                <!-- Populated dynamically -->
                            </div>
                        </div>

                        <!-- Student search (shown if no student selected or when changing) -->
                        <div id="studentInventorySearchWrap">
                            <label for="invStudentSearchInput" class="form-label small text-muted">Search by student or parent name, phone, ID, registration number or address</label>
                            <div class="input-group">
                                <span class="input-group-text bg-white"><i class="fas fa-search text-muted"></i></span>
                                <input type="text" class="form-control" id="invStudentSearchInput" placeholder="Type at least 2 characters to search...">
                            </div>
                            <div class="inventory-search-results" id="invStudentSearchResults"></div>
                        </div>
                    </div>

                    <!-- Step 2: Transaction Kind -->
                    <div class="mb-3">
                        <label for="invTransactionKind" class="form-label fw-bold">What are you doing?</label>
                        <select id="invTransactionKind" class="form-select exclude-from-load">
                            <option value="sale" selected>Sell items (Cash or Credit)</option>
                            <option value="gift">Give items free of charge (Gift / School Distribution)</option>
                        </select>
                    </div>

                    <!-- Step 3: Product Search & Cart -->
                    <div class="mb-3">
                        <div class="inventory-step mb-2">2. Add Products</div>
                        <label class="form-label small text-muted" for="invProductSearchInput">Find a product from inventory</label>
                        <div class="input-group">
                            <span class="input-group-text bg-white"><i class="fas fa-box text-muted"></i></span>
                            <input class="form-control" id="invProductSearchInput" placeholder="Search product name or code (SKU)...">
                        </div>
                        <div class="inventory-search-results" id="invProductSearchResults"></div>

                        <!-- Cart table -->
                        <div id="invCartContainer" class="mt-3">
                            <div class="table-responsive">
                                <table class="table table-sm align-middle inventory-cart mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Product</th>
                                            <th style="width: 100px;">Quantity</th>
                                            <th style="width: 130px;">Price / item</th>
                                            <th style="width: 120px;" class="text-end">Total</th>
                                            <th style="width: 40px;"></th>
                                        </tr>
                                    </thead>
                                    <tbody id="invCartTableBody">
                                        <tr>
                                            <td colspan="5" class="text-muted text-center py-3">No products added yet. Search above to add items.</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Bill Total -->
                        <div class="inventory-total mt-3">
                            <span class="fw-bold">Bill Total</span>
                            <strong id="invCartTotalDisplay">₹0.00</strong>
                        </div>
                    </div>

                    <!-- Step 4: Payment Section (Only for Sales) -->
                    <div id="invPaymentSection" class="mb-3">
                        <div class="inventory-step mb-2">3. Payment</div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label" for="invPaymentPaid">Amount received now</label>
                                <div class="input-group">
                                    <span class="input-group-text"><?= htmlspecialchars($websiteConfig['currency_symbol'] ?? '₹', ENT_QUOTES, 'UTF-8') ?></span>
                                    <input type="number" class="form-control" id="invPaymentPaid" name="paid" value="0.00" min="0" max="99999999.99" step="0.01" required>
                                </div>
                                <div class="d-flex justify-content-between align-items-center mt-1">
                                    <div class="form-text">Enter 0 for full credit, or partial payment.</div>
                                    <button type="button" class="btn btn-link btn-sm p-0 text-decoration-none" id="btnInvPayLater">No payment now</button>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label" for="invPaymentMethod">Payment method</label>
                                <select class="form-select" id="invPaymentMethod" name="method">
                                    <option value="cash" selected>Cash</option>
                                    <option value="online">UPI / online</option>
                                    <option value="bank">Bank transfer</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <label class="form-label" for="invPaymentReference">Payment reference (optional)</label>
                                <input type="text" class="form-control" id="invPaymentReference" name="reference" placeholder="e.g. Transaction ID / Receipt No." maxlength="100">
                            </div>
                        </div>
                        <div class="small fw-bold text-danger mt-2" id="invBalancePreview">Balance due after this payment: ₹0.00</div>
                    </div>

                    <!-- Step 5: Optional Note -->
                    <div class="mb-2">
                        <label class="form-label" for="invNote">Note (optional)</label>
                        <input type="text" class="form-control" id="invNote" name="note" placeholder="Any internal reference or remark" maxlength="500">
                    </div>

                    <div class="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-success px-4" id="btnInvSubmit">
                            <i class="fas fa-check me-1"></i> Save Entry
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
