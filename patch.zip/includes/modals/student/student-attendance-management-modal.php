<!-- Manage Attendance Modal -->
<div class="modal fade" id="manageAttendanceModal" tabindex="-1" aria-labelledby="manageAttendanceModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog">
        <div class="modal-content rounded-4 shadow-lg overflow-hidden">
            <form method="post" id="manageAttendanceForm">
                <div class="modal-header bg-primary text-white">
                    <h1 class="modal-title fs-5" id="manageAttendanceModalLabel">Manage Attendance</h1>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="attendance_action" class="form-label">Action: </label>
                        <select class="form-select exclude-from-load" name="attendance_action" id="attendance_action" required>
                            <option selected value="">-- Select Action --</option>
                            <option value="present">Mark Present</option>
                            <option value="absent">Mark Absent</option>
                            <option value="late">Mark Late</option>
                            <option value="leave">Mark Leave</option>
                        </select>
                    </div>

                    <!-- Date Selection -->
                    <div class="mb-3">
                        <label for="attendance_dates" class="form-label">Select Dates: </label>
                        <input class="form-control" type="text" name="attendance_dates" id="attendance_dates" placeholder="Select multiple dates" required>
                    </div>

                    <!-- Time Selection -->
                    <div class="mb-3">
                        <label for="attendance_time" class="form-label">Time: </label>
                        <input class="form-control" type="time" name="attendance_time" id="attendance_time" required>
                    </div>

                    <!-- Hidden field for combined date-time values -->
                    <input type="hidden" name="attendance_datetimes" id="attendance_datetimes">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" id="resetAttendanceForm">Reset</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>