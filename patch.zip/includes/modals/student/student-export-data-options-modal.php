<!-- Bulk student manage wallet -->
<div class="modal fade" id="exportDataOptionsModal" tabindex="-1" aria-labelledby="exportDataOptionsModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content rounded-4 shadow-lg overflow-hidden">
            <form method="post" target="_blank" action="../../api/download/export-students-data.php">
                <input type="hidden" name="student_ids" id="exportDataStudentIdsInputField" value="">
                <div class="modal-header bg-primary text-white">
                    <h1 class="modal-title fs-5" id="exportDataOptionsModalLabel">Select Export Options</h1>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body row">
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportStudentId" name="exportStudentId" checked>
                        <label for="exportStudentId" class="form-label">Student ID</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportStudentName" name="exportStudentName" checked>
                        <label for="exportStudentName" class="form-label">Student Name</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportClass" name="exportClass" checked>
                        <label for="exportClass" class="form-label">Class</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportSection" name="exportSection" checked>
                        <label for="exportSection" class="form-label">Section</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportRollNo" name="exportRollNo">
                        <label for="exportRollNo" class="form-label">Roll Number</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportRegNo" name="exportRegNo">
                        <label for="exportRegNo" class="form-label">Reg. No.</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportAdmissionDate" name="exportAdmissionDate">
                        <label for="exportAdmissionDate" class="form-label">Admission Date</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportDOB" name="exportDOB">
                        <label for="exportDOB" class="form-label">Date of Birth</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportGender" name="exportGender">
                        <label for="exportGender" class="form-label">Gender</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportBloodGroup" name="exportBloodGroup">
                        <label for="exportBloodGroup" class="form-label">Blood Group</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportEmail" name="exportEmail">
                        <label for="exportEmail" class="form-label">Email</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportPhone" name="exportPhone">
                        <label for="exportPhone" class="form-label">Phone</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportAltPhone" name="exportAltPhone">
                        <label for="exportAltPhone" class="form-label">Alt. Phone</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportReligion" name="exportReligion">
                        <label for="exportReligion" class="form-label">Religion</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportFullAddress" name="exportFullAddress">
                        <label for="exportFullAddress" class="form-label">Full Address</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportVillage" name="exportVillage">
                        <label for="exportVillage" class="form-label">Village/Town</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportPostOffice" name="exportPostOffice">
                        <label for="exportPostOffice" class="form-label">Post Office</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportPoliceStation" name="exportPoliceStation">
                        <label for="exportPoliceStation" class="form-label">Police Station</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportDistrict" name="exportDistrict">
                        <label for="exportDistrict" class="form-label">District</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportPinCode" name="exportPinCode">
                        <label for="exportPinCode" class="form-label">Pin Code</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportFatherName" name="exportFatherName">
                        <label for="exportFatherName" class="form-label">Father's Name</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportMotherName" name="exportMotherName">
                        <label for="exportMotherName" class="form-label">Mother's Name</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportStudentAadhar" name="exportStudentAadhar">
                        <label for="exportStudentAadhar" class="form-label">Student's Aadhar</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportFatherAadhar" name="exportFatherAadhar">
                        <label for="exportFatherAadhar" class="form-label">Father's Aadhar</label>
                    </div>
                    <div class="col-md-4">
                        <input type="checkbox" class="form-check-input" id="exportMotherAadhar" name="exportMotherAadhar">
                        <label for="exportMotherAadhar" class="form-label">Mother's Aadhar</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>