<!-- Bulk notification send modal -->
<div class="modal fade" id="sendPaymentRemindersModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content rounded-4 shadow-lg overflow-hidden">
            <form method="post" id="sendPaymentRemindersModalForm">
                <div class="modal-header bg-primary text-white">
                    <h1 class="modal-title fs-5" id="notificationModalLabel">Send Payment Reminders</h1>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Sending Via: </label>
                        <select class="form-select" name="via" required>
                            <option value="whatsapp">WhatsApp (Charges Apply)</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Last Date of Payment: </label>
                        <input type="date" class="form-control" name="last_payment_date" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Sample Message: </label>
                        <textarea class="form-control" type="text" rows="15" readonly disabled>প্রিয় অভিভাবক,

আপনার সন্তান *{{student_name}}* -এর বিদ্যালয়ের কিছু পাওনা এখনও পরিশোধ করা হয়নি। আমাদের রেকর্ড অনুযায়ী মোট বকেয়া পরিমাণ *₹{{total_due}}*।

অনুগ্রহ করে *{{last_date_of_payment}}* তারিখের মধ্যে বকেয়া পরিশোধ করার জন্য বিশেষভাবে অনুরোধ করা হচ্ছে।

বকেয়ার বিস্তারিত তথ্য জানতে অনুগ্রহ করে বিদ্যালয়ে যোগাযোগ করুন অথবা *{{contact_no_1}}* বা *{{contact_no_2}}* নম্বরে কল করুন। এছাড়াও, আমাদের স্কুলের তৈরি প্যারেন্ট অ্যাপটি ডাউনলোড করে আপনার সন্তানের বকেয়াসহ অন্যান্য তথ্য সহজেই দেখতে পারবেন।

যদি ইতোমধ্যে অর্থ পরিশোধ করে থাকেন, তাহলে অনুগ্রহ করে এই বার্তাটি উপেক্ষা করুন।

ধন্যবাদান্তে,
*{{school_name}}* কর্তৃপক্ষ।</textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send</button>
                </div>
            </form>
        </div>
    </div>
</div>