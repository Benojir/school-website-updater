<!-- Bulk notification send modal -->
<div class="modal fade" id="sendNotificationsModal" tabindex="-1" aria-labelledby="notificationModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content rounded-4 shadow-lg overflow-hidden">
            <form method="post" id="sendNotificationForm">
                <div class="modal-header bg-primary text-white">
                    <h1 class="modal-title fs-5" id="notificationModalLabel">Send Notification</h1>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="notification_title" class="form-label">Notification Title: </label>
                        <input class="form-control" type="text" name="notification_title" id="notification_title" required>
                    </div>
                    <div class="mb-3">
                        <label for="notification_message" class="form-label">Notification Message: </label>
                        <input class="form-control" type="text" name="notification_message" id="notification_message" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send</button>
                </div>
            </form>
        </div>
    </div>
</div>