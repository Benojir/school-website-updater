<div class="modal fade" id="globalStudentActionModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow">

            <div class="modal-header bg-light">
                <h5 class="modal-title">
                    <i class="fas fa-user-graduate text-primary me-2"></i>
                    Manage: <strong id="actionModalName">Student Name</strong> (<span id="actionModalId">ID</span>)
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body p-4">

                <h6 class="text-uppercase text-muted mb-3 fw-bold" style="font-size: 0.8rem; letter-spacing: 1px;">Profile & Academics</h6>
                <div class="row g-3 mb-4">
                    <div class="col-6 col-md-3">
                        <a target="_blank" id="linkEditProfile" href="#" class="btn btn-outline-primary w-100 p-3 h-100 d-flex flex-column align-items-center justify-content-center gap-2">
                            <i class="fas fa-edit fa-lg"></i>
                            <span>Edit Profile</span>
                        </a>
                    </div>
                    <div class="col-6 col-md-3">
                        <a id="linkViewDetails" target="_blank" href="#" class="btn btn-outline-primary w-100 p-3 h-100 d-flex flex-column align-items-center justify-content-center gap-2">
                            <i class="fas fa-eye fa-lg"></i>
                            <span>View Details</span>
                        </a>
                    </div>
                    <div class="col-6 col-md-3">
                        <a target="_blank" id="linkMarkEntry" href="#" class="btn btn-outline-primary w-100 p-3 h-100 d-flex flex-column align-items-center justify-content-center gap-2">
                            <i class="fas fa-pen-nib fa-lg"></i>
                            <span>Mark Entry</span>
                        </a>
                    </div>
                    <div class="col-6 col-md-3">
                        <a target="_blank" id="linkResults" href="#" class="btn btn-outline-primary w-100 p-3 h-100 d-flex flex-column align-items-center justify-content-center gap-2">
                            <i class="fas fa-poll fa-lg"></i>
                            <span>Results</span>
                        </a>
                    </div>
                </div>

                <hr class="text-muted opacity-25">

                <h6 class="text-uppercase text-muted mb-3 fw-bold" style="font-size: 0.8rem; letter-spacing: 1px;">Financial Management</h6>
                <div class="row g-2 mb-4">
                    <div class="col-md-4">
                        <div class="card h-100 border-success border-opacity-25 bg-success bg-opacity-10">
                            <div class="card-body p-2 text-center">
                                <strong class="text-success d-block mb-2">Monthly</strong>
                                <div class="d-grid gap-2">
                                    <button id="btnMonthlyUnpaid" class="btn btn-sm btn-light text-success border-0 shadow-sm text-start">
                                        <i class="fas fa-exclamation-circle me-1"></i> Unpaid
                                    </button>
                                    <button id="btnMonthlyFeesEntry" class="btn btn-sm btn-light text-success border-0 shadow-sm text-start">
                                        <i class="fas fa-money-bill-1 me-1"></i> Fees Entry
                                    </button>
                                    <button id="btnMonthlyPaymentsEntry" class="btn btn-sm btn-light text-success border-0 shadow-sm text-start">
                                        <i class="fas fa-money-bill-1 me-1"></i> Payments Entry
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card h-100 border-info border-opacity-25 bg-info bg-opacity-10">
                            <div class="card-body p-2 text-center">
                                <strong class="text-primary d-block mb-2">Admission</strong>
                                <div class="d-grid gap-2">
                                    <button id="btnAdmissionUnpaid" class="btn btn-sm btn-light text-primary border-0 shadow-sm text-start">
                                        <i class="fas fa-exclamation-circle me-1"></i> Unpaid
                                    </button>
                                    <button id="btnAdmissionFeesEntry" class="btn btn-sm btn-light text-primary border-0 shadow-sm text-start">
                                        <i class="fas fa-money-bill-1 me-1"></i> Fees Entry
                                    </button>
                                    <button id="btnAdmissionPaymentsEntry" class="btn btn-sm btn-light text-primary border-0 shadow-sm text-start">
                                        <i class="fas fa-money-bill-1 me-1"></i> Payments Entry
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card h-100 border-warning border-opacity-25 bg-warning bg-opacity-10">
                            <div class="card-body p-2 text-center">
                                <strong class="text-dark d-block mb-2">Extra Fees</strong>
                                <div class="d-grid gap-2">
                                    <button id="btnExtraManage" class="btn btn-sm btn-light text-dark border-0 shadow-sm text-start">
                                        <i class="fas fa-cog me-1"></i> Manage
                                    </button>
                                    <button id="btnExtraHistory" class="btn btn-sm btn-light text-dark border-0 shadow-sm text-start">
                                        <i class="fas fa-list me-1"></i> History
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <hr class="text-muted opacity-25">

                <h6 class="text-uppercase text-muted mb-3 fw-bold" style="font-size: 0.8rem; letter-spacing: 1px;">More Actions</h6>

                <div class="row g-3 mb-4 justify-content-center">
                    <div class="col-6 col-md-3">
                        <a id="btnAdmissionForm" href="javascript:void(0)" class="btn btn-outline-primary w-100 p-3 h-100 d-flex flex-column align-items-center justify-content-center gap-2">
                            <i class="fas fa-file-download fa-lg"></i>
                            <span>Admission Form</span>
                        </a>
                    </div>
                    <div class="col-6 col-md-3">
                        <a id="btnPermissions" href="javascript:void(0)" class="btn btn-outline-primary w-100 p-3 h-100 d-flex flex-column align-items-center justify-content-center gap-2">
                            <i class="fas fa-key fa-lg"></i>
                            <span>Permissions</span>
                        </a>
                    </div>
                </div>

                <hr class="text-muted opacity-25">

                <div class="d-flex justify-content-center align-items-center gap-3">
                    <button id="btnDeactiveStudent" class="btn btn-warning btn-sm">
                        <i class="fas fa-ban me-1"></i> Deactive Student
                    </button>
                    <button id="btnDeleteStudent" class="btn btn-danger btn-sm">
                        <i class="fas fa-trash-alt me-1"></i> Delete Student
                    </button>
                </div>

            </div>
        </div>
    </div>
</div>