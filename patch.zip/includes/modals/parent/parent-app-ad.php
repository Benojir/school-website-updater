<div class="modal fade" id="parentAppAdvertiseModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content ad-modal-content rounded-4">

            <button type="button" class="btn-close btn-close-custom" data-bs-dismiss="modal" aria-label="Close"></button>

            <div class="ad-header">
                <div class="app-icon-wrapper">
                    <img src="<?php echo BASE_URL;?>/uploads/school/logo-square.png" alt="Parent App Icon" class="app-icon-img">
                </div>
            </div>

            <div class="modal-body ad-body-content">

                <div class="rating-stars">
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <i class="fa-solid fa-star"></i>
                    <span class="text-muted ms-2 small">(4.9/5)</span>
                </div>

                <h3 class="ad-title">Stay Connected</h3>
                <p class="ad-text">
                    Ensure your child's digital safety. Monitor activity, set limits, and track location in real-time with the <strong>Ultimate Parent App</strong>.
                </p>

                <div class="row g-2">
                    <div class="col-12">
                        <a href="<?php echo BASE_URL;?>/apps/parent/" class="store-btn btn-primary-custom">
                            <i class="fa-brands fa-android fa-lg"></i>
                            <span>Download</span>
                        </a>
                    </div>
                    <!-- <div class="col-12">
                        <a href="#" class="store-btn btn-outline-custom">
                            <i class="fa-brands fa-android fa-lg"></i>
                            <span>Download APK</span>
                        </a>
                    </div> -->
                </div>

                <div class="mt-3">
                    <a href="#" id="dont_show_again" class="small text-muted text-decoration-none" data-bs-dismiss="modal">No thanks, don't show again</a>
                </div>

            </div>
        </div>
    </div>
</div>

<style>
    /* Remove default modal borders/padding for a cleaner canvas */
    .ad-modal-content {
        border: none;
        border-radius: 1.5rem;
        /* Matches rounded-4/5 */
        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
        overflow: hidden;
        /* Keeps children inside rounded corners */
        background: #fff;
        position: relative;
    }

    /* The Close Button (Absolute Top Right) */
    .btn-close-custom {
        position: absolute;
        top: 15px;
        right: 15px;
        z-index: 10;
        background-color: rgba(255, 255, 255, 0.2);
        border-radius: 50%;
        padding: 0.5rem;
        backdrop-filter: blur(5px);
        transition: all 0.3s ease;
    }

    .btn-close-custom:hover {
        background-color: rgba(255, 255, 255, 0.5);
        transform: rotate(90deg);
    }

    /* The Top Section (Gradient) */
    .ad-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        /* Modern Purple/Blue */
        height: 140px;
        width: 100%;
        position: relative;
        display: flex;
        justify-content: center;
        align-items: flex-end;
    }

    /* The App Icon (Floating Effect) */
    .app-icon-wrapper {
        width: 100px;
        height: 100px;
        background: white;
        border-radius: 22px;
        padding: 5px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        margin-bottom: -40px;
        /* Pulls the icon down halfway */
        z-index: 5;
    }

    .app-icon-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 18px;
    }

    /* Content Area */
    .ad-body-content {
        padding: 55px 30px 30px 30px;
        /* Top padding accounts for the floating icon */
        text-align: center;
    }

    .ad-title {
        font-weight: 800;
        color: #2d3748;
        margin-bottom: 0.5rem;
    }

    .ad-text {
        color: #718096;
        font-size: 0.95rem;
        line-height: 1.6;
        margin-bottom: 1.5rem;
    }

    /* Download Buttons */
    .store-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        width: 100%;
        padding: 12px;
        border-radius: 12px;
        font-weight: 600;
        transition: transform 0.2s, box-shadow 0.2s;
        margin-bottom: 10px;
        text-decoration: none;
    }

    .btn-primary-custom {
        background-color: #2d3748;
        color: white;
    }

    .btn-primary-custom:hover {
        background-color: #1a202c;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(45, 55, 72, 0.3);
        color: white;
    }

    .btn-outline-custom {
        background-color: transparent;
        border: 2px solid #e2e8f0;
        color: #2d3748;
    }

    .btn-outline-custom:hover {
        background-color: #f7fafc;
        border-color: #cbd5e0;
        color: #2d3748;
    }

    .rating-stars {
        color: #ecc94b;
        font-size: 0.9rem;
        margin-bottom: 10px;
    }
</style>

<script>
    $(document).ready(function() {

        const isAndroid = /Android/i.test(navigator.userAgent);

        // 1. Check if the cookie 'hide_parent_app_ad' exists
        // logical check: if index is -1, the cookie does NOT exist
        if (document.cookie.indexOf('hide_parent_app_ad=true') === -1) {
            if (isAndroid) {
                $('#parentAppAdvertiseModal').modal('show');
            }
        }

        // 2. Handle the "No thanks" click event
        $('#dont_show_again').on('click', function() {
            // Calculate 1 days in seconds
            var seconds = 1 * 24 * 60 * 60;

            // Set the cookie:
            // name=value
            // max-age=seconds (how long it lives)
            // path=/ (available on the whole site)
            document.cookie = "hide_parent_app_ad=true; max-age=" + seconds + "; path=/";
        });
    });
</script>