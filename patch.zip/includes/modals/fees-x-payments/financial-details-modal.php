<div class="modal fade" id="studentFinancialDetailsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content shadow-lg overflow-hidden">
            <div class="modal-header bg-primary text-white">
                <h1 class="modal-title fs-5" id="studentFinancialDetailsModalLabel">Student Financial Details</h1>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <div class="modal-body" id="studentFinancialDetailsModalBody">
                </div>
            
            <div class="modal-footer bg-light justify-content-center">
                <button type="button" class="btn btn-primary" onclick="showUpdateMonthlyFeesModal()">
                    <i class="fas fa-edit me-1"></i> Update Monthly Fees
                </button>
            </div>
        </div>
    </div>
</div>