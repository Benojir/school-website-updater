<div class="modal fade" id="studentFinancialDetailsModal" tabindex="-1" aria-labelledby="studentFinancialDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content shadow-lg overflow-hidden">
            <div class="modal-header bg-primary text-white">
                <h1 class="modal-title fs-5" id="studentFinancialDetailsModalLabel">Student Details</h1>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="studentFinancialDetailsModalBody">
             <!-- Data will be loaded via ajax -->
            </div>
        </div>
    </div>
</div>