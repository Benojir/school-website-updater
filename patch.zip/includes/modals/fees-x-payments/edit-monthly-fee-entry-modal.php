<div class="modal fade" id="editMonthlyFeeEntryModal" tabindex="-1" aria-labelledby="editMonthlyFeeEntryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content shadow-lg border-0 rounded-4">

            <div class="modal-header bg-primary text-white border-0 py-3">
                <h5 class="modal-title fw-bold" id="editMonthlyFeeEntryModalLabel">Edit Monthly Fee Entry</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body p-4" id="editMonthlyFeeEntryModalBody">

                <div class="row g-4 mb-4 bg-light p-3 rounded-3 border">
                    <div class="col-md-6">
                        <label class="form-label fw-bold text-secondary text-uppercase fs-6 mb-1">Month</label>
                        <div id="editMonthlyFeeEntryModalMonth" class="fw-bold text-primary fs-5"></div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold text-secondary text-uppercase fs-6 mb-1">Total Amount</label>
                        <div id="editMonthlyFeeEntryModalTotalAmount" class="fw-bold text-primary fs-5"></div>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="editMonthlyFeeEntryModalTutionFee" class="form-label text-secondary fw-medium">Tuition Fee</label>
                        <input type="text" class="form-control form-control-lg shadow-sm" id="editMonthlyFeeEntryModalTutionFee">
                    </div>
                    <div class="col-md-6">
                        <label for="editMonthlyFeeEntryModalCarFee" class="form-label text-secondary fw-medium">Car Fee</label>
                        <input type="text" class="form-control form-control-lg shadow-sm" id="editMonthlyFeeEntryModalCarFee">
                    </div>
                    <div class="col-md-6">
                        <label for="editMonthlyFeeEntryModalHostelFee" class="form-label text-secondary fw-medium">Hostel Fee</label>
                        <input type="text" class="form-control form-control-lg shadow-sm" id="editMonthlyFeeEntryModalHostelFee">
                    </div>
                    <div class="col-md-6">
                        <label for="editMonthlyFeeEntryModalCoachingFee" class="form-label text-secondary fw-medium">Coaching Fee</label>
                        <input type="text" class="form-control form-control-lg shadow-sm" id="editMonthlyFeeEntryModalCoachingFee">
                    </div>
                    <div class="col-md-6">
                        <label for="editMonthlyFeeEntryModalTiffinFee" class="form-label text-secondary fw-medium">Tiffin Fee</label>
                        <input type="text" class="form-control form-control-lg shadow-sm" id="editMonthlyFeeEntryModalTiffinFee">
                    </div>
                    <div class="col-md-6">
                        <label for="editMonthlyFeeEntryModalDiscount" class="form-label text-secondary fw-medium">Discount</label>
                        <input type="text" class="form-control form-control-lg shadow-sm" id="editMonthlyFeeEntryModalDiscount">
                    </div>
                </div>
            </div>

            <div class="modal-footer border-0 pt-2 pb-4 px-4 justify-content-end">
                <button type="button" class="btn btn-outline-secondary px-4 me-2" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" id="updateEditMonthlyFeeEntryBtn" class="btn btn-primary px-5">Update</button>
            </div>

        </div>
    </div>
</div>