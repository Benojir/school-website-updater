<div class="modal fade" id="noDueStudentsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content shadow-lg overflow-hidden">
            <div class="modal-header bg-primary text-white">
                <h1 class="modal-title fs-5">Students Without Any Due</h1>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info" role="alert">
                    These students have no pending dues. 
                    Any payment made for them will be treated as an advance payment. 
                    If the upcoming month is January, the amount will be credited directly to the student's wallet. 
                    For other months, fee requests for the upcoming months will be automatically generated first, and then the payment will be recorded.
                </div>

                <div class="table-responsive">
                    <table class="table table-light table-striped table-hover">
                        <thead>
                            <tr class="text-center align-middle">
                                <th>Student Name</th>
                                <th>Roll No</th>
                                <th>Class</th>
                                <th>Section</th>
                            </tr>
                        </thead>
                        <tbody id="noDueStudentsModalTableBody">
                            <!-- Load dynamically -->
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>