<div class="modal fade" id="updateMonthlyFeesModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content shadow-lg border-0 rounded-4">

            <div class="modal-header bg-primary text-white border-0 py-3">
                <h5 class="modal-title fw-bold">Update Monthly Fees</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body p-4" id="updateMonthlyFeesModalBody">

                <div class="row g-4 mb-4 bg-light p-3 rounded-3 border">
                    <div class="col-md-3">
                        <label class="form-label fw-bold text-secondary text-uppercase fs-6 mb-1">Student Name</label>
                        <div id="updateMonthlyFeesModalStudentName" class="fw-bold text-primary fs-5">John Doe</div>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold text-secondary text-uppercase fs-6 mb-1">Class Info</label>
                        <div id="updateMonthlyFeesModalClassInfo" class="fw-bold text-primary fs-5">Nursery - A (Roll: 51) </div>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold text-secondary text-uppercase fs-6 mb-1">Class Fee</label>
                        <div id="updateMonthlyFeesModalRegularClassFee" class="fw-bold text-primary fs-5">Nursery: ₹550</div>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold text-secondary text-uppercase fs-6 mb-1">Calculated Monthly Fee</label>
                        <div id="updateMonthlyFeesModalCalculatedClassFee" class="fw-bold text-primary fs-5">₹550</div>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="updateMonthlyFeesModalCustomClassFee" class="form-label text-secondary fw-medium">Custom Fee</label>
                        <input type="text" class="form-control form-control-lg shadow-sm" id="updateMonthlyFeesModalCustomClassFee">
                    </div>
                    <div class="col-md-6">
                        <label for="updateMonthlyFeesModalCarFee" class="form-label text-secondary fw-medium">Car Fee</label>
                        <input type="text" class="form-control form-control-lg shadow-sm" id="updateMonthlyFeesModalCarFee">
                    </div>
                    <div class="col-md-6">
                        <label for="updateMonthlyFeesModalHostelFee" class="form-label text-secondary fw-medium">Hostel Fee</label>
                        <input type="text" class="form-control form-control-lg shadow-sm" id="updateMonthlyFeesModalHostelFee">
                    </div>
                    <div class="col-md-6">
                        <label for="updateMonthlyFeesModalCoachingFee" class="form-label text-secondary fw-medium">Coaching Fee</label>
                        <input type="text" class="form-control form-control-lg shadow-sm" id="updateMonthlyFeesModalCoachingFee">
                    </div>
                    <div class="col-md-6">
                        <label for="updateMonthlyFeesModalTiffinFee" class="form-label text-secondary fw-medium">Tiffin Fee</label>
                        <input type="text" class="form-control form-control-lg shadow-sm" id="updateMonthlyFeesModalTiffinFee">
                    </div>
                    <div class="col-md-6" title="If you select months then it will update the existing requested monthly fee bills too">
                        <label for="updateMonthlyFeesModalSelectedMonths" class="form-label text-secondary fw-medium">Months</label>
                        <select id="updateMonthlyFeesModalSelectedMonths" multiple size="10" class="feeMonthSelect bts-multiselect" tabindex="-1"></select>
                    </div>
                    <div class="col-md-12">
                        <input type="checkbox" id="updateMonthlyFeesModalPermanentChangeCheckbox" class="form-check-input me-1" checked>
                        <label for="updateMonthlyFeesModalPermanentChangeCheckbox" class="form-check-label user-select-none">Make the changes permanent</label>
                    </div>
                </div>
            </div>

            <div class="modal-footer border-0 pt-2 pb-4 px-4 justify-content-end">
                <button type="button" class="btn btn-outline-secondary px-4 me-2" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" id="updateMonthlyFeesModalUpdateBtn" class="btn btn-primary px-5">Update</button>
            </div>

        </div>
    </div>
</div>