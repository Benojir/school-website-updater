<?php
require_once __DIR__ . '/../exports/staff-data-export.php';
$staffExportConfig = staffExportConfig($staffExportType, hasPermission(PERM_CAN_SEE_FINANCIAL_REPORT));
?>
<div class="modal fade" id="staffExportModal" tabindex="-1" aria-labelledby="staffExportModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content rounded-4 shadow-lg overflow-hidden">
            <form id="staffExportForm" method="post" target="_blank" action="../../api/download/export-staff-data.php">
                <input type="hidden" name="staff_type" value="<?= $staffExportType ?>">
                <input type="hidden" name="staff_ids" id="staffExportIds">
                <input type="hidden" name="column_order" id="staffExportColumnOrder">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="staffExportModalLabel">Export <?= $staffExportConfig['title'] ?></h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="text-muted">Select columns in the order you want them in Excel. Uncheck and select a column again to move it to the end.</p>
                    <p class="small fw-semibold" id="staffExportSelectionCount"></p>
                    <div class="row g-2">
                        <?php foreach ($staffExportConfig['columns'] as $key => $label): ?>
                            <div class="col-6 col-md-4">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input staff-export-column" id="staffExport_<?= $key ?>" value="<?= $key ?>" <?= in_array($key, ['id', 'name', 'phone'], true) ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="staffExport_<?= $key ?>"><?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?></label>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="small bg-light rounded p-2 mt-3"><strong>Column order:</strong> <span id="staffExportOrderPreview"></span></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-file-excel me-1"></i> Export Excel</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="../../assets/js/staff-data-export.js?v=<?= filemtime(__DIR__ . '/../../assets/js/staff-data-export.js') ?>"></script>
