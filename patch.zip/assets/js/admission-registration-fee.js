(function () {
    'use strict';

    const form = document.getElementById('addStudentForm');
    if (!form) return;
    const data = JSON.parse(document.getElementById('admissionRegistrationFeeData').textContent);
    const field = id => document.getElementById(id);
    const enabled = field('auto_include_admission_fee');
    const classSelect = field('class_id');
    const agreed = field('admission_fee_amount');
    const paid = field('admission_fee_paid');
    const pin = field('admission_fee_security_pin');
    const error = field('admission_fee_error');
    const warning = field('admission_fee_warning');
    let lastAcceptedPayment = '0';

    function cents(value) {
        if (!/^\d{1,8}(?:\.\d{1,2})?$/.test(String(value))) return null;
        const parts = String(value).split('.');
        return Number(parts[0]) * 100 + Number((parts[1] || '').padEnd(2, '0'));
    }

    function money(value) {
        return data.currency + ' ' + (value / 100).toFixed(2);
    }

    function update() {
        const active = enabled.checked;
        field('admission_fee_fields').hidden = !active;
        agreed.disabled = paid.disabled = !active;
        agreed.required = active;
        agreed.setCustomValidity('');
        paid.setCustomValidity('');
        agreed.classList.remove('is-invalid');
        paid.classList.remove('is-invalid');
        error.hidden = warning.hidden = true;
        error.textContent = warning.textContent = '';

        const defaultCents = cents(data.rates[classSelect.value]);
        const agreedCents = cents(agreed.value);
        const paidCents = paid.value === '' ? 0 : cents(paid.value);
        const needsPin = active && data.requiresPin && paidCents > 0;
        field('admission_fee_pin_fields').hidden = !needsPin;
        pin.disabled = !needsPin;
        pin.required = needsPin;
        if (!needsPin) pin.value = '';

        field('admission_fee_default').value = defaultCents === null ? '' : money(defaultCents);
        field('admission_fee_discount_display').textContent = '—';
        field('admission_fee_due_display').textContent = '—';
        field('admission_fee_adjustment').textContent = '';
        if (!active) return true;

        let invalidField = agreed;
        let message = '';
        if (!classSelect.value) message = 'Select a class to calculate its admission fee.';
        else if (defaultCents === null || defaultCents <= 0) message = 'Set a positive new admission fee for this class in Fee Settings first.';
        else if (agreedCents === null || agreedCents <= 0) message = 'Enter an agreed admission fee greater than zero, with at most two decimal places.';
        else if (paidCents === null) {
            invalidField = paid;
            message = 'Payment must be a non-negative amount with at most two decimal places.';
        } else if (paidCents > agreedCents) {
            invalidField = paid;
            message = 'Payment cannot exceed the agreed admission fee of ' + money(agreedCents) + '. Reduce the payment or update the agreed fee.';
        }
        paid.max = agreedCents === null ? '99999999.99' : (agreedCents / 100).toFixed(2);

        if (message) {
            invalidField.setCustomValidity(message);
            invalidField.classList.add('is-invalid');
            error.textContent = message;
            error.hidden = false;
            return false;
        }

        lastAcceptedPayment = paid.value || '0';
        field('admission_fee_discount_display').textContent = money(Math.max(0, defaultCents - agreedCents));
        field('admission_fee_due_display').textContent = money(agreedCents - paidCents);
        if (agreedCents > defaultCents) {
            field('admission_fee_adjustment').textContent = 'Agreed fee is ' + money(agreedCents - defaultCents) + ' above the default class fee.';
        }
        return true;
    }

    function useClassDefault() {
        const amount = cents(data.rates[classSelect.value]);
        agreed.value = amount === null ? '' : (amount / 100).toFixed(2);
        update();
    }

    classSelect.addEventListener('change', useClassDefault);
    enabled.addEventListener('change', function () {
        if (enabled.checked && agreed.value === '') useClassDefault();
        else update();
    });
    agreed.addEventListener('input', update);
    paid.addEventListener('input', function () {
        const agreedCents = cents(agreed.value);
        const paidCents = cents(paid.value);
        if (agreedCents !== null && paidCents !== null && paidCents > agreedCents) {
            // Reject the excess entry, keeping the previous accepted payment visible.
            const previous = cents(lastAcceptedPayment);
            paid.value = previous !== null && previous <= agreedCents ? lastAcceptedPayment : '0';
            update();
            warning.textContent = 'Payment cannot exceed the agreed admission fee of ' + money(agreedCents) + '. The excess entry was rejected.';
            warning.hidden = false;
        } else update();
    });
    form.addEventListener('reset', function () {
        lastAcceptedPayment = '0';
        setTimeout(update, 0);
    });
    window.admissionRegistrationFee = {
        validate: function () {
            const valid = update();
            if (!valid) form.reportValidity();
            return valid;
        }
    };
    update();
})();
