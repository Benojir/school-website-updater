(() => {
    'use strict';
    const root = document.getElementById('driverPayroll');
    if (!root) return;
    const $ = id => document.getElementById(id);
    const text = (tag, value, className) => { const el = document.createElement(tag); el.textContent = String(value ?? ''); if (className) el.className = className; return el; };
    const money = n => `${root.dataset.currency} ${Number(n || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/$/, '')}`;
    const cash = n => money(Number(n || 0) / 100);
    const decimal = n => (Number(n) / 100).toFixed(2);
    const paise = value => { if (!/^\d{1,8}(?:\.\d{1,2})?$/.test(String(value))) return NaN; const [a,b=''] = String(value).split('.'); return Number(a)*100+Number(b.padEnd(2,'0')); };
    const label = kind => ({ salary:'Salary payment', advance:'Advance paid', advance_return:'Advance returned', advance_recovery:'Advance recovery', recover:'Advance recovery' }[kind] || kind);
    let context, ledger, report, today, writing = false, ledgerLoading = false, reportLoading = false, ledgerSequence = 0, reportSequence = 0;
    let loadedDriver = '', loadedMonth = '', reportFilters = null;
    function initDates() {
        if (typeof window.flatpickr !== 'function') return;
        for (const input of root.querySelectorAll('input[type="date"]')) {
            if (input._flatpickr) input._flatpickr.destroy();
            window.flatpickr(input, {
                dateFormat:'Y-m-d', altInput:false, allowInput:true, disableMobile:true,
                minDate:'2000-01-01', maxDate:'2100-12-31',
                // A native dialog is in the browser's top layer. Its calendar must
                // be inside that dialog, with room to scroll on smaller screens.
                static:input.id === 'dpConfirmDate'
            });
        }
    }
    function setDateInput(id, value, limits = {}) {
        const input=$(id);
        for (const [key,date] of Object.entries(limits)) input[key]=date;
        if (input._flatpickr) {
            input._flatpickr.set({minDate:input.min||'2000-01-01', maxDate:input.max||'2100-12-31'});
            input._flatpickr.setDate(value, false, 'Y-m-d');
        } else input.value=value;
    }
    const pending = new Map();
    try { for (const [key,value] of JSON.parse(sessionStorage.getItem('driver-payroll-pending') || '[]')) pending.set(key,value); } catch (_) { /* Storage may be unavailable. */ }
    function remember() { try { sessionStorage.setItem('driver-payroll-pending', JSON.stringify([...pending].slice(-30))); } catch (_) {} }
    function feedback(target, message, type = 'info') { const el = typeof target === 'string' ? $(target) : target; el.hidden = !message; el.textContent = message; el.className = el.id === 'dpMessage' ? type : `dp-feedback ${type}`; if (type === 'error') el.focus(); }
    async function api(params, body) {
        const url = new URL(root.dataset.endpoint, location.href);
        if (params) for (const [key,value] of Object.entries(params)) if (value !== '' && value !== null) url.searchParams.set(key,value);
        const response = await fetch(url, { credentials:'same-origin', cache:'no-store', method:body ? 'POST':'GET', headers:body ? { 'Content-Type':'application/json', 'X-CSRF-Token':root.dataset.csrf }: {}, body:body ? JSON.stringify(body):undefined });
        let result; try { result = await response.json(); } catch (_) { throw new Error('The server response could not be read. Reload to check the ledger before retrying.'); }
        if (!response.ok || !result.success) { const error = new Error(result.message || 'Unable to process this request.'); error.status = response.status; throw error; }
        return result.data;
    }
    function stat(container, title, amount, hint, accent = false) { const el = text('div','','dp-stat' + (accent ? ' dp-accent':'')); el.append(text('span',title),text('strong',cash(amount)),text('small',hint)); container.append(el); }
    function cell(row, value) { const el = document.createElement('td'); if (value instanceof Node) el.append(value); else el.textContent = value; row.append(el); return el; }
    function empty(body, cols, message) { body.replaceChildren(); const tr = document.createElement('tr'); cell(tr,message).colSpan = cols; body.append(tr); }
    function button(title, fn, className='btn btn-sm btn-outline-primary') { const b = text('button',title,className); b.type='button'; b.addEventListener('click',fn); return b; }
    function stateBadge(s) { return text('span',s === 'draft' ? 'Draft · ' : '', 'dp-badge'); }
    function disableForms() {
        const denied = !context?.can_manage;
        const archived = ledger?.driver.status === 'deleted';
        root.classList.toggle('dp-view-only', !context?.can_manage);
        for (const form of [$('dpQuickForm'),$('dpMonthForm'),$('dpPaymentForm'),$('dpTermForm')]) for (const el of form.elements) el.disabled = writing || ledgerLoading || !ledger || denied;
        if (ledger && !writing && !ledgerLoading && !denied) {
            for (const el of $('dpMonthForm').elements) el.disabled = ledger.statement?.state === 'locked' || (archived && !ledger.statement);
            for (const el of $('dpTermForm').elements) el.disabled = archived;
            $('dpKind').querySelector('option[value="advance"]').disabled=archived;
            $('dpLock').disabled = !ledger.statement || ledger.statement.state !== 'draft';
            $('dpReopen').disabled = !ledger.statement || ledger.statement.state !== 'locked';
        } else { $('dpLock').disabled = true; $('dpReopen').disabled = true; }
        for (const id of ['dpDriver','dpMonth','dpLedgerTab','dpReportTab']) $(id).disabled = writing;
        $('dpSelector').querySelector('button').disabled = writing || ledgerLoading;
        for (const b of root.querySelectorAll('[data-write]')) b.disabled = writing || ledgerLoading || denied;
        $('dpPayslip').disabled = writing || ledgerLoading || !ledger?.statement;
        previewQuick();
        root.setAttribute('aria-busy', String(writing || ledgerLoading || reportLoading));
    }
    function currentLedger() { if (!ledger || loadedDriver !== $('dpDriver').value || loadedMonth !== $('dpMonth').value) throw new Error('Load the selected driver and month first.'); return ledger; }
    function makeInput(title, type, value, options = {}) { const l = text('label',title); const input = document.createElement('input'); input.type=type; input.className='form-control'; input.value=value; Object.assign(input,options); l.append(input); return [l,input]; }
    function makeSelect(title, choices, value) { const l=text('label',title), s=document.createElement('select'); s.className='form-select'; for(const [key,title] of choices) s.add(new Option(title,key)); s.value=value; l.append(s); return [l,s]; }
    function addAdjustment(item={}) {
        const line=text('div','','dp-adjustment');
        const [typeLabel,type] = makeSelect('Type',[['addition','Addition (+)'],['deduction','Deduction (−)']],item.type || 'addition'); type.dataset.field='type';
        const [nameLabel,name] = makeInput('Description','text',item.label || '',{required:true,maxLength:200}); name.dataset.field='label';
        const [amountLabel,amount] = makeInput('Amount','number',item.amount_paise ? decimal(item.amount_paise) : '',{required:true,min:'0.01',max:'99999999.99',step:'0.01'}); amount.dataset.field='amount';
        const remove=button('×',()=>{line.remove();previewMonth();},'btn btn-outline-danger'); remove.setAttribute('aria-label','Remove adjustment');
        line.append(typeLabel,nameLabel,amountLabel,remove); $('dpAdjustmentLines').append(line); line.addEventListener('input',previewMonth); line.addEventListener('change',previewMonth); disableForms();
    }
    function adjustments() { return [...$('dpAdjustmentLines').children].map(line => Object.fromEntries([...line.querySelectorAll('[data-field]')].map(i=>[i.dataset.field,i.value]))); }
    function previewMonth() {
        if (!ledger) return;
        let net=$('dpBase').value === '' ? ledger.estimate.base_paise : paise($('dpBase').value);
        for(const item of adjustments()) net += (item.type==='addition'?1:-1)*paise(item.amount);
        $('dpNetPreview').textContent=Number.isFinite(net) ? `Reviewed net salary: ${cash(net)} · already settled: ${cash((ledger.statement?.paid_paise||0)+(ledger.statement?.recovered_paise||0))}`:'Enter valid amounts for every line to preview net salary.';
    }
    function addPaymentLine(month=loadedMonth) {
        const line=text('div','','dp-payment-line');
        const months=ledger.history.filter(h=>h.state==='locked' && h.due_paise>0);
        const [monthLabel,select]=makeSelect('Salary month · outstanding', months.length ? months.map(h=>[h.salary_month,`${h.salary_month} · ${cash(h.due_paise)}`]):[['','No locked salary with a balance']],month);
        if (!select.value && months.length) select.value=months[0].salary_month;
        select.dataset.field='month'; select.required=true;
        const selected=()=>months.find(h=>h.salary_month===select.value);
        const [amountLabel,amount]=makeInput('Pay this month','number',selected()?decimal(selected().due_paise):'',{required:true,min:'0.01',max:'99999999.99',step:'0.01'}); amount.dataset.field='amount';
        select.addEventListener('change',()=>{amount.value=selected()?decimal(selected().due_paise):'';previewPayment();});
        amount.addEventListener('input',previewPayment);
        const remove=button('×',()=>{line.remove();previewPayment();},'btn btn-outline-danger'); remove.setAttribute('aria-label','Remove salary month');
        line.append(monthLabel,amountLabel,remove); $('dpPaymentLines').append(line); previewPayment(); disableForms();
    }
    function paymentLines() { return [...$('dpPaymentLines').children].map(line=>{const month=line.querySelector('[data-field="month"]').value;return {month,amount:line.querySelector('[data-field="amount"]').value,version:ledger.history.find(h=>h.salary_month===month)?.version};}); }
    function previewPayment() {
        if (!ledger) return;
        const kind=$('dpKind').value, salary=kind==='salary', recovery=kind==='recover';
        $('dpPaymentAllocations').hidden=!salary; $('dpCashFields').hidden=recovery;
        for(const el of $('dpPaymentAllocations').querySelectorAll('input,select')) el.required=salary;
        $('dpPaymentAmount').readOnly=salary;
        $('dpReference').required=!recovery && $('dpMethod').value!=='cash';
        if (salary) { const sum=paymentLines().reduce((sum,a)=>sum+paise(a.amount),0); $('dpPaymentAmount').value=Number.isFinite(sum)&&sum>0?decimal(sum):''; }
        const amount=paise($('dpPaymentAmount').value);
        const hint=recovery?`Available advance: ${cash(ledger.advance_paise)} · this month due: ${cash(ledger.statement?.due_paise || 0)}. No new money is paid.`:kind==='advance_return'?`Unrecovered advance: ${cash(ledger.advance_paise)}. This records money received back from the driver.`:kind==='advance'?`Unrecovered advance after this payment: ${cash(ledger.advance_paise+(Number.isFinite(amount)?amount:0))}. Allocate it to salary later.`:`New money paid: ${Number.isFinite(amount)?cash(amount):'—'}. Allocations must stay within each month's outstanding salary.`;
        $('dpPaymentPreview').textContent=hint;
    }
    function quickDue() {
        if (!ledger) return NaN;
        return ledger.statement ? ledger.statement.due_paise : !ledger.terms.length ? paise($('dpQuickSalary').value) : ledger.estimate.base_paise;
    }
    function previewQuick(suggestAmount = false) {
        if (!ledger) { $('dpQuickSubmit').disabled = true; return; }
        const due = quickDue(), useAdvance = $('dpQuickUseAdvance').checked;
        const recovery = useAdvance ? paise($('dpQuickRecovery').value) : 0;
        if (suggestAmount) $('dpQuickAmount').value = Number.isFinite(due) && Number.isFinite(recovery) ? decimal(Math.max(0,due-recovery)) : '';
        const amount = paise($('dpQuickAmount').value), left = due-amount-recovery;
        const setup = !ledger.statement && !ledger.terms.length;
        const unsupported = !ledger.statement && (ledger.driver.status==='deleted' || (!setup && ledger.estimate.covered_days===0));
        $('dpQuickSetup').hidden=!setup; $('dpQuickSalary').required=setup;
        $('dpQuickRecoveryLabel').hidden=!useAdvance; $('dpQuickRecovery').required=useAdvance;
        $('dpQuickReferenceLabel').hidden=$('dpQuickMethod').value==='cash';
        $('dpQuickReference').required=amount>0 && $('dpQuickMethod').value!=='cash';
        $('dpQuickRecovery').setCustomValidity(useAdvance && (!Number.isFinite(recovery) || recovery<=0 || recovery>ledger.advance_paise || recovery>due) ? 'Use a positive amount within available advance and outstanding salary.' : '');
        $('dpQuickAmount').setCustomValidity(Number.isFinite(left) && left<0 ? 'Payment plus advance recovery exceeds the outstanding salary.' : '');
        let message;
        if (unsupported) message='No salary is configured for this month. Open More options to review employment dates or enter a manual calculation.';
        else if (ledger.statement && due===0) message='This salary month is fully settled. Payments remain available in salary history.';
        else if (!Number.isFinite(due)) message='Enter the monthly salary once. The payment amount will be filled in for you.';
        else if (!Number.isFinite(amount) || !Number.isFinite(recovery)) message='Enter a valid payment amount to see the remaining salary.';
        else if (left<0 || recovery>ledger.advance_paise) message='Payment and advance recovery must stay within salary due and available advance.';
        else message=`Salary outstanding: ${cash(due)} · Pay now: ${cash(amount)}${useAdvance?` · Advance used: ${cash(recovery)}`:''} · Remaining: ${cash(left)}`;
        $('dpQuickPreview').textContent=message;
        $('dpQuickSubmit').textContent=amount===0 && recovery>0 ? 'Settle salary using advance' : 'Record salary payment';
        $('dpQuickSubmit').disabled=writing || ledgerLoading || !context?.can_manage || unsupported || !Number.isFinite(left) || amount+recovery<=0 || left<0 || recovery>ledger.advance_paise || (useAdvance && recovery<=0);
    }
    function renderQuick() {
        $('dpQuickForm').reset(); $('dpQuickDetails').open=false;
        setDateInput('dpQuickDate',today,{max:today});
        $('dpQuickMonth').textContent=loadedMonth;
        $('dpQuickHelp').textContent=ledger.statement ? 'Uses the saved salary, including its bonuses and deductions.' : 'Salary and payment are saved together. No separate prepare or lock steps.';
        $('dpQuickSetupHelp').textContent=`Saved from ${loadedMonth}-01 and reused for following months. For a mid-month start or custom salary, use More options / Salary terms.`;
        $('dpQuickAdvance').hidden=ledger.advance_paise<=0;
        $('dpQuickAdvanceLabel').textContent=`Use earlier advance with this salary · ${cash(ledger.advance_paise)} available`;
        $('dpQuickRecovery').value=''; previewQuick(true);
    }
    function renderLedger() {
        const s=ledger.statement;
        $('dpDriverTitle').textContent=ledger.driver.name;
        $('dpLedgerSubtitle').textContent=`Salary month ${ledger.month} · ${ledger.driver.status} · All saved months outstanding: ${cash(ledger.all_due_paise)}`;
        $('dpSummary').replaceChildren();
        stat($('dpSummary'),s?'Net salary':'Suggested salary',s?.net_paise??ledger.estimate.base_paise,s?'Saved monthly calculation':'Saved with your first payment');
        stat($('dpSummary'),'Salary paid',s?.paid_paise||0,'New money paid against this month');
        stat($('dpSummary'),'Salary outstanding',s?.due_paise||0,`Advance used: ${cash(s?.recovered_paise||0)}`,true);
        stat($('dpSummary'),'Unrecovered advance',ledger.advance_paise,'Available across salary months');
        $('dpDraftNotice').textContent=!s?'Quick payment saves this month’s salary and payment together. Enter the monthly salary below if this is the first time.':s.state==='draft'?'Quick payment uses this saved salary. To change its base, bonuses or deductions first, open More options.':`Salary ${s.status}. Pay any remaining amount below; open More options for corrections or other entries.`;
        const breakdown=$('dpBreakdown'); breakdown.replaceChildren();
        function pair(title,value,total=false){const row=text('div','','dp-breakdown-row'+(total?' total':''));row.append(text('span',title),text('strong',cash(value)));breakdown.append(row);}
        if (s) { pair(s.snapshot.manual_base?'Manual base salary':'Prorated base salary',s.base_paise); for(const a of s.snapshot.adjustments) pair(`${a.type==='addition'?'+':'−'} ${a.label}`,a.amount_paise); pair('Net salary',s.net_paise,true);pair('Salary payments',s.paid_paise);pair('Advance recovered',s.recovered_paise);pair('Outstanding',s.due_paise,true);breakdown.append(text('p',s.snapshot.reason,'small text-muted mt-3')); }
        else breakdown.append(text('p',`Suggested base ${cash(ledger.estimate.base_paise)} · ${ledger.estimate.covered_days}/${ledger.estimate.calendar_days} covered calendar days. Save a calculation to create salary due.`,'text-muted'));
        const reversed=new Set(ledger.allocations.filter(a=>a.reversal_of_id).map(a=>String(a.reversal_of_id)));
        const body=$('dpAllocations');body.replaceChildren();
        for(const a of ledger.allocations){const tr=document.createElement('tr');cell(tr,a.entry_date);cell(tr,`${a.reversal_of_id?'Reversal · ':''}${label(a.kind)}${reversed.has(String(a.id))?' · reversed':''}`);cell(tr,cash(Number(a.amount_paise)*(a.reversal_of_id?-1:1)));cell(tr,`${a.reference||''} ${a.reason}`);const c=cell(tr,'');c.className='dp-admin';if(a.kind==='advance_recovery'&&!a.reversal_of_id&&!reversed.has(String(a.id))){const b=button('Reverse',()=>reverse('reverse_recovery',a.id,a.driver_id,`${cash(a.amount_paise)} advance recovery for ${a.salary_month}`,a.entry_date));b.dataset.write='1';c.append(b);}body.append(tr);}
        if(!body.children.length)empty(body,5,'No salary payments or recoveries for this month.');
        const history=$('dpHistory');history.replaceChildren();
        for(const h of ledger.history){const tr=document.createElement('tr');cell(tr,button(h.salary_month,()=>{$('dpMonth').value=h.salary_month;loadLedger();},'btn btn-link p-0'));for(const key of ['net_paise','paid_paise','recovered_paise','due_paise'])cell(tr,cash(h[key]));const badge=stateBadge(h.state);badge.append(document.createTextNode(h.status));badge.classList.add(h.status);cell(tr,badge);history.append(tr);}
        if(!history.children.length)empty(history,6,'No prepared salary months yet.');
        $('dpHistoryHelp').textContent=`Showing the latest ${ledger.history.length} of ${ledger.month_count} saved months. Select any older month above to view it directly.`;
        $('dpTerms').replaceChildren();for(const t of [...ledger.terms].reverse()){const tr=document.createElement('tr');for(const v of [t.effective_date,t.end_date||'Until revised',cash(t.monthly_paise),t.reason])cell(tr,v);$('dpTerms').append(tr);}if(!ledger.terms.length)empty($('dpTerms'),4,'No salary terms yet. Set the salary and effective date below, or use a reviewed manual base amount.');
        $('dpAudit').replaceChildren();for(const a of ledger.audit)$('dpAudit').append(text('p',`${a.created_at} UTC · ${a.action_name.replaceAll('_',' ')} · Admin #${a.actor_id} · ${a.reason}`,'dp-audit-row'));
        $('dpBase').value=s?.snapshot.manual_base?decimal(s.base_paise):'';
        $('dpMonthReason').value='';$('dpAdjustmentLines').replaceChildren();for(const a of s?.snapshot.adjustments||[])addAdjustment(a);
        $('dpEstimate').textContent=`Current salary terms suggest ${cash(ledger.estimate.base_paise)}, covering ${ledger.estimate.covered_days}/${ledger.estimate.calendar_days} calendar days. Saving recalculates using these current terms.`;
        $('dpPaymentForm').reset();setDateInput('dpPaymentDate',today,{max:today});$('dpPaymentLines').replaceChildren();addPaymentLine();
        $('dpTermForm').reset();setDateInput('dpTermDate',loadedMonth+'-01');setDateInput('dpTermEnd','');previewMonth();previewPayment();renderQuick();
        for(const el of root.querySelectorAll('#dpLedger .dp-feedback'))feedback(el,'');
        $('dpLedger').hidden=false;disableForms();
    }
    async function loadLedger() {
        if(writing)return;const id=$('dpDriver').value,month=$('dpMonth').value;const seq=++ledgerSequence;
        ledger=null;$('dpLedger').hidden=true;ledgerLoading=true;disableForms();feedback('dpMessage','Loading driver salary…');
        try { if(!id||!month)throw new Error('Choose a driver and salary month.');const data=await api({action:'ledger',driver_id:id,month});if(seq!==ledgerSequence)return false;if(data.month!==month||String(data.driver.id)!==id)throw new Error('Salary response does not match this selection. Reload.');ledger=data;loadedDriver=id;loadedMonth=month;renderLedger();feedback('dpMessage','');return true; }
        catch(e){if(seq===ledgerSequence)feedback('dpMessage',e.message,'error');return false;}
        finally{if(seq===ledgerSequence){ledgerLoading=false;disableForms();}}
    }
    function review(title,message,extra=false,dateRequired=false,minDate='') {
        if($('dpConfirm').open)return Promise.resolve(null);
        $('dpConfirmTitle').textContent=title;$('dpConfirmText').textContent=message;$('dpConfirmExtra').hidden=!extra;$('dpConfirmReason').value='';$('dpConfirmReason').required=extra;$('dpConfirmReason').disabled=!extra;$('dpConfirmDateLabel').hidden=!dateRequired;$('dpConfirmDate').required=dateRequired;$('dpConfirmDate').disabled=!dateRequired;setDateInput('dpConfirmDate',today,{max:today,min:minDate});
        return new Promise(resolve=>{const dialog=$('dpConfirm'),form=dialog.querySelector('form');const submit=e=>{e.preventDefault();const input=$('dpConfirmDate'),date=input.value;input.setCustomValidity('');if(dateRequired&&(!/^\d{4}-\d{2}-\d{2}$/.test(date)||date<(input.min||'2000-01-01')||date>input.max||Number.isNaN(Date.parse(date+'T00:00:00Z'))||new Date(date+'T00:00:00Z').toISOString().slice(0,10)!==date))input.setCustomValidity('Choose a correction date on or after the original entry and no later than today.');if(!form.reportValidity())return;dialog.close('confirm');};const close=()=>{form.removeEventListener('submit',submit);dialog.removeEventListener('close',close);$('dpConfirmDate')._flatpickr?.close();$('dpConfirmDate').setCustomValidity('');resolve(dialog.returnValue==='confirm'?{reason:$('dpConfirmReason').value,date:$('dpConfirmDate').value}:null);};form.addEventListener('submit',submit);dialog.addEventListener('close',close);dialog.returnValue='';dialog.showModal();});
    }
    async function write(input,origin,confirmation,reviewed=false) {
        if(writing||ledgerLoading)return;
        const target=origin.querySelector('.dp-feedback')||$('dpMessage');
        try {
            if(!context.can_manage)throw new Error('You have read-only access.');
            if(!reviewed){const approval=await review('Review entry',confirmation);if(!approval)return;}
            writing=true;disableForms();feedback(target,'Saving…');
            const signature=JSON.stringify(input);let key=pending.get(signature);if(!key){key=crypto.randomUUID().replaceAll('-','');pending.set(signature,key);remember();}
            let result;
            try{result=await api(null,{...input,request_key:key});pending.delete(signature);remember();}
            catch(e){if([403,409,422].includes(e.status)){pending.delete(signature);remember();}throw e;}
            writing=false;disableForms();
            const reversal=input.action.startsWith('reverse_'),receipt=result.receipt||(reversal&&result.payment_id?`DSP-${result.payment_id}`:'');
            const saved=`${reversal?'Reversal saved successfully':'Saved successfully'}${receipt?` · ${receipt}`:''}.`;
            // A report can reverse another driver without loading that driver's
            // ledger. Never let a failed refresh imply the successful POST failed.
            const ledgerRefreshed=String(input.driver_id)===$('dpDriver').value ? await loadLedger() : true;
            if(reportFilters){reportSequence++;report=null;$('dpReport').hidden=true;$('dpCSV').disabled=true;$('dpPrintReport').disabled=true;}
            const reportRefreshed=!$('dpReportPanel').hidden&&reportFilters ? await loadReport(1) : true;
            const failed=[!ledgerRefreshed?'driver ledger':'',!reportRefreshed?'payment report':''].filter(Boolean);
            const message=failed.length?`${saved} Could not refresh the ${failed.join(' and ')}. Reload to see the latest records; do not repeat this saved entry.`:saved;
            feedback('dpMessage',message,failed.length?'warning':'success');feedback(target,message,failed.length?'warning':'success');
        }catch(e){feedback(target,`${e.message} If the connection failed, reload to check the ledger; an unchanged retry uses the same request key.`,'error');}
        finally{writing=false;disableForms();}
    }
    async function reverse(action,entry,driver,description,minDate) {
        if(writing)return;const approval=await review('Reverse recorded entry',`${description}\nThis appends a correction and restores the affected balance. Original history remains. Confirm only after checking receipts; this does not move money.`,true,true,minDate);if(!approval)return;
        const input={action,driver_id:Number(driver),...(action==='reverse_payment'?{payment_id:Number(entry)}:{allocation_id:Number(entry)}),...approval};
        // The reversal has already been reviewed, then uses the same guarded write path.
        await write(input,$('dpReportPanel').hidden?$('dpPaymentCard'):$('dpReportForm'),'',true);
    }
    $('dpCancel').addEventListener('click',()=>$('dpConfirm').close('cancel'));
    for(const event of ['input','change'])$('dpConfirmDate').addEventListener(event,()=>$('dpConfirmDate').setCustomValidity(''));
    $('dpSelector').addEventListener('submit',e=>{e.preventDefault();loadLedger();});
    for(const id of ['dpDriver','dpMonth'])$(id).addEventListener('change',()=>{$('dpAdvanced').open=false;loadLedger();});
    $('dpQuickSalary').addEventListener('input',()=>{if($('dpQuickUseAdvance').checked&&!$('dpQuickRecovery').value&&Number.isFinite(quickDue()))$('dpQuickRecovery').value=decimal(Math.min(ledger.advance_paise,quickDue()));previewQuick(true);});
    $('dpQuickAmount').addEventListener('input',()=>previewQuick());
    $('dpQuickRecovery').addEventListener('input',()=>previewQuick(true));
    $('dpQuickUseAdvance').addEventListener('change',()=>{
        const due=quickDue();$('dpQuickRecovery').value=Number.isFinite(due)?decimal(Math.min(ledger.advance_paise,due)):'';previewQuick(true);
    });
    $('dpQuickMethod').addEventListener('change',()=>{previewQuick();if($('dpQuickMethod').value!=='cash')$('dpQuickReference').focus();});
    $('dpQuickForm').addEventListener('invalid',e=>{if($('dpQuickDetails').contains(e.target))$('dpQuickDetails').open=true;},true);
    $('dpQuickForm').addEventListener('submit',e=>{
        e.preventDefault();
        try {
            currentLedger();previewQuick();if($('dpQuickSubmit').disabled)return;
            const form=e.currentTarget, amount=paise($('dpQuickAmount').value), recovery=$('dpQuickUseAdvance').checked?paise($('dpQuickRecovery').value):0;
            // Do not reuse a hidden invalid reference/date after the selected method changes.
            if(!form.reportValidity()){if(!$('dpQuickDate').validity.valid)$('dpQuickDetails').open=true;return;}
            const input={action:'quick_payment',driver_id:Number(loadedDriver),month:loadedMonth,version:ledger.statement?.version||0,estimate_hash:ledger.estimate_hash,
                monthly_salary:!ledger.statement&&!ledger.terms.length?$('dpQuickSalary').value:'',amount:$('dpQuickAmount').value,recovery_amount:decimal(recovery),date:$('dpQuickDate').value,
                method:$('dpQuickMethod').value,reference:$('dpQuickMethod').value==='cash'?'':$('dpQuickReference').value,reason:$('dpQuickNote').value.trim()||`Salary payment for ${loadedMonth}`};
            const s=ledger.statement;
            const calculation=s?`Saved net salary: ${cash(s.net_paise)}\nBase: ${cash(s.base_paise)}${s.snapshot.adjustments.map(a=>`\n${a.type==='addition'?'+':'−'} ${a.label}: ${cash(a.amount_paise)}`).join('')}`:!ledger.terms.length?`Monthly salary: ${cash(paise(input.monthly_salary))} · from ${loadedMonth}-01 (reused next month)`:`Salary: ${cash(ledger.estimate.base_paise)} · ${ledger.estimate.covered_days}/${ledger.estimate.calendar_days} covered days`;
            write(input,form,`${ledger.driver.name} · Salary ${loadedMonth}\n${calculation}\nPay now: ${cash(amount)} · ${amount>0?input.method:'no new cash payment'}${amount>0&&input.reference?` · ${input.reference}`:''}\nAdvance used: ${cash(recovery)}\nRemaining salary: ${cash(quickDue()-amount-recovery)}\nDate: ${input.date}${!s||s.state==='draft'?'\nThe reviewed salary and this payment will be saved together.':''}`);
        }catch(error){feedback($('dpQuickForm').querySelector('.dp-feedback'),error.message,'error');}
    });
    $('dpAddAdjustment').addEventListener('click',()=>{if($('dpAdjustmentLines').children.length<30)addAdjustment();});$('dpBase').addEventListener('input',previewMonth);
    $('dpAddPaymentMonth').addEventListener('click',()=>{if($('dpPaymentLines').children.length<24)addPaymentLine();});
    for(const id of ['dpKind','dpMethod','dpPaymentAmount'])$(id).addEventListener('input',previewPayment);
    $('dpMonthForm').addEventListener('submit',e=>{e.preventDefault();try{currentLedger();const input={action:'month',driver_id:Number(loadedDriver),month:loadedMonth,version:ledger.statement?.version||0,estimate_hash:ledger.estimate_hash,base_amount:$('dpBase').value,adjustments:adjustments(),reason:$('dpMonthReason').value};write(input,e.currentTarget,`Save ${ledger.driver.name}'s salary calculation for ${loadedMonth}.\n${$('dpNetPreview').textContent}\n${input.reason}`);}catch(e){feedback($('dpMonthForm').querySelector('.dp-feedback'),e.message,'error');}});
    $('dpTermForm').addEventListener('submit',e=>{e.preventDefault();try{currentLedger();const input={action:'term',driver_id:Number(loadedDriver),amount:$('dpTermAmount').value,effective_date:$('dpTermDate').value,end_date:$('dpTermEnd').value,reason:$('dpTermReason').value};write(input,e.currentTarget,`Monthly salary ${cash(paise(input.amount))} for ${ledger.driver.name} from ${input.effective_date}${input.end_date?` through ${input.end_date}`:''}.\nPreviously saved salary calculations stay fixed until explicitly revised.\n${input.reason}`);}catch(e){feedback($('dpTermForm').querySelector('.dp-feedback'),e.message,'error');}});
    for(const [id,action] of [['dpLock','lock'],['dpReopen','reopen']])$(id).addEventListener('click',async()=>{try{currentLedger();const a=await review(action==='lock'?'Lock salary calculation':'Reopen salary calculation',`${ledger.driver.name} · ${loadedMonth} · ${cash(ledger.statement.net_paise)} net.\n${action==='lock'?'Lock this reviewed amount so payments can be recorded.':'Existing payments and advance recovery remain accounted for. The revised net cannot be below money already settled.'}`,true);if(a)await write({action,driver_id:Number(loadedDriver),month:loadedMonth,version:ledger.statement.version,reason:a.reason},$('dpMonthForm'),'',true);}catch(e){feedback('dpMessage',e.message,'error');}});
    $('dpPaymentForm').addEventListener('submit',e=>{e.preventDefault();try{currentLedger();const kind=$('dpKind').value,input={action:kind==='recover'?'recover':'payment',driver_id:Number(loadedDriver),amount:$('dpPaymentAmount').value,date:$('dpPaymentDate').value,reason:$('dpPaymentReason').value};if(kind==='recover'){input.month=loadedMonth;input.version=ledger.statement?.version;}else{Object.assign(input,{kind,method:$('dpMethod').value,reference:$('dpReference').value,allocations:kind==='salary'?paymentLines():[]});}write(input,e.currentTarget,`${label(kind)} · ${ledger.driver.name} · ${cash(paise(input.amount))}\nDate ${input.date}${kind==='salary'?`\n${input.allocations.map(a=>`${a.month}: ${cash(paise(a.amount))}`).join('\n')}`:''}\n${input.reason}`);}catch(e){feedback($('dpPaymentForm').querySelector('.dp-feedback'),e.message,'error');}});
    function showTab(reportView) { $('dpLedgerPanel').hidden=reportView;$('dpReportPanel').hidden=!reportView;for(const [id,active] of [['dpLedgerTab',!reportView],['dpReportTab',reportView]]){$(id).classList.toggle('active',active);$(id).setAttribute('aria-pressed',String(active));}feedback('dpMessage',''); }
    $('dpLedgerTab').addEventListener('click',()=>showTab(false));$('dpReportTab').addEventListener('click',()=>showTab(true));
    function filters() { return {from:$('dpReportFrom').value,to:$('dpReportTo').value,driver_id:$('dpReportDriver').value,salary_month:$('dpReportMonth').value}; }
    function validateReport(data,f) { if(data.from!==f.from||data.to!==f.to||(data.salary_month||'')!==f.salary_month||!Array.isArray(data.entries)||!data.totals)throw new Error('Report response does not match these filters. Reload.'); }
    function renderReport() {
        const totals=report.totals;$('dpReportSummary').replaceChildren();stat($('dpReportSummary'),'Salary + advances paid',totals.outgoing_paise,'Before returns and corrections');stat($('dpReportSummary'),'Advances returned',totals.returned_paise,'Money received from drivers');stat($('dpReportSummary'),'Reversal corrections',totals.correction_paise,'Signed correction to recorded outflow');stat($('dpReportSummary'),'Net recorded outflow',totals.net_paise,`${totals.entry_count} entries · all pages`,true);
        $('dpReportCaption').textContent=`${report.from} through ${report.to}${report.salary_month?` · Salary month ${report.salary_month}`:''}. All totals include every matching entry.`;
        $('dpReportGroups').replaceChildren();for(const d of report.drivers){const tr=document.createElement('tr');cell(tr,d.driver_name);cell(tr,String(d.entry_count));cell(tr,cash(d.net_paise));$('dpReportGroups').append(tr);}if(!report.drivers.length)empty($('dpReportGroups'),3,'No matching payments.');
        $('dpReportRows').replaceChildren();for(const p of report.entries){const tr=document.createElement('tr');cell(tr,`DSP-${p.id} · ${p.payment_date}`);cell(tr,p.driver_name);cell(tr,`${p.reversal_of_id?`Reversal of DSP-${p.reversal_of_id} · `:''}${label(p.kind)}${p.reversed_by_entry?' · reversed':''}\n${p.allocations.map(a=>`${a.salary_month}: ${cash(a.amount_paise)}`).join(', ')}`);cell(tr,cash(p.signed_paise));cell(tr,`${p.method} · ${p.reference||'—'}`);cell(tr,p.reason);const c=cell(tr,'');c.className='dp-admin';if(!p.reversal_of_id&&!p.reversed_by_entry){const b=button('Reverse',()=>reverse('reverse_payment',p.id,p.driver_id,`DSP-${p.id} · ${p.driver_name} · ${cash(p.amount_paise)}`,p.payment_date));b.dataset.write='1';c.append(b);}$('dpReportRows').append(tr);}if(!report.entries.length)empty($('dpReportRows'),7,'No matching payment entries in this date range.');
        const pages=Math.max(1,Math.ceil(totals.entry_count/50));$('dpPage').textContent=`Page ${report.page} of ${pages} · ${totals.entry_count} entries`;$('dpPrev').disabled=report.page<=1;$('dpNext').disabled=report.page>=pages;$('dpCSV').disabled=false;$('dpPrintReport').disabled=false;$('dpReport').hidden=false;disableForms();
    }
    async function loadReport(page=1) {
        if(writing)return;const seq=++reportSequence,f=filters();report=null;reportLoading=true;$('dpReport').hidden=true;$('dpCSV').disabled=true;$('dpPrintReport').disabled=true;disableForms();feedback($('dpReportForm').querySelector('.dp-feedback'),'Loading payment report…');
        try{const data=await api({action:'report',...f,page});if(seq!==reportSequence)return false;validateReport(data,f);report=data;reportFilters=f;renderReport();feedback($('dpReportForm').querySelector('.dp-feedback'),'');return true;}
        catch(e){if(seq===reportSequence)feedback($('dpReportForm').querySelector('.dp-feedback'),e.message,'error');return false;}finally{if(seq===reportSequence){reportLoading=false;disableForms();}}
    }
    $('dpReportForm').addEventListener('submit',e=>{e.preventDefault();loadReport();});
    for(const id of ['dpReportFrom','dpReportTo','dpReportDriver','dpReportMonth'])$(id).addEventListener('change',()=>{reportSequence++;reportLoading=false;report=null;$('dpReport').hidden=true;$('dpCSV').disabled=true;$('dpPrintReport').disabled=true;disableForms();});
    $('dpPrev').addEventListener('click',()=>{if(report)loadReport(report.page-1);});$('dpNext').addEventListener('click',()=>{if(report)loadReport(report.page+1);});
    function period(last=false) { const date=new Date(today+'T12:00:00');date.setDate(1);if(last)date.setMonth(date.getMonth()-1);const year=date.getFullYear(),month=String(date.getMonth()+1).padStart(2,'0');setDateInput('dpReportFrom',`${year}-${month}-01`);setDateInput('dpReportTo',last?`${year}-${month}-${new Date(year,date.getMonth()+1,0).getDate()}`:today); }
    for(const b of root.querySelectorAll('[data-period]'))b.addEventListener('click',()=>{period(b.dataset.period==='last');loadReport();});
    function printable(title) { const area=$('dpPrintArea');area.replaceChildren(text('h2',root.dataset.school),text('h3',title),text('p',`Generated ${new Date().toLocaleString()} · ${root.dataset.currency}`));return area; }
    $('dpPayslip').addEventListener('click',()=>{try{currentLedger();if(!ledger.statement)return;const area=printable(`${ledger.driver.name} · Salary ${ledger.month}`);area.append($('dpSummary').cloneNode(true),$('dpBreakdown').cloneNode(true));const table=$('dpAllocations').closest('table').cloneNode(true);for(const el of table.querySelectorAll('.dp-admin'))el.remove();area.append(table,text('p',`Calculation state: ${ledger.statement.state}. Outstanding is after all recorded payments and advance recoveries, including later payments. Unrecovered advance is the current balance across months.`));window.print();}catch(e){feedback('dpMessage',e.message,'error');}});
    $('dpPrintReport').addEventListener('click',()=>{if(!report)return;const area=printable(`Driver payment totals · ${report.from} to ${report.to}${report.salary_month?` · Salary ${report.salary_month}`:''}`);area.append($('dpReportSummary').cloneNode(true),$('dpReportGroups').closest('table').cloneNode(true),text('p','Totals include all matching entries. Net outflow = salary + advances − advance returns + reversal corrections. Export CSV for all detailed entries. A reversal corrects a record and does not move money.'));window.print();});
    function csvCell(value) { let v=String(value??'');if(/^[\s]*[=+@-]/.test(v))v="'"+v;return '"'+v.replaceAll('"','""')+'"'; }
    $('dpCSV').addEventListener('click',async()=>{if(!report||reportLoading)return;const f={...reportFilters},base=report.totals;const target=$('dpReportForm').querySelector('.dp-feedback');$('dpCSV').disabled=true;try{let entries=[...report.entries];if(report.page!==1){const first=await api({action:'report',...f,page:1});validateReport(first,f);if(JSON.stringify(first.totals)!==JSON.stringify(base))throw new Error('Report changed during export. Reload and export again.');entries=first.entries;}const pages=Math.ceil(base.entry_count/50);for(let page=2;page<=pages;page++){const data=await api({action:'report',...f,page});validateReport(data,f);if(JSON.stringify(data.totals)!==JSON.stringify(base))throw new Error('Report changed during export. Reload and export again.');entries.push(...data.entries);feedback(target,`Exporting page ${page} of ${pages}…`);}if(entries.length!==base.entry_count||new Set(entries.map(p=>String(p.id))).size!==entries.length)throw new Error('Report entries changed during export. Reload and try again.');const rows=[['Receipt','Date','Driver','Type','Salary allocations','Signed amount','Currency','Method','Reference','Reason','Reversal of','Reversed by'],...entries.map(p=>[`DSP-${p.id}`,p.payment_date,p.driver_name,label(p.kind),p.allocations.map(a=>`${a.salary_month}: ${decimal(a.amount_paise)}`).join('; '),decimal(p.signed_paise),root.dataset.currency,p.method,p.reference,p.reason,p.reversal_of_id?`DSP-${p.reversal_of_id}`:'',p.reversed_by_entry?`DSP-${p.reversed_by_entry}`:''])];const blob=new Blob(['\ufeff'+rows.map(row=>row.map(csvCell).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`driver-payments-${f.from}-to-${f.to}.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);feedback(target,`Exported all ${entries.length} entries.`,'success');}catch(e){feedback(target,e.message,'error');}finally{$('dpCSV').disabled=!report;}});
    async function start() {disableForms();try{context=await api({action:'context'});today=context.today;root.dataset.currency=context.currency||root.dataset.currency;$('dpDriver').replaceChildren(new Option('Select driver',''));for(const d of context.drivers){const name=`${d.name} · #${d.serial_number||d.id}${d.archived?' · archived':d.status!=='active'?` · ${d.status}`:''}`;$('dpDriver').add(new Option(name,String(d.id)));$('dpReportDriver').add(new Option(name,String(d.id)));}$('dpMonth').value=today.slice(0,7);period();const initial=root.dataset.driver;if(context.drivers.some(d=>String(d.id)===initial))$('dpDriver').value=initial;else if(context.drivers.length)$('dpDriver').value=String(context.drivers[0].id);if($('dpDriver').value)await loadLedger();else feedback('dpMessage','Add a driver to start recording salaries.');}catch(e){feedback('dpMessage',e.message,'error');}finally{disableForms();}}
    initDates();start();
})();
