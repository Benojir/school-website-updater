(() => {
    'use strict';
    const form = document.getElementById('student-application-lookup');
    if (!form) return;
    const button = document.getElementById('student-lookup-submit');
    const message = document.getElementById('student-lookup-message');
    const reference = form.elements.namedItem('application_ref');
    let checking = false;
    reference.addEventListener('input', () => { reference.value = reference.value.toUpperCase(); });
    const showError = text => {
        message.textContent = text;
        message.classList.remove('d-none');
        message.classList.add('alert-danger');
    };
    form.addEventListener('submit', async event => {
        event.preventDefault();
        if (checking || !form.reportValidity()) return;
        const data = new FormData(form);
        if (!data.get('cf-turnstile-response')) {
            showError('Please complete the captcha verification.');
            return;
        }
        checking = true;
        button.disabled = true;
        button.textContent = 'Checking...';
        message.classList.add('d-none');
        try {
            const response = await fetch(form.action, {method: 'POST', body: data, credentials: 'same-origin', headers: {Accept: 'application/json'}});
            const result = await response.json();
            if (!response.ok || !result.success) throw new Error(result.message || 'The application could not be found. Please check your details and try again.');
            window.location.reload();
        } catch (error) {
            showError(error instanceof SyntaxError ? 'The server could not respond. Please try again later.'
                : (error.message || 'The application could not be loaded. Please try again.'));
            if (typeof window.turnstile?.reset === 'function') window.turnstile.reset();
            checking = false;
            button.disabled = false;
            button.textContent = 'View My Application';
        }
    });
})();
