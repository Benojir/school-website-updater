(() => {
    'use strict';
    const cfg = window.inventoryConfig;
    const $ = selector => document.querySelector(selector);
    const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[c]));
    const money = paise => cfg.currency + (Number(paise) / 100).toLocaleString('en-IN', {minimumFractionDigits:2, maximumFractionDigits:2});
    const date = value => new Date(String(value).replace(' ', 'T')).toLocaleString('en-IN', {dateStyle:'medium', timeStyle:'short'});
    const num = value => Number(value).toLocaleString('en-IN');
    const key = () => '10000000-1000-4000-8000-100000000000'.replace(/[018]/g, c => (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16));
    const modal = new bootstrap.Modal($('#inventoryModal'));
    const state = {tab:'products', page:1, products:new Map(), cart:[], kind:'sale', selectedStudent:null, saving:false, sequence:0, searchSequence:0, searchRows:{}, pending:null, report:null, doc:null};
    const labels = {purchase:'Stock purchase', sale:'Sale', gift:'Free distribution', damage:'Stock loss', return:'Full return'};
    const badge = (text, style = '') => `<span class="inventory-badge ${style}">${esc(text)}</span>`;
    const formEnd = (text = 'Save') => `<div class="alert alert-danger inventory-form-error d-none" role="alert"></div><div class="d-flex justify-content-end gap-2 mt-4"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary px-4">${text}</button></div>`;
    const input = (name, label, value = '', attrs = '', hint = '') => `<div><label class="form-label" for="inv-${name}">${label}</label><input class="form-control" id="inv-${name}" name="${name}" value="${esc(value)}" ${attrs}>${hint ? `<div class="form-text">${hint}</div>` : ''}</div>`;
    const paymentMethod = () => '<label class="form-label" for="inv-method">Payment method</label><select class="form-select" id="inv-method" name="method"><option value="cash">Cash</option><option value="online">UPI / online</option><option value="bank">Bank transfer</option></select>';
    const studentSummary = student => {
        const parents = [student.father_name ? `Father: ${student.father_name}` : '', student.mother_name ? `Mother: ${student.mother_name}` : ''].filter(Boolean).join(' · ');
        return `<span class="inventory-student-summary"><span class="inventory-student-photo"><i class="fas fa-user" aria-hidden="true"></i>${student.student_image ? `<img src="../../uploads/students/${esc(encodeURIComponent(student.student_image))}" alt="Photo of ${esc(student.name)}" loading="lazy">` : ''}</span><span class="inventory-student-info"><b>${esc(student.name)}</b><small>${esc(`${student.student_id} · ${student.class_name||''} ${student.section_name||''} · Roll ${student.roll_no||'-'}`)}</small>${parents ? `<small>${esc(parents)}</small>` : ''}</span></span>`;
    };

    async function api(action, params = {}, post = false) {
        const response = await fetch(cfg.api + (post ? '' : '?' + new URLSearchParams({action, ...params})), post ? {
            method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action, csrf:cfg.csrf, ...params})
        } : {cache:'no-store'});
        let result;
        try { result = await response.json(); } catch (_) { throw new Error('Could not read the response. Check your connection and try again.'); }
        if (!response.ok || !result.success) throw new Error(result.message || 'Unable to complete the request.');
        return result.data;
    }
    function notice(message = '') { $('#inventoryNotice').textContent = message; $('#inventoryNotice').classList.toggle('d-none', !message); }
    function showModal(title, html) {
        if (state.saving) return;
        state.searchSequence++;
        state.pending = null;
        $('#inventoryModalTitle').textContent = title;
        $('#inventoryModalBody').innerHTML = html;
        modal.show();
        setTimeout(() => $('#inventoryModalBody input:not([type=hidden])')?.focus(), 180);
    }
    function table(headers, rows) { return `<div class="table-responsive"><table class="table align-middle"><thead><tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows}</tbody></table></div>`; }
    function empty(title, description, action = '') { return `<div class="inventory-empty"><h3>${title}</h3><p>${description}</p>${action}</div>`; }

    function changeTab(tab) {
        state.tab = tab; state.page = 1; notice();
        const stock = tab === 'products', report = tab === 'report';
        document.querySelectorAll('[data-tab]').forEach(button => { const active = button.dataset.tab === tab; button.classList.toggle('active', active); button.setAttribute('aria-selected', active); });
        $('#viewTitle').textContent = {products:'Products & stock', sales:'Sales & dues', purchases:'Stock purchases', report:'Inventory profit & loss'}[tab];
        $('#viewHint').textContent = {products:'See what is available and what needs restocking.', sales:'Find a bill, collect a due or record a full return.', purchases:'Every stock purchase, with its supplier and cost.', report:'See what the school store earned for the selected dates.'}[tab];
        ['stockActions','stockStatusWrap','stockLowWrap'].forEach(id => $('#'+id).classList.toggle('d-none', !stock));
        $('#dueWrap').classList.toggle('d-none', tab !== 'sales');
        $('#searchWrap').classList.toggle('d-none', report);
        $('#reportExportWrap').classList.toggle('d-none', !report || !cfg.canReport);
        document.querySelectorAll('.date-wrap').forEach(el => el.classList.toggle('d-none', stock));
        $('#inventorySearch').value = '';
        $('#inventorySearch').placeholder = stock ? 'Product name, code or category' : 'Student, supplier or bill number';
        $('#inventoryFrom').value = report ? cfg.monthStart : '';
        $('#inventoryTo').value = report ? cfg.today : '';
        load();
    }
    async function load() {
        const sequence = ++state.sequence;
        $('#inventoryResults').innerHTML = empty('Loading…', 'Please wait a moment.');
        $('#inventoryPagination').innerHTML = '';
        notice();
        if (state.tab === 'report' && !cfg.canReport) {
            $('#inventoryResults').innerHTML = empty('Financial report access required', 'Ask the school owner to enable financial-report permission for your role.');
            return;
        }
        try {
            const params = {search:$('#inventorySearch').value, page:state.page};
            let data;
            if (state.tab === 'products') {
                data = await api('products', {...params, status:$('#stockStatus').value, low:$('#stockLow').value});
            } else if (state.tab === 'report') {
                data = await api('report', {from:$('#inventoryFrom').value, to:$('#inventoryTo').value});
            } else {
                data = await api('documents', {...params, group:state.tab, due:state.tab === 'sales' ? $('#onlyDue').value : '', from:$('#inventoryFrom').value, to:$('#inventoryTo').value});
            }
            if (sequence !== state.sequence) return;
            if (state.tab === 'products') renderProducts(data);
            else if (state.tab === 'report') renderReport(data);
            else renderDocuments(data);
            if (state.tab !== 'report') pagination(data);
        } catch (error) {
            if (sequence !== state.sequence) return;
            notice(error.message);
            $('#inventoryResults').innerHTML = empty('Could not load this view', 'Your saved entries are unchanged.', '<button class="btn btn-outline-primary" data-action="refresh">Try again</button>');
        }
    }
    function overview(data) { $('#statProducts').textContent = num(data.products); $('#statUnits').textContent = num(data.units); $('#statLow').textContent = num(data.low); }
    function renderProducts(data) {
        overview(data.overview);
        data.rows.forEach(p => state.products.set(String(p.id), p));
        if (!data.rows.length) {
            $('#inventoryResults').innerHTML = empty('No products here yet', 'Add your first book, bag or school supply. If you used filters, try clearing them.', '<button class="btn btn-primary" data-action="product">Add a product</button>');
            return;
        }
        $('#inventoryResults').innerHTML = table(['Product','Category','Available','Selling price',''], data.rows.map(p => `<tr>
            <td><div class="inventory-product-name">${esc(p.name)}</div><small class="text-muted">${esc(p.sku || 'P' + p.id)} ${Number(p.is_active) ? '' : '· Inactive'}</small></td>
            <td>${esc(p.category || '-')}</td><td><b>${num(p.stock_quantity)}</b> ${esc(p.unit)}<br>${Number(p.stock_quantity) === 0 ? badge('Out of stock','danger') : Number(p.stock_quantity) <= Number(p.low_stock_level) ? badge('Low stock','warn') : badge('In stock')}</td>
            <td>${money(p.selling_price_paise)}</td><td><div class="d-flex gap-1 justify-content-end"><button class="btn btn-sm btn-outline-primary" data-action="purchase" data-id="${p.id}" ${Number(p.is_active) ? '' : 'disabled'}>Add stock</button><button class="btn btn-sm btn-light" data-action="product" data-id="${p.id}">Edit</button><button class="btn btn-sm btn-light" data-action="movements" data-id="${p.id}">History</button></div></td></tr>`).join(''));
    }
    function renderDocuments(data) {
        if (!data.rows.length) { $('#inventoryResults').innerHTML = empty('No entries found', 'Saved entries will appear here. Try another search or date range.'); return; }
        $('#inventoryResults').innerHTML = table(['Entry / date','Student / supplier','Type','Bill amount','Balance due',''], data.rows.map(d => `<tr>
            <td><b>INV-${d.id}</b><br><small class="text-muted">${esc(date(d.created_at))}</small></td>
            <td>${esc(d.customer_name || d.supplier || 'School stock')}<br><small class="text-muted">${esc(d.student_id || d.reference)}</small></td>
            <td>${badge(labels[d.kind], d.kind === 'return' ? 'muted' : '')}${d.status === 'returned' ? '<br>'+badge('Returned','muted') : ''}</td>
            <td>${money(d.total_paise)}</td><td>${Number(d.due_paise) > 0 ? badge(money(d.due_paise),'warn') : '-'}</td>
            <td class="text-end"><button class="btn btn-sm btn-outline-primary" data-action="detail" data-id="${d.id}">View${Number(d.due_paise) > 0 ? ' / collect' : ''}</button></td></tr>`).join(''));
    }
    function pagination(data) {
        const pages = Math.max(1, Math.ceil(data.total / 30));
        $('#inventoryPagination').innerHTML = `<small class="text-muted">${num(data.total)} entries · Page ${state.page} of ${pages}</small><div class="btn-group"><button class="btn btn-sm btn-outline-secondary" data-page="${state.page-1}" ${state.page<=1?'disabled':''}>Previous</button><button class="btn btn-sm btn-outline-secondary" data-page="${state.page+1}" ${state.page>=pages?'disabled':''}>Next</button></div>`;
    }
    function renderReport(data) {
        state.report = data;
        const s = data.summary;
        const cards = [['Net sales','sales_paise'],['Cost of items sold','sold_cost_paise'],['Inventory profit / loss','profit_paise'],['Free items: cost','gifts_paise'],['Damaged / lost: cost','loss_paise'],['Stock purchases','purchases_paise']];
        $('#inventoryResults').innerHTML = `<div class="inventory-report-grid">${cards.map(([label,k]) => `<div class="inventory-stat ${k==='profit_paise'?'profit-card':''}"><span>${label}</span><strong class="${Number(s[k])<0?'text-danger':''}">${money(s[k])}</strong></div>`).join('')}</div>
            <div class="alert alert-light border small"><b>How this works:</b> Sales − cost of sold items − free-item cost − damaged/lost-item cost = inventory profit. Credit sales count when sold; collecting their dues later does not count as a new sale. Full returns reverse the sale on the return date. Unsold purchases stay in stock.</div>
            <div class="row g-3 mb-4"><div class="col-md-6"><b>Money received, less refunds:</b> ${money(s.received_paise)}<br><b>Cash after stock purchases:</b> ${money(s.cash_flow_paise)}</div><div class="col-md-6"><b>All unpaid bills, as of now:</b> ${money(s.due_paise)}<br><b>Stock value, as of now:</b> ${money(s.stock_value_paise)}</div></div>
            <h3 class="h6">Product breakdown</h3>${data.rows.length ? table(['Product','Net units sold','Net sales','Item cost incl. free / lost','Profit / loss'], data.rows.map(r => `<tr><td>${esc(r.product_name)}</td><td>${num(r.sold_quantity)}</td><td>${money(r.sales_paise)}</td><td>${money(r.cost_paise)}</td><td>${money(Number(r.sales_paise)-Number(r.cost_paise))}</td></tr>`).join('')) : empty('No stock issued in this period','Choose another date range to see sales and stock costs.')}
            <p class="small text-muted">This report covers the school store only. School fees, salaries and other school expenses are separate. Purchase entries here should not be added again as general expenses.</p>`;
    }
    function productForm(id) {
        const p = state.products.get(String(id)) || {};
        showModal(id ? 'Edit product' : 'Add a new product', `<form data-form="product"><div class="row g-3">
            <input type="hidden" name="id" value="${p.id||0}"><input type="hidden" name="version" value="${p.version||0}">
            <div class="col-md-8">${input('name','Product name',p.name||'','required maxlength="150" placeholder="e.g. Class 3 book set"')}</div>
            <div class="col-md-4">${input('sku','Product code (optional)',p.sku||'','maxlength="60" placeholder="e.g. BOOK-03"')}</div>
            <div class="col-md-6">${input('category','Category (optional)',p.category||'','maxlength="80" placeholder="Books, stationery, uniform…"')}</div>
            <div class="col-md-6">${input('unit','Counted in',p.unit||'piece','required maxlength="30"','Examples: piece, set, pack. Quantities use whole numbers.')}</div>
            <div class="col-md-6">${input('selling_price','Selling price per item',(Number(p.selling_price_paise||0)/100).toFixed(2),'type="number" min="0" max="99999999.99" step="0.01" required')}</div>
            <div class="col-md-6">${input('low_stock_level','Alert when stock reaches',p.low_stock_level??5,'type="number" min="0" max="100000" step="1" required')}</div>
            <div class="col-12"><label class="form-label" for="inv-is_active">Availability</label><select class="form-select" id="inv-is_active" name="is_active"><option value="1">Active — available for stock and sales</option><option value="0" ${p.is_active!=null&&!Number(p.is_active)?'selected':''}>Inactive — keep history, stop new sales</option></select></div></div>${formEnd('Save product')}</form>`);
    }
    function documentForm(kind, id) {
        state.kind = kind; state.cart = []; state.selectedStudent = null; state.paidTouched = false;
        const purchase = kind === 'purchase', damage = kind === 'damage';
        showModal(purchase ? 'Add purchased stock' : damage ? 'Record damaged or lost stock' : 'Sell or give items to a student', `<form data-form="document">
            ${purchase ? `<p class="text-muted small">Enter the items received and their actual purchase price. Include delivery costs in the per-item price. Purchases are recorded as paid in full.</p><div class="row g-3"><div class="col-md-6">${input('supplier','Supplier name','','required maxlength="150"')}</div><div class="col-md-6">${input('reference','Supplier bill / reference (optional)','','maxlength="100"')}</div></div>` : damage ? '<p class="text-muted">Use this for damaged, lost or missing items. Their cost is included in inventory profit/loss.</p>' : `<div class="inventory-step">1. Choose the student</div><label for="inv-student-search" class="form-label">Search by student or parent name, phone, ID, registration number or address</label><input class="form-control" id="inv-student-search" autocomplete="off" placeholder="Type at least 2 characters"><div class="inventory-search-results" id="studentResults"></div><div class="small text-success mt-2" id="selectedStudentLabel"></div><div class="mt-3"><label for="inv-kind" class="form-label">What are you doing?</label><select id="inv-kind" class="form-select"><option value="sale">Sell items</option><option value="gift">Give items free of charge</option></select></div>`}
            <div class="inventory-step">${purchase||damage?'1':'2'}. Add the products</div><label class="form-label" for="inv-product-search">Find a product</label><input class="form-control" id="inv-product-search" autocomplete="off" placeholder="Search product name or code"><div class="inventory-search-results" id="productResults"></div>
            <div id="cartBody" class="mt-3"></div><div class="inventory-total"><span>${purchase?'Purchase total':'Bill total'}</span><strong id="cartTotal">${money(0)}</strong></div>
            ${!purchase&&!damage ? `<div id="salePayment"><div class="inventory-step">3. Record payment</div><div class="row g-3"><div class="col-md-6">${input('paid','Amount received now','0.00','type="number" min="0" max="99999999.99" step="0.01" required','Enter 0 for a credit sale, or enter a partial payment.')}<button type="button" class="btn btn-link btn-sm px-0" data-action="paylater">No payment now</button></div><div class="col-md-6">${paymentMethod()}</div><div class="col-12">${input('reference','Payment reference (optional)','','maxlength="100"')}</div></div><div class="small mt-2" id="balancePreview"></div></div>` : ''}
            <div class="mt-3">${input('note',damage?'Reason for stock loss':'Note (optional)','','maxlength="500" '+(damage?'required':''))}</div>${formEnd(purchase?'Save stock purchase':damage?'Save stock loss':'Save entry')}</form>`);
        if (id && state.products.has(String(id))) addToCart(state.products.get(String(id)));
        else renderCart();
    }
    function addToCart(product) {
        const existing = state.cart.find(i => String(i.product.id) === String(product.id));
        if (existing) existing.quantity = Number(existing.quantity)+1;
        else state.cart.push({product, quantity:1, price:state.kind==='purchase'?'':(Number(product.selling_price_paise)/100).toFixed(2)});
        $('#inv-product-search').value = ''; $('#productResults').innerHTML = ''; renderCart();
    }
    function cartTotal() { return state.cart.reduce((sum, item) => sum + Math.round(Number(item.price||0)*100)*Number(item.quantity||0),0); }
    function renderCart() {
        const free = ['gift','damage'].includes(state.kind);
        $('#cartBody').innerHTML = state.cart.length ? `<div class="table-responsive"><table class="table inventory-cart"><thead><tr><th>Product</th><th>Quantity</th><th>${state.kind==='purchase'?'Buy price / item':'Price / item'}</th><th></th></tr></thead><tbody>${state.cart.map((item, i) => `<tr><td><b>${esc(item.product.name)}</b><div class="small text-muted">${num(item.product.stock_quantity)} ${esc(item.product.unit)} in stock</div></td><td><input class="form-control form-control-sm" type="number" min="1" max="100000" step="1" required aria-label="Quantity of ${esc(item.product.name)}" data-cart="quantity" data-index="${i}" value="${esc(item.quantity)}"></td><td>${free ? 'Free / no sale' : `<input class="form-control form-control-sm" type="number" min="0" max="99999999.99" step="0.01" required aria-label="Price of ${esc(item.product.name)}" data-cart="price" data-index="${i}" value="${esc(item.price)}">`}</td><td><button class="btn btn-sm btn-light" type="button" aria-label="Remove ${esc(item.product.name)}" data-action="remove" data-index="${i}">×</button></td></tr>`).join('')}</tbody></table></div>` : '<p class="small text-muted text-center py-3">Find a product above to add it to this entry.</p>';
        totals();
    }
    function totals() {
        const total = ['gift','damage'].includes(state.kind) ? 0 : cartTotal();
        $('#cartTotal').textContent = money(total);
        if ($('#inv-paid')) {
            if (!state.paidTouched) $('#inv-paid').value = (total/100).toFixed(2);
            $('#salePayment').classList.toggle('d-none', state.kind !== 'sale');
            $('#inv-paid').required = state.kind === 'sale';
            $('#balancePreview').textContent = 'Balance due after this payment: ' + money(Math.max(0,total-Math.round(Number($('#inv-paid').value||0)*100)));
        }
    }
    async function searchOptions(kind, term) {
        const sequence = ++state.searchSequence, target = $('#'+(kind==='students'?'studentResults':'productResults'));
        if (!target) return;
        if (term.length < (kind==='students'?2:1)) { target.innerHTML=''; return; }
        target.innerHTML='<div class="p-2 text-muted small">Searching…</div>';
        try {
            const data = await api(kind, {search:term,status:'active'});
            if (sequence !== state.searchSequence || !target.isConnected) return;
            const rows = kind==='students'?data:data.rows;
            state.searchRows[kind] = rows;
            target.innerHTML = rows.map((r,i) => `<button type="button" data-pick="${kind}" data-index="${i}">${kind==='students' ? studentSummary(r) : `<span><b>${esc(r.name)}</b><br><small>${esc(r.sku||r.category)}</small></span><small>${num(r.stock_quantity)} in stock · ${money(r.selling_price_paise)}</small>`}</button>`).join('') || `<div class="p-3 text-muted small">${kind==='students' ? 'No matches. Try a name, phone, student ID, registration number or address.' : 'No matches. Try another name or code.'}</div>`;
        } catch(error) { if(sequence===state.searchSequence) target.innerHTML=`<div class="p-3 text-danger">${esc(error.message)}</div>`; }
    }
    async function showDetail(id) {
        try {
            const d = await api('detail',{id}); state.doc=d;
            const items = table(['Product','Quantity','Price','Amount'], d.items.map(i=>`<tr><td>${esc(i.product_name)}</td><td>${num(i.quantity)} ${esc(i.unit)}</td><td>${money(i.unit_price_paise)}</td><td>${money(i.line_total_paise)}</td></tr>`).join(''));
            const payments = d.payments.length ? '<h3 class="h6 mt-4">Payments & refunds</h3>'+table(['Date','Amount','Method','Received / refunded by'],d.payments.map(p=>`<tr><td>${esc(date(p.created_at))}</td><td>${money(p.amount_paise)}</td><td>${esc(p.method)}<br><small>${esc(p.reference)}</small></td><td>${esc(p.admin_name||'-')}</td></tr>`).join('')) : '';
            showModal(`${labels[d.kind]} · INV-${d.id}`, `<p class="text-muted small">${esc(date(d.created_at))} · Recorded by ${esc(d.admin_name||'-')}</p><h3 class="h6">${esc(d.customer_name||d.supplier||'School stock')}</h3><p class="small">${esc(d.student_id||'')} ${esc(d.class_name||'')} ${d.status==='returned'?badge('Returned','muted'):''}</p>${items}<div class="inventory-total"><span>Total</span><strong>${money(d.total_paise)}</strong></div><p>Payment recorded: <b>${money(d.paid_paise)}</b> · Balance due: <b>${money(d.due_paise)}</b></p><p class="small text-muted">${esc(d.note)} ${esc(d.reference)}</p>${payments}<div class="d-flex flex-wrap gap-2 mt-4"><a class="btn btn-outline-primary" href="${cfg.receipt}?id=${d.id}" target="_blank" rel="noopener">Print receipt</a>${Number(d.due_paise)>0?'<button class="btn btn-primary" data-action="collect">Collect due</button>':''}${d.kind==='sale'&&d.status==='posted'?'<button class="btn btn-outline-danger ms-auto" data-action="return">Full return / cancel sale</button>':''}</div>`);
        } catch(error) { notice(error.message); }
    }
    function paymentForm(isReturn) {
        const d = state.doc;
        const amount = isReturn ? Number(d.paid_paise) : Number(d.due_paise);
        showModal(isReturn?'Return all items & record refund':'Collect payment', `<form data-form="${isReturn?'return':'collect'}"><input type="hidden" name="document_id" value="${d.id}"><h3 class="h6">${esc(d.customer_name)} · INV-${d.id}</h3>
            ${isReturn?`<div class="alert alert-warning">All items on this bill must be returned in usable condition. Stock will be restored, ${money(d.due_paise)} in dues cleared, and <b>${money(amount)}</b> recorded as refunded. Give this refund to the student when saving. For damaged returned items, record a stock loss afterwards.</div>${input('note','Reason for return','','required maxlength="500"')}`:`<p>Balance due: <b>${money(amount)}</b></p>${input('amount','Amount received',(amount/100).toFixed(2),`type="number" min="0.01" max="${amount/100}" step="0.01" required`)}`}
            <div class="row g-3 mt-1"><div class="col-md-6">${paymentMethod()}</div><div class="col-md-6">${input('reference',isReturn?'Refund reference (optional)':'Payment reference (optional)','','maxlength="100"')}</div></div>${formEnd(isReturn?'Confirm full return & refund':'Save payment')}</form>`);
    }
    async function movements(id, page=1) {
        try {
            const data=await api('movements',{product_id:id,page});
            showModal('Stock movement history',data.rows.length?table(['Date / entry','Movement','Quantity change','Stock after'],data.rows.map(r=>`<tr><td>${esc(date(r.created_at))}<br>INV-${r.document_id}<br><small>${esc(r.customer_name||r.supplier||r.note)}</small></td><td>${esc(labels[r.kind])}</td><td>${Number(r.stock_delta)>0?'+':''}${r.stock_delta}</td><td>${r.stock_after}</td></tr>`).join(''))+`<div class="d-flex justify-content-between"><button class="btn btn-sm btn-light" data-action="movements" data-id="${id}" data-move-page="${page-1}" ${page<=1?'disabled':''}>Previous</button><small>Page ${page} · ${data.total} movements</small><button class="btn btn-sm btn-light" data-action="movements" data-id="${id}" data-move-page="${page+1}" ${page*30>=data.total?'disabled':''}>Next</button></div>`:empty('No stock movements','Add stock to start this product’s history.'));
        } catch(error) { notice(error.message); }
    }
    async function saveForm(form) {
        if(state.saving || !form.reportValidity()) return;
        const data = Object.fromEntries(new FormData(form));
        let action=form.dataset.form;
        const errorBox=form.querySelector('.inventory-form-error');
        errorBox.classList.add('d-none');
        if(action==='document') {
            action=state.kind;
            if(!state.cart.length) { errorBox.textContent='Add at least one product.'; errorBox.classList.remove('d-none'); return; }
            if(['sale','gift'].includes(action)&&!state.selectedStudent) { errorBox.textContent='Search and choose a student first.'; errorBox.classList.remove('d-none'); return; }
            data.student_id=state.selectedStudent?.student_id||'';
            data.items=state.cart.map(i=>({product_id:i.product.id,quantity:i.quantity,price:i.price}));
        }
        const fingerprint=JSON.stringify({action,data});
        if(!state.pending||state.pending.fingerprint!==fingerprint) state.pending={fingerprint,key:key()};
        data.request_key=state.pending.key;
        state.saving=true;
        const controls=[...$('#inventoryModal').querySelectorAll('input,select,button')];
        controls.forEach(el=>el.disabled=true);
        const submit=form.querySelector('[type=submit]'), original=submit.textContent;
        submit.textContent='Saving…';
        try {
            const result=await api(action,data,true);
            state.saving=false; modal.hide();
            toastr.success(result.message);
            await load();
            if(state.tab!=='products') api('products').then(d=>overview(d.overview)).catch(()=>{});
            if(['sale','gift','collect','return'].includes(action)) setTimeout(()=>showDetail(result.id),250);
        } catch(error) { errorBox.textContent=error.message; errorBox.classList.remove('d-none'); }
        finally {state.saving=false; controls.forEach(el=>el.disabled=false); submit.textContent=original;}
    }
    function exportReport() {
        if(!state.report||!cfg.canReport) return;
        const d=state.report, s=d.summary;
        const rows=[['School store report',d.from,d.to],['Metric','Amount'],...Object.entries(s).map(([k,v])=>[k.replace(/_paise$/,'').replace(/_/g,' '),(Number(v)/100).toFixed(2)]),[],['Product','Net units sold','Net sales','Item cost incl. free/lost','Profit/loss'],...d.rows.map(r=>[r.product_name,r.sold_quantity,(r.sales_paise/100).toFixed(2),(r.cost_paise/100).toFixed(2),((r.sales_paise-r.cost_paise)/100).toFixed(2)])];
        const csv=rows.map(row=>row.map(v=>'"'+String(v??'').replace(/^[=+@\-]/,"'$&").replace(/"/g,'""')+'"').join(',')).join('\r\n');
        const url=URL.createObjectURL(new Blob(['\uFEFF'+csv],{type:'text/csv;charset=utf-8'}));
        const a=document.createElement('a');a.href=url;a.download=`inventory-report-${d.from}-to-${d.to}.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
    }
    document.addEventListener('click',event=>{
        const button=event.target.closest('[data-action],[data-tab],[data-page],[data-pick]');
        if(!button||button.disabled||state.saving) return;
        if(button.dataset.tab) return changeTab(button.dataset.tab);
        if(button.dataset.page) {state.page=Number(button.dataset.page);return load();}
        if(button.dataset.pick) {
            const row=state.searchRows[button.dataset.pick]?.[Number(button.dataset.index)];
            if (!row) return;
            if(button.dataset.pick==='products') addToCart(row);
            else {state.selectedStudent=row;$('#inv-student-search').value=row.name;$('#selectedStudentLabel').innerHTML=studentSummary(row);$('#studentResults').innerHTML='';}
            return;
        }
        const id=button.dataset.id;
        switch(button.dataset.action) {
            case 'product':productForm(id);break;
            case 'sale':case 'purchase':case 'damage':documentForm(button.dataset.action,id);break;
            case 'remove':state.cart.splice(Number(button.dataset.index),1);renderCart();break;
            case 'paylater':state.paidTouched=true;$('#inv-paid').value='0.00';totals();break;
            case 'detail':showDetail(id);break;
            case 'collect':paymentForm(false);break;
            case 'return':paymentForm(true);break;
            case 'movements':movements(id,Number(button.dataset.movePage||1));break;
            case 'low':changeTab('products');$('#stockLow').value='1';load();break;
            case 'refresh':load();break;
            case 'export':exportReport();break;
        }
    });
    let searchTimer;
    $('#inventoryModal').addEventListener('error',event=>{
        if(event.target.matches('.inventory-student-photo img')) event.target.remove();
    },true);
    $('#inventoryModal').addEventListener('input',event=>{
        const el=event.target;
        if(el.dataset.cart) {state.cart[Number(el.dataset.index)][el.dataset.cart]=el.value;totals();}
        if(el.id==='inv-paid') {state.paidTouched=true;totals();}
        if(['inv-student-search','inv-product-search'].includes(el.id)) {
            if(el.id==='inv-student-search') {state.selectedStudent=null;$('#selectedStudentLabel').textContent='';}
            state.searchSequence++; clearTimeout(searchTimer);
            searchTimer=setTimeout(()=>searchOptions(el.id==='inv-student-search'?'students':'products',el.value.trim()),250);
        }
    });
    $('#inventoryModal').addEventListener('change',event=>{if(event.target.id==='inv-kind'){state.kind=event.target.value;renderCart();}});
    $('#inventoryModal').addEventListener('submit',event=>{event.preventDefault();saveForm(event.target);});
    $('#inventoryModal').addEventListener('hide.bs.modal',event=>{if(state.saving)event.preventDefault();});
    $('#inventoryFilters').addEventListener('submit',event=>{event.preventDefault();state.page=1;load();});
    const initialTab = new URLSearchParams(window.location.search).get('view') === 'report' ? 'report' : 'products';
    changeTab(initialTab);
    if (initialTab === 'report') api('products').then(data => overview(data.overview)).catch(() => {});
})();
