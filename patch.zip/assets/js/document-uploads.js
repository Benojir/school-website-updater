/* Shared free-ratio document cropping, bounded image preparation and truthful upload progress. */
(function (window, document) {
    'use strict';
    const config = window.DocumentUploadConfig || {};
    const documentNames = new Set(['document_file[]', 'father_aadhaar_image', 'father_voter_image', 'father_pan_image',
        'mother_aadhaar_image', 'mother_voter_image', 'mother_pan_image', 'student_birth_certificate',
        'student_aadhaar_image', 'student_transfer_certificate']);
    const accepted = new WeakMap(), originals = new WeakMap(), previews = new WeakMap();
    const committing = new WeakSet(), preparing = new WeakSet();
    const maxDocumentBytes = Math.min(config.maxFileBytes || 2097152, 2097152);
    const modalEl = document.getElementById('documentCropModal');
    const imageEl = document.getElementById('documentCropImage');
    let modal, cropper, pending = null, parentModal = null, imageUrl = null;

    function isDocumentInput(input) {
        return input?.type === 'file' && (input.matches('.document-upload, .doc-file') || documentNames.has(input.name) ||
            !!input.closest('.image-field[data-crop="0"]'));
    }
    function report(error) { if (window.toastr) window.toastr.error(error.message || String(error)); }
    function assignFile(input, file) {
        const transfer = new DataTransfer();
        if (file) transfer.items.add(file);
        input.files = transfer.files;
    }
    function dispatchCommitted(input) {
        committing.add(input);
        try { input.dispatchEvent(new Event('change', {bubbles: true})); }
        finally { committing.delete(input); }
    }
    async function decodeFile(file) {
        if (!file || !file.type.startsWith('image/')) throw new Error('Select a document image (JPG, PNG or WebP).');
        const url = URL.createObjectURL(file), image = new Image();
        try {
            image.src = url; await image.decode();
            if (!image.naturalWidth || !image.naturalHeight) throw new Error('The selected document image could not be read.');
            return image;
        } finally { URL.revokeObjectURL(url); }
    }
    function canvasBlob(canvas, quality) {
        return new Promise((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('Could not prepare the document image.')), 'image/jpeg', quality));
    }
    async function encodeDocument(canvas, name, budget) {
        if (budget < 65536) throw new Error('This form has too much data. Remove some files or reduce the photo size and try again.');
        // Bound the long edge, without changing the document's aspect ratio.
        let scale = Math.min(1, 2500 / Math.max(canvas.width, canvas.height));
        for (let resize = 0; resize < 5; resize++) {
            const output = document.createElement('canvas');
            output.width = Math.max(1, Math.round(canvas.width * scale));
            output.height = Math.max(1, Math.round(canvas.height * scale));
            const ctx = output.getContext('2d');
            ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, output.width, output.height);
            ctx.drawImage(canvas, 0, 0, output.width, output.height);
            for (const quality of [0.9, 0.82, 0.74, 0.66]) {
                const blob = await canvasBlob(output, quality);
                if (blob.size <= budget) return new File([blob], (name || 'document').replace(/\.[^.]+$/, '') + '.jpg', {type: 'image/jpeg', lastModified: Date.now()});
            }
            scale *= 0.8;
        }
        throw new Error('The document is still too large. Crop more tightly or select a smaller image.');
    }
    async function prepareFile(file, budget) {
        // Already cropped/small JPEGs and PNGs keep their original pixels.
        if (['image/jpeg', 'image/png'].includes(file.type) && file.size <= budget) return file;
        const image = await decodeFile(file);
        const canvas = document.createElement('canvas');
        const scale = Math.min(1, 2500 / Math.max(image.naturalWidth, image.naturalHeight));
        canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
        canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
        canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height);
        return encodeDocument(canvas, file.name, budget);
    }
    function preview(input) {
        let tools = previews.get(input);
        if (tools) { URL.revokeObjectURL(tools.url); tools.el.remove(); }
        if (!input.files?.[0]) { previews.delete(input); return; }
        const el = document.createElement('div');
        el.className = 'document-image-tools d-flex align-items-center gap-2 mt-1';
        const img = document.createElement('img'), button = document.createElement('button');
        const url = URL.createObjectURL(input.files[0]);
        img.src = url; img.alt = 'Document preview'; img.style.cssText = 'max-width:90px;max-height:65px;object-fit:contain';
        button.type = 'button'; button.className = 'btn btn-outline-secondary btn-sm'; button.textContent = 'Crop again';
        button.addEventListener('click', () => openCrop(input, originals.get(input) || input.files[0]));
        el.append(img, button); input.insertAdjacentElement('afterend', el); previews.set(input, {el, url});
    }
    function dismissParent() {
        const parent = pending.input.closest('.modal.show');
        if (!parent) { modal.show(); return; }
        parentModal = bootstrap.Modal.getInstance(parent);
        if (!parentModal) { modal.show(); return; }
        parent.addEventListener('hidden.bs.modal', () => modal.show(), {once: true});
        parentModal.hide();
    }
    async function openCrop(sourceInput, file) {
        if (!file || pending) return;
        const field = sourceInput.closest('.image-field[data-crop="0"]');
        const input = field?.querySelector('.src-gallery') || sourceInput;
        const previous = accepted.get(input) || null;
        pending = {input, sourceInput, previous, file, saved: false};
        try {
            if (!modalEl || !window.Cropper || !window.bootstrap) throw new Error('Document cropping could not load. Refresh the page and try again.');
            await decodeFile(file);
            imageUrl = URL.createObjectURL(file); imageEl.src = imageUrl;
            document.getElementById('documentCropError').textContent = '';
            modal = bootstrap.Modal.getOrCreateInstance(modalEl);
            dismissParent();
        } catch (error) {
            assignFile(input, previous);
            if (sourceInput !== input) sourceInput.value = '';
            pending = null; report(error);
        }
    }
    if (modalEl) {
        modalEl.addEventListener('shown.bs.modal', () => {
            cropper?.destroy();
            cropper = new Cropper(imageEl, {aspectRatio: NaN, viewMode: 1, autoCropArea: 1, dragMode: 'crop',
                cropBoxMovable: true, cropBoxResizable: true, responsive: true, restore: false});
        });
        modalEl.addEventListener('hidden.bs.modal', () => {
            cropper?.destroy(); cropper = null;
            if (pending && !pending.saved) {
                assignFile(pending.input, pending.previous); dispatchCommitted(pending.input);
                if (pending.sourceInput !== pending.input) pending.sourceInput.value = '';
            }
            pending = null;
            if (imageUrl) URL.revokeObjectURL(imageUrl);
            imageUrl = null; imageEl.removeAttribute('src');
            parentModal?.show(); parentModal = null;
        });
        modalEl.querySelectorAll('[data-document-crop]').forEach(button => button.addEventListener('click', () => {
            if (!cropper) return;
            if (button.dataset.documentCrop === 'reset') cropper.reset();
            else cropper.rotate(button.dataset.documentCrop === 'rotate-left' ? -90 : 90);
        }));
        document.getElementById('documentCropConfirm').addEventListener('click', async event => {
            if (!cropper || !pending) return;
            const selection = pending, button = event.currentTarget;
            button.disabled = true;
            try {
                const canvas = cropper.getCroppedCanvas({maxWidth: 2500, maxHeight: 2500, fillColor: '#fff', imageSmoothingQuality: 'high'});
                if (!canvas) throw new Error('Select a crop area first.');
                const file = await encodeDocument(canvas, selection.file.name, Math.min(maxDocumentBytes, 614400));
                if (pending !== selection || !selection.input.isConnected) return;
                assignFile(selection.input, file);
                accepted.set(selection.input, file); originals.set(selection.input, selection.file); selection.saved = true;
                if (selection.sourceInput !== selection.input) selection.sourceInput.value = '';
                dispatchCommitted(selection.input); preview(selection.input); modal.hide();
            } catch (error) { document.getElementById('documentCropError').textContent = error.message; }
            finally { button.disabled = false; }
        });
    }
    document.addEventListener('click', event => {
        if (isDocumentInput(event.target) && !pending) accepted.set(event.target, event.target.files?.[0] || null);
        const clear = event.target.closest('.tile-clear');
        if (clear) clear.closest('.image-field')?.querySelectorAll('input[type="file"]').forEach(input => {
            accepted.delete(input); originals.delete(input);
            const tools = previews.get(input); if (tools) { URL.revokeObjectURL(tools.url); tools.el.remove(); previews.delete(input); }
        });
    }, true);
    document.addEventListener('change', event => {
        const input = event.target;
        if (!isDocumentInput(input) || committing.has(input)) return;
        if (!input.files?.[0]) { accepted.delete(input); originals.delete(input); preview(input); return; }
        event.stopImmediatePropagation();
        if (pending) { assignFile(input, accepted.get(input) || null); report(new Error('Finish cropping the current document first.')); return; }
        openCrop(input, input.files[0]);
    }, true);
    document.addEventListener('reset', event => {
        setTimeout(() => event.target.querySelectorAll('input[type="file"]').forEach(input => {
            accepted.delete(input); originals.delete(input); preview(input);
        }), 0);
    }, true);

    async function prepareFormData(data, onProgress = () => {}) {
        if (pending) throw new Error('Finish cropping the document before submitting.');
        // These forms send a preferred cropped/original portrait alongside an
        // unused copy in the file input. Retain the server's preferred version once.
        const preferredPortrait = data.get('cropped_image') || data.get('original_image');
        const hasCroppedPortrait = data.get('cropped_image') instanceof Blob && data.get('cropped_image').size > 0;
        const portraitBase64 = typeof data.get('cropped_image_data') === 'string' && data.get('cropped_image_data').startsWith('data:image/');
        const entries = [...data.entries()].filter(([name]) => {
            if (preferredPortrait instanceof Blob && preferredPortrait.size > 0 && ['teacher_photo', 'driver_photo'].includes(name)) return false;
            if (hasCroppedPortrait && name === 'original_image') return false;
            if (portraitBase64 && name === 'photo') return false;
            return true;
        });
        const docs = entries.filter(([name, value]) => documentNames.has(name) && value instanceof Blob && value.size > 0);
        const files = entries.filter(([, value]) => value instanceof Blob && value.size > 0);
        if (config.maxFiles > 0 && files.length > config.maxFiles) throw new Error('Too many files in one request. Save fewer documents at a time.');
        const overhead = entries.reduce((bytes, [name, value]) => bytes + 1024 + new TextEncoder().encode(name).length +
            (value instanceof Blob ? (documentNames.has(name) ? 0 : value.size) : new TextEncoder().encode(String(value)).length), 65536);
        const totalBudget = config.maxPostBytes > 0 ? Math.floor(config.maxPostBytes * 0.9) : Infinity;
        const perDocument = Math.floor(Math.min(maxDocumentBytes, 614400, (totalBudget - overhead) / Math.max(1, docs.length)));
        if (totalBudget <= overhead) throw new Error('The form is too large for the server. Reduce the photo size or remove files and try again.');
        const replacement = new Map();
        for (let i = 0; i < docs.length; i++) {
            const file = docs[i][1];
            // Sequential preparation keeps memory bounded when many scans are selected.
            replacement.set(file, await prepareFile(file, perDocument));
            onProgress(Math.round((i + 1) * 100 / docs.length), 'Preparing documents ' + (i + 1) + ' / ' + docs.length);
        }
        const prepared = new FormData(); let bodySize = 65536;
        entries.forEach(([name, value]) => {
            const next = replacement.get(value) || value;
            prepared.append(name, next);
            bodySize += 1024 + (next instanceof Blob ? next.size : new TextEncoder().encode(String(next)).length);
        });
        if (config.maxPostBytes > 0 && bodySize > totalBudget) throw new Error('The form is too large for the server. Save fewer documents at a time.');
        return prepared;
    }
    function progressView(target) {
        let root = typeof target === 'string' ? document.querySelector(target) : target;
        if (root?.jquery) root = root[0];
        root ||= document.body;
        const parent = root.matches('tr') ? root.lastElementChild : (root.querySelector('.modal-body') || root);
        let view = parent.querySelector('.document-upload-progress');
        if (!view) {
            view = document.createElement('div'); view.className = 'document-upload-progress mt-3 mb-2 w-100';
            view.innerHTML = '<div class="small fw-semibold mb-1" role="status" aria-live="polite"></div><div class="progress" style="height:20px;min-width:120px"><div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuemin="0" aria-valuemax="100"></div></div>';
            parent.appendChild(view);
        }
        return {root, view, update(percent, label, state = 'busy') {
            view.hidden = false;
            const bar = view.querySelector('.progress-bar');
            bar.style.width = percent + '%'; bar.textContent = percent + '%'; bar.setAttribute('aria-valuenow', percent);
            bar.classList.toggle('bg-danger', state === 'error'); bar.classList.toggle('bg-success', state === 'success');
            bar.classList.toggle('progress-bar-animated', state === 'busy');
            view.querySelector('[role="status"]').textContent = label + ' — ' + percent + '%';
            // These two older forms had an estimated 0–70% bar; use this real upload bar instead.
            const legacy = root.querySelector('#uploadProgressWrapper'); if (legacy) legacy.style.display = 'none';
        }};
    }
    function ajax(settings) {
        const $ = window.jQuery, deferred = $.Deferred(), view = progressView(settings.documentUploadTarget);
        if (preparing.has(view.root)) { deferred.reject(null, 'busy', 'A request is already running.'); return deferred.promise(); }
        preparing.add(view.root);
        const buttons = [...view.root.querySelectorAll('button[type="submit"], .update-btn, #documentsModalSaveBtn')]
            .filter(button => !button.disabled).map(button => [button, false]);
        buttons.forEach(([button]) => button.disabled = true);
        const context = settings.context || settings;
        function finish(xhr, status) {
            preparing.delete(view.root); buttons.forEach(([button, disabled]) => button.disabled = disabled);
            settings.complete?.call(context, xhr, status);
        }
        view.update(0, 'Preparing form');
        prepareFormData(settings.data, (percent, label) => view.update(percent, label)).then(data => {
            const request = {...settings, data,
                xhr() {
                    const xhr = settings.xhr ? settings.xhr() : $.ajaxSettings.xhr();
                    if (xhr.upload) {
                        xhr.upload.addEventListener('progress', event => {
                            if (event.lengthComputable) {
                                const percent = Math.round(event.loaded * 100 / event.total);
                                view.update(percent, percent === 100 ? 'Upload complete; server is processing documents' : 'Uploading form and files');
                            }
                        });
                        xhr.upload.addEventListener('load', () => view.update(100, 'Upload complete; server is processing documents'));
                    }
                    return xhr;
                },
                beforeSend(xhr, options) {
                    const result = settings.beforeSend?.call(context, xhr, options);
                    view.update(0, 'Uploading form and files'); return result;
                },
                success(response, status, xhr) {
                    let decoded = response;
                    if (typeof response === 'string') { try { decoded = JSON.parse(response); } catch (_) { decoded = {success: false}; } }
                    const success = decoded?.success === true;
                    view.update(100, success ? 'Saved successfully' : 'Upload sent; saving failed', success ? 'success' : 'error');
                    settings.success?.call(context, response, status, xhr);
                    view.update(100, success ? 'Saved successfully' : (decoded?.message || 'Upload sent; saving failed'), success ? 'success' : 'error');
                    if (success) view.root.querySelectorAll('input[type="file"]').forEach(input => { if (!input.files?.length) preview(input); });
                    deferred.resolve(response, status, xhr);
                },
                error(xhr, status, error) {
                    view.update(0, 'Request failed; selected documents are retained', 'error');
                    settings.error?.call(context, xhr, status, error); deferred.reject(xhr, status, error);
                },
                complete: finish
            };
            delete request.documentUploadTarget;
            $.ajax(request);
        }).catch(error => {
            const xhr = {status: 0, responseText: JSON.stringify({success: false, message: error.message})};
            view.update(0, error.message, 'error'); report(error);
            settings.error?.call(context, xhr, 'error', error.message); deferred.reject(xhr, 'error', error.message); finish(xhr, 'error');
        });
        return deferred.promise();
    }
    window.DocumentUploads = {ajax, prepareFormData, isDocumentInput};
})(window, document);
