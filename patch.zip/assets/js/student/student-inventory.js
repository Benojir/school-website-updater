(() => {
    'use strict';
    const cfg = window.studentInventoryConfig;
    if (!cfg) return;
    const $ = id => document.getElementById(id);
    const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
    const money = value => esc(cfg.currency) + (Number(value) / 100).toLocaleString('en-IN', {minimumFractionDigits:2, maximumFractionDigits:2});
    const label = d => d.kind === 'gift' ? 'Received free' : d.kind === 'return' ? 'Returned to school' : d.status === 'returned' ? 'Purchase — returned' : 'Purchased from school';
    let page = 1, sequence = 0, detailSequence = 0;
    async function request(params) {
        const response = await fetch(cfg.api + '?' + new URLSearchParams({student_id:cfg.studentId, ...params}), {credentials:'same-origin', cache:'no-store'});
        let payload;
        try { payload = await response.json(); } catch { throw new Error('Unable to load inventory. Please refresh and try again.'); }
        if (!response.ok || !payload.success) throw new Error(payload.message || 'Unable to load inventory.');
        return payload.data;
    }
    function clearSummary() { document.querySelectorAll('[data-inventory-summary]').forEach(el => { el.textContent = '-'; }); }
    async function load(nextPage = 1) {
        const ticket = ++sequence;
        $('studentInventoryMessage').textContent = '';
        $('studentInventoryRows').innerHTML = '<tr><td colspan="6" class="text-center py-4">Loading inventory account…</td></tr>';
        $('studentInventoryPagination').replaceChildren();
        clearSummary();
        try {
            const data = await request({action:'history', page:nextPage, due:$('studentInventoryDue').checked ? 1 : 0});
            if (ticket !== sequence) return;
            page = data.page;
            cfg.currency = data.currency;
            document.querySelectorAll('[data-inventory-summary]').forEach(el => { el.innerHTML = money(data.summary[el.dataset.inventorySummary]); });
            $('studentInventoryMessage').textContent = 'Account totals are for all time. The filter below only changes the bill list.';
            $('studentInventoryRows').innerHTML = data.rows.length ? data.rows.map(d => `<tr>
                <td><strong>INV-${d.id}</strong><div class="small text-muted text-nowrap">${esc(d.created_at)}</div><button type="button" class="btn btn-sm btn-outline-primary d-md-none d-print-none mt-2" data-inventory-bill="${d.id}">View bill</button></td>
                <td>${esc(label(d))}</td><td>${money(d.total_paise)}</td>
                <td>${d.refund_paise > 0 ? 'Refunded ' + money(d.refund_paise) : money(d.net_paid_paise)}${d.waived_paise > 0 ? `<div class="small">Waived ${money(d.waived_paise)}</div>` : ''}</td>
                <td class="${d.due_paise > 0 ? 'text-danger fw-bold' : ''}">${money(d.due_paise)}</td>
                <td class="d-none d-md-table-cell d-print-none"><button type="button" class="btn btn-sm btn-outline-primary" data-inventory-bill="${d.id}">View items &amp; payments</button></td>
            </tr>`).join('') : `<tr><td colspan="6" class="text-center text-muted py-4">${$('studentInventoryDue').checked ? 'No inventory balance due.' : 'No school store entries yet.'}</td></tr>`;
            $('studentInventoryPagination').innerHTML = `<button type="button" class="btn btn-sm btn-outline-secondary" data-inventory-page="${page - 1}" ${page <= 1 ? 'disabled' : ''}>Previous</button><span class="small text-muted">Page ${page} of ${data.pages} · ${data.total} entries</span><button type="button" class="btn btn-sm btn-outline-secondary" data-inventory-page="${page + 1}" ${page >= data.pages ? 'disabled' : ''}>Next</button>`;
        } catch (error) {
            if (ticket !== sequence) return;
            $('studentInventoryMessage').textContent = error.message;
            $('studentInventoryRows').innerHTML = '<tr><td colspan="6" class="text-center text-muted py-4">Account unavailable. Use Refresh to try again.</td></tr>';
        }
    }
    async function detail(id) {
        const ticket = ++detailSequence;
        $('studentInventoryDetailTitle').textContent = `INV-${id} · Items & payments`;
        $('studentInventoryDetailBody').textContent = 'Loading bill…';
        bootstrap.Modal.getOrCreateInstance($('studentInventoryDetail')).show();
        try {
            const d = await request({action:'detail', id});
            if (ticket !== detailSequence) return;
            cfg.currency = d.currency;
            $('studentInventoryDetailBody').innerHTML = `<p><strong>${esc(label(d))}</strong><br><span class="small text-muted">${esc(d.created_at)}</span></p>
                ${d.original_document_id ? `<p>Original bill: INV-${d.original_document_id}</p>` : ''}
                ${d.status === 'returned' ? '<div class="alert alert-info">All items were returned. Any payment was refunded and the balance due was cleared.</div>' : ''}
                <div class="table-responsive"><table class="table"><thead><tr><th>Product</th><th>Quantity</th><th>Price / item</th><th>Amount</th></tr></thead><tbody>${d.items.map(i => `<tr><td>${esc(i.product_name)}</td><td>${i.quantity} ${esc(i.unit)}</td><td>${money(i.unit_price_paise)}</td><td>${money(i.line_total_paise)}</td></tr>`).join('')}</tbody></table></div>
                <div class="bg-light rounded p-3 mb-3"><div>${d.kind === 'return' ? 'Returned items value' : 'Bill amount'}: <strong>${money(d.kind === 'return' ? Math.abs(d.total_paise) : d.total_paise)}</strong></div>${d.kind !== 'return' ? `<div>Paid after refunds: <strong>${money(d.net_paid_paise)}</strong></div>` : ''}${d.refund_paise || d.kind === 'return' ? `<div>Refund recorded: <strong>${money(d.refund_paise)}</strong></div>` : ''}<div>${d.kind==='return'?'Waiver reversed':'Balance waived'}: <strong>${money(Math.abs(d.waived_paise||0))}</strong></div><div>Balance due: <strong>${money(d.due_paise)}</strong></div></div>
                <h6>Payments &amp; refunds</h6>${d.payments.length ? `<div class="table-responsive"><table class="table table-sm"><thead><tr><th>Date</th><th>Type</th><th>Amount</th><th>Method / reference</th></tr></thead><tbody>${d.payments.map(p => `<tr><td>${esc(p.created_at)}</td><td>${p.amount_paise < 0 ? 'Refund' : 'Payment'}</td><td>${money(Math.abs(p.amount_paise))}</td><td>${esc(p.method)}<br><small>${esc(p.reference)}</small></td></tr>`).join('')}</tbody></table></div>` : '<p class="small text-muted">No payments recorded for this entry.</p>'}`;
        } catch (error) { if (ticket === detailSequence) $('studentInventoryDetailBody').textContent = error.message; }
    }
    $('studentInventoryDetail').addEventListener('hidden.bs.modal', () => { detailSequence++; });
    if (!cfg.allowed) {
        $('studentInventoryMessage').textContent = 'Manage Inventory permission is required to view this account.';
        $('studentInventoryRows').innerHTML = '<tr><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td></tr>';
        return;
    }
    $('studentInventoryRefresh').addEventListener('click', () => load(page));
    $('studentInventoryDue').addEventListener('change', () => load(1));
    $('studentInventoryPanel').addEventListener('click', event => {
        const button = event.target.closest('[data-inventory-page], [data-inventory-bill]');
        if (!button || button.disabled) return;
        if (button.dataset.inventoryBill) detail(Number(button.dataset.inventoryBill));
        else load(Number(button.dataset.inventoryPage));
    });
    load();
})();
