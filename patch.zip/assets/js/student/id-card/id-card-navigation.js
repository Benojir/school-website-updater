/* Editor view only: navigation never changes card coordinates, objects or saved JSON. */
(() => {
    'use strict';
    const MIN_ZOOM = 0.1, MAX_ZOOM = 4, ZOOM_STEP = 1.25;
    // Rasterize the visible workspace, not the whole magnified document.
    const MAX_BACKING_SIDE = 4096;
    const FIT_MARGIN = 40;

    function attach({canvas, area, getSize, canNavigate}) {
        let tool = 'select', effectiveTool = 'select', zoom = 1, panX = 0, panY = 0;
        let fitted = true, drag = null, space = false, ctrl = false, alt = false;
        let zoomContextPending = false;
        let drawingLine = false;
        const tools = {select: 'btnViewSelect', hand: 'btnViewHand', zoom: 'btnViewZoom', line: 'btnViewLine'};
        const wrapper = canvas.wrapperEl;
        const paper = document.createElement('div');
        paper.className = 'id-card-document';
        paper.setAttribute('aria-hidden', 'true');
        area.insertBefore(paper, wrapper);
        let rasterScaleX = 1, rasterScaleY = 1;

        // Fabric's interaction surface fills the workspace so native selection
        // borders, rotation and resize handles remain usable beyond the paper.
        // Clip artwork only; keep this editor decoration out of design JSON.
        canvas.controlsAboveOverlay = true;
        for (const [method, objectSpace] of [['_renderBackground', false], ['_renderObjects', true], ['_renderOverlay', false]]) {
            const render = canvas[method];
            canvas[method] = function (context, ...args) {
                const size = getSize(), view = this.viewportTransform;
                context.save();
                context.beginPath();
                if (objectSpace) context.rect(0, 0, size.width, size.height);
                else context.rect(view[4], view[5], size.width * view[0], size.height * view[3]);
                context.clip();
                try { return render.call(this, context, ...args); }
                finally { context.restore(); }
            };
        }

        // Fabric 5 applies the inverse viewport before CSS scaling. With a
        // capped bitmap and a translated viewport those operations must run in
        // the opposite order, including when Fabric caches a pointer mid-drag.
        const getPointer = canvas.getPointer;
        canvas.getPointer = function (event, ignoreZoom) {
            const point = getPointer.call(this, event, true);
            return ignoreZoom ? point : this.restorePointerVpt(point);
        };
        const editable = element => !!element?.closest?.('input,textarea,select,[contenteditable]:not([contenteditable="false"])');
        const typing = event => editable(event?.target) || editable(document.activeElement) || !!canvas.getActiveObject()?.isEditing;
        const allowed = () => !canNavigate || canNavigate();
        const fitScale = () => {
            const size = getSize();
            return Math.max(0.001, Math.min(1, Math.max(1, area.clientWidth - FIT_MARGIN * 2) / size.width,
                Math.max(1, area.clientHeight - FIT_MARGIN * 2) / size.height));
        };
        const clamp = value => Math.max(Math.min(MIN_ZOOM, fitScale()), Math.min(MAX_ZOOM, value));
        const consume = event => { event.preventDefault(); event.stopImmediatePropagation(); };
        const localPoint = event => {
            const bounds = area.getBoundingClientRect();
            return {x: event.clientX - bounds.left, y: event.clientY - bounds.top};
        };

        function updateCursor() {
            const cursor = effectiveTool === 'hand' ? (drag ? 'grabbing' : 'grab')
                : effectiveTool === 'zoom' ? 'zoom-in' : effectiveTool === 'line' ? 'crosshair' : 'default';
            area.style.cursor = cursor;
            canvas.defaultCursor = cursor;
            canvas.hoverCursor = effectiveTool === 'select' ? 'move' : cursor;
            canvas.upperCanvasEl.style.cursor = cursor;
        }
        function syncTools() {
            effectiveTool = space && !alt ? (ctrl ? 'zoom' : 'hand') : tool;
            if (drag && effectiveTool !== 'hand') drag = null;
            if (drawingLine && effectiveTool !== 'line') cancelLine();
            area.dataset.viewTool = effectiveTool;
            Object.entries(tools).forEach(([name, id]) => {
                const button = document.getElementById(id);
                if (!button) return;
                button.classList.toggle('active', effectiveTool === name);
                button.setAttribute('aria-pressed', String(effectiveTool === name));
            });
            const status = document.getElementById('viewToolStatus');
            if (status) status.textContent = effectiveTool === 'hand' ? 'Hand: drag to move the document'
                : effectiveTool === 'zoom' ? 'Zoom: left click in, right click out'
                : effectiveTool === 'line' ? 'Line: drag on the card to draw. Hold Shift for 45° steps. Esc cancels.' : 'Select: edit card elements';
            updateCursor();
            canvas.fire('view:tool-changed', {tool: effectiveTool});
        }
        function positionPaper() {
            const size = getSize();
            const left = (area.clientWidth - size.width * zoom) / 2 + panX;
            const top = (area.clientHeight - size.height * zoom) / 2 + panY;
            Object.assign(paper.style, {left: left + 'px', top: top + 'px',
                width: size.width * zoom + 'px', height: size.height * zoom + 'px'});
            canvas.setViewportTransform([zoom * rasterScaleX, 0, 0, zoom * rasterScaleY,
                left * rasterScaleX, top * rasterScaleY]);
            canvas.calcOffset();
            canvas.renderAll();
        }
        function renderView() {
            const width = Math.max(1, area.clientWidth), height = Math.max(1, area.clientHeight);
            const retina = Math.max(1, canvas.getRetinaScaling());
            const rasterScale = Math.min(1, MAX_BACKING_SIDE / (Math.max(width, height) * retina));
            canvas.setDimensions({width: width * rasterScale, height: height * rasterScale});
            canvas.setDimensions({width: width + 'px', height: height + 'px'}, {cssOnly: true});
            // Canvas bitmap dimensions are integers, even with a fractional DPR
            // or capped size. Use the actual pixel ratios to keep paper, artwork
            // and pointer coordinates aligned on both axes.
            rasterScaleX = canvas.lowerCanvasEl.width / (width * retina);
            rasterScaleY = canvas.lowerCanvasEl.height / (height * retina);
            positionPaper();
            const label = document.getElementById('viewZoomLabel');
            if (label) label.textContent = (zoom * 100 < 10 ? (zoom * 100).toFixed(1) : Math.round(zoom * 100)) + '%';
            const out = document.getElementById('btnViewZoomOut'), into = document.getElementById('btnViewZoomIn');
            if (out) out.disabled = zoom <= Math.min(MIN_ZOOM, fitScale()) + 0.000001;
            if (into) into.disabled = zoom >= MAX_ZOOM - 0.000001;
            updateCursor();
        }
        function endDrag() {
            drag = null;
            updateCursor();
        }
        function cancelLine() {
            if (!drawingLine) return;
            drawingLine = false;
            canvas.fire('line:draw:cancel');
        }
        function fit() {
            endDrag();
            zoom = fitScale(); panX = 0; panY = 0; fitted = true;
            renderView();
        }
        function setZoom(value, point) {
            if (!allowed() || !Number.isFinite(value)) return;
            const next = clamp(value);
            if (Math.abs(next - zoom) < 0.000001) return;
            point ??= {x: area.clientWidth / 2, y: area.clientHeight / 2};
            const ratio = next / zoom;
            panX = (point.x - area.clientWidth / 2) * (1 - ratio) + panX * ratio;
            panY = (point.y - area.clientHeight / 2) * (1 - ratio) + panY * ratio;
            zoom = next; fitted = false;
            renderView();
        }
        function setTool(next) {
            if (!Object.hasOwn(tools, next) || !allowed()) return;
            endDrag();
            const active = canvas.getActiveObject();
            if (active?.isEditing && typeof active.exitEditing === 'function') active.exitEditing();
            tool = next;
            syncTools();
        }
        function clearHeldKeys() {
            space = ctrl = alt = false;
            cancelLine();
            endDrag(); syncTools();
        }

        wrapper.style.position = 'absolute';
        wrapper.style.left = '0'; wrapper.style.top = '0';
        Object.entries(tools).forEach(([name, id]) => {
            document.getElementById(id)?.addEventListener('click', () => setTool(name));
        });
        document.getElementById('btnViewZoomIn')?.addEventListener('click', () => setZoom(zoom * ZOOM_STEP));
        document.getElementById('btnViewZoomOut')?.addEventListener('click', () => setZoom(zoom / ZOOM_STEP));
        document.getElementById('btnViewFit')?.addEventListener('click', () => { if (allowed()) fit(); });
        document.getElementById('btnViewActualSize')?.addEventListener('click', () => setZoom(1));

        area.addEventListener('wheel', event => {
            if (!allowed() || drag || drawingLine || event.buttons || event.ctrlKey || event.metaKey
                || zoom <= fitScale() + 0.000001) return;

            const unit = event.deltaMode === WheelEvent.DOM_DELTA_LINE ? 16
                : event.deltaMode === WheelEvent.DOM_DELTA_PAGE ? area.clientHeight : 1;
            const deltaY = event.deltaY * unit;
            if (!deltaY) return;
            consume(event);

            const limit = Math.max(0, (getSize().height * zoom - area.clientHeight) / 2) + FIT_MARGIN;
            // A previous hand drag may already be past the wheel limits.
            // Let the wheel bring the paper back without snapping it to an edge.
            const minY = Math.min(-limit, panY);
            const maxY = Math.max(limit, panY);
            const nextY = Math.max(minY, Math.min(maxY, panY - deltaY));
            if (nextY === panY) return;
            panY = nextY;
            fitted = false;
            positionPaper();
        }, {capture: true, passive: false});

        // Capture before Fabric receives a mousedown, so a view gesture cannot select,
        // drag, resize or open the text/table editor beneath the pointer.
        area.addEventListener('mousedown', event => {
            if (!allowed() || effectiveTool === 'select') { zoomContextPending = false; return; }
            if (effectiveTool === 'zoom' && (event.button === 0 || event.button === 2)) {
                consume(event);
                zoomContextPending = event.button === 2;
                setZoom(zoom * (event.button === 2 ? 1 / ZOOM_STEP : ZOOM_STEP), localPoint(event));
            } else if (effectiveTool === 'hand' && event.button === 0) {
                consume(event);
                drag = {x: event.clientX, y: event.clientY};
                updateCursor();
            } else if (effectiveTool === 'line' && event.button === 0) {
                consume(event);
                drawingLine = true;
                canvas.fire('line:draw:start', {e: event});
            }
        }, true);
        area.addEventListener('mousemove', event => {
            if (allowed() && effectiveTool !== 'select') { consume(event); updateCursor(); }
        }, true);
        area.addEventListener('dblclick', event => {
            if (allowed() && effectiveTool !== 'select') consume(event);
        }, true);
        area.addEventListener('contextmenu', event => {
            if (allowed() && (effectiveTool === 'zoom' || zoomContextPending)) consume(event);
            zoomContextPending = false;
        }, true);
        window.addEventListener('mousemove', event => {
            if (drawingLine) {
                if (!allowed() || effectiveTool !== 'line' || !(event.buttons & 1)) { cancelLine(); return; }
                consume(event); canvas.fire('line:draw:move', {e: event}); return;
            }
            if (!drag) return;
            if (!allowed() || effectiveTool !== 'hand' || !(event.buttons & 1)) { endDrag(); return; }
            consume(event);
            panX += event.clientX - drag.x; panY += event.clientY - drag.y;
            drag = {x: event.clientX, y: event.clientY}; fitted = false;
            positionPaper();
        }, true);
        window.addEventListener('mouseup', event => {
            if (drawingLine) {
                consume(event); drawingLine = false;
                if (allowed() && effectiveTool === 'line') canvas.fire('line:draw:end', {e: event});
                else canvas.fire('line:draw:cancel');
            }
            if (drag) { consume(event); endDrag(); }
        }, true);
        document.addEventListener('keydown', event => {
            if (typing(event) || !allowed()) { clearHeldKeys(); return; }
            if (event.key === 'Escape') {
                if (effectiveTool !== 'select') consume(event);
                clearHeldKeys(); tool = 'select'; syncTools(); return;
            }
            if (event.code === 'Space' || event.key === ' ') space = true;
            ctrl = event.ctrlKey; alt = event.altKey;
            syncTools();
            if (space && !alt) consume(event);
        }, true);
        document.addEventListener('keyup', event => {
            const wasTemporary = space && !alt;
            if (event.code === 'Space' || event.key === ' ') space = false;
            ctrl = event.ctrlKey; alt = event.altKey;
            if (wasTemporary) event.preventDefault();
            syncTools();
        }, true);
        document.addEventListener('focusin', event => { if (editable(event.target)) clearHeldKeys(); });
        window.addEventListener('blur', clearHeldKeys);
        document.addEventListener('visibilitychange', () => { if (document.hidden) clearHeldKeys(); });
        window.addEventListener('resize', () => {
            if (fitted) fit(); else { endDrag(); renderView(); }
        });
        syncTools();
        return {fit, setZoom, setTool, reset: clearHeldKeys,
            getState: () => ({tool, effectiveTool, zoom, panX, panY, panning: !!drag})};
    }
    window.IdCardNavigation = {attach};
})();
