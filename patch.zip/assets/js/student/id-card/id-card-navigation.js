/* Editor view only: navigation never changes card coordinates, objects or saved JSON. */
(() => {
    'use strict';
    const MIN_ZOOM = 0.1, MAX_ZOOM = 4, ZOOM_STEP = 1.25;
    // Bound actual bitmap allocation even for a 300 mm card at 400% on a Retina screen.
    const MAX_BACKING_SIDE = 4096;

    function attach({canvas, area, getSize, canNavigate}) {
        let tool = 'select', effectiveTool = 'select', zoom = 1, panX = 0, panY = 0;
        let fitted = true, drag = null, space = false, ctrl = false, alt = false;
        let zoomContextPending = false;
        const tools = {select: 'btnViewSelect', hand: 'btnViewHand', zoom: 'btnViewZoom'};
        const wrapper = canvas.wrapperEl;
        const editable = element => !!element?.closest?.('input,textarea,select,[contenteditable]:not([contenteditable="false"])');
        const typing = event => editable(event?.target) || editable(document.activeElement) || !!canvas.getActiveObject()?.isEditing;
        const allowed = () => !canNavigate || canNavigate();
        const fitScale = () => {
            const size = getSize();
            return Math.max(0.001, Math.min(1, Math.max(1, area.clientWidth - 20) / size.width,
                Math.max(1, area.clientHeight - 20) / size.height));
        };
        const clamp = value => Math.max(Math.min(MIN_ZOOM, fitScale()), Math.min(MAX_ZOOM, value));
        const consume = event => { event.preventDefault(); event.stopImmediatePropagation(); };
        const localPoint = event => {
            const bounds = area.getBoundingClientRect();
            return {x: event.clientX - bounds.left, y: event.clientY - bounds.top};
        };

        function updateCursor() {
            const cursor = effectiveTool === 'hand' ? (drag ? 'grabbing' : 'grab')
                : effectiveTool === 'zoom' ? 'zoom-in' : 'default';
            area.style.cursor = cursor;
            canvas.defaultCursor = cursor;
            canvas.hoverCursor = effectiveTool === 'select' ? 'move' : cursor;
            canvas.upperCanvasEl.style.cursor = cursor;
        }
        function syncTools() {
            effectiveTool = space && !alt ? (ctrl ? 'zoom' : 'hand') : tool;
            if (drag && effectiveTool !== 'hand') drag = null;
            area.dataset.viewTool = effectiveTool;
            Object.entries(tools).forEach(([name, id]) => {
                const button = document.getElementById(id);
                if (!button) return;
                button.classList.toggle('active', effectiveTool === name);
                button.setAttribute('aria-pressed', String(effectiveTool === name));
            });
            const status = document.getElementById('viewToolStatus');
            if (status) status.textContent = effectiveTool === 'hand' ? 'Hand: drag to move the document'
                : effectiveTool === 'zoom' ? 'Zoom: left click in, right click out' : 'Select: edit card elements';
            updateCursor();
        }
        function positionPaper() {
            wrapper.style.transform = `translate(calc(-50% + ${panX}px), calc(-50% + ${panY}px))`;
            canvas.calcOffset();
        }
        function renderView() {
            const size = getSize();
            const retina = Math.max(1, canvas.getRetinaScaling());
            const rasterZoom = Math.min(zoom, MAX_BACKING_SIDE / (Math.max(size.width, size.height) * retina));
            canvas.setZoom(rasterZoom);
            canvas.setDimensions({width: size.width * rasterZoom, height: size.height * rasterZoom});
            canvas.setDimensions({width: size.width * zoom + 'px', height: size.height * zoom + 'px'}, {cssOnly: true});
            positionPaper();
            canvas.renderAll();
            const label = document.getElementById('viewZoomLabel');
            if (label) label.textContent = (zoom * 100 < 10 ? (zoom * 100).toFixed(1) : Math.round(zoom * 100)) + '%';
            const out = document.getElementById('btnViewZoomOut'), into = document.getElementById('btnViewZoomIn');
            if (out) out.disabled = zoom <= Math.min(MIN_ZOOM, fitScale()) + 0.000001;
            if (into) into.disabled = zoom >= MAX_ZOOM - 0.000001;
            updateCursor();
        }
        function endDrag() {
            drag = null;
            updateCursor();
        }
        function fit() {
            endDrag();
            zoom = fitScale(); panX = 0; panY = 0; fitted = true;
            renderView();
        }
        function setZoom(value, point) {
            if (!allowed() || !Number.isFinite(value)) return;
            const next = clamp(value);
            if (Math.abs(next - zoom) < 0.000001) return;
            point ??= {x: area.clientWidth / 2, y: area.clientHeight / 2};
            const ratio = next / zoom;
            panX = (point.x - area.clientWidth / 2) * (1 - ratio) + panX * ratio;
            panY = (point.y - area.clientHeight / 2) * (1 - ratio) + panY * ratio;
            zoom = next; fitted = false;
            renderView();
        }
        function setTool(next) {
            if (!Object.hasOwn(tools, next) || !allowed()) return;
            endDrag();
            const active = canvas.getActiveObject();
            if (active?.isEditing && typeof active.exitEditing === 'function') active.exitEditing();
            tool = next;
            syncTools();
        }
        function clearHeldKeys() {
            space = ctrl = alt = false;
            endDrag(); syncTools();
        }

        wrapper.style.position = 'absolute';
        wrapper.style.left = '50%'; wrapper.style.top = '50%';
        wrapper.style.transformOrigin = 'center';
        Object.entries(tools).forEach(([name, id]) => {
            document.getElementById(id)?.addEventListener('click', () => setTool(name));
        });
        document.getElementById('btnViewZoomIn')?.addEventListener('click', () => setZoom(zoom * ZOOM_STEP));
        document.getElementById('btnViewZoomOut')?.addEventListener('click', () => setZoom(zoom / ZOOM_STEP));
        document.getElementById('btnViewFit')?.addEventListener('click', () => { if (allowed()) fit(); });
        document.getElementById('btnViewActualSize')?.addEventListener('click', () => setZoom(1));

        // Capture before Fabric receives a mousedown, so a view gesture cannot select,
        // drag, resize or open the text/table editor beneath the pointer.
        area.addEventListener('mousedown', event => {
            if (!allowed() || effectiveTool === 'select') { zoomContextPending = false; return; }
            if (effectiveTool === 'zoom' && (event.button === 0 || event.button === 2)) {
                consume(event);
                zoomContextPending = event.button === 2;
                setZoom(zoom * (event.button === 2 ? 1 / ZOOM_STEP : ZOOM_STEP), localPoint(event));
            } else if (effectiveTool === 'hand' && event.button === 0) {
                consume(event);
                drag = {x: event.clientX, y: event.clientY};
                updateCursor();
            }
        }, true);
        area.addEventListener('mousemove', event => {
            if (allowed() && effectiveTool !== 'select') { consume(event); updateCursor(); }
        }, true);
        area.addEventListener('dblclick', event => {
            if (allowed() && effectiveTool !== 'select') consume(event);
        }, true);
        area.addEventListener('contextmenu', event => {
            if (allowed() && (effectiveTool === 'zoom' || zoomContextPending)) consume(event);
            zoomContextPending = false;
        }, true);
        window.addEventListener('mousemove', event => {
            if (!drag) return;
            if (!allowed() || effectiveTool !== 'hand' || !(event.buttons & 1)) { endDrag(); return; }
            consume(event);
            panX += event.clientX - drag.x; panY += event.clientY - drag.y;
            drag = {x: event.clientX, y: event.clientY}; fitted = false;
            positionPaper();
        }, true);
        window.addEventListener('mouseup', event => {
            if (drag) { consume(event); endDrag(); }
        }, true);
        document.addEventListener('keydown', event => {
            if (typing(event) || !allowed()) { clearHeldKeys(); return; }
            if (event.key === 'Escape') {
                if (effectiveTool !== 'select') consume(event);
                clearHeldKeys(); tool = 'select'; syncTools(); return;
            }
            if (event.code === 'Space' || event.key === ' ') space = true;
            ctrl = event.ctrlKey; alt = event.altKey;
            syncTools();
            if (space && !alt) consume(event);
        }, true);
        document.addEventListener('keyup', event => {
            const wasTemporary = space && !alt;
            if (event.code === 'Space' || event.key === ' ') space = false;
            ctrl = event.ctrlKey; alt = event.altKey;
            if (wasTemporary) event.preventDefault();
            syncTools();
        }, true);
        document.addEventListener('focusin', event => { if (editable(event.target)) clearHeldKeys(); });
        window.addEventListener('blur', clearHeldKeys);
        document.addEventListener('visibilitychange', () => { if (document.hidden) clearHeldKeys(); });
        window.addEventListener('resize', () => {
            if (fitted) fit(); else { endDrag(); renderView(); }
        });
        syncTools();
        return {fit, setZoom, setTool, reset: clearHeldKeys,
            getState: () => ({tool, effectiveTool, zoom, panX, panY, panning: !!drag})};
    }
    window.IdCardNavigation = {attach};
})();
