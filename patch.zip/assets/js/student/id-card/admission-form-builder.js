/* Admission tools. The editor, named templates, tables, shapes and print renderer are shared. */
(() => {
    function ready() { return canvasReady && !templateBusy && !isSwappingSide && !isRestoringHistory; }
    function image(type, label, width, height) {
        const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="'+width+'" height="'+height+'"><rect width="100%" height="100%" fill="#eef3fa"/><text x="50%" y="50%" text-anchor="middle" dominant-baseline="middle" font-family="Arial" font-size="24" fill="#28446b">'+label+'</text></svg>';
        return new Promise(resolve => fabric.Image.fromURL('data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg), object => {
            object.set({data:{type,borderRadius:0}}); resolve(object);
        }));
    }
    [
        ['btnAddPrincipalSign','principal-signature','Principal Sign',240,80],
        ['btnAddHeadmasterSign','headmaster-signature','Head Master Sign',240,120],
        ['btnAddSchoolStamp','school-stamp','School Stamp',180,180],
        ['btnAddFatherPhoto','father-photo','Father Photo',240,280],
        ['btnAddMotherPhoto','mother-photo','Mother Photo',240,280]
    ].forEach(([id,type,label,width,height]) => document.getElementById(id).addEventListener('click',async()=>{
        if(!ready())return;
        const object=await image(type,label,width,height);
        if(!ready())return;
        addObjectCentered(object);pushHistory();
    }));
    document.getElementById('btnAdmissionStarter').addEventListener('click',async()=>{
        if(!ready())return;
        if(canvas.getObjects().length&&!window.confirm('Replace this side with a starter admission form?'))return;
        setTemplateBusy(true);
        try{
            const [logo,photo,sign,receiptSign,receiptStamp]=await Promise.all([
                image('school-logo','School Logo',150,150),image('student-photo','Student Photo',240,280),
                image('principal-signature','Principal Sign',240,64),image('principal-signature','Authorised Sign',220,66),
                image('school-stamp','School Stamp',150,150)
            ]);
            const k=Math.min(CARD_WIDTH_PX/2100,CARD_HEIGHT_PX/2970),ox=(CARD_WIDTH_PX-2100*k)/2,oy=(CARD_HEIGHT_PX-2970*k)/2;
            let section='school-copy';
            const add=object=>{object.data={...object.data,admissionSection:section};canvas.add(object);return object;};
            const at=(object,x,y)=>{object.set({left:ox+x*k,top:oy+y*k,scaleX:k,scaleY:k});return add(object);};
            canvas.discardActiveObject();canvas.clear();canvas.backgroundColor='#ffffff';
            function text(value,x,y,width,size,variable=false,extra={},lines=1){
                const label=variable?[...document.getElementById('dynamicVarSelect').options].find(o=>o.value==='{{'+value+'}}')?.textContent||value:value;
                const object=new fabric.Textbox(label,{left:ox+x*k,top:oy+y*k,width:width*k,fontFamily:'Arial',fontSize:size*k,
                    fill:'#23344e',strokeWidth:0,...extra,data:variable?{type:'dynamic-text',variable:'{{'+value+'}}',maxLines:lines,clipEnabled:true,boxHeight:size*1.32*lines*k}
                        :{type:'static-text',baseText:value}});
                if(variable)applyTextClip(object);return add(object);
            }
            function box(x,y,width,height,fill,border=null,radius=0){
                const object=IdCardShapes.create('rectangle',width*k);
                object.set({left:ox+x*k,top:oy+y*k,width:width*k,height:height*k,stroke:border,strokeWidth:border?1.2*k:0});
                object.data.cornerRadius=radius;IdCardShapes.setFill(object,{color:fill});return add(object);
            }
            function line(x,y,width,pattern='solid',color='#8799ad'){
                const object=IdCardShapes.create('line',width*k);
                object.set({left:ox+x*k,top:oy+y*k,width:width*k});
                IdCardShapes.setLineStyle(object,{width:1.5*k,color,pattern});return add(object);
            }
            function table(rows,widths,x,y,rowHeight=72,{fontSize=29,labelSize=27,padding=9,mergedValueRows=[]}={}){
                const model=tableModel.create(rows.length,widths.length,widths.reduce((a,b)=>a+b,0)*k);
                model.columns=widths.map(w=>w*k);
                if(Array.isArray(rowHeight))model.rows=rowHeight.map(height=>height*k);else model.rows.fill(rowHeight*k);
                Object.assign(model.style,{fontFamily:'Arial',fontSize:fontSize*k,padding:padding*k,borderColor:'#d4deea',borderWidth:1*k,verticalAlign:'middle',background:'#ffffff'});
                rows.forEach((row,r)=>row.forEach((value,c)=>{
                    model.cells[r][c].text=value;
                    if(c%2===0)Object.assign(model.cells[r][c].style,{fontWeight:'bold',fontSize:labelSize*k,background:'#f1f5fa',fill:'#28446b'});
                }));
                mergedValueRows.forEach(r=>tableModel.merge(model,{r1:r,r2:r,c1:1,c2:widths.length-1}));
                return add(new fabric.IdCardTable({left:ox+x*k,top:oy+y*k,data:{type:'table',table:model}}));
            }
            function heading(label,y){box(90,y+4,7,29,'#28446b');text(label,115,y,1850,30,false,{fontWeight:'bold'});}
            at(logo,90,75);
            text('school_name',275,70,1735,55,true,{fontWeight:'bold'});
            text('school_address',275,145,1735,29,true,{},2);
            text('school_contact_no',275,230,1735,26,true);
            box(90,285,1920,86,'#28446b');
            text('ADMISSION FORM',125,302,1260,42,false,{fill:'#ffffff',fontWeight:'bold'});
            text('SCHOOL COPY',1540,313,430,25,false,{fill:'#ffffff',fontWeight:'bold',textAlign:'right'});
            table([
                ['Student Name','{{student_name}}','',''],
                ['Student ID','{{student_id}}','Academic Year','{{academic_year}}'],
                ['Class & Section','{{class}}','Roll Number','{{roll_no}}']
            ],[300,530,300,350],90,410,[100,70,70],{mergedValueRows:[0]});
            at(photo,1740,410);
            heading('STUDENT & FAMILY DETAILS',720);
            table([
                ['Registration No','{{registration_no}}','Admission Date','{{admission_date}}'],
                ['Date of Birth','{{dob}}','Gender','{{gender}}'],
                ["Father's Name",'{{father_name}}',"Mother's Name",'{{mother_name}}'],
                ["Father's Occupation",'{{father_occupation}}',"Mother's Occupation",'{{mother_occupation}}'],
                ['Contact Number','{{student_contact}}','Alternative Contact','{{alt_contact}}'],
                ['Blood Group','{{blood_group}}','Religion','{{religion}}'],
                ['Category','{{caste}}','Aadhaar Number','{{aadhaar_no}}']
            ],[360,600,360,600],90,775,[68,68,92,68,68,68,68]);
            table([
                ['Address','{{student_address}}','',''],
                ['Village / Town','{{village}}','Post Office','{{post_office}}'],
                ['District','{{district}}','PIN Code','{{pin_code}}']
            ],[360,600,360,600],90,1305,[100,64,64],{mergedValueRows:[0]});
            heading('ADMISSION & MONTHLY FEE AGREEMENT',1568);
            table([
                ['Agreed Admission Fee','{{currency_symbol}} {{admission_agreed_amount}}','Paid So Far','{{currency_symbol}} {{admission_paid_amount}}'],
                ['Admission Due','{{currency_symbol}} {{admission_due_amount}}','Admission Discount','{{currency_symbol}} {{admission_discount_amount}}'],
                ['Monthly Tuition','{{currency_symbol}} {{monthly_tuition_fee}}','Total Monthly Fee','{{currency_symbol}} {{total_monthly_fee}}']
            ],[360,600,360,600],90,1620,72);
            text('I confirm that the information supplied is correct and agree to follow the school rules.',90,1870,1920,24);
            at(sign,1710,1908);
            [[90,'Student Signature'],[780,'Parent / Guardian Signature'],[1570,'Principal Signature']].forEach(([x,label])=>{
                line(x,1980,440);text(label,x,2000,440,24,false,{textAlign:'center'});
            });

            section='cut-line';
            line(90,2070,1920,'dashed','#64748b');
            text('CUT HERE',885,2053,330,23,false,{textAlign:'center',backgroundColor:'#ffffff',fill:'#64748b'});

            section='guardian-receipt';
            box(90,2120,1920,800,'#f8fafc','#bdcddd',3);
            text('ADMISSION ACKNOWLEDGEMENT',125,2140,1430,28,false,{fontWeight:'bold',fill:'#28446b'});
            box(1640,2136,335,44,'#28446b',null,22);
            text('GUARDIAN COPY',1640,2145,335,22,false,{fontWeight:'bold',fill:'#ffffff',textAlign:'center'});
            text('school_name',125,2187,1450,36,true,{fontWeight:'bold'});
            text('school_contact_no',1610,2200,365,23,true,{textAlign:'right'});
            text('school_address',125,2240,1850,23,true);
            const receiptOptions={fontSize:27,labelSize:25,padding:8};
            table([
                ['Student Name','{{student_name}}','',''],
                ['Class & Section','{{class}}','Academic Year','{{academic_year}}'],
                ['Student ID','{{student_id}}','Registration No','{{registration_no}}'],
                ['Admission Date','{{admission_date}}','Roll Number','{{roll_no}}']
            ],[320,605,320,605],125,2280,[88,60,60,60],{...receiptOptions,mergedValueRows:[0]});
            table([
                ['Agreed Admission Fee','{{currency_symbol}} {{admission_agreed_amount}}','Paid So Far','{{currency_symbol}} {{admission_paid_amount}}'],
                ['Admission Due','{{currency_symbol}} {{admission_due_amount}}','Total Monthly Fee','{{currency_symbol}} {{total_monthly_fee}}']
            ],[320,605,320,605],125,2570,64,receiptOptions);
            at(receiptSign,1715,2740);
            line(125,2830,520);text('Parent / Guardian Signature',125,2850,520,23,false,{textAlign:'center'});
            line(1495,2830,480);text('Authorised Signature',1495,2850,480,23,false,{textAlign:'center'});
            box(1000,2730,250,150,'#ffffff','#bdcddd',6);
            at(receiptStamp,1050,2730);
            text('Please retain this receipt for your records.',125,2890,780,18,false,{fill:'#64748b'});
            canvas.getObjects().forEach(object=>object.setCoords());
            canvas.requestRenderAll();syncPropsPanelFromObject(null);pushHistory();
        }finally{setTemplateBusy(false);}
    });
})();
