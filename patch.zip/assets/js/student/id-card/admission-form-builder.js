/* Admission tools. The editor, named templates, tables, shapes and print renderer are shared. */
(() => {
    function ready() { return canvasReady && !templateBusy && !isSwappingSide && !isRestoringHistory; }
    function image(type, label, width, height) {
        const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="'+width+'" height="'+height+'"><rect width="100%" height="100%" fill="#eef3fa"/><text x="50%" y="50%" text-anchor="middle" dominant-baseline="middle" font-family="Arial" font-size="24" fill="#28446b">'+label+'</text></svg>';
        return new Promise(resolve => fabric.Image.fromURL('data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg), object => {
            object.set({data:{type,borderRadius:0}}); resolve(object);
        }));
    }
    [
        ['btnAddPrincipalSign','principal-signature','Principal Sign',240,80],
        ['btnAddHeadmasterSign','headmaster-signature','Head Master Sign',240,120],
        ['btnAddSchoolStamp','school-stamp','School Stamp',180,180],
        ['btnAddFatherPhoto','father-photo','Father Photo',240,280],
        ['btnAddMotherPhoto','mother-photo','Mother Photo',240,280]
    ].forEach(([id,type,label,width,height]) => document.getElementById(id).addEventListener('click',async()=>{
        if(!ready())return;
        const object=await image(type,label,width,height);
        if(!ready())return;
        addObjectCentered(object);pushHistory();
    }));
    document.getElementById('btnAdmissionStarter').addEventListener('click',async()=>{
        if(!ready())return;
        if(canvas.getObjects().length&&!window.confirm('Replace this side with a starter admission form?'))return;
        setTemplateBusy(true);
        try{
            const [logo,photo,sign]=await Promise.all([image('school-logo','School Logo',180,180),image('student-photo','Student Photo',260,320),image('principal-signature','Principal Sign',280,90)]);
            const k=Math.min(CARD_WIDTH_PX/2100,CARD_HEIGHT_PX/2970),ox=(CARD_WIDTH_PX-2100*k)/2,oy=(CARD_HEIGHT_PX-2970*k)/2;
            const at=(object,x,y)=>{object.set({left:ox+x*k,top:oy+y*k,scaleX:k,scaleY:k});canvas.add(object);};
            canvas.discardActiveObject();canvas.clear();canvas.backgroundColor='#ffffff';
            function text(value,x,y,width,size,variable=false,extra={}){
                const label=variable?[...document.getElementById('dynamicVarSelect').options].find(o=>o.value==='{{'+value+'}}')?.textContent||value:value;
                const object=new fabric.Textbox(label,{left:ox+x*k,top:oy+y*k,width:width*k,fontFamily:'Arial',fontSize:size*k,
                    fill:'#23344e',strokeWidth:0,...extra,data:variable?{type:'dynamic-text',variable:'{{'+value+'}}',clipEnabled:true,boxHeight:size*2.5*k}
                        :{type:'static-text',baseText:value}});
                if(variable)applyTextClip(object);canvas.add(object);
            }
            function table(rows,widths,x,y,rowHeight=85){
                const model=tableModel.create(rows.length,widths.length,widths.reduce((a,b)=>a+b,0)*k);
                model.columns=widths.map(w=>w*k);
                if(Array.isArray(rowHeight))model.rows=rowHeight.map(height=>height*k);else model.rows.fill(rowHeight*k);
                Object.assign(model.style,{fontFamily:'Arial',fontSize:31*k,padding:12*k,borderColor:'#cbd5e1',borderWidth:1*k,verticalAlign:'middle',background:'#ffffff'});
                rows.forEach((row,r)=>row.forEach((value,c)=>{
                    model.cells[r][c].text=value;
                    if(c%2===0)Object.assign(model.cells[r][c].style,{fontWeight:'bold',background:'#f2f6fb',fill:'#28446b'});
                }));
                at(new fabric.IdCardTable({data:{type:'table',table:model}}),x,y);
                // Table dimensions/font sizes already use the document scale.
                const object=canvas.getObjects().at(-1);object.set({scaleX:1,scaleY:1});object.setCoords();
            }
            at(logo,110,95);
            text('school_name',330,90,1660,62,true,{fontWeight:'bold'});
            text('school_address',330,185,1660,32,true);
            text('school_contact_no',330,245,1660,30,true);
            const band=IdCardShapes.create('rectangle',1880*k);band.set({height:100*k});IdCardShapes.setFill(band,{color:'#28446b'});
            band.set({left:ox+110*k,top:oy+345*k});canvas.add(band);
            text('ADMISSION FORM',110,363,1880,46,false,{fill:'#ffffff',fontWeight:'bold',textAlign:'center'});
            table([['Academic Year','{{academic_year}}'],['Student ID','{{student_id}}'],['Student Name','{{student_name}}'],['Class & Section','{{class}}']],
                [330,1140],110,500,82);
            at(photo,1720,500);
            text('STUDENT & FAMILY DETAILS',110,910,1880,37,false,{fontWeight:'bold'});
            table([
                ['Roll Number','{{roll_no}}','Registration No','{{registration_no}}'],
                ['Admission Date','{{admission_date}}','Date of Birth','{{dob}}'],
                ["Father's Name",'{{father_name}}',"Mother's Name",'{{mother_name}}'],
                ["Father's Occupation",'{{father_occupation}}',"Mother's Occupation",'{{mother_occupation}}'],
                ['Contact Number','{{student_contact}}','Alternative Contact','{{alt_contact}}'],
                ['Gender','{{gender}}','Blood Group','{{blood_group}}'],
                ['Religion','{{religion}}','Category','{{caste}}']
            ],[380,560,380,560],110,980,90);
            table([['Address','{{student_address}}'],['Village / Town','{{village}}'],['Post Office','{{post_office}}'],['District','{{district}}'],['PIN Code','{{pin_code}}']],
                [380,1500],110,1650,[110,65,65,65,65]);
            text('ADMISSION FEE AGREEMENT',110,2070,1880,37,false,{fontWeight:'bold'});
            table([
                ['Agreed Admission Fee','{{currency_symbol}} {{admission_agreed_amount}}','Paid So Far','{{currency_symbol}} {{admission_paid_amount}}'],
                ['Admission Due','{{currency_symbol}} {{admission_due_amount}}','Monthly Tuition','{{currency_symbol}} {{monthly_tuition_fee}}']
            ],[380,560,380,560],110,2140,95);
            text('I confirm that the information supplied is correct and agree to follow the school rules.',110,2430,1880,32);
            at(sign,1670,2660);
            [[110,'Student Signature'],[790,'Parent / Guardian Signature'],[1570,'Principal Signature']].forEach(([x,label])=>{
                const line=IdCardShapes.create('line',420*k);IdCardShapes.setLineStyle(line,{width:1.5*k,color:'#64748b'});
                line.set({left:ox+x*k,top:oy+2770*k});canvas.add(line);
                text(label,x,2800,420,28,false,{textAlign:'center'});
            });
            canvas.getObjects().forEach(object=>object.setCoords());
            canvas.requestRenderAll();syncPropsPanelFromObject(null);pushHistory();
        }finally{setTemplateBusy(false);}
    });
})();
