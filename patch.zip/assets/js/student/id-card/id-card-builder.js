/**
 * id-card-builder.js
 * -----------------------------------------------------------------
 * Core logic for the Fabric.js-based Visual ID Card Editor.
 * - Canvas init (11:17 ratio = 55mm x 85mm), font preloading + loading overlay
 * - Toolbox actions (dynamic text, static text, image, QR placeholder)
 * - Photoshop-style Layers panel (drag-reorder, show/hide, lock)
 * - Undo / Redo history stack (Ctrl+Z / Ctrl+Y)
 * - Keyboard shortcuts: arrow-move, delete, duplicate, copy/paste style, layer order
 * - Properties panel bindings (font, color, stroke, shadow, align, image border
 *   radius, image background color)
 * - Design saved via canvas.toJSON()
 * -----------------------------------------------------------------
 */

// ---- 0. CONFIG ------------------------------------------------------------
const CARD_WIDTH_PX = 550; // 55mm * 10 (11:17 ratio preserved)
const CARD_HEIGHT_PX = 850; // 85mm * 10
const HISTORY_LIMIT = 60;
const ARROW_STEP = 1;
const ARROW_STEP_SHIFT = 10;

const FONT_LIST = [
    "Poppins",
    "Arial",
    "Georgia",
    "Roboto",
    "Courier New",
    "Times New Roman",
    "Verdana",
    "Montserrat",
    "Open Sans",
    "Lato",
    "Nunito",
    "Oswald",
    "Playfair Display",
    "Merriweather",
];

const TEXT_TYPES = ["textbox", "i-text", "text"];
function isTextObject(obj) {
    return !!obj && TEXT_TYPES.includes(obj.type);
}
function isImageObject(obj) {
    return !!obj && obj.type === "image";
}
// stroke/shadow — applicable to both text and image objects (common Fabric properties)
function isStyleable(obj) {
    return isTextObject(obj) || isImageObject(obj);
}

// ---- Text Case (Uppercase / Lowercase / Capitalize) -----------------------
// Applied directly to static text (baked into the saved design) and, for
// Variable Text, applied to the REAL substituted student value at print time
// instead (see render-id-cards-batch.js — this exact function is duplicated
// there, keep both copies in sync).
function applyTextCase(str, caseType) {
    if (str === null || str === undefined) return "";
    str = String(str); // <-- এই লাইনটা যোগ করো
    switch (caseType) {
        case "uppercase":
            return str.toUpperCase();
        case "lowercase":
            return str.toLowerCase();
        case "capitalize":
            return str.replace(
                /\w\S*/g,
                (w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase(),
            );
        default:
            return str;
    }
}

// ---- Max Lines (prevents long names/addresses from overflowing the card) --
// Trims a Fabric Textbox's text word-by-word (falling back to char-by-char
// for a single very long token) and appends an ellipsis until it wraps
// within `maxLines` lines at its current width/font settings. maxLines <= 0
// disables the cap. Also duplicated in render-id-cards-batch.js, since that's
// where long real student data actually gets substituted — keep in sync.
function enforceMaxLines(textboxObj, maxLines) {
    if (!textboxObj || !maxLines || maxLines <= 0) return;
    const ELLIPSIS = "…";
    if (typeof textboxObj._initDimensions === "function")
        textboxObj._initDimensions();
    if (!textboxObj._textLines || textboxObj._textLines.length <= maxLines)
        return;

    let text = (textboxObj.text || "").replace(/…\s*$/, "").trimEnd();
    let guard = 0; // safety cap so a pathological case can never loop forever
    while (text.length > 0 && guard < 500) {
        guard++;
        const withoutLastWord = text.replace(/\s*\S+$/, "");
        text = withoutLastWord === text ? text.slice(0, -1) : withoutLastWord;
        const candidate =
            text.trimEnd().length > 0 ? text.trimEnd() + " " + ELLIPSIS : ELLIPSIS;
        textboxObj.set("text", candidate);
        if (typeof textboxObj._initDimensions === "function")
            textboxObj._initDimensions();
        if (!textboxObj._textLines || textboxObj._textLines.length <= maxLines)
            break;
    }
}

// ---- Rounded text background (Fabric's native `backgroundColor` is always a
// flat rectangle — ctx.fillRect — with no corner-radius support). We monkey-
// patch _renderBackground so a text object can store a radius percentage in
// data.bgRadius and get a real rounded-rect background instead.
// ⚠️ IMPORTANT: render-id-cards-batch.js renders cards with its own Fabric
// StaticCanvas instance (separate page/runtime), so this exact patch is
// duplicated there too — keep both copies in sync if this logic changes.
(function patchRoundedTextBackground() {
    const originalRenderBackground = fabric.Text.prototype._renderBackground;
    fabric.Text.prototype._renderBackground = function (ctx) {
        const radiusPercent = (this.data && this.data.bgRadius) || 0;
        if (!this.backgroundColor || radiusPercent <= 0) {
            originalRenderBackground.call(this, ctx);
            return;
        }
        const dim = this._getNonTransformedDimensions();
        const w = dim.x,
            h = dim.y;
        const r = Math.min(
            (radiusPercent / 100) * (Math.min(w, h) / 2),
            w / 2,
            h / 2,
        );
        const x = -w / 2,
            y = -h / 2;
        ctx.save();
        ctx.fillStyle = this.backgroundColor;
        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.lineTo(x + w - r, y);
        ctx.arcTo(x + w, y, x + w, y + r, r);
        ctx.lineTo(x + w, y + h - r);
        ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
        ctx.lineTo(x + r, y + h);
        ctx.arcTo(x, y + h, x, y + h - r, r);
        ctx.lineTo(x, y + r);
        ctx.arcTo(x, y, x + r, y, r);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
        if (this.styles && typeof this._removeShadow === "function") {
            this._removeShadow(ctx);
        }
    };
})();

// ---- Fixed-Height Clip (HARD overflow safety net) --------------------------
// ROOT CAUSE this fixes: fabric.Textbox has no real "height" property — its
// height is always just however many lines the current text wraps into. At
// design time you only ever see the short placeholder label (e.g. "Address"),
// so the box LOOKS small and you build the rest of the card around it. At
// print time the real student value (often much longer) wraps onto more
// lines than the label did, the Textbox silently grows taller, and — because
// nothing ever clipped it — the extra lines spill straight past wherever you
// visually placed the box, over neighboring elements or off the card edge.
// This is what was happening in the reported video.
//
// Max Lines (above) already fixes this for the common case by truncating the
// text itself with "…" — but it depends on someone remembering to set it per
// field, and it only limits LINE COUNT, not literal pixel height (a
// non-default line-height/font-size combo could still, in theory, exceed the
// box). This clipPath is the structural, can't-forget-it safety net: however
// tall the text tries to get, drawing is hard-clipped to `data.boxHeight`
// (in the object's own local space, so it tracks position/rotation
// automatically). Independent of and stacks safely with Max Lines.
//
// Clip to Fixed Width works the same way, horizontally: obj.data.clipWidthEnabled
// (bool) / obj.data.boxWidth (px). The two toggles are independent — either one
// can be on by itself (clipping only that dimension) or both together, and
// applyTextClip builds a single clipPath Rect covering whichever are enabled.
//
// obj.data.clipEnabled/boxHeight and obj.data.clipWidthEnabled/boxWidth — all
// persisted via canvas.toJSON(['data', ...]), same as every other custom field
// on this object.
// ⚠️ Duplicated in render-id-cards-batch.js (separate Fabric runtime/page) —
// keep both copies in sync if this logic changes.
function applyTextClip(obj) {
    if (!isTextObject(obj)) return;
    const heightEnabled = !!(obj.data && obj.data.clipEnabled);
    const boxHeight = (obj.data && obj.data.boxHeight) || 0;
    const widthEnabled = !!(obj.data && obj.data.clipWidthEnabled);
    const boxWidth = (obj.data && obj.data.boxWidth) || 0;

    // Keep the WRAP width in sync with the CLIP width. Fabric wraps text
    // using obj.width, but the clip rect below is sized from data.boxWidth —
    // two independent numbers. If boxWidth ever ends up narrower than
    // obj.width, Fabric happily wraps a word onto the current line (thinking
    // the wider obj.width is available) and the clip then slices off
    // whatever hangs past boxWidth — chopping a word mid-letter ("Road" ->
    // "Ro") instead of ever wrapping it down. Forcing obj.width = boxWidth
    // before re-wrapping guarantees a word can never wrap somewhere the clip
    // is about to cut it off.
    if (widthEnabled && boxWidth > 0 && obj.width !== boxWidth) {
        obj.set({ width: boxWidth });
        if (typeof obj.initDimensions === "function") obj.initDimensions();
    }

    if ((!heightEnabled || boxHeight <= 0) && (!widthEnabled || boxWidth <= 0)) {
        obj.clipPath = null;
        obj.dirty = true;
        return;
    }

    // Whichever dimension isn't being clipped falls back to the object's own
    // current size (+small buffer so stroke/glyph edges aren't clipped), so
    // turning on just one of the two toggles never clips the other axis.
    const clipWidth = widthEnabled && boxWidth > 0 ? boxWidth : 100000;

    const clipHeight = heightEnabled && boxHeight > 0 ? boxHeight : 100000;

    obj.clipPath = new fabric.Rect({
        width: clipWidth,
        height: clipHeight,
        originX: "center",
        originY: "center",
        left: 0,
        top: 0,
    });
    obj.clipPath.absolutePositioned = false; // clip lives in the object's own local coord space
    obj.dirty = true;
}

// Live feedback: if the field's current content already exceeds its box
// height while clipping is on, warn right in the panel so it's caught at
// design time instead of discovered later on a printed card.
function updateClipWarning(obj) {
    const el = document.getElementById("propClipWarning");
    if (!el || !isTextObject(obj)) return;
    const enabled = !!(obj.data && obj.data.clipEnabled);
    const boxHeight = (obj.data && obj.data.boxHeight) || 0;
    if (!enabled || boxHeight <= 0) {
        el.textContent =
            obj.data && obj.data.type === "dynamic-text"
                ? "Off — long real student data can spill outside this box at print time."
                : "Off — this field can spill outside its box if the text grows.";
        el.style.color = "#6c757d";
        return;
    }
    if (typeof obj._initDimensions === "function") obj._initDimensions();
    const actualHeight = obj.height || 0;
    if (actualHeight > boxHeight) {
        el.textContent = `⚠ Current content (${Math.round(actualHeight)}px) exceeds the box height (${boxHeight}px) — the extra will be invisibly clipped.`;
        el.style.color = "#dc3545";
    } else {
        el.textContent = `On — content is hard-clipped at ${boxHeight}px, will never spill outside this box.`;
        el.style.color = "#198754";
    }
}

// Same live-feedback idea as updateClipWarning, for the Clip to Fixed Width toggle.
function updateClipWidthWarning(obj) {
    const el = document.getElementById("propClipWidthWarning");
    if (!el || !isTextObject(obj)) return;
    const enabled = !!(obj.data && obj.data.clipWidthEnabled);
    const boxWidth = (obj.data && obj.data.boxWidth) || 0;
    if (!enabled || boxWidth <= 0) {
        el.textContent =
            obj.data && obj.data.type === "dynamic-text"
                ? "Off — long real student data can spill past this box at print time."
                : "Off — this field can spill past its box if the text grows.";
        el.style.color = "#6c757d";
        return;
    }
    if (typeof obj._initDimensions === "function") obj._initDimensions();
    const actualWidth = obj.width || 0;
    if (actualWidth > boxWidth) {
        el.textContent = `⚠ Current content (${Math.round(actualWidth)}px) exceeds the box width (${boxWidth}px) — the extra will be invisibly clipped.`;
        el.style.color = "#dc3545";
    } else {
        el.textContent = `On — content is hard-clipped at ${boxWidth}px, will never spill past this box.`;
        el.style.color = "#198754";
    }
}

// ---- 1. LOADING OVERLAY -----------------------------------------------
const loadingOverlay = document.getElementById("canvasLoadingOverlay");
function showLoading() {
    if (loadingOverlay) loadingOverlay.style.display = "flex";
}
function hideLoading() {
    if (loadingOverlay) loadingOverlay.style.display = "none";
}
showLoading();

// Populate the font dropdown (no need to wait for the canvas to be ready)
(function populateFontSelect() {
    const sel = document.getElementById("propFontFamily");
    if (!sel) return;
    sel.innerHTML = FONT_LIST.map(
        (f) => `<option value="${f}">${f}</option>`,
    ).join("");
})();

// Selection box styling
fabric.Object.prototype.set({
    borderColor: "#4F46E5",
    cornerColor: "#4F46E5",
    cornerStrokeColor: "#ffffff",
    transparentCorners: false,
    cornerSize: 8,
});

// ---- 2. CANVAS SETUP ----------------------------------------------------
const canvas = new fabric.Canvas("idCardCanvas", {
    width: CARD_WIDTH_PX,
    height: CARD_HEIGHT_PX,
    backgroundColor: "#ffffff",
    preserveObjectStacking: true,
});

// Scale canvas visually to fit viewport (actual working coordinates stay the
// same — zoomToFit only affects the view, not the underlying data)
function fitCanvasToStage() {
    const stage = document.querySelector(".builder-stage");
    const availableH = stage.clientHeight - 20;
    const scale = Math.min(1, availableH / CARD_HEIGHT_PX);
    canvas.setZoom(scale);
    canvas.setWidth(CARD_WIDTH_PX * scale);
    canvas.setHeight(CARD_HEIGHT_PX * scale);
}
window.addEventListener("resize", fitCanvasToStage);

// For fast readiness: fonts are preloaded in parallel ahead of time, so there's
// no font-swap/jank when text is rendered on the canvas.
const FONT_LOAD_PROMISES = FONT_LIST.map((f) => {
    try {
        return document.fonts.load(`16px "${f}"`);
    } catch (e) {
        return Promise.resolve();
    }
});

let canvasInitialized = false;
function initCanvasContent() {
    if (canvasInitialized) return;
    canvasInitialized = true;

    if (typeof EXISTING_DESIGN_JSON !== "undefined" && EXISTING_DESIGN_JSON) {
        canvas.loadFromJSON(EXISTING_DESIGN_JSON, () => {
            canvas.renderAll();
            fitCanvasToStage();
            afterCanvasReady();
        });
    } else {
        fitCanvasToStage();
        afterCanvasReady();
    }
}

function afterCanvasReady() {
    hideLoading();
    refreshLayersPanel();
    refitAllTextObjectsToLoadedFonts(); // harmless no-op if fonts were already ready
    pushHistory(); // baseline history state
}

// ---- Font-Ready Re-fit ------------------------------------------------
// ROOT CAUSE: initCanvasContent() runs on whichever finishes FIRST — real
// fonts loading, or the 1.2s safety timeout (added so a slow font CDN can
// never freeze the Builder). On a slow connection the timeout wins, so
// EXISTING_DESIGN_JSON gets loaded and every Textbox wraps/sizes itself using
// the BROWSER'S TEMPORARY FALLBACK FONT (e.g. Arial) instead of the design's
// real font (Poppins, Oswald, etc.). Fabric draws the selection box/bounding
// box from that fallback-font wrap. A moment later the real font finishes
// loading and Fabric repaints the glyphs in it — but never recomputes the
// wrap on its own, and the real font is very often WIDER than the fallback,
// so the freshly-drawn text spills past the (still fallback-sized) box. This
// is exactly the same class of bug already fixed for print time in
// render-id-cards-batch.js (see its preloadTemplateFonts()/initDimensions()
// comments) — this re-applies that same fix to the Builder's own canvas.
function refitAllTextObjectsToLoadedFonts() {
    let touched = false;
    canvas.getObjects().forEach((obj) => {
        if (!isTextObject(obj)) return;

        const originalWidth = obj.width; // width সেভ করা

        // Fixed width আগেই ফিরিয়ে আনা হচ্ছে — initDimensions() width অনুযায়ী wrap
        // করে, তাই width আগে ঠিক করে তারপর wrap করানো হয় — উলটোপাল্টা করলে চৌড়া
        // width-এ wrap করে তারপর সংখ্যায় সঙ্কুচিত করলে লেখা overflow করে যায় (যেমন
        // print-time-এ render-id-cards-batch.js-এ হতো).
        if (obj.type === "textbox") {
            obj.set({ width: originalWidth });
        }

        if (typeof obj.initDimensions === "function") obj.initDimensions();

        obj.setCoords();
        if (obj.data && (obj.data.clipEnabled || obj.data.clipWidthEnabled))
            applyTextClip(obj);
        touched = true;
    });
    if (touched) canvas.renderAll();
}
// document.fonts.ready is the browser's own stronger guarantee that font
// metrics are actually installed for measurement — not just that each
// individual load() promise settled — so wait for that too before re-fitting.
Promise.all(FONT_LOAD_PROMISES)
    .then(() =>
        document.fonts && document.fonts.ready ? document.fonts.ready : null,
    )
    .catch(() => { })
    .finally(refitAllTextObjectsToLoadedFonts);

// Canvas init fires once fonts finish loading (or after a 1.2s safety timeout
// either way), so the builder never gets stuck on a slow network.
Promise.all(FONT_LOAD_PROMISES).finally(initCanvasContent);
setTimeout(initCanvasContent, 1200);

// ---- 3. TOOLBOX ACTIONS ---------------------------------------------------

/** Common helper: add an object to the canvas, centered, with shared settings */
function addObjectCentered(obj) {
    obj.set({
        left: canvas.getWidth() / (2 * canvas.getZoom()),
        top: canvas.getHeight() / (2 * canvas.getZoom()),
        originX: "center",
        originY: "center",
    });
    canvas.add(obj);
    canvas.setActiveObject(obj);
    canvas.renderAll();
}

// ---- Dynamic variable text (e.g. {{student_name}}, {{school_name}}) ----
document.getElementById("btnAddDynamicText").addEventListener("click", () => {
    const select = document.getElementById("dynamicVarSelect");
    const variable = select.value;
    const label = select.options[select.selectedIndex].text;

    const textbox = new fabric.Textbox(label, {
        fontSize: 22,
        fontFamily: "Poppins",
        fill: "#000000",
        width: 220,
        stroke: null,
        strokeWidth: 0,
        splitByGrapheme: false,
        // ⚠️ Custom data — this is what's used to substitute the real value during batch render
        // clipEnabled/boxHeight default ON so every NEW field is safe-by-default against
        // overflow; boxHeight starts equal to the label's own height — widen it in the
        // Properties panel (or click "Use Current") for fields expected to hold multi-line
        // real data (address, school name, etc.), ideally together with a Max Lines value.
        data: {
            type: "dynamic-text",
            variable: variable,
            textCase: "none",
            maxLines: 0,

            clipEnabled: false,
            boxHeight: 0,

            clipWidthEnabled: false,
            boxWidth: 0,
        },
    });
    textbox.data.boxHeight = Math.ceil(textbox.height || 30);
    applyTextClip(textbox);
    addObjectCentered(textbox);
});

// ---- Static text (fixed, admin-typed) ----
document.getElementById("btnAddStaticText").addEventListener("click", () => {
    const textbox = new fabric.Textbox("Static Text", {
        fontSize: 18,
        fontFamily: "Poppins",
        fill: "#000000",
        width: 200,
        stroke: null,
        strokeWidth: 0,
        splitByGrapheme: false,
        // baseText is the untouched, as-typed source — Text Case/Max Lines are
        // always re-derived from it so toggling settings never compounds/loses content.
        data: {
            type: "static-text",
            textCase: "none",
            maxLines: 0,
            baseText: "Static Text",
            clipEnabled: false,
            boxHeight: 0,
            clipWidthEnabled: false,
            boxWidth: 0,
        },
    });
    textbox.data.boxHeight = Math.ceil(textbox.height || 26);
    applyTextClip(textbox);
    addObjectCentered(textbox);
});

// ---- School Logo placeholder (the server sends the real URL at render time) ----
document.getElementById("btnAddSchoolLogo").addEventListener("click", () => {
    fabric.Image.fromURL(
        "https://placehold.co/120x120.png?text=Logo",
        (img) => {
            img.set({ data: { type: "school-logo", borderRadius: 0 } });
            img.scaleToWidth(120);
            addObjectCentered(img);
        },
        { crossOrigin: "anonymous" },
    );
});

// ---- Student Photo placeholder ----
document.getElementById("btnAddStudentPhoto").addEventListener("click", () => {
    fabric.Image.fromURL(
        "https://placehold.co/150x180.png?text=Student+Photo",
        (img) => {
            img.set({ data: { type: "student-photo", borderRadius: 0 } });
            img.scaleToWidth(150);
            addObjectCentered(img);
        },
        { crossOrigin: "anonymous" },
    );
});

// ---- QR Code placeholder ----
document.getElementById("btnAddQrPlaceholder").addEventListener("click", () => {
    fabric.Image.fromURL(
        "https://placehold.co/90x90.png?text=QR",
        (img) => {
            img.set({ data: { type: "qr-code", borderRadius: 0 } });
            img.scaleToWidth(90);
            addObjectCentered(img);
        },
        { crossOrigin: "anonymous" },
    );
});

// ---- Custom uploaded image (background art, decorations, etc.) ----
document.getElementById("customImageInput").addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
        fabric.Image.fromURL(evt.target.result, (img) => {
            img.set({ data: { type: "custom-image", borderRadius: 0 } });
            img.scaleToWidth(150);
            addObjectCentered(img);
        });
    };
    reader.readAsDataURL(file);
    e.target.value = ""; // reset so the same file can be selected again
});

// ---- Layer ordering & delete (from buttons) ----
document.getElementById("btnBringForward").addEventListener("click", () => {
    const obj = canvas.getActiveObject();
    if (obj) {
        canvas.bringForward(obj);
        canvas.renderAll();
        refreshLayersPanel();
        pushHistory();
    }
});
document.getElementById("btnSendBackward").addEventListener("click", () => {
    const obj = canvas.getActiveObject();
    if (obj) {
        canvas.sendBackwards(obj);
        canvas.renderAll();
        refreshLayersPanel();
        pushHistory();
    }
});
document.getElementById("btnDeleteSelected").addEventListener("click", () => {
    const obj = canvas.getActiveObject();
    if (obj) {
        canvas.remove(obj);
        canvas.discardActiveObject();
        canvas.renderAll();
        refreshLayersPanel();
        pushHistory();
    }
});

// ---- Lock All / Unlock All ----
document.getElementById("btnLockAll").addEventListener("click", () => {
    canvas.discardActiveObject();
    canvas.getObjects().forEach((o) => {
        o.selectable = false;
        o.evented = false;
    });
    canvas.renderAll();
    refreshLayersPanel();
    pushHistory();
});
document.getElementById("btnUnlockAll").addEventListener("click", () => {
    canvas.getObjects().forEach((o) => {
        o.selectable = true;
        o.evented = true;
    });
    canvas.renderAll();
    refreshLayersPanel();
    pushHistory();
});

// ---- Duplicate ----
document
    .getElementById("btnDuplicateSelected")
    .addEventListener("click", () => {
        const obj = canvas.getActiveObject();
        if (obj) duplicateObject(obj);
    });
function duplicateObject(obj) {
    obj.clone(
        (cloned) => {
            cloned.set({ left: (obj.left || 0) + 20, top: (obj.top || 0) + 20 });
            if (obj.data) cloned.data = JSON.parse(JSON.stringify(obj.data));
            if (isTextObject(cloned)) applyTextClip(cloned); // clipPath is a live object, not just data — must rebuild
            canvas.add(cloned);
            canvas.setActiveObject(cloned);
            canvas.renderAll();
            refreshLayersPanel();
            pushHistory();
        },
        ["data", "crossOrigin"],
    );
}

// ---- Copy / Paste style (copy one element's design onto another) ----
let copiedStyle = null;
const STYLE_PROPS = [
    "fontFamily",
    "fontSize",
    "fill",
    "fontWeight",
    "fontStyle",
    "textAlign",
    "stroke",
    "strokeWidth",
    "shadow",
    "underline",
    "linethrough",
    "lineHeight",
];
// Image-only style props copied separately (background color + border radius)
const IMAGE_STYLE_PROPS = ["backgroundColor"];

function copyStyleFromObject(obj) {
    if (!isStyleable(obj)) return;
    copiedStyle = {};
    STYLE_PROPS.forEach((p) => {
        copiedStyle[p] = obj[p];
    });
    if (copiedStyle.shadow)
        copiedStyle.shadow = new fabric.Shadow(copiedStyle.shadow);
    // Stroke width/position now live in data (fabric's own strokeWidth may be
    // doubled internally for inside/outside), so copy those from data instead.
    copiedStyle.strokeWidthDesired = (obj.data && obj.data.strokeWidth) || 0;
    copiedStyle.strokePosition =
        (obj.data && obj.data.strokePosition) || "center";
    if (isImageObject(obj)) {
        IMAGE_STYLE_PROPS.forEach((p) => {
            copiedStyle[p] = obj[p];
        });
        copiedStyle.borderRadius = (obj.data && obj.data.borderRadius) || 0;
    }
    if (isTextObject(obj)) {
        copiedStyle.gradient =
            obj.data && obj.data.gradient ? { ...obj.data.gradient } : null;
        copiedStyle.textBackgroundColor = obj.backgroundColor || "";
        copiedStyle.bgRadius = (obj.data && obj.data.bgRadius) || 0;
        copiedStyle.textCase = (obj.data && obj.data.textCase) || "none";
        copiedStyle.maxLines = (obj.data && obj.data.maxLines) || 0;
        // Clip height/width are intentionally NOT copied — they're tied to this
        // specific field's own footprint on the card, not a transferable "style".
    }
    notify("Style copied. Now select another element and paste it.");
}
function pasteStyleToObject(obj) {
    if (!copiedStyle) {
        notify("Copy a style from an element first.");
        return;
    }
    if (!isStyleable(obj)) return;
    if (!obj.data) obj.data = {};

    // Text-specific properties (font/fill, etc.) don't need to be applied to images
    const applicable = isTextObject(obj)
        ? {
            fontFamily: copiedStyle.fontFamily,
            fontSize: copiedStyle.fontSize,
            fontWeight: copiedStyle.fontWeight,
            fontStyle: copiedStyle.fontStyle,
            textAlign: copiedStyle.textAlign,
            stroke: copiedStyle.stroke,
            shadow: copiedStyle.shadow,
            underline: copiedStyle.underline,
            linethrough: copiedStyle.linethrough,
            lineHeight: copiedStyle.lineHeight,
        }
        : { stroke: copiedStyle.stroke, shadow: copiedStyle.shadow };
    obj.set(applicable);

    obj.data.strokeWidth = copiedStyle.strokeWidthDesired || 0;
    obj.data.strokePosition = copiedStyle.strokePosition || "center";
    applyStrokeStyle(obj);

    if (isImageObject(obj) && typeof copiedStyle.borderRadius === "number") {
        obj.data.borderRadius = copiedStyle.borderRadius;
        obj.set({ backgroundColor: copiedStyle.backgroundColor || "" });
        applyImageClipPath(obj);
    }
    if (isTextObject(obj)) {
        if (copiedStyle.gradient && copiedStyle.gradient.enabled) {
            obj.data.gradient = { ...copiedStyle.gradient };
            obj.set({
                fill: buildTextGradient(
                    obj,
                    copiedStyle.gradient.color1,
                    copiedStyle.gradient.color2,
                    copiedStyle.gradient.angle,
                ),
            });
        } else {
            obj.data.gradient = { enabled: false };
            obj.set({ fill: copiedStyle.fill });
        }
        obj.data.bgRadius = copiedStyle.bgRadius || 0;
        obj.set({ backgroundColor: copiedStyle.textBackgroundColor || "" });
        obj.dirty = true;

        obj.data.textCase = copiedStyle.textCase || "none";
        obj.data.maxLines = copiedStyle.maxLines || 0;
        if (obj.data.type === "static-text") {
            if (typeof obj.data.baseText !== "string") obj.data.baseText = obj.text;
            obj.set("text", applyTextCase(obj.data.baseText, obj.data.textCase));
            enforceMaxLines(obj, obj.data.maxLines);
        }
    }

    if (obj.data && (obj.data.clipEnabled || obj.data.clipWidthEnabled))
        applyTextClip(obj);
    canvas.renderAll();
    syncPropsPanelFromObject(obj); // also refreshes the clip warnings via updateClipWarning/updateClipWidthWarning
    pushHistory();
    notify("Style pasted.");
}
document.getElementById("btnCopyStyle").addEventListener("click", () => {
    const obj = canvas.getActiveObject();
    if (obj) copyStyleFromObject(obj);
});
document.getElementById("btnPasteStyle").addEventListener("click", () => {
    const obj = canvas.getActiveObject();
    if (obj) pasteStyleToObject(obj);
});

function notify(msg) {
    toastr.success(msg);
}

// ---- 4. PROPERTIES PANEL --------------------------------------------------
const propsFields = document.getElementById("propsFields");
const noSelectionMsg = document.getElementById("noSelectionMsg");

function syncPropsPanelFromObject(obj) {
    const styleable = isStyleable(obj);
    propsFields.style.display = styleable ? "block" : "none";
    noSelectionMsg.style.display = obj ? "none" : "block";
    refreshLayersPanel();
    if (!styleable) return;

    const isText = isTextObject(obj);
    const isImage = isImageObject(obj);
    document.getElementById("textOnlyProps").style.display = isText
        ? "block"
        : "none";
    document.getElementById("imageOnlyProps").style.display = isImage
        ? "block"
        : "none";

    if (isText) {
        document.getElementById("propFontFamily").value =
            obj.fontFamily || "Poppins";
        document.getElementById("propFontSize").value = obj.fontSize || 16;
        const isGradientFill = !!(
            obj.data &&
            obj.data.gradient &&
            obj.data.gradient.enabled
        );
        document.getElementById("propColor").value = isGradientFill
            ? "#000000"
            : obj.fill || "#000000";
        document.getElementById("propColor").disabled = isGradientFill;
        document
            .getElementById("propBold")
            .classList.toggle("active", obj.fontWeight === "bold");
        document
            .getElementById("propItalic")
            .classList.toggle("active", obj.fontStyle === "italic");
        document
            .getElementById("propUnderline")
            .classList.toggle("active", obj.underline === true);

        // ---- Text case ----
        document.getElementById("propTextCase").value =
            (obj.data && obj.data.textCase) || "none";

        // ---- Line height ----
        const lineHeight =
            typeof obj.lineHeight === "number" ? obj.lineHeight : 1.16;
        document.getElementById("propLineHeight").value = lineHeight;
        document.getElementById("propLineHeightValue").textContent =
            lineHeight.toFixed(2);

        // ---- Max lines ----
        document.getElementById("propMaxLines").value =
            (obj.data && obj.data.maxLines) || 0;
        updateLineCountIndicator(obj);

        // ---- Fixed-height clip (overflow safety net) ----
        const clipEnabled = !!(obj.data && obj.data.clipEnabled);
        document.getElementById("propClipEnable").checked = clipEnabled;
        document.getElementById("propBoxHeight").value =
            (obj.data && obj.data.boxHeight) || Math.ceil(obj.height || 0);
        document.getElementById("propBoxHeight").disabled = !clipEnabled;
        document.getElementById("btnUseCurrentHeight").disabled = !clipEnabled;
        updateClipWarning(obj);

        // ---- Fixed-width clip (overflow safety net, horizontal) ----
        const clipWidthEnabled = !!(obj.data && obj.data.clipWidthEnabled);
        document.getElementById("propClipWidthEnable").checked = clipWidthEnabled;
        document.getElementById("propBoxWidth").value =
            (obj.data && obj.data.boxWidth) || Math.ceil(obj.width || 0);
        document.getElementById("propBoxWidth").disabled = !clipWidthEnabled;
        document.getElementById("btnUseCurrentWidth").disabled = !clipWidthEnabled;
        updateClipWidthWarning(obj);

        // ---- Gradient fill ----
        const grad = (obj.data && obj.data.gradient) || {};
        document.getElementById("propGradientEnable").checked = !!grad.enabled;
        document.getElementById("propGradientColor1").value =
            grad.color1 || "#ff5f6d";
        document.getElementById("propGradientColor2").value =
            grad.color2 || "#ffc371";
        document.getElementById("propGradientAngle").value =
            typeof grad.angle === "number" ? grad.angle : 0;
        document.getElementById("propGradientAngleValue").textContent =
            (typeof grad.angle === "number" ? grad.angle : 0) + "°";
        document.getElementById("propGradientColor1").disabled = !grad.enabled;
        document.getElementById("propGradientColor2").disabled = !grad.enabled;
        document.getElementById("propGradientAngle").disabled = !grad.enabled;

        // ---- Text background + radius ----
        const hasTextBg = !!obj.backgroundColor;
        document.getElementById("propTextBgEnable").checked = hasTextBg;
        document.getElementById("propTextBgColor").value = hasTextBg
            ? obj.backgroundColor
            : "#ffff00";
        document.getElementById("propTextBgColor").disabled = !hasTextBg;
        const textBgRadius = clampBorderRadiusPercent(
            (obj.data && obj.data.bgRadius) || 0,
        );
        document.getElementById("propTextBgRadius").value = textBgRadius;
        document.getElementById("propTextBgRadiusValue").textContent =
            textBgRadius + "%";
        document.getElementById("propTextBgRadius").disabled = !hasTextBg;
    }

    if (isImage) {
        const radiusPercent = clampBorderRadiusPercent(
            (obj.data && obj.data.borderRadius) || 0,
        );
        document.getElementById("propBorderRadius").value = radiusPercent;
        document.getElementById("propBorderRadiusValue").textContent =
            radiusPercent + "%";

        const hasBg = !!obj.backgroundColor;
        document.getElementById("propBgColorEnable").checked = hasBg;
        document.getElementById("propBgColor").value = hasBg
            ? obj.backgroundColor
            : "#ffffff";
        document.getElementById("propBgColor").disabled = !hasBg;
    }

    // ---- Stroke (applies to both text and images) ----
    // `data.strokeWidth` is the "desired visible width" the admin set; fall
    // back to the raw fabric strokeWidth for designs saved before this update
    // (those are all effectively 'center' position, so no halving needed).
    const hasDataStroke = !!(
        obj.data &&
        typeof obj.data.strokeWidth === "number" &&
        obj.data.strokeWidth > 0
    );

    const hasStroke = hasDataStroke;
    const desiredStrokeWidth = hasDataStroke
        ? obj.data.strokeWidth
        : 0;

    const strokePosition = (obj.data && obj.data.strokePosition) || "center";
    document.getElementById("propStrokeEnable").checked = hasStroke;
    document.getElementById("propStrokeColor").value = obj.stroke || "#000000";
    document.getElementById("propStrokeWidth").value = hasStroke
        ? desiredStrokeWidth
        : 2;
    document.getElementById("propStrokePosition").value = strokePosition;

    document.getElementById("propStrokeColor").disabled = !hasStroke;
    document.getElementById("propStrokeWidth").disabled = !hasStroke;
    document.getElementById("propStrokePosition").disabled = !hasStroke;

    // ---- Shadow (applies to both text and images) ----
    const shadow = obj.shadow;
    document.getElementById("propShadowEnable").checked = !!shadow;
    document.getElementById("propShadowColor").value = shadow
        ? shadow.color
        : "#000000";
    document.getElementById("propShadowBlur").value = shadow ? shadow.blur : 4;
    document.getElementById("propShadowOffsetX").value = shadow
        ? shadow.offsetX
        : 2;
    document.getElementById("propShadowOffsetY").value = shadow
        ? shadow.offsetY
        : 2;
}

// Resizing a Textbox via its side handles changes `width` (unlike height,
// which Fabric derives purely from wrapped content) — keep the clip's width
// in sync whenever that happens, and refresh the warning indicator.
canvas.on("object:modified", (e) => {
    const obj = e.target;
    if (
        isTextObject(obj) &&
        obj.data &&
        (obj.data.clipEnabled || obj.data.clipWidthEnabled)
    ) {
        // A drag-resize is the user deliberately changing the box's own
        // footprint — treat the new obj.width as the new source of truth and
        // push it into boxWidth, rather than applyTextClip's usual direction
        // of forcing obj.width back down to the (now stale) boxWidth. Without
        // this, dragging a width-clipped box wider would silently snap it
        // back to the old boxWidth on every modification.
        if (obj.data.clipWidthEnabled) {
            obj.data.boxWidth = Math.ceil(obj.width || 0);
            const boxWidthInput = document.getElementById("propBoxWidth");
            if (boxWidthInput && canvas.getActiveObject() === obj)
                boxWidthInput.value = obj.data.boxWidth;
        }
        applyTextClip(obj);
        canvas.renderAll();
        if (canvas.getActiveObject() === obj) {
            updateClipWarning(obj);
            updateClipWidthWarning(obj);
        }
    }
});

canvas.on("selection:created", (e) => syncPropsPanelFromObject(e.selected[0]));
canvas.on("selection:updated", (e) => syncPropsPanelFromObject(e.selected[0]));
canvas.on("selection:cleared", () => syncPropsPanelFromObject(null));

// Text-specific updates (font/color, etc.) — only apply to text objects
function updateActiveText(props) {
    const obj = canvas.getActiveObject();
    if (!isTextObject(obj)) return;
    obj.set(props);
    canvas.renderAll();
    updateClipWarning(obj);
    pushHistoryDebounced();
}

// Generic update (stroke/shadow) — applies to both text and image objects
function updateActiveObject(props) {
    const obj = canvas.getActiveObject();
    if (!isStyleable(obj)) return;
    obj.set(props);
    canvas.renderAll();
    pushHistoryDebounced();
}

document
    .getElementById("propFontFamily")
    .addEventListener("change", (e) =>
        updateActiveText({ fontFamily: e.target.value }),
    );
document
    .getElementById("propFontSize")
    .addEventListener("input", (e) =>
        updateActiveText({ fontSize: parseInt(e.target.value, 10) || 16 }),
    );
document
    .getElementById("propColor")
    .addEventListener("input", (e) => updateActiveText({ fill: e.target.value }));

document.getElementById("propBold").addEventListener("click", (e) => {
    const obj = canvas.getActiveObject();
    if (!obj) return;
    const newWeight = obj.fontWeight === "bold" ? "normal" : "bold";
    updateActiveText({ fontWeight: newWeight });
    e.currentTarget.classList.toggle("active", newWeight === "bold");
});
document.getElementById("propItalic").addEventListener("click", (e) => {
    const obj = canvas.getActiveObject();
    if (!obj) return;
    const newStyle = obj.fontStyle === "italic" ? "normal" : "italic";
    updateActiveText({ fontStyle: newStyle });
    e.currentTarget.classList.toggle("active", newStyle === "italic");
});
document.getElementById("propUnderline").addEventListener("click", (e) => {
    const obj = canvas.getActiveObject();
    if (!obj) return;
    const newUnderline = !obj.underline;
    updateActiveText({ underline: newUnderline });
    e.currentTarget.classList.toggle("active", newUnderline);
});
document.querySelectorAll("[data-align]").forEach((btn) => {
    btn.addEventListener("click", (e) =>
        updateActiveText({ textAlign: e.currentTarget.dataset.align }),
    );
});

// ---- Text Case ----------------------------------------------------------
function applyTextCaseFromPanel() {
    const obj = canvas.getActiveObject();
    if (!isTextObject(obj)) return;
    if (!obj.data) obj.data = {};
    const caseType = document.getElementById("propTextCase").value;
    obj.data.textCase = caseType;

    if (obj.data.type === "static-text") {
        // Always re-derive from the untouched baseText so switching case never compounds.
        if (typeof obj.data.baseText !== "string") obj.data.baseText = obj.text;
        obj.set("text", applyTextCase(obj.data.baseText, caseType));
        enforceMaxLines(obj, obj.data.maxLines || 0);
    }
    // Variable Text: the canvas preview intentionally keeps showing the plain
    // label — the case transform is applied to the real student value at
    // print time instead (see render-id-cards-batch.js).

    canvas.renderAll();
    updateLineCountIndicator(obj);
    updateClipWarning(obj);
    pushHistoryDebounced();
}
document
    .getElementById("propTextCase")
    .addEventListener("change", applyTextCaseFromPanel);

// ---- Line Height ----------------------------------------------------------
document.getElementById("propLineHeight").addEventListener("input", (e) => {
    const lineHeight = parseFloat(e.target.value) || 1.16;
    document.getElementById("propLineHeightValue").textContent =
        lineHeight.toFixed(2);
    updateActiveText({ lineHeight });
    const obj = canvas.getActiveObject();
    if (obj) updateLineCountIndicator(obj);
});

// ---- Max Lines --------------------------------------------------------------
function applyMaxLinesFromPanel() {
    const obj = canvas.getActiveObject();
    if (!isTextObject(obj)) return;
    if (!obj.data) obj.data = {};
    const maxLines = Math.max(
        0,
        parseInt(document.getElementById("propMaxLines").value, 10) || 0,
    );
    obj.data.maxLines = maxLines;

    if (obj.data.type === "static-text") {
        // Re-derive from baseText (via the current case setting) so raising the
        // limit back up restores text instead of staying permanently truncated.
        if (typeof obj.data.baseText !== "string") obj.data.baseText = obj.text;
        obj.set(
            "text",
            applyTextCase(obj.data.baseText, obj.data.textCase || "none"),
        );
        enforceMaxLines(obj, maxLines);
    }
    // Variable Text: can't preview real student data length at design time —
    // the cap is enforced on the real value at print time, see the indicator note.

    canvas.renderAll();
    updateLineCountIndicator(obj);
    updateClipWarning(obj);
    pushHistoryDebounced();
}
document
    .getElementById("propMaxLines")
    .addEventListener("input", applyMaxLinesFromPanel);

// ---- Fixed-Height Clip (overflow safety net) -------------------------------
function applyClipSettingsFromPanel() {
    const obj = canvas.getActiveObject();
    if (!isTextObject(obj)) return;
    if (!obj.data) obj.data = {};

    const enabled = document.getElementById("propClipEnable").checked;
    let boxHeight = parseInt(document.getElementById("propBoxHeight").value, 10);
    if (isNaN(boxHeight) || boxHeight <= 0)
        boxHeight = Math.ceil(obj.height || 30);

    obj.data.clipEnabled = enabled;
    obj.data.boxHeight = boxHeight;
    document.getElementById("propBoxHeight").value = boxHeight;
    document.getElementById("propBoxHeight").disabled = !enabled;
    document.getElementById("btnUseCurrentHeight").disabled = !enabled;

    applyTextClip(obj);
    canvas.renderAll();
    updateClipWarning(obj);
    pushHistoryDebounced();
}
document
    .getElementById("propClipEnable")
    .addEventListener("change", applyClipSettingsFromPanel);
document
    .getElementById("propBoxHeight")
    .addEventListener("input", applyClipSettingsFromPanel);
document.getElementById("btnUseCurrentHeight").addEventListener("click", () => {
    const obj = canvas.getActiveObject();
    if (!isTextObject(obj)) return;
    if (typeof obj._initDimensions === "function") obj._initDimensions();
    document.getElementById("propBoxHeight").value = Math.ceil(obj.height || 30);
    applyClipSettingsFromPanel();
});

// ---- Fixed-Width Clip (overflow safety net, horizontal) --------------------
function applyClipWidthSettingsFromPanel() {
    const obj = canvas.getActiveObject();
    if (!isTextObject(obj)) return;
    if (!obj.data) obj.data = {};

    const enabled = document.getElementById("propClipWidthEnable").checked;
    let boxWidth = parseInt(document.getElementById("propBoxWidth").value, 10);
    if (isNaN(boxWidth) || boxWidth <= 0) boxWidth = Math.ceil(obj.width || 30);

    obj.data.clipWidthEnabled = enabled;
    obj.data.boxWidth = boxWidth;
    document.getElementById("propBoxWidth").value = boxWidth;
    document.getElementById("propBoxWidth").disabled = !enabled;
    document.getElementById("btnUseCurrentWidth").disabled = !enabled;

    applyTextClip(obj);
    canvas.renderAll();
    updateClipWidthWarning(obj);
    pushHistoryDebounced();
}
document
    .getElementById("propClipWidthEnable")
    .addEventListener("change", applyClipWidthSettingsFromPanel);
document
    .getElementById("propBoxWidth")
    .addEventListener("input", applyClipWidthSettingsFromPanel);
document.getElementById("btnUseCurrentWidth").addEventListener("click", () => {
    const obj = canvas.getActiveObject();
    if (!isTextObject(obj)) return;
    if (typeof obj._initDimensions === "function") obj._initDimensions();
    document.getElementById("propBoxWidth").value = Math.ceil(obj.width || 30);
    applyClipWidthSettingsFromPanel();
});

// ---- Line-count indicator (live feedback under the Max Lines field) --------
function updateLineCountIndicator(obj) {
    const el = document.getElementById("propLineCountIndicator");
    if (!el || !isTextObject(obj)) return;
    const maxLines = (obj.data && obj.data.maxLines) || 0;

    if (obj.data && obj.data.type === "dynamic-text") {
        el.textContent =
            maxLines > 0
                ? `Real student data will be shortened with "…" to fit ${maxLines} line(s) at print time.`
                : "No limit — long real student data may wrap onto extra lines.";
        el.style.color = "#6c757d";
        return;
    }

    if (typeof obj._initDimensions === "function") obj._initDimensions();
    const currentLines = (obj._textLines && obj._textLines.length) || 1;
    if (maxLines > 0) {
        el.textContent = `Current: ${currentLines} line(s) / max ${maxLines}`;
        el.style.color = currentLines > maxLines ? "#dc3545" : "#6c757d";
    } else {
        el.textContent = `Current: ${currentLines} line(s) (no limit)`;
        el.style.color = "#6c757d";
    }
}

// ---- Image: Border Radius --------------------------------------------------
// Stored as a 0–50 CSS-style percentage. IMPORTANT: this must match CSS's
// `border-radius: N%` behavior, which computes the horizontal radius as a
// percentage of the box WIDTH and the vertical radius as a percentage of the
// box HEIGHT *independently* — at 50% that gives a full ellipse (a circle
// when width == height). The previous implementation used a single radius
// derived from min(width, height), which under-rounds non-square boxes (a
// rounded rectangle instead of a true ellipse). rx/ry below are now computed
// separately per axis to match CSS exactly.
// ⚠️ render-id-cards-batch.js recomputes this same clip after swapping in the
// real photo (different pixel size) — keep the rx/ry formula in sync there.
function clampBorderRadiusPercent(v) {
    v = parseFloat(v);
    if (isNaN(v)) return 0;
    return Math.max(0, Math.min(50, v));
}

/**
 * Builds the clip Rect for an image, given its own (unscaled) box size.
 * `extraPx` inflates the box outward on all sides while keeping the corner
 * rounding concentric — used only for an "outside" stroke halo on a rounded
 * image, so the halo isn't cut off at the original (un-inflated) rounded edge.
 */
function buildRoundedClipRect(w, h, radiusPercent, extraPx) {
    extraPx = extraPx || 0;
    const rx = (radiusPercent / 100) * (w / 2);
    const ry = (radiusPercent / 100) * (h / 2);
    if (rx <= 0 && ry <= 0 && extraPx <= 0) return null;
    return new fabric.Rect({
        width: w + 2 * extraPx,
        height: h + 2 * extraPx,
        rx: rx > 0 ? rx + extraPx : 0,
        ry: ry > 0 ? ry + extraPx : 0,
        originX: "center",
        originY: "center",
    });
}

/**
 * Traces a CSS-style rounded-rect path (independent rx/ry per axis) on ctx,
 * centered at the current origin. Same bezier algorithm Fabric's own
 * fabric.Rect uses internally — i.e. the exact same shape as the
 * border-radius clipPath — so a stroke traced with this follows the clip's
 * curve instead of getting cut off at the corners.
 */
function traceRoundedRectPath(ctx, w, h, rx, ry) {
    const x = -w / 2,
        y = -h / 2;
    const isRounded = rx > 0 || ry > 0;
    const k = 1 - 0.5522847498; // standard ellipse bezier constant
    ctx.beginPath();
    ctx.moveTo(x + rx, y);
    ctx.lineTo(x + w - rx, y);
    if (isRounded)
        ctx.bezierCurveTo(x + w - k * rx, y, x + w, y + k * ry, x + w, y + ry);
    ctx.lineTo(x + w, y + h - ry);
    if (isRounded)
        ctx.bezierCurveTo(
            x + w,
            y + h - k * ry,
            x + w - k * rx,
            y + h,
            x + w - rx,
            y + h,
        );
    ctx.lineTo(x + rx, y + h);
    if (isRounded)
        ctx.bezierCurveTo(x + k * rx, y + h, x, y + h - k * ry, x, y + h - ry);
    ctx.lineTo(x, y + ry);
    if (isRounded) ctx.bezierCurveTo(x, y + k * ry, x + k * rx, y, x + rx, y);
    ctx.closePath();
}

// ---- Rounded stroke for images (border-radius aware) ----------------------
// fabric.Image._renderStroke always strokes a PLAIN rectangle, regardless of
// clipPath — the border-radius clip only hides pixels, it never changes that
// path. So a rounded image's stroke got chopped off hard at each corner
// instead of curving with the radius. This overrides the stroke path to
// match the same rounded rect used for the border-radius clip.
// ⚠️ Duplicated in render-id-cards-batch.js — keep both copies in sync.
(function patchRoundedImageStroke() {
    const originalRenderStroke = fabric.Image.prototype._renderStroke;
    fabric.Image.prototype._renderStroke = function (ctx) {
        if (!this.stroke || this.strokeWidth === 0) return;
        const radiusPercent = (this.data && this.data.borderRadius) || 0;
        if (radiusPercent <= 0) {
            originalRenderStroke.call(this, ctx);
            return;
        }
        const w = this.width,
            h = this.height;
        const rx = Math.min((radiusPercent / 100) * (w / 2), w / 2);
        const ry = Math.min((radiusPercent / 100) * (h / 2), h / 2);
        ctx.save();
        if (
            this.shadow &&
            !this.shadow.affectStroke &&
            typeof this._removeShadow === "function"
        ) {
            this._removeShadow(ctx);
        }
        ctx.lineWidth = this.strokeWidth;
        ctx.strokeStyle = this.stroke;
        traceRoundedRectPath(ctx, w, h, rx, ry);
        ctx.stroke();
        ctx.restore();
    };
})();

/**
 * Rebuilds an image object's clipPath from its stored border-radius
 * percentage AND its stroke position (data.strokePosition):
 *  - 'outside' stroke needs the clip inflated so the stroke halo painted
 *    beyond the image edges isn't clipped away.
 *  - 'inside' stroke reuses the plain (non-inflated) rounded rect, which
 *    also happens to be exactly the clip needed to trim the outer half of
 *    the doubled stroke width down to an inside-only look.
 */
function applyImageClipPath(obj) {
    if (!isImageObject(obj)) return;
    const percent = clampBorderRadiusPercent(
        (obj.data && obj.data.borderRadius) || 0,
    );
    const w = obj.width || 0;
    const h = obj.height || 0;
    const position = (obj.data && obj.data.strokePosition) || "center";
    const strokeDesired = (obj.data && obj.data.strokeWidth) || 0;
    const extraPx =
        position === "outside" && strokeDesired > 0 ? strokeDesired : 0;

    obj.clipPath = buildRoundedClipRect(w, h, percent, extraPx);
    obj.dirty = true;
}

document.getElementById("propBorderRadius").addEventListener("input", (e) => {
    const obj = canvas.getActiveObject();
    if (!isImageObject(obj)) return;
    const percent = clampBorderRadiusPercent(e.target.value);
    if (!obj.data) obj.data = {};
    obj.data.borderRadius = percent;
    document.getElementById("propBorderRadiusValue").textContent = percent + "%";
    applyImageClipPath(obj);
    canvas.renderAll();
    pushHistoryDebounced();
});

// ---- Image: Background Color -----------------------------------------------
// Uses Fabric's native `backgroundColor` property, which fills the object's
// bounding box behind it — respecting the clipPath above, so rounded corners
// apply to the background fill as well.
function applyImageBackgroundFromPanel() {
    const obj = canvas.getActiveObject();
    if (!isImageObject(obj)) return;
    const enabled = document.getElementById("propBgColorEnable").checked;
    document.getElementById("propBgColor").disabled = !enabled;
    const color = document.getElementById("propBgColor").value;
    obj.set({ backgroundColor: enabled ? color : "" });
    canvas.renderAll();
    pushHistoryDebounced();
}
["propBgColorEnable", "propBgColor"].forEach((id) => {
    document
        .getElementById(id)
        .addEventListener("input", applyImageBackgroundFromPanel);
    document
        .getElementById(id)
        .addEventListener("change", applyImageBackgroundFromPanel);
});

// ---- Stroke (enable/disable toggle, Center/Inside/Outside position, applies to both text and images) ----
//
// Canvas strokes are always painted CENTERED on the path (half inside, half
// outside) — there's no native "inside"/"outside" option. To fake it:
//  - OUTSIDE: the fabric strokeWidth is doubled and `paintFirst` is set to
//    'stroke', so the stroke is painted first and the fill/image is painted
//    on top afterwards, covering (masking) the inner half — only the outer
//    half remains visible. This is exact, per-glyph for text and pixel-exact
//    for images, since the same shape is used for both paint passes.
//  - INSIDE: the fabric strokeWidth is also doubled, but instead the OUTER
//    half is removed with a clipPath matching the object's own boundary.
//    For images this is exact (the clip is the same rounded rect used for
//    border-radius). For TEXT it's an approximation: the clip is the text's
//    bounding box, not each individual glyph's outline (canvas text has no
//    per-glyph clip without converting letters to paths), so a very thick
//    inside stroke on text can bleed slightly into the space between
//    letters. Outside and Center are exact for text.
function applyStrokeStyle(obj) {
    if (!isStyleable(obj)) return;
    if (!obj.data) obj.data = {};
    const desired = obj.data.strokeWidth || 0;
    const position = obj.data.strokePosition || "center";

    if (!desired || desired <= 0) {
        obj.set({ strokeWidth: 0, paintFirst: "fill" });
    } else if (position === "outside") {
        obj.set({ strokeWidth: desired * 2, paintFirst: "stroke" });
    } else if (position === "inside") {
        obj.set({ strokeWidth: desired * 2, paintFirst: "fill" });
    } else {
        obj.set({ strokeWidth: desired, paintFirst: "fill" });
    }

    if (isImageObject(obj)) {
        applyImageClipPath(obj); // radius-aware, and stroke-position-aware (inflates for 'outside')
    } else if (isTextObject(obj)) {
        obj.clipPath =
            position === "inside" && desired > 0
                ? new fabric.Rect({
                    width: obj.width,
                    height: obj.height,
                    originX: "center",
                    originY: "center",
                })
                : null;
    }
    obj.dirty = true;
}

function applyStrokeFromPanel() {
    const obj = canvas.getActiveObject();
    if (!isStyleable(obj)) return;
    if (!obj.data) obj.data = {};
    const enabled = document.getElementById("propStrokeEnable").checked;
    const positionSelect = document.getElementById("propStrokePosition");
    positionSelect.disabled = !enabled;
    document.getElementById("propStrokeColor").disabled = !enabled;
    document.getElementById("propStrokeWidth").disabled = !enabled;

    if (!enabled) {
        obj.data.strokeWidth = 0;
        applyStrokeStyle(obj);
    } else {
        const color = document.getElementById("propStrokeColor").value;
        const width =
            parseFloat(document.getElementById("propStrokeWidth").value) || 2;
        obj.data.strokeWidth = width;
        obj.data.strokePosition = positionSelect.value;
        obj.set({ stroke: color });
        applyStrokeStyle(obj);
    }
    canvas.renderAll();
    pushHistoryDebounced();
}
[
    "propStrokeEnable",
    "propStrokeColor",
    "propStrokeWidth",
    "propStrokePosition",
].forEach((id) => {
    document.getElementById(id).addEventListener("input", applyStrokeFromPanel);
    document.getElementById(id).addEventListener("change", applyStrokeFromPanel);
});

// ---- Text: Gradient Fill (linear, 2 colors + angle) ------------------------
function buildTextGradient(obj, color1, color2, angleDeg) {
    const w = obj.width || 1;
    const h = obj.height || 1;
    const halfW = w / 2,
        halfH = h / 2;
    const rad = (angleDeg * Math.PI) / 180;
    const dx = Math.cos(rad),
        dy = Math.sin(rad);
    // Project a line through the center at the given angle out to the edge
    // of the bounding box (same idea as a CSS linear-gradient angle).
    const len = Math.abs(dx) * halfW + Math.abs(dy) * halfH;
    return new fabric.Gradient({
        type: "linear",
        coords: {
            x1: halfW - dx * len,
            y1: halfH - dy * len,
            x2: halfW + dx * len,
            y2: halfH + dy * len,
        },
        colorStops: [
            { offset: 0, color: color1 },
            { offset: 1, color: color2 },
        ],
    });
}

function applyGradientFromPanel() {
    const obj = canvas.getActiveObject();
    if (!isTextObject(obj)) return;
    if (!obj.data) obj.data = {};
    const enabled = document.getElementById("propGradientEnable").checked;
    document.getElementById("propColor").disabled = enabled;
    document.getElementById("propGradientColor1").disabled = !enabled;
    document.getElementById("propGradientColor2").disabled = !enabled;
    document.getElementById("propGradientAngle").disabled = !enabled;

    if (!enabled) {
        obj.data.gradient = { enabled: false };
        obj.set({ fill: document.getElementById("propColor").value });
    } else {
        const color1 = document.getElementById("propGradientColor1").value;
        const color2 = document.getElementById("propGradientColor2").value;
        const angle =
            parseFloat(document.getElementById("propGradientAngle").value) || 0;
        obj.data.gradient = { enabled: true, color1, color2, angle };
        obj.set({ fill: buildTextGradient(obj, color1, color2, angle) });
    }
    canvas.renderAll();
    pushHistoryDebounced();
}
[
    "propGradientEnable",
    "propGradientColor1",
    "propGradientColor2",
    "propGradientAngle",
].forEach((id) => {
    document.getElementById(id).addEventListener("input", applyGradientFromPanel);
    document
        .getElementById(id)
        .addEventListener("change", applyGradientFromPanel);
});
document.getElementById("propGradientAngle").addEventListener("input", (e) => {
    document.getElementById("propGradientAngleValue").textContent =
        e.target.value + "°";
});

// ---- Text: Background Color + Border Radius --------------------------------
// Uses Fabric's native `backgroundColor` (a flat fill behind the text box);
// the rounded-corner part comes from the _renderBackground patch above,
// driven by data.bgRadius (same 0–50% convention as the image border radius).
function applyTextBackgroundFromPanel() {
    const obj = canvas.getActiveObject();
    if (!isTextObject(obj)) return;
    if (!obj.data) obj.data = {};
    const enabled = document.getElementById("propTextBgEnable").checked;
    document.getElementById("propTextBgColor").disabled = !enabled;
    document.getElementById("propTextBgRadius").disabled = !enabled;

    const color = document.getElementById("propTextBgColor").value;
    const radiusPercent = clampBorderRadiusPercent(
        document.getElementById("propTextBgRadius").value,
    );
    obj.data.bgRadius = radiusPercent;
    document.getElementById("propTextBgRadiusValue").textContent =
        radiusPercent + "%";
    obj.set({ backgroundColor: enabled ? color : "" });
    obj.dirty = true;
    canvas.renderAll();
    pushHistoryDebounced();
}
["propTextBgEnable", "propTextBgColor", "propTextBgRadius"].forEach((id) => {
    document
        .getElementById(id)
        .addEventListener("input", applyTextBackgroundFromPanel);
    document
        .getElementById(id)
        .addEventListener("change", applyTextBackgroundFromPanel);
});

// ---- Shadow (enable/disable toggle, applies to both text and images) ----
function applyShadowFromPanel() {
    const enabled = document.getElementById("propShadowEnable").checked;
    if (!enabled) {
        updateActiveObject({ shadow: null });
        return;
    }
    const color = document.getElementById("propShadowColor").value;
    const blur = parseFloat(document.getElementById("propShadowBlur").value) || 0;
    const offsetX =
        parseFloat(document.getElementById("propShadowOffsetX").value) || 0;
    const offsetY =
        parseFloat(document.getElementById("propShadowOffsetY").value) || 0;
    updateActiveObject({
        shadow: new fabric.Shadow({ color, blur, offsetX, offsetY }),
    });
}
[
    "propShadowEnable",
    "propShadowColor",
    "propShadowBlur",
    "propShadowOffsetX",
    "propShadowOffsetY",
].forEach((id) => {
    document.getElementById(id).addEventListener("input", applyShadowFromPanel);
    document.getElementById(id).addEventListener("change", applyShadowFromPanel);
});

// ---- 5. UNDO / REDO HISTORY -------------------------------------------
let historyStack = [];
let historyIndex = -1;
let isRestoringHistory = false;
let pushHistoryTimeout = null;

function snapshotCanvas() {
    return JSON.stringify(canvas.toJSON(["data", "crossOrigin"]));
}

function pushHistory() {
    if (isRestoringHistory) return;
    const snap = snapshotCanvas();
    if (historyStack[historyIndex] === snap) return; // avoid duplicate entries when nothing changed
    historyStack = historyStack.slice(0, historyIndex + 1);
    historyStack.push(snap);
    if (historyStack.length > HISTORY_LIMIT) historyStack.shift();
    historyIndex = historyStack.length - 1;
}

function pushHistoryDebounced() {
    clearTimeout(pushHistoryTimeout);
    pushHistoryTimeout = setTimeout(pushHistory, 350);
}

function restoreHistory(index) {
    if (index < 0 || index >= historyStack.length) return;
    isRestoringHistory = true;
    canvas.loadFromJSON(historyStack[index], () => {
        canvas.renderAll();
        isRestoringHistory = false;
        refreshLayersPanel();
        syncPropsPanelFromObject(canvas.getActiveObject());
    });
}

function undo() {
    if (historyIndex <= 0) return;
    historyIndex -= 1;
    restoreHistory(historyIndex);
}
function redo() {
    if (historyIndex >= historyStack.length - 1) return;
    historyIndex += 1;
    restoreHistory(historyIndex);
}

canvas.on("object:modified", (e) => {
    const obj = e.target;
    // Resizing a static text box can change how many lines it wraps to —
    // re-enforce the cap so it can't silently start overflowing the card.
    if (obj && isTextObject(obj) && obj.data && obj.data.type === "static-text") {
        enforceMaxLines(obj, obj.data.maxLines || 0);
        canvas.renderAll();
        updateLineCountIndicator(obj);
    }
    pushHistory();
});
canvas.on("object:added", () => pushHistoryDebounced());
canvas.on("object:removed", () => pushHistory());

// Live line-count feedback while the admin is typing (no truncation mid-typing —
// that would be disruptive; the cap is only (re)applied once editing finishes).
canvas.on("text:changed", (e) => {
    const obj = e.target;

    if (!obj || !isTextObject(obj)) return;

    if (typeof obj.initDimensions === "function") {
        obj.initDimensions();
    }

    obj.setCoords();

    if (obj.data && (obj.data.clipEnabled || obj.data.clipWidthEnabled)) {
        applyTextClip(obj);
    }

    canvas.renderAll();
    updateLineCountIndicator(obj);
});

// Once the admin finishes typing static text, lock in the new baseText, then
// re-apply the Text Case and Max Lines settings on top of it.
canvas.on("text:editing:exited", (e) => {
    const obj = e.target;
    if (
        !obj ||
        !isTextObject(obj) ||
        !obj.data ||
        obj.data.type !== "static-text"
    )
        return;
    obj.data.baseText = obj.text;
    if (obj.data.textCase && obj.data.textCase !== "none") {
        obj.set("text", applyTextCase(obj.data.baseText, obj.data.textCase));
    }
    enforceMaxLines(obj, obj.data.maxLines || 0);
    canvas.renderAll();
    refreshLayersPanel();
    updateLineCountIndicator(obj);
    pushHistory();
});

document.getElementById("btnUndo").addEventListener("click", undo);
document.getElementById("btnRedo").addEventListener("click", redo);

// ---- 6. LAYERS PANEL (Photoshop-style) -----------------------------
let draggedLayerObj = null;

function layerLabelForObject(obj) {
    const type = obj.data && obj.data.type;
    if (type === "dynamic-text") return obj.data.variable || "Variable Text";
    if (type === "static-text") return (obj.text || "Static Text").slice(0, 18);
    if (type === "school-logo") return "School Logo";
    if (type === "student-photo") return "Student Photo";
    if (type === "qr-code") return "QR Code";
    if (type === "custom-image") return "Custom Image";
    return obj.type;
}
function layerIconForObject(obj) {
    const type = obj.data && obj.data.type;
    if (type === "dynamic-text" || type === "static-text") return "fa-font";
    if (type === "qr-code") return "fa-qrcode";
    return "fa-image";
}

function refreshLayersPanel() {
    const list = document.getElementById("layersList");
    if (!list) return;
    list.innerHTML = "";

    const objects = canvas.getObjects().slice().reverse(); // top layer first (like Photoshop)
    const activeObj = canvas.getActiveObject();

    objects.forEach((obj) => {
        const isLocked = obj.selectable === false;
        const li = document.createElement("div");
        li.className =
            "layer-item" +
            (obj === activeObj ? " active" : "") +
            (isLocked ? " is-locked" : "");
        li.draggable = true;

        li.innerHTML = `
            <span class="layer-icon"><i class="fas ${layerIconForObject(obj)}"></i></span>
            <span class="layer-name">${layerLabelForObject(obj)}</span>
            <button type="button" class="layer-visibility-btn" title="Show/Hide">
                <i class="fas ${obj.visible === false ? "fa-eye-slash" : "fa-eye"}"></i>
            </button>
            <button type="button" class="layer-lock-btn${isLocked ? " locked" : ""}" title="Lock/Unlock">
                <i class="fas ${isLocked ? "fa-lock" : "fa-unlock"}"></i>
            </button>
        `;

        li.addEventListener("click", (e) => {
            if (
                e.target.closest(".layer-visibility-btn") ||
                e.target.closest(".layer-lock-btn")
            )
                return;
            canvas.setActiveObject(obj);
            canvas.renderAll();
        });

        li.querySelector(".layer-visibility-btn").addEventListener("click", (e) => {
            e.stopPropagation();
            obj.visible = obj.visible === false;
            canvas.renderAll();
            refreshLayersPanel();
            pushHistory();
        });
        li.querySelector(".layer-lock-btn").addEventListener("click", (e) => {
            e.stopPropagation();
            const currentlyLocked = obj.selectable === false;
            obj.selectable = currentlyLocked;
            obj.evented = currentlyLocked;
            canvas.renderAll();
            refreshLayersPanel();
        });

        // ---- Drag-and-drop layer reordering ----
        li.addEventListener("dragstart", () => {
            draggedLayerObj = obj;
            li.classList.add("dragging");
        });
        li.addEventListener("dragend", () => {
            li.classList.remove("dragging");
            draggedLayerObj = null;
        });
        li.addEventListener("dragover", (e) => e.preventDefault());
        li.addEventListener("drop", (e) => {
            e.preventDefault();
            if (!draggedLayerObj || draggedLayerObj === obj) return;
            const targetIndex = canvas.getObjects().indexOf(obj);
            canvas.moveTo(draggedLayerObj, targetIndex);
            canvas.renderAll();
            refreshLayersPanel();
            pushHistory();
        });

        list.appendChild(li);
    });
}

// ---- 7. KEYBOARD SHORTCUTS ---------------------------------------------
document.addEventListener("keydown", (e) => {
    const activeEl = document.activeElement;
    const activeObj = canvas.getActiveObject();
    const isEditingText = activeObj && activeObj.isEditing;
    const isTypingInField =
        ["INPUT", "TEXTAREA", "SELECT"].includes(activeEl.tagName) || isEditingText;
    const ctrlOrCmd = e.ctrlKey || e.metaKey;

    // ---- Undo / Redo (works even with an input field focused, except while editing canvas text) ----
    if (
        ctrlOrCmd &&
        !e.shiftKey &&
        e.key.toLowerCase() === "z" &&
        !isEditingText
    ) {
        e.preventDefault();
        undo();
        return;
    }
    if (
        ctrlOrCmd &&
        (e.key.toLowerCase() === "y" ||
            (e.shiftKey && e.key.toLowerCase() === "z")) &&
        !isEditingText
    ) {
        e.preventDefault();
        redo();
        return;
    }

    if (isTypingInField) return; // other shortcuts stay disabled while typing/editing text

    // ---- Delete ----
    if ((e.key === "Delete" || e.key === "Backspace") && activeObj) {
        e.preventDefault();
        canvas.remove(activeObj);
        canvas.discardActiveObject();
        canvas.renderAll();
        refreshLayersPanel();
        pushHistory();
        return;
    }

    // ---- Arrow-key move ----
    if (
        ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key) &&
        activeObj
    ) {
        e.preventDefault();
        const step = e.shiftKey ? ARROW_STEP_SHIFT : ARROW_STEP;
        if (e.key === "ArrowUp") activeObj.top -= step;
        if (e.key === "ArrowDown") activeObj.top += step;
        if (e.key === "ArrowLeft") activeObj.left -= step;
        if (e.key === "ArrowRight") activeObj.left += step;
        activeObj.setCoords();
        canvas.renderAll();
        pushHistoryDebounced();
        return;
    }

    // ---- Layer order shortcuts (Photoshop style: ] forward, [ backward) ----
    if (activeObj && (e.key === "]" || e.key === "[")) {
        e.preventDefault();
        if (e.key === "]") {
            ctrlOrCmd
                ? canvas.bringToFront(activeObj)
                : canvas.bringForward(activeObj);
        } else {
            ctrlOrCmd
                ? canvas.sendToBack(activeObj)
                : canvas.sendBackwards(activeObj);
        }
        canvas.renderAll();
        refreshLayersPanel();
        pushHistory();
        return;
    }

    // ---- Duplicate ----
    if (ctrlOrCmd && e.key.toLowerCase() === "d" && activeObj) {
        e.preventDefault();
        duplicateObject(activeObj);
        return;
    }

    // ---- Copy style / Paste style ----
    if (ctrlOrCmd && e.key.toLowerCase() === "c" && activeObj) {
        e.preventDefault();
        copyStyleFromObject(activeObj);
        return;
    }
    if (ctrlOrCmd && e.key.toLowerCase() === "v" && activeObj) {
        e.preventDefault();
        pasteStyleToObject(activeObj);
        return;
    }
});

// ---- 8. SAVE DESIGN --------------------------------------------------------
const btnSaveDesign = document.getElementById("btnSaveDesign");
// Cache the button's original markup once at load time so it can be restored
// exactly (icon + label) after saving, instead of hardcoding it a second time.
const btnSaveDesignDefaultHTML = btnSaveDesign.innerHTML;

btnSaveDesign.addEventListener("click", async () => {
    // 'data' must be included or the dynamic-text/variable tags (and image border-radius
    // settings, which live in data.borderRadius) will be lost.
    // 'crossOrigin' is also saved — otherwise cross-origin images (logo/photo/QR) can taint
    // the offscreen canvas during batch printing and make toDataURL() fail (this was the
    // original cause of batch generation failing on designs with photos/QR codes).
    const designJson = canvas.toJSON(["data", "crossOrigin"]);

    // Always save the canvas's real (unscaled) dimensions too — needed at render time
    const payload = {
        template_name: "design-1",
        canvas_width: CARD_WIDTH_PX,
        canvas_height: CARD_HEIGHT_PX,
        design_json: designJson,
    };

    // Enter loading state: disable the button (prevents double-submit while the
    // request is in flight) and swap the label for a Bootstrap spinner.
    btnSaveDesign.disabled = true;
    btnSaveDesign.innerHTML =
        '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Saving...';

    try {
        const res = await fetch(SAVE_DESIGN_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (data.success) {
            showSuccessAlert(data.message, "Saved!");
        } else {
            showErrorAlert(data.message, "Error");
        }
    } catch (err) {
        showErrorAlert(
            "An error occurred while saving the design: " + err.message,
            "System Error",
        );
    } finally {
        // Always restore, whether save succeeded, failed, or threw a network error.
        btnSaveDesign.disabled = false;
        btnSaveDesign.innerHTML = btnSaveDesignDefaultHTML;
    }
});