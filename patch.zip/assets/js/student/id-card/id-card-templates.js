/* Named template library for the Fabric editor. */
let templateLibrary = TEMPLATE_LIBRARY;
let currentTemplateId = Number(CURRENT_TEMPLATE.id);
let templateBusy = false;
let templateCsrfToken = TEMPLATE_CSRF;
let cleanTemplateSnapshot = null;
const templateSelect = document.getElementById('templateSelect');
const templateName = document.getElementById('templateName');
templateName.value = CURRENT_TEMPLATE.name;

function templateSnapshot() {
    flushCurrentSide();
    return JSON.stringify({name: templateName.value.trim(), width: CARD_WIDTH_PX, height: CARD_HEIGHT_PX,
        hasBack: hasBackSide, front: sideDesigns.front, back: sideDesigns.back});
}
function markTemplateClean() { cleanTemplateSnapshot = templateSnapshot(); }
function templateIsDirty() { return cleanTemplateSnapshot !== null && cleanTemplateSnapshot !== templateSnapshot(); }
function refreshTemplateLibrary() {
    templateSelect.replaceChildren(new Option('New / unsaved template', '0'));
    templateLibrary.forEach(t => templateSelect.add(new Option(t.template_name + (Number(t.is_active) ? ' — used for printing' : ''), String(t.id))));
    templateSelect.value = String(currentTemplateId);
    const active = templateLibrary.find(t => Number(t.is_active));
    document.getElementById('templateStatus').textContent = active ? 'Printing template: ' + active.template_name : 'Save your first named template to use it for printing.';
    document.getElementById('btnActivateTemplate').disabled = !currentTemplateId || templateBusy;
}
function setTemplateBusy(busy) {
    templateBusy = busy;
    ['templateSelect', 'templateName', 'btnNewTemplate', 'btnSaveTemplateCopy', 'btnSaveDesign', 'btnActivateTemplate', 'btnUndo', 'btnRedo'].forEach(id => document.getElementById(id).disabled = busy);
    document.querySelectorAll('.builder-sidebar, .builder-props, #sideTabs').forEach(el => el.inert = busy);
    if (busy) showLoading(); else hideLoading();
    refreshTemplateLibrary();
}
async function templateRequest(payloadOrId, canRefreshCsrf = true) {
    const get = typeof payloadOrId === 'number';
    const response = await fetch(SAVE_DESIGN_URL + (get ? '?id=' + payloadOrId : ''), get ? {cache: 'no-store', credentials: 'same-origin'} : {
        method: 'POST', credentials: 'same-origin', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': templateCsrfToken},
        body: JSON.stringify({...payloadOrId, csrf_token: templateCsrfToken})
    });
    const result = await response.json();
    // CSRF rejection happens before any write, so one retry cannot duplicate a save.
    if (!get && canRefreshCsrf && response.status === 403 && result.code === 'csrf_expired') {
        const refreshed = await fetch(SAVE_DESIGN_URL + '?action=csrf', {cache: 'no-store', credentials: 'same-origin'});
        const tokenResult = await refreshed.json();
        if (!refreshed.ok || !tokenResult.success || typeof tokenResult.csrf_token !== 'string' || !tokenResult.csrf_token) {
            throw new Error(tokenResult.message || 'Could not renew your form. Sign in again before saving.');
        }
        templateCsrfToken = tokenResult.csrf_token;
        return templateRequest(payloadOrId, false);
    }
    if (!result.success || !response.ok) throw new Error(result.message || 'Template request failed.');
    return result;
}
function canLeaveTemplate() {
    return !templateIsDirty() || window.confirm('This template has unsaved changes. Discard them and continue?');
}
async function loadTemplate(id) {
    if (templateBusy || isSwappingSide || isRestoringHistory || !canvasReady) { templateSelect.value = String(currentTemplateId); return; }
    if (!canLeaveTemplate()) { templateSelect.value = String(currentTemplateId); return; }
    setTemplateBusy(true);
    try {
        // Fetch before clearing, so failed requests preserve the current work.
        const result = id ? await templateRequest(id) : null;
        const t = result?.template;
        await IdCardFonts.loadDesigns([t?.design_json, t?.back_design_json]);
        if (result) templateLibrary = result.templates;
        clearTimeout(pushHistoryTimeout);
        isSwappingSide = true;
        const active = canvas.getActiveObject();
        if (active?.isEditing) active.exitEditing();
        canvas.discardActiveObject();
        canvas.clear(); canvas.backgroundColor = '#ffffff';
        currentSide = 'front';
        CARD_WIDTH_PX = t ? Number(t.canvas_width) : (typeof DOCUMENT_CONFIG !== 'undefined' ? DOCUMENT_CONFIG.defaultWidth : 550);
        CARD_HEIGHT_PX = t ? Number(t.canvas_height) : (typeof DOCUMENT_CONFIG !== 'undefined' ? DOCUMENT_CONFIG.defaultHeight : 850);
        hasBackSide = !!Number(t?.has_back || 0);
        sideDesigns.front = t?.design_json || null;
        sideDesigns.back = t?.back_design_json || null;
        currentTemplateId = t ? Number(t.id) : 0;
        templateName.value = t?.template_name || '';
        SIDES.forEach(side => { sideHistory[side] = {stack: [], index: -1}; });
        if (sideDesigns.front) await new Promise(resolve => canvas.loadFromJSON(sideDesigns.front, resolve));
        refitAllTextObjectsToLoadedFonts();
        fitCanvasToStage(); syncCardSetupPanel(); syncSideTabs(); syncPropsPanelFromObject(null);
        isSwappingSide = false;
        pushHistory(); markTemplateClean();
        if (!id) templateName.focus();
    } catch (error) {
        showErrorAlert(error.message, 'Could not open template');
    } finally {
        isSwappingSide = false; setTemplateBusy(false);
    }
}
async function saveNamedTemplate(asCopy = false) {
    if (templateBusy || isSwappingSide || isRestoringHistory || !canvasReady) return false;
    let name = templateName.value.trim();
    if (asCopy) {
        const entered = window.prompt('Name for the new template copy:', name ? name + ' (copy)' : '');
        if (entered === null) return false;
        name = entered.trim();
    }
    if (!name || Array.from(name).length > 100 || /\p{C}/u.test(name)) {
        showErrorAlert('Enter a template name of 1–100 characters.', 'Template name required'); templateName.focus(); return false;
    }
    flushCurrentSide();
    if (!sideDesigns.front?.objects?.length || (hasBackSide && !sideDesigns.back?.objects?.length)) {
        showErrorAlert('Add at least one element to the front and each enabled back side before saving.', 'Empty card side'); return false;
    }
    setTemplateBusy(true);
    try {
        const result = await templateRequest({action: 'save', template_id: asCopy ? 0 : currentTemplateId, template_name: name,
            canvas_width: CARD_WIDTH_PX, canvas_height: CARD_HEIGHT_PX, has_back: hasBackSide ? 1 : 0,
            design_json: sideDesigns.front, back_design_json: sideDesigns.back});
        currentTemplateId = Number(result.template_id); templateName.value = name;
        templateLibrary = result.templates; markTemplateClean();
        showSuccessAlert(result.message, 'Saved'); return true;
    } catch (error) {
        showErrorAlert(error.message, 'Could not save template'); return false;
    } finally { setTemplateBusy(false); }
}
templateSelect.addEventListener('change', () => loadTemplate(Number(templateSelect.value)));
document.getElementById('btnNewTemplate').addEventListener('click', () => loadTemplate(0));
document.getElementById('btnSaveDesign').addEventListener('click', () => saveNamedTemplate());
document.getElementById('btnSaveTemplateCopy').addEventListener('click', () => saveNamedTemplate(true));
document.getElementById('btnActivateTemplate').addEventListener('click', async () => {
    if (templateBusy || isSwappingSide || isRestoringHistory || !currentTemplateId) return;
    // Printing must use the design visible in the editor, including pending edits.
    if (templateIsDirty() && !(await saveNamedTemplate())) return;
    setTemplateBusy(true);
    try {
        const result = await templateRequest({action: 'activate', template_id: currentTemplateId});
        templateLibrary = result.templates; showSuccessAlert(result.message, 'Ready to print');
    } catch (error) { showErrorAlert(error.message, 'Could not select template'); }
    finally { setTemplateBusy(false); }
});
window.addEventListener('beforeunload', event => {
    if (templateBusy || templateIsDirty()) { event.preventDefault(); event.returnValue = ''; }
});
refreshTemplateLibrary();
if (canvasReady) markTemplateClean();
