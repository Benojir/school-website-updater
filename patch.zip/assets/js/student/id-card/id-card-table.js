/* Shared Fabric table object and model used by BOTH the editor and batch printer. */
(function (root) {
    'use strict';
    const clone = value => JSON.parse(JSON.stringify(value));
    const limit = (value, min, max, fallback) => Number.isFinite(Number(value)) ? Math.min(max, Math.max(min, Number(value))) : fallback;
    const defaults = {fontFamily: 'Poppins', fontSize: 18, fill: '#111111', background: '#ffffff',
        borderColor: '#333333', borderWidth: 1, borderStyle: 'solid', padding: 6, textAlign: 'left',
        verticalAlign: 'middle', fontWeight: 'normal', fontStyle: 'normal', underline: false};
    const blank = () => ({text: '', rowSpan: 1, colSpan: 1, style: {}});
    function create(rows = 3, cols = 2, width = 400) {
        rows = Math.round(limit(rows, 1, 20, 3)); cols = Math.round(limit(cols, 1, 12, 2));
        return {columns: Array(cols).fill(Math.max(20, width / cols)), rows: Array(rows).fill(48),
            style: clone(defaults), cells: Array.from({length: rows}, () => Array.from({length: cols}, blank))};
    }
    function normalize(input) {
        const model = create(input?.rows?.length, input?.columns?.length);
        // Splitting can introduce narrow grid tracks hidden inside spanning cells.
        // Preserve them on reload; the editor validates the visible cell dimensions.
        model.rows = model.rows.map((_, r) => limit(input?.rows?.[r], 0.01, 1000, 48));
        model.columns = model.columns.map((_, c) => limit(input?.columns?.[c], 0.01, 1500, 200));
        model.style = {...defaults, ...input?.style};
        model.cells = model.cells.map((row, r) => row.map((_, c) => {
            const cell = input?.cells?.[r]?.[c] || blank();
            return {text: String(cell.text ?? ''), rowSpan: Math.round(limit(cell.rowSpan, 1, model.rows.length - r, 1)),
                colSpan: Math.round(limit(cell.colSpan, 1, model.columns.length - c, 1)), style: {...cell.style}};
        }));
        // Canonicalize covered cells so malformed/older JSON cannot overlap anchors.
        const covered = new Set();
        model.cells.forEach((row, r) => row.forEach((cell, c) => {
            if (covered.has(r + ':' + c)) { cell.rowSpan = cell.colSpan = 1; return; }
            for (let y = r; y < r + cell.rowSpan; y++) for (let x = c; x < c + cell.colSpan; x++) {
                if (y !== r || x !== c) covered.add(y + ':' + x);
            }
        }));
        return model;
    }
    function anchors(model) {
        const result = [], covered = new Set();
        model.cells.forEach((row, r) => row.forEach((cell, c) => {
            if (covered.has(r + ':' + c)) return;
            result.push({r, c, cell});
            for (let y = r; y < r + cell.rowSpan; y++) for (let x = c; x < c + cell.colSpan; x++) covered.add(y + ':' + x);
        }));
        return result;
    }
    function owner(model, r, c) {
        return anchors(model).find(a => r >= a.r && r < a.r + a.cell.rowSpan && c >= a.c && c < a.c + a.cell.colSpan);
    }
    function range(model, start, end) {
        const box = {r1: Math.min(start.r, end.r), c1: Math.min(start.c, end.c), r2: Math.max(start.r, end.r), c2: Math.max(start.c, end.c)};
        let changed;
        do {
            changed = false;
            anchors(model).forEach(({r, c, cell}) => {
                const bottom = r + cell.rowSpan - 1, right = c + cell.colSpan - 1;
                if (r > box.r2 || bottom < box.r1 || c > box.c2 || right < box.c1) return;
                if (r < box.r1 || c < box.c1 || bottom > box.r2 || right > box.c2) changed = true;
                box.r1 = Math.min(box.r1, r); box.c1 = Math.min(box.c1, c);
                box.r2 = Math.max(box.r2, bottom); box.c2 = Math.max(box.c2, right);
            });
        } while (changed);
        return box;
    }
    function merge(model, box) {
        const texts = [];
        anchors(model).forEach(({r, c, cell}) => {
            if (r >= box.r1 && r <= box.r2 && c >= box.c1 && c <= box.c2 && cell.text) texts.push(cell.text);
        });
        for (let r = box.r1; r <= box.r2; r++) for (let c = box.c1; c <= box.c2; c++) {
            const cell = model.cells[r][c]; cell.text = ''; cell.rowSpan = cell.colSpan = 1;
        }
        Object.assign(model.cells[box.r1][box.c1], {text: texts.join('\n'), rowSpan: box.r2 - box.r1 + 1, colSpan: box.c2 - box.c1 + 1});
    }
    function split(model, box) {
        anchors(model).forEach(({r, c, cell}) => {
            if (r >= box.r1 && r <= box.r2 && c >= box.c1 && c <= box.c2) cell.rowSpan = cell.colSpan = 1;
        });
    }
    function subdivide(model, r, c, rowParts, colParts) {
        if (!Number.isInteger(rowParts) || !Number.isInteger(colParts) || rowParts < 1 || colParts < 1 ||
            rowParts > 20 || colParts > 12 || (rowParts === 1 && colParts === 1)) {
            throw new Error('Choose at least 2 rows or columns to split the cell (maximum 20 rows × 12 columns).');
        }
        const selected = owner(model, r, c);
        if (!selected) throw new Error('Select one cell to split.');
        const boundaries = sizes => sizes.reduce((points, size) => [...points, points[points.length - 1] + size], [0]);
        const oldX = boundaries(model.columns), oldY = boundaries(model.rows);
        const cell = selected.cell;
        const left = oldX[selected.c], right = oldX[selected.c + cell.colSpan];
        const top = oldY[selected.r], bottom = oldY[selected.r + cell.rowSpan];
        if ((right - left) / colParts < 20 || (bottom - top) / rowParts < 16) {
            throw new Error('Each resulting cell needs at least 20px width and 16px height. Increase the cell size or use fewer divisions.');
        }
        const divisions = (from, to, parts) => Array.from({length: parts + 1}, (_, i) => from + (to - from) * i / parts);
        const splitX = divisions(left, right, colParts), splitY = divisions(top, bottom, rowParts);
        const union = (old, added) => [...old, ...added].sort((a, b) => a - b).filter((point, i, points) => !i || point - points[i - 1] > 0.000001);
        const xs = union(oldX, splitX), ys = union(oldY, splitY);
        if (xs.length > 13 || ys.length > 21) throw new Error('This split exceeds the table limit of 20 grid rows × 12 grid columns. Use fewer divisions.');
        if (xs.some((point, i) => i && point - xs[i - 1] < 0.01) || ys.some((point, i) => i && point - ys[i - 1] < 0.01)) {
            throw new Error('These divisions are too close to an existing border. Adjust the cell size or choose a different split.');
        }
        const index = (points, value) => points.findIndex(point => Math.abs(point - value) < 0.000001);
        const next = {style: clone(model.style), columns: xs.slice(1).map((x, i) => x - xs[i]),
            rows: ys.slice(1).map((y, i) => y - ys[i]), cells: Array.from({length: ys.length - 1}, () => Array.from({length: xs.length - 1}, blank))};
        function place(source, x1, x2, y1, y2, text) {
            const row = index(ys, y1), col = index(xs, x1);
            next.cells[row][col] = {text, style: clone(source.style), rowSpan: index(ys, y2) - row, colSpan: index(xs, x2) - col};
        }
        // Refine the grid but span each neighboring cell across the inserted tracks.
        // Their content, formatting and physical size therefore stay unchanged.
        anchors(model).forEach(a => {
            if (a.r === selected.r && a.c === selected.c) return;
            place(a.cell, oldX[a.c], oldX[a.c + a.cell.colSpan], oldY[a.r], oldY[a.r + a.cell.rowSpan], a.cell.text);
        });
        for (let y = 0; y < rowParts; y++) for (let x = 0; x < colParts; x++) {
            place(cell, splitX[x], splitX[x + 1], splitY[y], splitY[y + 1], x === 0 && y === 0 ? cell.text : '');
        }
        Object.assign(model, next);
        return {r: index(ys, top), c: index(xs, left)};
    }
    function transpose(model) {
        [model.rows, model.columns] = [model.columns, model.rows];
        model.cells = model.rows.map((_, r) => model.columns.map((_, c) => {
            const cell = clone(model.cells[c][r]);
            [cell.rowSpan, cell.colSpan] = [cell.colSpan, cell.rowSpan]; return cell;
        }));
    }
    // Structural edits preserve spans and data on surviving cells.
    function editAxis(model, axis, index, remove) {
        const sizes = axis === 'row' ? model.rows : model.columns;
        if (remove && sizes.length === 1) throw new Error('A table needs at least one ' + axis + '.');
        if (!remove && sizes.length >= (axis === 'row' ? 20 : 12)) throw new Error('Maximum table size is 20 rows × 12 columns.');
        if (axis === 'column') transpose(model);
        const existing = anchors(model);
        if (remove) {
            existing.forEach(({r, c, cell}) => {
                if (r < index && r + cell.rowSpan > index) cell.rowSpan--;
                else if (r === index && cell.rowSpan > 1) {
                    model.cells[r + 1][c] = {...clone(cell), rowSpan: cell.rowSpan - 1};
                }
            });
            model.rows.splice(index, 1); model.cells.splice(index, 1);
        } else {
            existing.forEach(({r, cell}) => { if (r < index && r + cell.rowSpan > index) cell.rowSpan++; });
            model.rows.splice(index, 0, model.rows[Math.max(0, index - 1)]);
            model.cells.splice(index, 0, model.columns.map(blank));
        }
        if (axis === 'column') transpose(model);
    }
    function substitute(text, values) {
        return String(text).replace(/\{\{\s*([a-z_]+)\s*\}\}/g, (_, key) => String(values[key] ?? ''));
    }
    // A routine is a heading row plus ONE repeatable subject-row template.
    // Keep source cells intact so another student's schedule never reuses substituted values.
    function expandExamRoutine(source, records, values, areaHeight) {
        const model = normalize(source);
        if (model.rows.length !== 2 || anchors(model).some(a => a.cell.rowSpan !== 1)) {
            throw new Error('An automatic exam routine needs two template rows, with no merges between the heading and subject rows.');
        }
        const subjects = records.length ? records : [{routine_subject: 'Routine not published'}];
        const height = limit(areaHeight, 40, 3000, 600);
        const headerHeight = Math.min(model.rows[0], height / 3);
        // Share the entire remaining area, including when there are few subjects.
        const bodyHeight = (height - headerHeight) / subjects.length;
        const resolve = (cells, data) => cells.map(cell => ({...clone(cell), text: substitute(cell.text, data)}));
        return {...model, rows: [headerHeight, ...subjects.map(() => bodyHeight)],
            cells: [resolve(model.cells[0], values), ...subjects.map(row => resolve(model.cells[1], {...values, ...row}))]};
    }
    const api = root.IdCardTableModel = {create, normalize, anchors, owner, range, merge, split, subdivide, editAxis, substitute, expandExamRoutine, defaults};
    if (typeof module !== 'undefined') module.exports = api;
    if (!root.fabric) return;

    const fabric = root.fabric;
    const resizeRoutineHeight = fabric.controlsUtils.wrapWithFireEvent('resizing',
        fabric.controlsUtils.wrapWithFixedAnchor(function (event, transform, x, y) {
            const target = transform.target;
            if (target.lockScalingY) return false;
            const point = fabric.controlsUtils.getLocalPoint(transform, transform.originX, transform.originY, x, y);
            const fromBottom = transform.originY === 'bottom' || (transform.originY === 'center' && transform.corner === 'mt');
            const distance = point.y * (fromBottom ? -1 : 1) * (transform.originY === 'center' ? 2 : 1);
            const height = limit(Math.round(distance / target.scaleY), 40, 3000, target.height);
            if (height === target.height) return false;
            // Resize the row layout instead of stretching its text, borders and padding.
            target.data.routineHeight = height;
            target.refreshTable();
            return true;
        }));
    fabric.IdCardTable = fabric.util.createClass(fabric.Object, {
        type: 'id-card-table',
        initialize: function (options = {}) {
            this.callSuper('initialize', {...options, strokeWidth: 0, objectCaching: false});
            this.data = {...options.data, type: 'table', table: normalize(options.data?.table)};
            if (this.data.examRoutine) {
                // Own controls so ordinary tables keep Fabric's normal scale handles.
                this.controls = {...this.controls};
                ['mt', 'mb'].forEach(corner => {
                    this.controls[corner] = new fabric.Control({...this.controls[corner],
                        actionName: 'resizing', getActionName: () => 'resizing',
                        cursorStyleHandler: fabric.controlsUtils.scaleCursorStyleHandler,
                        actionHandler: resizeRoutineHeight});
                });
            }
            this.refreshTable();
        },
        refreshTable: function () {
            const model = this.data.table;
            this.set({width: model.columns.reduce((a, b) => a + b, 0), height: this.data.examRoutine ? limit(this.data.routineHeight, 40, 3000, 600) : model.rows.reduce((a, b) => a + b, 0), dirty: true});
            this._tableTextCache = new Map(); this.setCoords();
        },
        setStudentValues: function (values) {
            this._studentValues = values; this._tableTextCache = new Map(); this.dirty = true;
        },
        toObject: function (properties) {
            return {...this.callSuper('toObject', properties), data: clone(this.data)};
        },
        _render: function (ctx) {
            this._routineOverflow = '';
            const preview = Array.from({length: 6}, (_, i) => ({routine_serial: i + 1, routine_subject: 'Subject ' + (i + 1), routine_written_date: '15 Nov 2026', routine_written_time: '10:00 AM – 01:00 PM', routine_oral_date: '16 Nov 2026', routine_oral_time: '10:00 AM – 11:00 AM'}));
            const model = this.data.examRoutine
                ? expandExamRoutine(this.data.table, this._studentValues?.exam_routine || preview, this._studentValues || {}, this.height)
                : this.data.table;
            const xs = [0], ys = [0];
            model.columns.forEach(w => xs.push(xs[xs.length - 1] + w));
            model.rows.forEach(h => ys.push(ys[ys.length - 1] + h));
            ctx.save(); ctx.translate(-this.width / 2, -this.height / 2);
            anchors(model).forEach(({r, c, cell}) => {
                const style = {...model.style, ...cell.style};
                const x = xs[c], y = ys[r], w = xs[c + cell.colSpan] - x, h = ys[r + cell.rowSpan] - y;
                ctx.fillStyle = style.background; ctx.fillRect(x, y, w, h);
                const border = limit(style.borderWidth, 0, 12, 1);
                if (border && style.borderStyle !== 'none') {
                    ctx.strokeStyle = style.borderColor; ctx.lineWidth = border;
                    ctx.setLineDash(style.borderStyle === 'dashed' ? [border * 4, border * 2] : style.borderStyle === 'dotted' ? [border, border * 2] : []);
                    ctx.strokeRect(x + border / 2, y + border / 2, w - border, h - border); ctx.setLineDash([]);
                }
                const padding = Math.min(limit(style.padding, 0, 50, 6) + border, w / 2 - 1, h / 2 - 1);
                const key = r + ':' + c;
                let text = this._tableTextCache.get(key);
                if (!text) {
                    text = new fabric.Textbox(this._studentValues ? substitute(cell.text, this._studentValues) : cell.text, {
                        width: Math.max(1, w - padding * 2), fontFamily: style.fontFamily,
                        fontSize: limit(style.fontSize, 4, 120, 18), fill: style.fill,
                        fontWeight: style.fontWeight, fontStyle: style.fontStyle, underline: style.underline,
                        textAlign: style.textAlign, splitByGrapheme: true, objectCaching: false, strokeWidth: 0,
                        originX: 'left', originY: 'top'
                    });
                    if (this.data.examRoutine) {
                        while (text.height > h - padding * 2 && text.fontSize > 12) {
                            text.set('fontSize', Math.max(12, text.fontSize - 1)); text.initDimensions();
                        }
                    }
                    this._tableTextCache.set(key, text);
                }
                if (this.data.examRoutine && this._studentValues && text.height > h - padding * 2 + 0.5) {
                    this._routineOverflow = 'The exam routine does not fit its area. Increase the routine area height or column width in the Admit Card Builder.';
                }
                const available = Math.max(0, h - padding * 2 - text.height);
                const offset = style.verticalAlign === 'bottom' ? available : style.verticalAlign === 'middle' ? available / 2 : 0;
                ctx.save(); ctx.beginPath(); ctx.rect(x + padding, y + padding, w - padding * 2, h - padding * 2); ctx.clip();
                text.set({left: x + padding, top: y + padding + offset}); text.render(ctx); ctx.restore();
            });
            ctx.restore();
        }
    });
    fabric.IdCardTable.fromObject = function (object, callback) { callback(new fabric.IdCardTable(object)); };
})(typeof window !== 'undefined' ? window : globalThis);
