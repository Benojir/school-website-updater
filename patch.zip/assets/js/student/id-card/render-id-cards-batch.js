/**
 * render-id-cards-batch.js
 * -----------------------------------------------------------------
 * Clones the saved Fabric JSON template for each student, replaces the
 * dynamic-text variables and placeholder images (photo/QR/logo) with the
 * real data, exports each card to an image — then lays the cards out on a
 * printable A4 grid.
 *
 * Cards can be any size and either single- or double-sided:
 *  - The page grid (GRID_COLS x GRID_ROWS) is computed from the card's real
 *    millimetre size by generate-student-id-cards.php, not hardcoded.
 *  - A double-sided card is rendered twice per student, once per side, by two
 *    independent side renderers (see createSideRenderer).
 *  - LAYOUT_MODE decides how the backs reach the paper — see
 *    layoutCardsForPrint().
 */

// Duplicate of id-card-builder.js's helper — needed by applyTextClip below.
const TEXT_TYPES = ['textbox', 'i-text', 'text'];
function isTextObject(obj) { return !!obj && TEXT_TYPES.includes(obj.type); }

// ---- Rounded text background --------------------------------------------
// Same patch as id-card-builder.js — Fabric's native `backgroundColor` for
// text is a flat ctx.fillRect() with no corner-radius support, so a text
// object can store a radius percentage in data.bgRadius and this override
// draws a real rounded rect instead. This is a SEPARATE page/runtime from
// the Builder (this script renders on the print page, not the editor), so
// the patch has to be duplicated here — keep both copies in sync.
(function patchRoundedTextBackground() {
    const originalRenderBackground = fabric.Text.prototype._renderBackground;
    fabric.Text.prototype._renderBackground = function (ctx) {
        const radiusPercent = (this.data && this.data.bgRadius) || 0;
        if (!this.backgroundColor || radiusPercent <= 0) {
            originalRenderBackground.call(this, ctx);
            return;
        }
        const dim = this._getNonTransformedDimensions();
        const w = dim.x, h = dim.y;
        const r = Math.min((radiusPercent / 100) * (Math.min(w, h) / 2), w / 2, h / 2);
        const x = -w / 2, y = -h / 2;
        ctx.save();
        ctx.fillStyle = this.backgroundColor;
        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.lineTo(x + w - r, y);
        ctx.arcTo(x + w, y, x + w, y + r, r);
        ctx.lineTo(x + w, y + h - r);
        ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
        ctx.lineTo(x + r, y + h);
        ctx.arcTo(x, y + h, x, y + h - r, r);
        ctx.lineTo(x, y + r);
        ctx.arcTo(x, y, x + r, y, r);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
        if (this.styles && typeof this._removeShadow === 'function') {
            this._removeShadow(ctx);
        }
    };
})();

// ---- Fixed-Height Clip (HARD overflow safety net) --------------------------
// Same function as id-card-builder.js — see that file for the full
// explanation. This is the side that matters most in practice: the REAL
// student value (not the short design-time placeholder label) gets
// substituted here, and it's this substitution that used to make a Textbox
// silently grow taller than wherever it was visually placed in the Builder,
// spilling text over neighboring elements/off the card. Re-applying the clip
// after every substitution guarantees the printed card never exceeds the
// field's designed footprint, regardless of how long the real data is.
// ⚠️ Duplicated from id-card-builder.js (separate Fabric runtime/page) — keep
// both copies in sync.
// Clip to Fixed Width mirrors the height version, horizontally:
// obj.data.clipWidthEnabled (bool) / obj.data.boxWidth (px). Either toggle can
// be on independently — whichever dimension isn't clipped falls back to the
// object's own current size.
function applyTextClip(obj) {
    if (!isTextObject(obj)) return;
    const heightEnabled = !!(obj.data && obj.data.clipEnabled);
    const boxHeight = (obj.data && obj.data.boxHeight) || 0;
    const widthEnabled = !!(obj.data && obj.data.clipWidthEnabled);
    const boxWidth = (obj.data && obj.data.boxWidth) || 0;

    // Keep the WRAP width in sync with the CLIP width. Fabric wraps text
    // using obj.width, but the clip rect below is sized from data.boxWidth —
    // two independent numbers. If boxWidth ever ends up narrower than
    // obj.width, Fabric happily wraps a word onto the current line (thinking
    // the wider obj.width is available) and the clip then slices off
    // whatever hangs past boxWidth — chopping a word mid-letter ("Road" ->
    // "Ro") instead of ever wrapping it down. Forcing obj.width = boxWidth
    // before re-wrapping guarantees a word can never wrap somewhere the clip
    // is about to cut it off.
    if (widthEnabled && boxWidth > 0 && obj.width !== boxWidth) {
        obj.set({ width: boxWidth });
        if (typeof obj.initDimensions === 'function') obj.initDimensions();
    }

    if ((!heightEnabled || boxHeight <= 0) && (!widthEnabled || boxWidth <= 0)) {
        obj.clipPath = null;
        obj.dirty = true;
        return;
    }

    // Whichever dimension isn't being clipped falls back to the object's own
    // current size (+small buffer so stroke/glyph edges aren't clipped), so
    // turning on just one of the two toggles never clips the other axis.
    const clipWidth = widthEnabled && boxWidth > 0
        ? boxWidth
        : 100000;

    const clipHeight = heightEnabled && boxHeight > 0
        ? boxHeight
        : 100000;

    obj.clipPath = new fabric.Rect({
        width: clipWidth,
        height: clipHeight,
        originX: 'center',
        originY: 'center',
        left: 0,
        top: 0
    });
    obj.clipPath.absolutePositioned = false; // clip lives in the object's own local coord space
    obj.dirty = true;
}

/** {{student_name}} -> 'student_name' */
function variableKey(placeholder) {
    return placeholder.replace(/^\{\{/, '').replace(/\}\}$/, '');
}

// ---- Text Case (Uppercase / Lowercase / Capitalize) -----------------------
// Applied here to the REAL student value being substituted into a
// dynamic-text field (obj.data.textCase, set in the Builder). Static text
// already has its case baked into the saved design, so it needs no handling
// here. Duplicate of id-card-builder.js's copy — keep both in sync.
function applyTextCase(str, caseType) {
    if (str === null || str === undefined || str === '') return '';
    str = String(str); // student[key] can come through as a number (e.g. roll_no) — force to string
    switch (caseType) {
        case 'uppercase': return str.toUpperCase();
        case 'lowercase': return str.toLowerCase();
        case 'capitalize':
            return str.replace(/\w\S*/g, (w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
        default: return str;
    }
}

// ---- Max Lines (prevents long real student data from overflowing the card) --
// Same trimming logic as id-card-builder.js — kept in sync there. This is the
// critical copy: real student names/addresses (unlike the design-time
// placeholder label) are the actual long strings that can overflow a card.
function enforceMaxLines(textboxObj, maxLines) {
    if (!textboxObj || !maxLines || maxLines <= 0) return;
    const ELLIPSIS = '…';
    if (typeof textboxObj._initDimensions === 'function') textboxObj._initDimensions();
    if (!textboxObj._textLines || textboxObj._textLines.length <= maxLines) return;

    let text = (textboxObj.text || '').replace(/…\s*$/, '').trimEnd();
    let guard = 0;
    while (text.length > 0 && guard < 500) {
        guard++;
        const withoutLastWord = text.replace(/\s*\S+$/, '');
        text = (withoutLastWord === text) ? text.slice(0, -1) : withoutLastWord;
        const candidate = text.trimEnd().length > 0 ? text.trimEnd() + ' ' + ELLIPSIS : ELLIPSIS;
        textboxObj.set('text', candidate);
        if (typeof textboxObj._initDimensions === 'function') textboxObj._initDimensions();
        if (!textboxObj._textLines || textboxObj._textLines.length <= maxLines) break;
    }
}

// The placeholder image src (Logo/Student Photo/QR) added in the design is not
// loaded — during batch render it will be replaced with the real image
// regardless. Instead a 1x1 transparent pixel is used so that —
//   (a) each student card doesn't trigger an unnecessary extra network call, and
//   (b) the placeholder image (placehold.co) never gets drawn onto the canvas
//       without CORS and "taints" the offscreen canvas — this was the actual
//       cause of toDataURL() failing (and the whole batch generation getting
//       stuck) on designs that had a QR code or photo.
const BLANK_PIXEL = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=';
const DYNAMIC_IMAGE_TYPES = ['student-photo', 'school-logo', 'qr-code'];

function stripDynamicImagePlaceholders(clonedJson) {
    (clonedJson.objects || []).forEach((o) => {
        const type = o.data && o.data.type;
        if (DYNAMIC_IMAGE_TYPES.includes(type)) {
            o.src = BLANK_PIXEL;
            o.crossOrigin = null; // not needed for a data: URI
        }
    });
}

/**
 * Builds the same rounded-rect clip shape as id-card-builder.js's
 * buildRoundedClipRect() — rx/ry are computed independently per axis (CSS's
 * `border-radius: N%` rule: horizontal radius is a % of width, vertical
 * radius is a % of height), so the stored 0–100 roundness percentage gives a
 * true ellipse/full-circle at 100% instead of a rounded rectangle. `extraPx`
 * inflates the box outward (keeping the rounding concentric) to make room for
 * an "outside" stroke halo so it isn't clipped away at the original edge.
 * Keep in sync with the Builder's copy.
 */
function buildRoundedClipRect(w, h, radiusPercent, extraPx) {
    extraPx = extraPx || 0;
    const rx = (radiusPercent / 100) * (w / 2);
    const ry = (radiusPercent / 100) * (h / 2);
    if (rx <= 0 && ry <= 0 && extraPx <= 0) return null;
    return new fabric.Rect({
        width: w + 2 * extraPx,
        height: h + 2 * extraPx,
        rx: rx > 0 ? rx + extraPx : 0,
        ry: ry > 0 ? ry + extraPx : 0,
        originX: 'center',
        originY: 'center'
    });
}

/**
 * Traces a CSS-style rounded-rect path (independent rx/ry per axis) on ctx,
 * centered at the current origin. Same bezier algorithm Fabric's own
 * fabric.Rect uses internally — i.e. the exact same shape as the
 * border-radius clipPath — so a stroke traced with this follows the clip's
 * curve instead of getting cut off at the corners.
 */
function traceRoundedRectPath(ctx, w, h, rx, ry) {
    const x = -w / 2, y = -h / 2;
    const isRounded = rx > 0 || ry > 0;
    const k = 1 - 0.5522847498; // standard ellipse bezier constant
    ctx.beginPath();
    ctx.moveTo(x + rx, y);
    ctx.lineTo(x + w - rx, y);
    if (isRounded) ctx.bezierCurveTo(x + w - k * rx, y, x + w, y + k * ry, x + w, y + ry);
    ctx.lineTo(x + w, y + h - ry);
    if (isRounded) ctx.bezierCurveTo(x + w, y + h - k * ry, x + w - k * rx, y + h, x + w - rx, y + h);
    ctx.lineTo(x + rx, y + h);
    if (isRounded) ctx.bezierCurveTo(x + k * rx, y + h, x, y + h - k * ry, x, y + h - ry);
    ctx.lineTo(x, y + ry);
    if (isRounded) ctx.bezierCurveTo(x, y + k * ry, x + k * rx, y, x + rx, y);
    ctx.closePath();
}

// ---- Rounded stroke for images (border-radius aware) ----------------------
// fabric.Image._renderStroke always strokes a PLAIN rectangle, regardless of
// clipPath — the border-radius clip only hides pixels, it never changes that
// path. So a rounded image's stroke got chopped off hard at each corner
// instead of curving with the radius. This overrides the stroke path to
// match the same rounded rect used for the border-radius clip.
// ⚠️ Duplicated in render-id-cards-batch.js — keep both copies in sync.
(function patchRoundedImageStroke() {
    const originalRenderStroke = fabric.Image.prototype._renderStroke;
    fabric.Image.prototype._renderStroke = function (ctx) {
        if (!this.stroke || this.strokeWidth === 0) return;
        const radiusPercent = (this.data && this.data.borderRadius) || 0;
        if (radiusPercent <= 0) {
            originalRenderStroke.call(this, ctx);
            return;
        }
        const w = this.width, h = this.height;
        const rx = Math.min((radiusPercent / 100) * (w / 2), w / 2);
        const ry = Math.min((radiusPercent / 100) * (h / 2), h / 2);
        ctx.save();
        if (this.shadow && !this.shadow.affectStroke && typeof this._removeShadow === 'function') {
            this._removeShadow(ctx);
        }
        ctx.lineWidth = this.strokeWidth;
        ctx.strokeStyle = this.stroke;
        traceRoundedRectPath(ctx, w, h, rx, ry);
        ctx.stroke();
        ctx.restore();
    };
})();

/**
 * Changes a fabric.Image object's src and returns a promise that resolves once
 * loading finishes. If the real image is larger than the placeholder box, it's
 * scaled "cover"-style and the excess is cropped via a clipPath — the same
 * behavior as CSS's object-fit: cover.
 *
 * The clipPath also carries over any border-radius percentage configured for
 * this image in the Builder (stored in fabricImg.data.borderRadius), and, if
 * an "outside" stroke is configured (fabricImg.data.strokePosition +
 * data.strokeWidth), inflates the clip so that stroke halo isn't cut off —
 * matching the same logic id-card-builder.js uses for the live preview.
 */
function setImageSrcAsync(fabricImg, url, boxWidth, boxHeight) {
    return new Promise((resolve, reject) => {
        // boxWidth/boxHeight are passed in (captured once, at initial canvas load —
        // see cacheDynamicObjectRefs()) rather than read from fabricImg.width*scaleX
        // here. Reading it here only works the FIRST time: once a real image has been
        // loaded once, width/height/scaleX get overwritten to match that image, so on
        // the next student re-reading them would use the wrong (previous student's
        // image) box size instead of the original placeholder box.
        const borderRadiusPercent = (fabricImg.data && fabricImg.data.borderRadius) || 0;
        const strokePosition = (fabricImg.data && fabricImg.data.strokePosition) || 'center';
        const strokeDesired = (fabricImg.data && fabricImg.data.strokeWidth) || 0;

        fabricImg.setSrc(url, () => {
            if (!fabricImg.width || !fabricImg.height) {
                reject(new Error('Image failed to load: ' + url));
                return;
            }

            // cover fit: pick the larger scale factor so both dimensions of the box are covered
            const scale = Math.max(boxWidth / fabricImg.width, boxHeight / fabricImg.height);
            fabricImg.set({ scaleX: scale, scaleY: scale });

            // Crop the overflow with a box-sized clipPath
            // (originX/Y default to 'center' — cropping is centered on the object)
            const clipWidth = boxWidth / scale;
            const clipHeight = boxHeight / scale;
            const extraPx = (strokePosition === 'outside' && strokeDesired > 0) ? strokeDesired : 0;

            fabricImg.clipPath = buildRoundedClipRect(clipWidth, clipHeight, borderRadiusPercent, extraPx);

            fabricImg.setCoords();
            resolve();
        }, { crossOrigin: 'anonymous' });
    });
}

/** Generates a QR code data URL (via the qrcode.js library) */
function generateQrDataUrl(payload) {
    return new Promise((resolve, reject) => {
        QRCode.toDataURL(payload, { width: 300, margin: 1 }, (err, url) => {
            if (err) return reject(err);
            resolve(url);
        });
    });
}

// ---- One-time canvas setup, per card side --------------------------------
// Loading the template JSON and letting Fabric build out every object
// (text, image, shadow, clipPath, etc.) is the expensive part — doing that
// 700 times was the main cause of the slowdown, not the image/QR loading.
// Instead each side's canvas is built ONCE, direct references to its dynamic
// objects are kept, and for every student those same objects are mutated
// (set text, swap image src) instead of tearing everything down and rebuilding
// from JSON again.
//
// This is a factory rather than a set of module-level globals because a
// double-sided card needs TWO fully independent canvases, each with its own
// cached dynamic-object references — the front and back have completely
// different elements.

// ---- Web font preloading --------------------------------------------------
// IMPORTANT: <canvas> does NOT repaint automatically when a web font finishes
// downloading (unlike normal DOM text). If fabric draws a text object before
// its fontFamily's FontFace is actually ready, that text is permanently baked
// into the exported PNG/JPEG using the fallback font — with no error thrown.
// This is why some fonts "don't show up" here even though they work fine in
// the Builder: id-card-builder.js already waits on document.fonts.load()
// before letting you touch the canvas; this script never did. Fixed by
// scanning the template for every fontFamily actually used and waiting for
// each one to be ready before rendering the first card.
//
// Takes MULTIPLE designs (front + back) — scanning only the front would let a
// font used exclusively on the back silently fall back to Arial on every
// printed card, which is exactly the bug described above.
async function preloadTemplateFonts(designs) {
    const families = new Set();
    designs.filter(Boolean).forEach((json) => {
        (json.objects || []).forEach((obj) => {
            if (obj.fontFamily) families.add(obj.fontFamily);
        });
    });
    if (families.size === 0) return;

    const loadPromises = [...families].map((f) => {
        try { return document.fonts.load(`600 16px "${f}"`); } catch (e) { return Promise.resolve(); }
    });

    // Race against a safety timeout so a slow/blocked font CDN can never hang
    // the whole batch print job — worst case, a font falls back for this run
    // instead of the page freezing on "Preparing ID cards..." forever.
    await Promise.race([
        Promise.all(loadPromises).then(() => document.fonts.ready),
        new Promise((resolve) => setTimeout(resolve, 2000))
    ]);
}

/**
 * Builds a reusable renderer for ONE side of the card.
 *
 * @param {string} canvasElId  id of the hidden <canvas> element to draw on
 * @param {object} designJson  that side's saved Fabric template
 * @returns {{setup: Function, renderStudent: Function}}
 */
function createSideRenderer(canvasElId, designJson) {
    const sideCanvas = new fabric.StaticCanvas(canvasElId, {
        width: CANVAS_WIDTH,
        height: CANVAS_HEIGHT
    });

    let dynamicTextObjs = [];   // [{ obj, key, textCase, maxLines }]
    let dynamicImageObjs = [];  // [{ obj, type, boxWidth, boxHeight }]

    async function setup() {
        const clonedJson = JSON.parse(JSON.stringify(designJson));
        stripDynamicImagePlaceholders(clonedJson);

        await new Promise((resolve) => {
            sideCanvas.loadFromJSON(clonedJson, resolve);
        });

        sideCanvas.getObjects().forEach((obj) => {
            const type = obj.data && obj.data.type;

            // Rebuild the clip from data.clipEnabled/boxHeight regardless of what
            // was serialized in the saved JSON — cheap, and guarantees correctness
            // even for templates saved before this feature existed.
            if (isTextObject(obj)) applyTextClip(obj);

            if (type === 'dynamic-text' && obj.data.variable) {
                dynamicTextObjs.push({
                    obj,
                    key: variableKey(obj.data.variable),
                    textCase: obj.data.textCase,
                    maxLines: obj.data.maxLines || 0
                });
            } else if (DYNAMIC_IMAGE_TYPES.includes(type)) {
                // Capture the placeholder's real (scaled) box size ONCE, right now,
                // while width/scaleX still reflect the original placeholder image —
                // this is what setImageSrcAsync needs on every later call, since after
                // the first real image loads, width/scaleX change to match that image.
                dynamicImageObjs.push({
                    obj,
                    type,
                    boxWidth: obj.width * obj.scaleX,
                    boxHeight: obj.height * obj.scaleY
                });
            }
            // static-text and custom-image need no per-student handling
        });
    }

    /**
     * Updates this side's already-built canvas with one student's data and
     * returns a data URL for the rendered card. Must be called sequentially
     * (awaited one student at a time) — all students share the same
     * canvas/objects.
     */
    async function renderStudent(student) {
        dynamicTextObjs.forEach(({ obj, key, textCase, maxLines }) => {
            const rawValue = student[key] ?? '';
            const originalWidth = obj.width; // আগে থেকে সেট করা width সেভ করে রাখা

            obj.set('text', applyTextCase(rawValue, textCase));

            // fixed width আগেই ফিরিয়ে আনা হচ্ছে — initDimensions()-এর আগে এটা সেট না
            // করলে wrap হত সাময়িকভাবে চওড়া width অনুযায়ী, তারপর width কেবল সংখ্যায়
            // ছোট হতো (re-wrap না হওয়ায়) — লেখা বক্সের বাইরে overflow করত.
            obj.set({ width: originalWidth });

            obj.initDimensions();

            obj.setCoords();
            enforceMaxLines(obj, maxLines);
            applyTextClip(obj);
        });

        const imageLoadPromises = dynamicImageObjs.map(({ obj, type, boxWidth, boxHeight }) => {
            if (type === 'student-photo') {
                return setImageSrcAsync(obj, student.student_photo_url, boxWidth, boxHeight)
                    .catch((err) => console.error(`${student.student_name} — photo failed to load:`, err));
            } else if (type === 'school-logo') {
                return setImageSrcAsync(obj, SCHOOL_LOGO_URL, boxWidth, boxHeight)
                    .catch((err) => console.error('School logo failed to load:', err));
            } else if (type === 'qr-code') {
                return generateQrDataUrl(student.qr_payload)
                    .then((dataUrl) => setImageSrcAsync(obj, dataUrl, boxWidth, boxHeight))
                    .catch((err) => console.error(`${student.student_name} — QR code generation failed:`, err));
            }
            return Promise.resolve();
        });

        // If one image (e.g. QR or photo) fails to load, the whole batch shouldn't get
        // stuck — every promise above already has its own .catch(), so Promise.all
        // won't reject; that one element just stays at its placeholder/previous state.
        await Promise.all(imageLoadPromises);
        sideCanvas.renderAll();

        // JPEG instead of PNG: cards have an opaque background (no transparency needed),
        // and JPEG encoding is noticeably faster than PNG at this resolution — matters
        // across 700 exports. multiplier: 2 → for high-res print quality (the builder
        // works at 10px/mm, so this exports at 20px/mm ≈ 508 DPI at any card size).
        return sideCanvas.toDataURL({ format: 'jpeg', quality: 0.92, multiplier: 2 });
    }

    return { setup, renderStudent };
}

// ---- Print layout --------------------------------------------------------
// The page grid is not fixed at 3x3 any more: GRID_COLS / GRID_ROWS are worked
// out from the card's real millimetre size by generate-student-id-cards.php,
// which also emits the matching CSS grid-template.

/** Creates one <img>; its printed size comes from the page CSS. */
function cardImageEl(src) {
    const img = document.createElement('img');
    img.src = src;
    return img;
}

/**
 * An empty grid position. Needed for duplex alignment: the back sheet mirrors a
 * FIXED rows x cols grid, so a partially-filled last page must still occupy its
 * empty slots or every back on that sheet shifts sideways.
 */
function emptySlotEl() {
    const div = document.createElement('div');
    div.className = 'empty-slot';
    return div;
}

function newPageEl() {
    const pageDiv = document.createElement('div');
    pageDiv.className = 'page';
    return pageDiv;
}

/**
 * Lays the rendered cards out on printable pages.
 *
 * `cards` is [{ front, back }] — `back` is null on a single-sided card.
 *
 * Three arrangements:
 *
 *  1. Single-sided — cards fill the grid in order, nothing special.
 *
 *  2. LAYOUT_MODE 'sequential' (double-sided, for a duplex printer) — page N
 *     holds the fronts, page N+1 holds the SAME cards' backs with each grid ROW
 *     reversed. Reversing rows corresponds to flipping the sheet about its
 *     vertical axis, i.e. duplex "flip on long edge" for portrait A4, which is
 *     what makes each back land behind its own front.
 *
 *  3. LAYOUT_MODE 'side-by-side' (double-sided, any printer) — each grid cell
 *     holds one card's front and back next to each other; the admin cuts them
 *     out and laminates the pair back-to-back. No duplex alignment to get wrong.
 */
function layoutCardsForPrint(cards) {
    const container = document.getElementById('printContainer');
    container.innerHTML = '';

    const perPage = CARDS_PER_PAGE;
    const doubleSided = HAS_BACK && cards.some((c) => c.back);

    for (let i = 0; i < cards.length; i += perPage) {
        const pageCards = cards.slice(i, i + perPage);

        if (!doubleSided) {
            const pageDiv = newPageEl();
            pageCards.forEach((c) => pageDiv.appendChild(cardImageEl(c.front)));
            container.appendChild(pageDiv);
            continue;
        }

        if (LAYOUT_MODE === 'side-by-side') {
            // One grid cell per card, holding both of its sides.
            const pageDiv = newPageEl();
            pageCards.forEach((c) => {
                const pair = document.createElement('div');
                pair.className = 'card-pair';
                pair.appendChild(cardImageEl(c.front));
                pair.appendChild(cardImageEl(c.back || c.front));
                pageDiv.appendChild(pair);
            });
            container.appendChild(pageDiv);
            continue;
        }

        // 'sequential': pad this page out to the FULL grid so the mirrored back
        // sheet keeps every card in the physical position its front occupied.
        const slots = pageCards.slice();
        while (slots.length < perPage) slots.push(null);

        const frontPage = newPageEl();
        slots.forEach((c) => {
            frontPage.appendChild(c ? cardImageEl(c.front) : emptySlotEl());
        });
        container.appendChild(frontPage);

        const backPage = newPageEl();
        backPage.classList.add('back-page');
        for (let row = 0; row < GRID_ROWS; row++) {
            // Reverse this row, empties included, so the slot that was leftmost
            // on the front sheet becomes the rightmost on the back sheet.
            const rowSlots = slots
                .slice(row * GRID_COLS, (row + 1) * GRID_COLS)
                .reverse();
            rowSlots.forEach((c) => {
                backPage.appendChild(c && c.back ? cardImageEl(c.back) : emptySlotEl());
            });
        }
        container.appendChild(backPage);
    }
}

/** Main entry point */
async function renderAllCardsAndPrint() {
    const backDesign =
        HAS_BACK && typeof TEMPLATE_BACK_DESIGN_JSON !== 'undefined' && TEMPLATE_BACK_DESIGN_JSON
            ? TEMPLATE_BACK_DESIGN_JSON
            : null;

    // Both designs are scanned together — a font used only on the back would
    // otherwise be drawn with a fallback font on every printed card.
    await preloadTemplateFonts([TEMPLATE_DESIGN_JSON, backDesign]);

    const frontRenderer = createSideRenderer('offscreenCanvasFront', TEMPLATE_DESIGN_JSON);
    await frontRenderer.setup();

    let backRenderer = null;
    if (backDesign) {
        backRenderer = createSideRenderer('offscreenCanvasBack', backDesign);
        await backRenderer.setup();
    }

    const cards = [];
    const failedStudents = [];
    const loadingMsgEl = document.getElementById('loadingMsg');
    // Processed sequentially — all students share the same canvas/objects,
    // so a student's render must fully finish before the next one starts.
    for (let i = 0; i < STUDENTS.length; i++) {
        const student = STUDENTS[i];
        if (loadingMsgEl) {
            loadingMsgEl.textContent = `Preparing ID cards... ${i + 1} / ${STUDENTS.length}`;
        }
        try {
            const front = await frontRenderer.renderStudent(student);
            const back = backRenderer ? await backRenderer.renderStudent(student) : null;
            cards.push({ front, back });
        } catch (err) {
            // If one student's card fails to render, the rest shouldn't get stuck —
            // log the error and move on to the next student
            console.error(`Failed to render card for ${student.student_name} (${student.student_id}):`, err);
            failedStudents.push(student.student_name);
        }
    }

    if (failedStudents.length > 0) {
        console.warn('Could not render cards for: ' + failedStudents.join(', '));
    }

    if (cards.length === 0) {
        throw new Error('No cards could be rendered.');
    }

    layoutCardsForPrint(cards);

    if (failedStudents.length > 0) {
        // Even if one or two cards were skipped, proceed with printing the rest —
        // but show the user a small notice explaining what happened.
        const notice = document.createElement('div');
        notice.style.cssText = 'text-align:center;color:#b02a37;padding:8px;font-size:14px;';
        notice.textContent = `⚠️ ${failedStudents.length} card(s) could not be rendered: ${failedStudents.join(', ')}`;
        document.getElementById('printContainer').prepend(notice);
    }

    document.getElementById('loadingMsg').style.display = 'none';

    // A short delay makes sure the images have painted into the DOM before the print dialog opens
    setTimeout(() => window.print(), 300);
}

renderAllCardsAndPrint().catch((err) => {
    document.getElementById('loadingMsg').textContent =
        'An error occurred while rendering the cards: ' + err.message;
});