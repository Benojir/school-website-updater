/* One font catalog for the ID card editor, tables and print/export pages. */
(function (root) {
    'use strict';
    const regular = 'wght@400;600;700';
    const italic = 'ital,wght@0,400;0,600;0,700;1,400;1,600;1,700';
    const twoWeights = 'ital,wght@0,400;0,700;1,400;1,700';
    const catalog = {
        Poppins: italic, Arial: null, Georgia: null, Roboto: italic,
        'Courier New': null, 'Times New Roman': null, Verdana: null,
        Montserrat: italic, 'Open Sans': italic, Lato: twoWeights,
        Nunito: italic, Oswald: regular, 'Playfair Display': italic,
        Merriweather: twoWeights,
        Inter: italic, Manrope: regular, Outfit: regular, 'DM Sans': italic,
        'Plus Jakarta Sans': italic, 'Space Grotesk': regular,
        'Source Sans 3': italic, 'IBM Plex Sans': italic, 'Work Sans': italic,
        Raleway: italic, Ubuntu: twoWeights, Rubik: italic, Barlow: italic,
        Quicksand: regular, 'Bebas Neue': 'wght@400',
        'Libre Baskerville': 'ital,wght@0,400;0,700;1,400',
        'Noto Sans Bengali': regular, 'Hind Siliguri': regular,
        'Noto Sans Devanagari': regular
    };
    const pending = new Map();
    const cssPending = new Map();
    const axesFor = family => Object.prototype.hasOwnProperty.call(catalog, family) ? catalog[family] : null;
    // Include Indic glyphs: FontFaceSet.load's default Latin sample would leave
    // the Bengali/Devanagari subsets unloaded when Fabric measures the text.
    const sample = 'ID Card 0123456789 বাংলা বিদ্যালয় विद्यार्थी';
    const timeoutMs = 12000;

    function bounded(promise, message) {
        return new Promise((resolve, reject) => {
            const timer = setTimeout(() => reject(new Error(message)), timeoutMs);
            Promise.resolve(promise).then(value => { clearTimeout(timer); resolve(value); },
                error => { clearTimeout(timer); reject(error); });
        });
    }
    function stylesheetUrl(family) {
        const axes = axesFor(family);
        return axes ? 'https://fonts.googleapis.com/css2?family=' +
            encodeURIComponent(family).replace(/%20/g, '+') + ':' + axes + '&display=swap' : null;
    }
    function loadStylesheet(family) {
        if (!cssPending.has(family)) {
            const link = document.createElement('link');
            link.rel = 'stylesheet'; link.href = stylesheetUrl(family);
            link.dataset.idCardFont = family;
            const promise = bounded(new Promise((resolve, reject) => {
                link.onload = resolve;
                link.onerror = () => reject(new Error('Could not load the font ' + family + '. Check your connection and try again.'));
                document.head.appendChild(link);
            }), 'Loading ' + family + ' timed out. Check your connection and try again.').catch(error => {
                cssPending.delete(family); link.remove(); throw error;
            });
            cssPending.set(family, promise);
        }
        return cssPending.get(family);
    }
    function fontDescriptors(family) {
        const axes = axesFor(family);
        if (!axes) return ['normal 400 16px ' + JSON.stringify(family)];
        const [names, values] = axes.split('@');
        return values.split(';').map(value => {
            const pair = value.split(',');
            return (names === 'ital,wght' && pair[0] === '1' ? 'italic' : 'normal') + ' ' +
                pair[pair.length - 1] + ' 16px ' + JSON.stringify(family);
        });
    }
    function loadFamily(family) {
        if (typeof family !== 'string' || !family.trim()) return Promise.resolve();
        family = family.trim();
        if (!pending.has(family)) {
            const promise = (async () => {
                if (!document.fonts?.load) return;
                if (axesFor(family)) await loadStylesheet(family);
                const loaded = await bounded(Promise.all(fontDescriptors(family).map(font => document.fonts.load(font, sample))),
                    'Loading ' + family + ' timed out. Check your connection and try again.');
                if (axesFor(family) && loaded.some(faces => !faces.length)) {
                    throw new Error('The font ' + family + ' is unavailable. Check your connection and try again.');
                }
                // Fabric may have measured a saved design while the initial
                // loading overlay timed out. Discard those fallback metrics.
                root.fabric?.util?.clearFabricFontCache?.(family);
            })().catch(error => { pending.delete(family); throw error; });
            pending.set(family, promise);
        }
        return pending.get(family);
    }
    function familiesInDesigns(designs) {
        const families = new Set();
        function visit(object) {
            if (!object || typeof object !== 'object') return;
            if (object.fontFamily) families.add(object.fontFamily);
            if (object.type === 'id-card-table' && object.data?.table) {
                const table = object.data.table;
                families.add(table.style?.fontFamily || 'Poppins');
                (table.cells || []).forEach(row => row.forEach(cell => {
                    if (cell.style?.fontFamily) families.add(cell.style.fontFamily);
                }));
            }
            // Preserve fonts in grouped text and per-character text styles.
            Object.values(object.styles || {}).forEach(line => Object.values(line || {}).forEach(style => {
                if (style?.fontFamily) families.add(style.fontFamily);
            }));
            (object.objects || []).forEach(visit);
        }
        designs.filter(Boolean).forEach(design => {
            if (typeof design === 'string') {
                try { design = JSON.parse(design); } catch (_) { return; }
            }
            visit(design);
        });
        return [...families];
    }
    function loadDesigns(designs) {
        return Promise.all(familiesInDesigns(designs).map(loadFamily));
    }
    root.IdCardFonts = {families: Object.freeze(Object.keys(catalog)), loadFamily, loadDesigns,
        familiesInDesigns, stylesheetUrl};
})(typeof window !== 'undefined' ? window : globalThis);
