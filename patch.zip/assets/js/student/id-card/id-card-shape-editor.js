/* Shape toolbox/properties. Geometry also runs independently in the printer. */
const shapeProps = document.getElementById('shapeProps');
const shapeInput = id => document.getElementById(id);
const shapeNumber = (id, min, max, fallback) => {
    const value = Number(shapeInput(id).value);
    return Math.min(max, Math.max(min, Number.isFinite(value) ? value : fallback));
};
let lastLineStyle = {color: '#111827', width: 4, pattern: 'solid', cap: 'butt', opacity: 1};
let lineDrawing = null;

function syncLineProps(object) {
    const selected = IdCardShapes.isLine(object);
    shapeInput('lineProps').style.display = selected ? 'block' : 'none';
    if (!selected) return;
    const style = IdCardShapes.lineStyle(object);
    shapeInput('lineColor').value = style.color;
    shapeInput('lineThickness').value = style.width;
    shapeInput('lineLength').value = Math.round(object.width * object.scaleX * 10) / 10;
    shapeInput('lineAngle').value = Math.round(((object.angle % 360 + 360) % 360) * 10) / 10;
    shapeInput('lineStyle').value = style.pattern;
    shapeInput('lineCap').value = style.pattern === 'dotted' ? 'round' : style.cap;
    shapeInput('lineCap').disabled = style.pattern === 'dotted';
    shapeInput('lineOpacity').value = Math.round(style.opacity * 100);
    shapeInput('lineOpacityValue').textContent = Math.round(style.opacity * 100) + '%';
}

function syncShapeProps(object) {
    syncLineProps(object);
    const selected = IdCardShapes.isShape(object) && !IdCardShapes.isLine(object);
    shapeProps.style.display = selected ? 'block' : 'none';
    if (!selected) return;
    const fill = IdCardShapes.fillStyle(object), gradient = ['linear', 'radial'].includes(fill.mode);
    shapeInput('shapeTitle').textContent = IdCardShapes.label(object);
    shapeInput('shapeWidth').value = Math.round(object.width * object.scaleX * 10) / 10;
    shapeInput('shapeHeight').value = Math.round(object.height * object.scaleY * 10) / 10;
    shapeInput('shapeFillMode').value = fill.mode;
    shapeInput('shapeFillColor').value = fill.color;
    shapeInput('shapeSolidFields').style.display = fill.mode === 'solid' ? 'block' : 'none';
    shapeInput('shapeGradientFields').style.display = gradient ? 'block' : 'none';
    shapeInput('shapeGradientColor1').value = fill.color1;
    shapeInput('shapeGradientColor2').value = fill.color2;
    shapeInput('shapeGradientAngle').value = fill.angle;
    shapeInput('shapeGradientAngleValue').textContent = fill.angle + '°';
    shapeInput('shapeGradientAngleFields').style.display = fill.mode === 'linear' ? 'block' : 'none';
    shapeInput('shapeRadiusFields').style.display = object.data.shapeKind === 'ellipse' ? 'none' : 'block';
    const radii = IdCardShapes.cornerRadii(object), values = Object.values(radii);
    const mixed = values.some(value => value !== values[0]);
    shapeInput('shapeRadius').value = values[0] || 0;
    shapeInput('shapeRadiusValue').textContent = mixed ? 'Mixed' : (values[0] || 0) + '%';
    document.querySelectorAll('[data-shape-corner-field]').forEach(field => {
        const key = field.dataset.shapeCornerField;
        field.hidden = !Object.hasOwn(radii, key);
        const input = field.querySelector('input');
        input.value = radii[key] || 0;
        shapeInput(input.id + 'Value').textContent = (radii[key] || 0) + '%';
    });
    const border = object.strokeWidth > 0;
    shapeInput('shapeBorderEnable').checked = border;
    shapeInput('shapeBorderColor').value = object.stroke || '#111827';
    shapeInput('shapeBorderWidth').value = border ? object.strokeWidth : 2;
    shapeInput('shapeBorderColor').disabled = !border;
    shapeInput('shapeBorderWidth').disabled = !border;
}

document.querySelectorAll('[data-add-shape]').forEach(button => button.addEventListener('click', () => {
    cardNavigation.setTool('select');
    const object = IdCardShapes.create(button.dataset.addShape, Math.min(CARD_WIDTH_PX, CARD_HEIGHT_PX) * 0.4);
    if (IdCardShapes.isLine(object)) IdCardShapes.setLineStyle(object, lastLineStyle);
    addObjectCentered(object);
    syncPropsPanelFromObject(canvas.getActiveObject());
}));

function updateShape(edit) {
    const object = canvas.getActiveObject();
    if (!IdCardShapes.isShape(object) || IdCardShapes.isLine(object)) return;
    edit(object);
    object.dirty = true;
    object.setCoords();
    canvas.requestRenderAll();
    syncShapeProps(object);
    pushHistoryDebounced();
}
['shapeFillMode', 'shapeFillColor', 'shapeGradientColor1', 'shapeGradientColor2', 'shapeGradientAngle'].forEach(id => {
    shapeInput(id).addEventListener(id === 'shapeFillMode' ? 'change' : 'input', () => updateShape(object => {
        IdCardShapes.setFill(object, {mode: shapeInput('shapeFillMode').value, color: shapeInput('shapeFillColor').value,
            color1: shapeInput('shapeGradientColor1').value, color2: shapeInput('shapeGradientColor2').value,
            angle: shapeNumber('shapeGradientAngle', 0, 360, 0)});
    }));
});
shapeInput('shapeRadius').addEventListener('input', () => updateShape(object => {
    object.data.cornerRadius = shapeNumber('shapeRadius', 0, 100, 0);
    delete object.data.cornerRadii;
}));
document.querySelectorAll('[data-shape-corner]').forEach(input => input.addEventListener('input', () => updateShape(object => {
    IdCardShapes.setCornerRadius(object, input.dataset.shapeCorner, shapeNumber(input.id, 0, 100, 0));
})));
['shapeBorderEnable', 'shapeBorderColor', 'shapeBorderWidth'].forEach(id => {
    shapeInput(id).addEventListener(id === 'shapeBorderEnable' ? 'change' : 'input', () => updateShape(object => {
        object.set({stroke: shapeInput('shapeBorderColor').value,
            strokeWidth: shapeInput('shapeBorderEnable').checked ? shapeNumber('shapeBorderWidth', 0.1, 100, 2) : 0});
    }));
});
['shapeWidth', 'shapeHeight'].forEach(id => shapeInput(id).addEventListener('change', () => updateShape(object => {
    IdCardShapes.normalizeSize(object);
    object.set(id === 'shapeWidth' ? 'width' : 'height', shapeNumber(id, 1, 6000, 100));
})));
canvas.on('object:scaling', event => {
    if (IdCardShapes.isShape(event.target)) syncShapeProps(event.target);
});
['object:resizing', 'object:rotating'].forEach(event => canvas.on(event, ({target}) => {
    if (IdCardShapes.isLine(target)) syncLineProps(target);
}));

function updateLine(edit) {
    const object = canvas.getActiveObject();
    if (!IdCardShapes.isLine(object)) return;
    edit(object);
    lastLineStyle = IdCardShapes.lineStyle(object);
    object.setCoords(); canvas.requestRenderAll(); syncLineProps(object); pushHistoryDebounced();
}
['lineColor', 'lineThickness', 'lineStyle', 'lineCap', 'lineOpacity'].forEach(id => {
    shapeInput(id).addEventListener(['lineStyle', 'lineCap'].includes(id) ? 'change' : 'input', () => updateLine(object => {
        IdCardShapes.setLineStyle(object, {color: shapeInput('lineColor').value, width: shapeNumber('lineThickness', 0.1, 100, 4),
            pattern: shapeInput('lineStyle').value, cap: id === 'lineCap' ? shapeInput('lineCap').value : IdCardShapes.lineStyle(object).cap,
            opacity: shapeNumber('lineOpacity', 0, 100, 100) / 100});
    }));
});
['lineLength', 'lineAngle'].forEach(id => shapeInput(id).addEventListener('change', () => updateLine(object => {
    const center = object.getCenterPoint();
    IdCardShapes.normalizeSize(object);
    object.set(id === 'lineLength' ? 'width' : 'angle', shapeNumber(id, id === 'lineLength' ? 1 : 0, id === 'lineLength' ? 6000 : 360, 0));
    object.setPositionByOrigin(center, 'center', 'center');
})));

shapeInput('btnDrawLine').addEventListener('click', () => cardNavigation.setTool('line'));
canvas.on('view:tool-changed', ({tool}) => {
    shapeInput('btnDrawLine').classList.toggle('active', tool === 'line');
    shapeInput('btnDrawLine').setAttribute('aria-pressed', String(tool === 'line'));
});
function clearLinePreview() {
    lineDrawing = null;
    canvas.clearContext(canvas.contextTop); canvas.requestRenderAll();
}
function moveLinePreview(event) {
    if (!lineDrawing) return;
    const end = IdCardShapes.snapLinePoint(lineDrawing.start, canvas.getPointer(event), event.shiftKey);
    lineDrawing.length = Math.hypot(end.x - lineDrawing.start.x, end.y - lineDrawing.start.y);
    IdCardShapes.setLineEndpoints(lineDrawing.object, lineDrawing.start, end);
    canvas.requestRenderAll();
}
canvas.on('line:draw:start', ({e}) => {
    const start = canvas.getPointer(e);
    if (start.x < 0 || start.y < 0 || start.x > CARD_WIDTH_PX || start.y > CARD_HEIGHT_PX) return;
    document.activeElement?.blur();
    canvas.discardActiveObject();
    const object = IdCardShapes.create('line', 20);
    IdCardShapes.setLineStyle(object, lastLineStyle);
    lineDrawing = {start, object, length: 0};
    moveLinePreview(e);
});
canvas.on('line:draw:move', ({e}) => moveLinePreview(e));
canvas.on('line:draw:cancel', clearLinePreview);
canvas.on('after:render', () => {
    if (!lineDrawing) return;
    // Preview lives on the interaction layer, outside design JSON and undo history.
    const ctx = canvas.contextTop;
    canvas.clearContext(ctx); ctx.save(); ctx.transform(...canvas.viewportTransform);
    lineDrawing.object.render(ctx); ctx.restore();
});
canvas.on('line:draw:end', ({e}) => {
    moveLinePreview(e);
    const finished = lineDrawing;
    clearLinePreview(); cardNavigation.setTool('select');
    if (!finished || finished.length < 2) return;
    pushHistory(); canvas.add(finished.object); canvas.setActiveObject(finished.object);
    syncPropsPanelFromObject(finished.object); canvas.requestRenderAll(); pushHistory();
});
syncShapeProps(canvas.getActiveObject());
