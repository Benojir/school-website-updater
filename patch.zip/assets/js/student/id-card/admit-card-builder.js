/* Admit-specific tools; all normal editor, history, layers and templates stay shared. */
(() => {
    const fields = {
        routine_serial: 'Subject Number', routine_subject: 'Subject Name',
        routine_written_date: 'Written Date', routine_written_time: 'Written Time',
        routine_oral_date: 'Oral / Practical Date', routine_oral_time: 'Oral / Practical Time'
    };
    const group = document.createElement('optgroup'); group.label = 'Automatic routine subject row';
    Object.entries(fields).forEach(([key, label]) => group.appendChild(new Option(label, '{{' + key + '}}')));
    tableField('tableCellVariable').appendChild(group);

    const panel = document.createElement('div'); panel.className = 'prop-group';
    panel.innerHTML = '<p class="small">The first row contains headings. The second row repeats for every subject. Add or remove columns and format cells below. The canvas shows six sample subjects.</p>' +
        '<label for="routineAreaHeight">Routine area height (px)</label><input id="routineAreaHeight" type="number" min="40" max="3000" class="form-control form-control-sm">';
    tableField('tableProps').prepend(panel);
    const sync = syncTableProps;
    syncTableProps = function (obj) {
        sync(obj); panel.hidden = !obj?.data?.examRoutine;
        if (!panel.hidden) tableField('routineAreaHeight').value = obj.data.routineHeight || 600;
    };
    tableField('routineAreaHeight').addEventListener('change', event => {
        if (!selectedTable?.data.examRoutine || !event.target.checkValidity()) return;
        selectedTable.data.routineHeight = Number(event.target.value);
        selectedTable.refreshTable(); canvas.requestRenderAll(); pushHistory();
    });
    canvas.on('object:resizing', ({target}) => {
        if (target === selectedTable && target.data.examRoutine) {
            tableField('routineAreaHeight').value = target.data.routineHeight;
        }
    });

    function routineObject(width, height, scale = 1) {
        const table = tableModel.create(2, 6, width);
        table.columns = [0.24, 0.15, 0.18, 0.15, 0.18, 0.10].map(ratio => width * ratio);
        table.rows = [58 * scale, 70 * scale];
        Object.assign(table.style, {fontFamily: 'Arial', fontSize: 26 * scale, padding: 6 * scale, textAlign: 'center'});
        ['Subject', 'Written Date', 'Written Time', 'Oral Date', 'Oral Time', 'Signature'].forEach((text, c) => {
            table.cells[0][c] = {...table.cells[0][c], text, style: {fontWeight: 'bold', background: '#e7eef9', fill: '#203a60'}};
        });
        ['routine_subject', 'routine_written_date', 'routine_written_time', 'routine_oral_date', 'routine_oral_time'].forEach((key, c) => {
            table.cells[1][c].text = '{{' + key + '}}';
        });
        return new fabric.IdCardTable({data: {type: 'table', examRoutine: true, routineHeight: height, table}});
    }
    document.getElementById('btnAddExamRoutine').addEventListener('click', () => {
        if (!canvasReady || templateBusy || isSwappingSide || isRestoringHistory) return;
        const scale = Math.min(CARD_WIDTH_PX / 2100, CARD_HEIGHT_PX / 1485);
        addObjectCentered(routineObject(CARD_WIDTH_PX * 0.94, CARD_HEIGHT_PX * 0.4, scale));
        syncPropsPanelFromObject(canvas.getActiveObject()); pushHistory();
    });
    function image(type, label, width, height) {
        const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' + width + '" height="' + height + '"><rect width="100%" height="100%" fill="#e7eef9"/><text x="50%" y="50%" text-anchor="middle" dominant-baseline="middle" font-family="Arial" font-size="20" fill="#203a60">' + label + '</text></svg>';
        return new Promise(resolve => fabric.Image.fromURL('data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg), img => {
            img.set({data: {type, borderRadius: 0}}); resolve(img);
        }));
    }
    [
        ['btnAddPrincipalSign', 'principal-signature', 'Signature', 180, 60],
        ['btnAddHeadmasterSign', 'headmaster-signature', 'Head Master Sign', 180, 90],
        ['btnAddSchoolStamp', 'school-stamp', 'School Stamp', 140, 140]
    ].forEach(([id, type, label, width, height]) => {
        document.getElementById(id).addEventListener('click', async () => {
            if (!canvasReady || templateBusy || isSwappingSide || isRestoringHistory) return;
            addObjectCentered(await image(type, label, width, height)); pushHistory();
        });
    });
    document.getElementById('btnAdmitStarter').addEventListener('click', async () => {
        if (!canvasReady || templateBusy || isSwappingSide || isRestoringHistory) return;
        if (canvas.getObjects().length && !window.confirm('Replace the current side with a starter admit-card layout?')) return;
        const k = Math.min(CARD_WIDTH_PX / 2100, CARD_HEIGHT_PX / 1485), w = CARD_WIDTH_PX, h = CARD_HEIGHT_PX;
        setTemplateBusy(true);
        try {
            const [logo, photo, sign] = await Promise.all([image('school-logo', 'Logo', 140, 140), image('student-photo', 'Student Photo', 200, 240), image('principal-signature', 'Signature', 180, 60)]);
            canvas.clear(); canvas.backgroundColor = '#ffffff';
            function text(value, x, y, width, fontSize, variable = false, extra = {}) {
                const label = variable ? [...document.getElementById('dynamicVarSelect').options].find(o => o.value === '{{' + value + '}}')?.textContent || value : value;
                canvas.add(new fabric.Textbox(label, {left: x, top: y, width, fontSize, fontFamily: 'Arial', fill: '#203a60', ...extra,
                    data: variable ? {type: 'dynamic-text', variable: '{{' + value + '}}', maxLines: 0} : {type: 'static-text', baseText: value}}));
            }
            logo.set({left: 40 * k, top: 35 * k, scaleX: k, scaleY: k}); canvas.add(logo);
            text('school_name', 210*k, 35*k, w-260*k, 54*k, true, {fontWeight: 'bold'});
            text('school_address', 210*k, 110*k, w-260*k, 30*k, true);
            text('school_contact_no', 210*k, 155*k, w-260*k, 26*k, true);
            text('ADMIT CARD', 40*k, 220*k, w-80*k, 48*k, false, {textAlign: 'center', fontWeight: 'bold'});
            const info = tableModel.create(6, 2, w-400*k);
            info.columns = [260*k, w-660*k]; info.rows.fill(55*k);
            Object.assign(info.style, {fontFamily: 'Arial', fontSize: 30*k, borderWidth: 0, background: 'transparent', padding: 4*k});
            [['Student Name','student_name'],["Father's Name",'father_name'],['Class & Section','class'],['Roll No','roll_no'],['Exam','exam_name'],['Center','exam_center']].forEach(([label,key], r) => {
                info.cells[r][0].text = label; info.cells[r][1].text = '{{'+key+'}}';
            });
            canvas.add(new fabric.IdCardTable({left:40*k,top:310*k,data:{type:'table',table:info}}));
            photo.set({left:w-280*k,top:315*k,scaleX:k,scaleY:k});canvas.add(photo);
            const routine = routineObject(w-80*k, Math.max(120*k, h-930*k), k);
            routine.set({left:40*k,top:680*k});canvas.add(routine);
            text('Bring this admit card to the examination hall.',40*k,h-230*k,w-80*k,25*k);
            sign.set({left:w-300*k,top:h-145*k,scaleX:k,scaleY:k});canvas.add(sign);
            text('Exam Controller',40*k,h-65*k,400*k,24*k);
            text('Principal Signature',w-420*k,h-65*k,380*k,24*k,false,{textAlign:'center'});
            fitCanvasToStage(); canvas.discardActiveObject(); syncPropsPanelFromObject(null); pushHistory();
        } catch (error) { showErrorAlert(error.message, 'Could not insert layout'); }
        finally { setTemplateBusy(false); }
    });
})();
