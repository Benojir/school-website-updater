/* Cell editing and formatting UI; table rendering lives in id-card-table.js. */
let selectedTable = null;
let tableSelectionStart = {r: 0, c: 0};
let tableSelectionEnd = {r: 0, c: 0};
const tableModel = IdCardTableModel;
const tableField = id => document.getElementById(id);
const tableStyleFields = document.querySelectorAll('[data-table-style]');
FONT_LIST.forEach(font => tableField('tableFontFamily').add(new Option(font, font)));
tableField('tableCellVariable').innerHTML = document.getElementById('dynamicVarSelect').innerHTML;

function tableSelectionBox() {
    return tableModel.range(selectedTable.data.table, tableSelectionStart, tableSelectionEnd);
}
function selectTableCell(r, c, extend) {
    const owner = tableModel.owner(selectedTable.data.table, r, c);
    if (!owner) return;
    if (!extend) tableSelectionStart = {r: owner.r, c: owner.c};
    tableSelectionEnd = {r: owner.r, c: owner.c};
    renderTablePanel();
}
function syncTableProps(obj) {
    tableField('tableProps').style.display = obj?.type === 'id-card-table' ? 'block' : 'none';
    if (!obj || obj.type !== 'id-card-table') { selectedTable = null; return; }
    if (obj !== selectedTable) {
        selectedTable = obj; tableSelectionStart = {r: 0, c: 0}; tableSelectionEnd = {r: 0, c: 0};
    }
    renderTablePanel();
}
function renderTablePanel() {
    if (!selectedTable) return;
    const model = selectedTable.data.table;
    const box = tableSelectionBox();
    const grid = document.createElement('table');
    const body = document.createElement('tbody'); grid.appendChild(body);
    const anchors = new Map(tableModel.anchors(model).map(a => [a.r + ':' + a.c, a]));
    model.rows.forEach((_, r) => {
        const tr = document.createElement('tr'); body.appendChild(tr);
        model.columns.forEach((_, c) => {
            const a = anchors.get(r + ':' + c); if (!a) return;
            const td = document.createElement('td'); td.rowSpan = a.cell.rowSpan; td.colSpan = a.cell.colSpan;
            td.textContent = a.cell.text || 'R' + (r + 1) + ' C' + (c + 1);
            td.classList.toggle('selected', r >= box.r1 && r <= box.r2 && c >= box.c1 && c <= box.c2);
            td.tabIndex = 0; td.setAttribute('aria-label', 'Row ' + (r + 1) + ', column ' + (c + 1));
            td.addEventListener('click', event => selectTableCell(r, c, event.shiftKey));
            td.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); selectTableCell(r, c, event.shiftKey); } });
            tr.appendChild(td);
        });
    });
    tableField('tableCellGrid').replaceChildren(grid);
    const cell = model.cells[box.r1][box.c1];
    tableField('btnTableUnmerge').disabled = !tableModel.anchors(model).some(a =>
        a.r >= box.r1 && a.r <= box.r2 && a.c >= box.c1 && a.c <= box.c2 && (a.cell.rowSpan > 1 || a.cell.colSpan > 1));
    tableField('tableCellText').value = cell.text;
    tableField('tableSelectionLabel').textContent = 'Cell R' + (box.r1 + 1) + ' C' + (box.c1 + 1) + ' text' +
        (box.r1 !== box.r2 || box.c1 !== box.c2 ? ' (range selected)' : '');
    tableField('tableColumnWidth').value = model.columns[box.c1];
    tableField('tableRowHeight').value = model.rows[box.r1];
    const style = tableField('tableStyleScope').value === 'table' ? model.style : {...model.style, ...cell.style};
    tableStyleFields.forEach(field => {
        const value = style[field.dataset.tableStyle];
        if (field.type === 'checkbox') field.checked = !!value;
        else if (field.id !== 'tableBackground' || value !== 'transparent') field.value = value;
    });
    tableField('tableBackgroundTransparent').checked = style.background === 'transparent';
    tableField('tableBackground').disabled = style.background === 'transparent';
    tableField('tableBold').checked = style.fontWeight === 'bold';
    tableField('tableItalic').checked = style.fontStyle === 'italic';
}
function mutateTable(change, rebuildPanel = true) {
    if (!selectedTable || canvas.getActiveObject() !== selectedTable || isSwappingSide || isRestoringHistory) return;
    try {
        change(selectedTable.data.table, tableSelectionBox());
        selectedTable.refreshTable(); canvas.requestRenderAll(); pushHistory(); refreshLayersPanel();
        if (rebuildPanel) renderTablePanel();
    } catch (error) { showErrorAlert(error.message, 'Table'); }
}
function applyTableStyle(key, value) {
    mutateTable((model, box) => {
        if (tableField('tableStyleScope').value === 'table') {
            model.style[key] = value;
            // Whole-table formatting overrides earlier cell formatting for this property.
            model.cells.forEach(row => row.forEach(cell => delete cell.style[key]));
        } else {
            for (let r = box.r1; r <= box.r2; r++) for (let c = box.c1; c <= box.c2; c++) model.cells[r][c].style[key] = value;
        }
    }, false);
}
tableStyleFields.forEach(field => field.addEventListener('change', () => {
    if (field.type === 'number' && !field.checkValidity()) { renderTablePanel(); return; }
    applyTableStyle(field.dataset.tableStyle, field.type === 'number' ? Number(field.value) : field.type === 'checkbox' ? field.checked : field.value);
}));
tableField('tableBold').addEventListener('change', event => applyTableStyle('fontWeight', event.target.checked ? 'bold' : 'normal'));
tableField('tableItalic').addEventListener('change', event => applyTableStyle('fontStyle', event.target.checked ? 'italic' : 'normal'));
tableField('tableStyleScope').addEventListener('change', renderTablePanel);
tableField('tableBackgroundTransparent').addEventListener('change', event => {
    applyTableStyle('background', event.target.checked ? 'transparent' : tableField('tableBackground').value);
    renderTablePanel();
});
tableField('tableCellText').addEventListener('input', event => {
    mutateTable((model, box) => { model.cells[box.r1][box.c1].text = event.target.value; }, false);
    // Refresh the grid label without replacing the focused textarea/caret.
    const box = selectedTable && tableSelectionBox();
    if (box) {
        const index = tableModel.anchors(selectedTable.data.table).findIndex(a => a.r === box.r1 && a.c === box.c1);
        const td = tableField('tableCellGrid').querySelectorAll('td')[index];
        if (td) td.textContent = event.target.value || 'R' + (box.r1 + 1) + ' C' + (box.c1 + 1);
    }
});
tableField('btnTableVariable').addEventListener('click', () => {
    const field = tableField('tableCellText'), token = tableField('tableCellVariable').value;
    const start = field.selectionStart, end = field.selectionEnd;
    field.value = field.value.slice(0, start) + token + field.value.slice(end);
    field.dispatchEvent(new Event('input')); field.focus(); field.setSelectionRange(start + token.length, start + token.length);
});
[['tableColumnWidth', 'columns', 'c'], ['tableRowHeight', 'rows', 'r']].forEach(([id, axis, prefix]) => {
    tableField(id).addEventListener('change', event => {
        if (!event.target.checkValidity()) { renderTablePanel(); return; }
        mutateTable((model, box) => {
            for (let i = box[prefix + '1']; i <= box[prefix + '2']; i++) model[axis][i] = Number(event.target.value);
        });
    });
});
[['btnTableAddRow', 'row', false], ['btnTableRemoveRow', 'row', true],
 ['btnTableAddColumn', 'column', false], ['btnTableRemoveColumn', 'column', true]].forEach(([id, axis, remove]) => {
    tableField(id).addEventListener('click', () => mutateTable((model, box) => {
        const prefix = axis === 'row' ? 'r' : 'c';
        tableModel.editAxis(model, axis, remove ? box[prefix + '1'] : box[prefix + '2'] + 1, remove);
        tableSelectionStart = {r: Math.min(box.r1, model.rows.length - 1), c: Math.min(box.c1, model.columns.length - 1)};
        tableSelectionEnd = {...tableSelectionStart};
    }));
});
tableField('btnTableMerge').addEventListener('click', () => mutateTable((model, box) => tableModel.merge(model, box)));
tableField('btnTableUnmerge').addEventListener('click', () => mutateTable((model, box) => {
    tableModel.split(model, box); tableSelectionEnd = {...tableSelectionStart};
}));
tableField('btnTableSplit').addEventListener('click', () => mutateTable((model, box) => {
    const rows = tableField('tableSplitRows'), cols = tableField('tableSplitColumns');
    if (!rows.checkValidity() || !cols.checkValidity()) throw new Error('Enter whole-number row and column counts within the shown limits.');
    const selected = tableModel.owner(model, box.r1, box.c1);
    if (box.r2 !== selected.r + selected.cell.rowSpan - 1 || box.c2 !== selected.c + selected.cell.colSpan - 1) {
        throw new Error('Select one cell to split. Click it without holding Shift.');
    }
    tableSelectionStart = tableModel.subdivide(model, selected.r, selected.c, Number(rows.value), Number(cols.value));
    tableSelectionEnd = {...tableSelectionStart};
}));
tableField('btnAddTable').addEventListener('click', () => {
    if (isSwappingSide || isRestoringHistory || !canvasReady) return;
    const rows = tableField('newTableRows'), cols = tableField('newTableColumns');
    if (!rows.checkValidity() || !cols.checkValidity() || !rows.value || !cols.value) { showErrorAlert('Choose 1–20 rows and 1–12 columns.', 'Table size'); return; }
    const model = tableModel.create(Number(rows.value), Number(cols.value), Math.min(400, CARD_WIDTH_PX - 40));
    if (model.rows.length >= 3 && model.columns.length >= 2) {
        model.cells[0][0].text = 'Name'; model.cells[0][1].text = CARD_PERSON.nameVariable;
        model.cells[1][0].text = CARD_PERSON.detailLabel; model.cells[1][1].text = CARD_PERSON.detailVariable;
        model.cells[2][0].text = 'ID'; model.cells[2][1].text = CARD_PERSON.idVariable;
    }
    addObjectCentered(new fabric.IdCardTable({data: {type: 'table', table: model}}));
    syncTableProps(canvas.getActiveObject()); pushHistory();
});
function selectTableCellAtPointer(event, focusText) {
    if (event.target?.type !== 'id-card-table') return;
    if (!focusText && (canvas.getActiveObject() !== event.target || (event.transform && event.transform.action !== 'drag'))) return;
    canvas.setActiveObject(event.target); syncPropsPanelFromObject(event.target);
    const point = canvas.getPointer(event.e);
    const local = fabric.util.transformPoint(point, fabric.util.invertTransform(event.target.calcTransformMatrix()));
    let x = local.x + event.target.width / 2, y = local.y + event.target.height / 2;
    if (x < 0 || y < 0 || x > event.target.width || y > event.target.height) return;
    const model = event.target.data.table;
    let c = 0, r = 0;
    while (c < model.columns.length - 1 && x >= model.columns[c]) { x -= model.columns[c]; c++; }
    while (r < model.rows.length - 1 && y >= model.rows[r]) { y -= model.rows[r]; r++; }
    selectTableCell(r, c, event.e.shiftKey);
    if (focusText) tableField('tableCellText').focus();
}
canvas.on('mouse:down', event => selectTableCellAtPointer(event, false));
canvas.on('mouse:dblclick', event => selectTableCellAtPointer(event, true));
