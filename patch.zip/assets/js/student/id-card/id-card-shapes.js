/* Shared shape geometry for the card editor and batch printer (Fabric 5). */
(function (root) {
    'use strict';
    const fabric = root.fabric;
    const clone = value => JSON.parse(JSON.stringify(value));
    const limit = (value, min, max, fallback) => Number.isFinite(Number(value))
        ? Math.min(max, Math.max(min, Number(value))) : fallback;
    const labels = {rectangle: 'Rectangle', triangle: 'Triangle', ellipse: 'Circle / Oval', line: 'Straight Line'};
    const cornersByKind = {rectangle: ['topLeft', 'topRight', 'bottomLeft', 'bottomRight'],
        triangle: ['top', 'bottomLeft', 'bottomRight']};
    const defaultFill = {mode: 'solid', color: '#2563eb', color1: '#2563eb', color2: '#a855f7', angle: 0};

    function cornerRadii(object) {
        // Older templates have one radius; missing individual corners inherit it.
        const fallback = limit(object.data.cornerRadius, 0, 100, 0);
        return Object.fromEntries((cornersByKind[object.data.shapeKind] || []).map(key =>
            [key, limit(object.data.cornerRadii?.[key], 0, 100, fallback)]));
    }
    function setCornerRadius(object, key, value) {
        const radii = cornerRadii(object);
        if (!Object.hasOwn(radii, key)) return;
        object.data.cornerRadii = {...radii, [key]: limit(value, 0, 100, 0)};
        object.dirty = true;
    }

    function buildFill(style) {
        if (style.mode === 'none') return null;
        if (style.mode === 'solid') return style.color;
        const radial = style.mode === 'radial';
        const angle = limit(style.angle, 0, 360, 0) * Math.PI / 180;
        const x = Math.cos(angle) / 2, y = Math.sin(angle) / 2;
        return new fabric.Gradient({
            type: radial ? 'radial' : 'linear', gradientUnits: 'percentage',
            coords: radial ? {x1: 0.5, y1: 0.5, r1: 0, x2: 0.5, y2: 0.5, r2: 0.5}
                : {x1: 0.5 - x, y1: 0.5 - y, x2: 0.5 + x, y2: 0.5 + y},
            colorStops: [{offset: 0, color: style.color1}, {offset: 1, color: style.color2}]
        });
    }

    function isLine(object) { return object?.type === 'id-card-shape' && object.data?.shapeKind === 'line'; }
    function lineEndpoints(object) {
        const matrix = object.calcTransformMatrix();
        return [-1, 1].map(sign => fabric.util.transformPoint(new fabric.Point(sign * object.width / 2, 0), matrix));
    }
    function snapLinePoint(start, end, snap) {
        if (!snap) return end;
        const dx = end.x - start.x, dy = end.y - start.y, length = Math.hypot(dx, dy);
        const angle = Math.round(Math.atan2(dy, dx) / (Math.PI / 4)) * Math.PI / 4;
        return {x: start.x + Math.cos(angle) * length, y: start.y + Math.sin(angle) * length};
    }
    function setLineEndpoints(object, start, end) {
        object.set({width: Math.max(1, Math.hypot(end.x - start.x, end.y - start.y)), height: 1,
            scaleX: 1, scaleY: 1, skewX: 0, skewY: 0, flipX: false, flipY: false,
            angle: Math.atan2(end.y - start.y, end.x - start.x) * 180 / Math.PI,
            originX: 'center', originY: 'center', left: (start.x + end.x) / 2, top: (start.y + end.y) / 2});
        object.setCoords();
    }
    function lineStyle(object) {
        return {color: object.stroke || '#111827', width: object.strokeWidth || 4,
            pattern: object.data.lineStyle || 'solid', cap: object.data.lineCap || 'butt', opacity: object.opacity};
    }
    function setLineStyle(object, changes) {
        const style = {...lineStyle(object), ...changes};
        const width = limit(style.width, 0.1, 100, 4);
        const pattern = ['solid', 'dashed', 'dotted'].includes(style.pattern) ? style.pattern : 'solid';
        const cap = ['butt', 'round', 'square'].includes(style.cap) ? style.cap : 'butt';
        object.data.lineStyle = pattern; object.data.lineCap = cap;
        object.set({fill: null, stroke: style.color, strokeWidth: width, strokeUniform: true,
            strokeDashArray: pattern === 'dashed' ? [width * 4, width * 2] : pattern === 'dotted' ? [0, width * 2] : null,
            strokeLineCap: pattern === 'dotted' ? 'round' : cap, opacity: limit(style.opacity, 0, 1, 1)});
        object.dirty = true;
    }
    function endpointControl(index) {
        return new fabric.Control({x: index ? 0.5 : -0.5, y: 0, cursorStyle: 'crosshair', actionName: 'resizing',
            positionHandler: function (dim, matrix, object) {
                // Fabric's control matrix removes zoom; endpoint geometry needs the full view transform.
                const view = fabric.util.multiplyTransformMatrices(object.getViewportTransform(), object.calcTransformMatrix());
                return fabric.util.transformPoint(new fabric.Point((index ? 1 : -1) * object.width / 2, 0), view);
            },
            actionHandler: fabric.controlsUtils.wrapWithFireEvent('resizing', function (event, transform, x, y) {
                const object = transform.target;
                if (object.lockScalingX || object.lockRotation) return false;
                transform.lineAnchor ??= lineEndpoints(object)[1 - index];
                const end = snapLinePoint(transform.lineAnchor, {x, y}, event.shiftKey);
                if (index) setLineEndpoints(object, transform.lineAnchor, end);
                else setLineEndpoints(object, end, transform.lineAnchor);
                return true;
            })});
    }

    fabric.IdCardShape = fabric.util.createClass(fabric.Object, {
        type: 'id-card-shape',
        initialize: function (options) {
            options = options || {};
            this.callSuper('initialize', {width: 220, height: 140, fill: '#2563eb', stroke: '#111827',
                strokeWidth: 0, strokeUniform: true, strokeLineJoin: 'round', ...options,
                data: {type: 'shape', shapeKind: 'rectangle', cornerRadius: 0, ...clone(options.data || {})}});
            if (isLine(this)) {
                this.set({height: 1, fill: null, hasBorders: false});
                this.controls = {lineStart: endpointControl(0), lineEnd: endpointControl(1), mtr: this.controls.mtr};
            }
        },
        toObject: function (properties) {
            return {...this.callSuper('toObject', properties), data: clone(this.data)};
        },
        _render: function (ctx) {
            const w = this.width, h = this.height, x = -w / 2, y = -h / 2;
            const radii = cornerRadii(this);
            ctx.beginPath();
            if (isLine(this)) {
                ctx.moveTo(x, 0); ctx.lineTo(x + w, 0);
                this._renderStroke(ctx);
                return;
            } else if (this.data.shapeKind === 'ellipse') {
                ctx.ellipse(0, 0, w / 2, h / 2, 0, 0, Math.PI * 2);
            } else if (this.data.shapeKind === 'triangle') {
                const points = [{x: 0, y}, {x: w / 2, y: h / 2}, {x, y: h / 2}];
                // Capping each corner at the inradius keeps adjacent arcs from overlapping.
                const inradius = (w * h / 2) / (w / 2 + Math.hypot(w / 2, h));
                const radiusKeys = ['top', 'bottomRight', 'bottomLeft'];
                const corners = points.map((p, i) => {
                    const radius = inradius * radii[radiusKeys[i]] / 100 * 0.999;
                    const prev = points[(i + 2) % 3], next = points[(i + 1) % 3];
                    const a = Math.hypot(prev.x - p.x, prev.y - p.y), b = Math.hypot(next.x - p.x, next.y - p.y);
                    const u = {x: (prev.x - p.x) / a, y: (prev.y - p.y) / a};
                    const v = {x: (next.x - p.x) / b, y: (next.y - p.y) / b};
                    const halfAngle = Math.acos(Math.max(-1, Math.min(1, u.x * v.x + u.y * v.y))) / 2;
                    const distance = radius / Math.tan(halfAngle);
                    return {p, radius, start: {x: p.x + u.x * distance, y: p.y + u.y * distance},
                        end: {x: p.x + v.x * distance, y: p.y + v.y * distance}};
                });
                ctx.moveTo(corners[0].start.x, corners[0].start.y);
                corners.forEach(({p, radius, start, end}) => {
                    ctx.lineTo(start.x, start.y);
                    if (radius > 0) ctx.arcTo(p.x, p.y, end.x, end.y, radius);
                    else ctx.lineTo(p.x, p.y);
                });
            } else {
                const maxRadius = Math.min(w, h) / 2;
                const tl = maxRadius * radii.topLeft / 100, tr = maxRadius * radii.topRight / 100;
                const bl = maxRadius * radii.bottomLeft / 100, br = maxRadius * radii.bottomRight / 100;
                ctx.moveTo(x + tl, y);
                ctx.lineTo(x + w - tr, y); ctx.arcTo(x + w, y, x + w, y + tr, tr);
                ctx.lineTo(x + w, y + h - br); ctx.arcTo(x + w, y + h, x + w - br, y + h, br);
                ctx.lineTo(x + bl, y + h); ctx.arcTo(x, y + h, x, y + h - bl, bl);
                ctx.lineTo(x, y + tl); ctx.arcTo(x, y, x + tl, y, tl);
            }
            ctx.closePath();
            this._renderPaintInOrder(ctx);
        }
    });
    fabric.IdCardShape.fromObject = function (object, callback) {
        fabric.Object._fromObject('IdCardShape', object, callback);
    };

    function isShape(object) { return object?.type === 'id-card-shape'; }
    function fillStyle(object) { return {...defaultFill, ...object.data?.shapeFill}; }
    function setFill(object, style) {
        object.data.shapeFill = {...fillStyle(object), ...style};
        object.set('fill', buildFill(object.data.shapeFill));
        object.dirty = true;
    }
    function create(kind, size) {
        const edge = limit(size, 20, 3000, 220);
        const object = new fabric.IdCardShape({width: edge, height: kind === 'rectangle' ? edge * 0.65 : edge,
            data: {shapeKind: labels[kind] ? kind : 'rectangle'}});
        if (kind === 'line') setLineStyle(object, {width: 4});
        else setFill(object, defaultFill);
        return object;
    }
    function normalizeSize(object) {
        if (!isShape(object) || object.group) return;
        const center = object.getCenterPoint();
        object.set({width: Math.max(1, object.width * object.scaleX), height: isLine(object) ? 1 : Math.max(1, object.height * object.scaleY),
            scaleX: 1, scaleY: 1});
        object.setPositionByOrigin(center, 'center', 'center');
        object.setCoords();
    }
    function getStyle(object) {
        if (isLine(object)) return {line: true, ...lineStyle(object)};
        return {fill: fillStyle(object), cornerRadius: object.data.cornerRadius || 0,
            cornerRadii: object.data.cornerRadii ? cornerRadii(object) : null,
            stroke: object.stroke, strokeWidth: object.strokeWidth};
    }
    function setStyle(object, style) {
        if (isLine(object)) { setLineStyle(object, style); object.setCoords(); return; }
        setFill(object, style.fill);
        object.data.cornerRadius = style.cornerRadius;
        if (style.cornerRadii) object.data.cornerRadii = clone(style.cornerRadii);
        else delete object.data.cornerRadii;
        object.set({stroke: style.stroke, strokeWidth: style.strokeWidth});
        object.setCoords();
    }
    root.IdCardShapes = {isShape, create, fillStyle, setFill, normalizeSize, getStyle, setStyle, cornerRadii, setCornerRadius,
        isLine, lineStyle, setLineStyle, lineEndpoints, setLineEndpoints, snapLinePoint,
        label: object => labels[object.data.shapeKind] || 'Shape'};
})(window);
