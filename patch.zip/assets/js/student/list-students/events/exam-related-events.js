$(document).ready(function () {

    // Add Result button click handler
    $('#addBulkResults').click(function () {

        const selectedStudentIds = getSelectedStudentIds();
        const selectedClassIds = getSelectedClassIds();

        if (areSelectedStudentsFromSameClass(selectedClassIds)) {
            window.open('../marksheet/students-mark-entry.php?student_ids=' + selectedStudentIds.join(','), '_blank');
        } else {
            showWarningAlert('Please select students from the same class');
        }
    });

    // Download Admit Cards
    $('#downloadAdmitCards').click(function () {
        const selectedStudentIds = getSelectedStudentIds();
        const selectedClassIds = getSelectedClassIds();

        if (selectedStudentIds.length <= 0) {
            showWarningAlert('Please select at least one student');
            return;
        }

        const classId = selectedClassIds[0];

        if (!areSelectedStudentsFromSameClass(selectedClassIds)) {
            showWarningAlert('Please select students from the same class');
            return;
        }

        $.ajax({
            url: "../../api/admin/get/exam/get-released-admit-cards.php?class_id=" + classId,
            method: "GET",
            dataType: "json",
            beforeSend: function () {
                showLoadingAlert();
            },
            success: function (response) {
                Swal.close();
                if (!response.success || !Array.isArray(response.data) || !response.data.length) {
                    showWarningAlert(response.message || 'No examinations are available.');
                    return;
                }
                let data = response.data;
                let options = {};
                for (let i = 0; i < data.length; i++) {
                    options[data[i].id] = data[i].exam_name + " (" + data[i].class_name + ")";
                }

                // Show modal to select which admit card to download
                Swal.fire({
                    title: 'Select Admit Card',
                    html: '<label for="admitRenderer" class="form-label">Design method</label>' +
                        '<select id="admitRenderer" class="form-select"><option value="classic">Current admit-card design</option><option value="builder">Custom Admit Card Builder</option></select>' +
                        '<div id="admitDuplexOptions" hidden class="mt-2"><label for="admitDuplex" class="form-label">Double-sided printing</label>' +
                        '<select id="admitDuplex" class="form-select"><option value="sequential">Fronts sheet, then matching backs (flip on long edge)</option><option value="side-by-side">Front and back side-by-side</option></select>' +
                        '<small>Uses the template selected for printing in <a href="../settings/admit-card-builder.php" target="_blank" rel="noopener">Admit Card Builder</a>.</small></div>',
                    input: 'select',
                    inputOptions: options,
                    inputPlaceholder: 'Select an admit card',
                    showCancelButton: true,
                    confirmButtonText: 'Download',
                    customClass: {
                        popup: 'rounded-4 shadow-lg'
                    },
                    didOpen: () => {
                        document.getElementById('admitRenderer').addEventListener('change', event => {
                            document.getElementById('admitDuplexOptions').hidden = event.target.value !== 'builder';
                        });
                    },
                    preConfirm: (admitId) => {
                        if (!admitId) {
                            Swal.showValidationMessage('Please select an admit card');
                        }
                        return admitId ? {admitId, renderer: document.getElementById('admitRenderer').value, duplex: document.getElementById('admitDuplex').value} : false;
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        const selected = String(result.value.admitId);
                        const selection = selected.startsWith('exam-') ? 'exam_id=' + encodeURIComponent(selected.slice(5)) : 'admit_id=' + encodeURIComponent(selected);
                        window.open('../../api/download/download-admit-card.php?' + selection + '&student_ids=' + encodeURIComponent(selectedStudentIds.join(',')) + '&renderer=' + encodeURIComponent(result.value.renderer) + '&duplex_layout=' + encodeURIComponent(result.value.duplex), '_blank');
                    }
                });
            },
            error: function (xhr, status, error) {
                console.error(xhr.responseText);
                showErrorAlert('Failed to fetch admit card options. Please try again.');
            }
        });
    });

    // Download Marksheet - handled by exam dropdown items
    $(document).on('click', '.single-marksheet-download-button', function (e) {
        e.preventDefault();
        const examId = $(this).data('exam-id');
        const selectedIds = getSelectedStudentIds();
        const selectedClassIds = getSelectedClassIds();

        if (!areSelectedStudentsFromSameClass(selectedClassIds)) {
            showWarningAlert('Please select students from the same class');
            return;
        }

        $.ajax({
            url: '../../api/admin/get/exam/get-student-result-ids.php',
            type: 'GET',
            data: {
                student_ids: selectedIds.join(','),
                exam_id: examId
            },
            dataType: 'json',
            beforeSend: function () {
                showLoadingAlert();
            },
            success: function (response) {
                if (response.success && response.result_ids.length > 0) {
                    Swal.close();
                    window.open('../../api/download/marksheet/download-single-marksheet.php?result_ids=' + response.result_ids.join(','), '_blank');
                } else {
                    showWarningAlert('No marksheets found for selected students and exam');
                }
            },
            error: function (xhr) {
                console.error(xhr.responseText);
                showErrorAlert('Error fetching result data');
            }
        });
    });
});
