$(document).ready(function () {

    // Add Result button click handler
    $('#addBulkResults').click(function () {

        const selectedStudentIds = getSelectedStudentIds();
        const selectedClassIds = getSelectedClassIds();

        if (areSelectedStudentsFromSameClass(selectedClassIds)) {
            window.open('../marksheet/students-mark-entry.php?student_ids=' + selectedStudentIds.join(','), '_blank');
        } else {
            showWarningAlert('Please select students from the same class');
        }
    });

    // Download Admit Cards
    $('#downloadAdmitCards').click(function () {
        const selectedStudentIds = getSelectedStudentIds();
        const selectedClassIds = getSelectedClassIds();

        if (selectedStudentIds.length <= 0) {
            showWarningAlert('Please select at least one student');
            return;
        }

        const classId = selectedClassIds[0];

        if (!areSelectedStudentsFromSameClass(selectedClassIds)) {
            showWarningAlert('Please select students from the same class');
            return;
        }

        $.ajax({
            url: "../../api/admin/get/exam/get-released-admit-cards.php?class_id=" + classId,
            method: "GET",
            dataType: "json",
            beforeSend: function () {
                showLoadingAlert();
            },
            success: function (response) {
                Swal.close();
                let data = response.data;
                let options = {};
                for (let i = 0; i < data.length; i++) {
                    options[data[i].id] = data[i].exam_name + " (" + data[i].class_name + ")";
                }

                // Show modal to select which admit card to download
                Swal.fire({
                    title: 'Select Admit Card',
                    text: 'Which admit card do you want to download?',
                    input: 'select',
                    inputOptions: options,
                    inputPlaceholder: 'Select an admit card',
                    showCancelButton: true,
                    confirmButtonText: 'Download',
                    customClass: {
                        popup: 'rounded-4 shadow-lg'
                    },
                    preConfirm: (admitId) => {
                        if (!admitId) {
                            Swal.showValidationMessage('Please select an admit card');
                        }
                        return admitId;
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.open('../../api/download/download-bulk-admit-card.php?admit_id=' + result.value + '&student_ids=' + selectedStudentIds.join(','), '_blank');
                    }
                });
            },
            error: function (xhr, status, error) {
                console.error(xhr.responseText);
                showErrorAlert('Failed to fetch admit card options. Please try again.');
            }
        });
    });

    // Download Marksheet - handled by exam dropdown items
    $(document).on('click', '.single-marksheet-download-button', function (e) {
        e.preventDefault();
        const examId = $(this).data('exam-id');
        const selectedIds = getSelectedStudentIds();
        const selectedClassIds = getSelectedClassIds();

        if (!areSelectedStudentsFromSameClass(selectedClassIds)) {
            showWarningAlert('Please select students from the same class');
            return;
        }

        $.ajax({
            url: '../../api/admin/get/exam/get-student-result-ids.php',
            type: 'GET',
            data: {
                student_ids: selectedIds.join(','),
                exam_id: examId
            },
            dataType: 'json',
            beforeSend: function () {
                showLoadingAlert();
            },
            success: function (response) {
                if (response.success && response.result_ids.length > 0) {
                    window.open('../../api/download/download-single-marksheet.php?result_ids=' + response.result_ids.join(','), '_blank');
                } else {
                    showWarningAlert('No marksheets found for selected students and exam');
                }
            },
            error: function (xhr) {
                console.error(xhr.responseText);
                showErrorAlert('Error fetching result data');
            }
        });
    });
});