$(document).ready(function () {

    // Show Selected Students Info On Click
    $(document).on('click', '#showSelectedStudentsInfoBtn', () => {
        showAllSelectedStudentsInfo();
    });

    // Form submission handler
    $('#filterForm').on('submit', function (e) {
        e.preventDefault();
        loadStudents();
    });

    // Reset filters
    $('#resetFilters').click(function () {
        $('#filterForm')[0].reset();
        globalSelectedStudents = []; // Clear selections
        loadStudents();
        $('#selectAll').prop('checked', false).prop('indeterminate', false);
        updateSelectedCount();
    });

    // Set up event listeners for real-time filtering
    $('#search').on('input', debounce(function () {
        loadStudents();
    }, 500));

    $('select').change(function () {
        if (!$(this).hasClass('exclude-from-load')) {
            loadStudents();

            // remove check box selection
            $('#selectAll').prop('checked', false);
            $('.student-checkbox').prop('checked', false);
            updateSelectedCount();
        }
    });
});