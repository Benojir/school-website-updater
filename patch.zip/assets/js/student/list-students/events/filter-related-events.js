$(document).ready(function () {

    // Form submission handler
    $('#filterForm').on('submit', function (e) {
        e.preventDefault();
        loadStudents();
    });

    // Reset filters
    $('#resetFilters').click(function () {
        $('#filterForm')[0].reset();
        globalSelectedStudents = []; // Clear selections
        loadStudents();
        $('#selectAll').prop('checked', false).prop('indeterminate', false);
        updateSelectedCount();
    });

    // Set up event listeners for real-time filtering
    $('#search').on('input', debounce(function () {
        loadStudents();
        if ($(this).val() === '') {
            $('#clear-search-box').hide();
        } else {
            $('#clear-search-box').show();
        }
    }, 800));

    // Clear search box
    $('#clear-search-box').click(function () {
        $('#search').val('').trigger('input');
        $(this).hide();
        $('#search').focus();
    });

    $('#search').on('focus', function () {
        $(this).select();
    });

    $(document).on('keydown', function (e) {
        // চেক করুন Ctrl (বা Mac এর ক্ষেত্রে Cmd) এবং '/' একসাথে প্রেস করা হয়েছে কিনা
        if ((e.ctrlKey || e.metaKey) && e.key === '/') {
            e.preventDefault(); // ব্রাউজারের ডিফল্ট কোনো শর্টকাট থাকলে তা বন্ধ করতে
            $('#search').focus();
            $('#search').select();
        }

        if ((e.ctrlKey || e.metaKey) && e.key === 'l') {
            e.preventDefault(); // ব্রাউজারের ডিফল্ট কোনো শর্টকাট থাকলে তা বন্ধ করতে
            $('#resetFilters').click();
            $('#search').focus();
            $('#clear-search-box').hide();
        }

        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();

            // বাটন visible থাকলে তবেই click হবে
            if ($('#clearSelection').is(':visible')) {
                $('#clearSelection').click();
            }
        }
    });

    // Load students on select change
    $('select').change(function () {
        if (!$(this).hasClass('exclude-from-load')) {
            
            // API কলের আগে কনফ্লিক্ট চেক এবং UI রিসেট করুন
            handleMonthFilterConflict();

            loadStudents();

            // remove check box selection
            $('#selectAll').prop('checked', false);
            $('.student-checkbox').prop('checked', false);
            updateSelectedCount();
        }
    });

    // Filter card collapse/expand icon toggle
    $('#filterCollapseBody').on('show.bs.collapse', function () {
        // কার্ড খুললে আইকন উপরের দিকে পয়েন্ট করবে
        $('#filterToggleIcon').removeClass('fa-chevron-down').addClass('fa-chevron-up');
    });

    $('#filterCollapseBody').on('hide.bs.collapse', function () {
        // কার্ড বন্ধ হলে আইকন নিচের দিকে পয়েন্ট করবে
        $('#filterToggleIcon').removeClass('fa-chevron-up').addClass('fa-chevron-down');
    });
});