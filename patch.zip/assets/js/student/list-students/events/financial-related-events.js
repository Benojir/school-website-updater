$(document).ready(function () {

    // Admission Fees Form Class Selector Enable/Disable
    $('#enable_admission_class_selection').change(function () {
        if ($(this).is(':checked')) {
            $('#admission_class_selector').prop('disabled', false);
        } else {
            $('#admission_class_selector').prop('disabled', true).val('');
        }
    });

    // Form submission for additional fees
    $('#formAdditionalFeesModal').submit(function (event) {
        event.preventDefault();

        let form = $(this);
        let url = '../../api/admin/put/fees-x-payments/process-additional-fees-entry.php';

        // Build form data manually
        let formData = form.serializeArray();

        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            dataType: 'json',
            beforeSend: function () {
                showLoadingAlert();
            },
            success: function (response) {

                if (response.success) {
                    // --- THIS IS THE UPDATED BLOCK ---

                    // 1. Show a simple toast for immediate feedback
                    toastr.success('Operation completed.');

                    // 2. Get the counts
                    let processedCount = response.processedStudents.length;
                    let skippedCount = response.skippedStudents.length;

                    // 3. Build the detailed HTML for the main alert
                    let htmlContent = `<p>${response.message}</p>
                                            <hr>
                                            <p><strong>Processed:</strong> ${processedCount} student(s)</p>
                                            <p><strong>Skipped:</strong> ${skippedCount} student(s)</p>`;

                    // 4. If any students were skipped, add the details
                    if (skippedCount > 0) {
                        htmlContent += '<h5 class="mt-3">Skipped Details:</h5>';
                        // We use 'text-align: left' to make the list look better in Swal
                        htmlContent += '<ul style="text-align: left; max-height: 150px; overflow-y: auto; padding-left: 30px;">';

                        response.skippedStudents.forEach(function (student) {
                            htmlContent += `<li><strong>ID ${student.student_id}:</strong> ${student.reason}</li>`;
                        });

                        htmlContent += '</ul>';
                    }

                    // 5. Reset the form and hide the modal
                    $('#additionalFeesManagementModal').modal('hide');
                    form[0].reset();

                    showSuccessAlert(htmlContent);
                } else {
                    // Show server-side validation or permission errors
                    showErrorAlert(response.message);
                }
            },
            error: function (xhr) {
                console.error(xhr.responseText);
                showErrorAlert('Error processing form. Check console for details.');
            }
        });
    });

});