$(document).ready(function () {
    // Manage Wallet Form
    $('#manageWalletForm').submit(function (e) {
        e.preventDefault();

        const selectedStudentIds = getSelectedStudentIds();
        const $form = $(this);
        const $btn = $form.find('[type="submit"]');
        const btnText = $btn.html();

        if (selectedStudentIds.length === 0) {
            toastr.warning('Please select at least one student.');
            showWarningAlert('Please select at least one student.');
            return;
        }

        $.ajax({
            url: '../../api/admin/put/fees-x-payments/process-wallet.php',
            method: 'POST',
            dataType: 'json',
            data: $form.serialize() + '&student_ids=' + selectedStudentIds.join(','),
            beforeSend: function () {
                showLoadingAlert();
            },
            success: function (response) {
                console.log('Success:', response);
                if (response.success) {
                    let successMessage = response.message;
                    if (response.not_effected_students > 0) {
                        successMessage += "<br> Total <b>" + response.not_effected_students + "</b> student(s) wallets are not affected due to insufficient funds.";
                    }

                    showSuccessAlert(successMessage);
                    $('#manageWalletModal').modal('hide');
                } else {
                    showErrorAlert(response.message);
                }
            },
            error: function (xhr, status, error) {
                console.error('Error:', xhr.responseText);
                showErrorAlert('An error occurred while processing the request.');
            }
        });
    });

    // Manage Fees Button
    $('#manageFeesAndPaymentsBtn').click(function () {
        const selectedStudentIds = getSelectedStudentIds();
        openManageMonthlyFeesAndPaymentsModal(selectedStudentIds);
    });

    // Ask Admission Fees Form Submit
    $('#admissionFeesEntryForm').submit(function (e) {
        e.preventDefault();

        let selectedStudentIds = getSelectedStudentIds();
        if (selectedStudentIds.length === 0) {
            if (singleStudentId) {
                selectedStudentIds = [singleStudentId];
            } else {
                toastr.warning('Please select at least one student.');
                showWarningAlert('Please select at least one student.');
                return;
            }
        }
        const $form = $(this);
        const $btn = $form.find('[type="submit"]');
        const btnText = $btn.html();

        // Show loading state
        $btn.prop('disabled', true).html(
            '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...'
        );

        // Build form data manually
        let formData = $form.serializeArray();
        formData.push({
            name: 'studentIDs',
            value: selectedStudentIds.join(',')
        });

        $.ajax({
            url: '../../api/admin/put/fees-x-payments/process-fees-entry-admission.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    // Show summary success message
                    toastr.success(response.message);

                    // Show detailed results in a modal or console
                    if (response.results && response.results.length > 0) {
                        let successCount = 0;
                        let skippedCount = 0;
                        let html = '<div class="bulk-results-container">';

                        response.results.forEach(result => {
                            if (result.success) {
                                successCount++;
                                html += `
                                        <div class="alert alert-success mb-2">
                                            <strong>${result.student_id}</strong>: ${result.message} 
                                            (Amount: ${result.amount || 'N/A'})
                                        </div>
                                    `;
                            } else {
                                skippedCount++;
                                html += `
                                        <div class="alert alert-warning mb-2">
                                            <strong>${result.student_id}</strong>: ${result.message}
                                        </div>
                                    `;
                            }
                        });

                        html += '</div>';

                        let finalHtml = `
                            <div class="text-left">
                                <p><strong>Summary:</strong> ${response.message}</p>
                                <p>Successfully processed: ${successCount}</p>
                                <p>Skipped: ${skippedCount}</p>
                                <div class="mt-3" style="max-height: 300px; overflow-y: auto;">
                                    ${html}
                                </div>
                            </div>
                        `;

                        showInfoAlert(finalHtml, 'Detailed Results');
                    }

                    $('#bulkAdmissionFeeModal').modal('hide');
                    $('.modal-backdrop').hide();
                } else {
                    showErrorAlert(response.message);
                }
            },
            error: function (xhr) {
                try {
                    console.log(xhr.responseText);
                    const errorResponse = JSON.parse(xhr.responseText);
                    let errorMsg = 'Error: ' + (errorResponse.message || 'Operation failed');

                    if (errorResponse.processed_up_to) {
                        errorMsg += ` (Last processed student ID: ${errorResponse.processed_up_to})`;
                    }

                    showErrorAlert(errorMsg);
                } catch (e) {
                    showErrorAlert('Error: ' + xhr.status + " " + xhr.statusText);
                    console.error(e);
                }
            },
            complete: function () {
                $btn.prop('disabled', false).html(btnText);
                singleStudentId = null; // Reset single student ID after processing
            }
        });
    });

    // Save admission payment form submit
    $('#admissionPaymentsEntryForm').submit(function (e) {
        e.preventDefault();

        const amountVal = $('#admission_fee_amount').val();
        if (!amountVal || isNaN(amountVal)) {
            showErrorAlert('Please enter a valid amount before submitting.');
            return;
        }

        let selectedStudentIds = getSelectedStudentIds();

        if (selectedStudentIds.length === 0) {
            if (singleStudentId) {
                selectedStudentIds = [singleStudentId];
            } else {
                showWarningAlert('Please select at least one student.');
                return;
            }
        }

        Swal.fire({
            title: "Is the amount correct?",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            html: `<h3><b><span style="color: #0057c9;">₹${parseFloat(amountVal).toFixed(2)}</span></b></h3>`,
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, correct amount!",
            customClass: {
                popup: 'rounded-4 shadow-lg'
            }
        }).then((result) => {

            if (result.isConfirmed) {

                const $form = $(this);
                const $btn = $form.find('[type="submit"]');
                const btnText = $btn.html();

                // Show loading state
                $btn.prop('disabled', true).html(
                    '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...'
                );

                // Build form data manually
                let formData = $form.serializeArray();
                formData.push({
                    name: 'studentIDs',
                    value: selectedStudentIds.join(',')
                });

                $.ajax({
                    url: '../../api/admin/put/fees-x-payments/process-payments-entry-admission.php',
                    type: 'POST',
                    data: formData,
                    dataType: 'json',
                    success: function (response) {
                        if (response.success) {
                            $('#bulkAdmissionFeeModal').modal('hide');
                            $('.modal-backdrop').hide();

                            // 1. Prepare the HTML for the detailed report
                            let reportHtml = `<div class="text-start">`;

                            // Summary Header
                            reportHtml += `<p class="alert alert-success text-center mb-3"><b>${response.message}</b></p>`;

                            // 2. Check for Wallet Credits
                            if (response.details && response.details.wallet_credits.length > 0) {
                                reportHtml += `<h6 class="text-primary fw-bold mt-3"><i class="fas fa-wallet"></i> Wallet Credited (Excess Payment)</h6>
                                                <div class="table-responsive" style="max-height: 200px; overflow-y: auto;">
                                                    <table class="table table-sm table-bordered table-hover mb-0">
                                                        <thead class="table-light"><tr><th>Student Name</th><th class="text-end">Amount</th></tr></thead>
                                                        <tbody>`;

                                response.details.wallet_credits.forEach(function (item) {
                                    reportHtml += `<tr>
                                        <td>${item.name}</td>
                                        <td class="text-end text-success fw-bold">+${item.amount}</td>
                                    </tr>`;
                                });
                                reportHtml += `</tbody></table></div>`;
                            }

                            // 3. Check for Skipped Students
                            if (response.details && response.details.skipped_students.length > 0) {
                                reportHtml += `<h6 class="text-danger fw-bold mt-3"><i class="fas fa-exclamation-triangle"></i> Skipped Students</h6>
                                                <div class="table-responsive" style="max-height: 200px; overflow-y: auto;">
                                                    <table class="table table-sm table-bordered table-hover mb-0">
                                                        <thead class="table-light"><tr><th>Student Name</th><th>Reason</th></tr></thead>
                                                        <tbody>`;

                                response.details.skipped_students.forEach(function (item) {
                                    reportHtml += `<tr>
                                        <td>${item.name}</td>
                                        <td class="text-danger small">${item.reason}</td>
                                    </tr>`;
                                });
                                reportHtml += `</tbody></table></div>`;
                            }

                            reportHtml += `</div>`;

                            // 4. Display the Detailed Report using SweetAlert
                            Swal.fire({
                                title: "Processing Complete",
                                icon: "success",
                                html: reportHtml,
                                width: '600px', // Make it wider for tables
                                confirmButtonText: "Close",
                                customClass: {
                                    popup: 'rounded-4 shadow-lg'
                                }
                            }).then(() => {
                                // Optional: Reload page or refresh table after closing the report
                                // location.reload(); 
                            });

                        } else {
                            showErrorAlert(response.message);
                        }
                    },
                    error: function (xhr) {
                        try {
                            let errorMsg = 'Error: ' + (xhr.statusText || 'Operation failed');
                            showErrorAlert(errorMsg);
                        } catch (e) {
                            console.error(e);
                            showErrorAlert('Error: ' + xhr.status + " " + xhr.statusText);
                        }
                        console.error(xhr.responseText);
                    },
                    complete: function () {
                        $btn.prop('disabled', false).html(btnText);
                        singleStudentId = null; // Reset single student ID after processing
                    }
                });
            }
        });
    });

    // Admission Fees Form Class Selector Enable/Disable
    $('#enable_admission_class_selection').change(function () {
        if ($(this).is(':checked')) {
            $('#admission_class_selector').prop('disabled', false);
        } else {
            $('#admission_class_selector').prop('disabled', true).val('');
        }
    });

    // Ask Fees form submit
    $('#monthlyFeesEntryForm').submit(function (e) {
        e.preventDefault();

        let selectedStudentIds = getSelectedStudentIds();
        if (selectedStudentIds.length === 0) {
            if (singleStudentId) {
                selectedStudentIds = [singleStudentId];
            } else {
                toastr.warning('Please select at least one student.');
                showWarningAlert('Please select at least one student.');
                return;
            }
        }
        const $form = $(this);
        const $btn = $form.find('[type="submit"]');
        const btnText = $btn.html();

        // Show loading state
        $btn.prop('disabled', true).html(
            '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...'
        );

        // Build form data manually
        let formData = $form.serializeArray();
        formData.push({
            name: 'studentIDs',
            value: selectedStudentIds.join(',')
        });

        $.ajax({
            url: '../../api/admin/put/fees-x-payments/process-fees-entry-monthly.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    // Show summary success message
                    toastr.success(response.message);

                    // Show detailed results in a modal or console
                    if (response.results && response.results.length > 0) {
                        let successCount = 0;
                        let skippedCount = 0;
                        let html = '<div class="bulk-results-container">';

                        response.results.forEach(result => {
                            if (result.success) {
                                successCount++;
                                html += `
                                        <div class="alert alert-success mb-2">
                                            <strong>${result.student_id}</strong>: ${result.message} 
                                            (Amount: ${result.amount || 'N/A'})
                                        </div>
                                    `;
                            } else {
                                skippedCount++;
                                html += `
                                        <div class="alert alert-warning mb-2">
                                            <strong>${result.student_id}</strong>: ${result.message}
                                        </div>
                                    `;
                            }
                        });

                        html += '</div>';

                        let finalHtml = `<div class="text-left">
                                            <p><strong>Summary:</strong> ${response.message}</p>
                                            <p>Successfully processed: ${successCount}</p>
                                            <p>Skipped: ${skippedCount}</p>
                                            <div class="mt-3" style="max-height: 300px; overflow-y: auto;">
                                                ${html}
                                            </div>
                                        </div>`;

                        showInfoAlert(finalHtml, 'Detailed Results');
                    }

                    $('#bulkMonthlyFeeModal').modal('hide');
                    $('.modal-backdrop').hide();
                } else {
                    showErrorAlert(response.message);
                }
            },
            error: function (xhr) {
                console.error(xhr.responseText);
                try {
                    const errorResponse = JSON.parse(xhr.responseText);
                    let errorMsg = 'Error: ' + (errorResponse.message || 'Operation failed');

                    if (errorResponse.processed_up_to) {
                        errorMsg += ` (Last processed student ID: ${errorResponse.processed_up_to})`;
                    }

                    showErrorAlert(errorMsg);
                } catch (e) {
                    console.error(e);
                    showErrorAlert('Error: ' + xhr.status + " " + xhr.statusText);
                }
            },
            complete: function () {
                $btn.prop('disabled', false).html(btnText);
                singleStudentId = null; // Reset single student ID after processing
            }
        });
    });

    // Save payment form submit
    $('#monthlyPaymentsEntryForm').submit(function (e) {
        e.preventDefault();

        const amountVal = $('#monthly_fee_amount').val();
        if (!amountVal || isNaN(amountVal)) {
            toastr.error('Please enter a valid amount before submitting.');
            showWarningAlert('Please enter a valid amount before submitting.');
            return;
        }

        let selectedStudentIds = getSelectedStudentIds();

        if (selectedStudentIds.length === 0) {
            if (singleStudentId) {
                selectedStudentIds = [singleStudentId];
            } else {
                showWarningAlert('Please select at least one student.');
                return;
            }
        }

        Swal.fire({
            title: "Is the amount correct?",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            html: `<h3><b><span style="color: #0057c9;">₹${parseFloat(amountVal).toFixed(2)}</span></b></h3>`,
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, correct amount!",
            customClass: {
                popup: 'rounded-4 shadow-lg'
            }
        }).then((result) => {

            if (result.isConfirmed) {

                const $form = $(this);
                const $btn = $form.find('[type="submit"]');
                const btnText = $btn.html();

                // Show loading state
                $btn.prop('disabled', true).html(
                    '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...'
                );

                // Build form data manually
                let formData = $form.serializeArray();
                formData.push({
                    name: 'studentIDs',
                    value: selectedStudentIds.join(',')
                });

                $.ajax({
                    url: '../../api/admin/put/fees-x-payments/process-payments-entry-monthly.php',
                    type: 'POST',
                    data: formData,
                    dataType: 'json',
                    success: function (response) {
                        if (response.success) {
                            // Show summary success message
                            toastr.success(response.message);
                            showSuccessAlert(response.message);
                            $('#bulkMonthlyFeeModal').modal('hide');
                            $('.modal-backdrop').hide();
                        } else {
                            showErrorAlert(response.message);
                        }

                        console.log(response.message);
                    },
                    error: function (xhr) {
                        try {
                            let errorMsg = 'Error: ' + (xhr.statusText || 'Operation failed');
                            showErrorAlert(errorMsg);
                        } catch (e) {
                            console.error(e);
                            showErrorAlert('Error: ' + xhr.status + " " + xhr.statusText);
                        }
                        console.error(xhr.responseText);
                    },
                    complete: function () {
                        $btn.prop('disabled', false).html(btnText);
                        singleStudentId = null; // Reset single student ID after processing
                    }
                });
            }
        });
    });

    // Form submission for additional fees
    $('#formAdditionalFeesModal').submit(function (event) {
        event.preventDefault();

        let form = $(this);
        let url = '../../api/admin/put/fees-x-payments/process-additional-fees-entry.php';

        // Build form data manually
        let formData = form.serializeArray();

        $.ajax({
            url: url,
            type: 'POST',
            data: formData,
            dataType: 'json',
            beforeSend: function () {
                showLoadingAlert();
            },
            success: function (response) {

                if (response.success) {
                    // --- THIS IS THE UPDATED BLOCK ---

                    // 1. Show a simple toast for immediate feedback
                    toastr.success('Operation completed.');

                    // 2. Get the counts
                    let processedCount = response.processedStudents.length;
                    let skippedCount = response.skippedStudents.length;

                    // 3. Build the detailed HTML for the main alert
                    let htmlContent = `<p>${response.message}</p>
                                            <hr>
                                            <p><strong>Processed:</strong> ${processedCount} student(s)</p>
                                            <p><strong>Skipped:</strong> ${skippedCount} student(s)</p>`;

                    // 4. If any students were skipped, add the details
                    if (skippedCount > 0) {
                        htmlContent += '<h5 class="mt-3">Skipped Details:</h5>';
                        // We use 'text-align: left' to make the list look better in Swal
                        htmlContent += '<ul style="text-align: left; max-height: 150px; overflow-y: auto; padding-left: 30px;">';

                        response.skippedStudents.forEach(function (student) {
                            htmlContent += `<li><strong>ID ${student.student_id}:</strong> ${student.reason}</li>`;
                        });

                        htmlContent += '</ul>';
                    }

                    // 5. Reset the form and hide the modal
                    $('#additionalFeesManagementModal').modal('hide');
                    form[0].reset();

                    showSuccessAlert(htmlContent);
                } else {
                    // Show server-side validation or permission errors
                    showErrorAlert(response.message);
                }
            },
            error: function (xhr) {
                console.error(xhr.responseText);
                showErrorAlert('Error processing form. Check console for details.');
            }
        });
    });

    // Monthly fees entry form auto scroll
    // This event fires strictly AFTER the modal CSS transition is complete
    $('#bulkMonthlyFeeModal').on('shown.bs.modal', function () {

        // Target the select box specifically inside this modal
        $(this).find('.feeMonthSelect').each(function () {
            const selectBox = this;

            // Check if we have a valid selection
            if (selectBox.selectedIndex !== -1) {
                const selectedOption = selectBox.options[selectBox.selectedIndex];

                if (selectedOption) {
                    // Now that modal is visible, offsetTop will calculate correctly
                    // We subtract offsetHeight so the previous month is visible at the top
                    selectBox.scrollTop = selectedOption.offsetTop - selectedOption.offsetHeight;
                }
            }
        });
    });
});