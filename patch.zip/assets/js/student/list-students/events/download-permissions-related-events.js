$(document).ready(function () {
    // Add this to your document ready function
    $('#bulkEditPermissions').click(function () {
        const selectedStudentIds = getSelectedStudentIds();
        if (selectedStudentIds.length === 0) {
            showWarningAlert('Please select at least one student');
            return;
        }

        openManageDownloadsPermissionModal(selectedStudentIds);
    });
});