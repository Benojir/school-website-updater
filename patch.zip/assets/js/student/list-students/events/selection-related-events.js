$(document).ready(function () {

    // Pagination click handler
    $(document).on('click', '.page-link', function (e) {
        e.preventDefault();
        const page = $(this).data('page');
        if (page) {
            loadStudents(page);
        }
    });

    // Select/Deselect all functionality
    $('#selectAll').change(function () {
        const isChecked = $(this).prop('checked');
        $('.student-checkbox').each(function () {
            $(this).prop('checked', isChecked);
            const studentId = $(this).data('student-id').toString();
            const classId = $(this).data('class-id').toString(); // ক্লাস আইডি নেওয়া হচ্ছে

            if (isChecked) {
                if (!globalSelectedStudents.includes(studentId)) {
                    globalSelectedStudents.push(studentId);
                }
                // ক্লাস আইডি সেভ করা হচ্ছে
                globalStudentClasses[studentId] = classId;
            } else {
                const index = globalSelectedStudents.indexOf(studentId);
                if (index > -1) {
                    globalSelectedStudents.splice(index, 1);
                }
                // ক্লাস আইডি মুছে ফেলা হচ্ছে
                delete globalStudentClasses[studentId];
            }
        });
        updateSelectedCount();
    });

    // Update select all checkbox when individual checkboxes change
    $(document).on('change', '.student-checkbox', function () {
        updateSelectedCount();
    });

    // Clear selection
    $('#clearSelection').click(function () {
        globalSelectedStudents = []; // Clear global selections
        globalStudentClasses = {}; // অবজেক্ট ক্লিয়ার করা হলো
        
        $('.student-checkbox, #selectAll').prop('checked', false);
        $('.student-checkbox, #selectAll').prop('indeterminate', false);
        updateSelectedCount();
    });

});