$(document).ready(function () {

    // Pagination click handler
    $(document).on('click', '.page-link', function (e) {
        e.preventDefault();
        const page = $(this).data('page');
        if (page) {
            loadStudents(page);
        }
    });

    // Select/Deselect all functionality
    $('#selectAll').change(function () {
        const isChecked = $(this).prop('checked');
        $('.student-checkbox').each(function () {
            $(this).prop('checked', isChecked);
            const studentId = $(this).data('student-id').toString();

            if (isChecked) {
                if (!globalSelectedStudents.includes(studentId)) {
                    globalSelectedStudents.push(studentId);
                }
            } else {
                const index = globalSelectedStudents.indexOf(studentId);
                if (index > -1) {
                    globalSelectedStudents.splice(index, 1);
                }
            }
        });
        updateSelectedCount();
    });

    // Update select all checkbox when individual checkboxes change
    $(document).on('change', '.student-checkbox', function () {
        updateSelectedCount();
    });

    // Clear selection
    $('#clearSelection').click(function () {
        globalSelectedStudents = []; // Clear global selections
        $('.student-checkbox, #selectAll').prop('checked', false);
        $('.student-checkbox, #selectAll').prop('indeterminate', false);
        updateSelectedCount();
    });

});