$(document).ready(function () {

    // Bulk promote students
    $('#bulkPromoteStudents').click(function () {
        const selectedStudentIds = getSelectedStudentIds();
        const selectedClassIds = getSelectedClassIds();

        if (areSelectedStudentsFromSameClass(selectedClassIds)) {
            window.open('../academic/promote-bulk-students.php?student_ids=' + selectedStudentIds.join(','), '_blank');
        } else {
            showWarningAlert('Please select students from the same class');
        }
    });


    // Bulk edit students
    $('#bulkEditStudents').click(function () {
        const selectedStudentIds = getSelectedStudentIds();
        var url = '../student/edit-bulk-students.php?student_ids=' + selectedStudentIds.join(',');
        window.open(url, '_blank');
    });

    // Bulk download transfer certificate
    $('#transferCertificateDownload').click(function () {
        const selectedStudentIds = getSelectedStudentIds();
        var url = '../student/before-transfer-certificate.php?student_ids=' + selectedStudentIds.join(',');
        window.open(url, '_blank');
    });

    // Bulk download pending fees receipt
    $('#pendingFeesReceiptDownload').click(function () {
        const selectedStudentIds = getSelectedStudentIds();
        var url = '../../api/download/receipt/student-due-fees-bill.php?student_ids=' + selectedStudentIds.join(',');
        window.open(url, '_blank');
    });

    // ------------------Student Data Export Related Codes-------------------------- //

    // Array to maintain selected column order
    let selectedColumnOrder = [];

    $('#exportDataOptionsModal input[type="checkbox"]:checked').each(function () {
        selectedColumnOrder.push($(this).attr('name'));
    });

    // Set initial value to hidden input
    $('#exportColumnOrder').val(selectedColumnOrder.join(','));

    // Modal Show Event: ONLY update Student IDs (Do not touch the column order)
    $('#exportDataOptionsModal').on('show.bs.modal', function () {
        const selectedStudentIds = getSelectedStudentIds();
        $('#exportDataStudentIdsInputField').val(selectedStudentIds.join(','));
        $('#exportColumnOrder').val(selectedColumnOrder.join(','));
    });

    // On Change Event: Update the array based on user interaction
    $('#exportDataOptionsModal input[type="checkbox"]').on('change', function () {
        const columnName = $(this).attr('name');

        if ($(this).is(':checked')) {
            // Add to end of array (User Order)
            // Check if not already exists to prevent duplicates (safety check)
            if (!selectedColumnOrder.includes(columnName)) {
                selectedColumnOrder.push(columnName);
            }
        } else {
            // Remove from array
            selectedColumnOrder = selectedColumnOrder.filter(item => item !== columnName);
        }

        // Update Hidden Input
        $('#exportColumnOrder').val(selectedColumnOrder.join(','));

        console.log("Current Order:", selectedColumnOrder);
    });

// ------------------------------------------------------------------------------ //

    // Download ID Cards
    $('#downloadIdCards').click(function () {
        const selectedIds = getSelectedStudentIds();
        if (selectedIds.length > 0) {
            // Create form and submit via POST
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '../../api/download/student-id-cards-generate-option.php';
            form.target = '_blank';

            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'student_ids';
            input.value = JSON.stringify(selectedIds);
            form.appendChild(input);

            document.body.appendChild(form);
            form.submit();
            document.body.removeChild(form);
        } else {
            showWarningAlert('Please select at least one student');
        }
    });

    // Download Transport ID Cards
    $('#downloadTransportIdCards').click(function () {
        const selectedIds = getSelectedStudentIds();
        if (selectedIds.length > 0) {
            // Create form and submit via POST
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '../../api/download/student-transport-id-card.php';
            form.target = '_blank';

            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'student_ids';
            input.value = selectedIds.join(',');
            form.appendChild(input);

            document.body.appendChild(form);
            form.submit();
            document.body.removeChild(form);
        } else {
            showWarningAlert('Please select at least one student');
        }
    });

    // Bulk manage student attendance
    $('#manageAttendanceBtn').click(function () {
        const selectedStudentIds = getSelectedStudentIds();
        if (selectedStudentIds.length === 0) {
            showWarningAlert('Please select at least one student to manage attendance');
            return;
        }
        openStudentAttendanceModal(selectedStudentIds);
    });

    // Prepare data before form submission
    $('#manageAttendanceForm').on('submit', function (e) {
        e.preventDefault();

        // Get student IDs from hidden field or fall back to selection
        let rawStudentIds = $('#attendance_student_ids').val();
        let selectedStudentIds = rawStudentIds ? rawStudentIds.split(',').map(s => s.trim()).filter(Boolean) : getSelectedStudentIds();

        if (selectedStudentIds.length === 0) {
            showWarningAlert('Please select at least one student to mark attendance');
            return;
        }

        const dates = datePicker ? datePicker.selectedDates : [];
        const time = $('#attendance_time').val();
        const action = $('#attendance_action').val();

        // Validation
        if (!dates || dates.length === 0) {
            showWarningAlert('Please select at least one date for attendance');
            return;
        }

        if (!action) {
            showWarningAlert('Please select an action for attendance');
            return;
        }

        if (!time) {
            showWarningAlert('Please select a time for attendance');
            return;
        }

        // Format dates as YYYY-MM-DD
        const dateValues = dates.map(date => {
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        });

        // Prepare form data as JSON
        const formData = {
            action: action,
            dates: dateValues,
            time: time,
            student_ids: selectedStudentIds.join(',')
        };

        // Show loading state
        const submitBtn = $(this).find('button[type="submit"]');
        submitBtn.prop('disabled', true);
        submitBtn.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...');

        // AJAX submission with JSON data
        $.ajax({
            url: '../../api/admin/put/student/process-attendance.php',
            type: 'POST',
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify(formData),
            success: function (response) {
                if (response.success) {
                    $('#manageAttendanceModal').modal('hide');

                    let skippedInfoHtml = '';
                    if (response.skipped_students && response.skipped_students.length > 0) {
                        const skippedItems = response.skipped_students.map(s => `<li><strong>${escapeHtml(s.name)}</strong> (${escapeHtml(s.id)}): <span class="text-danger">${escapeHtml(s.reason)}</span></li>`).join('');
                        skippedInfoHtml += `
                            <div class="alert alert-warning mt-2 mb-0 p-2 small text-start">
                                <strong><i class="fas fa-exclamation-triangle me-1"></i> Skipped Students (No Section Assigned):</strong>
                                <ul class="mb-0 ps-3 mt-1">
                                    ${skippedItems}
                                </ul>
                            </div>
                        `;
                    }
                    if (response.skipped_leave_students && response.skipped_leave_students.length > 0) {
                        const skippedLeaveItems = response.skipped_leave_students.map(s => `<li><strong>${escapeHtml(s.name)}</strong> (${escapeHtml(s.id)}) on ${s.date}: <span class="text-danger">${escapeHtml(s.reason)}</span></li>`).join('');
                        skippedInfoHtml += `
                            <div class="alert alert-warning mt-2 mb-0 p-2 small text-start">
                                <strong><i class="fas fa-exclamation-circle me-1"></i> Skipped Leave Actions:</strong>
                                <ul class="mb-0 ps-3 mt-1">
                                    ${skippedLeaveItems}
                                </ul>
                            </div>
                        `;
                    }

                    let infoHtml = `
                        <div class="alert alert-success mb-2 text-start">
                            <p class="fw-bold mb-2">${escapeHtml(response.message)}</p>
                            <hr class="my-2">
                            <p class="mb-1">Total Dates Processed: <b>${response.totalDateProcessed ?? 0}</b></p>
                            <p class="mb-1">Total Students Processed: <b>${response.totalStudentsProcessed ?? 0}</b></p>
                            <p class="mb-1">Total Records Updated / Replaced: <b>${response.totalUpdatedRecords ?? 0}</b></p>
                            <p class="mb-1">Total Records Inserted: <b>${response.totalInsertedRecords ?? 0}</b></p>
                            ${response.totalSkipStudents > 0 ? `<p class="mb-1 text-danger">Total Students Skipped: <b>${response.totalSkipStudents}</b></p>` : ''}
                        </div>
                        ${skippedInfoHtml}
                    `;

                    showSuccessAlert(infoHtml);
                } else {
                    showErrorAlert(response.message || 'Failed to save attendance records.');
                }
            },
            error: function (xhr) {
                const errorMsg = xhr.responseJSON?.message ||
                    xhr.responseText ||
                    'An error occurred while saving attendance';

                console.error('Error:', errorMsg);
                showErrorAlert(errorMsg);
            },
            complete: function () {
                submitBtn.prop('disabled', false);
                submitBtn.html('<i class="fas fa-paper-plane"></i> Submit');
            }
        });
    });

    // Reset form when modal closes
    $('#manageAttendanceModal').on('hidden.bs.modal', function () {
        if (typeof datePicker !== 'undefined' && datePicker) {
            datePicker.clear();
        }
        $('#attendance_action').val('');
        $('#attendance_student_ids').val('');
        $('#attendanceTargetSummary').hide();
    });

    // Reset form
    $('#resetAttendanceForm').click(function () {
        if (typeof datePicker !== 'undefined' && datePicker) {
            datePicker.clear();
        }
        const now = new Date();
        $('#attendance_time').val(
            now.getHours().toString().padStart(2, '0') + ':' +
            now.getMinutes().toString().padStart(2, '0')
        );
        $('#attendance_action').val('');
    });
});