$(document).ready(function () {

    // Bulk promote students
    $('#bulkPromoteStudents').click(function () {
        const selectedStudentIds = getSelectedStudentIds();
        const selectedClassIds = getSelectedClassIds();

        if (areSelectedStudentsFromSameClass(selectedClassIds)) {
            window.open('../academic/promote-bulk-students.php?student_ids=' + selectedStudentIds.join(','), '_blank');
        } else {
            showWarningAlert('Please select students from the same class');
        }
    });


    // Bulk edit students
    $('#bulkEditStudents').click(function () {
        const selectedStudentIds = getSelectedStudentIds();
        const selectedClassIds = getSelectedClassIds();

        if (areSelectedStudentsFromSameClass(selectedClassIds)) {
            var url = '../student/edit-bulk-students.php?student_ids=' + selectedStudentIds.join(',');
            window.open(url, '_blank');
        } else {
            showWarningAlert('Please select students from the same class');
        }
    });

    // Bulk export students data
    $('#exportBulkStudentData').click(function () {

        const selectedStudentIds = getSelectedStudentIds();

        if (selectedStudentIds.length > 0) {
            window.open('../../api/admin/put/student/export-students-data.php?student_ids=' + selectedStudentIds.join(','), '_blank');
        } else {
            showWarningAlert('Please select at least one student');
        }
    });

    // Download ID Cards
    $('#downloadIdCards').click(function () {
        const selectedIds = getSelectedStudentIds();
        if (selectedIds.length > 0) {
            // Create form and submit via POST
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '../../api/download/download-student-id-card.php';
            form.target = '_blank';

            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'student_ids';
            input.value = JSON.stringify(selectedIds);
            form.appendChild(input);

            document.body.appendChild(form);
            form.submit();
            document.body.removeChild(form);
        } else {
            showWarningAlert('Please select at least one student');
        }
    });

    // Prepare data before form submission
    $('#manageAttendanceForm').on('submit', function (e) {
        e.preventDefault();

        // Get form data
        const selectedStudentIds = getSelectedStudentIds();
        if (selectedStudentIds.length === 0) {
            showWarningAlert('Please select at least one student to mark attendance');
            return;
        }

        const dates = datePicker.selectedDates;
        const time = $('#attendance_time').val();
        const action = $('#attendance_action').val();

        // Validation
        if (dates.length === 0) {
            showWarningAlert('No Dates Selected', 'Please select at least one date for attendance');
            return;
        }

        if (!action) {
            showWarningAlert('No Action Selected', 'Please select an action for attendance');
            return;
        }

        if (!time) {
            showWarningAlert('No Time Selected', 'Please select a time for attendance');
            return;
        }

        // Combine dates with time
        const dateTimeValues = dates.map(date => {
            const dateStr = date.toLocaleDateString('en-CA'); // YYYY-MM-DD format
            return `${dateStr} ${time}`;
        });

        // Prepare form data as JSON
        const formData = {
            action: action,
            datetimes: dateTimeValues,
            student_ids: selectedStudentIds.join(',')
        };

        // Show loading state
        const submitBtn = $(this).find('button[type="submit"]');
        submitBtn.prop('disabled', true);
        submitBtn.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...');

        // AJAX submission with JSON data
        $.ajax({
            url: '../../api/admin/put/student/process-attendance.php',
            type: 'POST',
            dataType: 'json',
            contentType: 'application/json', // Add this line
            data: JSON.stringify(formData), // Stringify the JSON
            success: function (response) {
                if (response.success) {
                    $('#manageAttendanceModal').modal('hide');

                    let infoHtml = `
                            <div class="alert alert-success mb-3">
                                <p>${response.message}</p>
                                <hr>
                                <p class="mb-1">Total Dates Processed: <b>${response.totalDateProcessed}</b></p>
                                <p class="mb-1">Total Students Processed: <b>${response.totalStudentsProcessed}</b></p>
                                <p class="mb-1">Total Records Updated: <b>${response.totalUpdatedRecords}</b></p>
                                <p class="mb-1">Total Records Inserted: <b>${response.totalInsertedRecords}</b></p>
                                <p class="mb-1">Total Dates Skipped: <b>${response.totalSkipDateRecords}</b></p>
                                <p class="mb-1">Total Students Skipped: <b>${response.totalSkipStudents}</b></p>
                            </div>
                        `;

                    showSuccessAlert(infoHtml);
                } else {
                    showErrorAlert(response.message || 'Failed to save attendance records.');
                }
            },
            error: function (xhr) {
                const errorMsg = xhr.responseJSON?.message ||
                    xhr.responseText ||
                    'An error occurred while saving attendance';

                console.error('Error:', errorMsg);
                showErrorAlert(errorMsg);
            },
            complete: function () {
                submitBtn.prop('disabled', false);
                submitBtn.html('<i class="fas fa-paper-plane"></i> Submit');
            }
        });
    });

    // Reset form when modal closes
    $('#manageAttendanceModal').on('hidden.bs.modal', function () {
        datePicker.clear();
        $('#attendance_action').val('');
    });

    // Reset form
    $('#resetAttendanceForm').click(function () {
        datePicker.clear();
        const now = new Date();
        document.getElementById('attendance_time').value =
            now.getHours().toString().padStart(2, '0') + ':' +
            now.getMinutes().toString().padStart(2, '0');
        $('#attendance_action').val('');
    });
});