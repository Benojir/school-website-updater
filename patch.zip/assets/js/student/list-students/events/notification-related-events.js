$(document).ready(function () {
    // Send notification form
    $('#sendNotificationForm').submit((e) => {
        e.preventDefault();

        const selectedStudentIds = getSelectedStudentIds();

        if (selectedStudentIds.length === 0) {
            toastr.warning('Please select at least one student.');
            showWarningAlert('Please select at least one student.');
            return;
        }

        const formData = $('#sendNotificationForm').serializeArray();
        formData.push({
            name: 'student_ids',
            value: selectedStudentIds.join(',')
        });

        $.ajax({
            url: '../../api/admin/put/notice/send-notification.php',
            method: 'POST',
            dataType: 'json',
            data: $.param(formData),
            beforeSend: function () {
                showLoadingAlert();
            },
            success: function (response) {
                console.log('Success:', response);
                if (response.success) {
                    showSuccessAlert(response.message);
                    $('#sendNotificationsModal').modal('hide');
                } else {
                    showWarningAlert(response.message);
                }
            },
            error: function (xhr, status, error) {
                console.error('Error:', xhr.responseText);
                showErrorAlert('An error occurred. Please try again.');
            }
        });
    });
});