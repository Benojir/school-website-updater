$(document).ready(function () {
    // Send notification form
    $('#sendNotificationForm').submit((e) => {
        e.preventDefault();

        const selectedStudentIds = getSelectedStudentIds();

        if (selectedStudentIds.length === 0) {
            toastr.warning('Please select at least one student.');
            showWarningAlert('Please select at least one student.');
            return;
        }

        const formData = $('#sendNotificationForm').serializeArray();
        formData.push({
            name: 'student_ids',
            value: selectedStudentIds.join(',')
        });

        $.ajax({
            url: '../../api/admin/put/notice/send-notification.php',
            method: 'POST',
            dataType: 'json',
            data: $.param(formData),
            beforeSend: function () {
                showLoadingAlert();
            },
            success: function (response) {
                console.log('Success:', response);
                if (response.success) {
                    showSuccessAlert(response.message);
                    $('#sendNotificationsModal').modal('hide');
                } else {
                    showWarningAlert(response.message);
                }
            },
            error: function (xhr, status, error) {
                console.error('Error:', xhr.responseText);
                showErrorAlert('An error occurred. Please try again.');
            }
        });
    });

    //-----------------------------------------------------------------------
    $('#sendPaymentRemindersModalForm').on('submit', function (e) {
        e.preventDefault();

        const $form = $(this);
        const $submitBtn = $form.find('[type="submit"]');

        // Guard against double-submits (double click / Enter key spam) while
        // a request is already in flight - important here since this triggers
        // real, billable SMS/WhatsApp sends.
        if ($submitBtn.prop('disabled')) {
            return;
        }

        let selectedStudentIds = getSelectedStudentIds();

        if (selectedStudentIds.length === 0) {
            toastr.warning('Please select at least one student.');
            return;
        }

        // Filter out any pre-existing 'student_ids' field so we don't send it twice.
        let formData = $form.serializeArray().filter(field => field.name !== 'student_ids');
        formData.push({
            name: 'student_ids',
            value: selectedStudentIds.join(',')
        });

        $submitBtn.prop('disabled', true);

        $.ajax({
            url: '../../api/admin/put/notice/send-payment-reminders.php',
            method: 'POST',
            dataType: 'json',
            data: $.param(formData),
            timeout: 120000, // large batches can take a while server-side; fail loudly instead of hanging forever
            beforeSend: function () {
                showLoadingAlert();
            },
            success: function (response) {
                if (response.success) {
                    let totalSuccessSent = response.sent_count || 0;
                    let totalFailedSent = response.skipped_count || 0;

                    let responseHTML = '';
                    if (totalSuccessSent > 0) {
                        responseHTML += `<p>${totalSuccessSent} payment reminder(s) sent successfully.</p>`;
                    }
                    if (totalFailedSent > 0) {
                        responseHTML += `<p>${totalFailedSent} payment reminder(s) failed to send.</p>`;
                        responseHTML += buildSkippedSummary(response.skipped_students);
                    }

                    showSuccessAlert(responseHTML);
                    $('#sendPaymentRemindersModal').modal('hide');
                } else {
                    showWarningAlert(escapeHtml(response.message || 'Something went wrong.'));
                }
            },
            error: function (xhr, status) {
                if (status === 'timeout') {
                    showErrorAlert('The request timed out. Some reminders may still have been sent - please check before retrying.');
                } else {
                    showErrorAlert('An error occurred. Please try again.');
                }
            },
            complete: function () {
                // Always re-enable the button and clear the loading state,
                // whether the request succeeded, failed, or timed out.
                $submitBtn.prop('disabled', false);
                hideLoadingAlert();
            }
        });
    });

    // Show up to a few skipped students with their reasons so the admin
    // knows *why* a send failed, not just how many.
    function buildSkippedSummary(skippedStudents) {
        if (!Array.isArray(skippedStudents) || skippedStudents.length === 0) {
            return '';
        }

        const MAX_SHOWN = 5;
        let items = skippedStudents.slice(0, MAX_SHOWN).map(s => {
            const name = escapeHtml(s.name || `Student #${s.id ?? ''}`);
            const reason = escapeHtml(s.error || 'Unknown reason');
            return `<li>${name} - ${reason}</li>`;
        }).join('');

        let extra = skippedStudents.length > MAX_SHOWN
            ? `<p>...and ${skippedStudents.length - MAX_SHOWN} more.</p>`
            : '';

        return `<ul>${items}</ul>${extra}`;
    }
});