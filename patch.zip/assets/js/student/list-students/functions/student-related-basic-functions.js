// Function to render students in the table
function renderStudents(students) {
    const $tbody = $('#studentsTableBody');
    $tbody.empty();

    if (students.length > 0) {
        students.forEach(function (student) {
            const isSelected = globalSelectedStudents.includes(student.student_id.toString());
            const row = `
                        <tr>
                            <td>
                                <input type="checkbox" class="form-check-input student-checkbox" 
                                    data-student-id="${escapeHtml(student.student_id)}" 
                                    data-class-id="${escapeHtml(student.class_id)}"
                                    ${isSelected ? 'checked' : ''}>
                            </td>
                            <td>
                                <a data-src="../../uploads/students/${escapeHtml(student.student_image)}" data-fancybox data-caption="${escapeHtml(student.name)}">
                                    <img src="../../uploads/students/${escapeHtml(student.student_image)}" alt="📷" style="max-width: 55px;" class="rounded-2 border" loading="lazy">
                                </a>
                            </td>
                            <td>
                                <a target="_blank" href="../../parent/dashboard/student-details.php?student_id=${escapeHtml(student.student_id)}" class="text-decoration-none">
                                    ${escapeHtml(student.name)}
                                </a>
                                <br>
                                <span class="text-muted" style="font-size: 0.8rem;">${escapeHtml(student.student_id)}</span>
                                <br>
                                <span class="text-muted" style="font-size: 0.8rem;">Reg: ${escapeHtml(student.registration_no)}</span>
                            </td>
                            <td>${escapeHtml(student.father_name)}</td>
                            <td>
                                <a class="text-decoration-none" href="tel:${escapeHtml(student.phone_number)}">
                                    ${escapeHtml(student.phone_number)}
                                </a>
                                <br>
                                &
                                <br>
                                <a class="text-decoration-none" href="tel:${escapeHtml(student.alternate_phone_number)}">
                                    ${escapeHtml(student.alternate_phone_number)}
                                </a>
                            </td>
                            <td class="text-truncate" style="max-width: 200px;" title="${escapeHtml(student.address)}">${escapeHtml(student.village)}, ${escapeHtml(student.post_office)}</td>
                            <td>
                                ${escapeHtml(student.class_name)} - ${escapeHtml(student.section_name)}
                                <br>
                                <span class="text-muted" style="font-size: 0.85rem;">Roll: ${escapeHtml(student.roll_no)}</span>
                            </td>
                            <td>
                                <span class="badge ${student.is_hosteler ? 'bg-info' : 'bg-secondary'}">
                                    ${student.is_hosteler ? 'Yes' : 'No'}
                                </span>
                            </td>
                            <td>
                                ${student.driving_route ?
                                `<span class="badge bg-primary" title="${escapeHtml(student.driving_route)}">Yes</span>` :
                                `<span class="badge bg-secondary">No</span>`}
                            </td>
                            <td>
                                <span class="badge status-badge ${student.status === 'Active' ? 'bg-success' : 'bg-danger'}">
                                    ${escapeHtml(student.status)}
                                </span>
                            </td>
                            <td>
                                ${renderFeeStatus(student)}
                            </td>
                            <td>
                                ${renderActionModal(student)}
                            </td>
                        </tr>
                    `;
            $tbody.append(row);
        });
        // Update selection count after rendering
        setTimeout(updateSelectAllCheckbox, 100);
    } else {
        $tbody.html(`
                    <tr>
                        <td colspan="15" class="text-center py-4">
                            <i class="fas fa-user-slash fa-2x text-muted mb-3"></i>
                            <h5>No students found</h5>
                            ${hasFilters() ? '<p class="text-muted">Try adjusting your filters</p>' : ''}
                        </td>
                    </tr>
                `);
    }
}

// Function to load initial data (classes, sections, etc.)
function loadInitialData() {
    $.ajax({
        url: '../../api/admin/get/student/students-list-api.php',
        type: 'GET',
        dataType: 'json',
        success: function (response) {
            if (response.success) {
                // Populate class filter
                const classFilter = $('#classFilter');
                response.classes.forEach(cls => {
                    classFilter.append(`<option value="${cls.id}">${cls.class_name}</option>`);
                });

                // Populate marksheets download modal body;
                let marksheetsRows = '';

                response.exams.forEach(exam => {
                    let marksheetsDownloadTableRow = `
                            <tr>
                                <td><input type="checkbox" class="exam-checkbox-for-marksheet" data-exam-id="${exam.id}"></td>
                                <td>${exam.exam_name} (${formatDate(exam.exam_date)})</td>
                                <td>
                                    <button class="btn btn-sm btn-success single-marksheet-download-button" data-exam-id="${exam.id}">
                                        <i class="fas fa-download"></i> Download
                                    </button>
                                </td>
                            </tr>
                        `;
                    marksheetsRows += marksheetsDownloadTableRow;
                });

                $('#marksheetDownloadModalTableBody').html(marksheetsRows);

                // Populate admit cards dropdown (for bulk actions)
                const admitCards = response.admit_cards;

                // Now load the students
                loadStudents();
            } else {
                showErrorAlert('Error loading initial data');
            }
        },
        error: function (xhr) {
            showErrorAlert('Error: ' + xhr.statusText);
            console.error(xhr.responseText);
        }
    });
}

// Function to render fee status
// Replace the renderFeeStatus function with:
function renderFeeStatus(student) {
    if (student.unpaid_amount !== undefined) {
        if (student.unpaid_amount > 0) {
            return `<span class="badge bg-danger status-badge" title="Unpaid: ₹${parseFloat(student.unpaid_amount).toFixed(2)}">
                <i class="fas fa-times-circle"></i> Unpaid
            </span>`;
        } else if (student.paid_amount > 0) {
            return `<span class="badge bg-success status-badge" title="Paid: ₹${parseFloat(student.paid_amount || 0).toFixed(2)}">
                <i class="fas fa-check-circle"></i> Paid
            </span>`;
        } else {
            return `<span class="badge bg-secondary status-badge">No Fee Data</span>`;
        }
    } else {
        return `<span class="badge bg-secondary status-badge">No Fee Data</span>`;
    }
}

// Function to render action button only (Lightweight)
function renderActionModal(student) {
    // We store the necessary data in data-attributes
    // Note: escapeHtml is assumed to be a helper function you already have. 
    // If not, ensure you escape quotes in the name to prevent breaking the HTML.
    
    // Safety check for class_id
    const classId = student.class_id ? student.class_id : '';

    return `<button type="button" class="btn btn-sm btn-primary shadow-sm" 
            onclick="openGlobalStudentModal(
                '${escapeHtml(student.student_id)}', 
                '${escapeHtml(student.name.replace(/'/g, "\\'"))}', 
                '${classId}'
            )">
                <i class="fas fa-sliders-h me-1"></i> Manage
            </button>`;
}

// NEW Function to populate and show the single global modal
function openGlobalStudentModal(studentId, studentName, classId) {
    // 1. Update Header
    $('#actionModalName').text(studentName);
    $('#actionModalId').text(studentId);

    // 2. Update Profile & Academic Links
    $('#linkEditProfile').attr('href', `../student/edit-student.php?student_id=${studentId}`);
    $('#linkViewDetails').attr('href', `../../parent/dashboard/student-details.php?student_id=${studentId}`);
    $('#linkMarkEntry').attr('href', `../marksheet/students-mark-entry.php?student_ids=${studentId}`);
    $('#linkResults').attr('href', `../marksheet/view-results.php?student_id=${studentId}`);

    // 3. Update Financial Buttons (Update onclick attributes dynamically)
    
    // Monthly Fees
    $('#btnMonthlyUnpaid').attr('onclick', `fetchAllUnpaidFees('${studentName.replace(/'/g, "\\'")}', '${studentId}', 'monthly')`);
    $('#btnMonthlyFeesEntry').attr('onclick', `openFeesEntryPage(['${studentId}'], 'monthly')`);
    $('#btnMonthlyPaymentsEntry').attr('onclick', `openPaymentsEntryPage(['${studentId}'], 'monthly')`);

    // Admission Fees
    $('#btnAdmissionUnpaid').attr('onclick', `fetchAllUnpaidFees('${studentName.replace(/'/g, "\\'")}', '${studentId}', 'admission')`);
    $('#btnAdmissionFeesEntry').attr('onclick', `openFeesEntryPage(['${studentId}'], 'admission')`);
    $('#btnAdmissionPaymentsEntry').attr('onclick', `openPaymentsEntryPage(['${studentId}'], 'admission')`);

    // Extra Fees
    // Note: The original code passed classId as an array [classId]
    $('#btnExtraManage').attr('onclick', `openManageAdditionalFeesAndPaymentsModal(['${studentId}'], '${studentName.replace(/'/g, "\\'")}', [${classId}])`);
    $('#btnExtraHistory').attr('onclick', `fetchAllAdditionalFeesHistory('${studentId}', '${studentName.replace(/'/g, "\\'")}')`);

    // 4. Update More Actions
    $('#btnAdmissionForm').attr('onclick', `downloadAdmissionForm('${studentId}')`);
    
    // Permissions (Note: The original code targeted a modal #permissionModal, ensure this logic matches your permission handler)
    $('#btnPermissions').attr('onclick', `openManageDownloadsPermissionModal(['${studentId}'], '${studentName.replace(/'/g, "\\'")}')`);

    // 5. Deactive Button
    $('#btnDeactiveStudent').attr('onclick', `confirmDeactive(['${studentId}'], '${studentName.replace(/'/g, "\\'")}')`);

    // 6. Delete Button
    $('#btnDeleteStudent').attr('onclick', `confirmDelete(['${studentId}'], '${studentName.replace(/'/g, "\\'")}')`);

    // 6. Show the Modal
    $('#globalStudentActionModal').modal('show');
}

// Function to update pagination
function updatePagination(totalPages, currentPage) {
    const $pagination = $('#paginationContainer');
    $pagination.empty();

    if (totalPages <= 1) return;

    // Build pagination HTML
    let html = '';

    // Previous buttons
    if (currentPage > 1) {
        html += `
            <li class="page-item">
                <a class="page-link" href="#" data-page="1" title="First Page">
                    <i class="fas fa-angle-double-left"></i>
                </a>
            </li>
            <li class="page-item">
                <a class="page-link" href="#" data-page="${currentPage - 1}" title="Previous Page">
                    <i class="fas fa-angle-left"></i>
                </a>
            </li>
            `;
    }

    // Page numbers
    const start = Math.max(1, currentPage - 2);
    const end = Math.min(totalPages, currentPage + 2);

    if (start > 1) {
        html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
    }

    for (let i = start; i <= end; i++) {
        html += `
            <li class="page-item ${i == currentPage ? 'active' : ''}">
                <a class="page-link" href="#" data-page="${i}">${i}</a>
            </li>
            `;
    }

    if (end < totalPages) {
        html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
    }

    // Next buttons
    if (currentPage < totalPages) {
        html += `
            <li class="page-item">
                <a class="page-link" href="#" data-page="${currentPage + 1}" title="Next Page">
                    <i class="fas fa-angle-right"></i>
                </a>
            </li>
            <li class="page-item">
                <a class="page-link" href="#" data-page="${totalPages}" title="Last Page">
                    <i class="fas fa-angle-double-right"></i>
                </a>
            </li>
            `;
    }

    $pagination.html(html);
}

/**
 * Confirms student deletion by requiring the user to type
 * 'Delete [studentName]' to enable the delete button.
 * * @param {string|number} studentIds - The IDs of the students to delete.
 * @param {string} studentName - The full name of the student.
 */
function confirmDeactive(studentIds, studentName = null) {

    if ($('.modal.show').length > 0) {
        $('.modal.show').modal('hide');
    }

    if (studentIds.length <= 0) {
        showWarningAlert('No student selected for deactivation.');
        return;
    }

    if (studentName === undefined || studentName === null || studentName.trim() === '' || studentIds.length > 1) {
        studentName = studentIds.length + ' students';
    }

    Swal.fire({
        title: 'Are you sure?',
        icon: 'warning',
        html: `<p>You are about to deactive <strong>${studentName}</strong>.</p>`,
        showCancelButton: true,
        confirmButtonText: 'Yes, deactive!',
        customClass: {
            popup: 'rounded-4 shadow-lg',
            confirmButton: 'btn btn-danger px-4 py-2',
            cancelButton: 'btn btn-secondary px-4 py-2'
        },
        allowOutsideClick: () => !Swal.isLoading()
    }).then((result) => {
        // 7. This part remains the same. 
        // If 'isConfirmed' is true, it means the user typed the text correctly and clicked the button.
        if (result.isConfirmed) {
            $.ajax({
                url: '../../api/admin/put/student/deactivate-student.php',
                type: 'POST',
                data: {
                    student_ids: studentIds.join(',')
                },
                dataType: 'json',
                success: function (response) {
                    if (response.success) {
                        showSuccessAlert(response.message);
                        $('#clearSelection').click(); // Clear selection after deactivation
                        loadStudents();
                    } else {
                        showErrorAlert(response.message);
                    }
                },
                error: function (xhr) {
                    showErrorAlert('Error: ' + xhr.statusText);
                }
            });
        }
    });
}

/**
 * Confirms student deletion by requiring the user to type
 * 'Delete [studentName]' to enable the delete button.
 * * @param {string|number} studentId - The ID of the student to delete.
 * @param {string} studentName - The full name of the student.
 */
function confirmDelete(studentIds, studentName = null) {

    if ($('.modal.show').length > 0) {
        $('.modal.show').modal('hide');
    }

    // 1. Define the exact confirmation text required
    let requiredText = 'Delete ' + studentName;

    if (studentName === undefined || studentName === null || studentName.trim() === '' || studentIds.length > 1) {
        studentName = studentIds.length + ' students';
        requiredText = 'Delete all ' + studentIds.length + ' students';
    }

    Swal.fire({
        title: 'Are you absolutely sure?',
        icon: 'warning',

        // 2. Use the 'html' property for custom content
        html: `
                <p>This action <strong>cannot</strong> be undone. This will permanently delete <strong>${studentName}</strong>.</p>
                <p>Please type <strong>${requiredText}</strong> to confirm.</p>
                
                <input type="text" id="swal-confirm-input" class="swal2-input" 
                    placeholder="Type the text exactly as shown" 
                    style="width: 80%; margin-top: 10px;">
            `,

        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!',
        customClass: {
            popup: 'rounded-4 shadow-lg'
        },

        // 3. Use 'didOpen' to add custom event listeners
        didOpen: () => {
            const confirmButton = Swal.getConfirmButton();
            const inputElement = document.getElementById('swal-confirm-input');

            // 4. Disable the confirm button by default
            confirmButton.disabled = true;

            // 5. Focus the input field for the user
            inputElement.focus();

            // 6. Add an 'input' event listener to the text field
            inputElement.addEventListener('input', () => {
                // Check if the user's input matches the required text
                if (inputElement.value === requiredText) {
                    confirmButton.disabled = false; // Enable the button
                } else {
                    confirmButton.disabled = true; // Keep it disabled
                }
            });
        },

        allowOutsideClick: () => !Swal.isLoading()

    }).then((result) => {
        // 7. This part remains the same. 
        // If 'isConfirmed' is true, it means the user typed the text correctly and clicked the button.
        if (result.isConfirmed) {
            $.ajax({
                url: '../../api/admin/delete/student/delete-student.php',
                type: 'POST',
                data: {
                    student_ids: studentIds.join(',')
                },
                dataType: 'json',
                success: function (response) {
                    if (response.success) {
                        toastr.success(response.message);
                        showSuccessAlert(response.message);
                        $('#clearSelection').click(); // Clear selection after deletion
                        loadStudents();
                    } else {
                        showErrorAlert(response.message);
                    }
                },
                error: function (xhr) {
                    showErrorAlert('Error: ' + xhr.statusText);
                }
            });
        }
    });
}

// Debounce function to prevent too many AJAX calls
function debounce(func, wait, immediate) {
    let timeout;
    return function () {
        const context = this,
            args = arguments;
        const later = function () {
            timeout = null;
            if (!immediate) func.apply(context, args);
        };
        const callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func.apply(context, args);
    };
}

// Function to check if selected students are all in the same class
function areSelectedStudentsFromSameClass(selectedClassIds) {
    if (selectedClassIds.length > 0) {
        // Loop through selected IDs and check if they are in the same class
        let allSameClass = true;
        const classId = selectedClassIds[0];

        for (let i = 1; i < selectedClassIds.length; i++) {
            if (selectedClassIds[i] !== classId) {
                allSameClass = false;
                break;
            }
        }

        if (allSameClass) {
            return true;
        } else {
            return false;
        }
    } else {
        showWarningAlert('Please select at least one student');
        return false;
    }
}