// Helper function to get selected student IDs
function getSelectedStudentIds() {
    // Return the global array instead of just visible checkboxes
    console.log(globalSelectedStudents);
    return globalSelectedStudents.map(id => id);
}

// Helper function to get selected class IDs (you'll need to modify this)
function getSelectedClassIds() {
    const selectedClassIds = [];
    globalSelectedStudents.forEach(function(studentId) {
        if (globalStudentClasses[studentId]) {
            selectedClassIds.push(globalStudentClasses[studentId]);
        }
    });
    return selectedClassIds;
}

// Add this new function to preserve selections before reload
function preserveSelectionsBeforeReload() {
    // Don't just capture visible checkboxes, maintain the global array
    $('.student-checkbox:checked').each(function () {
        const studentId = $(this).data('student-id').toString();
        const classId = $(this).data('class-id').toString();
        if (!globalSelectedStudents.includes(studentId)) {
            globalSelectedStudents.push(studentId);
        }
        // স্টুডেন্টের ক্লাস আইডি সেভ করে রাখুন
        globalStudentClasses[studentId] = classId; 
    });

    // Remove unchecked students from global array
    $('.student-checkbox:not(:checked)').each(function () {
        const studentId = $(this).data('student-id').toString();
        const index = globalSelectedStudents.indexOf(studentId);
        if (index > -1) {
            globalSelectedStudents.splice(index, 1);
        }
    });
}

// Update selected count display
// Update the updateSelectedCount function
function updateSelectedCount() {
    // Update global array with current page selections
    $('.student-checkbox:checked').each(function () {
        const studentId = $(this).data('student-id').toString();
        if (!globalSelectedStudents.includes(studentId)) {
            globalSelectedStudents.push(studentId);
        }
    });

    // Remove unchecked students from current page
    $('.student-checkbox:not(:checked)').each(function () {
        const studentId = $(this).data('student-id').toString();
        const index = globalSelectedStudents.indexOf(studentId);
        if (index > -1) {
            globalSelectedStudents.splice(index, 1);
        }
    });

    // Update the UI count
    $('#selectedCount').text(globalSelectedStudents.length + ' selected');

    // Show/hide bulk actions panel
    if (globalSelectedStudents.length > 0) {
        $('#bulkActionsPanel').slideDown();
    } else {
        $('#bulkActionsPanel').slideUp();
    }

    // Update "Select All" checkbox state for current page
    updateSelectAllCheckbox();
}

// NEW: Function to update "Select All" checkbox state
function updateSelectAllCheckbox() {
    const visibleCheckboxes = $('.student-checkbox');
    const checkedVisibleCheckboxes = $('.student-checkbox:checked');

    if (visibleCheckboxes.length === 0) {
        $('#selectAll').prop('checked', false).prop('indeterminate', false);
    } else if (checkedVisibleCheckboxes.length === visibleCheckboxes.length) {
        $('#selectAll').prop('checked', true).prop('indeterminate', false);
    } else if (checkedVisibleCheckboxes.length > 0) {
        $('#selectAll').prop('checked', false).prop('indeterminate', true);
    } else {
        $('#selectAll').prop('checked', false).prop('indeterminate', false);
    }
}