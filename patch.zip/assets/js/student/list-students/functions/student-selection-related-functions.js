// Helper function to get selected student IDs
function getSelectedStudentIds() {
    // Return the global array instead of just visible checkboxes
    console.log(globalSelectedStudents);
    return globalSelectedStudents.map(id => id);
}

// Helper function to get selected class IDs (you'll need to modify this)
function getSelectedClassIds() {
    // Since we need class IDs, we should store them in globalSelectedStudents as objects
    // For now, let's get class IDs from currently visible selections
    const selectedIds = [];
    $('.student-checkbox:checked').each(function () {
        selectedIds.push($(this).data('class-id'));
    });
    return selectedIds;
}

// Add this new function to preserve selections before reload
function preserveSelectionsBeforeReload() {
    // Don't just capture visible checkboxes, maintain the global array
    $('.student-checkbox:checked').each(function () {
        const studentId = $(this).data('student-id').toString();
        if (!globalSelectedStudents.includes(studentId)) {
            globalSelectedStudents.push(studentId);
        }
    });

    // Remove unchecked students from global array
    $('.student-checkbox:not(:checked)').each(function () {
        const studentId = $(this).data('student-id').toString();
        const index = globalSelectedStudents.indexOf(studentId);
        if (index > -1) {
            globalSelectedStudents.splice(index, 1);
        }
    });
}

// Function to show all selected students in a modal
function showAllSelectedStudentsInfo() {
    console.log('Showing selected students details');

    if (globalSelectedStudents.length === 0) {
        showWarningAlert('No students selected');
        return;
    }

    // Fetch details of all selected students
    $.ajax({
        url: '../../api/admin/get/student/get-selected-students-details.php',
        type: 'POST',
        data: {
            student_ids: globalSelectedStudents.join(',')
        },
        dataType: 'json',
        success: function (response) {
            if (response.success) {
                let html = '<div class="table-responsive"><table class="table table-sm">';
                html += '<thead><tr><th>ID</th><th>Name</th><th>Class</th></tr></thead><tbody>';

                response.students.forEach(student => {
                    html += `<tr>
                                <td>${student.student_id}</td>
                                <td>${student.name}</td>
                                <td>${student.class_name} - ${student.section_name}</td>
                            </tr>`;
                });

                html += '</tbody></table></div>';

                // Swal.fire({
                //     title: `Selected Students (${globalSelectedStudents.length})`,
                //     html: html,
                //     width: '600px',
                //     confirmButtonText: 'Close'
                // });
                showInfoAlert(html, 'Selected Students');
            }
        },
        error: function () {
            showErrorAlert('Error fetching student details');
        }
    });
}

// Update selected count display
// Update the updateSelectedCount function
function updateSelectedCount() {
    // Update global array with current page selections
    $('.student-checkbox:checked').each(function () {
        const studentId = $(this).data('student-id').toString();
        if (!globalSelectedStudents.includes(studentId)) {
            globalSelectedStudents.push(studentId);
        }
    });

    // Remove unchecked students from current page
    $('.student-checkbox:not(:checked)').each(function () {
        const studentId = $(this).data('student-id').toString();
        const index = globalSelectedStudents.indexOf(studentId);
        if (index > -1) {
            globalSelectedStudents.splice(index, 1);
        }
    });

    // Update the UI count
    $('#selectedCount').text(globalSelectedStudents.length + ' selected');

    // Show/hide bulk actions panel
    if (globalSelectedStudents.length > 0) {
        $('#bulkActionsPanel').slideDown();
    } else {
        $('#bulkActionsPanel').slideUp();
    }

    // Update "Select All" checkbox state for current page
    updateSelectAllCheckbox();
}

// NEW: Function to update "Select All" checkbox state
function updateSelectAllCheckbox() {
    const visibleCheckboxes = $('.student-checkbox');
    const checkedVisibleCheckboxes = $('.student-checkbox:checked');

    if (visibleCheckboxes.length === 0) {
        $('#selectAll').prop('checked', false).prop('indeterminate', false);
    } else if (checkedVisibleCheckboxes.length === visibleCheckboxes.length) {
        $('#selectAll').prop('checked', true).prop('indeterminate', false);
    } else if (checkedVisibleCheckboxes.length > 0) {
        $('#selectAll').prop('checked', false).prop('indeterminate', true);
    } else {
        $('#selectAll').prop('checked', false).prop('indeterminate', false);
    }
}

// ADD: Function to display selection summary
function displaySelectionSummary() {
    if (globalSelectedStudents.length > 0) {
        const visibleSelected = $('.student-checkbox:checked').length;
        const totalSelected = globalSelectedStudents.length;

        if (totalSelected > visibleSelected) {
            $('.results-summary').append(`
                    <div class="alert alert-info alert-sm mt-2">
                        <i class="fas fa-info-circle"></i> 
                        ${totalSelected} students selected (${visibleSelected} visible on this page)
                        <button class="btn btn-sm btn-outline-primary ms-2" id="showSelectedStudentsInfoBtn">
                            View All Selected
                        </button>
                    </div>
                `);
        }
    }
}