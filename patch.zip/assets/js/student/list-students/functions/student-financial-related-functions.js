// Function to fetch all additional fees data
function fetchAllAdditionalFeesHistory(student_id, student_name = null) {
    $.ajax({
        url: '../../api/admin/get/fees-x-payments/get-student-additional-fees-data.php',
        type: 'GET', // Use GET for fetching data
        data: {
            student_id: student_id
        },
        dataType: 'json',
        beforeSend: function () {
            // Show loading indicator
            showLoadingAlert('Fetching Additional Fees...', '<div class="spinner-border text-primary" role="status"></div>');
        },
        success: function (response) {

            if (response.success) {
                // Show success message
                toastr.success(response.message);
                Swal.close();
                let html = '';
                response.data.forEach(function (fee) {
                    html += `
                        <tr class="text-center align-middle">
                            <td>${fee.class_name}</td>
                            <td>${fee.fee_type}</td>
                            <td>${fee.amount}</td>
                            <td>
                                <span class="badge ${fee.additional_fee_status == 'paid'
                            ? 'bg-success'
                            : 'bg-danger'
                        } text-capitalize">
                                    ${fee.additional_fee_status}
                                </span>
                            </td>
                            <td>${fee.additional_fee_status == 'paid'
                            ? fee.additional_fee_paid_date
                            : fee.additional_fee_due_date
                        }
                            </td>
                            <td>
                                <div class="d-flex justify-content-center align-items-center gap-1">
                                    <button class="btn btn-sm btn-danger" onclick="deleteAdditionalFeeEntry('${fee.additional_fee_setup_id}', '${student_id}', '${student_name}')" title="Delete Entry">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                    <button class="btn btn-sm btn-success" onclick="markAdditionalFeeEntry('${fee.additional_fee_setup_id}', 'paid', '${student_id}', '${student_name}')" title="Mark as Paid">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </button>
                                    <button class="btn btn-sm btn-warning" onclick="markAdditionalFeeEntry('${fee.additional_fee_setup_id}', 'unpaid', '${student_id}', '${student_name}')" title="Mark as Unpaid">
                                        <i class="fa-solid fa-clock"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        `;
                });

                $('#listAllAdditionalFeesModalTableBody').html(html);
                $('#listAllAdditionalFeesModalLabel').html(`Additional Fees History <b>(${student_name})</b>`);
                $('#listAllAdditionalFeesModal').modal('show');
                console.log(response.data);
            } else {
                showWarningAlert(response.message);
            }
        },
        error: function (xhr) {
            showErrorAlert('Error fetching additional fees data');
            console.error(xhr.responseText);
        }
    });
}

/**
 * Deletes an additional fee entry after confirmation.
 * @param {string} additional_fee_id - The ID of the fee entry to delete.
 */
function deleteAdditionalFeeEntry(additional_fee_id, student_id, student_name = null) {

    // 1. Show SweetAlert2 confirmation dialog for deletion
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!',
        customClass: {
            popup: 'rounded-4 shadow-lg'
        }
    }).then((result) => {

        // 2. If the user confirmed, proceed with the AJAX call
        if (result.isConfirmed) {

            $('#listAllAdditionalFeesModal').modal('hide');

            $.ajax({
                // IMPORTANT: Make sure this URL is correct for your API
                url: '../../api/admin/delete/fees-x-payments/delete-additional-fee-entry.php',
                type: 'POST', // Using POST, but some APIs might prefer 'DELETE'
                data: {
                    additional_fee_id: additional_fee_id,
                    student_id: student_id
                },
                dataType: 'json',
                beforeSend: function () {
                    showLoadingAlert('Deleting Entry...', '<div class="spinner-border text-primary" role="status"></div>');
                },
                success: function (response) {
                    if (response.success) {
                        showSuccessAlert(response.message);
                    } else {
                        showErrorAlert(response.message);
                        console.error(response.error);
                    }
                },
                error: function (xhr) {
                    showErrorAlert('An error occurred while deleting the entry.');
                    console.error(xhr.responseText);
                }
            });
        }
    });
}

/**
 * Marks an additional fee as 'paid' or 'unpaid' after confirmation.
 * @param {string} additional_fee_id - The ID of the fee entry to update.
 * @param {string} new_status - The new status, either 'paid' or 'unpaid'.
 */
function markAdditionalFeeEntry(additional_fee_id, new_status, student_id, student_name) {

    // 1. Set up dynamic text for the confirmation dialog
    const titleText = `Mark as ${new_status.charAt(0).toUpperCase() + new_status.slice(1)}?`;
    const confirmButtonText = `Yes, mark as ${new_status}!`;
    // Set button color: green for 'paid', yellow/warning for 'unpaid'
    const confirmButtonColor = (new_status === 'paid') ? '#28a745' : '#ffc107';

    // 2. Show SweetAlert2 confirmation dialog
    Swal.fire({
        title: titleText,
        text: `Do you want to update this fee status to ${new_status}?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: confirmButtonColor,
        cancelButtonColor: '#d33',
        confirmButtonText: confirmButtonText,
        customClass: {
            popup: 'rounded-4 shadow-lg'
        }
    }).then((result) => {

        // 3. If the user confirmed, proceed with the AJAX call
        if (result.isConfirmed) {

            $('#listAllAdditionalFeesModal').modal('hide');

            $.ajax({
                // IMPORTANT: Make sure this URL is correct for your API
                url: '../../api/admin/put/fees-x-payments/update-additional-fee-status.php',
                type: 'POST',
                data: {
                    additional_fee_id: additional_fee_id,
                    new_status: new_status,
                    student_id: student_id
                },
                dataType: 'json',
                beforeSend: function () {
                    showLoadingAlert('Updating Status...', '<div class="spinner-border text-primary" role="status"></div>');
                },
                success: function (response) {
                    if (response.success) {
                        toastr.success(response.message);
                        Swal.close();
                        if (student_id) {
                            // Call the original function to refresh the table
                            fetchAllAdditionalFeesHistory(student_id, student_name);
                        } else {
                            // Fallback just in case
                            showInfoAlert('Please reopen the modal to see changes.');
                        }
                    } else {
                        // Handle server-side errors (e.g., validation)
                        showErrorAlert(response.message);
                        console.error(response.error);
                    }
                },
                error: function (xhr) {
                    showErrorAlert('An error occurred while updating the fee status.');
                    console.error(xhr.responseText);
                }
            });
        }
    });
}

// Function to manage unpaid fees
function fetchAllUnpaidFees(student_name, student_id, feesType = 'monthly') {

    let api_url = '../../api/admin/get/fees-x-payments/fetch-all-monthly-unpaid-fees.php';
    let fees_type_text = 'Monthly';

    if (feesType == 'admission') {
        fees_type_text = 'Admission';
    }

    if (feesType == 'admission') {
        api_url = '../../api/admin/get/fees-x-payments/fetch-all-admission-unpaid-fees.php';
    }

    $.ajax({
        url: api_url,
        type: 'GET', // Use GET for fetching data
        data: {
            student_id: student_id
        },
        dataType: 'json',
        beforeSend: function () {
            showLoadingAlert('Fetching Unpaid Fees...', '<div class="spinner-border text-primary" role="status"></div>');
        },
        success: function (response) {
            if (response.success) {
                // Show success message
                toastr.success(response.message);
                Swal.close();
                // Populate the modal body with the unpaid fees data
                let html = response.html;
                $('#manageUnpaidFeesModalBody').html(html);
                $('#manageUnpaidFeesModal').modal('show');
                $('#manageUnpaidFeesModalLabel').html('Unpaid ' + fees_type_text + ' Fees for <b>' + student_name + '</b>');
            } else {
                showErrorAlert(response.message);
            }
        },
        error: function (xhr) {
            showErrorAlert('An error occurred while fetching unpaid fees.');
            console.error(xhr.responseText);
        }
    });
}

// Function to delete unpaid fee entry
function deleteUnpaidFeeEntry(entryId, btn, feesType = 'monthly') {

    let api_url = '../../api/admin/delete/fees-x-payments/delete-unpaid-monthly-fee-entry.php';
    if (feesType == 'admission') {
        api_url = '../../api/admin/delete/fees-x-payments/delete-unpaid-admission-fee-entry.php';
    }

    Swal.fire({
        title: 'Are you sure?',
        text: "This action cannot be undone!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'No, cancel!',
        customClass: {
            popup: 'rounded-4 shadow-lg'
        }
    }).then((result) => {
        if (result.isConfirmed) {
            // Proceed with deletion
            $.ajax({
                url: api_url,
                type: 'POST',
                data: {
                    entry_id: entryId
                },
                dataType: 'json',
                beforeSend: function () {
                    showLoadingAlert('Deleting Fee Entry...', '<div class="spinner-border text-primary" role="status"></div>');
                },
                success: function (response) {
                    if (response.success) {
                        // Show success message
                        toastr.success(response.message);
                        Swal.close();
                        // Refresh the unpaid fees modal content
                        $(btn).closest('.alert').remove();
                        if ($('#manageUnpaidFeesModalBody').children().length === 0) {
                            $('#manageUnpaidFeesModal').modal('hide');
                            showInfoAlert('No more unpaid fees for this student.');
                        }
                    } else {
                        showErrorAlert(response.message);
                    }
                },
                error: function (xhr) {
                    showErrorAlert('An error occurred while deleting the fee entry.');
                    console.error(xhr.responseText);
                }
            });
        }
    });
}

// Function to show/hide additional fees due/payement date
function additionalFeesDueAndPaymentDateShowHide() {
    let status = $('#additional_fee_status').val();
    let additional_fee_paid_date = $('#additional_fee_paid_date');
    let additional_fee_due_date = $('#additional_fee_due_date');

    if (status == 'unpaid') {
        additional_fee_paid_date.parent().hide();
        additional_fee_due_date.parent().show();

        // Fix: 'paid_date' is hidden, so it is NOT required
        $('[name="additional_fee_paid_date"]').prop('required', false);
        // Fix: 'due_date' is shown, so it IS required
        $('[name="additional_fee_due_date"]').prop('required', true);

    } else if (status == 'paid') {
        additional_fee_paid_date.parent().show();
        additional_fee_due_date.parent().hide();

        // Fix: 'paid_date' is shown, so it IS required
        $('[name="additional_fee_paid_date"]').prop('required', true);
        // Fix: 'due_date' is hidden, so it is NOT required
        $('[name="additional_fee_due_date"]').prop('required', false);

    } else {
        // This part was already correct
        additional_fee_paid_date.parent().hide();
        additional_fee_due_date.parent().hide();
        $('[name="additional_fee_paid_date"]').prop('required', false);
        $('[name="additional_fee_due_date"]').prop('required', false);
    }
}

// Function to open additional fees and payments modal
function openManageAdditionalFeesAndPaymentsModal(selectedStudentIds, studentName = null, selectedClassIds) {

    if (selectedStudentIds.length === 0) {
        showWarningAlert('Please select at least one student.');
        return;
    }

    if (selectedStudentIds.length === 1) {
        singleStudentId = selectedStudentIds[0];
    }

    if (!areSelectedStudentsFromSameClass(selectedClassIds)) {
        showWarningAlert('Please select students from the same class.');
        return;
    }

    if (studentName && selectedStudentIds.length === 1) {
        $('#additionalFeesManagementModalFor').text('(' + studentName + ')');
    } else {
        $('#additionalFeesManagementModalFor').text('(' + selectedStudentIds.length + ' students)');
    }

    $('#additionalFeesManagementModalFormStudentIds').val(selectedStudentIds.join(','));

    let classId = selectedClassIds[0];
    
    // Fetch additional fees data before showing modal
    $.ajax({
        url: '../../api/admin/get/fees-x-payments/get-additional-fees-setup-by-class.php',
        method: 'POST',
        dataType: 'json', // make sure your PHP returns JSON
        data: {
            class_id: classId
        },
        beforeSend: function () {
            showLoadingAlert();
        },
        success: function (response) {
            console.log('Success:', response);
            Swal.close();
            if (response.success) {
                let html = '<option value="" selected disabled>-- Select Fees Type --</option>';
                response.amounts.forEach(function (fee) {
                    html += `
                        <option value="${fee.id}">${fee.fee_type} (${currencySymbol}${fee.amount})</option>
                        `;
                });
                // Populate the modal with the data
                $('#additional_fees_setup_id').html(html);
                // Show the modal
                $('#additionalFeesManagementModal').modal('show');
            } else {
                showErrorAlert(response.message);
            }
        },
        error: function (xhr) {
            console.error(xhr.responseText);
            showErrorAlert('Error fetching additional fees data');
        }
    });
}

// Function to open admission fees and payments modal
function openManageAdmissionFeesAndPaymentsModal(selectedStudentIds, studentName = null) {

    let bulkFeeModal = new bootstrap.Modal(document.getElementById('bulkAdmissionFeeModal'));

    if (selectedStudentIds.length === 0) {
        showWarningAlert('Please select at least one student.');
        return;
    }

    if (studentName && selectedStudentIds.length === 1) {
        $('.studentNameInModal').text('[' + studentName + ']');
    } else {
        $('.studentNameInModal').text('');
    }

    if (selectedStudentIds.length === 1) {
        singleStudentId = selectedStudentIds[0];
        // For single student, fetch fee info and show it
        $.ajax({
            url: '../../api/admin/get/fees-x-payments/get-admission-fees-info-remark.php',
            method: 'POST',
            dataType: 'json', // make sure your PHP returns JSON
            data: {
                student_id: selectedStudentIds[0]
            },
            beforeSend: function () {
                showLoadingAlert();
            },
            success: function (response) {
                console.log('Success:', response);
                Swal.close();
                if (response.success) {
                    $('.payment-entry-info-alert-container').html(`
                            <div class="alert alert-info" role="alert">
                                ${response.message}
                            </div>
                        `);
                } else {
                    $('.payment-entry-info-alert-container').html(`
                                <div class="alert alert-warning" role="alert">
                                    ${response.message || 'No info available'}
                                </div>
                            `);
                }
            },
            error: function (xhr, status, error) {
                console.error('AJAX Error:', error);
                console.error('Error:', xhr.responseText);
                showErrorAlert('Error fetching fee info');
            },
            complete: function () {
                bulkFeeModal.show(); // ✅ Show the modal
            }
        });
    } else {
        $('.payment-entry-info-alert-container').html(`
                    <div class="alert alert-info" role="alert">
                        Payment entry for total <b>${selectedStudentIds.length}</b> students.
                    </div>
                `);

        bulkFeeModal.show();
    }
}

// Function to open the bulk fees and payments modal
function openManageMonthlyFeesAndPaymentsModal(selectedStudentIds, studentName = null) {

    let bulkFeeModal = new bootstrap.Modal(document.getElementById('bulkMonthlyFeeModal'));

    if (selectedStudentIds.length === 0) {
        showWarningAlert('Please select at least one student.');
        return;
    }

    if (studentName && selectedStudentIds.length === 1) {
        $('.studentNameInModal').text('[' + studentName + ']');
    } else {
        $('.studentNameInModal').text('');
    }

    if (selectedStudentIds.length === 1) {
        singleStudentId = selectedStudentIds[0];
        // For single student, fetch fee info and show it
        $.ajax({
            url: '../../api/admin/get/fees-x-payments/get-fees-info-remark.php',
            method: 'POST',
            dataType: 'json', // make sure your PHP returns JSON
            data: {
                student_id: selectedStudentIds[0]
            },
            beforeSend: function () {
                showLoadingAlert();
            },
            success: function (response) {
                console.log('Success:', response);
                Swal.close();
                if (response.success) {
                    $('.payment-entry-info-alert-container').html(`
                                <div class="alert alert-info" role="alert">
                                    ${response.message}
                                </div>
                            `);
                } else {
                    $('.payment-entry-info-alert-container').html(`
                                <div class="alert alert-warning" role="alert">
                                    ${response.message || 'No info available'}
                                </div>
                            `);
                }
            },
            error: function (xhr, status, error) {
                console.error('Error:', xhr.responseText);
                showErrorAlert('Error fetching fee info');
            },
            complete: function () {
                bulkFeeModal.show(); // ✅ Show the modal
            }
        });
    } else {
        $('.payment-entry-info-alert-container').html(`
                    <div class="alert alert-info" role="alert">
                        Payment entry for total <b>${selectedStudentIds.length}</b> students.
                    </div>
                `);

        bulkFeeModal.show();
    }
}

function toggleOverrideOptions(type, show) {
    const container = type === 'admit' ? '#admitCardOverrideContainer' : '#marksheetOverrideContainer';
    if (show) {
        $(container).show();
    } else {
        $(container).hide();
        $(container).find('input[type="checkbox"]').prop('checked', false);
    }
}

function populateMonthlyFeesSelection() {

    const totalMonths = 15;
    // Clear existing options first to prevent duplicates if called multiple times
    $('.feeMonthSelect').empty(); 

    for (let i = totalMonths; i >= -totalMonths; i--) {
        const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const month = date.toLocaleString('default', { month: 'long' });
        const year = date.getFullYear();
        const value = `${month} ${year}`;

        $('.feeMonthSelect').each(function () {
            const option = document.createElement('option');
            option.value = value;
            option.textContent = value;

            // Set selected if it's the current month and year
            if (date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear()) {
                option.selected = true;
            }

            $(this).append(option);
        });
    }
}