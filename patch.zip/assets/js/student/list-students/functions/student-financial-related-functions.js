// Function to fetch all additional fees data
function fetchAllAdditionalFeesHistory(student_id, student_name = null) {
    $.ajax({
        url: '../../api/admin/get/fees-x-payments/get-student-additional-fees-data.php',
        type: 'GET', // Use GET for fetching data
        data: {
            student_id: student_id
        },
        dataType: 'json',
        beforeSend: function () {
            // Show loading indicator
            showLoadingAlert('Fetching Additional Fees...', '<div class="spinner-border text-primary" role="status"></div>');
        },
        success: function (response) {

            if (response.success) {
                // Show success message
                toastr.success(response.message);
                Swal.close();
                let html = '';
                response.data.forEach(function (fee) {
                    html += `
                        <tr class="text-center align-middle">
                            <td>${fee.class_name}</td>
                            <td>${fee.fee_type}</td>
                            <td>${fee.amount}</td>
                            <td>
                                <span class="badge ${fee.additional_fee_status == 'paid'
                            ? 'bg-success'
                            : 'bg-danger'
                        } text-capitalize">
                                    ${fee.additional_fee_status}
                                </span>
                            </td>
                            <td>${fee.additional_fee_status == 'paid'
                            ? fee.additional_fee_paid_date
                            : fee.additional_fee_due_date
                        }
                            </td>
                            <td>
                                <div class="d-flex justify-content-center align-items-center gap-1">
                                    <button class="btn btn-sm btn-danger" onclick="deleteAdditionalFeeEntry('${fee.additional_fee_setup_id}', '${student_id}', '${student_name}')" title="Delete Entry">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                    <button class="btn btn-sm btn-success" onclick="markAdditionalFeeEntry('${fee.additional_fee_setup_id}', 'paid', '${student_id}', '${student_name}')" title="Mark as Paid">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </button>
                                    <button class="btn btn-sm btn-warning" onclick="markAdditionalFeeEntry('${fee.additional_fee_setup_id}', 'unpaid', '${student_id}', '${student_name}')" title="Mark as Unpaid">
                                        <i class="fa-solid fa-clock"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        `;
                });

                $('#listAllAdditionalFeesModalTableBody').html(html);
                $('#listAllAdditionalFeesModalLabel').html(`Additional Fees History <b>(${student_name})</b>`);
                $('#listAllAdditionalFeesModal').modal('show');
                console.log(response.data);
            } else {
                showWarningAlert(response.message);
            }
        },
        error: function (xhr) {
            showErrorAlert('Error fetching additional fees data');
            console.error(xhr.responseText);
        }
    });
}

/**
 * Deletes an additional fee entry after confirmation.
 * @param {string} additional_fee_id - The ID of the fee entry to delete.
 */
function deleteAdditionalFeeEntry(additional_fee_id, student_id, student_name = null) {

    // 1. Show SweetAlert2 confirmation dialog for deletion
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!',
        customClass: {
            popup: 'rounded-4 shadow-lg'
        }
    }).then((result) => {

        // 2. If the user confirmed, proceed with the AJAX call
        if (result.isConfirmed) {

            $('#listAllAdditionalFeesModal').modal('hide');

            $.ajax({
                // IMPORTANT: Make sure this URL is correct for your API
                url: '../../api/admin/delete/fees-x-payments/delete-additional-fee-entry.php',
                type: 'POST', // Using POST, but some APIs might prefer 'DELETE'
                data: {
                    additional_fee_id: additional_fee_id,
                    student_id: student_id
                },
                dataType: 'json',
                beforeSend: function () {
                    showLoadingAlert('Deleting Entry...', '<div class="spinner-border text-primary" role="status"></div>');
                },
                success: function (response) {
                    if (response.success) {
                        showSuccessAlert(response.message);
                    } else {
                        showErrorAlert(response.message);
                        console.error(response.error);
                    }
                },
                error: function (xhr) {
                    showErrorAlert('An error occurred while deleting the entry.');
                    console.error(xhr.responseText);
                }
            });
        }
    });
}

/**
 * Marks an additional fee as 'paid' or 'unpaid' after confirmation.
 * @param {string} additional_fee_id - The ID of the fee entry to update.
 * @param {string} new_status - The new status, either 'paid' or 'unpaid'.
 */
function markAdditionalFeeEntry(additional_fee_id, new_status, student_id, student_name) {

    // 1. Set up dynamic text for the confirmation dialog
    const titleText = `Mark as ${new_status.charAt(0).toUpperCase() + new_status.slice(1)}?`;
    const confirmButtonText = `Yes, mark as ${new_status}!`;
    // Set button color: green for 'paid', yellow/warning for 'unpaid'
    const confirmButtonColor = (new_status === 'paid') ? '#28a745' : '#ffc107';

    // 2. Show SweetAlert2 confirmation dialog
    Swal.fire({
        title: titleText,
        text: `Do you want to update this fee status to ${new_status}?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: confirmButtonColor,
        cancelButtonColor: '#d33',
        confirmButtonText: confirmButtonText,
        customClass: {
            popup: 'rounded-4 shadow-lg'
        }
    }).then((result) => {

        // 3. If the user confirmed, proceed with the AJAX call
        if (result.isConfirmed) {

            $('#listAllAdditionalFeesModal').modal('hide');

            $.ajax({
                // IMPORTANT: Make sure this URL is correct for your API
                url: '../../api/admin/put/fees-x-payments/update-additional-fee-status.php',
                type: 'POST',
                data: {
                    additional_fee_id: additional_fee_id,
                    new_status: new_status,
                    student_id: student_id
                },
                dataType: 'json',
                beforeSend: function () {
                    showLoadingAlert('Updating Status...', '<div class="spinner-border text-primary" role="status"></div>');
                },
                success: function (response) {
                    if (response.success) {
                        toastr.success(response.message);
                        Swal.close();
                        if (student_id) {
                            // Call the original function to refresh the table
                            fetchAllAdditionalFeesHistory(student_id, student_name);
                        } else {
                            // Fallback just in case
                            showInfoAlert('Please reopen the modal to see changes.');
                        }
                    } else {
                        // Handle server-side errors (e.g., validation)
                        showErrorAlert(response.message);
                        console.error(response.error);
                    }
                },
                error: function (xhr) {
                    showErrorAlert('An error occurred while updating the fee status.');
                    console.error(xhr.responseText);
                }
            });
        }
    });
}

// Function to fetch unpaid fees data
function fetchFullyUnpaidFees(selectedStudentIds, feesType = 'monthly') {
    if (selectedStudentIds.length === 0) {
        showWarningAlert('Please select at least one student.');
        return;
    }

    let url = `../../api/admin/get/fees-x-payments/monthly/monthly-unpaid-fees-data.php?student_ids=${selectedStudentIds.join(',')}`;

    if (feesType == 'admission') {
        url = `../../api/admin/get/fees-x-payments/admission/admission-unpaid-fees-data.php?student_ids=${selectedStudentIds.join(',')}`;
    }

    $.ajax({
        url: url,
        type: 'GET',
        dataType: 'json',
        beforeSend: function () {
            showLoadingAlert('Fetching Unpaid Fees Data...');
        },
        success: function (response) {
            Swal.close();
            if (response.success) {
                toastr.success(response.message);
                let data = response.data;
                if (data.length > 0) {
                    let table = `<div class="table-responsive"><table class="table table-sm table-hover table-bordered table-striped table-condensed text-center"><thead class="table-dark"><tr><th>Period</th><th>Action</th></tr></thead><tbody>`;
                    
                    // Array টিকে JSON স্ট্রিং এ রূপান্তর করা হলো যাতে onclick এর ভেতর সঠিকভাবে পাস করা যায়
                    let idsStr = JSON.stringify(selectedStudentIds);

                    data.forEach(item => {
                        // ${this} এর বদলে this এবং ${selectedStudentIds} এর বদলে ${idsStr} ব্যবহার করা হয়েছে
                        // এবং onclick এর বাইরের কোটেশন সিঙ্গল (') করা হয়েছে যাতে ভেতরের ডাবল (") কোটেশনের সাথে কনফ্লিক্ট না হয়
                        table += `<tr><td>${item}</td><td><a href="javascript:void(0)" class="btn btn-sm btn-danger" onclick='deleteUnpaidMonthlyFees(this, ${idsStr}, "${item}", "${feesType}")'>Delete</a></td></tr>`;
                    });
                    
                    table += `</tbody></table></div>`;

                    $('#manageUnpaidFeesModalBody').html(table);
                    $('#manageUnpaidFeesModal').modal('show');
                    $('#manageUnpaidFeesModalLabel').html('Unpaid Fees for <b>' + selectedStudentIds.length + '</b> students');
                } else {
                    showInfoAlert('No unpaid fees found.');
                }
            } else {
                showErrorAlert(response.message);
            }
        },
        error: function (xhr) {
            showErrorAlert('An error occurred while fetching unpaid fees data.');
            console.error(xhr.responseText);
            sendErrorReport(xhr.responseText);
        }
    });
}

function deleteUnpaidMonthlyFees(btn, selectedStudentIds, period, feeType = 'monthly') {
    // প্রথমে চেক করুন কোনো স্টুডেন্ট সিলেক্ট করা হয়েছে কিনা
    if (selectedStudentIds.length === 0) {
        showWarningAlert('Please select at least one student.');
        return;
    }

    // এরপর কনফার্মেশন ডায়ালগ দেখান
    Swal.fire({
        title: 'Are you sure?',
        text: `You won\'t be able to revert this! Unpaid ${feeType} fee ${period} will be deleted.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        customClass: {
            popup: 'rounded-4 shadow-lg',
            confirmButton: 'btn btn-danger px-4 py-2',
            cancelButton: 'btn btn-secondary px-4 py-2'
        },
        allowOutsideClick: () => !Swal.isLoading()
    }).then((result) => {
        // যদি ব্যবহারকারী "Yes, delete it!" এ ক্লিক করে, তবেই ডিলিট প্রসেস শুরু হবে
        if (result.isConfirmed) {

            let apiURL = '../../api/admin/delete/fees-x-payments/monthly/delete-unpaid-monthly-fees.php';

            if (feeType == 'admission') {
                apiURL = '../../api/admin/delete/fees-x-payments/admission/delete-unpaid-admission-fees.php';
            }
            
            $.ajax({
                url: apiURL,
                type: 'POST',
                data: {
                    student_ids: selectedStudentIds,
                    period: period
                },
                dataType: 'json',
                beforeSend: function () {
                    btn.disabled = true;
                    btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Deleting...';
                },
                success: function (response) {
                    if (response.success) {
                        toastr.success(response.message);
                        let row = $(btn).closest('tr');
                        row.remove();
                        fetchFullyUnpaidFees(selectedStudentIds, feeType);
                    } else {
                        // Handle server-side errors (e.g., validation)
                        showErrorAlert(response.message);
                    }
                },
                error: function (xhr) {
                    showErrorAlert('An error occurred while deleting unpaid fees.');
                    console.error(xhr.responseText);
                    sendErrorReport(xhr.responseText);
                },
                complete: function () {
                    btn.disabled = false;
                    btn.innerHTML = 'Delete';
                }
            });
        }
    });
}

// Function to manage unpaid fees
function fetchAllUnpaidFees(student_name, student_id, feesType = 'monthly') {

    let api_url = '../../api/admin/get/fees-x-payments/monthly/fetch-all-monthly-unpaid-fees.php';
    let fees_type_text = 'Monthly';

    if (feesType == 'admission') {
        fees_type_text = 'Admission';
    }

    if (feesType == 'admission') {
        api_url = '../../api/admin/get/fees-x-payments/admission/fetch-all-admission-unpaid-fees.php';
    }

    $.ajax({
        url: api_url,
        type: 'GET', // Use GET for fetching data
        data: {
            student_id: student_id
        },
        dataType: 'json',
        beforeSend: function () {
            showLoadingAlert('Fetching Unpaid Fees...');
        },
        success: function (response) {
            if (response.success) {
                // Show success message
                toastr.success(response.message);
                Swal.close();
                // Populate the modal body with the unpaid fees data
                let html = response.html;
                $('#manageUnpaidFeesModalBody').html(html);
                $('#manageUnpaidFeesModal').modal('show');
                $('#manageUnpaidFeesModalLabel').html('Unpaid ' + fees_type_text + ' Fees for <b>' + student_name + '</b>');
            } else {
                showErrorAlert(response.message);
            }
        },
        error: function (xhr) {
            showErrorAlert('An error occurred while fetching unpaid fees.');
            console.error(xhr.responseText);
        }
    });
}

// Function to delete unpaid fee entry
function deleteUnpaidFeeEntry(entryId, btn, feesType = 'monthly') {

    Swal.fire({
        title: 'Are you sure?',
        text: `This action cannot be undone! You are about to delete an unpaid ${feesType} fee entry.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'No, cancel!',
        customClass: {
            popup: 'rounded-4 shadow-lg'
        }
    }).then((result) => {
        if (result.isConfirmed) {
            // Proceed with deletion
            $.ajax({
                url: '../../api/admin/delete/fees-x-payments/delete-unpaid-fee-entry.php',
                type: 'POST',
                data: {
                    entry_id: entryId,
                    fees_type: feesType
                },
                dataType: 'json',
                beforeSend: function () {
                    showLoadingAlert('Deleting Fee Entry...', '<div class="spinner-border text-primary" role="status"></div>');
                },
                success: function (response) {
                    if (response.success) {
                        // Show success message
                        toastr.success(response.message);
                        Swal.close();
                        // Refresh the unpaid fees modal content
                        $(btn).closest('.alert').remove();
                        if ($('#manageUnpaidFeesModalBody').children().length === 0) {
                            $('#manageUnpaidFeesModal').modal('hide');
                            showInfoAlert('No more unpaid fees for this student.');
                        } else {
                            fetchAllUnpaidFees(response.data.student_name, response.data.student_id, feesType);
                        }
                    } else {
                        showErrorAlert(response.message);
                    }
                },
                error: function (xhr) {
                    showErrorAlert('An error occurred while deleting the fee entry.');
                    console.error(xhr.responseText);
                }
            });
        }
    });
}

// Function to show/hide additional fees due/payement date
function additionalFeesDueAndPaymentDateShowHide() {
    let status = $('#additional_fee_status').val();

    // Flatpickr (initialised globally in header-open.php) turns the real date input
    // into a hidden field and shows its own text input beside it. Browsers skip
    // constraint validation on hidden inputs, so `required` has to be mirrored onto
    // the visible altInput to have any effect - and the field that no longer applies
    // must be cleared, otherwise a stale date is posted with the form.
    function applyDateFieldState($input, isActive) {
        const flatpickrInstance = $input[0] ? $input[0]._flatpickr : null;

        $input.parent().toggle(isActive);
        $input.prop('required', isActive);

        if (flatpickrInstance && flatpickrInstance.altInput) {
            $(flatpickrInstance.altInput).prop('required', isActive);
        }

        if (!isActive) {
            if (flatpickrInstance) {
                flatpickrInstance.clear();
            } else {
                $input.val('');
            }
        }
    }

    applyDateFieldState($('#additional_fee_paid_date'), status == 'paid');
    applyDateFieldState($('#additional_fee_due_date'), status == 'unpaid');
}

// Function to open additional fees and payments modal
function openManageAdditionalFeesAndPaymentsModal(selectedStudentIds, studentName = null, selectedClassIds) {

    if (selectedStudentIds.length === 0) {
        showWarningAlert('Please select at least one student.');
        return;
    }

    if (selectedStudentIds.length === 1) {
        singleStudentId = selectedStudentIds[0];
    }

    if (!areSelectedStudentsFromSameClass(selectedClassIds)) {
        showWarningAlert('Please select students from the same class.');
        return;
    }

    if (studentName && selectedStudentIds.length === 1) {
        $('#additionalFeesManagementModalFor').text('(' + studentName + ')');
    } else {
        $('#additionalFeesManagementModalFor').text('(' + selectedStudentIds.length + ' students)');
    }

    $('#additionalFeesManagementModalFormStudentIds').val(selectedStudentIds.join(','));

    let classId = selectedClassIds[0];

    // Fetch additional fees data before showing modal
    $.ajax({
        url: '../../api/admin/get/fees-x-payments/get-additional-fees-setup-by-class.php',
        method: 'POST',
        dataType: 'json', // make sure your PHP returns JSON
        data: {
            class_id: classId
        },
        beforeSend: function () {
            showLoadingAlert();
        },
        success: function (response) {
            console.log('Success:', response);
            Swal.close();
            if (response.success) {
                let html = '<option value="" selected disabled>-- Select Fees Type --</option>';
                response.amounts.forEach(function (fee) {
                    html += `
                        <option value="${fee.id}">${fee.fee_type} (${currencySymbol}${fee.amount})</option>
                        `;
                });
                // Populate the modal with the data
                $('#additional_fees_setup_id').html(html);
                // Show the modal
                $('#additionalFeesManagementModal').modal('show');
            } else {
                showErrorAlert(response.message);
            }
        },
        error: function (xhr) {
            console.error(xhr.responseText);
            showErrorAlert('Error fetching additional fees data');
        }
    });
}

// --------------------------Function to open the admission fees and payments entry page-----------------------------
function openFeesEntryPage(selectedStudentIds, feesType = 'monthly') {
    if (selectedStudentIds.length === 0) {
        showWarningAlert('Please select at least one student.');
        return;
    }

    let url = `../fees-x-payments/monthly/monthly-fees-request.php?student_ids=${selectedStudentIds.join(',')}`;

    if (feesType == 'admission') {
        url = `../fees-x-payments/admission/admission-fees-entry.php?student_ids=${selectedStudentIds.join(',')}`;
    }

    window.open(url, '_blank');
}

function openPaymentsEntryPage(selectedStudentIds, feesType = 'monthly') {
    if (selectedStudentIds.length === 0) {
        showWarningAlert('Please select at least one student.');
        return;
    }

    let url = `../fees-x-payments/monthly/monthly-payments-entry.php?student_ids=${selectedStudentIds.join(',')}`;

    if (feesType == 'admission') {
        url = `../fees-x-payments/admission/admission-payments-entry.php?student_ids=${selectedStudentIds.join(',')}`;
    }

    window.open(url, '_blank');
}
// --------------------------End of Function to open the admission fees and payments entry page--------------------------

function toggleOverrideOptions(type, show) {
    const container = type === 'admit' ? '#admitCardOverrideContainer' : '#marksheetOverrideContainer';
    if (show) {
        $(container).show();
    } else {
        $(container).hide();
        $(container).find('input[type="checkbox"]').prop('checked', false);
    }
}

