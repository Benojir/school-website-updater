// Function to manage bulk permissions
function openManageDownloadsPermissionModal(studentIds, studentName = null) {

    if (studentIds.length === 0) {
        toastr.warning('Please select at least one student.');
        showWarningAlert('Please select at least one student.');
        return;
    }

    if (studentName && studentIds.length === 1) {
        $('#permStudentName').html('<b>' + studentName + '</b>');
        $('#bulkPermissionAlert').hide();
        fetchStudentDownloadPermissions(studentIds[0]);
    } else {
        // Update the modal title and show the bulk info alert
        $('#permStudentName').text("total (" + studentIds.length + ") students");
        $('#bulkPermissionAlert').show();
        $('#selectedStudentsCount').text(studentIds.length);
        $('#currentFeeStatus').html('<em>Fee status varies across selected students</em>');
    }

    // Set the student IDs in the form
    $('#permStudentIds').val(studentIds.join(','));

    // Reset all permission checkboxes to default state
    $('#overrideAdmitCheck, #allowAdmitCard, #overrideMarksheetCheck, #allowMarksheet').prop('checked', false);
    $('#permissionNotes').val('');

    // Hide the override containers initially
    $('#admitCardOverrideContainer, #marksheetOverrideContainer').hide();

    // Set up event listeners for the checkboxes
    $('#overrideAdmitCheck').off('change').on('change', function () {
        toggleOverrideOptions('admit', $(this).is(':checked'));
    });

    $('#overrideMarksheetCheck').off('change').on('change', function () {
        toggleOverrideOptions('marksheet', $(this).is(':checked'));
    });

    // Show the modal
    $('#permissionModal').modal('show');

    // Add special handling for bulk operations
    $('#downloadPermissionsForm').off('submit').on('submit', function (e) {
        e.preventDefault();
        saveStudentsDownloadPermissions();
    });
}

// Function to fetch student download permissions for single student
function fetchStudentDownloadPermissions(studentId) {
    $.ajax({
        url: '../../api/admin/get/student/get-student-download-permissions.php',
        type: 'GET',
        data: {
            student_id: studentId
        },
        dataType: 'json',
        success: function (response) {
            if (response.success) {
                // Update fee status display
                let feeStatusText = response.fee_paid ?
                    '<span class="text-success">All fees cleared</span>' :
                    '<span class="text-danger">Pending fees: ₹' + response.unpaid_amount + '</span>';
                $('#currentFeeStatus').html(feeStatusText);

                // Set override checkboxes
                $('#overrideAdmitCheck').prop('checked', response.data.override_admit_check || false);
                $('#overrideMarksheetCheck').prop('checked', response.data.override_marksheet_check || false);

                // Show/hide override options based on checkboxes
                toggleOverrideOptions('admit', response.data.override_admit_check || false);
                toggleOverrideOptions('marksheet', response.data.override_marksheet_check || false);

                // Set permission toggles
                $('#allowAdmitCard').prop('checked', response.data.allow_admit_card || false);
                $('#allowMarksheet').prop('checked', response.data.allow_marksheet || false);
                $('#permissionNotes').val(response.data.notes || '');
            } else {
                showErrorAlert(response.message);
            }
        },
        error: function (xhr) {
            showErrorAlert('Error loading permissions: ' + xhr.statusText);
        }
    });
}

// Function to save student download permissions
function saveStudentsDownloadPermissions() {
    const $form = $('#downloadPermissionsForm');
    const $btn = $form.find('[type="submit"]');
    const btnText = $btn.html();

    // Show loading state
    $btn.prop('disabled', true).html(
        '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...'
    );

    // Get form data
    const formData = $form.serialize();

    $.ajax({
        url: '../../api/admin/put/student/update-student-download-permissions.php',
        type: 'POST',
        data: formData,
        dataType: 'json',
        success: function (response) {
            if (response.success) {
                // Show summary success message
                toastr.success(response.message);

                // Show detailed results in a modal if available
                if (response.results && response.results.length > 0) {
                    let successCount = 0;
                    let skippedCount = 0;
                    let html = '<div class="bulk-results-container">';

                    response.results.forEach(result => {
                        if (result.success) {
                            successCount++;
                            html += `
                                    <div class="alert alert-success mb-2">
                                        <strong>${result.student_id}</strong>: ${result.message}
                                    </div>
                                `;
                        } else {
                            skippedCount++;
                            html += `
                                    <div class="alert alert-warning mb-2">
                                        <strong>${result.student_id}</strong>: ${result.message}
                                    </div>
                                `;
                        }
                    });

                    html += '</div>';

                    let finalHtml = `
                                <div class="text-left">
                                    <p><strong>Summary:</strong> ${response.message}</p>
                                    <p>Successfully processed: ${successCount}</p>
                                    <p>Skipped: ${skippedCount}</p>
                                    <div class="mt-3" style="max-height: 300px; overflow-y: auto;">
                                        ${html}
                                    </div>
                                </div>
                            `;

                    // Show detailed results in a modal
                    // Swal.fire({
                    //     title: 'Bulk Permissions Results',
                    //     html: `
                    //             <div class="text-left">
                    //                 <p><strong>Summary:</strong> ${response.message}</p>
                    //                 <p>Successfully processed: ${successCount}</p>
                    //                 <p>Skipped: ${skippedCount}</p>
                    //                 <div class="mt-3" style="max-height: 300px; overflow-y: auto;">
                    //                     ${html}
                    //                 </div>
                    //             </div>
                    //         `,
                    //     icon: 'info',
                    //     confirmButtonText: 'OK',
                    //     width: '800px'
                    // });

                    showInfoAlert(finalHtml, 'Detailed Results');
                }

                // Close the modal
                $('#permissionModal').modal('hide');
                $('.modal-backdrop').hide();
            } else {
                showErrorAlert(response.message);
            }
        },
        error: function (xhr) {
            try {
                const errorResponse = JSON.parse(xhr.responseText);
                let errorMsg = 'Error: ' + (errorResponse.message || 'Operation failed');

                if (errorResponse.processed_up_to) {
                    errorMsg += ` (Last processed student ID: ${errorResponse.processed_up_to})`;
                }

                showErrorAlert(errorMsg);
            } catch (e) {
                console.error(e);
                showErrorAlert('Error: ' + xhr.status + " " + xhr.statusText);
            }
        },
        complete: function () {
            $btn.prop('disabled', false).html(btnText);
        }
    });
}