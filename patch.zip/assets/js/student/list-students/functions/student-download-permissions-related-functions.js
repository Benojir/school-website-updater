// Temporary document exemptions use the school's clock, including when the admin is in another timezone.
let downloadPermissionRequest = null;
let downloadPermissionGeneration = 0;
let downloadPermissionClock = null;
const downloadPermissionLoadedAt = Date.now();

function downloadPermissionSchoolNow() {
    const form = document.getElementById('downloadPermissionsForm');
    if (!downloadPermissionClock) {
        downloadPermissionClock = {wall: Date.parse(form.dataset.schoolNow + 'Z'), client: downloadPermissionLoadedAt};
    }
    return new Date(downloadPermissionClock.wall + Date.now() - downloadPermissionClock.client);
}

function setDownloadOverrideDays(type) {
    const days = Number(document.querySelector('[data-override-days="' + type + '"]').value);
    if (!Number.isInteger(days) || days < 1 || days > 365) return;
    const expiry = downloadPermissionSchoolNow();
    expiry.setUTCDate(expiry.getUTCDate() + days);
    document.querySelector('[name="' + type + '_expires_at"]').value = expiry.toISOString().slice(0, 19);
}

function refreshDownloadOverride(type) {
    const enabled = $(type === 'admit' ? '#overrideAdmitCheck' : '#overrideMarksheetCheck').is(':checked');
    toggleOverrideOptions(type, enabled);
    const input = document.querySelector('[name="' + type + '_expires_at"]');
    input.disabled = !enabled;
    input.required = enabled;
    if (enabled && !input.value) setDownloadOverrideDays(type);
}

function openManageDownloadsPermissionModal(studentIds, studentName = null) {
    if (!studentIds.length) { showWarningAlert('Please select at least one student.'); return; }
    if (downloadPermissionRequest) downloadPermissionRequest.abort();
    const generation = ++downloadPermissionGeneration;
    const form = document.getElementById('downloadPermissionsForm');
    form.reset();
    $('#permStudentIds').val(studentIds.join(','));
    $('#permStudentName').text(studentIds.length === 1 && studentName ? studentName : 'total (' + studentIds.length + ') students');
    $('#bulkPermissionAlert').toggle(studentIds.length > 1);
    $('#selectedStudentsCount').text(studentIds.length);
    $('#currentFeeStatus').text(studentIds.length === 1 ? 'Loading...' : 'Fee status varies across selected students');
    ['admit', 'marksheet'].forEach(refreshDownloadOverride);
    $('#overrideAdmitCheck, #overrideMarksheetCheck').off('change.downloadAccess').on('change.downloadAccess', function () {
        refreshDownloadOverride(this.id === 'overrideAdmitCheck' ? 'admit' : 'marksheet');
    });
    $('[data-override-days]').off('input.downloadAccess').on('input.downloadAccess', function () {
        setDownloadOverrideDays(this.dataset.overrideDays);
    });
    $('#downloadPermissionsForm').off('submit').on('submit', function (event) {
        event.preventDefault(); saveStudentsDownloadPermissions();
    });
    $('#downloadPermissionsForm [type=submit]').prop('disabled', studentIds.length === 1);
    $('#permissionModal').modal('show');
    if (studentIds.length === 1) fetchStudentDownloadPermissions(studentIds[0], generation);
}

function fetchStudentDownloadPermissions(studentId, generation = downloadPermissionGeneration) {
    downloadPermissionRequest = $.ajax({
        url: '../../api/admin/get/student/get-student-download-permissions.php',
        type: 'GET', data: {student_id: studentId}, dataType: 'json',
        success: function (response) {
            if (generation !== downloadPermissionGeneration) return;
            if (!response.success) { showErrorAlert(response.message); return; }
            if (response.server_time) downloadPermissionClock = {wall: Date.parse(response.server_time.replace(' ', 'T') + 'Z'), client: Date.now()};
            $('#currentFeeStatus').text(response.fee_paid ? 'All monthly, admission and additional fees cleared'
                : 'Pending fees: ₹' + response.unpaid_amount);
            $('#overrideAdmitCheck').prop('checked', Number(response.data.override_admit_check) === 1);
            $('#overrideMarksheetCheck').prop('checked', Number(response.data.override_marksheet_check) === 1);
            $('#allowAdmitCard').prop('checked', Number(response.data.allow_admit_card) === 1);
            $('#allowMarksheet').prop('checked', Number(response.data.allow_marksheet) === 1);
            ['admit', 'marksheet'].forEach(type => {
                document.querySelector('[name="' + type + '_expires_at"]').value =
                    (response.data[type + '_expires_at'] || '').replace(' ', 'T');
                refreshDownloadOverride(type);
            });
            $('#permissionNotes').val(response.data.notes || '');
            $('#downloadPermissionsForm [type=submit]').prop('disabled', false);
        },
        error: function (xhr, status) {
            if (generation !== downloadPermissionGeneration || status === 'abort') return;
            showErrorAlert(xhr.responseJSON?.message || 'Unable to load download permissions. Close and reopen this form to retry.');
        },
        complete: function () { if (generation === downloadPermissionGeneration) downloadPermissionRequest = null; }
    });
}

function saveStudentsDownloadPermissions() {
    const form = document.getElementById('downloadPermissionsForm');
    if (!form.reportValidity()) return;
    const button = $('#downloadPermissionsForm [type=submit]');
    if (button.prop('disabled')) return;
    const label = button.html();
    button.prop('disabled', true).text('Saving...');
    $.ajax({
        url: '../../api/admin/put/student/update-student-download-permissions.php',
        type: 'POST', data: $(form).serialize(), dataType: 'json',
        success: function (response) {
            if (!response.success) { showErrorAlert(response.message); return; }
            toastr.success(response.message);
            $('#permissionModal').modal('hide');
        },
        error: function (xhr) { showErrorAlert(xhr.responseJSON?.message || 'Download permissions could not be saved. Please try again.'); },
        complete: function () { button.prop('disabled', false).html(label); }
    });
}
