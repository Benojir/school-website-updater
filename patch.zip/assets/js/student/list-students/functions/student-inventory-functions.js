/**
 * Student Inventory Functions for list-students.php
 * Enables selling and gifting inventory products directly from the student management table.
 */
(() => {
    'use strict';

    const getCfg = () => window.studentInventoryConfig || {
        api: '../../api/admin/inventory.php',
        receipt: '../inventory/receipt.php',
        csrf: '',
        currency: '₹'
    };

    const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));

    const money = paise => {
        const curr = getCfg().currency || '₹';
        return curr + (Number(paise) / 100).toLocaleString('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    };

    const num = value => Number(value).toLocaleString('en-IN');

    const generateKey = () => '10000000-1000-4000-8000-100000000000'.replace(/[018]/g, c =>
        (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
    );

    const formatDate = d => {
        if (!d) return '';
        try {
            const parts = d.split(' ')[0].split('-');
            return `${parts[2]}/${parts[1]}/${parts[0]}`;
        } catch {
            return d;
        }
    };

    const state = {
        selectedStudent: null,
        kind: 'sale',
        cart: [],
        paidTouched: false,
        saving: false,
        searchSequence: 0,
        searchRows: { students: [], products: [] },
        pending: null
    };

    let modalInstance = null;
    let searchTimer = null;

    function getModal() {
        const el = document.getElementById('studentInventorySaleModal');
        if (!el) return null;
        if (!modalInstance) {
            modalInstance = new bootstrap.Modal(el);
        }
        return modalInstance;
    }

    async function api(action, params = {}, post = false) {
        const cfg = getCfg();
        const url = cfg.api + (post ? '' : '?' + new URLSearchParams({ action, ...params }));
        const options = post ? {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action, csrf: cfg.csrf, ...params })
        } : { cache: 'no-store' };

        const response = await fetch(url, options);
        let result;
        try {
            result = await response.json();
        } catch (_) {
            throw new Error('Could not read the response. Check your network connection.');
        }
        if (!response.ok || !result.success) {
            throw new Error(result.message || 'Unable to complete the request.');
        }
        return result.data;
    }

    function renderStudentSummary(student) {
        const parents = [
            student.father_name ? `Father: ${student.father_name}` : '',
            student.mother_name ? `Mother: ${student.mother_name}` : ''
        ].filter(Boolean).join(' · ');

        const photoHtml = student.student_image && student.student_image !== 'default_student_dp.jpg'
            ? `<img src="../../uploads/students/${esc(encodeURIComponent(student.student_image))}" alt="Photo" loading="lazy" onerror="this.remove()">`
            : '<i class="fas fa-user text-muted" aria-hidden="true"></i>';

        const classInfo = [student.class_name, student.section_name].filter(Boolean).join(' - ');
        const rollInfo = student.roll_no ? ` · Roll: ${student.roll_no}` : '';

        return `
            <div class="inventory-student-photo me-2">
                ${photoHtml}
            </div>
            <div class="inventory-student-info">
                <div class="fw-bold">${esc(student.name)}</div>
                <small class="text-muted">${esc(student.student_id)}${classInfo ? ' · ' + esc(classInfo) : ''}${esc(rollInfo)}</small>
                ${parents ? `<small class="text-muted d-block">${esc(parents)}</small>` : ''}
            </div>
        `;
    }

    function setStudent(student) {
        state.selectedStudent = student;
        const box = document.getElementById('studentInventorySelectedBox');
        const details = document.getElementById('studentInventorySelectedDetails');
        const searchWrap = document.getElementById('studentInventorySearchWrap');
        const changeBtn = document.getElementById('btnChangeStudentInventory');

        if (student) {
            details.innerHTML = renderStudentSummary(student);
            box.classList.remove('d-none');
            box.classList.add('d-flex');
            searchWrap.classList.add('d-none');
            changeBtn.classList.remove('d-none');
            document.getElementById('invStudentSearchInput').value = '';
            document.getElementById('invStudentSearchResults').innerHTML = '';
        } else {
            box.classList.add('d-none');
            box.classList.remove('d-flex');
            searchWrap.classList.remove('d-none');
            changeBtn.classList.add('d-none');
            details.innerHTML = '';
        }
    }

    function addToCart(product) {
        const existing = state.cart.find(item => String(item.product.id) === String(product.id));
        if (existing) {
            existing.quantity = Number(existing.quantity) + 1;
        } else {
            state.cart.push({
                product,
                quantity: 1,
                price: (Number(product.selling_price_paise) / 100).toFixed(2)
            });
        }
        document.getElementById('invProductSearchInput').value = '';
        document.getElementById('invProductSearchResults').innerHTML = '';
        renderCart();
    }

    function cartTotalPaise() {
        if (state.kind === 'gift') return 0;
        return state.cart.reduce((sum, item) => {
            const pricePaise = Math.round(Number(item.price || 0) * 100);
            return sum + (pricePaise * Number(item.quantity || 0));
        }, 0);
    }

    function renderCart() {
        const tbody = document.getElementById('invCartTableBody');
        const isGift = state.kind === 'gift';

        if (!state.cart.length) {
            tbody.innerHTML = `<tr><td colspan="5" class="text-muted text-center py-3">No products added yet. Search above to add items.</td></tr>`;
        } else {
            tbody.innerHTML = state.cart.map((item, index) => {
                const stockQty = Number(item.product.stock_quantity || 0);
                const lineTotalPaise = isGift ? 0 : Math.round(Number(item.price || 0) * 100) * Number(item.quantity || 0);

                return `
                    <tr>
                        <td>
                            <div class="fw-bold">${esc(item.product.name)}</div>
                            <small class="text-muted">${num(stockQty)} ${esc(item.product.unit)} in stock ${item.product.sku ? '· ' + esc(item.product.sku) : ''}</small>
                        </td>
                        <td>
                            <input class="form-control form-control-sm" type="number" min="1" max="100000" step="1" required
                                data-cart-action="qty" data-index="${index}" value="${esc(item.quantity)}">
                        </td>
                        <td>
                            ${isGift ? '<span class="badge bg-secondary">Free</span>' : `
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text">${esc(getCfg().currency || '₹')}</span>
                                    <input class="form-control form-control-sm" type="number" min="0" max="99999999.99" step="0.01" required
                                        data-cart-action="price" data-index="${index}" value="${esc(item.price)}">
                                </div>
                            `}
                        </td>
                        <td class="text-end fw-bold">
                            ${money(lineTotalPaise)}
                        </td>
                        <td class="text-end">
                            <button type="button" class="btn btn-sm btn-outline-danger p-1" title="Remove" data-cart-action="remove" data-index="${index}">
                                <i class="fas fa-times"></i>
                            </button>
                        </td>
                    </tr>
                `;
            }).join('');
        }
        updateTotals();
    }

    function updateTotals() {
        const totalPaise = cartTotalPaise();
        const totalDisplay = document.getElementById('invCartTotalDisplay');
        const paymentSection = document.getElementById('invPaymentSection');
        const paidInput = document.getElementById('invPaymentPaid');
        const balancePreview = document.getElementById('invBalancePreview');

        totalDisplay.textContent = money(totalPaise);

        if (state.kind === 'gift') {
            paymentSection.classList.add('d-none');
            paidInput.required = false;
        } else {
            paymentSection.classList.remove('d-none');
            paidInput.required = true;
            if (!state.paidTouched) {
                paidInput.value = (totalPaise / 100).toFixed(2);
            }
            const paidPaise = Math.round(Number(paidInput.value || 0) * 100);
            const duePaise = Math.max(0, totalPaise - paidPaise);
            balancePreview.textContent = `Balance due after this payment: ${money(duePaise)}`;
            if (duePaise > 0) {
                balancePreview.className = 'small fw-bold text-danger mt-2';
            } else {
                balancePreview.className = 'small fw-bold text-success mt-2';
            }
        }
    }

    async function search(type, term) {
        const target = document.getElementById(type === 'students' ? 'invStudentSearchResults' : 'invProductSearchResults');
        if (!target) return;

        const sequence = ++state.searchSequence;
        if (term.length < (type === 'students' ? 2 : 1)) {
            target.innerHTML = '';
            return;
        }

        target.innerHTML = '<div class="p-2 text-muted small">Searching…</div>';
        try {
            const data = await api(type, { search: term, status: 'active' });
            if (sequence !== state.searchSequence) return;

            const rows = type === 'students' ? data : (data.rows || []);
            state.searchRows[type] = rows;

            if (!rows.length) {
                target.innerHTML = `<div class="p-2 text-muted small">No matches found.</div>`;
                return;
            }

            target.innerHTML = rows.map((row, i) => {
                if (type === 'students') {
                    return `
                        <button type="button" class="w-100 text-start border-bottom p-2 bg-white" data-pick="students" data-index="${i}">
                            ${renderStudentSummary(row)}
                        </button>
                    `;
                } else {
                    return `
                        <button type="button" class="w-100 d-flex justify-content-between align-items-center border-bottom p-2 bg-white" data-pick="products" data-index="${i}">
                            <div>
                                <b class="d-block">${esc(row.name)}</b>
                                <small class="text-muted">${esc(row.sku || row.category || '')} · ${num(row.stock_quantity)} ${esc(row.unit)} in stock</small>
                            </div>
                            <span class="badge bg-light text-dark border">${money(row.selling_price_paise)}</span>
                        </button>
                    `;
                }
            }).join('');
        } catch (err) {
            if (sequence === state.searchSequence) {
                target.innerHTML = `<div class="p-2 text-danger small">${esc(err.message)}</div>`;
            }
        }
    }

    async function submitForm(form) {
        if (state.saving || !form.reportValidity()) return;

        const errorBox = document.getElementById('studentInventoryError');
        errorBox.classList.add('d-none');
        errorBox.textContent = '';

        if (!state.selectedStudent || !state.selectedStudent.student_id) {
            errorBox.textContent = 'Please choose a student first.';
            errorBox.classList.remove('d-none');
            return;
        }

        if (!state.cart.length) {
            errorBox.textContent = 'Please add at least one product to the cart.';
            errorBox.classList.remove('d-none');
            return;
        }

        const formData = new FormData(form);
        const data = Object.fromEntries(formData);

        data.student_id = state.selectedStudent.student_id;
        data.items = state.cart.map(item => ({
            product_id: item.product.id,
            quantity: Number(item.quantity),
            price: state.kind === 'gift' ? '0.00' : String(item.price)
        }));

        if (state.kind === 'gift') {
            data.paid = '0.00';
        }

        const action = state.kind;
        const fingerprint = JSON.stringify({ action, data });
        if (!state.pending || state.pending.fingerprint !== fingerprint) {
            state.pending = { fingerprint, key: generateKey() };
        }
        data.request_key = state.pending.key;

        state.saving = true;
        const submitBtn = document.getElementById('btnInvSubmit');
        const originalText = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span> Saving...';

        try {
            const result = await api(action, data, true);
            state.saving = false;
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;

            // Close modal
            getModal().hide();

            // Show Toastr success
            if (typeof toastr !== 'undefined') {
                toastr.success(result.message || 'Inventory entry saved successfully.');
            }

            // Show SweetAlert with receipt link
            if (typeof Swal !== 'undefined') {
                const receiptUrl = `${getCfg().receipt}?id=${result.id}`;
                Swal.fire({
                    icon: 'success',
                    title: 'Entry Saved!',
                    text: result.message || 'Inventory entry was successfully recorded.',
                    showCancelButton: true,
                    confirmButtonText: '<i class="fas fa-print me-1"></i> Print Receipt',
                    cancelButtonText: 'Done',
                    confirmButtonColor: '#176b52',
                    cancelButtonColor: '#6c757d'
                }).then(swalResult => {
                    if (swalResult.isConfirmed) {
                        window.open(receiptUrl, '_blank');
                    }
                });
            }

            // Refresh the students list table if function exists
            if (typeof loadStudents === 'function') {
                loadStudents();
            }

        } catch (err) {
            state.saving = false;
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
            errorBox.textContent = err.message;
            errorBox.classList.remove('d-none');
        }
    }

    /**
     * Public function to open the modal from list-students.php
     * @param {string|null} studentId 
     * @param {string|null} studentName 
     * @param {string} initialKind 'sale' or 'gift'
     */
    window.openStudentInventorySaleModal = function (studentId = null, studentName = null, initialKind = 'sale') {
        const modal = getModal();
        if (!modal) {
            alert('Inventory modal component is not initialized.');
            return;
        }

        // Close global student action modal if it's currently open
        const actionModal = bootstrap.Modal.getInstance(document.getElementById('globalStudentActionModal'));
        if (actionModal) {
            actionModal.hide();
        }

        // Reset state
        state.cart = [];
        state.paidTouched = false;
        state.saving = false;
        state.kind = initialKind === 'gift' ? 'gift' : 'sale';
        state.pending = null;

        // Reset UI elements
        const form = document.getElementById('studentInventorySaleForm');
        if (form) form.reset();

        document.getElementById('studentInventoryError').classList.add('d-none');
        document.getElementById('invProductSearchResults').innerHTML = '';
        document.getElementById('invStudentSearchResults').innerHTML = '';
        document.getElementById('invTransactionKind').value = state.kind;

        // Update modal title
        const titleEl = document.getElementById('studentInventoryModalTitle');
        if (state.kind === 'gift') {
            titleEl.innerHTML = '<i class="fas fa-gift me-2 text-warning"></i>School Store: Free Distribution (Gift)';
        } else {
            titleEl.innerHTML = '<i class="fas fa-bag-shopping me-2 text-success"></i>School Store: Sell Items';
        }

        // Handle student preselection
        if (studentId) {
            setStudent({
                student_id: studentId,
                name: studentName || studentId,
                class_name: '',
                section_name: '',
                roll_no: ''
            });

            // Fetch enriched student info in background
            api('students', { search: studentId }).then(students => {
                const found = (students || []).find(s => String(s.student_id).toLowerCase() === String(studentId).toLowerCase());
                if (found) {
                    setStudent(found);
                }
            }).catch(() => {});
        } else {
            setStudent(null);
        }

        renderCart();
        modal.show();

        // Focus search box after open
        setTimeout(() => {
            if (!studentId) {
                document.getElementById('invStudentSearchInput')?.focus();
            } else {
                document.getElementById('invProductSearchInput')?.focus();
            }
        }, 300);
    };

    /* ==========================================================================
       Student Inventory Dues Collection Functions
       ========================================================================== */

    const collectState = {
        studentId: null,
        studentName: '',
        bills: [],
        selectedBill: null,
        saving: false
    };

    let collectModalInstance = null;

    function getCollectModal() {
        const el = document.getElementById('studentInventoryCollectModal');
        if (!el) return null;
        if (!collectModalInstance) {
            collectModalInstance = new bootstrap.Modal(el);
        }
        return collectModalInstance;
    }

    function renderCollectBills() {
        const tbody = document.getElementById('invCollectBillsTableBody');
        if (!tbody) return;
        tbody.innerHTML = collectState.bills.map((b, idx) => `
            <tr style="cursor: pointer;" data-bill-id="${b.id}" class="${collectState.selectedBill?.id === b.id ? 'table-primary' : ''}">
                <td class="text-center">
                    <input type="radio" name="invCollectSelectedBill" value="${b.id}" class="form-check-input" ${collectState.selectedBill?.id === b.id || (!collectState.selectedBill && idx === 0) ? 'checked' : ''}>
                </td>
                <td class="fw-bold text-primary">INV-${b.id}</td>
                <td class="text-muted small">${formatDate(b.created_at)}</td>
                <td>${money(b.total_paise)}</td>
                <td class="text-success">${money(b.paid_paise)}</td>
                <td class="text-danger fw-bold">${money(b.due_paise)}</td>
            </tr>
        `).join('');
    }

    async function selectCollectBill(billId) {
        const bill = collectState.bills.find(b => Number(b.id) === Number(billId));
        if (!bill) return;
        collectState.selectedBill = bill;

        renderCollectBills();

        const docIdInput = document.getElementById('invCollectDocumentId');
        const amountInput = document.getElementById('invCollectAmount');
        const dueNotice = document.getElementById('invCollectDueNotice');
        const itemsWrap = document.getElementById('invCollectBillItemsWrap');
        const itemsList = document.getElementById('invCollectBillItemsList');
        const itemsSummary = document.getElementById('invCollectBillItemsSummary');

        if (docIdInput) docIdInput.value = bill.id;
        const maxAmount = (Number(bill.due_paise) / 100).toFixed(2);
        if (amountInput) {
            amountInput.max = maxAmount;
            amountInput.value = maxAmount;
        }
        if (dueNotice) {
            dueNotice.textContent = `Balance due on INV-${bill.id}: ${money(bill.due_paise)}`;
        }

        // Fetch detail of items
        if (itemsWrap && itemsList) {
            itemsWrap.classList.remove('d-none');
            itemsList.innerHTML = '<span class="text-muted"><i class="fas fa-spinner fa-spin me-1"></i>Loading items...</span>';
            if (itemsSummary) itemsSummary.textContent = `Bill INV-${bill.id}`;
            try {
                const detail = await api('detail', { id: bill.id });
                if (detail && Array.isArray(detail.items) && detail.items.length > 0) {
                    itemsList.innerHTML = `
                        <div class="table-responsive">
                            <table class="table table-sm table-borderless mb-0">
                                <tbody>
                                    ${detail.items.map(item => `
                                        <tr>
                                            <td><i class="fas fa-box text-muted me-1"></i><strong>${esc(item.product_name)}</strong></td>
                                            <td>Qty: <strong>${item.quantity} ${esc(item.unit || '')}</strong></td>
                                            <td class="text-end">@ ${money(item.unit_price_paise)}</td>
                                            <td class="text-end fw-bold">${money(item.line_total_paise)}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    `;
                } else {
                    itemsList.innerHTML = '<span class="text-muted">No item details found for this bill.</span>';
                }
            } catch {
                itemsList.innerHTML = '<span class="text-muted">Item details unavailable.</span>';
            }
        }
    }

    async function submitCollectForm(form) {
        if (collectState.saving || !form.reportValidity()) return;
        const errorEl = document.getElementById('invCollectError');
        const submitBtn = document.getElementById('btnSubmitInvCollect');
        if (errorEl) errorEl.classList.add('d-none');

        const bill = collectState.selectedBill;
        if (!bill) {
            if (errorEl) {
                errorEl.textContent = 'Please select a bill to collect payment for.';
                errorEl.classList.remove('d-none');
            }
            return;
        }

        const amountInput = document.getElementById('invCollectAmount');
        const amountVal = Number(amountInput?.value || 0);
        const maxDue = Number(bill.due_paise) / 100;

        if (isNaN(amountVal) || amountVal <= 0) {
            amountInput?.focus();
            if (errorEl) {
                errorEl.textContent = 'Please enter a valid payment amount greater than zero.';
                errorEl.classList.remove('d-none');
            }
            return;
        }

        if (amountVal > maxDue) {
            amountInput?.focus();
            if (errorEl) {
                errorEl.textContent = `Amount cannot exceed the balance due (${money(bill.due_paise)}).`;
                errorEl.classList.remove('d-none');
            }
            return;
        }

        const method = document.getElementById('invCollectMethod')?.value || 'cash';
        const reference = document.getElementById('invCollectReference')?.value?.trim() || '';

        collectState.saving = true;
        const originalBtnText = submitBtn ? submitBtn.innerHTML : '';
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Saving...';
        }

        try {
            const payload = {
                csrf: getCfg().csrf,
                request_key: generateKey(),
                action: 'collect',
                document_id: bill.id,
                amount: amountVal.toFixed(2),
                method,
                reference
            };

            const result = await api('collect', payload, true);
            getCollectModal()?.hide();

            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: 'Payment Received!',
                    html: `<p>Payment of <b>${money(Math.round(amountVal * 100))}</b> for bill <b>INV-${result.id}</b> was successfully recorded.</p>`,
                    icon: 'success',
                    showCancelButton: true,
                    confirmButtonText: '<i class="fas fa-print me-1"></i> Print Receipt',
                    cancelButtonText: 'Done',
                    customClass: {
                        popup: 'rounded-4 shadow-lg',
                        confirmButton: 'btn btn-primary px-3 py-2',
                        cancelButton: 'btn btn-secondary px-3 py-2'
                    }
                }).then(res => {
                    if (res.isConfirmed) {
                        window.open(`${getCfg().receipt}?id=${result.id}`, '_blank');
                    }
                });
            }

            if (typeof toastr !== 'undefined') {
                toastr.success(result.message || 'Payment received.');
            }

            // Automatically refresh student dues in table
            if (typeof loadStudents === 'function') {
                loadStudents();
            }
        } catch (err) {
            if (errorEl) {
                errorEl.textContent = err.message || 'Failed to save payment.';
                errorEl.classList.remove('d-none');
            }
        } finally {
            collectState.saving = false;
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnText;
            }
        }
    }

    /**
     * Entry point to open the Collect Inventory Due modal for a student
     * @param {string} studentId
     * @param {string} studentName
     */
    window.openStudentInventoryCollectModal = async function (studentId, studentName) {
        if (!studentId) return;

        // Hide action modal if open
        const actionModalEl = document.getElementById('globalStudentActionModal');
        if (actionModalEl) {
            const actionModal = bootstrap.Modal.getInstance(actionModalEl);
            actionModal?.hide();
        }

        collectState.studentId = studentId;
        collectState.studentName = studentName || studentId;
        collectState.bills = [];
        collectState.selectedBill = null;

        const modal = getCollectModal();
        if (!modal) return;

        const errorEl = document.getElementById('invCollectError');
        const loadingEl = document.getElementById('invCollectLoading');
        const emptyEl = document.getElementById('invCollectEmpty');
        const contentEl = document.getElementById('invCollectContent');
        const itemsWrap = document.getElementById('invCollectBillItemsWrap');
        const nameEl = document.getElementById('invCollectStudentName');
        const metaEl = document.getElementById('invCollectStudentMeta');
        const totalDueBadge = document.getElementById('invCollectTotalDueBadge');

        if (errorEl) { errorEl.classList.add('d-none'); errorEl.textContent = ''; }
        if (loadingEl) loadingEl.classList.remove('d-none');
        if (emptyEl) emptyEl.classList.add('d-none');
        if (contentEl) contentEl.classList.add('d-none');
        if (itemsWrap) itemsWrap.classList.add('d-none');
        if (nameEl) nameEl.textContent = collectState.studentName;
        if (metaEl) metaEl.textContent = 'ID: ' + studentId;
        if (totalDueBadge) {
            totalDueBadge.className = 'badge bg-secondary fs-6';
            totalDueBadge.textContent = 'Checking...';
        }

        modal.show();

        try {
            const data = await api('documents', { search: studentId, due: 1 });
            if (loadingEl) loadingEl.classList.add('d-none');

            const bills = (data.rows || []).filter(r =>
                String(r.student_id).toLowerCase() === String(studentId).toLowerCase() &&
                r.kind === 'sale' &&
                r.status === 'posted' &&
                Number(r.due_paise) > 0
            );

            collectState.bills = bills;

            if (bills.length === 0) {
                if (emptyEl) emptyEl.classList.remove('d-none');
                if (totalDueBadge) {
                    totalDueBadge.className = 'badge bg-success fs-6';
                    totalDueBadge.textContent = money(0);
                }
                return;
            }

            const totalDuePaise = bills.reduce((acc, b) => acc + Number(b.due_paise), 0);
            if (totalDueBadge) {
                totalDueBadge.className = 'badge bg-danger fs-6';
                totalDueBadge.textContent = money(totalDuePaise);
            }

            if (contentEl) contentEl.classList.remove('d-none');

            renderCollectBills();
            selectCollectBill(bills[0].id);
        } catch (err) {
            if (loadingEl) loadingEl.classList.add('d-none');
            if (errorEl) {
                errorEl.textContent = err.message || 'Failed to load unpaid store bills.';
                errorEl.classList.remove('d-none');
            }
        }
    };

    // Event listeners
    document.addEventListener('DOMContentLoaded', () => {
        const modalEl = document.getElementById('studentInventorySaleModal');
        if (modalEl) {
            // Transaction kind switch
            const kindSelect = document.getElementById('invTransactionKind');
            if (kindSelect) {
                kindSelect.addEventListener('change', e => {
                    state.kind = e.target.value;
                    const titleEl = document.getElementById('studentInventoryModalTitle');
                    if (state.kind === 'gift') {
                        titleEl.innerHTML = '<i class="fas fa-gift me-2 text-warning"></i>School Store: Free Distribution (Gift)';
                    } else {
                        titleEl.innerHTML = '<i class="fas fa-bag-shopping me-2 text-success"></i>School Store: Sell Items';
                    }
                    renderCart();
                });
            }

            // "No payment now / Pay later" button
            const payLaterBtn = document.getElementById('btnInvPayLater');
            if (payLaterBtn) {
                payLaterBtn.addEventListener('click', () => {
                    state.paidTouched = true;
                    const paidInput = document.getElementById('invPaymentPaid');
                    if (paidInput) {
                        paidInput.value = '0.00';
                        updateTotals();
                    }
                });
            }

            // Paid amount input
            const paidInput = document.getElementById('invPaymentPaid');
            if (paidInput) {
                paidInput.addEventListener('input', () => {
                    state.paidTouched = true;
                    updateTotals();
                });
            }

            // Change student button
            const changeStudentBtn = document.getElementById('btnChangeStudentInventory');
            if (changeStudentBtn) {
                changeStudentBtn.addEventListener('click', () => {
                    setStudent(null);
                    setTimeout(() => document.getElementById('invStudentSearchInput')?.focus(), 100);
                });
            }

            // Cart table interactions (delegated)
            const cartBody = document.getElementById('invCartTableBody');
            if (cartBody) {
                cartBody.addEventListener('input', e => {
                    const target = e.target;
                    const index = Number(target.dataset.index);
                    if (isNaN(index) || !state.cart[index]) return;

                    if (target.dataset.cartAction === 'qty') {
                        state.cart[index].quantity = Math.max(1, Number(target.value) || 1);
                        updateTotals();
                    } else if (target.dataset.cartAction === 'price') {
                        state.cart[index].price = target.value;
                        updateTotals();
                    }
                });

                cartBody.addEventListener('click', e => {
                    const btn = e.target.closest('[data-cart-action="remove"]');
                    if (!btn) return;
                    const index = Number(btn.dataset.index);
                    if (!isNaN(index) && state.cart[index]) {
                        state.cart.splice(index, 1);
                        renderCart();
                    }
                });
            }

            // Search inputs
            modalEl.addEventListener('input', e => {
                const id = e.target.id;
                if (id === 'invStudentSearchInput') {
                    clearTimeout(searchTimer);
                    searchTimer = setTimeout(() => search('students', e.target.value.trim()), 250);
                } else if (id === 'invProductSearchInput') {
                    clearTimeout(searchTimer);
                    searchTimer = setTimeout(() => search('products', e.target.value.trim()), 200);
                }
            });

            // Click on search result item (delegated)
            modalEl.addEventListener('click', e => {
                const pickBtn = e.target.closest('[data-pick]');
                if (!pickBtn) return;

                const type = pickBtn.dataset.pick;
                const index = Number(pickBtn.dataset.index);
                const row = state.searchRows[type]?.[index];
                if (!row) return;

                if (type === 'students') {
                    setStudent(row);
                    document.getElementById('invProductSearchInput')?.focus();
                } else if (type === 'products') {
                    addToCart(row);
                }
            });

            // Form submit
            const form = document.getElementById('studentInventorySaleForm');
            if (form) {
                form.addEventListener('submit', e => {
                    e.preventDefault();
                    submitForm(form);
                });
            }
        }

        // Collect Modal Events
        const collectModalEl = document.getElementById('studentInventoryCollectModal');
        if (collectModalEl) {
            // Bill selection click on row
            collectModalEl.addEventListener('click', e => {
                const tr = e.target.closest('tr[data-bill-id]');
                if (tr) {
                    const billId = tr.dataset.billId;
                    if (billId && collectState.selectedBill?.id !== Number(billId)) {
                        selectCollectBill(billId);
                    }
                }
            });

            // Bill radio change
            collectModalEl.addEventListener('change', e => {
                if (e.target.name === 'invCollectSelectedBill') {
                    selectCollectBill(e.target.value);
                }
            });

            // Pay full due button
            const payFullBtn = document.getElementById('btnInvCollectPayFull');
            if (payFullBtn) {
                payFullBtn.addEventListener('click', () => {
                    if (collectState.selectedBill) {
                        const amountInput = document.getElementById('invCollectAmount');
                        if (amountInput) {
                            amountInput.value = (Number(collectState.selectedBill.due_paise) / 100).toFixed(2);
                            amountInput.focus();
                        }
                    }
                });
            }

            // Collect Form Submit
            const collectForm = document.getElementById('studentInventoryCollectForm');
            if (collectForm) {
                collectForm.addEventListener('submit', e => {
                    e.preventDefault();
                    submitCollectForm(collectForm);
                });
            }
        }
    });
})();
