function chooseExamAndDownloadAttendanceRecord(examsData) {
    const studentIds = getSelectedStudentIds().slice();
    const classIds = getSelectedClassIds();
    if (!studentIds.length) return showWarningAlert('Please select at least one student');
    if (classIds.length !== studentIds.length || new Set(classIds.map(String)).size !== 1) {
        return showWarningAlert('Please select students from the same class');
    }
    if (studentIds.length > 500) return showWarningAlert('Please select up to 500 students at a time');
    const exams = Array.isArray(examsData) ? examsData.filter(exam => /^\d+$/.test(String(exam.id))) : [];
    if (!exams.length) return showWarningAlert('No exams are available. Add an exam first or refresh the student list.');
    Swal.fire({
        title: 'Exam Attendance Record',
        html: `<div class="text-start">
            <label for="attendance-record-exam" class="form-label">Exam</label>
            <select id="attendance-record-exam" class="form-select mb-3"><option value="">Choose an exam</option>${exams.map(exam => `<option value="${Number(exam.id)}">${escapeHtml(exam.exam_name)}</option>`).join('')}</select>
            <label for="attendance-record-mode" class="form-label">Exam papers</label>
            <select id="attendance-record-mode" class="form-select mb-3"><option value="written">Written</option><option value="oral">Oral / practical</option><option value="both">Written and oral / practical</option></select>
            <p class="small text-muted mb-0">Opens an A4 landscape sheet for Ctrl+P printing. Dates come from the exam routine; missing dates stay blank for handwriting. Sections are printed separately.</p>
        </div>`,
        showCancelButton: true,
        confirmButtonText: 'Open Print Sheet',
        preConfirm: () => {
            const examId = document.getElementById('attendance-record-exam').value;
            if (!examId) { Swal.showValidationMessage('Please select an exam'); return false; }
            // POST avoids URL-length limits for bulk selections; this is a read-only print page.
            const form = document.createElement('form');
            form.method = 'POST'; form.target = '_blank'; form.rel = 'noopener';
            form.action = '../../api/download/sheets/exam-attendance-record.php';
            const fields = {class_id:classIds[0], exam_id:examId, student_ids:studentIds.join(','), mode:document.getElementById('attendance-record-mode').value};
            Object.entries(fields).forEach(([name, value]) => {
                const input = document.createElement('input');
                input.type = 'hidden'; input.name = name; input.value = value; form.appendChild(input);
            });
            document.body.appendChild(form); form.submit(); form.remove();
            return true;
        }
    });
}

function chooseExamAndDownloadMarkEntrySheet(examsData) {

    const selectedStudentIds = getSelectedStudentIds();
    const selectedClassIds = getSelectedClassIds();

    if (areSelectedStudentsFromSameClass(selectedClassIds)) {

        if (!selectedStudentIds.length) {
            showWarningAlert('Please select at least one student');
            return;
        }

        // Build <option> list for the exam dropdown, newest exam first (as given)
        const examOptions = examsData
            .map(exam => `<option value="${exam.id}">${escapeHtml(exam.exam_name)}</option>`)
            .join('');

        Swal.fire({
            title: 'Select Exam',
            html: `
                <select id="oral-exam-select" class="form-select">
                    <option value="" disabled selected>Choose an exam</option>
                    ${examOptions}
                </select>
            `,
            focusConfirm: false,
            showCancelButton: true,
            confirmButtonText: '<i class="fas fa-file-pdf me-1"></i> Generate Sheet',
            cancelButtonText: 'Cancel',
            preConfirm: () => {
                const examId = document.getElementById('oral-exam-select').value;
                if (!examId) {
                    Swal.showValidationMessage('Please select an exam');
                    return false;
                }
                return examId;
            }
        }).then(result => {
            if (result.isConfirmed) {
                const examId = result.value;
                const classId = selectedClassIds[0];

                const params = new URLSearchParams({
                    class_id: classId,
                    exam_id: examId,
                    student_ids: selectedStudentIds.join(',')
                });

                const url = `../../api/download/sheets/mark-entry-sheet.php?${params.toString()}`;
                window.open(url, '_blank');
            }
        });

    } else {
        showWarningAlert('Please select students from the same class');
    }
}
