function chooseExamAndDownloadOralMarkEntrySheet(examsData) {

    const selectedStudentIds = getSelectedStudentIds();
    const selectedClassIds = getSelectedClassIds();

    if (areSelectedStudentsFromSameClass(selectedClassIds)) {

        if (!selectedStudentIds.length) {
            showWarningAlert('Please select at least one student');
            return;
        }

        // Build <option> list for the exam dropdown, newest exam first (as given)
        const examOptions = examsData
            .map(exam => `<option value="${exam.id}">${escapeHtml(exam.exam_name)}</option>`)
            .join('');

        Swal.fire({
            title: 'Select Exam',
            html: `
                <select id="oral-exam-select" class="form-select">
                    <option value="" disabled selected>Choose an exam</option>
                    ${examOptions}
                </select>
            `,
            focusConfirm: false,
            showCancelButton: true,
            confirmButtonText: '<i class="fas fa-file-pdf me-1"></i> Generate Sheet',
            cancelButtonText: 'Cancel',
            preConfirm: () => {
                const examId = document.getElementById('oral-exam-select').value;
                if (!examId) {
                    Swal.showValidationMessage('Please select an exam');
                    return false;
                }
                return examId;
            }
        }).then(result => {
            if (result.isConfirmed) {
                const examId = result.value;
                const classId = selectedClassIds[0];

                const params = new URLSearchParams({
                    class_id: classId,
                    exam_id: examId,
                    student_ids: selectedStudentIds.join(',')
                });

                const url = `../../api/download/sheets/mark-entry-sheet.php?${params.toString()}`;
                window.open(url, '_blank');
            }
        });

    } else {
        showWarningAlert('Please select students from the same class');
    }
}