function downloadStudentsFullData() {
    const selectedIds = getSelectedStudentIds();
    if (selectedIds.length > 0) {
        // Create form and submit via POST
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '../../api/download/students-full-data.php';
        form.target = '_blank';

        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'student_ids';
        input.value = selectedIds.join(',');
        form.appendChild(input);

        document.body.appendChild(form);
        form.submit();
        document.body.removeChild(form);
    } else {
        showWarningAlert('Please select at least one student');
    }
}

// Helper function to get session year options
function getSessionYearOptions() {
    const currentYear = new Date().getFullYear() - 1;
    const options = {};

    for (let i = 0; i < 3; i++) {
        const startYear = currentYear + i;
        const endYear = startYear + 1;

        // Key is start year, Value is range (e.g., "2025-2026")
        // options[startYear] = `${startYear}-${endYear}`;
        options[startYear] = startYear;
    }

    return options;
}

// Function to download admission Forms
function downloadAdmissionForm(studentId) {

    let studentIdsWithComma = '';

    if (studentId) {
        studentIdsWithComma = studentId;
    } else {
        const selectedIds = getSelectedStudentIds();
        const selectedClassIds = getSelectedClassIds();
        studentIdsWithComma = selectedIds.join(',');

        if (!areSelectedStudentsFromSameClass(selectedClassIds)) {
            toastr.warning('Please select students from the same class');
            showWarningAlert('Please select students from the same class');
            return;
        }

        if (selectedIds.length > 30) {
            toastr.warning('Please select up to 30 students at a time to download admission forms');
            showWarningAlert('Please select up to 30 students at a time to download admission forms');
            return;
        }
    }

    if (studentIdsWithComma) {
        // Show modal to select which admission form to download
        Swal.fire({
            title: 'Select Session Year',
            text: 'Which session year do you want to download?',
            input: 'select',
            inputOptions: getSessionYearOptions(),
            inputPlaceholder: 'Select a session year',
            showCancelButton: true,
            confirmButtonText: 'Download',
            customClass: {
                popup: 'rounded-4 shadow-lg'
            },
            preConfirm: (sessionYear) => {
                // 1. Validation: Ensure a session year was selected
                if (!sessionYear) {
                    Swal.showValidationMessage('Please select a session year');
                }
                // 2. Return the selected value so it can be used in .then()
                return sessionYear;
            }
        }).then((result) => {
            // Check if the user clicked "Download" and a value was confirmed
            if (result.isConfirmed) {
                // The selected sessionYear is in result.value
                window.open('../../api/download/download-bulk-admission-forms.php?student_ids=' + studentIdsWithComma + '&session_year=' + result.value, '_blank');
            }
        });
    } else {
        toastr.warning('Please select at least one student');
        showWarningAlert('Please select at least one student');
    }
}

// Function to download combined marksheets
function downloadCombinedMarksheets() {

    const selectedIds = getSelectedStudentIds();
    const selectedClassIds = getSelectedClassIds();

    if (!areSelectedStudentsFromSameClass(selectedClassIds)) {
        toastr.warning('Please select students from the same class');
        showWarningAlert('Please select students from the same class');
        return;
    }

    const classId = selectedClassIds[0];

    if (selectedIds.length == 0) {
        toastr.warning('Please select at least one student');
        showWarningAlert('Please select at least one student');
        return;
    }

    if (selectedIds.length > 50) {
        toastr.warning('Please select up to 50 students at a time to download combined marksheets');
        showWarningAlert('Please select up to 50 students at a time to download combined marksheets');
        return;
    }

    const studentIdsWithComma = selectedIds.join(',');
    const selectedExamIdsForMarksheet = [];

    $('.exam-checkbox-for-marksheet:checked').each(function () {
        const examId = $(this).data('exam-id');
        selectedExamIdsForMarksheet.push(examId);
    });

    // if (selectedExamIdsForMarksheet.length < 2) {
    //     toastr.warning('Please select at least 2 exams for marksheet');
    //     showWarningAlert('Please select at least 2 exams for marksheet');
    //     return;
    // }

    // Sort exam ids low to high
    selectedExamIdsForMarksheet.sort((a, b) => a - b);

    window.open('../../api/download/marksheet/download-combined-marksheet.php?student_ids=' + studentIdsWithComma + '&exam_ids=' + selectedExamIdsForMarksheet.join(',') + '&class_id=' + classId, '_blank');
}

// Function to open Attendance Modal for single student or bulk selected students
function openStudentAttendanceModal(studentIds, studentName = null) {
    if (!studentIds || (Array.isArray(studentIds) && studentIds.length === 0)) {
        showWarningAlert('Please select at least one student to manage attendance');
        return;
    }

    // Hide global action modal if open
    $('#globalStudentActionModal').modal('hide');

    const idsArray = Array.isArray(studentIds) ? studentIds : [studentIds];
    $('#attendance_student_ids').val(idsArray.join(','));

    // Update modal header / target summary
    if (studentName) {
        $('#manageAttendanceModalLabel').html('<i class="fa-solid fa-calendar-check me-2"></i>Manage Attendance');
        $('#attendanceTargetSummary').show();
        $('#attendanceTargetText').html(`Managing attendance for: <strong>${escapeHtml(studentName)}</strong> (${escapeHtml(idsArray[0])})`);
    } else {
        const count = idsArray.length;
        $('#manageAttendanceModalLabel').html('<i class="fa-solid fa-calendar-check me-2"></i>Manage Attendance');
        $('#attendanceTargetSummary').show();
        $('#attendanceTargetText').html(`Managing attendance for <strong>${count}</strong> selected student(s)`);
    }

    // Reset datePicker & action
    if (typeof datePicker !== 'undefined' && datePicker) {
        datePicker.clear();
    }
    $('#attendance_action').val('');
    const now = new Date();
    $('#attendance_time').val(now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0'));

    // Show attendance modal
    $('#manageAttendanceModal').modal('show');
}