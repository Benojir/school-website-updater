// Helper function to get session year options
function getSessionYearOptions() {
    const currentYear = new Date().getFullYear();
    const options = {};

    for (let i = 0; i < 2; i++) {
        const startYear = currentYear + i;
        const endYear = startYear + 1;

        // Key is start year, Value is range (e.g., "2025-2026")
        // options[startYear] = `${startYear}-${endYear}`;
        options[startYear] = startYear;
    }

    return options;
}

// Function to download admission Forms
function downloadAdmissionForm(studentId) {

    let studentIdsWithComma = '';

    if (studentId) {
        studentIdsWithComma = studentId;
    } else {
        const selectedIds = getSelectedStudentIds();
        const selectedClassIds = getSelectedClassIds();
        studentIdsWithComma = selectedIds.join(',');

        if (!areSelectedStudentsFromSameClass(selectedClassIds)) {
            toastr.warning('Please select students from the same class');
            showWarningAlert('Please select students from the same class');
            return;
        }

        if (selectedIds.length > 30) {
            toastr.warning('Please select up to 30 students at a time to download admission forms');
            showWarningAlert('Please select up to 30 students at a time to download admission forms');
            return;
        }
    }

    if (studentIdsWithComma) {
        // Show modal to select which admission form to download
        Swal.fire({
            title: 'Select Session Year',
            text: 'Which session year do you want to download?',
            input: 'select',
            inputOptions: getSessionYearOptions(),
            inputPlaceholder: 'Select a session year',
            showCancelButton: true,
            confirmButtonText: 'Download',
            customClass: {
                popup: 'rounded-4 shadow-lg'
            },
            preConfirm: (sessionYear) => {
                // 1. Validation: Ensure a session year was selected
                if (!sessionYear) {
                    Swal.showValidationMessage('Please select a session year');
                }
                // 2. Return the selected value so it can be used in .then()
                return sessionYear;
            }
        }).then((result) => {
            // Check if the user clicked "Download" and a value was confirmed
            if (result.isConfirmed) {
                // The selected sessionYear is in result.value
                window.open('../../api/download/download-bulk-admission-forms.php?student_ids=' + studentIdsWithComma + '&session_year=' + result.value, '_blank');
            }
        });
    } else {
        toastr.warning('Please select at least one student');
        showWarningAlert('Please select at least one student');
    }
}

// Function to download combined marksheets
function downloadCombinedMarksheets() {

    const selectedIds = getSelectedStudentIds();
    const selectedClassIds = getSelectedClassIds();

    if (!areSelectedStudentsFromSameClass(selectedClassIds)) {
        toastr.warning('Please select students from the same class');
        showWarningAlert('Please select students from the same class');
        return;
    }

    if (selectedIds.length == 0) {
        toastr.warning('Please select at least one student');
        showWarningAlert('Please select at least one student');
        return;
    }

    if (selectedIds.length > 50) {
        toastr.warning('Please select up to 50 students at a time to download combined marksheets');
        showWarningAlert('Please select up to 50 students at a time to download combined marksheets');
        return;
    }

    const studentIdsWithComma = selectedIds.join(',');
    const selectedExamIdsForMarksheet = [];

    $('.exam-checkbox-for-marksheet:checked').each(function () {
        const examId = $(this).data('exam-id');
        selectedExamIdsForMarksheet.push(examId);
    });

    if (selectedExamIdsForMarksheet.length < 2) {
        toastr.warning('Please select at least 2 exams for marksheet');
        showWarningAlert('Please select at least 2 exams for marksheet');
        return;
    }

    // Sort exam ids low to high
    selectedExamIdsForMarksheet.sort((a, b) => a - b);

    window.open('../../api/download/download-combined-marksheet.php?student_ids=' + studentIdsWithComma + '&exam_ids=' + selectedExamIdsForMarksheet.join(','), '_blank');
}