function downloadStudentsFullData() {
    const selectedIds = getSelectedStudentIds();
    if (selectedIds.length > 0) {
        // Create form and submit via POST
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '../../api/download/students-full-data.php';
        form.target = '_blank';

        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'student_ids';
        input.value = selectedIds.join(',');
        form.appendChild(input);

        document.body.appendChild(form);
        appendSelectedAcademicYear(form);
        form.submit();
        document.body.removeChild(form);
    } else {
        showWarningAlert('Please select at least one student');
    }
}

// Helper function to get session year options
function getSessionYearOptions() {
    return Object.fromEntries([...document.querySelectorAll('#academicYearFilter option')]
        .filter(option => /^20\d{2}$|^21\d{2}$|^2200$/.test(option.value))
        .map(option => [option.value, option.textContent]));
}

// Used by both the student row and the bulk download menu.
function downloadAdmissionForm(studentId) {
    const studentIds = studentId ? [String(studentId)] : getSelectedStudentIds().map(String);
    if (studentIds.length === 0) {
        showWarningAlert('Please select at least one student');
        return;
    }
    if (studentIds.length > 30) {
        showWarningAlert('Please select up to 30 students at a time to download admission forms');
        return;
    }

    const years = getSessionYearOptions();
    Swal.fire({
        title: 'Download Admission Form',
        html: '<label for="admissionFormRenderer" class="form-label">Design method</label>' +
            '<select id="admissionFormRenderer" class="form-select">' +
                '<option value="builder">Admission Form Builder</option>' +
                '<option value="classic">Classic Version (one class per batch)</option>' +
            '</select>',
        input: 'select',
        inputLabel: 'Academic year',
        inputOptions: years,
        inputValue: document.getElementById('academicYearFilter')?.value || '',
        inputPlaceholder: 'Select an academic year',
        showCancelButton: true,
        confirmButtonText: 'Download',
        customClass: {
            popup: 'rounded-4 shadow-lg'
        },
        preConfirm: (sessionYear) => {
            if (!Object.hasOwn(years, sessionYear)) {
                Swal.showValidationMessage('Please select an academic year');
                return false;
            }
            const renderer = Swal.getPopup().querySelector('#admissionFormRenderer').value;
            return {sessionYear, renderer};
        }
    }).then((result) => {
        if (!result.isConfirmed) return;

        const {sessionYear, renderer} = result.value;
        const classic = renderer === 'classic';
        const endpoint = classic ? 'download-bulk-admission-forms.php' : 'generate-admission-forms.php';
        const query = new URLSearchParams(classic
            ? {student_ids: studentIds.join(','), session_year: sessionYear}
            : {student_ids: JSON.stringify(studentIds), selected_year: sessionYear});
        window.open('../../api/download/' + endpoint + '?' + query.toString(), '_blank', 'noopener');
    });
}

// Function to download combined marksheets
function downloadCombinedMarksheets() {

    const selectedIds = getSelectedStudentIds();
    const selectedClassIds = getSelectedClassIds();

    if (!areSelectedStudentsFromSameClass(selectedClassIds)) {
        toastr.warning('Please select students from the same class');
        showWarningAlert('Please select students from the same class');
        return;
    }

    const classId = selectedClassIds[0];

    if (selectedIds.length == 0) {
        toastr.warning('Please select at least one student');
        showWarningAlert('Please select at least one student');
        return;
    }

    if (selectedIds.length > 50) {
        toastr.warning('Please select up to 50 students at a time to download combined marksheets');
        showWarningAlert('Please select up to 50 students at a time to download combined marksheets');
        return;
    }

    const studentIdsWithComma = selectedIds.join(',');
    const selectedExamIdsForMarksheet = [];

    $('.exam-checkbox-for-marksheet:checked').each(function () {
        const examId = $(this).data('exam-id');
        selectedExamIdsForMarksheet.push(examId);
    });

    // if (selectedExamIdsForMarksheet.length < 2) {
    //     toastr.warning('Please select at least 2 exams for marksheet');
    //     showWarningAlert('Please select at least 2 exams for marksheet');
    //     return;
    // }

    // Sort exam ids low to high
    selectedExamIdsForMarksheet.sort((a, b) => a - b);

    window.open('../../api/download/marksheet/download-combined-marksheet.php?student_ids=' + studentIdsWithComma + '&exam_ids=' + selectedExamIdsForMarksheet.join(',') + '&class_id=' + classId, '_blank');
}

// Function to open Attendance Modal for single student or bulk selected students
function openStudentAttendanceModal(studentIds, studentName = null) {
    if (!studentIds || (Array.isArray(studentIds) && studentIds.length === 0)) {
        showWarningAlert('Please select at least one student to manage attendance');
        return;
    }

    // Hide global action modal if open
    $('#globalStudentActionModal').modal('hide');

    const idsArray = Array.isArray(studentIds) ? studentIds : [studentIds];
    $('#attendance_student_ids').val(idsArray.join(','));

    // Update modal header / target summary
    if (studentName) {
        $('#manageAttendanceModalLabel').html('<i class="fa-solid fa-calendar-check me-2"></i>Manage Attendance');
        $('#attendanceTargetSummary').show();
        $('#attendanceTargetText').html(`Managing attendance for: <strong>${escapeHtml(studentName)}</strong> (${escapeHtml(idsArray[0])})`);
    } else {
        const count = idsArray.length;
        $('#manageAttendanceModalLabel').html('<i class="fa-solid fa-calendar-check me-2"></i>Manage Attendance');
        $('#attendanceTargetSummary').show();
        $('#attendanceTargetText').html(`Managing attendance for <strong>${count}</strong> selected student(s)`);
    }

    // Reset datePicker & action
    if (typeof datePicker !== 'undefined' && datePicker) {
        datePicker.clear();
    }
    $('#attendance_action').val('');
    const now = new Date();
    $('#attendance_time').val(now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0'));

    // Show attendance modal
    $('#manageAttendanceModal').modal('show');
}
