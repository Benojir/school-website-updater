// Helper function to check if any filters are applied
function hasFilters() {
    return $('#search').val() ||
        $('#classFilter').val() ||
        $('#sectionFilter').val() ||
        $('#statusFilter').val() ||
        $('#monthlyFeeStatusFilter').val() ||
        $('#admissionFeeStatusFilter').val() ||
        $('#hostelerFilter').val() ||
        $('#coachingFilter').val() ||
        $('#tiffinFilter').val() ||
        $('#customFeeFilter').val() ||
        $('#paidMonthFilter').val() ||
        $('#unpaidMonthFilter').val() ||
        $('#carRouteFilter').val() ||
        $('#driverByFilter').val() ||
        $('#sortByFilter').val() ||
        $('#genderFilter').val() ||
        $('#academicYearFilter').val();
}

// Function to check and reset month filters if they conflict
function handleMonthFilterConflict() {
    const paidVal = $('#paidMonthFilter').val();
    const unpaidVal = $('#unpaidMonthFilter').val();

    if (paidVal !== "" && unpaidVal !== "" && paidVal === unpaidVal) {
        // UI-তে ড্রপডাউন দুটি সাইলেন্টলি ডিফল্ট (খালি) অবস্থায় নিয়ে আসা হচ্ছে
        $('#paidMonthFilter').prop('selectedIndex', 0);
        $('#unpaidMonthFilter').prop('selectedIndex', 0);
        
        // ইউজারকে সতর্ক করার জন্য অ্যালার্ট
        showWarningAlert('Paid and Unpaid month cannot be the same. Both filters have been reset.');
    }
}

// Function to change section options based on selected class
function updateSectionOptions() {
    const selectedClassId = $('#classFilter').val();
    const sectionFilter = $('#sectionFilter');

    // Clear current options
    sectionFilter.empty();
    sectionFilter.append('<option value="">All Sections</option>');

    if (selectedClassId) {
        // Fetch sections for the selected class via AJAX
        $.ajax({
            url: '../../api/admin/get/class/get-sections-by-class.php',
            type: 'GET',
            data: {
                class_id: selectedClassId
            },
            dataType: 'json',
            success: function (response) {
                if (response.length > 0) {
                    response.forEach(sec => {
                        sectionFilter.append(`<option value="${sec.id}">${sec.section_name}</option>`);
                    });
                    sectionFilter.append(`<option value="-1">No Section</option>`);
                } else {
                    showWarningAlert('No sections available for the selected class');
                    sectionFilter.html('<option value="">No sections available</option>');
                }
            },
            error: function (xhr) {
                showErrorAlert('Error: ' + xhr.statusText);
                console.error(xhr.responseText);
            }
        });
    } else {
        // If no class is selected, leave it empty
        sectionFilter.empty();
        sectionFilter.append('<option value="">All Sections</option>');
    }
}

function setEmptyOptionToFeeStatusFilter(htmlIdOfPreviousOne) {
    if (isFeeStatusSelectionResetting) return; // Prevent loop
    isFeeStatusSelectionResetting = true;
    $(`#${htmlIdOfPreviousOne}`).prop('selectedIndex', 0).trigger('change');
    isFeeStatusSelectionResetting = false;
}

// IMPROVED: Update results summary to include selection info
function updateResultsSummary(totalStudents, currentPage) {
    const perPage = 250;
    const start = (currentPage - 1) * perPage + 1;
    const end = Math.min(start + perPage - 1, totalStudents);

    $('.results-summary').html(`
                Showing ${start} to ${end} of ${totalStudents} students
                ${hasFilters() ? '<div class="text-muted"><small>Filtered results</small></div>' : ''}
            `);
}

// Function to load students
function loadStudents(page = 1) {
    preserveSelectionsBeforeReload(); // Save selections before reload
    currentPage = page;

    // Show loading indicator
    $('#studentsTableBody').html(`
                <tr>
                    <td colspan="12" class="text-center py-4">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </td>
                </tr>
            `);

    // Get filter values
    filterParams = {
        search: $('#search').val(),
        class: $('#classFilter').val(),
        section: $('#sectionFilter').val(),
        gender: $('#genderFilter').val(),
        status: $('#statusFilter').val(),
        monthly_fee_status: $('#monthlyFeeStatusFilter').val(),
        admission_fee_status: $('#admissionFeeStatusFilter').val(),
        hosteler: $('#hostelerFilter').val(),
        coaching: $('#coachingFilter').val(),
        tiffin: $('#tiffinFilter').val(),
        customFee: $('#customFeeFilter').val(),
        paid_month: $('#paidMonthFilter').val(),
        unpaid_month: $('#unpaidMonthFilter').val(),
        additional_fee_status: $('#additionalFeeStatusFilter').val(),
        paid_additional_fee: $('#paidAdditionalFeeFilter').val(),
        unpaid_additional_fee: $('#unpaidAdditionalFeeFilter').val(),
        car_route: $('#carRouteFilter').val(),
        driver_id: $('#driverByFilter').val(),
        sort_by: $('#sortByFilter').val(),
        academic_year: $('#academicYearFilter').val(),
        page: currentPage
    };

    // Make AJAX request
    $.ajax({
        url: '../../api/admin/get/student/students-list-api.php',
        type: 'GET',
        data: filterParams,
        dataType: 'json',
        success: function (response) {
            if (response.success) {
                totalPages = response.total_pages;
                totalStudents = response.total_students;

                renderStudents(response.students);
                updatePagination(response.total_pages, response.current_page);
                updateResultsSummary(response.total_students, response.current_page);
            } else {
                toastr.error('Error loading students');
                $('#studentsTableBody').html(`
                    <tr>
                        <td colspan="12" class="text-center py-4 text-danger">
                            Error loading student data
                        </td>
                    </tr>
                `);
            }
        },
        error: function (xhr) {
            toastr.error('Error: ' + xhr.statusText);
            console.error(xhr.responseText);
            $('#studentsTableBody').html(`
                <tr>
                    <td colspan="12" class="text-center py-4 text-danger">
                        Error loading student data
                    </td>
                </tr>
            `);
        },
        complete: function () {
            initTooltips();
        }
    });
}