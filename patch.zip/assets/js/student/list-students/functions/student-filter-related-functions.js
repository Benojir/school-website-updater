// Helper function to check if any filters are applied
    function hasFilters() {
        return $('#search').val() ||
            $('#classFilter').val() ||
            $('#sectionFilter').val() ||
            $('#statusFilter').val() ||
            $('#monthlyFeeStatusFilter').val() ||
            $('#admissionFeeStatusFilter').val() ||
            $('#hostelerFilter').val() ||
            $('#carRouteFilter').val();
    }

    // Function to change section options based on selected class
    function updateSectionOptions() {
        const selectedClassId = $('#classFilter').val();
        const sectionFilter = $('#sectionFilter');

        // Clear current options
        sectionFilter.empty();
        sectionFilter.append('<option value="">All Sections</option>');

        if (selectedClassId) {
            // Fetch sections for the selected class via AJAX
            $.ajax({
                url: '../../api/admin/get/class/get-sections-by-class.php',
                type: 'GET',
                data: {
                    class_id: selectedClassId
                },
                dataType: 'json',
                success: function(response) {
                    if (response.length > 0) {
                        response.forEach(sec => {
                            sectionFilter.append(`<option value="${sec.id}">${sec.section_name}</option>`);
                        });
                    } else {
                        showWarningAlert('No sections available for the selected class');
                        sectionFilter.html('<option value="">No sections available</option>');
                    }
                },
                error: function(xhr) {
                    showErrorAlert('Error: ' + xhr.statusText);
                    console.error(xhr.responseText);
                }
            });
        } else {
            // If no class is selected, leave it empty
            sectionFilter.empty();
            sectionFilter.append('<option value="">All Sections</option>');
        }
    }

    function setEmptyOptionToFeeStatusFilter(htmlIdOfPreviousOne) {
        if (isFeeStatusSelectionResetting) return; // Prevent loop
        isFeeStatusSelectionResetting = true;
        $(`#${htmlIdOfPreviousOne}`).prop('selectedIndex', 0).trigger('change');
        isFeeStatusSelectionResetting = false;
    }