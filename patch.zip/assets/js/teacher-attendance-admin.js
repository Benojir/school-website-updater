/* Attendance administration: no secrets or uploaded image bytes in browser storage. */
(() => {
    'use strict';
    const root = document.getElementById('staffAttendance');
    if (!root) return;
    const $ = id => document.getElementById(id);
    const view = root.dataset.view || 'review';
    const teacher = $('staffTeacher'), month = $('staffMonth'), settingsDate = $('staffSettingsDate');
    const monthYear = $('staffMonthYear'), monthName = $('staffMonthName');
    const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const money = p => (Number(p || 0) / 100).toFixed(2);
    const selfieModeLabel = mode => ({blink_only:'Blink only',blink_turn:'Blink + head turn',manual_selfie:'Manual live-camera selfie (no gestures)'}[mode || 'blink_turn'] || 'Unknown camera mode');
    const lateRuleLabel = rules => rules.late_mode==='monthly_count'
        ? `1 day's salary per ${Number(rules.late_days_per_deduction)} late days each month; ${money(rules.late_partial_amount_paise)} ${rules.late_partial_mode==='per_minute'?'per minute after grace':'per late day'} in an incomplete group`
        : `${money(rules.late_amount_paise)} (${rules.late_mode==='flat'?'per day':'per minute after grace'})`;
    const weekdayFields = {start_time:'Shift starts',end_time:'Shift ends',checkin_open:'Arrival opens',checkin_close:'Arrival closes',checkout_close:'Departure closes',minimum_work_min:'Minimum shift work (minutes)'};
    const weekdayInput = (key, day) => key === 'start_time' ? 'weekday_start_'+day : key === 'end_time' ? 'weekday_end_'+day : 'weekday_'+key+'_'+day;
    let context = {}, report = null, selectedDate = '', busy = 0, settingsLoadVersion = 0;
    let reviewQueue = null;
    const selectedDays = new Set();
    const reviewPhotoState = new Map();
    const galleryPageSize = 10;
    let galleryPage = 1;
    let attendancePage = 1;
    const attendancePageSize = 10;
    let disabledBefore = [];
    function message(text, error = false) {
        $('staffMessage').className = 'alert ' + (error ? 'alert-danger' : 'alert-success');
        $('staffMessage').textContent = text;
    }
    function showFeedback(box, text = '', type = 'danger', focus = false) {
        box.className=text ? `alert alert-${type} mt-3 mb-2` : 'alert d-none mt-3 mb-2';
        box.setAttribute('role',type==='danger' || type==='warning'?'alert':'status');
        box.textContent=text;
        if (text && focus) { box.focus({preventScroll:true}); box.scrollIntoView({behavior:'smooth',block:'nearest'}); }
    }
    function feedbackBox(id, parent, after = null) {
        let box=$(id);
        if (!box) {
            box=document.createElement('div'); box.id=id; box.tabIndex=-1;
            box.setAttribute('aria-atomic','true');
            if (after) after.after(box); else parent.append(box);
        }
        box.dataset.staffFormMessage='';
        return box;
    }
    function loadMessage(text = '', type = 'danger', focus = false) {
        const parent=$('staffReload')?.closest('.card-body') || $('staffRules')?.parentElement || $('staffCalendar')?.parentElement;
        if (parent) showFeedback(feedbackBox('staffLoadMessage',parent),text,type,focus);
    }
    function formMessage(id, text = '', type = 'danger', focus = false) {
        const form=$(id); if (!form) return;
        showFeedback(feedbackBox(id+'Message',form.parentElement,form),text,type,focus && !form.closest('[hidden]'));
        // A failed settings refresh can hide the editor; keep the result visible in its selector card.
        if (text && form.closest('[hidden]')) loadMessage(text,type,focus);
    }
    function clearFeedback(scope = root) {
        scope.querySelectorAll('[data-staff-form-message]').forEach(box=>showFeedback(box));
    }
    function reviewMessage(text = '', type = 'danger', focus = false) { formMessage('staffReview',text,type,focus); }
    function syncMonthSelection() {
        const year=monthYear.value, number=monthName.value;
        if (!/^\d{4}$/.test(year) || Number(year) < 2000 || Number(year) > 2100 || !/^(0[1-9]|1[0-2])$/.test(number)) {
            month.value='';
            throw new Error('Choose a valid year and month.');
        }
        month.value=year+'-'+number;
    }
    function teacherSettingsState(state, detail = '') {
        if (view !== 'teacher') return;
        const ready=state === 'ready';
        $('staffTeacherSettingsEditor').hidden=!ready;
        $('staffTeacherSettingsFields').disabled=!ready;
        $('staffSettingsHelp').classList.toggle('d-none',state !== 'error');
        $('staffPersonalSummary').className='mt-3 mb-0'+(state === 'error'?' text-danger':'');
        if (ready) {
            if ($('staffMessage').classList.contains('alert-danger')) {
                $('staffMessage').className='alert d-none'; $('staffMessage').textContent='';
            }
            return;
        }
        report=null;
        copyNote();
        ['staffEffectiveRules','staffTeacherRuleHistory','staffTerms','staffWeekdays','staffDaySchedules'].forEach(id=>$(id).replaceChildren());
        ['staffTeacherRules','staffSalary','staffDevice'].forEach(id=>$(id).reset());
        personalGroups($('staffTeacherRules'),{});
        let text=state === 'loading' ? 'Loading the selected teacher and date...' : 'Select a teacher and a date, then click Load / Reload to show the settings.';
        if (state === 'error') {
            text='Attendance settings could not be loaded for the selected teacher/date. ';
            if (detail === 'The school has not configured attendance rules for this date.') {
                const first=(context.policies || []).map(p=>p.effective_date).sort()[0];
                text+=first ? `The first school rule starts on ${first}. Choose that date or a later date, then click Load / Reload.` : 'Create school attendance rules first, then select a covered date and click Load / Reload.';
            } else text+=detail || 'Try Load / Reload again.';
        }
        $('staffPersonalSummary').textContent=text;
    }
    function responseFailure(response, body = '') {
        const status=`HTTP ${response.status}`;
        const html=/text\/html/i.test(response.headers.get('Content-Type') || '') || /^\s*</.test(body);
        const format=html ? 'an HTML page' : 'an invalid or empty response';
        let message;
        if (response.redirected) {
            message=`${status}: The attendance API redirected to another page instead of returning data. Sign in again and retry. If it continues, ask the server administrator to check the API redirects.`;
        } else if (response.headers.get('cf-mitigated') === 'challenge') {
            message=`${status}: Cloudflare returned a security challenge instead of attendance data. Ask the server administrator to check the Cloudflare security events for this request.`;
        } else if (response.status === 403) {
            message=`${status}: The server refused this attendance request and returned ${format} instead of JSON. A hosting security rule or access restriction may be blocking it. Ask the server administrator to check the security/error logs for this API URL.`;
        } else if (response.status === 401) {
            message=`${status}: Your login could not be verified. Sign in again and retry.`;
        } else if (response.status === 404) {
            message=`${status}: The attendance API was not found. Ask the server administrator to check the deployed API file and its URL.`;
        } else if (response.status === 429) {
            message=`${status}: Too many requests. Wait a little, then retry.`;
        } else if (response.status >= 500) {
            message=`${status}: The server could not process attendance and returned ${format} instead of JSON. Ask the server administrator to check the PHP and hosting error logs.`;
        } else {
            message=`${status}: The attendance API returned ${format} instead of valid attendance data. Ask the server administrator to check the API response and PHP error logs.`;
        }
        if (html && /<title>\s*404\s*-\s*Page Abducted\s*<\/title>/i.test(body)) {
            message+=' The returned page is the site\'s "404 - Page Abducted" error template; its title does not change the HTTP status above.';
        }
        // Never insert the returned HTML or tokens into an alert. The request ID is safe for log lookup.
        const ray=response.headers.get('cf-ray');
        if (ray && /^[a-z0-9-]{1,100}$/i.test(ray)) message+=` Request ID (CF-Ray): ${ray}.`;
        return message;
    }
    async function attendanceResponse(response) {
        const body=await response.text();
        let json;
        try { json=JSON.parse(body); } catch { throw new Error(responseFailure(response,body)); }
        if (!json || typeof json !== 'object' || Array.isArray(json)) throw new Error(responseFailure(response,body));
        if (!response.ok || json.success !== true) {
            // Preserve the application's specific permission, date and validation errors.
            throw new Error(typeof json.message === 'string' && json.message.trim() ? json.message : responseFailure(response));
        }
        return json.data;
    }
    async function request(query = '', payload = null) {
        if (busy++ === 0) {
            disabledBefore = [...root.querySelectorAll('button,select,input,textarea')].map(el=>[el,el.disabled]);
            disabledBefore.forEach(([el])=>el.disabled = true);
            root.setAttribute('aria-busy','true');
        }
        try {
            const response = await fetch(root.dataset.endpoint + query, {
                credentials: 'same-origin', cache: 'no-store',
                headers:{Accept:'application/json',...(payload ? {'Content-Type':'application/json','X-CSRF-Token':root.dataset.csrf} : {})},
                ...(payload ? {method:'POST',body:JSON.stringify(payload)} : {})
            });
            return await attendanceResponse(response);
        } finally {
            if (--busy === 0) {
                disabledBefore.forEach(([el,disabled])=>el.disabled = disabled);
                root.removeAttribute('aria-busy');
            }
        }
    }
    function dateTime(utc, zone) {
        if (!utc) return '—';
        try { return new Intl.DateTimeFormat('en-IN', {timeZone:zone || context.timezone,hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(utc.replace(' ','T')+'Z')); }
        catch { return utc; }
    }
    const record = date => report?.records?.find(d => d.work_date === date);
    function imageUrl(value) {
        try {
            const url=new URL(value);
            return url.protocol==='https:' && !url.username && !url.password && (url.hostname==='ibb.co' || url.hostname.endsWith('.ibb.co')) ? url.href : null;
        } catch { return null; }
    }
    function galleryIssue(day) {
        return day.review_issue || (day.override_status ? 'Admin correction / leave: review individually.' : (!day.check_in || !day.check_out ? 'Missing arrival / departure: correct first.' : ''));
    }
    function canSelectCard(card) {
        const day=record(card.dataset.reviewDate);
        return canReviewDate(day?.work_date)
            && card.querySelectorAll('img.staff-review-photo').length===2 && [...card.querySelectorAll('img.staff-review-photo')].every(img=>img.dataset.loaded==='yes');
    }
    function canReviewDate(date) {
        const day=record(date), photos=reviewPhotoState.get(date);
        return report && !report.review_locked && day?.review_status==='pending' && day.work_date<=context.today && !galleryIssue(day)
            && photos && !photos.failed && photos.loaded.has('in') && photos.loaded.has('out');
    }
    function filteredReviewDays() {
        const filter=$('staffReviewFilter').value;
        return (report?.records || []).filter(d=>filter==='all' || (d.review_status==='pending' && (filter!=='attention' || galleryIssue(d))));
    }
    function updateSelection() {
        if (!$('staffReviewGallery')) return;
        // Off-page choices retain the loaded/photo-checked state for this report only.
        for (const date of selectedDays) if (!canReviewDate(date)) selectedDays.delete(date);
        $('staffReviewGallery').querySelectorAll('[data-review-date]').forEach(card=> {
            const checkbox=card.querySelector('[data-check-day]');
            const ready=canSelectCard(card);
            checkbox.disabled=busy>0 || !ready;
            checkbox.checked=selectedDays.has(card.dataset.reviewDate);
            card.classList.toggle('is-selected',checkbox.checked);
        });
        $('staffSelectionCount').textContent=selectedDays.size+' day(s) selected across pages';
        $('staffBatchApprove').textContent='Approve '+selectedDays.size+' selected day(s)';
        $('staffBatchApprove').disabled=busy>0 || !selectedDays.size || !$('staffBatchConfirmed').checked;
        $('staffSelectVisible').disabled=busy>0 || !report || report.review_locked;
    }
    function renderQueue() {
        if (!$('staffReviewQueue')) return;
        if (!reviewQueue || reviewQueue.month!==month.value) {
            $('staffQueueSummary').textContent='Staff review progress unavailable. Load / Reload to retry.';
            $('staffReviewQueue').replaceChildren(); $('staffNextTeacher').disabled=true; return;
        }
        const items=reviewQueue.teachers, pending=items.reduce((sum,t)=>sum+Number(t.pending),0);
        $('staffQueueSummary').textContent=`${items.filter(t=>t.pending>0).length} of ${items.length} staff have pending reviews · ${pending} day(s) remaining · ${reviewQueue.month}`;
        $('staffReviewQueue').innerHTML=items.map(t=>`<div class="col-12 col-sm-6 col-lg-4"><button type="button" data-review-teacher="${Number(t.teacher_id)}" class="btn ${String(t.teacher_id)===teacher.value?'btn-primary':'btn-outline-secondary'} text-start w-100">${esc(t.teacher_name)} · ${Number(t.pending)} pending${t.needs_attention?' · '+Number(t.needs_attention)+' correction / missing':''}${t.locked?' · locked':''}<span class="d-block small">${Number(t.reviewed)} day(s) reviewed</span></button></div>`).join('');
        $('staffNextTeacher').disabled=!items.some(t=>String(t.teacher_id)!==teacher.value && t.pending>0 && !t.locked);
    }
    function renderGallery(reset = true) {
        if (!$('staffReviewGallery')) return;
        $('staffGalleryTeacher').textContent=(report.teacher_name || context.teachers.find(t=>String(t.id)===teacher.value)?.name || '')+' · '+report.month;
        $('staffBatchTeacher').textContent=$('staffGalleryTeacher').textContent;
        if (reset) {
            selectedDays.clear(); reviewPhotoState.clear(); galleryPage=1; $('staffBatchConfirmed').checked=false;
            formMessage('staffBatchReview');
        }
        $('staffReviewGallery').replaceChildren();
        const allDays=filteredReviewDays(), pages=Math.max(1,Math.ceil(allDays.length/galleryPageSize));
        galleryPage=Math.max(1,Math.min(galleryPage,pages));
        const offset=(galleryPage-1)*galleryPageSize, days=allDays.slice(offset,offset+galleryPageSize);
        root.querySelectorAll('[data-gallery-page-info]').forEach(el=>el.textContent=`Page ${galleryPage} of ${pages} · ${allDays.length} day(s)`);
        root.querySelectorAll('[data-gallery-page]').forEach(el=>el.disabled=busy>0 || !allDays.length || (Number(el.dataset.galleryPage)<0 ? galleryPage===1 : galleryPage===pages));
        $('staffGalleryStatus').textContent=report.review_locked ? 'This salary month is locked. Reopen salary before changing attendance reviews.' : (days.length ? `Showing ${offset+1}–${offset+days.length} of ${allDays.length} saved day(s). Selections stay across pages. Click a photo to enlarge it.` : 'No saved days in this view. Unsaved absences are shown in the monthly attendance table below.');
        for (const day of days) {
            const date=day.work_date, calculated=report.days.find(d=>d.date===date), issue=galleryIssue(day);
            if (!reviewPhotoState.has(date)) reviewPhotoState.set(date,{loaded:new Set(),failed:false});
            const photoState=reviewPhotoState.get(date);
            const col=document.createElement('div'); col.className='col-12 col-md-6 col-xl-4';
            const card=document.createElement('div'); card.className='card h-100 staff-review-card'; card.dataset.reviewDate=date;
            card.innerHTML=`<div class="card-body"><div class="d-flex justify-content-between gap-2"><strong>${esc(date)}</strong><span class="badge ${day.review_status==='pending'?'text-bg-warning':'text-bg-secondary'}">${esc(day.review_status)}</span></div><div class="small mt-1 mb-2">${esc(calculated?.status || 'Attendance')}${day.override_status?' · Admin: '+esc(day.override_status):''} · Late ${Number(calculated?.late_minutes || 0)} / early ${Number(calculated?.early_minutes || 0)} min</div><div class="row g-2 staff-card-pair"></div>${issue?`<p class="small text-danger mt-2 mb-1">${esc(issue)}</p>`:''}${day.correction_reason?`<p class="small mt-2">Correction: ${esc(day.correction_reason)}</p>`:''}<div class="staff-card-evidence mt-2"></div><label class="d-block mt-2"><input type="checkbox" class="form-check-input" data-check-day disabled> Checked this day's photo pair</label><button type="button" class="btn btn-sm btn-outline-primary mt-2" data-open-day="${esc(date)}">Details / correct / reject</button></div>`;
            if (photoState.failed) {
                const failure=document.createElement('p'); failure.className='staff-photo-error mt-2';
                failure.textContent='Photo / live frames failed on an earlier page visit. Reload or review this day individually.';
                card.querySelector('.card-body').append(failure);
            }
            for (const [type,field,label] of [['in','check_in','Arrival'],['out','check_out','Departure']]) {
                const event=(report.events || []).find(e=>e.work_date===date && e.punch_type===type && e.occurred_at===day[field]);
                const cell=document.createElement('div'); cell.className='col-6';
                const title=document.createElement('div'); title.className='small fw-semibold mb-1'; title.textContent=label+' · '+dateTime(day[field],calculated?.timezone); cell.append(title);
                const url=imageUrl(event?.selfie_url);
                if (url) {
                    const link=document.createElement('a'); link.href=url; link.target='_blank'; link.rel='noopener noreferrer';
                    const img=document.createElement('img'); img.className='staff-review-photo'; img.alt=label+' selfie '+date; img.loading='lazy'; img.referrerPolicy='no-referrer';
                    img.addEventListener('load',()=> { if (reviewPhotoState.get(date)!==photoState) return; img.dataset.loaded=img.naturalWidth>0?'yes':'no'; if (img.naturalWidth>0) photoState.loaded.add(type); updateSelection(); });
                    img.addEventListener('error',()=> { if (reviewPhotoState.get(date)!==photoState) return; img.dataset.loaded='no'; photoState.failed=true; const error=document.createElement('p'); error.className='staff-photo-error'; error.textContent=label+' photo failed to load. Reload or review individually.'; cell.append(error); $('staffBatchConfirmed').checked=false; updateSelection(); });
                    img.src=url; link.append(img); cell.append(link);
                } else { const missing=document.createElement('p'); missing.className='small text-muted'; missing.textContent='No matching app selfie'; cell.append(missing); }
                card.querySelector('.staff-card-pair').append(cell);
                const evidenceUrl=imageUrl(event?.evidence_url);
                if (evidenceUrl) {
                    const detail=document.createElement('details'), summary=document.createElement('summary'); summary.className='small'; summary.textContent=label+' live frames'; detail.append(summary);
                    detail.addEventListener('toggle',()=> {
                        if (!detail.open || detail.querySelector('img')) return;
                        const link=document.createElement('a'); link.href=evidenceUrl; link.target='_blank'; link.rel='noopener noreferrer';
                        const img=document.createElement('img'); img.className='staff-review-evidence'; img.alt=label+' live challenge frames '+date; img.referrerPolicy='no-referrer'; img.src=evidenceUrl;
                        img.addEventListener('error',()=> { if (reviewPhotoState.get(date)!==photoState) return; const error=document.createElement('p'); error.className='staff-photo-error'; error.textContent='Live frames failed to load. Review this day individually.'; detail.append(error); photoState.failed=true; selectedDays.delete(date); $('staffBatchConfirmed').checked=false; updateSelection(); });
                        link.append(img); detail.append(link);
                    });
                    card.querySelector('.staff-card-evidence').append(detail);
                }
            }
            col.append(card); $('staffReviewGallery').append(col);
        }
        updateSelection();
    }
    function ensureLoaded() {
        if (view === 'teacher') {
            if (!report || String(report.teacher_id) !== teacher.value || report.date !== settingsDate.value) throw new Error('Load the selected teacher and date first.');
            return;
        }
        if (!report || String(report.teacher_id) !== teacher.value || report.month !== month.value) throw new Error('Load the selected teacher and month first.');
    }
    function selectDate(date) {
        if (date!==selectedDate) { reviewMessage(); formMessage('staffCorrection'); }
        selectedDate = date;
        $('staffDays').querySelectorAll('tr[data-attendance-date]').forEach(row=> {
            const active=row.dataset.attendanceDate===date;
            row.classList.toggle('staff-day-selected',active);
            row.querySelector('[data-date]').setAttribute('aria-pressed',String(active));
        });
        $('staffSelectedDate').textContent = '— ' + date;
        $('staffReview').elements.date.value = date;
        $('staffCorrection').elements.date.value = date;
        const d = record(date), day = report?.days.find(r => r.date === date);
        $('staffCorrection').elements.check_in.value = d?.check_in ? dateTime(d.check_in, day?.timezone) : '';
        $('staffCorrection').elements.check_out.value = d?.check_out ? dateTime(d.check_out, day?.timezone) : '';
        const events = (report?.events || []).filter(e => e.work_date === date);
        $('staffPhotos').replaceChildren();
        if (!events.length) $('staffPhotos').textContent = 'No app selfies for this date. Check the correction reason and audit history.';
        for (const event of events) {
            const col = document.createElement('div'); col.className = 'col-md-6';
            const title = document.createElement('h5'); title.textContent = (event.punch_type === 'in' ? 'Arrival' : 'Departure') + ' · ' + dateTime(event.occurred_at, day?.timezone);
            col.append(title);
            for (const key of ['selfie_url','evidence_url']) {
                const url = imageUrl(event[key]);
                if (!url) continue;
                const link = document.createElement('a'); link.href = url; link.target = '_blank'; link.rel = 'noopener noreferrer';
                const img = document.createElement('img'); img.src = url; img.loading = 'lazy'; img.referrerPolicy = 'no-referrer';
                img.alt = key === 'selfie_url' ? 'Attendance selfie' : 'Live challenge frames';
                link.append(img); col.append(link);
            }
            const details = document.createElement('p'); details.className = 'small text-muted';
            let loc={}; try { loc=JSON.parse(event.location_json) || {}; } catch { /* Older/manual records may have no location. */ }
            let proof={}; try {proof=JSON.parse(event.proof_json) || {};} catch { /* Older events use the original blink/turn mode. */ }
            details.textContent = `Reported distance ${loc.distance_m}m · GPS error ${loc.accuracy_m}m. Selfie mode: ${selfieModeLabel(proof.selfie_mode)}. ${proof.selfie_mode==='manual_selfie'?'No motion liveness challenge was required.':'On-device liveness signals require review.'} Check the uncovered face and school background.`;
            col.append(details); $('staffPhotos').append(col);
        }
    }
    function renderAttendanceTable(print = false) {
        if (!report || !$('staffDays')) return;
        const attendanceDays=report.attendance_days || report.days;
        const finance=context.can_manage_payroll && report.payroll_mode!=='manual', count=attendanceDays.length, pages=Math.max(1,Math.ceil(count/attendancePageSize));
        const deductionHeader=$('staffAttendanceCard').querySelector('thead tr th:last-child');
        if (context.can_manage_payroll && deductionHeader) deductionHeader.hidden=!finance;
        attendancePage=Math.max(1,Math.min(attendancePage,pages));
        const offset=(attendancePage-1)*attendancePageSize;
        $('staffAttendancePeriod').textContent=(report.teacher_name || context.teachers.find(t=>String(t.id)===teacher.value)?.name || '')+' · '+report.month;
        $('staffAttendancePage').innerHTML=Array.from({length:pages},(_,i)=>`<option value="${i+1}">Days ${i*attendancePageSize+1}–${Math.min((i+1)*attendancePageSize,count)}</option>`).join('');
        $('staffAttendancePage').value=String(attendancePage);
        $('staffAttendancePage').disabled=busy>0 || pages===1;
        $('staffAttendancePrevious').disabled=busy>0 || attendancePage===1;
        $('staffAttendanceNext').disabled=busy>0 || attendancePage===pages;
        $('staffAttendancePageInfo').textContent=count ? `Showing ${offset+1}–${Math.min(offset+attendancePageSize,count)} of ${count} days · Page ${attendancePage} of ${pages}` : 'No attendance dates for this month.';
        $('staffDays').innerHTML = (print ? attendanceDays : attendanceDays.slice(offset,offset+attendancePageSize)).map(d => {
            const saved = record(d.date);
            const deduction = ['absence_paise','late_paise','early_paise','short_day_paise'].reduce((s,k)=>s+Number(d[k]||0),0);
            const selected=d.date===selectedDate;
            const review=saved?.review_status || '—', reviewStyle=review==='approved'?'text-bg-success':review==='rejected'?'text-bg-danger':review==='pending'?'text-bg-warning':'text-bg-light';
            return `<tr data-attendance-date="${esc(d.date)}" ${selected?'class="staff-day-selected"':''}><td><button type="button" class="btn btn-link p-0" data-date="${esc(d.date)}" aria-label="Review attendance photos for ${esc(d.date)}" aria-pressed="${selected}">${esc(d.date)}</button></td><td class="staff-time-pair"><div><span>In</span>${esc(dateTime(saved?.check_in,d.timezone))}</div><div><span>Out</span>${esc(dateTime(saved?.check_out,d.timezone))}</div></td><td><div>${esc(d.status)}</div><span class="badge ${reviewStyle}">${esc(review)}</span>${saved?.override_status?`<span class="staff-day-meta ms-1">Admin: ${esc(saved.override_status)}</span>`:''}</td><td><div class="text-nowrap">${esc(d.shift_start || '—')} – ${esc(d.shift_end || '—')}</div><div class="staff-day-meta">${d.rule_source==='teacher'?'Personal rules':'School rules'}</div></td><td class="staff-time-pair"><div><span>Late</span>${Number(d.late_minutes||0)} min</div><div><span>Early</span>${Number(d.early_minutes||0)} min</div></td>${finance ? `<td>${money(deduction)}</td>` : ''}</tr>`;
        }).join('');
        $('staffDays').querySelectorAll('[data-date]').forEach(el=>el.addEventListener('click',()=> {
            selectDate(el.dataset.date);
            $('staffReview').scrollIntoView({behavior:'smooth',block:'center'});
        }));
    }
    function schoolPayrollMode() {
        let mode='attendance';
        for (const v of context.payroll_modes || []) if (v.effective_month<=month.value) mode=v.mode;
        return mode;
    }
    function renderPayrollMode() {
        const form=$('staffPayrollMode'); if (!form) return;
        const mode=schoolPayrollMode();
        form.elements.mode.value=mode;
        $('staffPayrollModeSummary').textContent=`School setting for ${month.value}: ${mode==='manual'?'Manual salary':'Attendance-based salary'}. Saving applies to every teacher.`;
        $('staffPayrollModeHistory').innerHTML=(context.payroll_modes || []).map(v=>`<li>From ${esc(v.effective_month)} · ${v.mode==='manual'?'Manual':'Attendance-based'} · ${esc(v.reason)}</li>`).join('') || '<li>No saved mode. Attendance-based salary is the default.</li>';
    }
    function showAttendanceSections() {
        const manual=context.can_manage_payroll && report?.payroll_mode==='manual';
        if ($('staffManualSalaryInfo')) $('staffManualSalaryInfo').hidden=!manual;
        const hidden=manual && !$('staffShowAttendance').checked;
        for (const id of ['staffReviewWorkspace','staffAttendanceCard','staffReviewCard','staffCorrectionItem','staffReviewActions']) if ($(id)) $(id).hidden=hidden;
    }
    function renderReport() {
        const finance = context.can_manage_payroll;
        renderPayrollMode(); showAttendanceSections();
        const manual=finance && report.payroll_mode==='manual';
        const cards = [['Salary state', report.state || 'Attendance review']];
        if (finance) cards.push(['Salary mode',manual?'Manual':'Attendance-based']);
        if (!manual) cards.push(['Pending reviews',report.records.filter(d => d.review_status === 'pending').length]);
        if (manual) {
            $('staffSalaryPanel').classList.add('show');
            $('staffSalaryToggle').classList.remove('collapsed'); $('staffSalaryToggle').setAttribute('aria-expanded','true');
        }
        if (finance) cards.push(['Gross',money(report.gross_paise)],['Attendance deductions',money(['absence_paise','late_paise','early_paise','short_day_paise'].reduce((s,k)=>s+Number(report[k]),0))],['Adjustments',money(report.adjustments_paise)],['Net salary',money(report.net_paise)]);
        if (finance && !manual && Number(report.monthly_late_days)>0) cards.push(['Monthly-rule late days',Number(report.monthly_late_days)],['Salary days for late',Number(report.late_salary_days)]);
        $('staffSummary').innerHTML = cards.map(([title,value])=>`<div class="col-sm-6 col-lg-2"><div class="card h-100"><div class="card-body"><div class="small text-muted">${esc(title)}</div><strong>${esc(value)}</strong></div></div></div>`).join('');
        $('staffFormula').textContent = finance ? report.formula + (report.paid_reference ? ' Payment reference: '+report.paid_reference : '') : '';
        attendancePage=1; renderAttendanceTable();
        if (finance) {
            $('staffAdjustments').innerHTML = (report.adjustments||[]).map(a=>`<li>#${Number(a.id)} · ${money(a.amount_paise)} · ${esc(a.reason)}</li>`).join('');
        }
        if ($('staffSettingsLink')) $('staffSettingsLink').href = 'teacher-attendance-settings.php?teacher_id='+encodeURIComponent(teacher.value);
        $('staffAudit').replaceChildren();
        for (const audit of report.audit || []) {
            const detail = document.createElement('details');
            const title = document.createElement('summary'); title.textContent = `${audit.created_at} UTC · admin #${audit.actor_id} · ${audit.action_name} · ${audit.reference_key} · ${audit.reason}`;
            const before = document.createElement('pre'); before.style.whiteSpace = 'pre-wrap';
            before.textContent = 'Before: '+audit.before_json+'\nAfter: '+audit.after_json;
            detail.append(title,before); $('staffAudit').append(detail);
        }
        const attendanceDays=report.attendance_days || report.days;
        selectDate(selectedDate.startsWith(month.value) ? selectedDate : (attendanceDays.find(d=>record(d.date)?.review_status==='pending')?.date || attendanceDays[0]?.date || report.month+'-01'));
        renderGallery();
    }
    async function loadReport() {
        clearFeedback();
        if (view === 'school') return;
        if (view === 'teacher') {
            const version=++settingsLoadVersion;
            teacherSettingsState('loading');
            try {
                // Reload also recovers if the initial context request failed.
                if (!Array.isArray(context.teachers)) { context=await request(); renderContext(true); }
                if (!teacher.value || !settingsDate.value) { teacherSettingsState('idle'); return; }
                const id=teacher.value, date=settingsDate.value;
                const loaded=await request('?action=settings&teacher_id='+encodeURIComponent(id)+'&date='+encodeURIComponent(date));
                if (version !== settingsLoadVersion || id !== teacher.value || date !== settingsDate.value) return;
                report=loaded;
                renderSettings();
                teacherSettingsState('ready');
            } catch (error) {
                if (version === settingsLoadVersion) teacherSettingsState('error',error.message);
                throw error;
            }
            return;
        }
        const version=++settingsLoadVersion;
        renderPayrollMode();
        reviewMessage();
        report=null; selectedDays.clear(); reviewPhotoState.clear(); galleryPage=1; reviewQueue=null;
        ['staffSummary','staffDays','staffPhotos','staffAudit','staffReviewGallery','staffReviewQueue'].forEach(id=>$(id)?.replaceChildren());
        $('staffGalleryStatus').textContent='Loading photos for the selected teacher and month...';
        $('staffGalleryTeacher').textContent='';
        $('staffBatchTeacher').textContent='';
        $('staffBatchConfirmed').checked=false;
        root.querySelectorAll('[data-gallery-page]').forEach(el=>el.disabled=true);
        root.querySelectorAll('[data-gallery-page-info]').forEach(el=>el.textContent='');
        ['staffAttendancePrevious','staffAttendanceNext','staffAttendancePage'].forEach(id=>$(id).disabled=true);
        ['staffAttendancePeriod','staffAttendancePageInfo','staffAttendancePage'].forEach(id=>$(id).replaceChildren());
        $('staffQueueSummary').textContent='Loading staff review progress...'; $('staffNextTeacher').disabled=true; updateSelection();
        if (!Array.isArray(context.teachers)) { context=await request(); renderContext(true); }
        if (!teacher.value || !month.value) { $('staffGalleryStatus').textContent='Choose a teacher and month.'; return; }
        const id=teacher.value, selectedMonth=month.value;
        const [loaded,queue]=await Promise.allSettled([
            request('?action=report&teacher_id='+encodeURIComponent(id)+'&month='+encodeURIComponent(selectedMonth)),
            request('?action=review_queue&month='+encodeURIComponent(selectedMonth))
        ]);
        if (version!==settingsLoadVersion || id!==teacher.value || selectedMonth!==month.value) return;
        if (queue.status==='fulfilled') {
            const selectableIds=new Set([...teacher.options].map(option=>option.value));
            reviewQueue={...queue.value,teachers:queue.value.teachers.filter(t=>selectableIds.has(String(t.teacher_id)))};
        }
        renderQueue();
        if (loaded.status==='rejected') { $('staffGalleryStatus').textContent='Photos could not be loaded. Load / Reload to retry.'; throw loaded.reason; }
        report=loaded.value; renderReport();
        if ($('staffMessage').classList.contains('alert-danger')) { $('staffMessage').className='alert d-none'; $('staffMessage').textContent=''; }
    }
    function syncLateFields(f) {
        const monthly=f.elements.late_mode.value==='monthly_count';
        f.querySelectorAll('[data-late-count]').forEach(el=>el.hidden=!monthly);
        f.querySelector('[data-late-amount]').hidden=monthly;
        f.elements.late_amount.required=!monthly;
        f.elements.late_days_per_deduction.required=monthly;
        f.elements.late_partial_mode.required=monthly;
        f.elements.late_partial_amount.required=monthly;
        f.querySelector('[data-late-partial-label]').textContent=f.elements.late_partial_mode.value==='per_minute'
            ? 'Per-minute late amount (incomplete group)' : 'Per-day late amount (incomplete group)';
    }
    function fillRuleFields(f, p) {
            p={...context.defaults,...p};
            for (const [key,value] of Object.entries(p)) if (f.elements.namedItem(key)) f.elements.namedItem(key).value = key === 'enabled' ? Number(value) : value;
            if (f.elements.timezone) f.elements.timezone.value = context.timezone;
            f.elements.late_amount.value = money(p.late_amount_paise);
            f.elements.late_partial_amount.value = money(p.late_partial_amount_paise);
            f.elements.early_amount.value = money(p.early_amount_paise);
            syncLateFields(f);
            const names = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
            $('staffWeekdays').innerHTML = names.map((name,i)=>`<label class="me-3"><input type="checkbox" name="working_days" value="${i+1}" ${p.working_days.includes(i+1)?'checked':''}> ${name}</label>`).join('');
            $('staffDaySchedules').innerHTML = names.map((name,i)=> {
                const day=i+1, custom=p.day_schedules[day] || {};
                return `<div class="col-12 col-xl-6"><details class="border rounded p-3" ${Object.keys(custom).length?'open':''}>
                    <summary class="fw-semibold">${name} · ${Object.keys(custom).length?'Custom settings':'Common settings'}</summary>
                    <p class="small text-muted mt-2">Fill only the fields that differ. Blank fields follow the common settings above. Working weekdays still controls whether this day is open.</p>
                    <div class="row g-2">${Object.entries(weekdayFields).map(([key,label])=> {
                        const id=weekdayInput(key,day);
                        return `<div class="col-12 col-sm-6"><label class="form-label w-100" for="${id}">${label}<input id="${id}" name="${id}" type="${key==='minimum_work_min'?'number':'time'}" ${key==='minimum_work_min'?'min="0" max="1440" step="1"':''} class="form-control" value="${esc(custom[key] ?? '')}"></label></div>`;
                    }).join('')}</div></details></div>`;
            }).join('');
    }
    function tomorrow() {
        const date = new Date(context.today+'T12:00:00Z'); date.setUTCDate(date.getUTCDate()+1);
        return date.toISOString().slice(0,10);
    }
    function copyNote(text = '') {
        const note = $('staffRuleCopyNote');
        if (!note) return;
        note.textContent = text;
        note.classList.toggle('d-none', !text);
    }
    function personalGroups(f, overrides) {
        f.querySelectorAll('[data-override]').forEach(el=> {
            el.checked = Object.hasOwn(overrides, el.dataset.override);
            const fields = f.querySelector(`[data-fields="${el.dataset.override}"]`);
            fields.disabled = !el.checked; fields.hidden = !el.checked;
        });
    }
    function reuseSchoolVersion(id) {
        if (busy || !context.can_manage_payroll) return;
        const version = context.policies.find(v=>String(v.id) === id);
        if (!version) throw new Error('This rule version is unavailable. Reload the page.');
        const f = $('staffRules');
        fillRuleFields(f, version.rules);
        f.elements.effective_date.value = tomorrow();
        f.elements.effective_date.min = tomorrow();
        f.elements.reason.value = `Reusing school rule version #${Number(version.id)}`;
        copyNote(`Copied school version #${Number(version.id)} into this form. Review the settings, choose Effective from and Change reason, then click Create rule version to activate them.`);
        f.scrollIntoView({behavior:'smooth',block:'start'});
        f.elements.effective_date.focus({preventScroll:true});
    }
    function reuseTeacherVersion(id) {
        if (busy || !context.can_manage_payroll) return;
        ensureLoaded();
        const version = report.teacher_rules.find(v=>String(v.id) === id);
        if (!version || Number(version.teacher_id) !== Number(teacher.value)) throw new Error('This personal version is unavailable for the selected teacher. Reload first.');
        const f = $('staffTeacherRules');
        // Copy personal groups only; unticked groups still follow school rules.
        const rules = Object.assign({}, report.school_policy.rules, ...Object.values(version.overrides));
        if (version.overrides.deductions && !Object.hasOwn(version.overrides.deductions,'late_partial_mode')) {
            rules.late_partial_mode=context.defaults.late_partial_mode;
        }
        // Legacy personal deduction versions had no incomplete-group amount and used zero.
        if (version.overrides.deductions && !Object.hasOwn(version.overrides.deductions,'late_partial_amount_paise')) {
            rules.late_partial_amount_paise=context.defaults.late_partial_amount_paise;
        }
        fillRuleFields(f, rules);
        personalGroups(f, version.overrides);
        f.elements.effective_date.value = tomorrow();
        f.elements.end_date.value = '';
        f.elements.reason.value = `Reusing personal rule version #${Number(version.id)}`;
        copyNote(`Copied personal version #${Number(version.id)} for ${report.teacher_name}. Choose a new Effective from and, for a temporary rule, a new Last date. Review Change reason, then click Save personal rules to activate it.`);
        f.scrollIntoView({behavior:'smooth',block:'start'});
        f.elements.effective_date.focus({preventScroll:true});
    }
    function renderContext(fillRules = false) {
        if (teacher) {
            const previous = teacher.value || new URLSearchParams(location.search).get('teacher_id');
            const teachers=context.teachers.filter(t=>view!=='review' || t.status==='active');
            teacher.innerHTML = teachers.map(t=>`<option value="${Number(t.id)}">${esc(t.name)} (${esc(t.status)})</option>`).join('');
            if ([...teacher.options].some(o=>o.value===previous)) teacher.value = previous;
            if (!teacher.value) message(view==='review'?'No active teacher accounts are available.':'No teacher accounts are available.',true);
        }
        if (month) {
            const selected=month.value || context.today.slice(0,7);
            monthYear.value=selected.slice(0,4); monthName.value=selected.slice(5,7);
            syncMonthSelection();
        }
        renderPayrollMode();
        if (settingsDate && !settingsDate.value) settingsDate.value = context.today;
        if ($('staffReview')) $('staffReview').elements.date.max = context.today;
        if ($('staffCorrection')) $('staffCorrection').elements.date.max = context.today;
        if ($('staffCalendarList')) $('staffCalendarList').innerHTML = context.calendar.map(d=>`<li>${esc(d.work_date)} · ${esc(d.kind)} · ${esc(d.reason)}</li>`).join('');
        const f = $('staffRules');
        if (!f || !context.can_manage_payroll) return;
        if (fillRules) {
            copyNote();
            fillRuleFields(f, context.policies.at(-1)?.rules || context.defaults);
            f.elements.effective_date.value = context.policies.length ? tomorrow() : context.today;
            f.elements.effective_date.min = context.policies.length ? f.elements.effective_date.value : '2000-01-01';
        }
        $('staffPolicyHistory').innerHTML = context.policies.map(p=>`<li class="mb-2">Version #${Number(p.id)} · ${esc(p.effective_date)} · ${p.rules.enabled?'Enabled':'Disabled'} · ${esc(selfieModeLabel(p.rules.selfie_mode))} · Late: ${esc(lateRuleLabel(p.rules))} · ${esc(p.reason)} <button type="button" class="btn btn-sm btn-outline-primary ms-2" data-reuse-school="${Number(p.id)}" aria-label="Reuse school version ${Number(p.id)}">Use this version again</button></li>`).join('');
    }
    function renderSettings() {
        const p = report.policy, f = $('staffTeacherRules');
        copyNote();
        f.closest('.card').hidden=!p;
        fillRuleFields(f, p?.rules || context.defaults);
        const active = report.teacher_rules.find(v=>Number(v.id) === Number(p?.teacher_rule_id));
        personalGroups(f, active?.overrides || {});
        f.elements.effective_date.value = report.date;
        f.elements.end_date.value = active?.end_date || '';
        f.elements.reason.value = '';
        $('staffPersonalSummary').textContent = `${report.teacher_name} · ${report.date} · ${!p?'Digital attendance is not configured for this date. You can still save salary terms below.':p.rule_source==='teacher'?'Personal attendance rules are active.':'Following school attendance rules.'}`;
        const r=p?.rules || context.defaults, names=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
        $('staffEffectiveRules').innerHTML = p ? `<div class="table-responsive"><table class="table table-sm"><caption>Rules used on the selected date</caption><tbody>
            <tr><th>Working days</th><td>${esc(r.working_days.map(d=>names[d-1]).join(', '))}</td></tr>
            <tr><th>School camera rule</th><td>${esc(selfieModeLabel(r.selfie_mode))}; uncovered face required. Change this for everyone in School Attendance Settings.</td></tr>
            <tr><th>Selected date</th><td>${report.schedule.working?'Working day':'Non-working day'}; shift ${esc(report.schedule.start_time)} – ${esc(report.schedule.end_time)}</td></tr>
            <tr><th>Attendance window</th><td>Arrival ${esc(report.schedule.checkin_open)} – ${esc(report.schedule.checkin_close)}; departure closes ${esc(report.schedule.checkout_close)}</td></tr>
            <tr><th>Minimum work / grace</th><td>${Number(report.schedule.minimum_work_min)} min; late ${Number(r.late_grace_min)} min; early ${Number(r.early_grace_min)} min</td></tr>
            <tr><th>Deductions</th><td>Absent ${Number(r.absence_percent)}%; short day ${Number(r.short_day_percent)}%; late ${esc(lateRuleLabel(r))}; early ${money(r.early_amount_paise)} (${r.early_mode==='flat'?'per day':'per minute after grace'}); daily rate divides salary by ${r.salary_divisor==='working_days'?'scheduled working days':r.salary_divisor==='calendar_days'?'calendar days':Number(r.fixed_divisor)}</td></tr>
            </tbody></table></div>` : '';
        $('staffTeacherRuleHistory').innerHTML = report.teacher_rules.length ? '<ul>'+report.teacher_rules.map(v=>`<li class="mb-2">Version #${Number(v.id)} · ${esc(v.effective_date)} – ${esc(v.end_date || 'ongoing')} · ${esc(Object.keys(v.overrides).join(', ') || 'School defaults')} · ${esc(v.reason)} <button type="button" class="btn btn-sm btn-outline-primary ms-2" data-reuse-teacher="${Number(v.id)}" aria-label="Reuse personal version ${Number(v.id)}">Use this version again</button></li>`).join('')+'</ul>' : 'No personal rules. School defaults apply.';
        $('staffTerms').textContent = report.salary_terms.map(t=>`${t.effective_date}: ${money(t.salary_paise)} / month${t.employment_end?' · ends '+t.employment_end:''} · ${t.reason}`).join('\n') || 'No salary term. Add the teacher’s salary below.';
        $('staffTerms').style.whiteSpace = 'pre-line';
        const salary = report.salary_terms.filter(t=>t.effective_date<=report.date).at(-1);
        $('staffSalary').elements.effective_date.value = report.date;
        $('staffSalary').elements.salary.value = salary ? money(salary.salary_paise) : '';
        $('staffSalary').elements.employment_end.value = salary?.employment_end || '';
    }
    function bindForm(id, action, transform = v=>v) {
        const form = $(id); if (!form) return;
        formMessage(id);
        form.addEventListener('submit', async event => {
            event.preventDefault();
            if (busy) return;
            const reviewing=id==='staffReview';
            let saved=false, reviewDate=form.elements.date?.value || '', decision=event.submitter?.value, appliedAction=action, appliedMonth=month?.value;
            clearFeedback(form.closest('.card,.accordion-item') || form.parentElement);
            try {
                if (!['policy','calendar','payroll_mode'].includes(action)) ensureLoaded();
                const data = Object.fromEntries(new FormData(form).entries());
                if (event.submitter?.name) data[event.submitter.name] = event.submitter.value;
                const payload = transform({...data,action:action || data.action,...(teacher?{teacher_id:Number(teacher.value)}:{}),...(month?{month:month.value}:{})});
                appliedAction=payload.action; appliedMonth=payload.month;
                if (['review','correct'].includes(action)) {
                    if (!payload.date.startsWith(report.month)) throw new Error('Select a date in the loaded month.');
                    payload.version = Number(record(payload.date)?.version || 0);
                }
                if (payload.action === 'finalize') payload.calculation_hash = report.calculation_hash;
                formMessage(id,reviewing ? `Saving review for ${reviewDate}...` : 'Saving...','info');
                await request('',payload); saved=true;
                message('Saved.');
                if (action === 'teacher_rules') settingsDate.value = payload.effective_date;
                if (view === 'teacher') teacherSettingsState('loading');
                context = await request(); renderContext(action === 'policy');
                await loadReport();
                if (reviewing) reviewMessage(`${reviewDate}: ${decision==='approved'?'Attendance approved.':'Attendance rejected; this day is treated as absent.'}`,'success',true);
                else {
                    const salaryResult={finalize:'Salary finalized and locked.',paid:'Salary marked paid.',reopen:'Salary reopened for correction.'};
                    formMessage(id,salaryResult[appliedAction] ? `${appliedMonth}: ${salaryResult[appliedAction]}` : 'Saved.','success',true);
                }
            } catch (error) {
                if (view === 'teacher' && !report) teacherSettingsState('error',error.message);
                const detail=reviewing ? (saved ? `${reviewDate}: Review was saved, but the refreshed report could not be loaded. Load / Reload before making another change. ${error.message}` : `${reviewDate}: ${decision==='approved'?'Approval':'Review'} was not saved. ${error.message}`) : (saved ? `Changes were saved, but the refreshed view could not be loaded. Load / Reload before making another change. ${error.message}` : error.message);
                message(detail,true);
                formMessage(id,detail,'danger',true);
            }
        });
    }
    bindForm('staffReview','review'); bindForm('staffCorrection','correct'); bindForm('staffDevice','reset_device');
    bindForm('staffCalendar','calendar'); bindForm('staffSalary','salary'); bindForm('staffAdjustment','adjust'); bindForm('staffSettlement',null); bindForm('staffPayrollMode','payroll_mode');
    $('staffShowAttendance')?.addEventListener('change',showAttendanceSections);
    function readRuleFields(f) {
        const rules = {...context.defaults};
        for (const key of Object.keys(rules)) if (f.elements.namedItem(key) && !['working_days','day_schedules'].includes(key)) {
            const raw = f.elements.namedItem(key).value;
            rules[key] = typeof context.defaults[key] === 'number' ? Number(raw) : raw;
        }
        if (f.elements.enabled) rules.enabled = f.elements.enabled.value === '1';
        rules.late_amount_paise = rules.late_mode==='monthly_count' ? 0 : Math.round(Number(f.elements.late_amount.value)*100);
        rules.late_partial_amount_paise = Math.round(Number(f.elements.late_partial_amount.value)*100);
        rules.early_amount_paise = Math.round(Number(f.elements.early_amount.value)*100);
        rules.working_days = [...f.querySelectorAll('[name=working_days]:checked')].map(el=>Number(el.value));
        rules.day_schedules = {};
        for (let day=1;day<=7;day++) {
            const custom={};
            for (const key of Object.keys(weekdayFields)) {
                const raw=f.elements[weekdayInput(key,day)].value;
                if (raw !== '') custom[key]=key === 'minimum_work_min' ? Number(raw) : raw;
            }
            if (Object.keys(custom).length) rules.day_schedules[day]=custom;
        }
        return rules;
    }
    bindForm('staffRules','policy', data=> ({action:'policy',effective_date:data.effective_date,reason:data.reason,rules:readRuleFields($('staffRules'))}));
    bindForm('staffTeacherRules','teacher_rules', data=> {
        const f=$('staffTeacherRules'), rules=readRuleFields(f), overrides={};
        const groups={schedule:['working_days','start_time','end_time','day_schedules','checkin_open','checkin_close','checkout_close','minimum_work_min'],grace:['late_grace_min','early_grace_min'],deductions:['late_mode','late_amount_paise','late_days_per_deduction','late_partial_mode','late_partial_amount_paise','early_mode','early_amount_paise','absence_percent','short_day_percent','salary_divisor','fixed_divisor']};
        f.querySelectorAll('[data-override]:checked').forEach(el=>overrides[el.dataset.override]=Object.fromEntries(groups[el.dataset.override].map(k=>[k,rules[k]])));
        return {...data,overrides};
    });
    for (const id of ['staffRules','staffTeacherRules']) {
        const form=$(id);
        form?.elements.late_mode.addEventListener('change',()=>syncLateFields(form));
        form?.elements.late_partial_mode.addEventListener('change',()=>syncLateFields(form));
    }
    if ($('staffTeacherRules')) $('staffTeacherRules').querySelectorAll('[data-override]').forEach(el=>el.addEventListener('change',()=> {
        const fields=$('staffTeacherRules').querySelector(`[data-fields="${el.dataset.override}"]`);
        fields.disabled = !el.checked; fields.hidden = !el.checked;
    }));
    $('staffDaySchedules')?.addEventListener('input',event=> {
        if (event.target.tagName !== 'INPUT') return;
        const day=event.target.closest('details'), summary=day.querySelector('summary');
        const custom=[...day.querySelectorAll('input')].some(el=>el.value !== '');
        summary.textContent=summary.textContent.split(' · ')[0]+' · '+(custom?'Custom settings':'Common settings');
    });
    $('staffPolicyHistory')?.addEventListener('click', event=> {
        const button = event.target.closest('[data-reuse-school]');
        if (!button) return;
        try { formMessage('staffRules'); reuseSchoolVersion(button.dataset.reuseSchool); } catch (error) { message(error.message,true); formMessage('staffRules',error.message,'danger',true); }
    });
    $('staffTeacherRuleHistory')?.addEventListener('click', event=> {
        const button = event.target.closest('[data-reuse-teacher]');
        if (!button) return;
        try { formMessage('staffTeacherRules'); reuseTeacherVersion(button.dataset.reuseTeacher); } catch (error) { message(error.message,true); formMessage('staffTeacherRules',error.message,'danger',true); }
    });
    const reload = () => loadReport().catch(e=> { message(e.message,true); loadMessage(e.message,'danger',true); });
    function changeAttendancePage(page) {
        if (busy || !report) return;
        attendancePage=Number(page); renderAttendanceTable();
    }
    $('staffAttendancePrevious')?.addEventListener('click',()=>changeAttendancePage(attendancePage-1));
    $('staffAttendanceNext')?.addEventListener('click',()=>changeAttendancePage(attendancePage+1));
    $('staffAttendancePage')?.addEventListener('change',event=>changeAttendancePage(event.target.value));
    window.addEventListener('beforeprint',()=> { if (view==='review' && report) renderAttendanceTable(true); });
    window.addEventListener('afterprint',()=> { if (view==='review' && report) renderAttendanceTable(); });
    root.querySelectorAll('[data-gallery-page]').forEach(button=>button.addEventListener('click',()=> {
        if (busy || !report) return;
        galleryPage+=Number(button.dataset.galleryPage);
        renderGallery(false);
        $('staffReviewWorkspace').scrollIntoView({behavior:'smooth',block:'start'});
    }));
    $('staffReviewFilter')?.addEventListener('change',()=> { if (!busy && report) renderGallery(); });
    $('staffReviewGallery')?.addEventListener('change',event=> {
        if (!event.target.matches('[data-check-day]') || busy) return;
        const card=event.target.closest('[data-review-date]');
        if (event.target.checked && canSelectCard(card)) selectedDays.add(card.dataset.reviewDate);
        else selectedDays.delete(card.dataset.reviewDate);
        $('staffBatchConfirmed').checked=false; updateSelection();
    });
    $('staffReviewGallery')?.addEventListener('click',event=> {
        const button=event.target.closest('[data-open-day]');
        if (!button || busy || !report) return;
        selectDate(button.dataset.openDay); $('staffReview').scrollIntoView({behavior:'smooth',block:'center'});
    });
    $('staffSelectVisible')?.addEventListener('click',()=> {
        if (busy || !report) return;
        $('staffReviewGallery').querySelectorAll('[data-review-date]').forEach(card=> { if (canSelectCard(card)) selectedDays.add(card.dataset.reviewDate); });
        $('staffBatchConfirmed').checked=false; updateSelection();
    });
    $('staffClearSelection')?.addEventListener('click',()=> { selectedDays.clear(); $('staffBatchConfirmed').checked=false; updateSelection(); });
    $('staffBatchConfirmed')?.addEventListener('change',updateSelection);
    $('staffReviewQueue')?.addEventListener('click',event=> {
        const button=event.target.closest('[data-review-teacher]');
        if (!button || busy) return;
        teacher.value=button.dataset.reviewTeacher; reload();
    });
    $('staffNextTeacher')?.addEventListener('click',()=> {
        if (busy || !reviewQueue || reviewQueue.month!==month.value) return;
        const items=reviewQueue.teachers, index=items.findIndex(t=>String(t.teacher_id)===teacher.value);
        const next=[...items.slice(index+1),...items.slice(0,index)].find(t=>t.pending>0 && !t.locked);
        if (next) { teacher.value=String(next.teacher_id); reload(); }
    });
    if ($('staffBatchReview')) formMessage('staffBatchReview');
    $('staffBatchReview')?.addEventListener('submit',async event=> {
        event.preventDefault(); if (busy) return;
        clearFeedback($('staffReviewWorkspace'));
        let saved=false;
        try {
            ensureLoaded(); updateSelection();
            if (!selectedDays.size || !$('staffBatchConfirmed').checked || report.review_locked) throw new Error('Select the checked photo days and confirm you reviewed them.');
            const payload={action:'review_batch',teacher_id:Number(teacher.value),month:month.value,reason:$('staffBatchReason').value,
                days:[...selectedDays].sort().map(date=>({date,version:Number(record(date).version)}))};
            formMessage('staffBatchReview','Saving selected attendance reviews...','info');
            await request('',payload); saved=true;
            await loadReport();
            const detail=`Approved ${payload.days.length} day(s). Use Next teacher with pending reviews to continue.`;
            message(detail); formMessage('staffBatchReview',detail,'success',true);
        } catch(error) {
            $('staffBatchConfirmed').checked=false; updateSelection();
            const detail=(saved?'Approvals were saved, but the refreshed report could not be loaded. Load / Reload. ':'')+error.message;
            message(detail,true); formMessage('staffBatchReview',detail,'danger',true);
        }
    });
    $('staffReload')?.addEventListener('click',reload); teacher?.addEventListener('change',reload); settingsDate?.addEventListener('change',reload);
    const changeMonth = () => {
        try { syncMonthSelection(); reload(); } catch(error) { message(error.message,true); loadMessage(error.message,'danger',true); }
    };
    monthYear?.addEventListener('change',changeMonth); monthName?.addEventListener('change',changeMonth);
    if ($('staffReview')) $('staffReview').elements.date.addEventListener('change',e=>selectDate(e.target.value));
    $('staffPrint')?.addEventListener('click',()=>window.print());
    (async()=> { teacherSettingsState('loading'); context = await request(); renderContext(true); await loadReport(); })().catch(e=> { teacherSettingsState('error',e.message); message(e.message,true); loadMessage(e.message,'danger',true); });
})();
