/* Read-only salary payment report. Financial data stays in memory, never browser storage. */
(() => {
    'use strict';
    const root=document.getElementById('staffSalaryPayments'); if(!root) return;
    const $=id=>document.getElementById(id);
    const year=$('staffPaymentsYear'), month=$('staffPaymentsMonth'), basis=$('staffPaymentsBasis'), view=$('staffPaymentsView');
    const print=$('staffPaymentsPrint'), panel=$('staffPaymentsPrintable'), form=$('staffPaymentsFilters'), box=$('staffPaymentsMessage');
    const monthNames=['January','February','March','April','May','June','July','August','September','October','November','December'];
    let report=null, generation=0, pending=null;
    const amount=value=>root.dataset.currency+' '+(value/100).toFixed(2);
    const monthLabel=value=>monthNames[Number(value.slice(5))-1]+' '+value.slice(0,4);
    const node=(tag,text,className='')=>{const el=document.createElement(tag);el.textContent=text;if(className)el.className=className;return el;};
    function selection() {
        if(!/^\d{4}$/.test(year.value) || Number(year.value)<2000 || Number(year.value)>2100 || !/^(0[1-9]|1[0-2])$/.test(month.value)) throw new Error('Choose a valid year and month.');
        return {month:year.value+'-'+month.value,basis:basis.value};
    }
    function message(text='',error=false) {
        box.className=text?'alert '+(error?'alert-danger':'alert-info'):'alert d-none';
        box.setAttribute('role',error?'alert':'status');box.textContent=text;
    }
    function invalidate() {
        generation++;pending?.abort();pending=null;report=null;panel.hidden=true;print.disabled=true;
        delete root.dataset.reportReady;root.removeAttribute('aria-busy');
        message('Selection changed. Click Load report to see and print this month.');
    }
    function render() {
        if(!report) return;
        const details=view.value==='entries';
        const title=`${details?'Salary payment entries':'Salary payments by teacher'} — ${monthLabel(report.month)} (${report.basis==='salary_month'?'salary month':'payment month'})`;
        $('staffPaymentsTitle').textContent=title;
        $('staffPaymentsGenerated').textContent=`Generated: ${report.generated_at_local} · Time zone: ${report.timezone}`;
        const totals=$('staffPaymentsTotals');totals.replaceChildren();
        for(const [label,value] of [['Teachers paid',report.teacher_count],['Payment entries',report.payment_count],['Total recorded payments',amount(report.total_paise)]]) {
            const card=node('div',label);card.append(node('strong',String(value)));totals.append(card);
        }
        const warning=$('staffPaymentsWarning');warning.hidden=report.reconciliation_count===0;
        warning.textContent=`${report.reconciliation_count} payment entry/entries need checking: a salary was reopened, its current payment record differs or is unavailable, or the same teacher/salary month has multiple payment entries. Totals include every displayed entry; reconcile these with payment receipts.`;
        const columns=details?['#','Teacher','Salary month','Amount paid','Payment recorded on','Payment reference','Salary status now']:['#','Teacher','Salary month(s)','Payments','Total paid'];
        const heading=node('tr','');columns.forEach(label=>heading.append(node('th',label)));
        heading.querySelectorAll('th').forEach(el=>el.scope='col');$('staffPaymentsHead').replaceChildren(heading);
        const rows=$('staffPaymentsRows');rows.replaceChildren();
        const items=details?report.rows:report.teachers;
        for(const [index,item] of items.entries()) {
            const row=node('tr','');row.dataset.teacherId=String(item.teacher_id);
            row.append(node('td',String(index+1)));
            const teacher=node('td',item.teacher_name);teacher.append(node('span','ID: '+item.teacher_id,'staff-payment-meta'));
            if(item.needs_reconciliation) teacher.append(node('span','Check payment history','staff-payment-attention'));
            row.append(teacher);
            if(details) {
                row.append(node('td',monthLabel(item.salary_month)),node('td',amount(item.amount_paise),'staff-payment-amount'),node('td',item.paid_at_local),node('td',item.reference),node('td',item.salary_state));
            } else {
                row.append(node('td',item.salary_months.map(monthLabel).join(', ')),node('td',String(item.payment_count)),node('td',amount(item.amount_paise),'staff-payment-amount'));
            }
            rows.append(row);
        }
        if(!items.length) {const row=node('tr',''),cell=node('td','No recorded salary payments for this selection.');cell.colSpan=columns.length;row.append(cell);rows.append(row);}
        const foot=node('tr',''),label=node('th','Total recorded payments');
        label.scope='row';label.colSpan=details?3:4;foot.append(label,node('td',amount(report.total_paise),'staff-payment-amount'));
        if(details) {const tail=node('td','');tail.colSpan=3;foot.append(tail);}
        $('staffPaymentsFoot').replaceChildren(foot);
        $('staffPaymentsCaption').textContent=details?'Each row is a saved payment entry.':'All teachers with recorded payments, including inactive or removed teachers.';
        panel.hidden=false;print.disabled=false;root.dataset.reportReady='true';
        document.title=title;
    }
    async function load() {
        const current=++generation;pending?.abort();pending=new AbortController();
        report=null;panel.hidden=true;print.disabled=true;delete root.dataset.reportReady;root.setAttribute('aria-busy','true');
        message('Loading salary payments…');
        try {
            const picked=selection(),url=new URL(root.dataset.endpoint,location.href);
            url.search=new URLSearchParams({action:'payments',...picked}).toString();
            const response=await fetch(url,{credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json'},signal:pending.signal});
            const result=await response.json();if(current!==generation)return;
            if(!response.ok || !result.success) throw new Error(result.message || 'Salary payments could not be loaded.');
            const data=result.data;
            if(data?.month!==picked.month || data.basis!==picked.basis || !Array.isArray(data.rows) || !Array.isArray(data.teachers)
                    || !Number.isSafeInteger(data.total_paise) || data.total_paise<0) throw new Error('The server returned an invalid payment report. Reload or contact the administrator.');
            report=data;render();message();
        } catch(error) {if(current===generation && error.name!=='AbortError')message(error.message || 'Salary payments could not be loaded.',true);}
        finally {if(current===generation){pending=null;root.removeAttribute('aria-busy');}}
    }
    [year,month,basis].forEach(el=>el.addEventListener('change',invalidate));
    view.addEventListener('change',()=>{if(report)render();});
    form.addEventListener('submit',event=>{event.preventDefault();load();});
    print.addEventListener('click',()=>{if(report && root.dataset.reportReady)window.print();});
    window.addEventListener('beforeprint',()=>{if(report)render();});
    load();
})();
