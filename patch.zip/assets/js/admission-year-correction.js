(() => {
    'use strict';
    document.querySelectorAll('.admission-year-correction-form').forEach(form => {
        const fields = form.querySelector('.correction-fields');
        const result = form.querySelector('.correction-preview-result');
        const message = form.querySelector('.correction-message');
        const confirmation = form.querySelector('.correction-confirmation');
        const apply = form.querySelector('.correction-apply');
        const checkbox = form.elements.namedItem('confirm');
        let hash = null, busy = false;
        const clearPreview = () => {
            hash = null; checkbox.checked = false; apply.disabled = true;
            result.classList.add('d-none'); confirmation.classList.add('d-none');
        };
        form.elements.namedItem('target_year').addEventListener('input', clearPreview);
        checkbox.addEventListener('change', () => { apply.disabled = !hash || !checkbox.checked || busy; });
        const showMessage = (text, success = false) => {
            message.textContent = text;
            message.className = 'correction-message alert ' + (success ? 'alert-success' : 'alert-danger') + ' mt-3';
        };
        async function request(action) {
            if (busy || !form.reportValidity()) return;
            if (action === 'apply' && (!hash || !checkbox.checked)) return;
            const data = new FormData(form);
            data.set('action', action);
            if (hash) data.set('preview_hash', hash);
            busy = true; fields.disabled = true; message.classList.add('d-none');
            try {
                const response = await fetch(form.action, {method: 'POST', body: data, credentials: 'same-origin', headers: {Accept: 'application/json'}});
                const payload = await response.json();
                if (!response.ok || !payload.success) throw new Error(payload.message || 'Year correction could not be completed.');
                if (action === 'apply') {
                    clearPreview(); showMessage(payload.message, true);
                    // Reload canonical records only after the correction succeeds.
                    window.location.reload();
                    return;
                }
                clearPreview();
                result.replaceChildren();
                const heading = document.createElement('strong');
                heading.textContent = payload.source_year + ' → ' + payload.target_year;
                result.appendChild(heading);
                const list = document.createElement('ul');
                const labels = {unpaid_admission_fees: 'Unpaid admission fees', paid_admission_fees: 'Paid admission fees',
                    partial_payments: 'Partial admission payments', payment_backups: 'Admission payment backups', online_snapshots: 'Online admission snapshots'};
                Object.entries(labels).forEach(([key, label]) => {
                    const item = document.createElement('li'); item.textContent = label + ': ' + (payload.counts[key] ?? 0); list.appendChild(item);
                });
                result.appendChild(list);
                if (payload.blockers.length) {
                    payload.blockers.forEach(text => { const item = document.createElement('p'); item.textContent = text; result.appendChild(item); });
                    result.className = 'correction-preview-result alert alert-warning mt-3';
                } else {
                    hash = payload.preview_hash;
                    result.className = 'correction-preview-result alert alert-info mt-3';
                    confirmation.classList.remove('d-none');
                }
            } catch (error) {
                clearPreview();
                showMessage(error instanceof SyntaxError ? 'The server could not respond. Please preview again or try later.' : error.message);
            } finally {
                busy = false; fields.disabled = false; apply.disabled = !hash || !checkbox.checked;
            }
        }
        form.querySelector('.correction-preview').addEventListener('click', () => request('preview'));
        form.addEventListener('submit', event => { event.preventDefault(); request('apply'); });
    });
})();
