document.addEventListener('DOMContentLoaded', () => {
    const rules = {
        schoolLogo: { info: 'fileInfoSquare', label: 'Square logo', minWidth: 300, minHeight: 300, width: 512, height: 512, ratio: 1 },
        logoRectangle: { info: 'fileInfoRect', label: 'Rectangle logo', minWidth: 600, minHeight: 170, width: 600, height: 170, ratio: 60 / 17 }
    };
    const selected = {};
    const modalElement = document.getElementById('logoCropModal');
    const modal = new bootstrap.Modal(modalElement);
    const image = document.getElementById('logoCropImage');
    const apply = document.getElementById('applyLogoCrop');
    const upload = document.getElementById('uploadBtn');
    let pending = null;
    let cropper = null;
    let busy = false;

    function lockInputs(locked) {
        upload.disabled = locked;
        Object.keys(rules).forEach(field => { document.getElementById(field).disabled = locked; });
    }

    Object.entries(rules).forEach(([field, rule]) => {
        const input = document.getElementById(field);
        input.addEventListener('change', () => {
            const file = input.files[0];
            input.value = ''; // Allow selecting the same source again after cancelling.
            if (!file || pending || busy) return;
            if (file.type !== 'image/png' || file.size > 2 * 1024 * 1024) {
                toastr.error(`${rule.label}: Please select a PNG up to 2MB.`);
                return;
            }
            if (typeof Cropper !== 'function') {
                toastr.error('Image cropper could not load. Please reload the page and try again.');
                return;
            }
            pending = { field, file, rule, url: URL.createObjectURL(file) };
            lockInputs(true);
            const probe = new Image();
            probe.onload = () => {
                if (probe.naturalWidth < rule.minWidth || probe.naturalHeight < rule.minHeight
                    || probe.naturalWidth * probe.naturalHeight > 16000000) {
                    toastr.error(`${rule.label}: Original image must be at least ${rule.minWidth}×${rule.minHeight}px and up to 16 megapixels.`);
                    cleanup();
                    return;
                }
                image.src = pending.url;
                document.getElementById('logoCropTitle').textContent = `Crop ${rule.label} (${field === 'schoolLogo' ? '1:1' : '60:17'})`;
                modal.show();
            };
            probe.onerror = () => { toastr.error('The selected image could not be read.'); cleanup(); };
            probe.src = pending.url;
        });
    });

    modalElement.addEventListener('shown.bs.modal', () => {
        try {
            cropper = new Cropper(image, {
                aspectRatio: pending.rule.ratio, viewMode: 1, autoCropArea: 1,
                dragMode: 'move', rotatable: false, scalable: false, checkOrientation: false,
                toggleDragModeOnDblclick: false,
                ready() { apply.disabled = false; }
            });
        } catch (error) {
            toastr.error('Unable to open the image cropper. Please try again.');
            modal.hide();
        }
    });

    apply.addEventListener('click', () => {
        if (!cropper || !pending) return;
        const { field, file, rule } = pending;
        try {
            const canvas = cropper.getCroppedCanvas({ width: rule.width, height: rule.height, imageSmoothingQuality: 'high' });
            if (!canvas) throw new Error('No crop canvas');
            const previewUrl = canvas.toDataURL('image/png');
            selected[field] = { file, crop: cropper.getData() };
            const info = document.getElementById(rule.info);
            info.querySelector('.name-text').textContent = `${file.name} — cropped, ready to upload`;
            info.querySelector('.file-name').classList.remove('d-none');
            let preview = info.querySelector('img');
            if (!preview) {
                preview = document.createElement('img');
                preview.className = 'img-fluid mt-3';
                preview.style.maxHeight = '140px';
                preview.alt = `${rule.label} cropped preview`;
                info.appendChild(preview);
            }
            preview.src = previewUrl;
            modal.hide();
        } catch (error) {
            toastr.error('Unable to crop this image. Please select another image.');
        }
    });

    function cleanup() {
        if (cropper) cropper.destroy();
        cropper = null;
        if (pending) URL.revokeObjectURL(pending.url);
        pending = null;
        image.removeAttribute('src');
        apply.disabled = true;
        lockInputs(false);
    }
    modalElement.addEventListener('hidden.bs.modal', cleanup);

    document.getElementById('logoUploadForm').addEventListener('submit', event => {
        event.preventDefault();
        if (pending || busy) return;
        if (!Object.keys(selected).length) {
            toastr.error('Please select and crop at least one logo.');
            return;
        }
        const data = new FormData();
        Object.entries(selected).forEach(([field, entry]) => {
            // Send the original so the server can verify minimum source dimensions.
            data.append(field, entry.file);
            data.append(field + 'Crop', JSON.stringify(entry.crop));
        });
        busy = true;
        lockInputs(true);
        document.getElementById('uploadText').textContent = 'Processing...';
        document.getElementById('spinner').classList.remove('d-none');
        $.ajax({
            url: '../../api/admin/put/school/upload-school-logo.php', type: 'POST', data,
            processData: false, contentType: false, dataType: 'json',
            success(response) {
                if (response.success) {
                    toastr.success(response.message);
                    window.location.reload();
                } else toastr.error(response.message);
            },
            error(xhr) { toastr.error(xhr.responseJSON?.message || 'Unable to upload the logo. Please try again.'); },
            complete() {
                busy = false;
                lockInputs(false);
                document.getElementById('uploadText').textContent = 'Upload & Process';
                document.getElementById('spinner').classList.add('d-none');
            }
        });
    });
});
