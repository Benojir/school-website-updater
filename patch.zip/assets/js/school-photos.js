(function () {
    'use strict';
    const settings = document.currentScript?.dataset || {};
    const base = (settings.schoolUrl || '').replace(/\/$/, '');
    const cdn = (settings.photoCdn || '').replace(/\/$/, '');
    const prefix = settings.schoolPrefix || '';
    const active = settings.photoActive !== '0';
    const defaults = { students: 'default_student_dp.jpg', fathers: 'default_father_dp.jpg', mothers: 'default_mother_dp.jpg', teachers: 'default_teacher_dp.jpg', drivers: 'default_driver_dp.jpg' };
    const validName = name => /^[a-zA-Z0-9_-][a-zA-Z0-9_.-]{0,190}\.(?:jpe?g|png|gif|webp)$/i.test(name) && !name.includes('..');
    function url(category, filename) {
        if (!Object.prototype.hasOwnProperty.call(defaults, category)) return '';
        filename = String(filename || defaults[category]);
        if (!validName(filename)) filename = defaults[category];
        if (!active || /^default_/i.test(filename)) return base + '/uploads/' + category + '/' + encodeURIComponent(filename);
        if (cdn) return cdn + '/' + prefix.split('/').map(encodeURIComponent).join('/') + '/' + category + '/' + encodeURIComponent(filename);
        return base + '/api/photo.php?category=' + category + '&filename=' + encodeURIComponent(filename);
    }
    function resolve(value) {
        if (!active || !value || /^(?:data:|blob:|#)/i.test(value)) return value;
        try {
            const app = new URL(base + '/', location.href);
            const link = new URL(value, location.href);
            const path = app.pathname.replace(/\/$/, '') + '/uploads/';
            if (link.origin !== app.origin || !link.pathname.startsWith(path)) return value;
            const parts = link.pathname.slice(path.length).split('/');
            if (parts.length !== 2 || !Object.prototype.hasOwnProperty.call(defaults, parts[0])) return value;
            const filename = decodeURIComponent(parts[1]);
            if (!validName(filename) || /^default_/i.test(filename)) return value;
            return url(parts[0], filename);
        } catch (_) { return value; }
    }
    window.SchoolPhotos = Object.freeze({ url, resolve });
    document.addEventListener('error', event => {
        const image = event.target;
        if (!active || !cdn || !(image instanceof HTMLImageElement) || image.dataset.schoolPhotoFallback === '1') return;
        try {
            const failed = new URL(image.src, location.href);
            const publicBase = new URL(cdn + '/');
            if (failed.origin !== publicBase.origin || !failed.pathname.startsWith(publicBase.pathname)) return;
            const pieces = failed.pathname.split('/');
            const filename = decodeURIComponent(pieces.pop());
            const category = pieces.pop();
            if (!Object.prototype.hasOwnProperty.call(defaults, category) || !validName(filename)) return;
            const fallback = base + '/api/photo.php?category=' + category + '&filename=' + encodeURIComponent(filename);
            image.dataset.schoolPhotoFallback = '1';
            const link = image.closest('a');
            if (link) for (const attribute of ['href', 'data-src']) {
                if (new URL(link.getAttribute(attribute) || '', location.href).href === failed.href) link.setAttribute(attribute, fallback);
            }
            image.src = fallback;
        } catch (_) { /* unrelated/invalid image URL */ }
    }, true);
    // Handles older cached page scripts, AJAX fragments and Fancybox/lazy-load links.
    const attributes = ['src', 'href', 'data-src', 'data-lazy-src', 'data-original'];
    function update(element) {
        if (!(element instanceof Element)) return;
        for (const attr of attributes) {
            const before = element.getAttribute(attr);
            const after = resolve(before);
            if (after !== before) element.setAttribute(attr, after);
        }
    }
    function scan(root) {
        update(root);
        root.querySelectorAll?.('img,a,[data-src],[data-lazy-src],[data-original]').forEach(update);
    }
    new MutationObserver(records => {
        for (const record of records) {
            if (record.type === 'attributes') update(record.target);
            else record.addedNodes.forEach(node => { if (node instanceof Element) scan(node); });
        }
    }).observe(document.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: attributes });
    scan(document.documentElement);
})();
