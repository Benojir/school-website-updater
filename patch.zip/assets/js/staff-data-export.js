function initStaffDataExport(getSelectedIds) {
    const modal = document.getElementById('staffExportModal');
    const form = document.getElementById('staffExportForm');
    const checkboxes = Array.from(modal.querySelectorAll('.staff-export-column'));
    let order = checkboxes.filter(box => box.checked).map(box => box.value);
    function updateOrder() {
        document.getElementById('staffExportColumnOrder').value = order.join(',');
        document.getElementById('staffExportOrderPreview').textContent = order.map((key, index) => {
            const box = checkboxes.find(item => item.value === key);
            return `${index + 1}. ${box.labels[0].textContent.trim()}`;
        }).join(' → ') || 'No columns selected';
    }
    function updateSelection() {
        const ids = getSelectedIds();
        document.getElementById('staffExportIds').value = ids.join(',');
        document.getElementById('staffExportSelectionCount').textContent = `${ids.length} selected`;
        if (!ids.length) {
            toastr.warning('Please select at least one person to export.');
            return false;
        }
        return true;
    }
    checkboxes.forEach(box => box.addEventListener('change', () => {
        order = order.filter(key => key !== box.value);
        if (box.checked) order.push(box.value);
        updateOrder();
    }));
    // Listen through jQuery to match Bootstrap's namespaced modal event bridge.
    $('#staffExportModal').on('show.bs.modal', event => {
        if (!updateSelection()) event.preventDefault();
        updateOrder();
    });
    form.addEventListener('submit', event => {
        if (!updateSelection()) { event.preventDefault(); return; }
        if (!order.length) {
            event.preventDefault();
            toastr.warning('Please select at least one export column.');
        }
        updateOrder();
    });
    updateOrder();
}
