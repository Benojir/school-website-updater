(() => {
    'use strict';
    document.querySelectorAll('form[data-contact-form]').forEach(form => {
        const button = form.querySelector('button[type="submit"]');
        const feedback = form.querySelector('[data-contact-feedback]');
        const widget = form.querySelector('.contact-turnstile');
        let widgetId = null;
        let sending = false;
        const show = (message, success = false) => {
            feedback.textContent = message;
            feedback.className = `alert alert-${success ? 'success' : 'danger'}`;
            feedback.focus({preventScroll: true});
        };
        if (!widget) button.disabled = true;
        const initCaptcha = (attempt = 0) => {
            if (!widget) return;
            if (!window.turnstile) {
                if (attempt < 100) setTimeout(() => initCaptcha(attempt + 1), 200);
                else show('Captcha could not load. Check your connection and reload the page.');
                return;
            }
            try {
                widgetId = window.turnstile.render(widget, {
                    sitekey: widget.dataset.sitekey, action: 'contact_message', size: 'flexible',
                    'error-callback': () => {
                        show('Captcha could not be verified. Please try the captcha again.');
                    },
                    'expired-callback': () => {
                        if (!sending) show('Captcha expired. Please verify again before sending.');
                    }
                });
            } catch (error) {
                show('Captcha could not load. Please reload the page and try again.');
            }
        };
        initCaptcha();
        form.addEventListener('submit', async event => {
            event.preventDefault();
            if (sending || !form.reportValidity()) return;
            const data = new FormData(form);
            if (!widget || !data.get('cf-turnstile-response')) {
                show('Please complete the captcha verification before sending.');
                return;
            }
            sending = true;
            button.disabled = true;
            form.setAttribute('aria-busy', 'true');
            const label = button.textContent;
            button.textContent = 'Sending...';
            feedback.classList.add('d-none');
            try {
                const response = await fetch(form.action, {
                    method: 'POST', body: data, credentials: 'same-origin',
                    headers: {'Accept': 'application/json'}
                });
                const result = await response.json();
                if (!response.ok || result.success !== true) {
                    throw new Error(result.message || 'Your message could not be sent. Please try again.');
                }
                form.reset();
                show(result.message, true);
            } catch (error) {
                show(error instanceof SyntaxError || error instanceof TypeError
                    ? 'Unable to send your message. Please check your connection and try again.'
                    : error.message);
            } finally {
                // Turnstile tokens are single use, including when storage fails after verification.
                sending = false;
                button.disabled = false;
                button.textContent = label;
                form.removeAttribute('aria-busy');
                if (window.turnstile && widgetId !== null) {
                    try { window.turnstile.reset(widgetId); } catch (error) {
                        show('Please reload the page to verify the captcha again.');
                    }
                }
            }
        });
    });
})();
