(function (root) {
    'use strict';

    const number = value => /^\d+(\.\d*)?$/.test(String(value)) ? String(Number(value)) : String(value);
    const sameMarks = (a, b) => !!a && !!b && number(a.written) === number(b.written)
        && number(a.oral) === number(b.oral) && a.absent === b.absent && a.excluded === b.excluded;
    const sameContext = (a, b) => sameMarks(a, b) && number(a.maxWritten) === number(b.maxWritten)
        && number(a.maxOral) === number(b.maxOral) && a.excludeLocked === b.excludeLocked;
    const validState = value => value && ['written', 'oral', 'maxWritten', 'maxOral'].every(k => typeof value[k] === 'string')
        && ['absent', 'excluded', 'excludeLocked'].every(k => typeof value[k] === 'boolean');

    class Store {
        constructor(storage, scope, onError = () => {}) {
            this.storage = storage;
            this.prefix = 'school-mark-draft:v1:' + JSON.stringify(scope);
            this.onError = onError;
            this.exam = '';
        }
        access(action, fallback) {
            try { return action(this.storage()); }
            catch (error) { this.onError(error); return fallback; }
        }
        key(id) { return this.prefix + ':' + JSON.stringify([this.exam, id]); }
        select(exam) {
            this.exam = String(exam);
            if (exam) this.access(storage => storage.setItem(this.prefix + ':last-exam', this.exam));
        }
        lastExam() { return this.access(storage => storage.getItem(this.prefix + ':last-exam'), ''); }
        read(id) {
            return this.access(storage => {
                const raw = storage.getItem(this.key(id));
                if (!raw) return null;
                const record = JSON.parse(raw);
                if (record.version !== 1 || !validState(record.base) || !validState(record.value) || typeof record.token !== 'string') {
                    throw new Error('Unreadable mark draft');
                }
                return record;
            }, null);
        }
        write(id, base, value) {
            const record = {version: 1, base, value, updatedAt: Date.now(), token: Date.now() + ':' + Math.random()};
            return this.access(storage => { storage.setItem(this.key(id), JSON.stringify(record)); return record; }, null);
        }
        remove(id, expected) {
            // A response from an older tab/request must not erase a newer draft.
            return this.access(storage => {
                const raw = storage.getItem(this.key(id));
                if (raw && expected && JSON.parse(raw).token === expected.token) storage.removeItem(this.key(id));
            });
        }
    }

    function attach(options) {
        const {form, status, reviewButton, discardButton} = options;
        const cells = new Map(), base = new Map(), drafts = new Map(), pending = new Map(), corrections = new Set();
        let ready = false, saving = false, storageFailed = false;
        const store = new Store(options.storage || (() => root.localStorage), options.scope, () => {
            storageFailed = true;
            render();
        });
        form.querySelectorAll('tbody td[data-subject-id]').forEach(cell => {
            const written = cell.querySelector('.theory-marks');
            const match = written.name.match(/^students\[([^\]]+)\]\[subjects\]\[([^\]]+)\]/);
            if (match) cells.set(JSON.stringify([match[1], match[2]]), cell);
        });
        function state(cell) {
            const written = cell.querySelector('.theory-marks'), oral = cell.querySelector('.practical-marks');
            const excluded = cell.querySelector('input[name^="exclude["]');
            return {written: written.value, oral: oral.value,
                absent: cell.querySelector('input[name^="absent["]').checked, excluded: excluded.checked,
                maxWritten: written.getAttribute('max') || '', maxOral: oral.getAttribute('max') || '',
                excludeLocked: excluded.disabled};
        }
        function apply(cell, value, current) {
            const blocked = value.absent || value.excluded;
            cell.querySelector('input[name^="absent["]').checked = value.absent;
            const excluded = cell.querySelector('input[name^="exclude["]');
            excluded.checked = value.excluded;
            excluded.disabled = current.excludeLocked;
            cell.querySelector('input[name^="absent["]').disabled = false;
            for (const [selector, key] of [['.theory-marks', 'written'], ['.practical-marks', 'oral']]) {
                const input = cell.querySelector(selector);
                input.value = blocked ? '0' : value[key];
                input.disabled = blocked;
                input.readOnly = false;
                const invalid = !blocked && input.value !== '' && (!/^\d+(\.\d*)?$/.test(input.value) || Number(input.value) > Number(input.max));
                input.classList.toggle('is-invalid', invalid);
                input.style.backgroundColor = invalid ? '#FF7777' : '';
            }
            const obtained = cell.querySelector('.obtained-marks');
            obtained.value = blocked ? '0' : ((parseFloat(value.written) || 0) + (parseFloat(value.oral) || 0)).toFixed(2);
            obtained.disabled = blocked;
        }
        function checkRecovered(id) {
            const cell = cells.get(id);
            const invalid = ['.theory-marks', '.practical-marks'].some(selector => {
                const input = cell.querySelector(selector);
                return !input.disabled && input.value !== ''
                    && (!/^\d+(\.\d*)?$/.test(input.value) || Number(input.value) > Number(input.max));
            });
            invalid ? corrections.add(id) : corrections.delete(id);
        }
        function render() {
            if (storageFailed) {
                status.textContent = 'Browser draft storage is unavailable or full. Keep this tab open until marks are saved to the server.';
            } else if (pending.size) {
                status.textContent = pending.size + ' draft entries need review because saved marks or exam settings changed. Your draft is still kept in this browser.';
            } else if (corrections.size) {
                status.textContent = 'Draft restored. Correct the highlighted marks to fit the current full marks before saving. Your entries are kept in this browser.';
            } else if (drafts.size) {
                status.textContent = drafts.size + ' unsaved subject entries kept in this browser. Refreshing or closing this tab will not remove them. Click Save All Results to save to the server.';
            } else {
                status.textContent = ready ? 'Draft protection is on. Changes are kept in this browser as you type.' : 'Select/load an exam to recover its drafts. Drafts are kept separately for each exam in this browser.';
            }
            status.parentElement.classList.toggle('alert-warning', storageFailed || pending.size > 0 || corrections.size > 0);
            status.parentElement.classList.toggle('alert-info', !storageFailed && pending.size === 0 && corrections.size === 0);
            reviewButton.hidden = pending.size === 0;
            discardButton.hidden = drafts.size === 0;
            reviewButton.disabled = discardButton.disabled = !ready || saving;
        }
        function freeze(id, record) {
            pending.set(id, record);
            cells.get(id).querySelectorAll('input').forEach(input => { if (input.type !== 'hidden') input.disabled = true; });
        }
        function capture(cell) {
            if (!ready || saving || !cell) return;
            const entry = Array.from(cells).find(([, node]) => node === cell);
            if (!entry) return;
            const [id] = entry;
            if (pending.has(id)) return;
            const value = state(cell), previous = drafts.get(id);
            if (corrections.has(id)) checkRecovered(id);
            if (sameMarks(base.get(id), value)) {
                store.remove(id, previous);
                drafts.delete(id);
            } else {
                const record = store.write(id, base.get(id), value);
                // Retain the entered values in memory even if browser storage is blocked.
                drafts.set(id, record || {base: base.get(id), value, token: ''});
            }
            render();
        }
        function loaded() {
            ready = true;
            cells.forEach((cell, id) => {
                const current = state(cell);
                base.set(id, current);
                const record = store.read(id);
                if (!record) return;
                if (sameMarks(record.value, current)) { store.remove(id, record); return; }
                drafts.set(id, record);
                if (sameContext(record.base, current)) { apply(cell, record.value, current); checkRecovered(id); }
                else freeze(id, record);
            });
            render();
        }
        const escape = text => String(text).replace(/[&<>"']/g, char => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[char]));
        const describe = value => 'Written: ' + value.written + ', Oral: ' + value.oral + (value.absent ? ' · Absent' : '') + (value.excluded ? ' · Excluded' : '');
        reviewButton.addEventListener('click', async () => {
            if (!ready || saving) return;
            const reviewingExam = store.exam;
            const entries = Array.from(pending);
            const html = entries.map(([id, record]) => {
                const cell = cells.get(id), current = base.get(id);
                const student = cell.closest('tr').querySelector('td').textContent.trim();
                const subject = options.subjectName(cell.dataset.subjectId);
                return '<div class="border-bottom mb-2 pb-2 text-start"><strong>' + escape(student) + ' — ' + escape(subject)
                    + '</strong><br>Server: ' + escape(describe(current)) + '<br>Draft: ' + escape(describe(record.value))
                    + (current.excludeLocked && current.excluded !== record.value.excluded ? '<br><b>Exclusion is locked. This draft will remain for reference.</b>' : '') + '</div>';
            }).join('');
            const result = await root.Swal.fire({title: 'Review recovered drafts', html: '<p>Restore only after reviewing these differences. Current full marks and exclusion rules still apply.</p><div style="max-height:50vh;overflow:auto">' + html + '</div>',
                showCancelButton: true, confirmButtonText: 'Restore for review', cancelButtonText: 'Keep for later'});
            if (!result.isConfirmed || store.exam !== reviewingExam || !ready || saving) return;
            entries.forEach(([id, record]) => {
                const current = base.get(id), latest = store.read(id);
                if (!latest || latest.token !== record.token || (current.excludeLocked && current.excluded !== record.value.excluded)) return;
                const value = {...record.value, maxWritten: current.maxWritten, maxOral: current.maxOral, excludeLocked: current.excludeLocked};
                apply(cells.get(id), value, current);
                checkRecovered(id);
                pending.delete(id);
                const updated = store.write(id, current, value);
                drafts.set(id, updated || {...record, base: current, value});
            });
            render();
        });
        discardButton.addEventListener('click', async () => {
            if (!ready || saving) return;
            const discardingExam = store.exam, entries = Array.from(drafts);
            const result = await root.Swal.fire({title: 'Discard these drafts?', text: 'Unsaved entries for the displayed students in this exam will be removed from this browser. The loaded server marks will be shown.',
                icon: 'warning', showCancelButton: true, confirmButtonText: 'Discard drafts', cancelButtonText: 'Keep editing'});
            if (!result.isConfirmed || store.exam !== discardingExam || !ready || saving) return;
            entries.forEach(([id, record]) => {
                const latest = store.read(id);
                if (latest && latest.token !== record.token) return;
                store.remove(id, record); drafts.delete(id); pending.delete(id); corrections.delete(id);
                apply(cells.get(id), base.get(id), base.get(id));
            });
            render();
        });
        root.addEventListener('beforeunload', event => {
            if (drafts.size || saving) { event.preventDefault(); event.returnValue = ''; }
        });
        render();
        return {
            lastExam: () => store.lastExam(),
            currentExam: () => store.exam,
            canLeave: () => !storageFailed || drafts.size === 0,
            begin(exam) {
                ready = false; base.clear(); drafts.clear(); pending.clear(); corrections.clear(); store.select(exam); render();
            },
            loaded, capture,
            canSubmit() { return ready && pending.size === 0 && corrections.size === 0; },
            setSaving(value) { saving = value; render(); },
            snapshot(rows) {
                const selected = new Set(rows);
                return Array.from(cells).filter(([, cell]) => selected.has(cell.closest('tr')))
                    .map(([id, cell]) => ({id, value: state(cell), record: drafts.get(id)}));
            },
            acknowledge(entries) {
                entries.forEach(({id, value, record}) => {
                    base.set(id, value);
                    if (sameMarks(state(cells.get(id)), value)) {
                        store.remove(id, record); drafts.delete(id);
                    }
                });
                render();
            }
        };
    }
    root.MarkEntryDrafts = {Store, sameMarks, sameContext, attach};
    if (typeof module !== 'undefined' && module.exports) module.exports = root.MarkEntryDrafts;
})(typeof window !== 'undefined' ? window : globalThis);
