$(document).ready(function () {

    $(document).on('show.bs.modal', '.modal', function () {
        // Close all other open modals
        $('.modal.show').not(this).modal('hide');
    });

    // Run this once (after Swal, jQuery, and Bootstrap are loaded)
    (function () {
        if (!window.Swal) return;

        const _origSwal = Swal.fire;

        Swal.fire = function () {
            // Close any open bootstrap modal(s) using jQuery
            try {
                $('.modal.show').modal('hide');
            } catch (e) {
                // ignore if jQuery/bootstrap not available
                console.warn('Could not hide Bootstrap modals automatically:', e);
            }

            // Normalize args into params object so we preserve original API
            let params;
            if (arguments.length === 0) {
                params = {};
            } else if (typeof arguments[0] === 'object') {
                params = Object.assign({}, arguments[0]);
            } else {
                // Swal.fire(title, htmlOrText, icon) style
                params = { title: arguments[0] };
                if (arguments[1] !== undefined) params.html = arguments[1];
                if (arguments[2] !== undefined) params.icon = arguments[2];
            }

            // Preserve user's didOpen callback while ensuring modals are closed
            const userDidOpen = params.didOpen;
            params.didOpen = function (popup) {
                // Ensure focus goes to Swal input if any
                if (userDidOpen) try { userDidOpen.call(this, popup); } catch (err) { console.error(err); }
                const input = Swal.getInput && Swal.getInput();
                if (input && typeof input.focus === 'function') input.focus();
            };

            // Call original Swal.fire with our prepared params
            return _origSwal.call(this, params);
        };
    })();

    // Bootstrap Multiselect
    $('.custom-multiselect').multiselect({
        templates: {
            button: '<button type="button" class="multiselect dropdown-toggle form-select" style="text-align: left !important;" data-bs-toggle="dropdown" aria-expanded="false"><span class="multiselect-selected-text"></span></button>',

            // 1. Wrapped in <li> to match the dropdown list structure
            // 2. Added 'p-2' (padding) to give it some breathing room from the edges
            filter: '<li class="multiselect-item filter"><div class="input-group p-2"><span class="input-group-text"><i class="fas fa-search"></i></span><input type="text" class="form-control multiselect-search" placeholder="Search..."><span class="input-group-text" style="cursor:pointer;"><i class="fas fa-times multiselect-clear-filter"></i></span></div></li>',
        },
        buttonWidth: '100%',
        includeSelectAllOption: true,
        nonSelectedText: 'Select option(s)',
        enableCaret: false,

        // Search settings
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        maxHeight: 300
    });
});