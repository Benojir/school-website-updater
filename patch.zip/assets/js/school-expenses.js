(() => {
    'use strict';
    const app = document.getElementById('schoolExpensesApp');
    if (!app) return;
    const config = window.schoolExpensesConfig;
    const byId = id => document.getElementById(id);
    const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[char]));
    const state = {categories: [], rows: new Map(), applied: null, page: 1, report: null, controller: null,
        loading: false, saving: false, categorySaving: false, inlineSaving: false, exporting: false,
        requestKey: '', categoryKey: '', inlineKey: '', editing: null, previewUrl: null, expandBreakdown: false, detailController: null};
    const money = value => {
        const paise = BigInt(value ?? 0);
        return config.currency + new Intl.NumberFormat('en-IN').format(paise / 100n) + '.' + String(paise % 100n).padStart(2, '0');
    };
    const decimal = value => {
        const paise = BigInt(value);
        return String(paise / 100n) + '.' + String(paise % 100n).padStart(2, '0');
    };
    const dateText = value => {
        if (!value) return '—';
        const parts = value.slice(0, 10).split('-').map(Number);
        return new Intl.DateTimeFormat('en-GB', {day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC'}).format(new Date(Date.UTC(parts[0], parts[1] - 1, parts[2])));
    };
    const timestamp = value => value ? dateText(value) + ' · ' + value.slice(11, 16) : '—';
    const billUrl = value => {
        try {
            const url = new URL(value);
            return url.protocol === 'https:' && ['i.ibb.co', 'ibb.co'].includes(url.hostname) && !url.username && !url.password ? url.href : '';
        } catch (_) { return ''; }
    };
    const key = () => crypto.randomUUID();
    const modal = id => bootstrap.Modal.getOrCreateInstance(byId(id));
    const error = (id, message) => {
        const element = byId(id);
        element.textContent = message;
        element.classList.toggle('d-none', !message);
    };
    const notify = (message, kind = 'success', source = 'general') => {
        const notice = byId('expensesNotice');
        notice.className = 'alert alert-' + kind;
        notice.dataset.source = source;
        notice.textContent = message;
    };
    const confirmAction = async (title, text, label) => {
        if (window.Swal) return (await Swal.fire({title, text, icon: 'warning', showCancelButton: true,
            confirmButtonText: label, confirmButtonColor: '#b42318', cancelButtonText: 'Cancel'})).isConfirmed;
        return window.confirm(title + '\n' + text);
    };
    const urlFor = (action, filters = {}) => {
        const url = new URL(config.api, location.href);
        url.searchParams.set('action', action);
        Object.entries(filters).forEach(([name, value]) => url.searchParams.set(name, String(value)));
        return url;
    };
    async function request(action, params = {}, body = null, signal = null) {
        const response = await fetch(urlFor(action, body ? {} : params), {
            method: body ? 'POST' : 'GET', credentials: 'same-origin', signal,
            headers: body ? {'Accept': 'application/json', 'X-CSRF-Token': config.csrf} : {'Accept': 'application/json'}, body
        });
        let result;
        try { result = await response.json(); } catch (_) { throw new Error('The server could not complete this request. Refresh or retry the same form.'); }
        if (!response.ok || result.success !== true) throw new Error(result.message || 'The request could not be completed.');
        return result.data;
    }
    const mutation = async (action, fields, requestKey) => {
        const body = fields instanceof FormData ? fields : new FormData();
        if (!(fields instanceof FormData)) Object.entries(fields).forEach(([name, value]) => body.set(name, String(value)));
        body.set('action', action);
        body.set('request_key', requestKey);
        return request(action, {}, body);
    };
    const messageFor = err => err instanceof TypeError ? 'Connection interrupted. Retry the same form, or refresh the list to check whether it was saved.' : err.message;
    const setFormBusy = (form, busy) => form.querySelectorAll('button, input, select, textarea').forEach(element => { element.disabled = busy; });
    function setDate(id, value) {
        const input = byId(id);
        if (input._flatpickr) value ? input._flatpickr.setDate(value, false) : input._flatpickr.clear(false);
        else input.value = value;
    }
    function markPeriod(period) {
        app.querySelectorAll('[data-expense-period]').forEach(button => {
            const active = button.dataset.expensePeriod === period;
            button.classList.toggle('active', active);
            button.setAttribute('aria-pressed', String(active));
        });
    }
    function preset(period) {
        let from = '', to = '';
        if (period === 'month') { from = config.monthStart; to = config.today; }
        if (period === 'year') { from = config.today.slice(0, 4) + '-01-01'; to = config.today; }
        if (period === 'last-month') {
            const year = Number(config.today.slice(0, 4)), month = Number(config.today.slice(5, 7)) - 1;
            from = new Date(Date.UTC(year, month - 1, 1)).toISOString().slice(0, 10);
            to = new Date(Date.UTC(year, month, 0)).toISOString().slice(0, 10);
        }
        setDate('expenseFrom', from); setDate('expenseTo', to); markPeriod(period);
    }
    function currentFilters() {
        return {from: byId('expenseFrom').value.trim(), to: byId('expenseTo').value.trim(),
            category_id: byId('expenseCategoryFilter').value || '0', search: byId('expenseSearch').value.trim(),
            sort: byId('expenseSort').value, per_page: byId('expensePageSize').value};
    }
    function filtersValid(filters) {
        for (const value of [filters.from, filters.to]) {
            if (value && (!/^\d{4}-\d{2}-\d{2}$/.test(value) || value < '1900-01-01' ||
                Number.isNaN(Date.parse(value + 'T00:00:00Z')) || new Date(value + 'T00:00:00Z').toISOString().slice(0, 10) !== value)) {
                notify('Choose valid From and To dates in YYYY-MM-DD format.', 'danger', 'report'); return false;
            }
        }
        if (filters.from && filters.to && filters.from > filters.to) {
            notify('From date must be on or before To date.', 'danger', 'report'); return false;
        }
        return true;
    }
    function renderCategoryOptions() {
        const filterValue = byId('expenseCategoryFilter').value;
        const selected = byId('expenseCategory').value;
        byId('expenseCategoryFilter').innerHTML = '<option value="0">All categories</option>' + state.categories.map(category =>
            `<option value="${category.id}">${escape(category.name)}${category.is_active ? '' : ' (archived)'}</option>`).join('');
        byId('expenseCategoryFilter').value = filterValue || '0';
        byId('expenseCategory').innerHTML = '<option value="">Choose a category</option>' + state.categories
            .filter(category => category.is_active || category.id === state.editing?.category_id)
            .map(category => `<option value="${category.id}">${escape(category.name)}${category.is_active ? '' : ' (archived)'}</option>`).join('');
        byId('expenseCategory').value = selected;
    }
    function renderCategories() {
        const search = byId('expenseCategorySearch').value.trim().toLocaleLowerCase();
        const categories = state.categories.filter(category => category.name.toLocaleLowerCase().includes(search));
        byId('expenseCategoryList').innerHTML = categories.length ? categories.map(category => `
            <div class="expenses-category-row">
                <div><strong>${escape(category.name)}</strong><small>${category.expense_count} recorded expense${category.expense_count === 1 ? '' : 's'}</small>
                    ${category.is_active ? '' : '<span class="expenses-tag muted">Archived</span>'}</div>
                <div class="expenses-category-actions"><button type="button" class="btn btn-sm btn-outline-secondary" data-category-edit="${category.id}">Edit</button>
                    <button type="button" class="btn btn-sm ${category.is_active ? 'btn-outline-danger' : 'btn-outline-primary'}" data-category-status="${category.id}">${category.is_active ? 'Archive' : 'Restore'}</button></div>
            </div>`).join('') : '<div class="expenses-empty">' + (search ? 'No categories match your search.' : 'Create your first category to start recording expenses.') + '</div>';
    }
    async function loadCategories() {
        const data = await request('categories');
        state.categories = data.categories;
        renderCategoryOptions(); renderCategories();
    }
    function renderBreakdown() {
        const groups = state.report?.breakdown || [];
        const total = BigInt(state.report?.summary.total_paise || 0);
        byId('toggleExpenseBreakdown').classList.toggle('d-none', groups.length <= 6);
        byId('toggleExpenseBreakdown').textContent = state.expandBreakdown ? 'Show less' : 'Show all (' + groups.length + ')';
        byId('expenseBreakdown').innerHTML = groups.length ? (state.expandBreakdown ? groups : groups.slice(0, 6)).map(group => {
            const share = total ? Number(BigInt(group.total_paise) * 10000n / total) / 100 : 0;
            return `<div class="expenses-breakdown-item"><div><span>${escape(group.category_name)}</span><strong>${escape(money(group.total_paise))}</strong></div>
                <div class="expenses-bar" role="img" aria-label="${escape(group.category_name)}: ${share}% of spending"><span style="width:${share}%"></span></div>
                <small>${group.entry_count} expense${group.entry_count === 1 ? '' : 's'} · ${share}%</small></div>`;
        }).join('') : '<p class="text-muted mb-0">No expenses in this period. Try a different date range or add an expense.</p>';
    }
    function renderReport(data) {
        if (byId('expensesNotice').dataset.source === 'report') byId('expensesNotice').classList.add('d-none');
        state.report = data; state.page = data.page;
        state.applied = {...data.filters, per_page: data.per_page};
        state.rows = new Map(data.rows.map(row => [Number(row.id), row]));
        const summary = data.summary;
        byId('expenseTotal').textContent = money(summary.total_paise);
        byId('expenseCount').textContent = new Intl.NumberFormat('en-IN').format(summary.entry_count);
        byId('expenseLargest').textContent = money(summary.largest_paise);
        byId('expenseReceiptCount').textContent = summary.receipt_count + ' with a bill image';
        const from = state.applied.from, to = state.applied.to;
        const category = state.categories.find(item => item.id === Number(state.applied.category_id));
        byId('expenseAppliedFilters').textContent = 'Applied: ' + (from && to ? dateText(from) + ' – ' + dateText(to) : from ? 'From ' + dateText(from) : to ? 'Until ' + dateText(to) : 'All dates') +
            ' · ' + (category?.name || 'All categories') + (state.applied.search ? ' · Search: ' + state.applied.search : '');
        const start = summary.entry_count ? (data.page - 1) * data.per_page + 1 : 0;
        const end = summary.entry_count ? start + data.rows.length - 1 : 0;
        byId('expenseResultsSummary').textContent = `Showing ${start}–${end} of ${summary.entry_count} expenses`;
        byId('expenseRows').innerHTML = data.rows.length ? data.rows.map(row => `
            <tr class="expense-record">
                <td data-label="Date" class="expenses-date-cell">${escape(dateText(row.expense_date))}<small>#${row.id}</small></td>
                <td data-label="Category" class="expenses-category-cell"><strong>${escape(row.category_name)}</strong>${Number(row.category_active) ? '' : '<span class="expenses-tag muted">Archived category</span>'}</td>
                <td data-label="Amount" class="expenses-amount-cell">${escape(money(row.amount_paise))}</td>
                <td data-label="Paid to / place">${escape(row.payee || '—')}</td>
                <td data-label="Note" class="expenses-note-cell"><div class="expenses-note">${escape(row.note || '—')}</div></td>
                <td data-label="Bill">${billUrl(row.bill_url) ? `<a class="expenses-bill-link" href="${escape(billUrl(row.bill_url))}" target="_blank" rel="noopener noreferrer"><i class="fas fa-image me-1" aria-hidden="true"></i>View bill</a>` : '<span class="text-muted">No bill</span>'}</td>
                <td class="expenses-actions-cell"><div><button type="button" class="btn btn-sm btn-outline-primary" data-expense-detail="${row.id}" aria-label="View expense ${row.id}">View</button><button type="button" class="btn btn-sm btn-outline-secondary" data-expense-edit="${row.id}" aria-label="Edit expense ${row.id}">Edit</button><button type="button" class="btn btn-sm btn-outline-danger" data-expense-remove="${row.id}" aria-label="Remove expense ${row.id}"><i class="fas fa-trash-can" aria-hidden="true"></i></button></div></td>
            </tr>`).join('') : '<tr class="expenses-state-row"><td colspan="7"><div class="expenses-empty"><i class="fas fa-receipt fa-2x mb-3" aria-hidden="true"></i><h3>No expenses found</h3><p>Try another date range or category, clear your search, or add your first expense.</p></div></td></tr>';
        renderBreakdown();
        const pages = [];
        if (data.pages > 1) {
            pages.push(`<button type="button" class="btn btn-outline-secondary" data-expense-page="${data.page - 1}" ${data.page === 1 ? 'disabled' : ''} aria-label="Previous expense page"><i class="fas fa-chevron-left" aria-hidden="true"></i></button>`);
            for (let i = Math.max(1, data.page - 2); i <= Math.min(data.pages, data.page + 2); i++) {
                pages.push(`<button type="button" class="btn ${i === data.page ? 'btn-primary' : 'btn-outline-secondary'}" data-expense-page="${i}" ${i === data.page ? 'aria-current="page"' : ''} aria-label="Expense page ${i}">${i}</button>`);
            }
            pages.push(`<button type="button" class="btn btn-outline-secondary" data-expense-page="${data.page + 1}" ${data.page === data.pages ? 'disabled' : ''} aria-label="Next expense page"><i class="fas fa-chevron-right" aria-hidden="true"></i></button>`);
        }
        byId('expensePagination').innerHTML = summary.entry_count ? `<span>Page ${data.page} of ${data.pages}</span><div>${pages.join('')}</div>` : '';
    }
    async function loadReport(page = 1, filters = currentFilters()) {
        if (!filtersValid(filters)) return;
        state.controller?.abort();
        const controller = new AbortController(); state.controller = controller; state.loading = true;
        byId('expenseResults').setAttribute('aria-busy', 'true'); byId('expenseSummary').setAttribute('aria-busy', 'true');
        byId('exportExpenses').disabled = true;
        ['expenseTotal', 'expenseCount', 'expenseLargest', 'expenseReceiptCount'].forEach(id => { byId(id).textContent = '—'; });
        byId('expenseResultsSummary').textContent = 'Loading expenses…';
        byId('expenseRows').innerHTML = '<tr class="expenses-state-row"><td colspan="7" class="text-center py-5"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading expenses…</span></div></td></tr>';
        byId('expenseBreakdown').textContent = 'Loading category totals…'; byId('expensePagination').innerHTML = '';
        try {
            const data = await request('report', {...filters, page}, null, controller.signal);
            if (state.controller === controller) renderReport(data);
        } catch (err) {
            if (err.name === 'AbortError' || state.controller !== controller) return;
            state.report = null;
            byId('expenseResultsSummary').textContent = 'Expenses could not be loaded.';
            byId('expenseBreakdown').textContent = 'Category totals are unavailable.';
            byId('expenseRows').innerHTML = '<tr class="expenses-state-row"><td colspan="7"><div class="expenses-empty"><h3>Unable to load expenses</h3><p>Check your connection and try again.</p><button type="button" class="btn btn-outline-primary" id="retryExpenseReport">Try again</button></div></td></tr>';
            notify(messageFor(err), 'danger', 'report');
        } finally {
            if (state.controller === controller) {
                state.loading = false;
                byId('expenseResults').setAttribute('aria-busy', 'false'); byId('expenseSummary').setAttribute('aria-busy', 'false');
                byId('exportExpenses').disabled = state.exporting || !state.report?.summary.entry_count;
            }
        }
    }
    function clearPreview() {
        if (state.previewUrl) URL.revokeObjectURL(state.previewUrl);
        state.previewUrl = null; byId('expenseBillPreview').innerHTML = ''; byId('expenseBillPreview').classList.add('d-none');
    }
    function showBillPreview(url, caption) {
        byId('expenseBillPreview').innerHTML = `<img src="${escape(url)}" alt="${escape(caption)}"><span>${escape(caption)}</span>`;
        byId('expenseBillPreview').classList.remove('d-none');
    }
    function openExpense(row = null) {
        const form = byId('expenseForm'); form.reset(); clearPreview(); state.editing = row; state.requestKey = key(); state.inlineKey = key();
        error('expenseFormError', ''); byId('inlineExpenseCategoryError').textContent = ''; byId('inlineExpenseCategory').classList.add('d-none');
        byId('expenseModalTitle').textContent = row ? 'Edit expense #' + row.id : 'Add expense';
        form.elements.id.value = row?.id || 0; form.elements.version.value = row?.version || 0;
        renderCategoryOptions(); byId('expenseCategory').value = row?.category_id || '';
        byId('expenseAmount').value = row ? decimal(row.amount_paise) : '';
        setDate('expenseDate', row?.expense_date || config.today);
        byId('expensePayee').value = row?.payee || ''; byId('expenseNote').value = row?.note || '';
        const bill = billUrl(row?.bill_url); byId('expenseRemoveBillWrap').classList.toggle('d-none', !bill);
        if (bill) showBillPreview(bill, 'Current bill — choose a file above to replace it');
        byId('saveExpense').innerHTML = '<i class="fas fa-check me-2" aria-hidden="true"></i>' + (row ? 'Save changes' : 'Save expense');
        modal('expenseModal').show();
    }
    function resetCategoryForm() {
        const form = byId('expenseCategoryForm'); form.reset(); state.categoryKey = key();
        form.elements.id.value = 0; form.elements.version.value = 0;
        byId('expenseCategoryNameLabel').textContent = 'New category name'; byId('saveExpenseCategory').textContent = 'Create category';
        byId('cancelExpenseCategoryEdit').classList.add('d-none'); error('expenseCategoryError', '');
    }
    function historyValue(field, value) {
        if (field === 'amount_paise') return escape(money(value));
        if (field === 'expense_date') return escape(dateText(value));
        if (field === 'bill_url') return billUrl(value) ? `<a href="${escape(billUrl(value))}" target="_blank" rel="noopener noreferrer">View bill</a>` : 'No bill';
        return escape(value || '—');
    }
    function renderDetail(data) {
        const row = data.expense, bill = billUrl(row.bill_url);
        const labels = {category_name: 'Category', amount_paise: 'Amount', expense_date: 'Date', payee: 'Paid to / place', note: 'Note', bill_url: 'Bill'};
        byId('expenseDetailBody').innerHTML = `<div class="expenses-detail-heading"><div><h3>${escape(row.category_name)}</h3><span>${escape(dateText(row.expense_date))} · #${row.id}${row.deleted_at ? ' · Removed' : ''}</span></div><strong>${escape(money(row.amount_paise))}</strong></div>
            <dl class="expenses-detail-meta"><dt>Paid to / place</dt><dd>${escape(row.payee || 'Not specified')}</dd><dt>Recorded by</dt><dd>${escape(row.created_by_name)}</dd><dt>Recorded at</dt><dd>${escape(timestamp(row.created_at))}</dd><dt>Last updated</dt><dd>${escape(timestamp(row.updated_at))}</dd></dl>
            <h4 class="fs-6 mt-4">Why / what was this expense?</h4><p class="expenses-full-note">${escape(row.note || 'No note added.')}</p>
            <h4 class="fs-6 mt-4">Bill / receipt</h4>${bill ? `<a href="${escape(bill)}" target="_blank" rel="noopener noreferrer"><img class="expenses-detail-bill" src="${escape(bill)}" alt="Bill for ${escape(row.category_name)}" loading="lazy"></a>` : '<p class="text-muted">No bill image attached.</p>'}
            <h4 class="fs-6 mt-4">Change history</h4><div class="expenses-audit">${data.history.map(event => {
                const title = {created: 'Expense recorded', updated: 'Expense updated', removed: 'Expense removed'}[event.action_name] || 'Expense changed';
                const changes = Object.keys(labels).filter(field => String(event.before?.[field] ?? '') !== String(event.after[field] ?? ''));
                return `<details><summary><strong>${title}</strong><span>${escape(event.actor_name)} · ${escape(timestamp(event.created_at))}</span></summary>
                    ${changes.length ? '<dl>' + changes.map(field => `<dt>${labels[field]}</dt><dd>${event.before ? historyValue(field, event.before[field]) + ' → ' : ''}${historyValue(field, event.after[field])}</dd>`).join('') + '</dl>' : '<p>Removed from expense totals. The original record is retained.</p>'}</details>`;
            }).join('') || '<p class="text-muted">No changes recorded.</p>'}</div>`;
    }
    async function exportReport() {
        if (!state.applied || !state.report || state.exporting || state.loading) return;
        state.exporting = true; byId('exportExpenses').disabled = true;
        try {
            const response = await fetch(urlFor('export', state.applied), {credentials: 'same-origin'});
            if (!response.ok || !response.headers.get('Content-Type')?.includes('text/csv')) {
                const result = await response.json(); throw new Error(result.message || 'The report could not be downloaded.');
            }
            const url = URL.createObjectURL(await response.blob());
            const link = document.createElement('a'); link.href = url; link.download = 'school-expenses-' + config.today + '.csv';
            document.body.appendChild(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
        } catch (err) { notify(messageFor(err), 'danger'); }
        finally { state.exporting = false; byId('exportExpenses').disabled = state.loading || !state.report?.summary.entry_count; }
    }
    function start() {
        if (window.flatpickr) {
            app.querySelectorAll('.expense-date').forEach(input => flatpickr(input, {dateFormat: 'Y-m-d', allowInput: true, disableMobile: true,
                onChange: () => markPeriod('custom')}));
            flatpickr(byId('expenseDate'), {dateFormat: 'Y-m-d', allowInput: true, disableMobile: true, maxDate: config.today, minDate: '1900-01-01'});
        }
        preset('month'); state.categoryKey = key();
        byId('expenseFilters').addEventListener('submit', event => { event.preventDefault(); loadReport(); });
        ['expenseFrom', 'expenseTo'].forEach(id => byId(id).addEventListener('input', () => markPeriod('custom')));
        app.querySelectorAll('[data-expense-period]').forEach(button => button.addEventListener('click', () => { preset(button.dataset.expensePeriod); loadReport(); }));
        byId('resetExpenseFilters').addEventListener('click', () => { byId('expenseFilters').reset(); byId('expenseSort').value = 'date_desc'; preset('month'); loadReport(); });
        ['expenseSort', 'expensePageSize'].forEach(id => byId(id).addEventListener('change', () => loadReport(1, {...(state.applied || currentFilters()), sort: byId('expenseSort').value, per_page: byId('expensePageSize').value})));
        byId('toggleExpenseBreakdown').addEventListener('click', () => { state.expandBreakdown = !state.expandBreakdown; renderBreakdown(); });
        byId('exportExpenses').addEventListener('click', exportReport);
        byId('addExpense').addEventListener('click', () => openExpense());
        byId('expenseModal').addEventListener('hide.bs.modal', event => { if (state.saving || state.inlineSaving) event.preventDefault(); });
        byId('expenseModal').addEventListener('hidden.bs.modal', clearPreview);
        byId('expenseDetailModal').addEventListener('hidden.bs.modal', () => {
            state.detailController?.abort(); state.detailController = null;
        });
        byId('expenseModal').addEventListener('shown.bs.modal', () => byId('expenseCategory').focus());
        byId('showInlineExpenseCategory').addEventListener('click', () => { byId('inlineExpenseCategory').classList.toggle('d-none'); byId('inlineExpenseCategoryName').focus(); });
        byId('inlineExpenseCategoryName').addEventListener('keydown', event => {
            if (event.key === 'Enter') { event.preventDefault(); byId('saveInlineExpenseCategory').click(); }
        });
        byId('saveInlineExpenseCategory').addEventListener('click', async () => {
            if (state.inlineSaving || state.saving) return;
            const name = byId('inlineExpenseCategoryName').value.trim();
            if (!name) { byId('inlineExpenseCategoryError').textContent = 'Enter a category name.'; return; }
            state.inlineSaving = true; byId('saveInlineExpenseCategory').disabled = true; byId('saveExpense').disabled = true;
            try {
                const result = await mutation('category_save', {name, id: 0}, state.inlineKey);
                await loadCategories(); byId('expenseCategory').value = result.id;
                byId('inlineExpenseCategoryName').value = ''; byId('inlineExpenseCategory').classList.add('d-none');
                byId('inlineExpenseCategoryError').textContent = ''; state.inlineKey = key();
            } catch (err) { byId('inlineExpenseCategoryError').textContent = messageFor(err); }
            finally { state.inlineSaving = false; byId('saveInlineExpenseCategory').disabled = false; byId('saveExpense').disabled = false; }
        });
        byId('expenseBillImage').addEventListener('change', () => {
            clearPreview(); error('expenseFormError', '');
            const file = byId('expenseBillImage').files[0];
            if (!file) { if (billUrl(state.editing?.bill_url)) showBillPreview(billUrl(state.editing.bill_url), 'Current bill'); return; }
            if (file.size > 5 * 1024 * 1024 || !['image/jpeg', 'image/png', 'image/gif', 'image/webp'].includes(file.type)) {
                byId('expenseBillImage').value = ''; error('expenseFormError', 'Choose a JPG, PNG, GIF or WebP bill image up to 5 MB.'); return;
            }
            byId('expenseRemoveBill').checked = false;
            state.previewUrl = URL.createObjectURL(file); showBillPreview(state.previewUrl, 'New bill: ' + file.name);
        });
        byId('expenseRemoveBill').addEventListener('change', () => {
            if (byId('expenseRemoveBill').checked) { byId('expenseBillImage').value = ''; clearPreview(); }
            else if (billUrl(state.editing?.bill_url)) showBillPreview(billUrl(state.editing.bill_url), 'Current bill');
        });
        byId('expenseForm').addEventListener('submit', async event => {
            event.preventDefault(); if (state.saving || state.inlineSaving) return;
            const form = event.currentTarget; if (!form.reportValidity()) return;
            const body = new FormData(form); if (!body.get('remove_receipt')) body.set('remove_receipt', '0');
            state.saving = true; setFormBusy(form, true); error('expenseFormError', ''); byId('saveExpense').textContent = 'Saving…';
            try {
                const result = await mutation('expense_save', body, state.requestKey);
                const outside = state.applied && ((state.applied.from && String(body.get('date')) < state.applied.from) || (state.applied.to && String(body.get('date')) > state.applied.to));
                state.saving = false; modal('expenseModal').hide();
                notify(result.message + (outside ? ' This expense is outside the displayed date range.' : ''));
                await Promise.all([loadCategories(), loadReport(1, state.applied || currentFilters())]);
            } catch (err) { error('expenseFormError', messageFor(err)); }
            finally { state.saving = false; setFormBusy(form, false); byId('saveExpense').textContent = state.editing ? 'Save changes' : 'Save expense'; }
        });
        byId('manageExpenseCategories').addEventListener('click', () => { resetCategoryForm(); renderCategories(); modal('expenseCategoriesModal').show(); });
        byId('expenseCategoriesModal').addEventListener('hide.bs.modal', event => { if (state.categorySaving) event.preventDefault(); });
        byId('expenseCategorySearch').addEventListener('input', renderCategories);
        byId('cancelExpenseCategoryEdit').addEventListener('click', resetCategoryForm);
        byId('expenseCategoryForm').addEventListener('submit', async event => {
            event.preventDefault(); if (state.categorySaving) return;
            const form = event.currentTarget; if (!form.reportValidity()) return;
            const body = new FormData(form); state.categorySaving = true; setFormBusy(form, true); error('expenseCategoryError', '');
            try {
                const result = await mutation('category_save', body, state.categoryKey);
                await loadCategories(); resetCategoryForm(); notify(result.message); await loadReport(state.page, state.applied || currentFilters());
            } catch (err) { error('expenseCategoryError', messageFor(err)); }
            finally { state.categorySaving = false; setFormBusy(form, false); }
        });
        byId('expenseCategoryList').addEventListener('click', async event => {
            const edit = event.target.closest('[data-category-edit]'), status = event.target.closest('[data-category-status]');
            if (!edit && !status || state.categorySaving) return;
            const category = state.categories.find(item => item.id === Number((edit || status).dataset[edit ? 'categoryEdit' : 'categoryStatus']));
            if (!category) return;
            if (edit) {
                const form = byId('expenseCategoryForm'); state.categoryKey = key(); error('expenseCategoryError', '');
                form.elements.id.value = category.id; form.elements.version.value = category.version; byId('expenseCategoryName').value = category.name;
                byId('expenseCategoryNameLabel').textContent = 'Edit category name'; byId('saveExpenseCategory').textContent = 'Save changes';
                byId('cancelExpenseCategoryEdit').classList.remove('d-none'); byId('expenseCategoryName').focus(); return;
            }
            if (category.is_active && !await confirmAction('Archive this category?', category.name + ' will be hidden from new expense entries. Past expenses will stay in reports.', 'Archive category')) return;
            state.categorySaving = true; status.disabled = true;
            try {
                const result = await mutation('category_status', {id: category.id, version: category.version, is_active: category.is_active ? 0 : 1}, key());
                await loadCategories(); notify(result.message); await loadReport(state.page, state.applied || currentFilters());
            } catch (err) { error('expenseCategoryError', messageFor(err)); }
            finally { state.categorySaving = false; status.disabled = false; }
        });
        app.addEventListener('click', async event => {
            const page = event.target.closest('[data-expense-page]');
            if (page && !page.disabled) { await loadReport(Number(page.dataset.expensePage), state.applied); byId('expenseRecordsTitle').scrollIntoView({block: 'start'}); return; }
            if (event.target.closest('#retryExpenseReport')) { loadCategories().catch(err => notify(messageFor(err), 'danger')); loadReport(); return; }
            const edit = event.target.closest('[data-expense-edit]');
            if (edit) { const row = state.rows.get(Number(edit.dataset.expenseEdit)); if (row) openExpense(row); return; }
            const detail = event.target.closest('[data-expense-detail]');
            if (detail) {
                state.detailController?.abort();
                const controller = new AbortController(); state.detailController = controller;
                byId('expenseDetailBody').textContent = 'Loading expense details…'; modal('expenseDetailModal').show();
                try {
                    const data = await request('detail', {id: detail.dataset.expenseDetail}, null, controller.signal);
                    if (state.detailController === controller) renderDetail(data);
                } catch (err) {
                    if (err.name !== 'AbortError' && state.detailController === controller) byId('expenseDetailBody').textContent = messageFor(err);
                }
                return;
            }
            const remove = event.target.closest('[data-expense-remove]');
            if (remove && !remove.disabled) {
                const row = state.rows.get(Number(remove.dataset.expenseRemove)); if (!row) return;
                if (!await confirmAction('Remove this expense?', `${row.category_name} · ${money(row.amount_paise)} · ${dateText(row.expense_date)}. It will be excluded from totals; its history will be retained.`, 'Remove expense')) return;
                remove.disabled = true;
                try { const result = await mutation('expense_remove', {id: row.id, version: row.version}, key()); notify(result.message); await Promise.all([loadCategories(), loadReport(state.page, state.applied)]); }
                catch (err) { notify(messageFor(err), 'danger'); }
                finally { remove.disabled = false; }
            }
        });
        loadCategories().then(() => { if (state.report) renderReport(state.report); }).catch(err => notify(messageFor(err), 'danger'));
        loadReport();
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
    else start();
})();
