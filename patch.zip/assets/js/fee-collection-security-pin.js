// Ask for a fresh PIN for each submission. The collection API validates it.
let feeCollectionInProgress = false;
function submitFeeCollection(options, requiresPin) {
    if (feeCollectionInProgress) return;
    feeCollectionInProgress = true;

    function send(pin) {
        $.ajax({
            ...options,
            data: {...options.data, security_pin: pin},
            complete: function(...args) {
                feeCollectionInProgress = false;
                if (options.complete) options.complete.apply(this, args);
            }
        });
    }

    if (!requiresPin) {
        send('');
        return;
    }

    Swal.fire({
        title: 'Enter Security PIN',
        text: 'Enter your security PIN to submit this payment.',
        input: 'password',
        inputAttributes: {autocomplete: 'one-time-code', maxlength: 6},
        showCancelButton: true,
        confirmButtonText: 'Submit Payment',
        cancelButtonText: 'Cancel',
        allowOutsideClick: false,
        preConfirm: function(pin) {
            if (!pin || pin.length !== 6) {
                Swal.showValidationMessage('Enter your 6-character security PIN.');
                return false;
            }
            return pin;
        },
        customClass: {
            popup: 'rounded-4 shadow-lg',
            confirmButton: 'btn btn-primary px-4 py-2',
            cancelButton: 'btn btn-secondary px-4 py-2'
        }
    }).then(function(result) {
        if (result.isConfirmed) send(result.value);
        else feeCollectionInProgress = false;
    });
}
