(() => {
    'use strict';
    const form = document.getElementById('enquiry-edit-form');
    if (!form) return;
    const message = document.getElementById('enquiry-edit-message');
    const fields = document.getElementById('enquiry-edit-fields');
    const saveButton = document.getElementById('enquiry-save');
    const photoFile = document.getElementById('enquiry-photo-file');
    const photoPreview = document.getElementById('enquiry-photo-preview');
    const removePhoto = document.getElementById('enquiry-remove-photo');
    const clearPhoto = document.getElementById('enquiry-clear-photo');
    const cropData = form.elements.namedItem('cropped_image_data');
    const modalElement = document.getElementById('enquiry-crop-modal');
    const cropImage = document.getElementById('enquiry-crop-image');
    const applyCrop = document.getElementById('enquiry-apply-crop');
    let cropper = null, objectUrl = null, saving = false;
    let originalPhoto = form.dataset.photoUrl;
    const defaultPhoto = form.dataset.defaultPhotoUrl;
    const showMessage = (text, success = false) => {
        message.textContent = text;
        message.className = 'alert ' + (success ? 'alert-success' : 'alert-danger');
        message.setAttribute('role', success ? 'status' : 'alert');
        message.scrollIntoView({ block: 'nearest' });
    };
    const resetReplacement = () => {
        cropData.value = '';
        photoFile.value = '';
        clearPhoto.hidden = true;
        photoPreview.src = removePhoto.checked ? defaultPhoto : originalPhoto;
    };
    clearPhoto.addEventListener('click', resetReplacement);
    removePhoto.addEventListener('change', resetReplacement);
    document.querySelectorAll('.enquiry-address-part').forEach(input => input.addEventListener('input', () => {
        const parts = { village: 'Vill', post_office: 'P.O', police_station: 'P.S', district: 'Dist', pin_code: 'Pin' };
        form.elements.namedItem('address').value = Object.entries(parts)
            .map(([field, label]) => {
                const value = form.elements.namedItem(field).value.trim();
                return value ? label + '- ' + value : '';
            }).filter(Boolean).join(', ');
    }));
    const cleanupCropper = () => {
        if (cropper) { cropper.destroy(); cropper = null; }
        if (objectUrl) { URL.revokeObjectURL(objectUrl); objectUrl = null; }
        cropImage.removeAttribute('src');
        applyCrop.disabled = true;
        // Cancelling a new selection leaves a previously applied replacement intact.
        photoFile.value = '';
    };
    modalElement.addEventListener('hidden.bs.modal', cleanupCropper);
    modalElement.addEventListener('shown.bs.modal', () => {
        if (typeof Cropper !== 'function') {
            showMessage('The photo editor could not load. Please reload the page.');
            bootstrap.Modal.getInstance(modalElement).hide();
            return;
        }
        cropper = new Cropper(cropImage, { aspectRatio: 5 / 6, viewMode: 1, autoCropArea: 1,
            ready() { applyCrop.disabled = false; } });
    });
    photoFile.addEventListener('change', () => {
        const file = photoFile.files[0];
        if (!file) return;
        if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 5 * 1024 * 1024) {
            photoFile.value = '';
            showMessage('Choose a JPG, PNG or WebP photo of at most 5 MB.');
            return;
        }
        if (typeof bootstrap === 'undefined' || !bootstrap.Modal) {
            photoFile.value = '';
            showMessage('The photo editor could not load. Please reload the page.');
            return;
        }
        cleanupCropper();
        objectUrl = URL.createObjectURL(file);
        cropImage.src = objectUrl;
        bootstrap.Modal.getOrCreateInstance(modalElement).show();
    });
    applyCrop.addEventListener('click', () => {
        if (!cropper) return;
        try {
            const canvas = cropper.getCroppedCanvas({ width: 500, height: 600, fillColor: '#fff' });
            if (!canvas) throw new Error('Could not crop photo');
            cropData.value = canvas.toDataURL('image/jpeg', 0.85);
            photoPreview.src = cropData.value;
            clearPhoto.hidden = false;
            removePhoto.checked = false;
            bootstrap.Modal.getInstance(modalElement).hide();
        } catch (error) {
            showMessage('The photo could not be cropped. Please choose another image.');
        }
    });
    form.addEventListener('submit', async event => {
        event.preventDefault();
        if (saving || !form.reportValidity()) return;
        if (objectUrl !== null) {
            showMessage('Finish or cancel cropping the student photo before saving.');
            return;
        }
        const data = new FormData(form);
        // Only submit an explicitly applied crop; cancelled file selections must never replace a photo.
        data.delete('student_image');
        saving = true;
        fields.disabled = true;
        const buttonHtml = saveButton.innerHTML;
        saveButton.textContent = 'Saving…';
        message.classList.add('d-none');
        try {
            const response = await fetch(form.action, { method: 'POST', body: data, credentials: 'same-origin', headers: { Accept: 'application/json' } });
            const result = await response.json();
            if (!response.ok || !result.success) throw new Error(result.message || 'The application could not be saved. Please try again.');
            form.elements.namedItem('original_version').value = result.original_version;
            originalPhoto = result.photo_url;
            removePhoto.checked = false;
            removePhoto.disabled = !result.has_photo;
            resetReplacement();
            showMessage(result.message, true);
        } catch (error) {
            showMessage(error instanceof SyntaxError ? 'The server could not respond. Please reload the page and try again.' : (error.message || 'The application could not be saved. Please try again.'));
        } finally {
            fields.disabled = false;
            saving = false;
            saveButton.innerHTML = buttonHtml;
        }
    });
})();
