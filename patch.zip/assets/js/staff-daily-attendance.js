/* Read-only daily teacher roster. Uses server dates and the school's dated rules. */
(() => {
    'use strict';
    const root=document.querySelector('#staffAttendance[data-view="daily"]');
    if(!root) return;
    const $=id=>document.getElementById(id);
    const date=$('dailyAttendanceDate'), search=$('dailyAttendanceSearch'), filter=$('dailyAttendanceStatus');
    const statuses={present:['Present','good'],on_campus:['Present · no checkout','info'],missing_checkout:['Missing departure','warn'],
        absent:['Absent','bad'],paid_leave:['Paid leave','info'],unpaid_leave:['Unpaid leave','warn'],
        awaiting_arrival:['Awaiting arrival','muted'],off:['Non-working day','muted'],disabled:['Attendance off','muted'],
        not_configured:['Rules not configured','muted'],not_employed:['Not employed on date','muted'],
        upcoming:['Upcoming','muted'],needs_attention:['Needs attention','warn']};
    const metrics=[['present','Present / arrived','present'],['absent','Absent','absent'],['late','Late arrivals','late'],
        ['early','Early departures','early'],['awaiting','Awaiting arrival','awaiting'],['pending_review','Pending review','review']];
    let report=null, version=0, controller=null, today=root.dataset.today;
    const node=(tag,text,cls)=>{const el=document.createElement(tag);if(text!==undefined)el.textContent=String(text);if(cls)el.className=cls;return el;};
    const badge=(text,tone)=>{const el=node('span',text,'staff-daily-badge');el.dataset.tone=tone;return el;};
    const prettyDate=value=>new Intl.DateTimeFormat('en-GB',{weekday:'long',day:'numeric',month:'long',year:'numeric',timeZone:'UTC'}).format(new Date(value+'T12:00:00Z'));
    function matches(row, value) {
        if(value==='present') return ['present','on_campus','missing_checkout'].includes(row.status);
        if(value==='late'||value==='early') return Number(row[value+'_minutes'])>0;
        if(value==='awaiting') return row.status==='awaiting_arrival';
        if(value==='missing') return ['missing_checkout','needs_attention'].includes(row.status);
        if(value==='leave') return ['paid_leave','unpaid_leave'].includes(row.status);
        if(value==='off') return ['off','disabled','not_configured','not_employed','upcoming'].includes(row.status);
        if(value==='review') return row.review_status==='pending';
        return value==='all'||row.status===value;
    }
    function timeCell(row, which) {
        const td=node('td'), value=row[which+'_time'];
        if(value) { const time=node('time',value);time.dateTime=row[which+'_at'];td.append(time); }
        else td.append(node('span','—'));
        return td;
    }
    function timingCell(minutes,label) {
        const td=node('td');
        td.append(minutes===null||minutes===undefined?node('span','—'):badge(minutes>0?minutes+' min '+label:'On time',minutes>0?'warn':'good'));
        return td;
    }
    function render() {
        if(!report) return;
        const term=search.value.trim().toLocaleLowerCase();
        const rows=report.teachers.filter(row=>matches(row,filter.value) &&
            [row.teacher_name,row.teacher_id,row.position].join(' ').toLocaleLowerCase().includes(term));
        const body=$('dailyAttendanceRows'); body.replaceChildren();
        const fragment=document.createDocumentFragment();
        for(const row of rows) {
            const tr=node('tr'), state=statuses[row.status]||['Unknown','warn']; tr.dataset.status=row.status;
            const teacher=node('th',row.teacher_name); teacher.scope='row';
            teacher.append(node('small','ID: '+row.teacher_id+(row.position?' · '+row.position:'')));tr.append(teacher);
            const status=node('td');status.append(badge(...state));
            if(['absent','awaiting_arrival','needs_attention'].includes(row.status)) status.append(node('small',row.detail));
            if(row.short_day) status.append(node('small','Below minimum shift work time'));
            if(row.manual) status.append(node('small','Admin entry'));
            tr.append(status,timeCell(row,'arrival'),timingCell(row.late_minutes,'late'),
                timeCell(row,'departure'),timingCell(row.early_minutes,'early'));
            const shift=node('td');
            shift.append(node('span',row.working?row.shift_start+' – '+row.shift_end:'—'));
            shift.append(node('small',row.schedule_note||(row.rule_source==='teacher'?'Personal schedule':'School schedule')));
            const review=node('td');
            const reviewLabel={approved:['Approved','good'],pending:['Pending review','warn'],rejected:['Rejected','bad']}[row.review_status];
            review.append(reviewLabel?badge(...reviewLabel):node('span','—'));
            const details=node('td'), link=node('a','View day','btn btn-sm btn-outline-secondary');
            const url=new URL(root.dataset.reviewUrl,location.href);url.searchParams.set('teacher_id',row.teacher_id);url.searchParams.set('date',report.date);
            link.href=url.href;link.setAttribute('aria-label','View '+row.teacher_name+' attendance for '+report.date);details.append(link);
            tr.append(shift,review,details);fragment.append(tr);
        }
        if(!rows.length) { const tr=node('tr'),td=node('td',report.teachers.length?'No teachers match these filters.':'No active teachers are available.','staff-daily-empty');td.colSpan=9;tr.append(td);fragment.append(tr); }
        body.append(fragment);
        $('dailyAttendanceCount').textContent=`Showing ${rows.length} of ${report.summary.total} active teachers`;
        $('dailyAttendanceSummary').querySelectorAll('button').forEach(button=>button.setAttribute('aria-pressed',String(filter.value===button.dataset.filter)));
    }
    function showMessage(text,error=false) {
        const box=$('dailyAttendanceMessage');box.hidden=!text;box.textContent=text;box.dataset.error=String(error);
    }
    async function load() {
        const selected=date.value, token=++version;
        controller?.abort();report=null;
        $('dailyAttendanceReport').hidden=true;
        if(!date.reportValidity()) {
            root.setAttribute('aria-busy','false');$('dailyAttendanceReload').disabled=false;
            showMessage('Choose a valid attendance date.');return;
        }
        controller=new AbortController();
        root.setAttribute('aria-busy','true');
        $('dailyAttendanceReload').disabled=true;
        showMessage('Loading attendance for '+selected+'…');
        try {
            const url=new URL(root.dataset.endpoint,location.href);url.searchParams.set('action','daily');url.searchParams.set('date',selected);
            const response=await fetch(url,{credentials:'same-origin',cache:'no-store',signal:controller.signal,headers:{Accept:'application/json'}});
            let result;try { result=await response.json(); } catch { throw new Error('Attendance could not be loaded. Refresh and try again.'); }
            if(!response.ok || !result.success) throw new Error(result.message||'Attendance could not be loaded.');
            if(token!==version || selected!==date.value) return;
            if(result.data?.date!==selected || !Array.isArray(result.data.teachers) || !result.data.summary) throw new Error('The attendance response did not match the selected date. Refresh and try again.');
            report=result.data;today=report.today;
            $('dailyAttendanceTitle').textContent=(selected===today?'Today · ':'')+prettyDate(selected);
            $('dailyAttendanceCaption').textContent='All active teachers · '+prettyDate(selected);
            $('dailyAttendanceUpdated').textContent='Updated '+new Intl.DateTimeFormat('en-GB',{hour:'2-digit',minute:'2-digit',second:'2-digit',timeZone:report.timezone}).format(new Date(report.generated_at))+' · '+report.timezone;
            const summary=$('dailyAttendanceSummary');summary.replaceChildren();
            for(const [key,label,value] of metrics) {
                const button=node('button');button.type='button';button.dataset.filter=value;
                button.append(node('strong',report.summary[key]),node('span',label));summary.append(button);
            }
            render();$('dailyAttendanceReport').hidden=false;showMessage('');
            const pageUrl=new URL(location.href);pageUrl.searchParams.set('date',selected);history.replaceState(null,'',pageUrl);
        } catch(error) {
            if(token!==version || error.name==='AbortError') return;
            showMessage(error.message||'Attendance could not be loaded.',true);
        } finally {
            if(token===version) { root.setAttribute('aria-busy','false');$('dailyAttendanceReload').disabled=false; }
        }
    }
    $('dailyAttendanceFilters').addEventListener('submit',event=>{event.preventDefault();load();});
    date.addEventListener('change',load);
    $('dailyAttendanceToday').addEventListener('click',()=>{date.value=today;load();});
    search.addEventListener('input',render);filter.addEventListener('change',render);
    $('dailyAttendanceSummary').addEventListener('click',event=>{const button=event.target.closest('button[data-filter]');if(button) { filter.value=filter.value===button.dataset.filter?'all':button.dataset.filter;render(); }});
    load();
})();
