(() => {
    'use strict';
    const root = document.getElementById('monthlyCategoryReport');
    if (!root) return;
    const el = id => document.getElementById(id);
    const labels = {tuition: 'Tuition Fee', car: 'Car Fee', hostel: 'Hostel Fee', coaching: 'Coaching Fee',
        tiffin: 'Tiffin Fee', other: 'Other Fee', unclassified: 'Legacy / unclassified'};
    const icons = {tuition: 'fa-graduation-cap', car: 'fa-bus', hostel: 'fa-bed', coaching: 'fa-book-open',
        tiffin: 'fa-utensils', other: 'fa-coins', unclassified: 'fa-clock-rotate-left'};
    const cents = amount => Math.round(Number(amount) * 100);
    const money = amount => (amount / 100).toFixed(2);
    let legacyBills = [], selectedBill = null, saving = false, reportRequest = 0, reportController = null;
    function message(text, error = false, busy = false) {
        el('categoryMessageText').textContent = text;
        el('categoryMessage').className = `alert alert-${error ? 'danger' : 'info'} category-message d-flex align-items-center gap-2`;
        el('categoryMessageIcon').className = `fa-solid ${busy ? 'fa-circle-notch fa-spin' : error ? 'fa-circle-exclamation' : 'fa-circle-check'}`;
    }
    function row(body, values, amountStart = 1) {
        const tr = document.createElement('tr');
        values.forEach((value, index) => {
            const td = document.createElement('td'); td.textContent = value;
            if (index >= amountStart) td.className = 'category-amount';
            tr.appendChild(td);
        });
        body.appendChild(tr); return tr;
    }
    function icon(className) {
        const item = document.createElement('i'); item.className = `fa-solid ${className}`;
        item.setAttribute('aria-hidden', 'true'); return item;
    }
    function feeCell(cell, code) { cell.prepend(icon(`${icons[code] || 'fa-coins'} category-fee-icon`)); }
    function emptyRow(body, columns, text) {
        const tr = row(body, [text]); tr.lastChild.colSpan = columns; tr.lastChild.className = 'category-empty-cell';
        tr.lastChild.prepend(icon('fa-inbox me-2'));
    }
    function studentOption(option) {
        if (!option.student) return option.text;
        const student = option.student, container = document.createElement('div');
        container.className = 'category-student-option';
        const name = document.createElement('div'); name.className = 'category-student-name';
        name.textContent = `${student.name || 'Student'} · ${student.student_id}`; container.appendChild(name);
        const details = document.createElement('span'); details.className = 'category-student-meta';
        details.textContent = [student.class_name, student.section_name, `Roll: ${student.roll_no ?? '—'}`,
            student.registration_no ? `Reg: ${student.registration_no}` : ''].filter(Boolean).join(' · ');
        container.appendChild(details);
        const family = document.createElement('span'); family.className = 'category-student-meta';
        const phones = [...new Set([student.phone_number, student.alternate_phone_number].filter(Boolean))];
        family.textContent = [student.father_name ? `Father: ${student.father_name}` : '', phones.join(' / ')].filter(Boolean).join(' · ');
        container.appendChild(family);
        return window.jQuery(container);
    }
    function initStudentSearch() {
        const studentSelect = window.jQuery(el('categoryStudent'));
        studentSelect.select2({
            theme: 'bootstrap-5', width: '100%', allowClear: true, minimumInputLength: 1,
            placeholder: 'All students — type to search…', templateResult: studentOption,
            ajax: {
                url: `${root.dataset.base}/api/admin/get/fees-x-payments/monthly/search-report-students.php`,
                dataType: 'json', delay: 300,
                data: params => ({q: params.term || '', page: params.page || 1, month: el('categoryMonth').value}),
                processResults: result => {
                    if (!result.success) { message(result.message || 'Unable to search students.', true); return {results: []}; }
                    return {results: (result.results || []).map(student => ({id: student.student_id,
                        text: `${student.name || 'Student'} (${student.student_id})`, student})),
                        pagination: {more: Boolean(result.pagination?.more)}};
                }
            }
        });
        studentSelect.on('change', () => {
            const selection = studentSelect.select2('data')[0];
            el('categoryStudentScope').textContent = selection?.id ? selection.text : 'All students';
            if (!saving) { selectedBill = null; el('legacyReviewPanel').hidden = true; }
            load();
        });
    }
    function render(report) {
        ['categoryBillSummary', 'categoryBillTotals', 'categoryCollectionSummary', 'categoryCollectionTotals',
            'categoryBillDetails', 'categoryLegacyBills'].forEach(id => el(id).replaceChildren());
        el('categoryBillPeriod').textContent = report.billing_month;
        el('categoryCollectionPeriod').textContent = `${report.from} to ${report.to}`;
        el('categoryWalletDeposits').textContent = report.wallet_deposits;
        const billTotals = [0, 0, 0, 0], collectionTotals = [0, 0, 0, 0];
        report.categories.forEach(category => {
            const bill = ['billed', 'discount', 'paid', 'due'].map(key => cents(category[key]));
            const collection = [cents(category.cash), cents(category.online), cents(category.cash) + cents(category.online), cents(category.wallet)];
            const billedRow = row(el('categoryBillSummary'), [category.label, ...bill.map(money)]);
            const collectedRow = row(el('categoryCollectionSummary'), [category.label, ...collection.map(money)]);
            feeCell(billedRow.children[0], category.code); feeCell(collectedRow.children[0], category.code);
            if (category.code === 'unclassified') { billedRow.className = 'category-unclassified'; collectedRow.className = 'category-unclassified'; }
            bill.forEach((value, index) => billTotals[index] += value);
            collection.forEach((value, index) => collectionTotals[index] += value);
        });
        row(el('categoryBillTotals'), ['Total', ...billTotals.map(money)]);
        row(el('categoryCollectionTotals'), ['Total', ...collectionTotals.map(money)]);
        const currency = root.dataset.currency || '';
        el('categoryStatBilled').textContent = currency + money(billTotals[0]);
        el('categoryStatPaid').textContent = currency + money(billTotals[2]);
        el('categoryStatDue').textContent = currency + money(billTotals[3]);
        el('categoryStatCollected').textContent = currency + money(collectionTotals[2]);
        el('categoryBillCount').textContent = `${report.bills.length} bills`;
        const states = {complete: 'Full bill', opening_reviewed: 'Verified opening balance', legacy: 'Legacy'};
        report.bills.forEach(bill => {
            const components = Object.entries(bill.components).filter(([, component]) => Object.values(component).some(value => cents(value) !== 0));
            components.forEach(([code, component], index) => {
                const values = [labels[code], component.billed, component.discount,
                    money(cents(component.paid) + cents(component.opening_paid)), component.due];
                if (index === 0) values.unshift(`${bill.student_name || ''} (${bill.student_id})`, `${bill.month_year} / ${states[bill.breakdown_state] || bill.breakdown_state}`);
                const tr = row(el('categoryBillDetails'), values, index === 0 ? 3 : 1);
                feeCell(tr.children[index === 0 ? 2 : 0], code);
                if (index === 0) {
                    tr.className = 'category-bill-group-start';
                    [tr.children[0], tr.children[1]].forEach(cell => { cell.rowSpan = components.length; cell.className = 'category-bill-identity'; });
                }
            });
        });
        legacyBills = report.legacy_pending;
        legacyBills.forEach((bill, index) => {
            const tr = row(el('categoryLegacyBills'), [`${bill.student_name || ''} (${bill.student_id})`, bill.month_year, bill.unpaid_amount, ''], 2);
            if (root.dataset.canReview === '1') {
                const button = document.createElement('button'); button.type = 'button'; button.className = 'btn btn-sm btn-outline-primary';
                button.textContent = 'Verify remaining fees'; button.dataset.legacyIndex = String(index);
                button.prepend(icon('fa-clipboard-check me-1'));
                tr.lastChild.appendChild(button);
            }
        });
        el('categoryLegacyCount').textContent = `${legacyBills.length} pending`;
        if (!report.bills.length) emptyRow(el('categoryBillDetails'), 7, 'No category bills for this selection.');
        if (!legacyBills.length) emptyRow(el('categoryLegacyBills'), 4, 'No legacy bills awaiting verification.');
    }
    async function load() {
        const request = ++reportRequest;
        reportController?.abort(); reportController = new AbortController();
        root.dataset.loading = '1';
        el('categoryReportSubmit').disabled = true; message('Loading report…', false, true);
        try {
            const query = new URLSearchParams({month: el('categoryMonth').value, from: el('categoryFrom').value,
                to: el('categoryTo').value, student_id: el('categoryStudent').value.trim()});
            const response = await fetch(`${root.dataset.base}/api/admin/get/fees-x-payments/monthly/category-report.php?${query}`,
                {credentials: 'same-origin', signal: reportController.signal});
            const result = await response.json();
            if (request !== reportRequest) return;
            if (!result.success) throw new Error(result.message || 'Unable to load report.');
            render(result.report); message('Report updated.');
        } catch (error) { if (request === reportRequest && error.name !== 'AbortError') message(error.message, true); }
        finally { if (request === reportRequest) { el('categoryReportSubmit').disabled = false; root.dataset.loading = '0'; } }
    }
    function reviewTotal() {
        const total = [...root.querySelectorAll('.legacy-component')].reduce((sum, input) => sum + cents(input.value || 0), 0);
        el('legacyReviewTotal').textContent = `Entered: ${money(total)} / Existing due: ${selectedBill ? selectedBill.unpaid_amount : '0.00'}`;
        return total;
    }
    el('categoryFilters').addEventListener('submit', event => { event.preventDefault(); load(); });
    el('categoryLegacyBills').addEventListener('click', event => {
        if (saving || root.dataset.loading === '1') return;
        const button = event.target.closest('[data-legacy-index]'); if (!button) return;
        selectedBill = legacyBills[Number(button.dataset.legacyIndex)];
        el('legacyReviewDescription').textContent = `${selectedBill.student_id} / ${selectedBill.month_year}. Verify only the remaining ${selectedBill.unpaid_amount}.`;
        root.querySelectorAll('.legacy-component').forEach(input => input.value = '0');
        el('legacyReviewPanel').hidden = false; reviewTotal(); el('legacyReviewPanel').scrollIntoView({behavior: 'smooth'});
    });
    el('legacyReviewForm').addEventListener('input', reviewTotal);
    el('legacyReviewCancel').addEventListener('click', () => { if (!saving) { selectedBill = null; el('legacyReviewPanel').hidden = true; } });
    el('legacyReviewForm').addEventListener('submit', async event => {
        event.preventDefault(); if (saving || !selectedBill) return;
        if (reviewTotal() !== cents(selectedBill.unpaid_amount)) { message('The components must equal the existing remaining due.', true); return; }
        const components = {};
        root.querySelectorAll('.legacy-component').forEach(input => components[input.dataset.fee] = input.value);
        const body = new URLSearchParams({fee_id: selectedBill.id, csrf: root.dataset.csrf, components: JSON.stringify(components)});
        saving = true; el('legacyReviewSubmit').disabled = true;
        try {
            const response = await fetch(`${root.dataset.base}/api/admin/put/fees-x-payments/monthly/verify-legacy-breakdown.php`,
                {method: 'POST', credentials: 'same-origin', body});
            const result = await response.json(); if (!result.success) throw new Error(result.message || 'Unable to save breakdown.');
            el('legacyReviewPanel').hidden = true; selectedBill = null; await load();
        } catch (error) { message(error.message, true); }
        finally { saving = false; el('legacyReviewSubmit').disabled = false; }
    });
    // The shared header initializes .select2 on ready, which also matches the
    // generated container spans. Create our remote selector after that callback.
    window.jQuery(() => { initStudentSearch(); load(); });
})();
