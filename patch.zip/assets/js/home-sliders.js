$(document).ready(function() {

    $('.big-slider-container').slick({
        centerMode: false,
        slidesToShow: 1,
        infinite: true,
        autoplay: true,
        autoplaySpeed: 6000,
        accessibility: true,
        adaptiveHeight: true,
        arrows: true,
        prevArrow: '<button id="prevBtnSlider"><i class="fa-solid fa-circle-chevron-left"></i></button>',
        nextArrow: '<button id="nextBtnSlider"><i class="fa-solid fa-circle-chevron-right"></i></button>',
        responsive: [
        {
            breakpoint: 768,
            settings: {
            centerPadding: '40px',
            slidesToShow: 1
            }
        },
        {
            breakpoint: 480,
            settings: {
            centerPadding: '40px',
            slidesToShow: 1
            }
        }
        ]
    });

    $('.teachers-cards').slick({
        centerMode: false,
        slidesToShow: 4,
        infinite: true,
        autoplay: true,
        autoplaySpeed: 3000,
        accessibility: true,
        adaptiveHeight: true,
        arrows: false,
        prevArrow: '<button id="prevBtnSlider"><i class="fa-solid fa-circle-chevron-left"></i></button>',
        nextArrow: '<button id="nextBtnSlider"><i class="fa-solid fa-circle-chevron-right"></i></button>',
        responsive: [
        {
            breakpoint: 768,
            settings: {
            centerPadding: '40px',
            slidesToShow: 2
            }
        },
        {
            breakpoint: 480,
            settings: {
            centerPadding: '40px',
            slidesToShow: 1,
            centerMode: true,
            }
        }
        ]
    });
});