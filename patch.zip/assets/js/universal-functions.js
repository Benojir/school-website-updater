// Helper function to escape HTML
function escapeHtml(text) {
    if (text === null || text === undefined) {
        return '';
    }
    return text.toString()
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// Helper function to capitalize first letter
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

// Helper function to format date and time
function formatDateTime(dateTimeString) {
    if (!dateTimeString) return '-';
    const date = new Date(dateTimeString);
    return date.toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
    });
}

// Function to format date
function formatDate(dateString) {
    if (!dateString || dateString === '0000-00-00') return '-';
    const date = new Date(dateString.split(' ')[0]); // Handle 'YYYY-MM-DD HH:MM:SS'
    return date.toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
    });
}

// Show loading alert
function showLoadingAlert(modalTitle = 'Loading...', modalHtml = 'Please wait...') {
    Swal.close();
    Swal.fire({
        title: modalTitle,
        html: modalHtml,
        allowOutsideClick: false,
        showConfirmButton: false,
        allowEscapeKey: false,
        showCloseButton: false,
        customClass: {
            popup: 'rounded-4 shadow-lg'
        },
        didOpen: () => {
            Swal.showLoading();
        }
    });
}

// Show sweet alert success message
function showSuccessAlert(message, modalTitle = 'Success') {
    // Close all open modals before showing success alert
    Swal.close();
    Swal.fire({
        icon: 'success',
        title: modalTitle,
        html: message,
        confirmButtonText: 'OK',
        customClass: {
            popup: 'rounded-4 shadow-lg',
            confirmButton: 'btn btn-success px-4 py-2'
        }
    });
}

// Show sweet alert error message
function showErrorAlert(message, modalTitle = 'Error') {
    Swal.close();
    Swal.fire({
        icon: 'error',
        title: modalTitle,
        html: message,
        confirmButtonText: 'OK',
        customClass: {
            popup: 'rounded-4 shadow-lg',
            confirmButton: 'btn btn-danger px-4 py-2'
        }
    });
}

// Show sweet alert warning message
function showWarningAlert(message, modalTitle = 'Warning') {
    Swal.close();
    Swal.fire({
        icon: 'warning',
        title: modalTitle,
        html: message,
        confirmButtonText: 'OK',
        customClass: {
            popup: 'rounded-4 shadow-lg',
            confirmButton: 'btn btn-warning px-4 py-2'
        }
    });
}

// Show sweet alert info message
function showInfoAlert(message, modalTitle = 'Info') {
    Swal.close();
    Swal.fire({
        icon: 'info',
        title: modalTitle,
        html: message,
        confirmButtonText: 'OK',
        customClass: {
            popup: 'rounded-4 shadow-lg',
            confirmButton: 'btn btn-info px-4 py-2'
        }
    });
}