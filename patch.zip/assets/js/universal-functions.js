// Helper function to escape HTML
function escapeHtml(text) {
    if (text === null || text === undefined) {
        return '';
    }
    return text.toString()
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// Helper function to capitalize first letter
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

// Helper function to format date and time
function formatDateTime(dateTimeString) {
    if (!dateTimeString) return '-';
    const date = new Date(dateTimeString);
    return date.toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
    });
}

// Function to format date
function formatDate(dateString) {
    if (!dateString || dateString === '0000-00-00') return '-';
    const date = new Date(dateString.split(' ')[0]); // Handle 'YYYY-MM-DD HH:MM:SS'
    return date.toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
    });
}

// Show loading alert
function showLoadingAlert(modalTitle = 'Loading...', modalHtml = 'Please wait...') {
    Swal.close();
    Swal.fire({
        title: modalTitle,
        html: modalHtml,
        allowOutsideClick: false,
        showConfirmButton: false,
        allowEscapeKey: false,
        showCloseButton: false,
        customClass: {
            popup: 'rounded-4 shadow-lg'
        },
        didOpen: () => {
            Swal.showLoading();
        }
    });
}

// Show sweet alert success message
function showSuccessAlert(message, modalTitle = 'Success') {
    // Close all open modals before showing success alert
    Swal.close();
    Swal.fire({
        icon: 'success',
        title: modalTitle,
        html: message,
        confirmButtonText: 'OK',
        customClass: {
            popup: 'rounded-4 shadow-lg',
            confirmButton: 'btn btn-success px-4 py-2'
        }
    });
}

// Show sweet alert error message
function showErrorAlert(message, modalTitle = 'Error') {
    Swal.close();
    Swal.fire({
        icon: 'error',
        title: modalTitle,
        html: message,
        confirmButtonText: 'OK',
        customClass: {
            popup: 'rounded-4 shadow-lg',
            confirmButton: 'btn btn-danger px-4 py-2'
        }
    });
}

// Show sweet alert warning message
function showWarningAlert(message, modalTitle = 'Warning') {
    Swal.close();
    Swal.fire({
        icon: 'warning',
        title: modalTitle,
        html: message,
        confirmButtonText: 'OK',
        customClass: {
            popup: 'rounded-4 shadow-lg',
            confirmButton: 'btn btn-warning px-4 py-2'
        }
    });
}

// Show sweet alert info message
function showInfoAlert(message, modalTitle = 'Info') {
    Swal.close();
    Swal.fire({
        icon: 'info',
        title: modalTitle,
        html: message,
        confirmButtonText: 'OK',
        customClass: {
            popup: 'rounded-4 shadow-lg',
            confirmButton: 'btn btn-info px-4 py-2'
        }
    });
}

// Helper function to get ordinal suffix
function getOrdinal(number) {
    const suffix = ['th', 'st', 'nd', 'rd'];
    const mod100 = number % 100;

    // Check for special cases: 11th, 12th, 13th
    if (mod100 >= 11 && mod100 <= 13) {
        return number + 'th';
    }

    // For other numbers, use the appropriate suffix
    const mod10 = number % 10;
    const suffixIndex = (mod10 <= 3) ? mod10 : 0;

    return number + suffix[suffixIndex];
}

// Helper function to capitalize each word in a string
function capitalize(str) {
    return str.toLowerCase().replace(/\b\w/g, char => char.toUpperCase());
}

// Function to check if a string is numeric
function isNumeric(str) {
    // Allows: -12, 12.5, 14
    // Rejects: +12, any non-numeric, empty strings
    return /^-?\d+(\.\d+)?$/.test(str);
}

// Function to check valid date
function isValidDate(dateString) {
    const date = new Date(dateString);
    return date instanceof Date && !isNaN(date);
}