// Helper function to escape HTML
function escapeHtml(text) {
    if (text === null || text === undefined) {
        return '';
    }
    return text.toString()
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// Helper function to capitalize first letter
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

// Helper function to format date and time
function formatDateTime(dateTimeString) {
    if (!dateTimeString) return '-';
    const date = new Date(dateTimeString);
    return date.toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
    });
}

// Function to format date
function formatDate(dateString) {
    if (!dateString || dateString === '0000-00-00') return '-';
    const date = new Date(dateString.split(' ')[0]); // Handle 'YYYY-MM-DD HH:MM:SS'
    return date.toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
    });
}

// Show loading alert
function showLoadingAlert(modalTitle = 'Loading...', modalHtml = 'Please wait...') {
    Swal.close();
    Swal.fire({
        title: modalTitle,
        html: modalHtml,
        allowOutsideClick: false,
        showConfirmButton: false,
        allowEscapeKey: false,
        showCloseButton: false,
        customClass: {
            popup: 'rounded-4 shadow-lg'
        },
        didOpen: () => {
            Swal.showLoading();
        }
    });
}

// Show sweet alert success message
function showSuccessAlert(message, modalTitle = 'Success') {
    // Close all open modals before showing success alert
    Swal.close();
    Swal.fire({
        icon: 'success',
        title: modalTitle,
        html: message,
        confirmButtonText: 'OK',
        customClass: {
            popup: 'rounded-4 shadow-lg',
            confirmButton: 'btn btn-success px-4 py-2'
        }
    });
}

// Show sweet alert error message
function showErrorAlert(message, modalTitle = 'Error') {
    Swal.close();
    Swal.fire({
        icon: 'error',
        title: modalTitle,
        html: message,
        confirmButtonText: 'OK',
        customClass: {
            popup: 'rounded-4 shadow-lg',
            confirmButton: 'btn btn-danger px-4 py-2'
        }
    });
}

// Show sweet alert warning message
function showWarningAlert(message, modalTitle = 'Warning') {
    Swal.close();
    Swal.fire({
        icon: 'warning',
        title: modalTitle,
        html: message,
        confirmButtonText: 'OK',
        customClass: {
            popup: 'rounded-4 shadow-lg',
            confirmButton: 'btn btn-warning px-4 py-2'
        }
    });
}

// Show sweet alert info message
function showInfoAlert(message, modalTitle = 'Info') {
    Swal.close();
    Swal.fire({
        icon: 'info',
        title: modalTitle,
        html: message,
        confirmButtonText: 'OK',
        customClass: {
            popup: 'rounded-4 shadow-lg',
            confirmButton: 'btn btn-info px-4 py-2'
        }
    });
}

// Helper function to get ordinal suffix
function getOrdinal(number) {
    const suffix = ['th', 'st', 'nd', 'rd'];
    const mod100 = number % 100;

    // Check for special cases: 11th, 12th, 13th
    if (mod100 >= 11 && mod100 <= 13) {
        return number + 'th';
    }

    // For other numbers, use the appropriate suffix
    const mod10 = number % 10;
    const suffixIndex = (mod10 <= 3) ? mod10 : 0;

    return number + suffix[suffixIndex];
}

// Helper function to capitalize each word in a string
function capitalize(str) {
    return str.toLowerCase().replace(/\b\w/g, char => char.toUpperCase());
}

// Function to check if a string is numeric
function isNumeric(str) {
    // Allows: -12, 12.5, 14, 14., 14.0
    // Rejects: +12, any non-numeric, empty strings
    return /^-?\d+(\.\d*)?$/.test(str);
}

// Function to check valid date
function isValidDate(dateString) {
    const date = new Date(dateString);
    return date instanceof Date && !isNaN(date);
}

// Function to auto correct number input
function autoCorrectNumberInput(input) {
    let val = input.value;

    // 1. Strip out everything except digits, minus signs, and decimal points
    val = val.replace(/[^\d.-]/g, '');

    // 2. Ensure a minus sign is ONLY allowed at the very beginning
    const isNegative = val.startsWith('-');
    val = val.replace(/-/g, ''); // Remove all minus signs
    if (isNegative) {
        val = '-' + val; // Add the single minus sign back to the front
    }

    // 3. Ensure there is ONLY one decimal point allowed
    const parts = val.split('.');
    if (parts.length > 2) {
        // Keep the first part before the decimal, and squash the rest together
        val = parts[0] + '.' + parts.slice(1).join('');
    }

    // 4. Prevent the input from starting with a decimal point (like ".13")
    // If it starts with "." it strips it. If it starts with "-." it changes it back to "-"
    val = val.replace(/^-?\./, (match) => match === '.' ? '' : '-');

    // Update the input field with the corrected value
    input.value = val;
}

// Send error report to technical team
function sendErrorReport(message) {
    $.ajax({
        url: '/api/developer/send-error-report.php',
        type: 'POST',
        data: {
            message: message
        },
        dataType: 'json',
        success: function(response) {
            toastr.success("Error report sent successfully to technical team.");
        },
        error: function(error) {
            console.error(error);
        }
    });
}

function initTooltips() {
    document.querySelectorAll('[title]').forEach(el => {
        const title = el.getAttribute('title');

        if (title && title.trim()) {
            tippy(el, {
                content: title,
                allowHTML: true,
                theme: 'translucent'
            });
        }
    });
}

/**
 * Formats a numeric value for display.
 *
 * Examples:
 *   "300.00" -> "300"
 *   "25.50"  -> "25.50"
 *   "14.05"  -> "14.05"
 *   "440.10" -> "440.10"
 *
 * If the value has no fractional part (.00), the decimal portion is removed.
 * Otherwise, the value is returned with exactly 2 decimal places.
 *
 * @param {string|number} value The value to format.
 * @returns {string} The formatted value.
 */
function formatNumber(value) {
    const num = parseFloat(value);

    return Number.isInteger(num)
        ? num.toString()
        : num.toFixed(2);
}