(() => {
    'use strict';
    const editor=document.getElementById('classOrderEditor');
    if (!editor) return;
    const list=document.getElementById('classOrderList'), save=document.getElementById('saveClassOrder');
    const message=document.getElementById('classOrderMessage');
    const order=()=>[...list.children].map(row=>Number(row.dataset.classId));
    let savedOrder=order(), saving=false;
    const sortable=typeof Sortable==='undefined' ? null : new Sortable(list, {
        animation:150, handle:'.class-order-handle', draggable:'[data-class-id]',
        onEnd:()=>refresh(true)
    });
    function say(text,error=false) {
        message.textContent=text;
        message.className='mt-2 mb-0 '+(error?'text-danger':'text-success');
    }
    function refresh(announce=false) {
        const rows=[...list.children], dirty=JSON.stringify(order())!==JSON.stringify(savedOrder);
        rows.forEach((row,index)=> {
            const name=row.querySelector('.class-order-name').textContent;
            for (const direction of ['up','down']) {
                const button=row.querySelector(`[data-class-move="${direction}"]`);
                button.disabled=saving || (direction==='up'?index===0:index===rows.length-1);
                button.setAttribute('aria-label',`Move ${name} ${direction}`);
            }
            const handle=row.querySelector('.class-order-handle');
            handle.disabled=saving || rows.length<2;
            handle.setAttribute('aria-label',`Drag ${name}`);
        });
        save.disabled=saving || !dirty || rows.length<1;
        sortable?.option('disabled',saving || rows.length<2);
        if (!rows.length) editor.hidden=true;
        if (announce) say(dirty?'Order changed. Click Save class order to apply it.':'The saved class order is restored.');
    }
    list.addEventListener('click',event=> {
        const button=event.target.closest('[data-class-move]');
        if (!button || saving || button.disabled) return;
        const row=button.closest('[data-class-id]');
        if (button.dataset.classMove==='up' && row.previousElementSibling) list.insertBefore(row,row.previousElementSibling);
        else if (button.dataset.classMove==='down' && row.nextElementSibling) list.insertBefore(row.nextElementSibling,row);
        refresh(true);
        if (!button.disabled) button.focus();
    });
    save.addEventListener('click',async()=> {
        if (saving || save.disabled) return;
        const requested=order(); saving=true; refresh(); say('Saving class order...');
        try {
            const response=await fetch(editor.dataset.endpoint, {
                method:'POST', credentials:'same-origin',
                headers:{Accept:'application/json','Content-Type':'application/json','X-CSRF-Token':editor.dataset.csrf},
                body:JSON.stringify({order:requested})
            });
            let result;
            try { result=await response.json(); }
            catch { throw new Error('The server response could not be read. Reload and try again.'); }
            if (!result || typeof result.success!=='boolean') throw new Error('The server response could not be read. Reload and try again.');
            if (!response.ok || !result.success) throw new Error(result.message || 'Class order could not be saved.');
            savedOrder=requested;
            const cards=document.getElementById('classCardsList');
            for (const id of savedOrder) {
                const card=document.getElementById('class-'+id);
                if (card && cards) cards.append(card);
            }
            say(result.message || 'Class order saved.');
        } catch (error) {
            say(error.message || 'Class order could not be saved. Try again.',true);
        } finally { saving=false; refresh(); }
    });
    document.addEventListener('school:class-deleted',event=> {
        const id=Number(event.detail.id);
        [...list.children].find(row=>Number(row.dataset.classId)===id)?.remove();
        savedOrder=savedOrder.filter(value=>value!==id);
        refresh(true);
    });
    document.addEventListener('school:class-renamed',event=> {
        const row=[...list.children].find(item=>Number(item.dataset.classId)===Number(event.detail.id));
        if (row) row.querySelector('.class-order-name').textContent=event.detail.name;
        refresh();
    });
    refresh();
})();
