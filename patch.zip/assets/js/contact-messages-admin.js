(() => {
    'use strict';
    const root = document.getElementById('contactMessages');
    if (!root) return;
    const rows = document.getElementById('contactMessageRows');
    const filters = document.getElementById('contactFilters');
    const feedback = document.getElementById('contactAdminFeedback');
    const previous = document.getElementById('contactPrevious');
    const next = document.getElementById('contactNext');
    const modal = new bootstrap.Modal(document.getElementById('contactMessageModal'));
    let page = 1, pages = 1, generation = 0, mutating = false;
    const show = (message, success = false) => {
        feedback.textContent = message;
        feedback.className = `alert alert-${success ? 'success' : 'danger'}`;
    };
    const request = async (url, options = {}) => {
        const response = await fetch(url, {credentials: 'same-origin', ...options});
        let data;
        try { data = await response.json(); } catch (error) {
            throw new Error('Unable to load contact messages. Please try again.');
        }
        if (!response.ok || data.success !== true) throw new Error(data.message || 'Request failed.');
        return data;
    };
    const cell = (row, text, className = '') => {
        const element = document.createElement('td');
        element.textContent = text;
        element.className = className;
        row.append(element);
        return element;
    };
    const empty = text => {
        rows.replaceChildren();
        const row = document.createElement('tr');
        cell(row, text).colSpan = 5;
        rows.append(row);
    };
    const load = async () => {
        const current = ++generation;
        previous.disabled = next.disabled = true;
        root.setAttribute('aria-busy', 'true');
        empty('Loading messages...');
        const query = new URLSearchParams(new FormData(filters));
        query.set('page', String(page));
        try {
            const data = await request(`${root.dataset.api}?${query}`);
            if (current !== generation) return;
            page = data.page; pages = data.pages;
            rows.replaceChildren();
            data.messages.forEach(message => {
                const row = document.createElement('tr');
                const read = Number(message.is_read) === 1;
                if (!read) row.classList.add('table-light');
                const visitor = cell(row, message.name, 'text-break');
                const phone = document.createElement('div');
                phone.className = 'small text-muted'; phone.textContent = message.phone;
                visitor.append(phone);
                const content = cell(row, message.subject || 'No subject', 'text-break');
                const preview = document.createElement('div');
                preview.className = 'small text-muted'; preview.textContent = message.preview;
                content.append(preview);
                cell(row, message.created_at);
                cell(row, read ? 'Read' : 'Unread');
                const actions = cell(row, '');
                for (const [action, label, style] of [['open', 'View', 'primary'], [read ? 'unread' : 'read', read ? 'Mark unread' : 'Mark read', 'secondary'], ['delete', 'Delete', 'danger']]) {
                    const button = document.createElement('button');
                    button.type = 'button'; button.className = `btn btn-sm btn-outline-${style} m-1`;
                    button.textContent = label; button.dataset.action = action; button.dataset.id = message.id;
                    actions.append(button);
                }
                rows.append(row);
            });
            if (!data.messages.length) empty('No contact messages found.');
            document.getElementById('contactCounts').textContent = `${data.summary.total} total messages · ${data.summary.unread} unread`;
            document.getElementById('contactPage').textContent = `Page ${page} of ${pages} · ${data.total} matching messages`;
            previous.disabled = page <= 1; next.disabled = page >= pages;
        } catch (error) {
            if (current === generation) {
                empty('Messages could not be loaded. Use Search to retry.');
                document.getElementById('contactPage').textContent = '';
                show(error.message);
            }
        } finally {
            if (current === generation) root.removeAttribute('aria-busy');
        }
    };
    filters.addEventListener('submit', event => {
        event.preventDefault(); page = 1; feedback.classList.add('d-none'); load();
    });
    previous.addEventListener('click', () => { if (page > 1) { page--; load(); } });
    next.addEventListener('click', () => { if (page < pages) { page++; load(); } });
    rows.addEventListener('click', async event => {
        const button = event.target.closest('button[data-action]');
        if (!button || mutating) return;
        const action = button.dataset.action;
        if (action === 'delete' && !window.confirm('Permanently delete this contact message?')) return;
        mutating = true; button.disabled = true;
        feedback.classList.add('d-none');
        try {
            const data = await request(root.dataset.api, {
                method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRF-Token': root.dataset.csrf},
                body: JSON.stringify({action, id: button.dataset.id})
            });
            if (action === 'open') {
                document.querySelectorAll('[data-contact-detail]').forEach(element => {
                    element.textContent = data.data[element.dataset.contactDetail] || '—';
                });
                modal.show();
            } else show(data.message, true);
            await load();
        } catch (error) { show(error.message); }
        finally { mutating = false; button.disabled = false; }
    });
    load();
})();
