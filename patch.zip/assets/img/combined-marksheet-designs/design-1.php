<?php
include_once(__DIR__ . '/../../../includes/config.php');

$stmt = $pdo->prepare("SELECT * FROM settings_marksheet LIMIT 1");
$stmt->execute();
$marksheet_settings = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$marksheet_settings) {
    die("Marksheet settings not found");
}

// School information
$school_name = $schoolInfo['name'];
$school_address = $schoolInfo['address'];
$school_phone = $schoolInfo['phone'];
$school_email = $schoolInfo['email'];

$school_logo_path = __DIR__ . '/../../../uploads/school/logo-square.png';
$school_logo_base64 = imageToBase64($school_logo_path);

$principal_sign_path = __DIR__ . '/../../../uploads/school/principle_sign.png';
$principal_sign_base64 = imageToBase64($principal_sign_path);

$primary_theme_color = $marksheet_settings['primary_theme_color'];
$dark_theme_color = $marksheet_settings['dark_theme_color'];
$light_theme_color = $marksheet_settings['light_theme_color'];
$background_color = $marksheet_settings['background_color'];
$school_name_text_color = $marksheet_settings['school_name_text_color'];
$school_address_text_color = $marksheet_settings['school_address_text_color'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Marksheet</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&family=Tinos:wght@700&display=swap');

        @page {
            size: A4 portrait;
            margin: 0;
        }

        html {
            margin: 0;
            padding: 0;
        }

        body {
            margin: 0;
            padding: 0;
        }

        * {
            box-sizing: border-box;
        }

        .marksheet-container {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            color: #333;
            background-color: <?=$background_color?>;
            width: 210mm;
            height: 297mm;
            padding: 7mm;
            break-after: always;
        }

        .marksheet {
            border: 1px solid <?=$dark_theme_color?>;
            padding: 3mm;
            overflow: hidden;
            position: relative;
            width: 100%;
            height: 100%;
            background-color: <?=$background_color?>;
            box-shadow: 0 0 15px rgba(58, 74, 109, 0.2);
            border-radius: 5px;
        }

        .header {
            width: 100%;
            height: 30mm;
            background: linear-gradient(135deg, <?=$primary_theme_color?> 0%, <?=$dark_theme_color?> 100%);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            display: flex;
            padding: 3mm;
            align-items: center;
            justify-content: center;
            gap: 3mm;
            border-radius: 3px;
        }

        .header img {
            background: white;
            width: 15mm;
            height: 15mm;
            border: 2px solid white;
            border-radius: 50%;
            object-fit: cover;
        }

        .school-name-container {
            height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
            color: white;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }

        .marks-tables-container:has(:nth-child(5):last-child) :nth-child(5) {
            grid-column: span 2;
        }

        .school-name-container h1 {
            margin: 0;
            padding: 0;
            font-size: 1.6rem;
            text-transform: uppercase;
            text-align: center;
            font-weight: 700;
            letter-spacing: 0.5px;
        }

        .school-name-container p {
            font-size: 0.8rem;
            margin: 0;
            line-height: 1.3;
            color: #d1e0ff;
            text-align: center;
        }

        .school-name-container p:first-of-type {
            padding: 1mm;
        }

        .student-info {
            background: <?=$light_theme_color?>;
            overflow: hidden;
            height: 24mm;
            border-radius: 4px;
            border: 1px solid #d6e0f5;
            padding: 2mm;
            margin-top: 2mm;
        }

        .student-info .details-left {
            float: left;
            height: 100%;
            width: calc(100% - 30mm);
        }

        .student-info .details-left table {
            border-collapse: collapse;
            width: 100%;
            height: 100%;
            text-align: left;
            font-size: 13px;
        }

        .student-info .details-left table th {
            color: <?=$dark_theme_color?>;
            font-weight: 600;
            white-space: nowrap;
            width: 1%;
            padding-right: 1mm;
        }

        .student-info .details-left table td {
            padding: 0 7mm 0 2mm;
            color: #333;
            font-weight: 500;
        }

        .student-info .photo-right {
            width: 25mm;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            float: right;
            margin-right: 5mm;
        }

        .student-info .photo-right .photo {
            width: 20mm;
            height: 100%;
            border: 1px solid <?=$dark_theme_color?>;
            border-radius: 5px;
            overflow: hidden;
            background: white;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .student-info .photo-right img {
            height: 100%;
            object-fit: cover;
        }

        .marks-tables-container {
            width: 100%;
            height: 185mm;
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            grid-auto-rows: auto auto;
            gap: 1.2mm;
            overflow: hidden;
            margin-top: 1.5mm;
            margin-bottom: 1.5mm;
        }

        .marks-tables-container>.marks-table {
            width: 100%;
            height: 100%;
            background: white;
            font-size: 12px;
            overflow: visible;
            display: flex;
            flex-direction: column;
            border-radius: 4px;
            border: 1px solid #e0e6f0;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }

        .marks-table .marks-table-exam-name {
            width: 100%;
            text-align: center;
            padding: 1mm 0;
            font-weight: bold;
            background: linear-gradient(to right, <?=$primary_theme_color?> 0%, <?=$primary_theme_color?> 70%, <?=$dark_theme_color?> 100%);
            color: white;
            border-radius: 3px 3px 0 0;
        }

        .marks-table table {
            width: 100%;
            height: 100%;
            border-collapse: collapse;
            font-size: 12px;
        }

        .marks-table table th,
        .marks-table table td {
            padding: 2px 4px;
            border: 1px solid #ddd;
            text-align: center;
        }

        .marks-table table th {
            font-weight: bold;
            background-color: #f0f5ff;
            color: <?=$dark_theme_color?>;
            font-weight: 600;
            text-align: center;
        }

        .marks-table table tr:nth-child(even) {
            background-color: #f9f9ff;
        }

        .marks-table-overall .marks-table-exam-name {
            background: linear-gradient(to right, #62e364, #047807);
        }

        .grade-system-table .marks-table-exam-name {
            background: linear-gradient(to right, #50a4b3, #0b7385);
        }

        .summary-table {
            width: 100%;
            border-collapse: collapse;
            background: <?=$light_theme_color?>;
            overflow: hidden;
            height: 15mm;
            border-radius: 4px;
            border: 1px solid #d6e0f5;
            padding: 1mm;
            margin-top: 1mm;
        }

        .summary-table table {
            width: 100%;
            height: 100%;
            text-align: left;
            font-size: 13px;
        }

        .summary-table table th {
            color: <?=$dark_theme_color?>;
            font-weight: 600;
            white-space: nowrap;
        }

        .signatures {
            width: 100%;
            position: absolute;
            bottom: 2.5mm;
            left: 0;
            font-size: 14px;
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            padding: 0 3mm;
        }

        .signatures img {
            width: 22mm;
        }

        .signatures p {
            text-align: center;
            margin: 0;
            padding: 0;
        }

        .signatures>div {
            display: flex;
            align-items: flex-end;
            justify-content: center;
        }

        .signatures>div>div {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
    </style>
</head>

<body>
    <div class="marksheet-container">
        <div class="marksheet">

            <div class="header">
                <img src="<?=$school_logo_base64?>" alt="School Logo">
                <div class="school-name-container">
                    <h1><?=$school_name?></h1>
                    <p><?=$school_address?></p>
                    <p>Phone: <?=$school_phone?> | Email: <?=$school_email?></p>
                </div>
            </div>

            <!-- <div class="title">
                <span>MARKSHEET</span>
            </div> -->

            <div class="student-info">
                <div class="details-left">
                    <table>
                        <tr>
                            <th>Student ID:</th>
                            <td>STU20253937</td>
                            <th>Roll No:</th>
                            <td>2</td>
                        </tr>
                        <tr>
                            <th>Student Name:</th>
                            <td>XYZ St</td>
                            <th>Father's Name:</th>
                            <td>ABC Ft</td>
                        </tr>
                        <tr>
                            <th>Class:</th>
                            <td>Three - B</td>
                        </tr>
                    </table>
                </div>
                <div class="photo-right">
                    <div class="photo">
                        <img src="data:image/jpg;base64,/9j/4RLhRXhpZgAATU0AKgAAAAgABwESAAMAAAABAAEAAAEaAAUAAAABAAAAYgEbAAUAAAABAAAAagEoAAMAAAABAAIAAAExAAIAAAAfAAAAcgEyAAIAAAAUAAAAkYdpAAQAAAABAAAAqAAAANQALcbAAAAnEAAtxsAAACcQQWRvYmUgUGhvdG9zaG9wIDI0LjIgKFdpbmRvd3MpADIwMjU6MDU6MjMgMTQ6MzY6NTYAAAAAAAOgAQADAAAAAQABAACgAgAEAAAAAQAAAfSgAwAEAAAAAQAAAlgAAAAAAAAABgEDAAMAAAABAAYAAAEaAAUAAAABAAABIgEbAAUAAAABAAABKgEoAAMAAAABAAIAAAIBAAQAAAABAAABMgICAAQAAAABAAARpwAAAAAAAABIAAAAAQAAAEgAAAAB/9j/7QAMQWRvYmVfQ00AAf/uAA5BZG9iZQBkgAAAAAH/2wCEAAwICAgJCAwJCQwRCwoLERUPDAwPFRgTExUTExgRDAwMDAwMEQwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwBDQsLDQ4NEA4OEBQODg4UFA4ODg4UEQwMDAwMEREMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDP/AABEIAJAAeAMBIgACEQEDEQH/3QAEAAj/xAE/AAABBQEBAQEBAQAAAAAAAAADAAECBAUGBwgJCgsBAAEFAQEBAQEBAAAAAAAAAAEAAgMEBQYHCAkKCxAAAQQBAwIEAgUHBggFAwwzAQACEQMEIRIxBUFRYRMicYEyBhSRobFCIyQVUsFiMzRygtFDByWSU/Dh8WNzNRaisoMmRJNUZEXCo3Q2F9JV4mXys4TD03Xj80YnlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vY3R1dnd4eXp7fH1+f3EQACAgECBAQDBAUGBwcGBTUBAAIRAyExEgRBUWFxIhMFMoGRFKGxQiPBUtHwMyRi4XKCkkNTFWNzNPElBhaisoMHJjXC0kSTVKMXZEVVNnRl4vKzhMPTdePzRpSkhbSVxNTk9KW1xdXl9VZmdoaWprbG1ub2JzdHV2d3h5ent8f/2gAMAwEAAhEDEQA/APVUkkklKSSUXvZWx1ljgxjAXOc4wABq5znFJTJc/wDWT679E+rx9HIe7IzSJbh0Q54BHtdc5xbXjs/41/8AxTLFyX1w/wAZb7TZ036uWFlf0LepDl377cHd/m/a/wD2F/weQvPDqXOJJc8lznEyS4/Se9x9znO/eSU9vnf42uv3OcMHFxsOs8epvvsH9qcar/wJZv8A45H103T9ur/q/Z64/wDJf9Nc0kip9B6L/jazGXNq67jV2Y5IDsrFDmvYP37MZ7rPWb+/6Nlf/E2r0vHyKcmivIx3i2m5ofVY0y1zXDcx7T/KavnRXsX6y/WHF6fV0zD6hbi4dBc6uumGEb3Gx/6VrfV+m/6G9JT9ApLxXo3+MT6zdLsb62Qep4w+nRkxvI/4LLa31WP/AON9ar/g1610PrvTuu4DM/p9m+t2j63aWVvH0qb69dlrP/UlXqVe9BToJJJJKUkkkkp//9D1VJJJJSxEgg99NNPyLxv6/wDUrX57+kVdYyepY2Odl9NgrbUx7dv6CyzGbT9vuqe39J69X6D9+3I9X0/T/rZ1OzpX1b6jn1HbdTQ70XDtY/8ARUO/s2vYvBGtDQGjt/rKSl0kkkUKSJA5SBkT93wWh076vu6li/abMl2OxznNY1jA4kN0LtxezZ7/AGoSkIiyV8ISmaiLLnFwA05TMHt+K1j9SfTdvx873DtZXAP9ZzLH/wDUKll9M6jgEHJrHok7W3Vu31kn82Ya+t//ABjE2OWEjQK6eHJEWY6fb+SBWcDq3UukZH2vpuS/FuiHPYRBHZt1dgdTaz/jmexVktODwdE9jfbvqjX9cH1WZX1nuY17gGUYdba/aASXZF9lG9rrbfbsZVb6TK/+E+h0S5X/ABZ5t2V9UcZtxLjivsxmOPJZW4ikf9bq2Vf9bXVIKUkkkkp//9H1VJJJJTgfX3Efl/U/qlVYlzafWjxFLm5Tv+jSvDiC1zg76QOoGvaf4r6P50K8P+vv1fv6L9YMl5b+p9Qsdk4lgEN95334/wDJfRY76H+h9JJTz+9qudL6Zd1K7vXiVn9Nb4x/gqv3rnf+BJ+iYOLmX3OzCfs+OwPeASJc4+1r9vv27Wv+h710rbsxrW14vReoPoYIrNeM5jI/kMdHtUc5y1jAXL8mfFihQnkkBHoP3qeX6hhWYGS6qwfoySaX9ns/Nh377f8ACNW79W7mP6b9nB/SYznBze+17jZXZ/V9+xWhmVW2fY8zFvxX2fRpzaSxryPza/U9j7FKvp3T6rW3U47K7WzteyWxOh0adqiyZLjwzBEhqz4sQjPjxyEoHSmwsv6y3Mr6aKnH3XWN2jyrPqPd/wBQz/ritZPUqKMgYra7srKIDjRjMNjwD9H1A36O5Q2ZDskZdvQeoi0ABt7sd7y0D/R1f4P/AK2xNxwlYlwkgar8uSFGHGBI+k307vK3UXY9ppvYa7AGuLTzteN7P+ip4mJdnZVWJQ0utuJgNBcYY111jtjfc7ZVW960frMGHIxMlpgXVurO4Fplh3t3MeGva79K76S7f/FZ9WBVjn6x5TZtyWmvBYRqymf0mR7vz8pzfZ/3W/8ADCtQlxRB+1o5IcEzEagbeR2em+pfSbej/VnBwrwW5Gw25DSIIsuc7Isrd/xLrPR/62txJJFYpJJJJT//0vVUkkklKXFf4wcirPYOgua0sIF1tpEuY/X0PRP5j2fTf++z9F/N+qu1XL/W7odl3+VMUFz62BuTUOSxurba/wCXXPvZ+fX/AMX+kjy8XCeFl5fg9wcex77W8z0zLqwvq9jOwMSrDzmOdiZb2MbuN2M0epd6u3fb9o9RlrLLP9Kq31w6hm9CyumH7fk5eJntF114DW/opbvZib9zPtHpO3fpnPZ/Nqxij7TiXY9bd11doymBupe1zBTcxjfz7Km01W/y61FuU844xbG1ZOK125uPkVsuY1x5dWLBvq/629QnJZuWsSBp4/pNqOGgYxNSiTrXq4ZfIyweqZ93TW9SabMvot976a2ZbZPsh9QyWe6rfZ9GvKxdlTMmv0v9GtCzpGAcllbMs1G8B9VDgHPh2rWteXf5m9VRk9Q6kGdPFgbjM/wNTW1UVsB3OsfXS1jNlX0v0iFmZPrZr8mnRoc30J/drhtP/UbkDKNWRcbHCJf8/hSITuhIRlR4jEb/AOb4/wDnpM3IycDB6hf00HC6X06xozLKWk3XPe5rbner/hsnY71N99noUb8avZ/oM/6p9RyvrD1vNxas7KxsKit1+Pe/YXhjXMb+u7NtW5zXbv0Llr5Gdm4r7LsS0tweoS/03Br6iXj9Yosqta+v1Gu3Ms/fYqP2p7MezHoZTiY9xBuqxqmUtfEx6prG+xvu+hv9NOOSIsEEn+Xy/wBVEcUiAYkAVtWvjx/14ybmN1CrKbYzq9NfUaKqrMhpvrZY6KgHOb+lDv52tan1M6xcy5nR7/5jZ+ptBn0wwT9lDj9KplQ/RfuemsIfq+DddYIdmN+z4wOm4Eh+Td/xTa6/T3/vrovqj0SwPb1fJG0Fp+yMPJDtHZDv67PbV/I96UJTJgL21P8AdKMkMcY5CQBZqP8AeiP0f8L53rEkklZaKkkkklP/0/VUkkklKSSSSU+f9d6Bk9Kyn5VQH2J7/wBDYww6sk7q6nN+k3ZLmVWMVE5+Q4zaK7nfvW1Me75v273f2l6L1HBq6hhXYdpIba2Nw5aQdzHj+o9u9ec5mHk4OS/Eym7bWa6fRc0/Rtr/AODf/wCo1VywMDcbET+bfwZBlFTozj/0VXZuVbSaS8MqP+Dra2thP8tlQbv/ALSql2ROlbY/rf6/9SisDS6HO2jtp/FG9CqOR8ZUWp3LYAEdAAGGPlZOO1wrs2h/02QHMd/WrsDmO/zVP7dcDLWUMd+82msH8WuQrG1t0Y6T94+9Pj49+TezGx2epdaYYz8rnH81jPz3o3LYEoMY6kgeJP7XQ6V0bN65mNvucXYtbtuTe90uMBp9Ctv8qt3/ABdW9eggACBoBwFT6R02vpmBXiMO9zZdZZxue73WP/8AIfyFdVrHDhGvzH5nOz5eOVD5Y6R8lJJJKRiUkkkkp//U9VSSSSUpJJJJSlzf1ryug247qcu2MqiSx9Q3urJ59T6Nex3+EofZ7/6/pq19YOo31ur6fiPNdtzS+61v0mVTs/R/8Lc/2Mf+Z71511i+t+S7HoAbRQdgA/OcPp2PP53uVLmOZPH7MACf05S2j5f1nQ5TlAYjLMkdYRjv5yP7rYa4OaCE8BM5mstO1w0kfxUYu/eb8YUdthk5wY0udwBJXV/VHL6BTUAy0/bciA620bQf+Bpd7mNY13+D3erYuRfXuY7c4uO0x2HCB0rIqqy623gOx7iGWNPALvayz+y5A5JQ9UAJEfoy6/8AoSfahkiYzMh4w/l6n2FJc/8AV/PtrvPTMh5ezaX4r3mXQ3SzHe78/wBPdur/AOD/AKi6BXsOaOWAnHruOxcvPhOKZgTfWMv3oqSSSUjEpJJJJT//1fVUkkklKVbqGU7ExLL2N3ObAaDxLiGAu/kt3Kvn9YpxSaqh6t45E+1v9d3/AHxYOXlZWZrdaSQdzANGNI49gVLmuehjEoQPFkoj07Ql5tvl+UlMxlIcMLB1/Siil7suzIeS+y4NLnHkls/+YLkcXHre2u55LzY31IOgl3v1/e+kutrfu9w9rmmHNPLXfurnsjG+w5LseP0Uutxz41OP6Sv+vi2P2/8AE+iqnIcEvejLXKYieO/6nqy/3pcLa5qeSE8JB4cXF7eTbrHgw/3YqSSSUy9Sp3YVbm2FjtkTpyNBP9ZXCQBJ0A5Ua8Z+Y4Yglpvk3OHLKv8ADO/rOb+gr/4Sz+QpuXjAylLKP1cImUy1+by5IQiMRrLOYjDrffSX6LuN35NeHc17q37W3eo3RzSWN+j/ACnOcuu6Pl35WHvvg2McWF4EB8RFm3836Xv/AJa5h72VMLj7WNgBo+5lbAiYl+Vik2V2Fljzue0at8Gs2n2u2N9qzeV5n2chJvglvENnmMJy4hHTij8siP8AGexSWZgdbryHNpyAKrXaNI+g4+A/cd/JctNbWLLDLHigeIfl5uTkxzxy4ZiipJJJSLH/1vVVV6llHFw7LW/TjbX/AFne1v8Am/SVpYn1iul1OODxNjh/0Gf+jFBzWT28M5DQ1Uf70vSy8vj48sYna7PlFx/x8ykkkufdphZW4uFlZDbQI1+i4fuWf99f+Yq2XQ3PodSP0OVUfUq3fmPGjXafzmPZ/NWf8GrihYwPAJ0czVjhy0+X/fmp0JyhITieGUTxA+SJxjkgYTFxkOF5qt25m5oNZktfWddr2nZZWf6jwpzZ+8Pu/wBqs9brbj9fyGsbsryh6rR29Rga2xzP+Mq2f26VWXTww4MsRMwFmxLhMhHjieCfy/13nZ81zOGRx+4aABjxCM5cE48cNZR/cYvLWNNtpLgwSf8AzFv77vosWxh1N6fjb8j+k3w6xrdTP5mOz+RRu27v9L6ln+EWRVNnUKKWt3mucgs7FzfZjB38ltv6f/rC6fIoqbm22gS4Q1p/dAa1vs/rLO+KzEYjBjqMYmMsgH6Up8ft3/d9v/0m3/hkZTl94zkzMhIYvKHDx1+5xe5/6UQVV2ueL8jR4/m6hwwHv/xqMkksd1SbUQCIOoK6Xo+U7Jwm7zusqPpvJ5MfRd/aYuaWp9X7tmVZSeLWbh8WH/yL1b5DJwZwOk/Sf+5avOY+LCT1h6h/3TvpJJLccl//1/VVy/VrfV6hcZkMisf2R7v+m566dxDQXHgCSuPcbLHOsc102EvOh5cdyzvik/RCH7xMv8T/ANHb3w+PqnLsOH/G/wDRUOQ4toeRzo0fFzms/wC/IrvpH4oOY1/oaNd/OVdj/pGI5a+T7T9xWVRdHoxSidPHT70+1/7p+4qdFb3X1jadXt5EDnxKMYmREe5r7UGVAnsLcr6zAONF4GteWGz/ACbA+hzfxYsta/X6rPsYbtLnDJpnaCRpa3dBassV2z/Nv/zXf3LovhkjLBMn/Oz/AOdwz/7p5/4lHhzRA/zcPw9Kf6v1h+R1HJ5IsbjM8hWzc/8Azn2LeuM2l37wa772tWJ9V2WDEzNzHA/bLTq0+DPJbt9VjTWCJJrafb7vEfmrJ58mWfmP78P+ZCWN1OSoYcH9yf8AzpRmiST7H/uu+4pbH/uu+4qlRblo6XbmvB5bY9v3OMf9Eq1g2+jm0WcAPAPwd+jP/VKnjtfuyPa7+ffGh8GIpY+DDXT20KMSYyEgNYkSH+CqQEgYnaQr/GezSQ8e31qK7ePUaHR8RKS6TiHDxdK4vo4XCb4et0//2f/tGvZQaG90b3Nob3AgMy4wADhCSU0EJQAAAAAAEAAAAAAAAAAAAAAAAAAAAAA4QklNBDoAAAAAAOUAAAAQAAAAAQAAAAAAC3ByaW50T3V0cHV0AAAABQAAAABQc3RTYm9vbAEAAAAASW50ZWVudW0AAAAASW50ZQAAAABDbHJtAAAAD3ByaW50U2l4dGVlbkJpdGJvb2wAAAAAC3ByaW50ZXJOYW1lVEVYVAAAAAEAAAAAAA9wcmludFByb29mU2V0dXBPYmpjAAAADABQAHIAbwBvAGYAIABTAGUAdAB1AHAAAAAAAApwcm9vZlNldHVwAAAAAQAAAABCbHRuZW51bQAAAAxidWlsdGluUHJvb2YAAAAJcHJvb2ZDTVlLADhCSU0EOwAAAAACLQAAABAAAAABAAAAAAAScHJpbnRPdXRwdXRPcHRpb25zAAAAFwAAAABDcHRuYm9vbAAAAAAAQ2xicmJvb2wAAAAAAFJnc01ib29sAAAAAABDcm5DYm9vbAAAAAAAQ250Q2Jvb2wAAAAAAExibHNib29sAAAAAABOZ3R2Ym9vbAAAAAAARW1sRGJvb2wAAAAAAEludHJib29sAAAAAABCY2tnT2JqYwAAAAEAAAAAAABSR0JDAAAAAwAAAABSZCAgZG91YkBv4AAAAAAAAAAAAEdybiBkb3ViQG/gAAAAAAAAAAAAQmwgIGRvdWJAb+AAAAAAAAAAAABCcmRUVW50RiNSbHQAAAAAAAAAAAAAAABCbGQgVW50RiNSbHQAAAAAAAAAAAAAAABSc2x0VW50RiNQeGxAcsAAAAAAAAAAAAp2ZWN0b3JEYXRhYm9vbAEAAAAAUGdQc2VudW0AAAAAUGdQcwAAAABQZ1BDAAAAAExlZnRVbnRGI1JsdAAAAAAAAAAAAAAAAFRvcCBVbnRGI1JsdAAAAAAAAAAAAAAAAFNjbCBVbnRGI1ByY0BZAAAAAAAAAAAAEGNyb3BXaGVuUHJpbnRpbmdib29sAAAAAA5jcm9wUmVjdEJvdHRvbWxvbmcAAAAAAAAADGNyb3BSZWN0TGVmdGxvbmcAAAAAAAAADWNyb3BSZWN0UmlnaHRsb25nAAAAAAAAAAtjcm9wUmVjdFRvcGxvbmcAAAAAADhCSU0D7QAAAAAAEAEsAAAAAQACASwAAAABAAI4QklNBCYAAAAAAA4AAAAAAAAAAAAAP4AAADhCSU0EDQAAAAAABAAAAFo4QklNBBkAAAAAAAQAAAAeOEJJTQPzAAAAAAAJAAAAAAAAAAABADhCSU0nEAAAAAAACgABAAAAAAAAAAI4QklNA/UAAAAAAEgAL2ZmAAEAbGZmAAYAAAAAAAEAL2ZmAAEAoZmaAAYAAAAAAAEAMgAAAAEAWgAAAAYAAAAAAAEANQAAAAEALQAAAAYAAAAAAAE4QklNA/gAAAAAAHAAAP////////////////////////////8D6AAAAAD/////////////////////////////A+gAAAAA/////////////////////////////wPoAAAAAP////////////////////////////8D6AAAOEJJTQQAAAAAAAACAAE4QklNBAIAAAAAAAQAAAAAOEJJTQQwAAAAAAACAQE4QklNBC0AAAAAAAYAAQAAAAI4QklNBAgAAAAAABAAAAABAAACQAAAAkAAAAAAOEJJTQREAAAAAAAQAAAAAgAAAkAAAAJAAAAAADhCSU0EHgAAAAAABAAAAAA4QklNBBoAAAAAA0kAAAAGAAAAAAAAAAAAAAJYAAAB9AAAAAoAVQBuAHQAaQB0AGwAZQBkAC0AMQAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAB9AAAAlgAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAQAAAAAAAG51bGwAAAACAAAABmJvdW5kc09iamMAAAABAAAAAAAAUmN0MQAAAAQAAAAAVG9wIGxvbmcAAAAAAAAAAExlZnRsb25nAAAAAAAAAABCdG9tbG9uZwAAAlgAAAAAUmdodGxvbmcAAAH0AAAABnNsaWNlc1ZsTHMAAAABT2JqYwAAAAEAAAAAAAVzbGljZQAAABIAAAAHc2xpY2VJRGxvbmcAAAAAAAAAB2dyb3VwSURsb25nAAAAAAAAAAZvcmlnaW5lbnVtAAAADEVTbGljZU9yaWdpbgAAAA1hdXRvR2VuZXJhdGVkAAAAAFR5cGVlbnVtAAAACkVTbGljZVR5cGUAAAAASW1nIAAAAAZib3VuZHNPYmpjAAAAAQAAAAAAAFJjdDEAAAAEAAAAAFRvcCBsb25nAAAAAAAAAABMZWZ0bG9uZwAAAAAAAAAAQnRvbWxvbmcAAAJYAAAAAFJnaHRsb25nAAAB9AAAAAN1cmxURVhUAAAAAQAAAAAAAG51bGxURVhUAAAAAQAAAAAAAE1zZ2VURVhUAAAAAQAAAAAABmFsdFRhZ1RFWFQAAAABAAAAAAAOY2VsbFRleHRJc0hUTUxib29sAQAAAAhjZWxsVGV4dFRFWFQAAAABAAAAAAAJaG9yekFsaWduZW51bQAAAA9FU2xpY2VIb3J6QWxpZ24AAAAHZGVmYXVsdAAAAAl2ZXJ0QWxpZ25lbnVtAAAAD0VTbGljZVZlcnRBbGlnbgAAAAdkZWZhdWx0AAAAC2JnQ29sb3JUeXBlZW51bQAAABFFU2xpY2VCR0NvbG9yVHlwZQAAAABOb25lAAAACXRvcE91dHNldGxvbmcAAAAAAAAACmxlZnRPdXRzZXRsb25nAAAAAAAAAAxib3R0b21PdXRzZXRsb25nAAAAAAAAAAtyaWdodE91dHNldGxvbmcAAAAAADhCSU0EKAAAAAAADAAAAAI/8AAAAAAAADhCSU0EFAAAAAAABAAAAAI4QklNBAwAAAAAEcMAAAABAAAAeAAAAJAAAAFoAADKgAAAEacAGAAB/9j/7QAMQWRvYmVfQ00AAf/uAA5BZG9iZQBkgAAAAAH/2wCEAAwICAgJCAwJCQwRCwoLERUPDAwPFRgTExUTExgRDAwMDAwMEQwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwBDQsLDQ4NEA4OEBQODg4UFA4ODg4UEQwMDAwMEREMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDP/AABEIAJAAeAMBIgACEQEDEQH/3QAEAAj/xAE/AAABBQEBAQEBAQAAAAAAAAADAAECBAUGBwgJCgsBAAEFAQEBAQEBAAAAAAAAAAEAAgMEBQYHCAkKCxAAAQQBAwIEAgUHBggFAwwzAQACEQMEIRIxBUFRYRMicYEyBhSRobFCIyQVUsFiMzRygtFDByWSU/Dh8WNzNRaisoMmRJNUZEXCo3Q2F9JV4mXys4TD03Xj80YnlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vY3R1dnd4eXp7fH1+f3EQACAgECBAQDBAUGBwcGBTUBAAIRAyExEgRBUWFxIhMFMoGRFKGxQiPBUtHwMyRi4XKCkkNTFWNzNPElBhaisoMHJjXC0kSTVKMXZEVVNnRl4vKzhMPTdePzRpSkhbSVxNTk9KW1xdXl9VZmdoaWprbG1ub2JzdHV2d3h5ent8f/2gAMAwEAAhEDEQA/APVUkkklKSSUXvZWx1ljgxjAXOc4wABq5znFJTJc/wDWT679E+rx9HIe7IzSJbh0Q54BHtdc5xbXjs/41/8AxTLFyX1w/wAZb7TZ036uWFlf0LepDl377cHd/m/a/wD2F/weQvPDqXOJJc8lznEyS4/Se9x9znO/eSU9vnf42uv3OcMHFxsOs8epvvsH9qcar/wJZv8A45H103T9ur/q/Z64/wDJf9Nc0kip9B6L/jazGXNq67jV2Y5IDsrFDmvYP37MZ7rPWb+/6Nlf/E2r0vHyKcmivIx3i2m5ofVY0y1zXDcx7T/KavnRXsX6y/WHF6fV0zD6hbi4dBc6uumGEb3Gx/6VrfV+m/6G9JT9ApLxXo3+MT6zdLsb62Qep4w+nRkxvI/4LLa31WP/AON9ar/g1610PrvTuu4DM/p9m+t2j63aWVvH0qb69dlrP/UlXqVe9BToJJJJKUkkkkp//9D1VJJJJSxEgg99NNPyLxv6/wDUrX57+kVdYyepY2Odl9NgrbUx7dv6CyzGbT9vuqe39J69X6D9+3I9X0/T/rZ1OzpX1b6jn1HbdTQ70XDtY/8ARUO/s2vYvBGtDQGjt/rKSl0kkkUKSJA5SBkT93wWh076vu6li/abMl2OxznNY1jA4kN0LtxezZ7/AGoSkIiyV8ISmaiLLnFwA05TMHt+K1j9SfTdvx873DtZXAP9ZzLH/wDUKll9M6jgEHJrHok7W3Vu31kn82Ya+t//ABjE2OWEjQK6eHJEWY6fb+SBWcDq3UukZH2vpuS/FuiHPYRBHZt1dgdTaz/jmexVktODwdE9jfbvqjX9cH1WZX1nuY17gGUYdba/aASXZF9lG9rrbfbsZVb6TK/+E+h0S5X/ABZ5t2V9UcZtxLjivsxmOPJZW4ikf9bq2Vf9bXVIKUkkkkp//9H1VJJJJTgfX3Efl/U/qlVYlzafWjxFLm5Tv+jSvDiC1zg76QOoGvaf4r6P50K8P+vv1fv6L9YMl5b+p9Qsdk4lgEN95334/wDJfRY76H+h9JJTz+9qudL6Zd1K7vXiVn9Nb4x/gqv3rnf+BJ+iYOLmX3OzCfs+OwPeASJc4+1r9vv27Wv+h710rbsxrW14vReoPoYIrNeM5jI/kMdHtUc5y1jAXL8mfFihQnkkBHoP3qeX6hhWYGS6qwfoySaX9ns/Nh377f8ACNW79W7mP6b9nB/SYznBze+17jZXZ/V9+xWhmVW2fY8zFvxX2fRpzaSxryPza/U9j7FKvp3T6rW3U47K7WzteyWxOh0adqiyZLjwzBEhqz4sQjPjxyEoHSmwsv6y3Mr6aKnH3XWN2jyrPqPd/wBQz/ritZPUqKMgYra7srKIDjRjMNjwD9H1A36O5Q2ZDskZdvQeoi0ABt7sd7y0D/R1f4P/AK2xNxwlYlwkgar8uSFGHGBI+k307vK3UXY9ppvYa7AGuLTzteN7P+ip4mJdnZVWJQ0utuJgNBcYY111jtjfc7ZVW960frMGHIxMlpgXVurO4Fplh3t3MeGva79K76S7f/FZ9WBVjn6x5TZtyWmvBYRqymf0mR7vz8pzfZ/3W/8ADCtQlxRB+1o5IcEzEagbeR2em+pfSbej/VnBwrwW5Gw25DSIIsuc7Isrd/xLrPR/62txJJFYpJJJJT//0vVUkkklKXFf4wcirPYOgua0sIF1tpEuY/X0PRP5j2fTf++z9F/N+qu1XL/W7odl3+VMUFz62BuTUOSxurba/wCXXPvZ+fX/AMX+kjy8XCeFl5fg9wcex77W8z0zLqwvq9jOwMSrDzmOdiZb2MbuN2M0epd6u3fb9o9RlrLLP9Kq31w6hm9CyumH7fk5eJntF114DW/opbvZib9zPtHpO3fpnPZ/Nqxij7TiXY9bd11doymBupe1zBTcxjfz7Km01W/y61FuU844xbG1ZOK125uPkVsuY1x5dWLBvq/629QnJZuWsSBp4/pNqOGgYxNSiTrXq4ZfIyweqZ93TW9SabMvot976a2ZbZPsh9QyWe6rfZ9GvKxdlTMmv0v9GtCzpGAcllbMs1G8B9VDgHPh2rWteXf5m9VRk9Q6kGdPFgbjM/wNTW1UVsB3OsfXS1jNlX0v0iFmZPrZr8mnRoc30J/drhtP/UbkDKNWRcbHCJf8/hSITuhIRlR4jEb/AOb4/wDnpM3IycDB6hf00HC6X06xozLKWk3XPe5rbner/hsnY71N99noUb8avZ/oM/6p9RyvrD1vNxas7KxsKit1+Pe/YXhjXMb+u7NtW5zXbv0Llr5Gdm4r7LsS0tweoS/03Br6iXj9Yosqta+v1Gu3Ms/fYqP2p7MezHoZTiY9xBuqxqmUtfEx6prG+xvu+hv9NOOSIsEEn+Xy/wBVEcUiAYkAVtWvjx/14ybmN1CrKbYzq9NfUaKqrMhpvrZY6KgHOb+lDv52tan1M6xcy5nR7/5jZ+ptBn0wwT9lDj9KplQ/RfuemsIfq+DddYIdmN+z4wOm4Eh+Td/xTa6/T3/vrovqj0SwPb1fJG0Fp+yMPJDtHZDv67PbV/I96UJTJgL21P8AdKMkMcY5CQBZqP8AeiP0f8L53rEkklZaKkkkklP/0/VUkkklKSSSSU+f9d6Bk9Kyn5VQH2J7/wBDYww6sk7q6nN+k3ZLmVWMVE5+Q4zaK7nfvW1Me75v273f2l6L1HBq6hhXYdpIba2Nw5aQdzHj+o9u9ec5mHk4OS/Eym7bWa6fRc0/Rtr/AODf/wCo1VywMDcbET+bfwZBlFTozj/0VXZuVbSaS8MqP+Dra2thP8tlQbv/ALSql2ROlbY/rf6/9SisDS6HO2jtp/FG9CqOR8ZUWp3LYAEdAAGGPlZOO1wrs2h/02QHMd/WrsDmO/zVP7dcDLWUMd+82msH8WuQrG1t0Y6T94+9Pj49+TezGx2epdaYYz8rnH81jPz3o3LYEoMY6kgeJP7XQ6V0bN65mNvucXYtbtuTe90uMBp9Ctv8qt3/ABdW9eggACBoBwFT6R02vpmBXiMO9zZdZZxue73WP/8AIfyFdVrHDhGvzH5nOz5eOVD5Y6R8lJJJKRiUkkkkp//U9VSSSSUpJJJJSlzf1ryug247qcu2MqiSx9Q3urJ59T6Nex3+EofZ7/6/pq19YOo31ur6fiPNdtzS+61v0mVTs/R/8Lc/2Mf+Z71511i+t+S7HoAbRQdgA/OcPp2PP53uVLmOZPH7MACf05S2j5f1nQ5TlAYjLMkdYRjv5yP7rYa4OaCE8BM5mstO1w0kfxUYu/eb8YUdthk5wY0udwBJXV/VHL6BTUAy0/bciA620bQf+Bpd7mNY13+D3erYuRfXuY7c4uO0x2HCB0rIqqy623gOx7iGWNPALvayz+y5A5JQ9UAJEfoy6/8AoSfahkiYzMh4w/l6n2FJc/8AV/PtrvPTMh5ezaX4r3mXQ3SzHe78/wBPdur/AOD/AKi6BXsOaOWAnHruOxcvPhOKZgTfWMv3oqSSSUjEpJJJJT//1fVUkkklKVbqGU7ExLL2N3ObAaDxLiGAu/kt3Kvn9YpxSaqh6t45E+1v9d3/AHxYOXlZWZrdaSQdzANGNI49gVLmuehjEoQPFkoj07Ql5tvl+UlMxlIcMLB1/Siil7suzIeS+y4NLnHkls/+YLkcXHre2u55LzY31IOgl3v1/e+kutrfu9w9rmmHNPLXfurnsjG+w5LseP0Uutxz41OP6Sv+vi2P2/8AE+iqnIcEvejLXKYieO/6nqy/3pcLa5qeSE8JB4cXF7eTbrHgw/3YqSSSUy9Sp3YVbm2FjtkTpyNBP9ZXCQBJ0A5Ua8Z+Y4Yglpvk3OHLKv8ADO/rOb+gr/4Sz+QpuXjAylLKP1cImUy1+by5IQiMRrLOYjDrffSX6LuN35NeHc17q37W3eo3RzSWN+j/ACnOcuu6Pl35WHvvg2McWF4EB8RFm3836Xv/AJa5h72VMLj7WNgBo+5lbAiYl+Vik2V2Fljzue0at8Gs2n2u2N9qzeV5n2chJvglvENnmMJy4hHTij8siP8AGexSWZgdbryHNpyAKrXaNI+g4+A/cd/JctNbWLLDLHigeIfl5uTkxzxy4ZiipJJJSLH/1vVVV6llHFw7LW/TjbX/AFne1v8Am/SVpYn1iul1OODxNjh/0Gf+jFBzWT28M5DQ1Uf70vSy8vj48sYna7PlFx/x8ykkkufdphZW4uFlZDbQI1+i4fuWf99f+Yq2XQ3PodSP0OVUfUq3fmPGjXafzmPZ/NWf8GrihYwPAJ0czVjhy0+X/fmp0JyhITieGUTxA+SJxjkgYTFxkOF5qt25m5oNZktfWddr2nZZWf6jwpzZ+8Pu/wBqs9brbj9fyGsbsryh6rR29Rga2xzP+Mq2f26VWXTww4MsRMwFmxLhMhHjieCfy/13nZ81zOGRx+4aABjxCM5cE48cNZR/cYvLWNNtpLgwSf8AzFv77vosWxh1N6fjb8j+k3w6xrdTP5mOz+RRu27v9L6ln+EWRVNnUKKWt3mucgs7FzfZjB38ltv6f/rC6fIoqbm22gS4Q1p/dAa1vs/rLO+KzEYjBjqMYmMsgH6Up8ft3/d9v/0m3/hkZTl94zkzMhIYvKHDx1+5xe5/6UQVV2ueL8jR4/m6hwwHv/xqMkksd1SbUQCIOoK6Xo+U7Jwm7zusqPpvJ5MfRd/aYuaWp9X7tmVZSeLWbh8WH/yL1b5DJwZwOk/Sf+5avOY+LCT1h6h/3TvpJJLccl//1/VVy/VrfV6hcZkMisf2R7v+m566dxDQXHgCSuPcbLHOsc102EvOh5cdyzvik/RCH7xMv8T/ANHb3w+PqnLsOH/G/wDRUOQ4toeRzo0fFzms/wC/IrvpH4oOY1/oaNd/OVdj/pGI5a+T7T9xWVRdHoxSidPHT70+1/7p+4qdFb3X1jadXt5EDnxKMYmREe5r7UGVAnsLcr6zAONF4GteWGz/ACbA+hzfxYsta/X6rPsYbtLnDJpnaCRpa3dBassV2z/Nv/zXf3LovhkjLBMn/Oz/AOdwz/7p5/4lHhzRA/zcPw9Kf6v1h+R1HJ5IsbjM8hWzc/8Azn2LeuM2l37wa772tWJ9V2WDEzNzHA/bLTq0+DPJbt9VjTWCJJrafb7vEfmrJ58mWfmP78P+ZCWN1OSoYcH9yf8AzpRmiST7H/uu+4pbH/uu+4qlRblo6XbmvB5bY9v3OMf9Eq1g2+jm0WcAPAPwd+jP/VKnjtfuyPa7+ffGh8GIpY+DDXT20KMSYyEgNYkSH+CqQEgYnaQr/GezSQ8e31qK7ePUaHR8RKS6TiHDxdK4vo4XCb4et0//2QA4QklNBCEAAAAAAFcAAAABAQAAAA8AQQBkAG8AYgBlACAAUABoAG8AdABvAHMAaABvAHAAAAAUAEEAZABvAGIAZQAgAFAAaABvAHQAbwBzAGgAbwBwACAAMgAwADIAMwAAAAEAOEJJTQQGAAAAAAAHAAQAAAABAQD/4Q6AaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA5LjAtYzAwMSA3OS4xNGVjYjQyLCAyMDIyLzEyLzAyLTE5OjEyOjQ0ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bWxuczpwaG90b3Nob3A9Imh0dHA6Ly9ucy5hZG9iZS5jb20vcGhvdG9zaG9wLzEuMC8iIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgMjQuMiAoV2luZG93cykiIHhtcDpDcmVhdGVEYXRlPSIyMDI1LTA1LTIzVDE0OjM2OjU2KzA1OjMwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDI1LTA1LTIzVDE0OjM2OjU2KzA1OjMwIiB4bXA6TW9kaWZ5RGF0ZT0iMjAyNS0wNS0yM1QxNDozNjo1NiswNTozMCIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo1NDU0ODcxZC1iMGZhLTZkNGQtYWJjMi0xNzQzZTI2YjM0NDkiIHhtcE1NOkRvY3VtZW50SUQ9ImFkb2JlOmRvY2lkOnBob3Rvc2hvcDplNmYyYWZjYy02ZTE1LTgwNGUtODAxMC1kYWZhN2RhMDVlMDgiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpmNjAwYmIxOC02Y2FlLWRkNDQtODA4OS1jYzEzNGQxYTNiNmEiIHBob3Rvc2hvcDpDb2xvck1vZGU9IjMiIHBob3Rvc2hvcDpJQ0NQcm9maWxlPSJzUkdCIElFQzYxOTY2LTIuMSIgZGM6Zm9ybWF0PSJpbWFnZS9qcGVnIj4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0iY3JlYXRlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDpmNjAwYmIxOC02Y2FlLWRkNDQtODA4OS1jYzEzNGQxYTNiNmEiIHN0RXZ0OndoZW49IjIwMjUtMDUtMjNUMTQ6MzY6NTYrMDU6MzAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyNC4yIChXaW5kb3dzKSIvPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NTQ1NDg3MWQtYjBmYS02ZDRkLWFiYzItMTc0M2UyNmIzNDQ5IiBzdEV2dDp3aGVuPSIyMDI1LTA1LTIzVDE0OjM2OjU2KzA1OjMwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjQuMiAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDxwaG90b3Nob3A6RG9jdW1lbnRBbmNlc3RvcnM+IDxyZGY6QmFnPiA8cmRmOmxpPjlGRjMzNjY5M0I2OTI5MDBBQUY5RTI5NkU3NDJCNEY4PC9yZGY6bGk+IDwvcmRmOkJhZz4gPC9waG90b3Nob3A6RG9jdW1lbnRBbmNlc3RvcnM+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw/eHBhY2tldCBlbmQ9InciPz7/4gxYSUNDX1BST0ZJTEUAAQEAAAxITGlubwIQAABtbnRyUkdCIFhZWiAHzgACAAkABgAxAABhY3NwTVNGVAAAAABJRUMgc1JHQgAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLUhQICAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABFjcHJ0AAABUAAAADNkZXNjAAABhAAAAGx3dHB0AAAB8AAAABRia3B0AAACBAAAABRyWFlaAAACGAAAABRnWFlaAAACLAAAABRiWFlaAAACQAAAABRkbW5kAAACVAAAAHBkbWRkAAACxAAAAIh2dWVkAAADTAAAAIZ2aWV3AAAD1AAAACRsdW1pAAAD+AAAABRtZWFzAAAEDAAAACR0ZWNoAAAEMAAAAAxyVFJDAAAEPAAACAxnVFJDAAAEPAAACAxiVFJDAAAEPAAACAx0ZXh0AAAAAENvcHlyaWdodCAoYykgMTk5OCBIZXdsZXR0LVBhY2thcmQgQ29tcGFueQAAZGVzYwAAAAAAAAASc1JHQiBJRUM2MTk2Ni0yLjEAAAAAAAAAAAAAABJzUkdCIElFQzYxOTY2LTIuMQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWFlaIAAAAAAAAPNRAAEAAAABFsxYWVogAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z2Rlc2MAAAAAAAAAFklFQyBodHRwOi8vd3d3LmllYy5jaAAAAAAAAAAAAAAAFklFQyBodHRwOi8vd3d3LmllYy5jaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABkZXNjAAAAAAAAAC5JRUMgNjE5NjYtMi4xIERlZmF1bHQgUkdCIGNvbG91ciBzcGFjZSAtIHNSR0IAAAAAAAAAAAAAAC5JRUMgNjE5NjYtMi4xIERlZmF1bHQgUkdCIGNvbG91ciBzcGFjZSAtIHNSR0IAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZGVzYwAAAAAAAAAsUmVmZXJlbmNlIFZpZXdpbmcgQ29uZGl0aW9uIGluIElFQzYxOTY2LTIuMQAAAAAAAAAAAAAALFJlZmVyZW5jZSBWaWV3aW5nIENvbmRpdGlvbiBpbiBJRUM2MTk2Ni0yLjEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHZpZXcAAAAAABOk/gAUXy4AEM8UAAPtzAAEEwsAA1yeAAAAAVhZWiAAAAAAAEwJVgBQAAAAVx/nbWVhcwAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAo8AAAACc2lnIAAAAABDUlQgY3VydgAAAAAAAAQAAAAABQAKAA8AFAAZAB4AIwAoAC0AMgA3ADsAQABFAEoATwBUAFkAXgBjAGgAbQByAHcAfACBAIYAiwCQAJUAmgCfAKQAqQCuALIAtwC8AMEAxgDLANAA1QDbAOAA5QDrAPAA9gD7AQEBBwENARMBGQEfASUBKwEyATgBPgFFAUwBUgFZAWABZwFuAXUBfAGDAYsBkgGaAaEBqQGxAbkBwQHJAdEB2QHhAekB8gH6AgMCDAIUAh0CJgIvAjgCQQJLAlQCXQJnAnECegKEAo4CmAKiAqwCtgLBAssC1QLgAusC9QMAAwsDFgMhAy0DOANDA08DWgNmA3IDfgOKA5YDogOuA7oDxwPTA+AD7AP5BAYEEwQgBC0EOwRIBFUEYwRxBH4EjASaBKgEtgTEBNME4QTwBP4FDQUcBSsFOgVJBVgFZwV3BYYFlgWmBbUFxQXVBeUF9gYGBhYGJwY3BkgGWQZqBnsGjAadBq8GwAbRBuMG9QcHBxkHKwc9B08HYQd0B4YHmQesB78H0gflB/gICwgfCDIIRghaCG4IggiWCKoIvgjSCOcI+wkQCSUJOglPCWQJeQmPCaQJugnPCeUJ+woRCicKPQpUCmoKgQqYCq4KxQrcCvMLCwsiCzkLUQtpC4ALmAuwC8gL4Qv5DBIMKgxDDFwMdQyODKcMwAzZDPMNDQ0mDUANWg10DY4NqQ3DDd4N+A4TDi4OSQ5kDn8Omw62DtIO7g8JDyUPQQ9eD3oPlg+zD88P7BAJECYQQxBhEH4QmxC5ENcQ9RETETERTxFtEYwRqhHJEegSBxImEkUSZBKEEqMSwxLjEwMTIxNDE2MTgxOkE8UT5RQGFCcUSRRqFIsUrRTOFPAVEhU0FVYVeBWbFb0V4BYDFiYWSRZsFo8WshbWFvoXHRdBF2UXiReuF9IX9xgbGEAYZRiKGK8Y1Rj6GSAZRRlrGZEZtxndGgQaKhpRGncanhrFGuwbFBs7G2MbihuyG9ocAhwqHFIcexyjHMwc9R0eHUcdcB2ZHcMd7B4WHkAeah6UHr4e6R8THz4faR+UH78f6iAVIEEgbCCYIMQg8CEcIUghdSGhIc4h+yInIlUigiKvIt0jCiM4I2YjlCPCI/AkHyRNJHwkqyTaJQklOCVoJZclxyX3JicmVyaHJrcm6CcYJ0kneierJ9woDSg/KHEooijUKQYpOClrKZ0p0CoCKjUqaCqbKs8rAis2K2krnSvRLAUsOSxuLKIs1y0MLUEtdi2rLeEuFi5MLoIuty7uLyQvWi+RL8cv/jA1MGwwpDDbMRIxSjGCMbox8jIqMmMymzLUMw0zRjN/M7gz8TQrNGU0njTYNRM1TTWHNcI1/TY3NnI2rjbpNyQ3YDecN9c4FDhQOIw4yDkFOUI5fzm8Ofk6Njp0OrI67zstO2s7qjvoPCc8ZTykPOM9Ij1hPaE94D4gPmA+oD7gPyE/YT+iP+JAI0BkQKZA50EpQWpBrEHuQjBCckK1QvdDOkN9Q8BEA0RHRIpEzkUSRVVFmkXeRiJGZ0arRvBHNUd7R8BIBUhLSJFI10kdSWNJqUnwSjdKfUrESwxLU0uaS+JMKkxyTLpNAk1KTZNN3E4lTm5Ot08AT0lPk0/dUCdQcVC7UQZRUFGbUeZSMVJ8UsdTE1NfU6pT9lRCVI9U21UoVXVVwlYPVlxWqVb3V0RXklfgWC9YfVjLWRpZaVm4WgdaVlqmWvVbRVuVW+VcNVyGXNZdJ114XcleGl5sXr1fD19hX7NgBWBXYKpg/GFPYaJh9WJJYpxi8GNDY5dj62RAZJRk6WU9ZZJl52Y9ZpJm6Gc9Z5Nn6Wg/aJZo7GlDaZpp8WpIap9q92tPa6dr/2xXbK9tCG1gbbluEm5rbsRvHm94b9FwK3CGcOBxOnGVcfByS3KmcwFzXXO4dBR0cHTMdSh1hXXhdj52m3b4d1Z3s3gReG54zHkqeYl553pGeqV7BHtje8J8IXyBfOF9QX2hfgF+Yn7CfyN/hH/lgEeAqIEKgWuBzYIwgpKC9INXg7qEHYSAhOOFR4Wrhg6GcobXhzuHn4gEiGmIzokziZmJ/opkisqLMIuWi/yMY4zKjTGNmI3/jmaOzo82j56QBpBukNaRP5GokhGSepLjk02TtpQglIqU9JVflcmWNJaflwqXdZfgmEyYuJkkmZCZ/JpomtWbQpuvnByciZz3nWSd0p5Anq6fHZ+Ln/qgaaDYoUehtqImopajBqN2o+akVqTHpTilqaYapoum/adup+CoUqjEqTepqaocqo+rAqt1q+msXKzQrUStuK4trqGvFq+LsACwdbDqsWCx1rJLssKzOLOutCW0nLUTtYq2AbZ5tvC3aLfguFm40blKucK6O7q1uy67p7whvJu9Fb2Pvgq+hL7/v3q/9cBwwOzBZ8Hjwl/C28NYw9TEUcTOxUvFyMZGxsPHQce/yD3IvMk6ybnKOMq3yzbLtsw1zLXNNc21zjbOts83z7jQOdC60TzRvtI/0sHTRNPG1EnUy9VO1dHWVdbY11zX4Nhk2OjZbNnx2nba+9uA3AXcit0Q3ZbeHN6i3ynfr+A24L3hROHM4lPi2+Nj4+vkc+T85YTmDeaW5x/nqegy6LzpRunQ6lvq5etw6/vshu0R7ZzuKO6070DvzPBY8OXxcvH/8ozzGfOn9DT0wvVQ9d72bfb794r4Gfio+Tj5x/pX+uf7d/wH/Jj9Kf26/kv+3P9t////7gAOQWRvYmUAZAAAAAAB/9sAhAAGBAQEBQQGBQUGCQYFBgkLCAYGCAsMCgoLCgoMEAwMDAwMDBAMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMAQcHBw0MDRgQEBgUDg4OFBQODg4OFBEMDAwMDBERDAwMDAwMEQwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAJYAfQDAREAAhEBAxEB/90ABAA//8QBogAAAAcBAQEBAQAAAAAAAAAABAUDAgYBAAcICQoLAQACAgMBAQEBAQAAAAAAAAABAAIDBAUGBwgJCgsQAAIBAwMCBAIGBwMEAgYCcwECAxEEAAUhEjFBUQYTYSJxgRQykaEHFbFCI8FS0eEzFmLwJHKC8SVDNFOSorJjc8I1RCeTo7M2F1RkdMPS4ggmgwkKGBmElEVGpLRW01UoGvLj88TU5PRldYWVpbXF1eX1ZnaGlqa2xtbm9jdHV2d3h5ent8fX5/c4SFhoeIiYqLjI2Oj4KTlJWWl5iZmpucnZ6fkqOkpaanqKmqq6ytrq+hEAAgIBAgMFBQQFBgQIAwNtAQACEQMEIRIxQQVRE2EiBnGBkTKhsfAUwdHhI0IVUmJy8TMkNEOCFpJTJaJjssIHc9I14kSDF1STCAkKGBkmNkUaJ2R0VTfyo7PDKCnT4/OElKS0xNTk9GV1hZWltcXV5fVGVmZ2hpamtsbW5vZHV2d3h5ent8fX5/c4SFhoeIiYqLjI2Oj4OUlZaXmJmam5ydnp+So6SlpqeoqaqrrK2ur6/9oADAMBAAIRAxEAPwD1TirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdXFXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FX/0PVOKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2Koe+1HT9Pt2ub+6itLZPtTTusaD5s5AxV51r3/ORn5U6RyRNUbVJl29LTomnG3/Fnww/8lMVef6z/wA5exjkui+W2b+Wa9uFT744Vk/5OYqw3U/+cpvzPuy31QWGnKT8IhtzIw9uUzup/wCAxVjt5+e/5uXbln8yTxV/Zgjt4l/4WKv44qlkv5r/AJny/b816pv/AC3Lp/xDhhpVsf5qfmbHXj5r1Wp7tdSP/wATLYaVMbP88vzatHDJ5mupCO0ywSr9IeM40rJtK/5yl/M+zYfXPqOpR1+JZrcxMR7NCyAf8i8FK9A8uf8AOXGhTlIvMWjT2DHZrmzcXMXzKMI5QP8AVEmNK9h8reevKXmu2Nx5f1WC/VRWSONqSp/xkibjIn+yXAqfVxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV/9H1TirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirE/PH5peSvJUHLXNQVLtl5Q6dD+9upP9WJdwP8ALfgn+Vir5885/wDOVHm7UmeDy1aR6JZmoFxJxuLth4/EPRi+hZf9fFXj2ta9reuXJutYv7jUbgmvqXUjSkf6oY8V/wBiFw0hA79zXGlt2NLbsaW3Y0tuwrbsVt2K27Fbditq1lfXthdx3ljcS2t5CQYrmB2jkUj+V1IYYrb338r/APnKG6glh0nz5++t2ISLXolo6dh9ZjQUdfGaIcv5o2+3gpL6WtLu2u7aK6tZUntp1EkM0bB0dGFQysKgg4FVcVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVf/0vVOKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2Koe/1Cx0+0lvL+4jtbSFeU1xM6xxoB3ZmIAxV84/mp/wA5OzytNpHkQ+nCKpNrzr8TdiLWNh8I/wCLpB/qR/7sxV8+XV1c3d1Ld3cz3F1O3OaeVi8jsf2ndqsx+eGlUjjSuwodirsVdirsVdirsVdirsVdirsVWOtQRil6p+Q/52XfkvVI9F1qdpPKd29G5kt9SkY/30fhCT/fR/8APVPi580q+yopY5Y1ljcSRuoZHU1VlYVBBHUHIqvxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2Kv/0/VOKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV5x+aH54eVvI0b2dRqfmArWPS4WHwV6NcSbiJf8AJ/vW/YTFXyh56/Mnzf52vfrGu3he3Vi1tp0VUtYa9OEdfiYf78k5yf5WKsXwhDsKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KtYqh5Vo/hil9W/84q/mJNq+g3PlHUJS97oqiTT3Y1Z7JzThv1+rv8AD/xjeNf2cBV7w8kcaF5GCIoqzMaAD3JwKxXVfzZ/LTSpDFfeZtOilFQY1uEkYEdarGWIxVLV/Pr8oGNB5os6+/qAfeUxVkOi+e/Jet8RpOu2F87brHDcRM5H+oG5fhiqe4q7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FX/1PVOKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxVbLLHFG8srBI4wWd2ICqoFSST0AxV84/m9/zksSZ9C8iS9OUd1rwAI8CLSvX/AJiGH/GL/fmKvnOWWaaV5pnaWaVi8sjkszO25ZmNSzHuxxVbhCHYVdirsVdirsVdirsVdirsVdirsVdirsVdirsVUJ+o9xgSE98ied9X8leY4df0pY5LuGKWH0puRiZZk4/GFKk8W4yAV+0mKV3mz8wvOfmydpde1a4u0Y1Fry9O3X2SBOMY/wCB5f5WKscCgdNvliq5Vdjt9OKqggTkGO5G4PcH2OKLZ15Q/OT8xfKzoLDV5bmzTrYXpNzAR4AOecf/ADydMVfRH5cf85I+VPM0kOna2o0LWZKJH6rVtJnPaOY04MeyTcf5VZ8CvYBireKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2Kv/9X1TirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdiqW+YvMeieXdJm1bWryOysIB+8mkPUnoqgfE7t+yi/E2Kvkb83fz21vzvLLpmneppvlgGn1WtJboA7NcEfs9xAp4f785/sqvLckhrGldirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVUbj9nFIUsCXYFXRoWNO3fCqJFAKAUGFi7FXYq0QCKHcHqMUvZfyf/wCcg9U8qtDo3mR5dR8ufCkMx+O4sx0+En4pYR/vs/Gn+6v994CFfWGm6lYanYQahp9wl1ZXSCS3uImDI6HoQRgVFYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FX//W9U4q7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FWE/mT+bflbyFY8tQk+s6pKvK00mEj15P8pq/wB1FXrI/wDsObfDir4+8/fmN5m886t9f1qf9zET9T0+IkW9up/kU9XP7UrfG/8Aq/BirGMlSHVxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxVxxVRn6rgKQpYEtgVNMQqJVQq0GSYt4q7FXYq7FXYq9E/KD84dX8g6kIJC955auXre6dWpjY9Zrev2ZP5k+xN/r/AB40yfZWha9pOu6Vb6rpNyl3YXS84Z4zUHxBHVWU7MrfErZFCYDFXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FX/9f1TirsVdirsVdirsVdirsVdirsVdirsVdXFXVxVD32oWOn2kl5fXEdraQjlLcTOscajxZmIAxV8/8A5m/85RWsKzaZ5FUTzbrJrky/ul/5h42/vT/xZIPT/wAmTFXzjf6hfajfT39/cSXd7csXnuZmLyOx7sxxVD4aQ7CrsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdiru2KuGKqE5BYU7YCkKeBKrAu/I4QEFWwodirsVdirsVdirhim2a/ll+a3mLyDqZmsT9a0qdq3+kyMRHJ25od/SmA6OB8X2ZOWNJfXnkL8z/KHnayE2jXg+tqoNxps1Euoj/lR1+Jf+LE5R/5WRQy3FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq//0PVOKuxV2KuxV2KuxV2KuxV2KuxV2KuxV4x+Zflj84tD1W981+RNeu7+3uD6l55fnC3HpgCn+ixSAoyD/facJf5WlxV5Bc/85N/m4yPAbiztZVPF2SzAkVh1BErOqt7MmKvP/MfnDzT5mmE2v6rc6kymqJO5MaH/ACIl4xJ/sUxVJ8Vdkgh2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KtE0U4qhmNTgLJrAqJQcVAyTFdirsVdirsVdirsVdirgQe+KVW2ubm0uYrq1mkt7mE8obiFmjkRvFXUhlPyxV6j5Y/5yW/M3RVWG8ng1y2XbjfJSan/ABmi4Mf+eiyY0r0XTf8AnL3RWRRqfly6hf8Aaa1nimX/AJKei2ClWa//AM5e6StpIugaFcyXjCkUt+8ccSk92SJpHen8tU/18aV6t+UnmHzB5i/L7SNc14INRv0kmb009NTGZWETcKmnKII2JVmGBXYq7FXYq7FXYq7FXYq7FXYq/wD/0fVOKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KsP84flH+X3m6Rp9Z0mNr5hT6/ATBcf7KSMqX/AOenPFXy5+bGhfk/5du5dJ8qz3+qavGeNxcNco9lbsDQpVY+c8o/lV+Cftvy+DFXmh65IIdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirWKqUsopxH04EqWBLaCrDFUVkmLsVdirsVdirsVdirsVU5EB+IdR4YEqYlcd8bVv138BjauMznG1pnv5N/lRqP5geYkWVHj8u2ThtWvBsCvX6vGf9+y/wDJOP4/5ORtX3Fa2tva20VrbRrFbwIsUMSCioiDiqgeCgUyKq2KuxV2KuxV2KuxV2KuxV2KuxV//9L1TirsVdirsVdirsVdirsVdirsVdirsVccVfM358/n5cTz3PlLyjc+nbR1h1XV4T8UjAkPBbsOiD7Msy/a+wn82KvnnthVvCh2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KtEgYqtMqDFKwznsMCrTO/tilaZGPfFWsCuxVUhWpr4YQgq+FDsVdirsVdirsVdirsVaxVRlSnxD6cCU18o+VNU81a7BomlvAl9c19EXUohRiu5UMa1em4RRybjir37yb/wA4iJHKlx5v1cTIpBOn6cGVW9nuHAen/GONP9fFL6C0PQtH0LTINL0ezisdPtxxht4V4qPE/wCUx/aZvib9rAhMMVdirsVdirsVdirsVdirsVdirsVf/9P1TirsVdirsVdirsVdirsVdirsVdirsVeKf85J/mnL5d0ZPLGkTmLWtXjLXM8ZIe3s6lSVI+zJMaon8q+o38uKvksAdhQdhhVvCh2KuxV2KuxV2KuxV2KuxV2KuxV2KuOKuxV2KuxVY8gX3PhgtVEuTilaSACSaAdSe2KUHLqlpGaAmQ/5PT7ziqgdbXtCae5/sxVUi1i3c0dTH79RiqOVlZQykFT0IxVvAqvCKLhCCqYUOxV2KuxV2KuxV2KuxV2KtEV28cVUkea3nSaB2imiYPFKhKurKaqysN1ZTupwJfa/5C/mg3nnyiBfuDr+lFbfUuxlBH7q4A7eqo+P/i1XxV6bTArsVdirsVdirsVdirsVdirsVdirsVf/1PVOKuxV2KuxV2KuxV2KuxV2KuxV2KqV1cwWttLczuI4IEaSWQ9FRByYn5AYq+A/O/mq582ea9U8wXBNb+YtAjfsW6fDBH/sYwv+y5YqkWSpDsVdirsVdirsVdirsVdirsVdirsVarirSHlU+GKru+KuxVa7hR88bVD1yLJD3V3FbLVzVj9le5wqklzez3DfG3w9kHTFChXFLsVcMVR2l3LRzCIn93IaU8D2xVOxiqoJSqgDFBcJ3rvSmG0UrAgio6Yq3irsVdirsVdirsVdirsVU5FJX3GKs5/I3zu/lL8xtNuZH46dqDDT9SBNF9KdgEc/8YpeD/6vPAyfdNcCHYq7FXYq7FXYq7FXYq7FXYq7FXYq/wD/1fVOKuxV2KuxV2KuxV2KuxV2KuxV2KvNf+ciPMDaL+VOremxSfUvT06Ig0P+kNST/kiJMVfFQ8MIVvCh2KuxV2KuxV2KuxV2KuxV2KuxV2KrJW4qfHtircYog98VXYq7FUNIxZ/ltkSyCK0jS7nVdRhsbanqSndj9lVG7M1OyjIZJiIstuHGZyEQyf8A5UrHK5e71dmcncRQgCngOTZhnXdwdgOzO+SIj/JTQB9u+unPegjX+ByH5+Xcy/kyP84rm/JXy6Rte3QPj+7P/GuP56Xcv8mR7yhZ/wAkNPNfQ1WVD25xK36mGEa49y/yYP5yV3f5J6xGK2moW8/s4eM/qcZcNdHqC0y7MmORBSC+/LjzlpziRrBp0Qg87crKNt+inl/wuXR1EJdXGnpMkeiGvL1bRzHLG4l7xlSpHz5Uy4G2ggjmh01qEkB42UeNQcUI+N0kQOjBlboRiqojlT7d8UUif44UOxV2KuxV2KuxV2KuxV2KoWRTyYA0PY+FcBZP0G/LzW313yJoGryEmW9sLeWYnqZDGA//AA9cCGRYq7FXYq7FXYq7FXYq7FXYq7FXYq//1vVOKuxV2KuxV2KuxV2KuxV2KuxV2Kvnj/nL/VSum+W9KVtpp7i6kX/jDGsan/ks2KvmcYQreFDsVdirsVdirsVdirsVdirsVdirTMFFTiqHr6j/AD/DAlE+3hhQ7FWmNFJxVC98gzej/lhpSx2lxqjj95MxghPgibuf9k+3+wzA1k7PC7bs7HQM+9nGYTs3YFdirsUuxS7FULf6ZpuoxmO/tYrpDtSVA1PkTuMnGZjyLXPFGXMMI1z8ntCu1Z9LlfT5+oRiZYflQ/Gv/BZlQ1khz3cDJ2dE/TswDUfKnmPyzP8A6dATZO1DcxfHCfeo+yf9bjmbjzxnyLrc2mnj5jZvLWhFBqgH2wsW8VdirsVdirsVdiqwtxceB2xVfiqjMKMDiWQfcX5AOz/k75XLGpFsyg+yzOo/AZFD0LFXYq7FXYq7FXYq7FXYq7FXYq7FX//X9U4q7FXYq7FXYq7FXYq7FXYq7FXYq+WP+cubjl5w0G3rtFp0klPD1Z6f8ysVeD5JXEgCpxQphmdqD7PfAlV27YUOxV2KuxV2KuxV2KuxVxIG5xVDySFj7YCUroU/a79sQpVsKHYq0w+E4qhOn0ZFk9q8p2otvLWmxAbmBZG9zJ8ZP/DZp8xuZL0WmFYohNsqcgOwK7FXYq7FXYq7FXYqtdVZGRgGVhRlIqCD2IOEKRbxnzZpseneYr22iUJDyEkKgUASRQwA+RNM3GCfFEF53VY+DIQOSBT7A+WXuKuxV2KuxV2KuxV2Kqc/2K9wcSluJ+S+4xVbPSqk9O+Kh93fktZPZ/lR5WgdeLfo+GQg7f3o9T/jbIqzXFXYq7FXYq7FXYq7FXYq7FXYq7FX/9D1TirsVdirsVdirsVdirsVdirsVdir5R/5y3iK+e9Gl7SaVxH+wuZCf+TgwhXh+FUPKxYmnQdsCqkK0T54QpVMUOxV2KuxV2KuxV2KtMwUVOKod5C3ywEsnRxySSLHGpd2NFRRUknwAwLSIUACmSCG8UOxV2KoRxQkZGmXR7lojBtE04jobWH/AJNjNLkPqPvelxfRH+qEbkG12BXYq7FXYq7FXYq7FXYUvLPzMUDzIhHVrWOvzDOP4Zs9H9HxdF2j/e/5rHVFFA9szHXuG+Kt4q7FXYq7FXYqpzf3Z+YxKhTiajivfbAElWjtZr29t7GAcp7qRIIgOvOVgi/8M2FQ/RTSdPi03S7PTov7qygit4/9WJAg/VkVRmKuxV2KuxV2KuxV2KuxV2KuxV2Kv//R9U4q7FXYq7FXYq7FXYq7FXYq7FXYq+Z/+cv7Fl1Dyxf0+F4ru3J91aKQfgWwhXzrK9NsKqI64FRIFNsKG8VdirsVdtirhirjiqm8qjYbnG00osxPXBaaa/X2wK9O8i+UP0cianfx/wC5CQVhib/dKHx/4sYf8CuazU5+LYcndaLS8HqlzYh5o0o6XrdxbgfuXYy257GNzUD/AGJ+HM/T5OONus1WHw5kdEqy5xm8VdiqhOtDy7HAUh695HuxdeVrBq1aFDA/sYmK/wDEeOanUwqZei0c+LEPJPcx3JdgV2KuxV2KuxV2KuxV2KXk3n6cXHmydF+zbxxRE+4XmfxfNtpI1AOg7QleU+SSZlOCpK9HIPSuKaVcUOxV2KuxV2KqcxASnicSkNR2dy9lNeqlba3kiilk8HmDlB9IifIq9H/5x38qv5h/NTTpHQtaaODqVy3YGLaEH5zMjf7BsKvtymBXYq7FXYq7FXYq7FXYq7FXYq7FXYq//9L1TirsVdirsVdirsVdirsVdirsVdirxr/nKnQXv/y5i1ONOUmj3sUzmnSGYGB/+Gkjb/Y4q+SNLsJdU1e00+I0ku5khVvDmwBb/Yj4skqEJjMhMZrGWPpk9eNfh/DAqJ98KFOQum43HhirQmBG+3jjaaXCRCPtDG1p3qRjvja0tM3hja0ptIzd9sCaW4FcASQACWOwA3JPgAMVAek+SvJH1P09T1RAbvZra2O4i/yn/wCLPb9j/WzXajU36Yu40ej4fVLmzbfvmDTskh82+XRrOn/ugBfW9WtmO1a/aQnwb/iWZGnzcEvJxdXp/Ejt9QeVPHJE7RyKUkQlXRhQgjYgjNyDe4eekCDRaxQ7FVrLyWmJUMv/ACy1cW93caRO1Fuf3tsT/v1RRlH+sm/+wzB1sCQCHadnZgCYnq9HzXU7h2BXYq7FXYq7FXYq7FVK5uYbW2luZjxhgRpJG8FUVOSjGzSJyERZeKXF1LeXdxey/wB7dSNK3tyNQPo6Zu4RoAPMZJ8UiT1UmPEEnoNzljBF6p5ev9O02x1C4HFb/kfToaoeqBvd0+LKIZhKRA6ORk08oREj/Ego35L7jLg45X4odirsVdiqhNUsAO2BL0HVNBOkfkTpV/MvG48y64bqMnY/VrK3lij28GdpH/2eKvf/APnGDyI2geR21y7j4aj5iZbgBhRltEBFuu/89Wm/56LgV7LirsVdirsVdirsVdirsVdirsVdirsVf//T9U4q7FXYq7FXYq7FXYq7FXYq7FXYqlvmXQrPX9A1DRLwVtdRt5LaU9wJFI5D3U/EMVfEvk7yxqGj+edcs9Ui43vlrTdXuJwQaepBaPHG6+Ks0sciH+XJKwFBx4+2BUU7UWo6YocGU/0xVTaHuuKVJgwO4+/FLq4FdirsVVbW1ubq4S3tommnkNEjQVJOAkAWWUYmRoPT/KXkeDSQt5fBZtS6r3SGvZf5n/y/+AzWZ9SZbD6XdabRCG53kyvMVznYq7FIY/5l8oWesKZ4yLe/A2mpVXp0EgH/ABL7WZODUmG38Lh6rRxyCx6ZPONU0XU9Ll9O9gaMVosvWNv9Vhtmzx5Yy5F0eXBOB3CCyxqdiraPJHIksTGOWNg0ci7FWG4IwSFhkDRt6l5X832mrxLBcMsGpqKPH0WT/Kjr490/ZzVZsBibHJ3ul1cZijtNkOYzmuwK7FXYq7FXYq7FWCfmH5gjZP0NbPy3DXrA7fCarF9/xP8A8Dmw0eH+I/5rqdfqQfQPiwWtBvsBmxp1Nsz8neTpLh01LUo+NspDW9u4oZCNwzA/seA/a/1cwNVqaHDHm7LR6MyPFLkynzdpn6S8vXkAXlMi+vB/rxfEPvHJcwtPPhkHZarHxYyHjcTfEPA5ug84icKHYq7FXYqj/KPli/8ANfmjT/L9iD6+ozCIyAV9OPrLKado4wz4EvsD8wPyUsPNdr5Q0iOdbTy/5bkpcWlGLzW4jWNYkIoFLBOLuf5v5sCvTIYo4YkiiQRxRqEjRRRVVRQAAdgMVX4q7FXYq7FXYq7FXYq7FXYq7FXYq7FX/9T1TirsVdirsVdirsVdirsVdirsVdirsVYZ5/8AJ+i3Hl/zVqtvYwrr19o1zZyX6p++eNYWKRlvCoH/AAv8uKvghDVQfEVwqiGPKKvt+rFVGprscCW+bjvirRYnqa4q1irsVTvy/wCUNX1plkiX6vZ1+K7lB40/yB1kPy+H/KyjJqIw8y5WDSyyeQen6D5c0zRYClonKVwBNcvvI/0/sr/krmuy5jM7u6waeOMbJrlTeXYEOxV2KuxVbJHHIhjkUPG2zIwBB+YOEEjkggHYpDfeRfLl2SywNauf2oG4j/gTyX8Mvhq8g57uJk0GKXIcPuSaf8sl3+r6gR4CWOv4qR+rMga7vDjHsvuKCl/LXWF/u7m3k+Zdf+NTkxrY9zUezZ9CEM/5f+ZY2BjSF6EFXWYCh8dwDk/zcC1/kMo7me+XrfWLfTEi1aVZrpSQHU8jw7B2/ab/ACs12UxMvTydvp4zjGpmymWVN7sVdirsVdiqReZ7vzCkIttGs2kklU87sFB6Y6UUMR8f+VmTp4wJuZcTVyy1WMc/4mGWvkDzJcvWZI7ZW3Z5pAzVPXZORJzOnq8ceRt1cOz8sufpZXonkPSdPZZrg/Xrpdw0gpGp/wAlP+asw8uslLYekOxwdnwhufWWS5iOe4dfbFDw3WrL6hrF7ZgUEE7qn+rXkv8AwpGbvHPiiC81mhwzI81NTVQctaF2KuxVTmag4+OKvqT/AJxY/LU6Zo0nnTUYqXurJ6Wlqw3jswamQeBuGH/IpE/nwFL34YFdirsVdirsVdirsVdirsVdirsVdirsVdir/9X1TirsVdirsVdirsVdirsVdirsVdirsVWyIkkbI45I4Ksp7g7HFX57efPK1x5U846toEykfUbh1gY/tQOecDj/AFomTCqTwtUFT26YqpOOLYpawK7FXbDc9O+KvTPKnkTSksbXUNQjNzdTIsohk/uk5br8H7Rp/PmtzaiVkB3Gl0cQBKW5LMgAAFAAUCgA2AHtmI7JvAl2FXYLV2FLsUOwK7FDsUuxQ7FXYq7FXYq7FXYq7FXYpdja07bArsKHYq7FXlX5k2gg8yesBQXUKSfNkqjf8RXNpopXD3Ok7QjWS+9jkP2MzA68qmKHdiT2xVm35L/lnP5/83xwToRoVgVuNYl3AMdfhgU/zzkcf8mPm+Nq+5YIYoIUhhRY4olCRxqKKqqKAADoAMilfirsVdirsVdirsVdirsVdirsVdirsVdirsVf/9b1TirsVdirsVdirsVdirsVdirsVdirsVdirwj/AJye/KuXXNJTzfpEJk1TSY+GoQRqS01mCW5KBu0luSW/yomf+VcVfJytQhhhVfLxYcl69xikKeBXYqidNsjfalaWQ/4+ZkiPyY/F/wALXIzNAlnjjxSA7y91AVQFUUVQAo8ANhmlt6ZbNNDDE0szrHEgq8jEBQPcnEAnkkkAWWJap+Y1jCxj06Brth/u5z6cf0CnJv8AhczMehkfqPC67L2lEfSOJIpvzC8xuTwMEK9gsdSPpYtmTHR4w4cu0Mp7gh/8c+aq/wC9o+XpR/8ANOH8rj7mP57L3qsfn/zMnWWKT/WiX/jXjgOjxp/lDL3j5ImP8yNbH24LZwOvwuv6myB0Me8sh2ll6iKOt/zMNQLrTxTu0Mn8GH/G2VnQ9xbo9qd8WWaXq9hqlqLizk5r0kQ7OjfyuvY5hzxygaLssWaOQXFG5BsdgV2KuxV2KuxV2KsZ1rz3penTNbwo17Omz+mwCKfAtvU/6uZWLSTlufSHCza+EDX1FIpvzM1In9zZQoP8tnf9XDMkaGPe4Uu059AEM/5i+YW+yLeP5Rlv1tkhooebA9pZf6I+H7UO/nvzM3S5VflFH/EHJjSY+5rPaGXvcnnzzOvW5V/9aKP+AGP5TH3L/KGbvTGz/MnUkI+t20U6dzHWJvx5DKpaKPQuRDtKf8Qtlui+Z9J1f4LdzHcgVNtL8L/7Hs3+xzDy6eUHY4dVDJy5ptlDkME/NSzra6feAf3cjwsfZ15D8UzO0UtyHWdpx2BYBB3zYh05VcKFbTtNv9Y1O10nTYTcX97KsFvCvVnc0A+Q6sf2V+LEq+6/yw/L7TvIvlO10W24yXP99qN2BQzXLAc3/wBVacIx+zGq5FWXYpdirsVdirsVdirsVdirsVdirsVdirsVdirsVf/X9U4q7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq44q+Sf+chfyPPly4n83eXYSdAuJOeo2iD/AHjlc/bUDpbOx/54v/xX9gq8MxV2NJdjSsm/Lu0Fx5nhciq20ck3004L+L5i6uVQc3QRvIPJ6xsNyaDuc1Qd6xi68n+efOVzW1tjaaPGf3HrkoHpt6jL3J/Z5fZXNnpoxgNhxSdLq5ymdyIRH8P/AEinFj/zjveMAb7V0j23WKPl+vMj94egDiEYh1l/sUzj/wCcddGp+81q6r/kxRj9dcIB6sJGPRev/OOvlz9rWL8/JYB/xocmGNtP/wA466BxPpa1eq3YukLD7gqZK0Wl9z/zjlIFP1TzAC3YT2u33pJitpBqf5B+ebYFrR7PUFHaOUxOdv5ZVVf+HxW2KNaeavJ+opNe2M9g9eJWdCIpVruvMVjf/YtlWTEJii24c0scrD0rS9TtdTsYr22NY5Bup6qw+0je65p54zE0XosWUTHEEXkKbHYFdirsVdilhXnnzU8BbSbBysxH+lzL1UH/AHWp8SPtf8Dmw0uC/UXVa7V16I8/4mIaNoGt63MYNHsJ751NG9BCyr/rPsi/7Js2Lp2caZ+Qvnq6UNdtZ6cp6rLKZZAPdYlYfRzxVkFr/wA44yFQbzzAAe4gtdvveT+GNqmEf/OOmgBR6mtXrHuUjhX9YfG1Xn/nHXy321i/H0Qf80Yqoz/846aQR+41q5Q+MkMbfqK5FmCOoSW//wCcfPMVuwm0rVred4zyjEivbuCOhDD1BXGrG6bANxTTT9L822toY9f094LmD4WuV4yRSr2cPGSK/wAwPHNVqcHDKxyd3o9UJij9SR+fbUXHlW8NKm34Tqev2GHL/hS2Q00qyAd7PWw4sZeSxkA75uKefK55K7D78KKe+f8AOJPkoXet6j5uuo6w6av1PT2YdbiZeUrj/Uh4p/z2bAUPqfArsUuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2Kv8A/9D1TirsVdirsVdirsVdirsVdirsVdirsVdirsVUru1trq2ltrmJJredGjmhkAZHRhRlYHYqRir4k/PL8r4vInmkrp8iyaHqFZbKPlyktz3gl77f7pc/bj/ykbHiF0yETV9Hm5oASeg64UPVvLH/ADj7rmqadBfapqEeli4VZI7URNNMEYVUv8SIjEfsfF/lYqz/AMpfkhovl+ea4bUri8lmQRmqRxAKDy2pzPXKsuIT2Ldg1MsRJiN2Z2fljQ7Uho7YO4/blJkP47fhkYaaEejKetyT2MkVe6rptiKXVwkRHSMmrfQo3y2WaMeZaoaec9wOL+kk8/nnR46iJJZj7KFH/DH+GY8tbDo5UOzch5kBAy/mAa/urL/g3/gBlR13cG+PZXfJDP591Q/Yt4FHvyP8Rlf52Xc2jsyHUlZ/jvWK/wB3B/wLf81YfzsvJl/JmPvkrRefr0H99aROP8ksp/HlhGul1DA9lx6EpnaeedLlIW4iktyf2tnX8N/wy6GuieYpxsnZsxvEiSdLJpuqWbp+6vbSQUkiYLIhB7MjV/EZlRmJcjbgThKBqQphlx+Vun6fcXF35dJtY5xyn0tiWhLjo8JY1ibsU/u/9TKdRh4xt9Tl6LU8Eql9JY9JHJHI0cilJENGRhQgjxzUkU7+JBFhrIpdirsVQGt6lJYWLSQRNPeykRWVuil3kmf7ICjdqfay3Dj45U0ajOMUCev8KM8j/kZCAuqecWNzdyn1P0WrHgpO9bh1NZH/AJo0+D+bnm7AoU80SSST1erKNL0qySJRDY2UQpHEgWKMDwVVp+GCU4x5llDHKXIWlF1570qElbeKS4I/aACL97b/APC5iy1sRy3c3H2bOXM8KWzfmBesT6VpEg7c2Zj+HHKTrT3OTHsuPWRUP8d6vX+7gp4cW/5qyP5yTP8AkzH3lcnn3VAfit4GH+yH8Tj+ckg9mQ7yiYvzAP8Au2xHzST+oyY1x7mo9ld0vsR0PnrR3p6qTQn3UOP+FP8ADLY62HW2qXZmQciCm1nq2m3wpbXCSkj+7rRv+BNDl8csZci4eTBOHMILV/KOgarbzwXVqAtwjRytEfTYhhQ7r3wHBAm63ZR1WQCr2ee3v/OOHlqQk2WrXtt4LIsU4H00jb8cttpYt5k/5x51zT9PmvNJ1GPVDApka0MRhmZVFT6Z5OjN/k/DyxV6z+RfnnQPL3k/T/Lt9bPYyIWknv6845J52Ls0gADR0qE/a+zmFDVgkg7Oxy9mzjEEHi2+l7pDLHLGkkbq8bgMjqQQQehBHXMoOuX4VdirsVdirsVdirsVdirsVdirsVdirsVdirsVf//R9U4q7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FWJfmF51j8uaaEt+L6rcgi1jO4QdDK4/lX9kftNmPqM3AP6TlaTTeLLf6Q+e9eto9chuYdUkM73hLSyuauX6hwT+0p6ZrI5JCQl1d9LBGUODo8S1fTLvSr6eyuB++gPwsOjjqjj/JbNxjmJCw85kxmEjE9H2Po1/FqOj2F/CwaK7t4pkYdCHQN/HLGoovFDDfMnmyYyvZac/CNarLcL1YjqEPYf5Wa/PqTdRdvpNAKEp/6Vhl1fwQyqszu9xMT6cSK8ssh/yUQM7fdmHwmXJ2hIiO4OWy8+3bBdJ8napcBvszXERtU/5K0P35dHTSLiy1kB1Qev6D+b+j6Y2panpVnpVrzWOMTTRvI7t0VUWRyx74ZabhFlGPVjIeGHNgWqed/M9jKIpryL1ju0UUaNxH+UStB9+DHp+Lcck5tV4ZqXPyZp+XHlr81PPek3eraJd2YtbSb6uReqI/Uk4B2CcI2+yrLWpy78m457SCK8y2P5l+TUhl80aJE9pMxjjurKVWDMAWpQFjXiK/Ei5Tk0/C5GDVjIaDWjeYtK1dCbSWky/3lvJ8Mi/R3H+rmPKJDlRkCnFrd3NpMJraVopB+0pp9/jhhMxNhE8UZipC2ceXPNS6gwtLsCO8p8DDZZKfqb2zZ6fVcZo83SarQ+H6o/Sv8z+WxqSfWLUBb5BSh2Eg/lJ8R+y2S1Gn49x9SNJrDjNH6WC3VjeWjlLmB4WH8wIH0HpmrnAx5h3kMsJC4m1Co8RkGyj3K9tZ3d04S2geZj2RSfx6DJRhI8gwnkjEbkBm/lnyulhxu7tVa/IITo3pBuoU/wAzftEZs9Ng4BZ5uj1mq8TYfSF3mPzOmmn6tbgS3hFSTusdelfFv8nDqNRwbD6kaTRnJudo/wC6YJfX1xcO1zeTFyBVnkNAoH4KM1UpmRsu7hjjAUAxS688QPcrZ6NayancuwjUr8MfNjQCvU7nJRgeqJZaZlZ/lJ+emo8Wki03R4234zSh3X58BPmZHSd7gy7Rj0eSaz5v83aPrV9pF9dBLzT55La5CxxMoeFyjcSF3FRtg/KIHaI8050HVfO+q3Vpb2M9ldNeuI7dpSsSM7bKpf4QpJ+H4v2soEBxcPIuackuDjHqizSbyn+c1jvfeT2uVB3aymic09gruT92WHSyaBr4KEt3eWY/3MaTqGjEUq17aypFU/8AFoUx/e2VywyHRvx6mMuRRKMDxdG8CrqfpBBGVN3Nlfl3zbNHIlpqL+pCxCx3DH4lJ2HI9198zMGqPKTq9ZoRXFDYs0zYunCy5uEt7aadzRIUZ2PgFBOCRoEsoRMpADqXjdkxW3Dmg9UlyD/lHNEHrZjeu4PQfy38/S6Ndx6bqEhbSJmojMa/V3b9of8AFZ/bX/Z5lYM/DsfpdZrNIJDij9X+6e4qwZQRuD0I3GbN0jeKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV//S9U4q7FXYq7FXYq7FXYq7FXYq7FXYq7FXYqo3t5b2dpNd3DcILdGklc9lQVOCUqFpjGzT5q8zeYbjWNTu9Xuq1kJMcX8ka/YQfIf8NmlyTM5WXpsGIY4iISSGzSSP1Lgc5ZNzXtXsMg3Wxnz15fa7sBPGC91aKWgenxPEN3iPiR9uP/m7MrTZeGVHkXB1+n442Pqim35FfmRcW93b+T9SPqWlwxGk3HeKQgv6J/4rejFP5H/yW+Hauge36xcNbaVeTqaNHC5U+9KD8crymoE+Tbp48WSI83lh8OtO+aQF6ZN/J92tp5q0m4c0RLqMMfZzw/42y7DKpho1Mbxy9z6Spm4ebfO//OS+uSprVlYb/V7Cye7KA7GSVmFfoWL/AIbMHVG5CLuOzvTjlPr/AMSOJ8rySySyNLKxaSQlnY9yeuZkY0KdXKRkbL1D8l/zyvPy5+uWVxZfpLRL1xM9ujiOaOYKE9SNiCpDIFV0b+Vfi/mkxIZRrX5sR/mz5us7C8vrfyh5e0yGe5t/rjesbi4KhAjsvBQ5Un01X7Px/wB47KuVZoiUS3aXKccwQn/kv8sNL8++SLma2I0zzXo9yyWGqR/DzDoJUjuOP215My8/tx/6nwZjYYCcPc7HW5Diygj6Zj/jv+9Y5pOoX7XF3pOsQG013S3MN/bkUqQac1/yW9v9b7LLmHkx8Jc3DlExaaxyPHIskZKyIQyMOoI3ByANG20gEUXqWlXwvtOt7ro0qAuP8obN+Izd4p8UQXmM2PgmYoogEUO48DuMnTUDSn9Vta19COvjwX+mR4Qy45d5VAABRQAPAbDJAMSbQ+o3i2VhcXZ6woWUHu37I+/IznwxJbMWPjkI97yueZ5JHmmersS8kjHv1JOaSRt6iMREUOTf5feQL78z9Sku7t5LTyRp8vpsUJSS+mXcqrdkX9p/2f2f3n93mafTgiy63V6zh9MeaTebdN0NtQ81m01S08rx6IXGjW5SnrNaPwSGHiR+9b0q8/jkZ35fF8WHHESyHyTmyHHpx/T+qTIbT/nMedNAWO68ver5gWPj66zBLR3Ap6hTj6i+JjX/AJGZnulD511bU73VdUvNUvn9W8vppLm5k6cpJWLsadtz0wFkE78k3kq3U1mGIVk9WMj9l1IFR9+YerhsJO07KyHiMD9JfenkvVpNX8paRqc399d2kUkp8XKjkfpbMrGbiC63PHhmR5sf/OO6WLyh6JPx3NzEij/Vq5/4jlOrlUHJ7PjeS+54cOmap3y4Cpp2O2FL0HyNqUupeT9IvZm5zS24Er+LRsYyf+FzeQ5B5PJ9R95Yr5/84PJPcaDZghInEV3L3kcgN6a/5K1HPMHWZiPSHc9l6QV4sv8AMY9HYx8B9YHqSUAJPQewGYAdpbVtyjle2JqqjlGT14namFD3X8o/M7alpEml3L8rvTuIjY9WgbZP+AI4f8Dmz0uTijR/hdDr8HBKxykz/MpwXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq//T9U4q7FXYq7FXYq7FXYq7FXYq7FXYq7FXYqwn83tRe08oSRIaNezR27f6m7t+CZjauVQ97maCHFk9zwS8BaHh3dlX7zvmqegCvSm2KrJYxIhU9O3sexxV5iLJtA/MLSZl/dwi/t54iOigzKHX6Kn/AGObfT5eOPm8/rMHhz25F9OeahTQ74D+X/jYZLUH92WvRD96HmmaZ6NwLKQykhlNVI6gjocVfSHk/X4td8v2t+rD1mUJcr3WZNnH3/EP8nNzhyccQXms+Lw5mLxr/nJXy7I99p+rhCbW7t3sLiQfsupZ0r/rK7/8BmLqwQRLudl2bIShLGf6z5QurWa0uJLeYUkjJB9/cex7ZmRlYsOsyQMJGJUskwTPy3p8l5qsJA/dQMJZm7AD7Ir4s2U58gjEuXosJnkHdF9q/kJoM2neSfrlwhSTVp2ukB2PpBVjjP8AsgvP/ZZDSxqHvZ9p5RPLQ5QHCxr/AJyH8nfVvqn5hadHS400rb64qdZbJyFEh8WhY9f5G/4rx1GPiDDRZuGVd7BAysAymqkVU+IOax3weg+SWJ0FQf2ZZAPvB/jm00f926HtH+9+ARWv69DpNup4+rcy19GKtBt1Zj/Lk8+bgHm16XTHKfIMV/xzrfKvGCnhwP8AzVmF+cm7P+Tsfmyjy9r8erQNyURXMVPUjBqCD0ZfbM3BnGQebrNVpTiPfEqXnJiNBlH80kYP/BV/hkdX9BZ9n/3oeW3+m6jr2o6b5V0w8bzXZjC81KiK2Qcp5T7Kn/NOa/BDik7jVZeCL6n8u6Dpvl/RLLRtMi9GxsIlhgTvQdWbxZzVnP8ANm3Ap5yRJNvkr89/KN5aeZ9Ztgjfvbg6jZf8WRzEuQPkzSJ/rLmATwZfIu6rxtNt9UXijdfltmwdNTWKhlfkXSruW4NxHGzyT0trNAN5HdgPhHf4uK5haqd1EO27Ox8N5DyfenlfSP0P5c0zSyatZW0ULkdCyqA3/DVzLgKADqs0uKZLyf8AOHzAt/rUOlwNyh00H1adDPJSo/2C0H+tyzXazJcqHR2/Z2HhjxH+L/csAGYjsVyfaHzGFIZh+U4P+AtOU/sy3ij5C8lGb2HIPJ5PqPvLAdQ/0rzXqE9Ph+tTEf7FiK/hmkzS4pn3vWYI8OGI8kbkFUJFIuYXHfkh+6owqzH8sNRey852IBol3zt5B4h1JX/h1XLtLKpjzcPXwvGfJ9ADNu8+7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FX//U9U4q7FXYq7FXYq7FXYq7FXYq7FXYq7FXYqwP85bOSfyok6An6pcxyPTsrBo6/ewzF1g9Hxc7s4gZa7w8QIBpUdDUfPNZbvg3gV2KsU8/acstlDeoKzWbrMKdaRkFv+F/4jmTpcnDL3uJrsJnjNc4+p7x5g/f6Fdsu/OHmPuDZsdQLgfc6XSmssT5vMs0oeldihkfkjzndeWdRL8TNp9xQXduOpp0dK/tr/w32cuw5jjP9FxdVphlH9J7NcL5X87+XprQut7p90oEgU0kjYbqafajkRtxm0Bjkjs6T14Z39JD518//wDOPvmC0ldorRtYsFJ9C7tBS4Ra7B4x8Vf9Tmn+rmJ4eTGbjuHajUYM4An6ZPPbf8otTkufSTTdUmkr/ci3kU/SfTGP5jJ3I/I4BuZ7e97L+W3/ADj5d+pDceYbddP0uM8/0YprNMfCUqT6a/zfF6jf5GGGCUjc2OXXY8ceDEP859BgQW0AUBYoIVAA2VFVRQDwAAzOdPZJee+f/wAxPLD6RfaLCo1V72GS2nVD+5VZVKNWTfkaH9jMPLqoDYepz9PoMkqJ9IeMxRrFEka14xqFWvWiigzXEu8Aej+TIyugREj7byN/w1P4ZtdIPQHQdoG8p9zE/N12bnXJlrVLcCFfo3b/AIY5harJcz5O00OPhxjzSfMZy028q3htdctiTRJiYX8CH6f8NTMjTT4Zhxdbj48Z8mX+b4y+gT0/YZHPyDD+uZ+r3gXUdnyrKGLeSNc0/wAveZ01m6tGuWFu9oGRqNGkrq7soOzMeCj/AFc12DNwHd3Gr0xyxFHd7xonmjQtbhEmnXaTNSrQk8ZV/wBaM/EM2kMkZci6LJhnA1IJN+Yn5eab5x01IpX+raja1axvQKlSeqOP2o2p8Q/2S4MuITDZpdVLDKxyfMnnD8i/MlldSNdaRO1CT9e08GaJ6ftEKGI/2aI2YoOXHt9QdlIabNvfBJJtF/JrWr26VLbSNQvHrTjJC0MY/wBZmEa0+bY+LllsBSx0unhvKXE+ifyq/JaPy5NFrGt+lLqkQ/0O0i+KK22pyr+3LTYU+CP9n+bLcOCjxS+pxdVruIcENoJ556/Myw0mCWx0mVLnVWBUyIQ0cHux6M/gn/BYNRqRHYfU16XRymbO0XibyPI7SSMXkclnYmpJJqSfpzWF3zWKrk+0PnhSGfeQLUWflDTY6caiWYg/8WzPL/xtm8x/SPc8pl+s+95pafvLy6n7M70P+sxOaI7kvXHaIHkjMWtogHr23HzwpZL+XNlJd+dNLCDaGQzyHwWNSf18ct08byBxNdKsR830MM3DzzsVdirsVdirsVdirsVdirsVdirsVdirsVf/1fVOKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KoXVNOt9S0+4sbleUFzG0cg9mFKj5YJAEUWUZGJBHMPm7XtEvtE1WfTb1aSxH4HH2ZEP2XX2bNLkhwyIelw5hkHEEBkG12Kpbq6iceiRyVVLSD2b4aYWcOdd72DSZYtR0C1dTVLi2VT9KcSPoObmHqh8Hls0TiyEfzZPM5I2ikeJ9mjYow91NM0xFGnpBKwCtwMnYVVrS9vLKcT2c8ltMOkkTFG+8YxJHJjOIkKItk1n+afnW1UKb1LgD/AH/ErH714N+OXx1Uw40uz8Z6UmC/nN5s40MVoT4+m/8AzXk/zk+5p/k3H3lC3P5tedJgQlxDbg/76hFfvcvkTq5lnHs/EO8sc1PX9a1Q11C9muR/JI5K/wDACifhlMskpcy5UMMIfSAEvyumwlv5dewxpXqFii6ZokIk2FtAGkr4gcm/HN3AcEPcHmMh8TKf6UnmMsryzSSuavIxdj7sanNMTZt6WMaAC3AltHZGDps6EMp9wajCDSkWKenyhdV0Rwm4u7eq/wCsVqP+GzdSqcPeHmo3iy7/AMMnl9CCQRQ9x75pKemttHeN1kjYpIu6upIYfIjEIIvmyLT/AMxPOViAsWpySoP2LgLMPvcFv+Gy+OpmOrjT0eKR3CbR/nH5vUUZLSQ+JiYfqfLPzkmmXZuM8rWzfnF5xkFE+qxe6xEn/hmOJ1clj2bDzSLVfOfmnVEaO91KZ4m+1ChEaH5qgWv05TLNOXMuRDS44cgklB0ypyHUxQ7FVyIzuqIKu5CqPc7DCBak0LenXckWlaDNJ0jsrY0H+olB95zdSIjD4PMQj4mSv50nk+nLS0U9S/xE/PNGHq8puSJwtbsLIPZvyi8qTafp8ms3cfC5v1At0bZlg61I7GQ/F/q8c2Wlw8Is8y6LtDUCcuEcovRBmW692KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2Kv//W9U4q7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FWM+efJdr5l03gKRajACbO5PYnco3+Q3/AAv2sozYRMebk6bUnFLyeBX9hd2F5LZ3kRhuYG4yRt2P8QexzVSiQaL0MJiQsckLNII4nk68QSBkWagtuRaysx5SSrydvxAGJUc2Vflp5kieWTy7O3GdIfrlkD+3HzKTKPeN+L/6smbXQm4e50na8ay3/OC3zlpptdVa4Vf3V38de3MfaH/G2Yerx8Mr/nOX2bm4oV1gkOYzsC7FXYoLsV4nYodirsVdilN/K2ltf6tHyFYLciWY9tvsr/smy/TY+KfkHF1ubgxnvPJknnjURDp62an97dn4x4Rqan7ztmbrJ1Gu91nZmHilxdI/7pgmat3zsUOxQznyNqPq2T2TH47Y8o/9RjX8GzaaPJca7nTdp4qkJj+JIPNmmGy1V3VaQXNZIz2qftr9+Yuqx8MvIudoM3HCusUlzFc12KHYodiyBdiguxQ7FXYsrCeeUNNN3qqzMKw2tJHPbl+wPv3zJ0uPil7nA7QzcOOhzkjvzL1j0rGLSoz+9uyJJvaNTsP9m/8AxHMjXZKAj3uP2Pp7kZnlH/dMLtVaGQ2x3RVDRn2rShzXB2x5orFXoX5a/l82pyx6zqkdNNjPK2gYf37D9oj/AH0P+Sn+rmbp8F+ous1us4fRHm9nAAFB0zYumbGKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV//X9U4q7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYqw78wvIsPmGyNzbKqavbqfQk6CRRv6T/8AGjfstmPnw8Y2+py9JqTjlv8AS8HuFaBmjmQo6ErKrChUg0IYexzU8noQQRYQxHokAGtu+2+/GvTf+XFIa0FxaXqX8SL9ctGIilIHIK32kr14v+1kseSUTsx1GKM+Y6PUGGn+ZdGoDxD9D1aKUDv/AJ/EubX05oPOevTZPx6osB1HTbzT7k291HwYbq37LDxU981mTGYGi7/DmjkFxQ2Vtpdih2LKw7FXYsXYpV7Gxur65W3tkLyN18FHix7DJ48ZkaDXlyxgLL0XTdPs9C0tg7iiD1Lmc/tNT/MKM22OAxR3efzZZZ8m3+a8/wBX1OTUr+S7cFQ3wxIf2UH2R/XNXlyccrd/p8QxwEQg8qbHYq4YqjNK1GXTr+K7j3CGkifzIftDLMWTglbXmwjJExegX1nY67pahWBjkHqW8w3Kt2P8GGbWcY5YvP4sksGT/dPPNQ067sLlre5TjINwezD+ZT3GarJjMTRehw5o5BcUNlbY7FDsWQdigl2KHYqiLDT7u/uBb2yF3O5PZR4sewycIGRoNeXLHHG5Fn0Edj5c0arGoXdz0aWU9h/n8K5tI8OKDopGWoybf9IvKdTv7nUtaluZDzmmkqAfsqq9B/qqBmpyTM5WXpsWMY8YiEVGojPGpeVt3J6n3PgPDA10zn8uPIp8wXf169UjSLZqMOnrSDf0x/kj/dh/2OZWmwcZs/S4Ot1Xhjhj9f8AuXuscaRxrGihUQBUVRQAAUAAzaOhXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq//0PVOKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KtHviryP84vKywTReYLWMBJiIr5V/35+xJ/sgOLf7HNdrMVeoO37Nzk+g/wCa8se0t3FKEA9VqafdmE7ZC6WzCSRT1pWvyNMAZyGwKe6Tq93plx61udm2kiP2XHgf65biymBsOLn08coos2tdX0LXbf6vMq8z1tptmB8Ub+K5s45YZBRdLLDlwSscv5yV6h5Dbkz2FwB4QzdvYOP4jKMmi/muVi7T6SCSXHljXYD8Vozj+aOjj/hcxZaeY6OZHW4pcignsrxPtW8q/ONv6ZDw5dzkDLE9QtWzvHNFt5WPtGx/hj4cu5TkiOqNt/LmuTkcLORQf2nHAf8ADUyccEz0aZ6rHHqnVh5ClajX84Re8UO5PtyIoMyoaE/xFwMvag/gDIgNG0O06JbRdd93c/8AEnOZXoxjudfeXPL+cwrzB5im1ST00rFZIapH3Yj9p/6Zrs+oMzt9Lu9JpBiFn60lBqK+PTMZzG8UOxV2Ktcvip92KQnHl/zFPpMpVgZbOQ1ki7g/zJ7/APEsyMGcw/quJq9IMov+Jmw/Quu2YpwuIutDs6H/AIkhzZejKHS1lwS/msf1DyHIGLWE4K9optj/AMGNvwzFyaI/wufi7TH8QSS48t65ATytHYDvHRx/wtcxJafIOjnR1eKXVBNZ3iGjW8qkdjGw/hkOCXc2jLE9W0srxzRLeVielEY/ww+HLuQckR1Rtv5Z12cjjaOgP7UlEH/DZZHTzPRqlq8UeZTuw8htyDX84p3hhrU/7I/805kQ0X84uBm7THKITa41PQdBtzbxBQ43FvF8Tsf8tt6f7LLpZIYhQcaGHLnlZthGsa1eanOZrg8UQH0oR9lB7e/i2a/LlMzu7rBp44hQY3psXrXUshqOA2oSDv8ALKHNycmR6Bosuqara6Zaji9zIFL9aDqzH/VUE5ZjgZEAONlyCETI9H0lpWmWmmafBYWaenb26BEXvt1J92O5zdxiIig8vOZlIyPMozCh2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2Kv8A/9H1TirsVdirsVdirsVdirsVdirsVdirsVdirsVdirqYql3mHSItY0a702X7NzGUVv5X6o3+xYA5GcBIEFnjyGEhIdHzTcW81tcS286lJ4HaOVD1DKaEffmkIo09TGQIsIBgI9QjIFFkWn05FtH0ozC0h2KUws/MOs2dBDdOUHSOT41/4auXQzzj1cbJpMc+YTeDz7qK0E1vFJ4lSyH/AI2GXjWy6hxpdmxPIkI1PzCtz9uzkH+q6n9YGT/PeTjnsqX84Kh/MCwptbTk+FV/rkvzw7ij+TJd8f8AZKEv5gJ/uqyJ8Ocg/gDg/P8Akyj2UepS2787azMCsXp2yn+Qcm/4Jq/qymWsmeWzk4+z8cefqSSe4nnkMs0jSyHq7ksfxzGMiebmwiI7AUhZXBlSDu45N/qj+uRZK23bFLsVditOxVZNXgWH2k+IfRiropFkjWRfssKjFKtDPNBIJIZGikHR0JU/eMlGRHJhKIlsU7tPOutQALKUuVH+/BRv+CWmZMNZMebhT7Pxy5elM4vzAT/d1ia9ykg/iMuGu7w40uy+6St/ysCwp/vLPXw5L/XJ/nodxYfyXL+dH/ZLX/MG3A+CzkJ/ynUfqByJ1w6BI7L75D5IGfz9qDikNtFH4FiXP/GuVy1sjyDdDsuA5kpVd+YtauwRLdMEOxSP4F/4WmY8s85cy5ePSY4cglvc+/XKiXIUbtuNtKf8mg+nbAyiLKhpSUid6faNPuyIZ5Tu9f8AyX0ElrvXJl2H+jWhI+RlYf8ACp/wWbHRY+cnSdp5eUB/Wer5nuqbxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2Kv/9L1TirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdih5L+bHki4+sN5h06IvG4/3IRIKkEbCYAdqbSf8FmBqsO/EHb9narbgl/mvJL8UWKYf7rYGvsc15d1HqEVWorhDU3irsVdirsVdhtXYFdirsKoa7t5WKTQECePoD0I8MCQg31adW4PGIn7hgfwxbIwCm95cuP7w0/ydv1YLbREKYmm7SN95wJoLxf3EfWU/I74sTEK0c99doYwoVG+1IQRtkg1EBMYo1jjWNeiigxYL8UOxV2KuxWnYrTsVp2KuxVB6m9IVQdWbf5DEt2Ibpz5S8tajrlzDp9inxGjTzEfBEhO7sf8AiI/ayWHGZmg42qzxx7l9IaNpVrpOl22nWi8YLZAi16k9Sx92PxHN3GAiKDzM8hnIyPVG0wsXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FX/9P1TirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirRFeorigsN8x/lT5T1oSN6LWNxJu0tqQoJ8TGQU/DMfJpYS8nNwdoZMf8ASH9J475n8vP5e1qbSmlM6whDFMwCl0ZQQSB92azLj4JU7vBmGWHFytKsg2uxQ7FXYq7FXYq7FXYq7FVskcci8ZFDjwIrilDHS7GtRGVP+SSMWQmXHTLQ9Qx/2RxpPiFUjsrSM1SJQfEip/HFBkSr/qxYuxV2KHYq7FXYq7FXYq7FXYpeh+Rvyq0fX9Lg1jV5Zyjs4htYmEaFFalWYAv8RB+yVzOwaUSHEXWantGeORjB61pOi6VpNotpptslrAv7CDr7sTux92zOjARFB1GTJKZuRso2gyTB2KXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FX/1PVOKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxVxxV5P+dujkPp+sIuxBtZ2Hj9uOv/AA+YGthyk7XszJzi8tzAdu7FDsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdiq6GGWeaOCEcpZWEcajuzGg/E4QLNIkaFl9NaJpsel6TaafHTjawpFUdyq0J+k75u4RoAPLzlxSMv5yOGSYuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2Kv8A/9X1TirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdiqUebNCj1zQbrTWoHlWsLn9mVfiRv+CH/A5XlhxRIbMGUwmJPm+eCa3nkt50Mc8LGOWM9VZTQj780pBBovTxkCLHJZil2KHYq7FXYq7FXYq1UVpXfwxSuEch6Ix+QOGlXfV7ntE33f240rvq9z/vl/uH9caKGjDOOsT/ccaVaQw6qR8wRjStVHjjSt40rqHFXYFdirsVdirsUs6/KTy22o69+k5krZ6b8QJ6NOw+AD/VHx/wDA5laTHcr/AJrr+0M3DDh6y/3L3AZtHRuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV//1vVOKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2Kupiry382PJDTB/MOnJWRAP0jCo3ZRsJgPFR9v/ACfizC1eC/UP852nZ2qr0S/zXk+a53DsVdih2KtVxVSSCQOQtwVUn9pQ4FfuOFUamm3Q3EkMo7clYfqOERW0RHHqEeyx29PbkP4YaRaqG1DvHF/wbf8ANOSQ7le/77j/AORjf8042mg6t7/vuP8A4Nv+acK06t5/vuP/AINv+acUUuBu/wCWMf7Jj/DAVWtFO/2lh+kMf6YKVRexNCWMSAdSEP8AFsSEhLJ7WOV6GR2Qfs/ZB+gZFKoAAKDoOmBW8CuxV2Ko7Q9Fvta1OHTrJeU0x3Yj4UQfadv8lcnCBkaDXlyxxx4i+ifL+h2WiaTBp1oP3cQ+Jz9p3P2nb3Y5uMcBEUHm8mUzkZFMsmwbBxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV/9f1TirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVaZAwKkAg7EHpTFDxH8yvITaLcNqmnRk6VM1ZEH/Hu7dv8AjGx+x/L9n+XNZqcHCbHJ3mi1fGOGR9TBMxHYuxQ7FWqYq7FVe3unhNOqdx/TJAqQmMc0Ui1Vq+I75K2K/CrsVdirsVbxVSmuYYti1W/lG5wWmkvuLqSUn9lOyjIkppRyKuxV2KuxVVtbW5u7mK1to2muJmCRRLuWY9sMQSaCJSERZ5PffIfku38tadR6SalcgG7nHanSND/Iv/DfazbYcIgPN57U6g5Zf0WT5e4zsVbGKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2Kv/0PVOKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV1cVUrm3guYJIJ41lhlUrJGwqrKeoIwEXskEg2HhHn/yJceXbv6zbBpNHnb91J1MTH/db/8AGjftf62avPg4Nx9LvdJqvEFH6mI5jua7ArsVdirsVcCQag0PiMVVUupF9/vH6sNqqi+PcN94/iMNpXfX/wDW/D+mG1Wm+fsD9J/pTBaFJ7qdhTkQD2G2NqpYFdgV2KuxV2KrooZZpUhhRpJZGCxxoKszE0AA8ThAQSALL3L8vPIMegWwvb1Vk1idfjPUQqf91p/lfztm10+DgFn6nRazVHIaH0M2pmQ4TqYq1TFWxirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdir/9H1TirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVaxV2KqN7ZWt7ay2l3Es1vMpSWJhUEHIyAIopEjE2Hg/nzyNdeW7z1YQ02kTtSCc7lCf91yHx/lb9vNXnwmHud9pNWMgo/UxTMdzHYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYquiiklkWKJGklkIVEUVZmPQADrhAtSaFl7Z+Xf5fJoka6lqKq+ryr8KdRApH2R/xYf22/2K5s9Pp+Dc/U6PWavxDwx+j/dM7AoMynAbxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2Kv/0vVOKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxVrFXYq2MVUL6ytb60ltLuJZreZSskbioIOCUQRRZRkQbDwnz35Cu/LlybiDlPpErUim6tGT0jk/41f8Aa/1s1efAYb/wu90mrGTY/WxLMZzXYodirsVdirsVdirsVdirsVdirsVXwwzTzRwQI0s0rBY40FWZj0AGEDdBIAsvbPy9/LuLQ411HUVWTV5B8K9VgU/sr4v/ADP/ALFc2en0/DufqdHq9YcnpH0f7pnY6ZlOC7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FX/0/VOKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV1MVdtiqB1XW9K0mD1tQuo7dO3I/Ef8AVUfE30ZTm1GPELmRFuwafJlNQiZlgerfnHboxj0mzM1DQT3HwL9CD4vv45os/tBEbY48X9KX44nodN7NTO+WXD/Rh+OFhuu/mL5ivbSZb27SKzkUrLEkaqpU9twzH781WTtbU5TUTXlEO4xdjaXFuRZ/nSkwuK5jlJ47CtUr3U9M22InhHF9Tr5gWa5KuWMG8Vdih2KuxV2KuxV2KuxV2KrXdUQsx4qBUk4ppU8veaBaXwls52tL1aiKXbcHY0r0rmu1eXPA8WM7B2GDTYZx4cg4noOm/mz5mtmC3YivYxsea+m//BJQf8LkMPb2aP1VP/Ytef2dwS+gyx/7L/dM10P80fL2ossVyx0+4bYLPT0yfaQbf8Fxzd6btnDk2P7uX9L/AIr6XQavsLUYtwPFj/Q+r/SfUzCORHQOjBkbdWUggj2IzbAg7h0pBGxXYUuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV//9T1TirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVWyypFG0kjBUQVZmIAAHck4CQBZUAnk8181fmuEL2ugAO26tfSCqg/8Vqftf6zZzmu7cAuOL/T/APEvUdn+zpl6s3p/2v8Ai/zv5rzW8vLu9uGubyZ7id/tSSEsf7M5rJllM3ImResxYIY48MQIx/ooK9vYbOEyyn2RR1Y+Aw4cMskqC5cogLLE9Q1C4vZOcpoo+xGOgGb7BgjjFB1GbLKZ3TMwPHGjDdeK/F4bd8yHBJREFzX4X6+OTBQQicLFvFXYodirsVdirsVdiq13VF5MaDElKX3kzSRv2XiaLgtlDmknfKy5SdaRrhQrb3bVj6Rynqvs3tms1eiB9UOf81ztPqa2kyGgI8Qc1NuwTvy95v1vQpB9Um9S2/btJatGfl3Q/wCrmdo+0cuD6TxR/mSdfreysOoG44Z/6pH6nr3lXzxpOvxcIj6F6orJaSEcvcof21zrtF2lj1A29Mv5jxWv7My6Y+r1Q/nsjGbB1zsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdir/9X1TirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdiqH1DULPT7SS7u5RDbwjlI7dh/XIZMkYRMpGohnixSySEYjilJ4p5y893+vytBCWt9KU/BBWjSU/ak/wCaPsrnF9o9qyznhj6cf+6/rPedl9jw044perL/ALj+p/xSQ2el3l0KovGP/fjbD6PHNVVuyyZ4w581HV1tdNVi83MxispAoB4KPFslDGZGgxx5yYmRHDFg19ey3k5lk2A2ReyjwzocGAY40HW5cpmbKHy5rZWqj01HUcQCPowhxDzQ81qV+KPcd18MKrYrpk2Ycl/EZK1pELcwk/ap89sNoVAQehBxQ3irsVaqMVWmWMdWA+nFVJ7yMD4fiP3DBaaQryM5qx38MCacYZJInIFF4nc9OmKRzSMZAuUHYEp9oOqtVbKc1B2gc/8AET/xrmr1um244/5zm6XUfwn/ADWU2WnXN5yMQAVdiWNBXwzVxFuXlzxhzWyQ32n3COeUMqHlHKhoQR3Vh3wgmJsc1EoZYkfUD/C9U8h/mIupmPTNVYJqHSG46LN7H+WT/iedb2X2uMtQyfX/ADv57xna3Ypw/vMf93/F/tf/ABxnwNc3zoG8VdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVf/1vVOKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxVbJIkcbSOwVEBZmJoABuSTgJpQL5PDvPfnGfX78xQsV0q3Yi3T/fjDb1W/wCNP5Vzie1O0Tnlwx/u4/7L+k9/2P2YNPDil/ey+r+h/Q/4pA6XooYLPdLUHdIv4t/TNWIuTqNV/DFMtQvPqlozjZvsxL/lHp92GRoOLgxccqeWa/qTXNwYVYmOJiWNftP3P0Zt9Dp+CPEfqk26nICeEfTFKc2DitgVYDxNMVZYBT6MLht4VUJrZHNR8LfhilCPE6H4ht49sKrcVXCSQdGP34q71ZP5j9+KrSzHqTirsVVI7eVxUCg8TiqJjtI0NW+M+/TAtqrjkhHsRjaQd2JjIW5QdhS3UjcGhHQ5Ei0PTfIepC80yQMf9IicCUeNRs300zSajB4ctuRbcuTjr3MjnginiaKVQyN1BzGa4yMTYYvqOnyWMylSfTJrG461G/Udxle4LtcWUZBRetfl350OsWhsL166nbLXmes0fQP/AKy9H/4LO07I7Q8aPDL+8h/sniu2ezPy8+KP91P/AGH9H/iWa5uXSuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2Kv/1/VOKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxVgH5s+YXs9Oj0mBqTX1WnI6iFe3+zb4f+CzQ9vavgxjGOeT6v6n/HnoPZ7ReJkOQ/Tj+n/hn/AB15xoeniaQ3MorHGaIpGxb+i5yQD1erzUOEMhybrWIedtVMKsiN8SDhGP8ALYVJ/wBiMu0+HxJgdHOxHw8Zl/FJ55T6fE5vnBawqqWy87iJfF1H44USZVi4jsVaOKtddsVU3tom7UPthVYbJezHFLQsh3b8MVXi0iHifniqqsaL9kAYquxQ7Arh1xUMTkXjK6/ysw/HIuWOS3Cl2Kpz5U1htL1iKVjS3m/dXI7cWOzf7Bt8x9Ti44V1V61miVTubaK5haGUfC3Q9wfEYCGcJmJsMcsru90PWIrqI0ntXDDwZe4/1XXbJ6fPLDkEx/C7LNihqcJieUx/sv8ApJ9B6bqEGoWNveQGsNxGsiH2YVpnoWLIJwEh/E+aZcZhMxPOJpE5YwdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdir//Q9U4q7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYqsllSONpHYIiAs7E0AAFSScBIAsrRJoPA/N+sDXvM891b1MLFYLWvdF2B9uRq2cD2jqvHzmQ+n6Yvo3Zem/L6cCXP65/j+qm1vCkMKQp9lAAP65iuJORkbK9mCqWPRQSfowsebyXzPfNdamwJ+GMn/gmNT/TNvocfDC/5zk6mVHhH8KT5nOM7FUVpi8r6H2JY/QK4WMzsyLFxXYq2MVbxV2KuxV2KuxV2KuxV2Ku74qxnUE4Xsw/yyR9O+ByYckPizdirsCvV/JuqHUNChLms1t+4l8fhHwn6Vpmk1ePhn5FU7OYypP5ituUKXCj4kPF/kemRkHN0c6PCzv8AKTzDBNpzaLK9Lm1LPAD0aJjU8f8AUY751fYOrEsfhn6of7l5v2i0Rjl8YfRk+r+jN6GCD0zfvOuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV//R9U4q7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FVruEUsxAUCpJ2AA7nEmkPL/AMwPNN3qVpNZaceGmx/70TdGnoeijtGP+H/1c5PtbtTxBwY/o/il/P8A6v8ARer7G7PjjmJ5Pr/gj/qf9b+mwbRYg+oJXpGC33bZz0Q9Lq51D3slGWU6lB6zci20q6nPRI2OERsgBsx/UPx9LxpnaRmdjVnJZj7nfOkEaFMCbNtYUOxVNdGtZFc3DLRCtIye9epwtOQpvi0OxS2MVbxV2KuxV2KuxV2KuxV2KuxVJdatJfW+sqKxsAHI7EYG7HLolhxbmsVdirLfy4v2i1WeyJ+C5j5KP8uPf/iJbNfr4XEHuV6NTNUqG1CISWM6dyhI+Y3wFsxSqQYvY3l1ZXUV3ayGK4hYPG47Ef57jBiyyxyEompRdvmxRyRMZDijJ7b5N88WOv24hbjBqcY/e21dmp1eOv2l/wCI52/Z/aUNQK+mY+qH/Evn/aXZc9LL+djP0z/4r+kynNm6t2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV//S9U4q7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYqpzzRQxPLKwSNBydjsABkZyERZ2ATEEmhzed+Y/M8+pu0EBMdgDsvRpPdvb/JzkO0e1JZjwx2x/wC7el0PZ4xDilvk/wBwkLoHRkPRgQfpGah2YNFItDiMeozI32o0K/8ADAZCLsNZK4Ap8Mm69IPPcrR+WbkL1kZEPyZhmTpI3kDIF5WB4b5uxuwuuaJi0+7kpxjIB7t8P68zcPZ+bJyFf1nXantbT4tjLiP82HqR+n6VGHZ56OyHZR9n+3MaeMwkYnnFux6nxMcZjlMcSbZFWqYq6mKuGKt4q7FXYq7FXYq7FXYq7FXYq0QCKHcHtikJPd6ZG9yVhPp13KkVHTt4ZZgwnJMQBriYZ9X4OMzI4uFCS6bdx/scx4rvmRl7PzQ5jiH9Fp03bOmy8pcMv5s/T/xSGIINCKEdQcwjY5uzBBFjdNPK85g8xae/jMqH5P8AD/HKNRG8ZCXr2aFVkv8AdP8A6p/ViyjzDDYopJHWONSztsqjqcrd1KYiLKZwaRq9vIlzbuI54zyRkejqR4HJQMokGJ4ZBxp6jFMGMhxRL1HyJ57Grf7jNT/datGNmI4iYL1IHZx+0udh2X2p4w4J7ZP928d2t2T4H7zH6sUv9gzYZunSOxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV//0/VOKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KsO8/6k6LBp6EhZP3k3uAaKPv3zne3tQQBjH8Xqk7rsfACTM/w/SwvOZd+7FUtWL0ddLdFuIiR8xSv6sj1cknixf1SmWScZiX5pXElv5SkkjpyM8I337nNx2Dgjl1IjLlwydZ2vq54MBnD6rEf9MxuzitxBFJEirzRWqBvuAeud/i0+PH9MQHhdRrcub6pSkP9L/sYq9N8vcTlyWWhr6p9/65xWU3M+99JxQ4YAD+GKIyDN2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KoKQ/6X9Iy7TGskT/SDj62HFhmP6BRJzs3zutlOWCGUUkQN8xlWTDDJ9QBcnBqsuE3CUo/FKpjDYa3pAjQkT3KAgnpSRRt9+abXdkw8ORiaqJeg0Xb+UyEZgT4iPU9jPU556Hr1C8kEdpM5/ZRj+GFnjFyA80s8vWYEbXLjdvhj+Q6nIxcvWZN+EJzknCCB1GGdSl9asY721IkjkXqeO/bDGUoyEo/VFuxTj9Et4ZPS9k0LU11PR7PUF2+sxLIwHZiPiH0NnoOnzeJjjP8AnDieG1ODwskoH+CXCj8uaHYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FX//U9U4q7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq8/wDPyMNZiY/ZaEcfoY1zku3YkZgf50Xo+xyDjI/pMazSO2diqFvkp6NwPtQOCf8AUb4WxLZjPMfzkVgDVTEfzUiL+TLgj/dc0Dn5c6f8bZvvZw1qx/Vl/uXT9vRvTHyMfvYroU3raPavWpCBW+a/D/DPQaeCR+EDdBUrLo/0HOGfTETih2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KoCU1uSf8oDJ4/qHva8393L+qUWc7YinzccnYEpHeEz+cdCtV3KzRMR7tKD+pcxdfLhwTP8AQk5ugjeeA/pPZT1OeVDk+lIPVQ8lsLdPtzsEHy6sfoAxLdg2lxH+FEwwpDEsSfZQUGFrlKzZX4sXHG1It6Z5Otfqvluxh6AIWUeAdiw/A53PZkSNPC/5ryXaM+LPM/0k5zPcN2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV/9X1TirsVdirsVdirsVdirsVdirsVdirsVdiq15I0Us7BVUVZjsAPngMgOagWxzVfO+n21Usx9blG1RtGD/rd/8AY5p9V21ihtD95L/Yf6Z2en7LyT3l6B/snn2q+ZdU1HW/Tv2T0iv+iKigBa9RXqenfOZ1etyZ5XOtvpel02gx4sVw5/xtjMZLsVaZA6lT0YUPyOKQaWw19MBjVl+Fj7jFZc0t806a2p+XNRsUFZJoG9L/AF1+Nf8AhlzM7P1HhaiEzyjL1f1XC1+DxcMojmQ8o8l3fO2ntT9qNhIg78XG/wDwwz1R82ZH3xjzYy5KFpUSuvt+o5w0hRIfSoSuIPeEXgS7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq1iqXr8U1fFq/jl+ljeWI/pBo1k+HDM/0JI3Oxt86DsKUp8mW7av+YYux8VvYc5g3akY9NPvZuWaT2g1Hh6WQ65Kh/v/APeu77CwcepB/mXL/e/756/nnQe8aKIXDkVZRRT4VwptvFDsVUrmdYLeSVvsoK08T2GNs4Q4pAd6deTvP+qi19PU4lmtoqRwyxgI9AOlPsNT/Y5utH25KAEZjiiP5rre0+xcfFeMkSP1Rk9B03WtN1BK20wZwKtEdnHzU50un1mPMLgb/wB083m008R9QR4IzJaXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq/wD/1vVOKuxV2KuxV2KuxV2KuxV2KuxV2KuLAAkmgHU4kqxvV/OljacorUfWrgbGhpGp927/AOxzT6vtjHi2j+8l/sP86Ts9N2Xkyby9Ef8AZMM1LW9S1FybqYlOqxL8KD6B/HOa1Wty5z6zt/N/hd7p9JjxfSN/5yBpmI5KC1S0aeESRf38HxR07+IwFvwZOE0fpkqWF4t1biUbP0kXwYYgscuMwlSJwtTsVWj7RPj+sdMUhuuAhLxbXbB/LHnSSopY3bNLCR0MUrbj5xPnpnY+tGo04l/HH0ZP6/8Ax7+F857V0ZwZiP4ZeqH9X/jrIds2dusKHU8Lr2P8c5PX4+DNIf53+me97My+Jp4H+b6UZmI5zsCuxV2KuxV2KuxV2KuxV2KuxV2KuxVTnfhEx8dh8zikIO2Wso9qn+GbHsuHFmB/m+p1XbWXh00h/P8AR/xSMzpw8Ql2v6gLLTZXU0lkHpxf6zd/9iN8Ksi/KbQXsNEk1GdeM2pFWjU9RAlQh/2ZJb/gc4L2l1gyZhjH04f93/F/pXt/Z7SHHi4zzy/7lnGc69A7FXYq7FUj1e4e6uY9Pg33HP8A1vD/AGOQl3Odp48MTMpxDAkMKQp9lBQe58ckA4cpmRsqqO6OroxR13VlJBHyIyUSQbHNiYgiiGSaT53v7YrHer9ah6c+kg/g2brSdtzhtk9cf9n/AMedRqeyYy3h6T/sGZ6brFjqMfO1lD0+0nRl+YOdLp9VjzC4G3RZtPPGakKRuZDU7FXYq7FXYq7FXYq7FXYq7FXYq7FX/9f1TirsVdirsVdirsVdirsVdirjiqWax5g0/S4/371lIqkK7sfo7D3OYer12PALkd/5v8TkabSzzH08v538LBNY8zajqRaNm9K2rtDHUAj/ACj1bOU1faeXNtfBH+ZH/fPRaXs/Hi3+qX85Ka5rnPaxV2KuxVKbtW067F5GCbeU0nQdie+R5ObjPix4D9Q+lNI5I5Y1kjPJG3UjDbhmJBorsKHYq7FLG/Pnlga/ojRxKPr9tWWzbxNPijPtIP8AhuObbsftD8tmBP8Adz9M/wDez/zXV9q6H8xiofXH1Qef+V9TNzaG0mJFza/CQ3UqDTf3U/C2ejg3uHz2Qrmmd0vRx22OaXtjDyyD+pL/AHj0fs9qK4sR/wCGR/36Ihk5xg9+hzRvTqmBDsVdirsVdirsVdirsVdirsVdirsVQl69SEHbc4qG7VPhLEdemdF2ThIgZn+M/wCxeU7f1HFkGMcsY9X/AAyX/HeFWzbOgpJrDS281+aksxX9F6d8V246HfcfOQjgv+TyzW9rdoDS4TL/ACktsf8AxX+a7HsvQnUZeH+CO8/+JewoiooVFCooAVRsAB0AzzMkncvooAAoN4q7FXYql+r6ktpFwjNZ3Hw/5I/mP8MBNORp8Bmb/hCloNgY4zdSj97L9ivUKe/+ywRbNVms8I5BNck4bsUuxQvgnmglWWCRo5F+y6mhyePJKBuJosJwEhUhxBl+i+eRtDqgp2Fyg2/2aj9a50Wj7c5Ry/6f/inR6rsmvVj/ANJ/xLMIZopo1kiYPG4qrqagj2IzoYyEhY5OmkCDR5r8kh2KuxV2KuxV2KuxV2KuxV2Kv//Q9U4q7FXYq7FXYq7FXYq7FXVFaYqxTzF5xS2L2unkSXA2ebqqHwH8zZou0e1xj9GP1T/nfzXa6Ls05PVPaP8AumDyyyzSNLM5klc1Z2NSTnLTnKZJkeIl6OEBEUBQW5FLsVdirsVdiqyWJJY2jcVVhQjFlGRBsJJBcTaTdtbznlbMao3gD3H/ABtkORc2cRljxD6k9VgyhlNVIqCPfJuBTeKuxV2KvLfzF8vzaPqieZtNSkEr0vox0EjbVP8Aky9/8v8A1s7f2c7S8SPgzPrj9H9KH/FReN7e7O4JeLAemf1/1/5y62uIb21SeI1ilWo8R4g+4zpcuETiYnlJ5/BmlimJx5xKyJzDJQ/ZPXOPzYTjkYno+g4M8csBOPKSNBBAI3B6HKW1vFXYq7FXYq7FXYq7FXYq7FXYqpzTCNf8o9BiqCRXkk+e5OZGm0xyzER/nONq9XHT4zM/5kf50vx6kYBQADoM6+ERECI5B4Gc5TJlL6pepLdcvpoYUtLQF9QvWENsi/aq21RjOYjEyO0Y/UsImUhEC5Seg+UPLUHl/R0tBRrqQ+peSj9qQ9q/yp9lc8z7T7Qlqspl/B/k4/0f+PfU+idm6EabEI/xfx/1k7zXOe7FXYqhdQ1CO0ir1kYfAniff2wEtuLEZnySTTbWTULxp5/ijQ1c+J7KMgBbn58gxx4RzZL7DpljqnYpdirsVdirsKplo2v3+lS1hPO3JrJbsfhPuP5WzM0faGTAdjcP5n4+lw9VooZh/Nl/Oei6TrFlqdsJrd6kbSRn7SnwIzstLq4Z48UT/wAdeYz6eeKXDJHZktLsVdirsVdirsVdirsVdir/AP/R9U4q7FXYq7FXYq7FXYq49MVYh5v8yvEW06zekhH+kSqd1B/YHue+c92v2mY3igfV/HL+b/x53HZug4/XP6f4f6TCc5l6F2BXYq7FXYq7FXYq7FULf2KXkHpnZxvG/gf6YCLbsWUwNpRp+oy2EptboERA0Neqn2/ycgDTmZsIyDiiyBWVlDKaqdwR0OWOuIbxQ7FVG8s7a9tZrS6jEtvOhjljPdWyeLLLHITialFhkxxnExlvGTx02tz5V8wy6RdMWsZ252k7bAq2yt/xpJ/lZ6b2fro6rEJjn/H/AEZvnPaGjOnymB5c4S/nRTyaJXHg2S1mkGaP9IfT/wAS2dndoHTT78cvqj/v1COV4TxO4ruP6Zy+THKB4ZCi9tizRyREoHijJFRyo/2T9HfINipgKC7FXYq7FXYq7FXYq0TQVxVQmu0UUT4j49sVQqiSZ69Se+W4cM8kuGA3adRqIYI8czQ/H0/zkXFGI1p1Pc51Wk0owxoc/wCKTxGv10tTk4jyH0RauLiG3gknmbjHGOTHMpwkf+Xegy3dy/mnUUo8wK6XC3+64unqfNui/wCyb9rON9o+1LPgQO3+V/6pvXdgdnUPGn1/u/8Ai2fZyT1LsUOxVC6hqENnHVvikP2I/H5+AwEt2HCZljyJdalebmrNuzdlXIc3ZExxRZPbW8VvCsUYoqj6SfE5Y6mczI2VTFi7FXYq7FXYq7FXYqidO1G6067W6tmo6/aU/Zdf5WGX6bUTwzEon/j39Zp1GCOWPDL/AKRenaNq0GqWSXUO1dpE7q46qc7jSamOaAlH/pGTyWowSxTMSjsyWl2KuxV2KuxV2KuxV2Kv/9L1TirsVdirsVdirsVdiqB1rUk07TZro7uopGp7udlGYus1Aw4jLub9NhOWYi8qkd5JGkkPKRyWdj3J3OcFKRkST9RexjERFDkFuBLsVdirsVdirsVdirsVdilA6ppiXicl+G4X7Ddj7HIkW34cxgfJKLHULiwlME6n0waMh6qfFciDTl5cQyCxzZFDNFNGJImDI3QjLHXSiQaK/Fi7FWPed/KsfmHR2iQAX9vWSykP81N0J/lk6f63xZteyO0Tpct/5OXpn/xTre1NANRir+OPqh/xLz3y3qjzxPY3NVvLUlGVvtEKaGv+Up+Fs9IBBFjkXzyQIJB5hOHjR+uVajTQyipD/inI0usyYJXA/wBaP8KHeB13XceI65z+o7LyQsx9cf8AZPV6btzDkoT/AHc/9g5bmVNjv881xiRzdsJCXL1Kq3q/tKR8sFJXi7hPcj5jGlp31qD+bFXfWof5sVWm9j7AnFVNrxj9lQPnvitKLPLIaElj4DDGBkaAssZzEN5HhHmqJbMd3+EeHfNrp+ypy+v0D/ZOl1fbuKG2P95L/YIhEVR8Ipm9w4IYxURTy+o1OTMeKZv/AHv9VdlzQlum6e/mvXhYoT+htPIkv5V29RgaCMH/ACvs/wDBvmq7X7RGlxWP7yfpx/8AF/5rtOy+zzqMoB/u4+qf/EvWY0SNFRFCIgCoiigAAoABnmxN7l9CAAFBdgV2KoDUtWitFKLR7jsnYe7YCacjBpzM3/Cx7/Sb257yTOf8/kMjzdl6ccfJk+n2MdpAEXdzu7+J/pkgHVZspmbROFqdirsVdirsVdirsVdirsKp55Q1b6hqYic0t7qiPXoG/Zb+GbXsjVHFl4SfTk9P+f8Awut7T03iY7H1Qekg7Z2Ty4dil2KuxV2KuxV2KuxV/9P1TirsVdirsVdirsVdirBfPuomS7isUPwQj1JKfzt0H0LnLdu6i5DGP4fVL/O+j/fO/wCx8FA5D19IYpmgd07FXYq7FXYq7FXYq7FXYq7FXYpQmoabDeL8XwSgfDIP1H2wEW3YsxhySJJL7S7ggig7qd1YZDk58hHLFPrHUILxaoaOPtRnqP65MF12TFKB3RWFqdirzH8zfL8unX8XmfTk48nC3yr09Q7K5/yZB8D/AOV/rZ2ns52lxROCZ3j6sf8AV/mvIe0Gg4T40RtL0z/4pZY3sN7aR3MX2ZBuvdWHVT8jnVPMIjG1aKq3UA5CeKM/qHE2Y8+TH9MjFTNtEexHyOYU+y8J6GLssfbmpjzIl/WH/ELPqi9mOYx7Gj0kXNj7RT/ihH/Nd9UH834ZD+Rj/O+xtHtHH+Z9rf1Qfz/h/bj/ACN/SYn2jHSH+ycLVe7fcMmOx4dZH5NUvaLIeUIf7L9a4W8Q7V+eZMOzMEd64nDydtamXUR/qj/ilRQqiigDM2GOMBURTrcuWeQ3ImXxbybB2KpPr+ozr6WmWIL6hekRoq9QrGn3t0yM5xhEyl9MWcIGRERzk9J8qeXYNA0WGwSjTfbuph+3K32j/qr9lP8AJzzLtLWnU5jM/T/B/UfRuz9GNPiER9X8f9ZOMwHNcSAKnYDqcVSbUddC1itDVu83Yf6uRMnOwaQneSSxRTXEwRAXkc/P6SciHOlIRHcGT6dp0VnFQfFK3238fYe2TAdTmzGZ8kZhaXYq7FXYq7FXYq7FXYq7FXYq7fsaHscIS9T8v6j+kNKt7gn95x4S/wCuux/rnd6HUeNhjLr/ABf1v4njdXh8LIYplmY47sVdirsVdirsVdir/9T1TirsVdirsVdirsVWTSLHG0jmiICzHwAFTglIAWVAs08m1C7a7vZ7puszlvo7fhnnuoynJklM/wARe1wYvDgI9wQ2VNjsVdirsVdirsVdirsVdirsVdirsU2pXNtBcxmOZar2PcfI4CGcJmJsMevdNurGQTRsTGD8Mq7Ef61MgRTscWaOTY80y0zWUnpDPRZuit2b+3JCTi59MY7jkmmScVRvLO2vbSa0uUElvOhjlQ91bJ4ssscxOJqUTxRasuKOSBhLeMvS8Vs0uPLnmK60W8b9yz0jkPQ1/u5P9mv2v8rPUtHqY58Uckev+xl/NfNtXppYcphLp/sv6TJ8yXGdigh2Nq7G1djauxV2CkuxQ7CrsVUL27is7WS5lPwRCpHcnsB88Uqn5XaLLfX9z5mvl5NyMVkD0Dftsvsi/u1/2ecn7S9oUBgiefqyf1f4Y/756n2d0Nk5pD+jD/fPTTnGvWqcsscMbSStxRepONpjEk0GOalrEl0THFVLfoR3b5/0ysyt2mDTCG5+pCWtrNcyiOIVP7R7AeJxb8mQQFlk9hp8NnHxX4pG+3Iep/syYDqc2YzKKwtLsVdirsVdirsVdirsVdirsVdirsUsu/L+/wCNxcWLHaQCWIe42YfdnQ9g56MsZ/rxdF2zh+mY/qs3zp3ROxV2KuxV2KuxV2Kv/9X1TirsVdirsVdirsVSPzlfC10SRQaSXBEK+NG+1/wozWdr5+DAe+fo/wBM53Z2LjzD+j6nm+cSHrC1hQ7FXYq7FXYq7FXYq7FXYq7FXYq7FXYpaYBgQdwdiD0xVJdS0I7zWYrTdoP+af6ZCUXOw6rpJ2ma1xpBdt02WQ9vZsRJc+lv1RTxFZyAgLk9Au9fuyyMTI0BZdeZACyaDz383vL5m0+LWI0Insj6VyKUJic/Cf8AYP8A8Tzp/ZrWGGU4Jf5T6f8Ahn44nnPaHSieMZo/wfV/USTy/qX17TkZjWeGkc3iSBs3+yGds8ameKl2KHYq7FXYq7FXYq7FXYqxjX5bnVNXttCsvid5FRqdPUfx9o13yvPljjgZy+mA4m7BiOSYgOcjwvZtL0+307T7bT7YUhtkWJPE06k+7H4s8q1GaWXIZy+qZ/EX0zBijhgID6YBVvbiOyTlc1jP7KkEMfkDkJxMfqBj/WbsQ8X6PUxe/v5ryTk5ogPwRjoMpJt3GLCIDzXWGmT3b7fDED8Un9PHABaM2eMB5smtLSC1j9OJaDue5PiTlgDqsmQzNlVwsHYq7FXYq7FXYq7FXYq7FXYq7FXYq7FKN0a9Nlqltcg0COOf+q2zfgcytFm8LNGXn/uvS42rxeJjlHyerqwIqDsehzvQXjm8KuxV2KuxV2KuxV//1vVOKuxV2KuxV2KuxVgnn69530FoDtCnNx/lP0/AZy3b2a5xh/N9T0HY2KoGf870sVzQO6dih2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxVL9S0iG7UulEuP5uzfPIkOTg1Jht/Cv8AJl7c2utLYXPR0dUDdVIHLb2NM23YWStSAf4g4Xb+GM9MZx/hItPfNumQXcLRTLWC7jaGYeIIpX7s2vbUDjlDPH6oy9X+6/3rouy58cZYpcjH0/7n/fPnTTfX0LzHPp10eIWQ20xPSoPwP9O3/B52GDOMuOOQfxjieQ1GE4shgf4SzLLWkuxQ7FXYq7FXYq7FXYqhtRvUsrKW6b/dY+EeLHZR9+KqX5SaO93qd3rdwOX1escTnvNLu7D/AFU/4nnL+0+rrHHEP4/VP+p/D/suN6f2c0nFM5Tyh6Y/1nsuhQrLfknf0V5Ee52GabsLTieQzP8Ak/8AdSd12xnMcYiP4/8AcpR+YlwjX9pAKc442Zj3+NqAf8Lj7R5QckY9eHic32YxEY5y6Sl/uUp03Q2kpLdArH1WPoT8/AZz4Dus2qraKfIiooVFCqNgo2AyQdcTbeFXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7EhIeo+Wr765otrMTVwvCT/WT4T+rO77OzeJgjLyeO1mLgyyHmmmZrjOxV2KuxV2KuxV/9f1TirsVdirsVdirjiryfWrw3mq3VxWoaQhD/kr8K/gM4HXZfEzSl5/7l7DR4+DFEeX+6QWYrkuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2Kt28MTajaTsKSQyqVcdaE0I+W+ZOinw54H+kGrU2cM49JQKcebJmt9N9cDl6TCo9uhzru2Y3ppf0al/snm+yBeohH+dcf9i8L/ADW02Nrq1121NYrtfRnp1WWMVUn3Kbf7DB7L6sShLD1h6o/1JNftLojDIMlfV6Zf1lTRb767psM5/vKcZP8AWXY51DyxR2KHYq7FXYq7FXYq7FWJ+c74tJDZIa8B6kij+Y7KPux96avlzelaHGnl3y3Z6agH18p6tz/kyy/E1f8AVrxH+rnl/a2sObUTl0vhj/Vi+pdi9ncGGIPKvV/WZl5ADNa3M7nlJI/xMeppm/8AZ+FYCf50v9y6j2il/hAiOUYf7pS1eyhk124u5PjccUjB6KFUZpO2JcWpl/RqP+x4nY9mTMdNGI63963Na5TsVdirsVdirsVdirsVdirsVdirsVdirsVdirsVdirNPy/vKxXVmT9giVB7Ns36hnTdgZrjKHd6nQdtYqMZ9/pZjnROldirsVdirsVdir//0PVOKuxV2KuxV2KoDXLz6npV1cVoUjPH/WbYficxdZl8PFKXcG/TYjPJGPm8p6ADOAD2TsKuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KuxV2KtoaOp8CD9xyUDUgWMhYITrzVEZtLeFTRpCQpPjQ53XaQHgT/qvK9ly4dTA+f+9k8j13T5LzSb3TmFJGHKNT2mj+JD/wAa/wCyzkOyNX4GphLpfDP+pP6ns+2dGNVpZAfVXHj/AK0WGeS72kk9m37QEsY+WzDPUi+RMrwIdirsVdirsVdirTMqKzsaKoLMfYb4qwrRlbVfNEcziq+qbhwdxwjNVH4KuaztjVeBppy6n0R/z/8AjvE7fsLR/mNXCH8I9cv6sP8Aj/C9KVZZ5gADJLIfmSTnl4fXTUR3B6N5MtWtbKSFiC4ILEeJrncdg/4sP60nz/tzJx6mR/oxQ1+a305/4sb8DTOW1xvPM/0nd6QViiPJD5iuQ7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYq7FXYqnPlG7NtrsFfsT1ib/ZdPxGbLsjLwZx/S9LgdqY+LCf6PqemZ2zyrsVdirsVdirsVf/R9U4q7FXYq7FXYqxbz/d+np0NsOs8lT/qoK/rIzSdu5axCP8AOP8AsYu27Hx3lMv5oYHnJPRuxV2KuxV2KtMwVSx6KCT8hirakMgYdGAI+nFXYq7FXYq7FXYq7FXYq7FXYq7FXYq2Oo+eIUp7r5/0eIf5RP3Cmdz2ua00/cPvi8l2cLzx/HQsK13Ti6/XIh+8T+8Hio7/AEZwcovdaTNXpLxqRBpXnBlHwxeuQo/4rm3H/Es9V7Nz+Np4T6yj6v6z5X2ppvA1M8fSMjw/1P4WZ5mOA7FDsVdirsVdiqUeaLv6vpEqg0eekS/7Lr/wuKUN+X1ntd3rDusMZ/4Zv+Nc472s1FcGL3zl/vf90937G6YDjynyxx/6ef7KL1bRdNFvEJ5B+/cbf5KntnHgUHptVn4jQ+kMr8vGjTL4gH7jna9gyvT1/Tk8b2wP33+al19/vZP/AMZG/XnLaz++n/Weg0393H3KGYze7FXYq7FXYq7FXYq7FXYq7FXYqtaRRIkZ+04JH+x6/rxVdirsVdirsVdiq+KVopUlU0aNg4PuprkoSMZAjoxnESBB6vXredZ4I5l+zIodfkwrnoeOYlESH8TxMgQSD0VMmh2KuxV2KuxV/9L1TirsVdirsVccVee+e7r1tYSEH4beMA/6zfEfw45yPbuXizCP82P+6ek7Hx1jMv5x/wByxzNK7Z2KHYq7FXYqg9Yl9LSruStCInAPuRQfrx6s4C5BEWpraQH/AIrT/iIxKJcyqYsXYq7FXYq7FXYq7FXYq7FXYq7FW0FXUeJA+/JQFkDzRI0E58wn+5TwBP4jOy7bnWnI/nVF5fsmN5gf85JWCkFW3BFCPY5xT1TxX80NMax1+KVdlmiDIf8AjGxA+4Fc7z2XzcWnMP5kv928d7UQH5iM+uSH/TP/AKSTy2m9a2im/wB+Ir/eK50jzKrgQ7FXYq7FXYqxHzrdcrq2tR0jQyMPdjQfgMUs4/LXSB+iLeR1+CrTMD3Zm+H/AIUVzzft/Lx6yQ6Y6h/pX0zsOPg6CAH1Zf3n+nZ/moLlppoL0umX+ZT+FDnW+z0rxyHdJ5vtqPrie+JQV+CL2cH/AH436853XCs8x/Sd5pTeKP8AVUMxW92KuxV2KuxV2KuxV2KuxV2KuxVLr+b09V0wdpDKh+lRTCGyIsFMcDW7FXYq7FXYq7FXpPk27+saFACatDWI/wCxO3/C52vZGXj08f6Po/0rynaWPhzn+l6k8zZuC7FXYq7FXYq//9P1TirsVdirsVcemKC8l1a5+tandXHUSSsV+QNB+Azz/V5ePLKXfJ7TTY+DHGPkhMx292KHYq7FXYqk/myb09GkHeRlQD6eR/VhHNuwi5JpbClrCPCNP+IjA1HmqYodirsVdirsVdirsVdirsVdirsVVLcVniHi6/ry7TC8sB/Ti1ZjUCf6JTDX3Juwv8qgffvnS+0E6xxj3y/3LoexYeuUv6KVnOTejec/nLahrDTLum6TSRE+zpyH/EM6z2Uy1OcP50eP/Sen/fvN+0uP0Ql/S4f9MOL/AHqU+XJTJolqT1RSh/2LEZ2heNTPAh2KuxV2KuxV555huPW1e7kBqFYovyQcf4YRzS968uacun6JZ2oFGSJOf+txFc8n1WTjyzn/ADpF9Twx4ccYjlCMYR/zUyyhmjdIbjfR+9R94OdF7PTqU4/5zpO2htErNUWmoXH+tX7wM1naka1Mx5/70OfoD+5j7v8AfFC5gOY7FXYq7FXYq7FXYq7FXYq7FXYqkXmWT0rnTJv5Jq1+7DFuw8pJ6euBpdirsVdirsVdirMvy9uqNeWpP8sq/wDET/xrnSez+X6of5zou2ce8Zf5rM86R0bsVdirsVdir//U9U4q7FXYq7FUFrV19U0m6uOhSNuP+sRQficx9Xl8PFKXdEtuDHx5Ix7y8n+eef29q7FDsVdirsVdirHPOkn+j2sI/bdj9wp/HJRDkYBuWRIOMaL4KB9wyLQebeKHYq7FXYq7FXYq7FXYq7FXYq7FUTpy87+3X/LB+7fMzs+HFngP6QcXWyrDI/0SqavJzv5PAGn3bZtfaHJc4gdxdf2NH0SPmgs553TDfzZg9Xyiz94LiF/vJT/jbN/7NTrVV/Pif0Ok9ocfFpr/AJshL/esN8oPy0ll/klYfQQDnoDwid4EOxV2KuxVa7iONpD0RSx+gVxV5xZxm71KCM7m4nRT783Ff15XlnwwlLuiW7BDinEd5D6TIA2HQbD6M8kfUAGsKVeyfhdRt2DD9ebjsOdZ6/nR4f8AfOs7WheG/wCaVfW146i/+UFb8KfwyHbMa1B/per/AHrLsqV4B5IHNU7F2KuxV2KuxV2KuxV2KuxV2KuxVj/nMf6FbOOqyn8VP9MMebfp+ZT2CQSQRSDo6K33iuBpI3X4odirsVdirsVTryjdfV9egBNFm5RH/ZDb8Rmz7Hy8GoA/n+l1/aeLiwn+j6npYztXlnYq7FXYq7FX/9X1TirsVdirsVY358ufT0dYAaG4lVfoX4j+rNL27krBw39cnZ9kwJzX/NDz7ORemdirsVdirsVdirFfN7FtQsovBa/8E4H8MnFycH0llZ65Bx2sUOxV2KuxV2KuxV2KuxV2KuxV2KphoactQVj0RS38P45tuxIcWoH9GMnW9rTrDXeUJdPzuJD4sT95x7blepI7gF7KjWAe9SzUuyY3+YsXqeS9THdURx/sZVObbsI1rMZ8z/uS6ztkXpZ/D/dB5x5Latlcr4Sj8UGekPnpZFixdirsVdiqC1uX0tIvHHX0mA/2Xw/xxVh/lOH1fM+kx+N3DX5B6/wzC7SlWmyH+hJzezxeoxj+nF9DnPLn0prFW1JDCnjmd2bPh1ED5/71xNfHiwSHl+lMtdFXtpv9+R/q3/jmy9ocdZIy/o8P+lcLsafolHz4kszn3cOxV2KuxV2KuxV2KuxV2KuxV2KpH5wWulIfCVfxBwx5t2m+tH6I5fSLRj/vpR/wO38MSwyfUUbgYOxV2KuxV2KqttO1vcRTr1idXH+xIOWYsnBMS/mkMMsOKJj3h69G6vGrr9lgCPkd89CibALxRFGl2SQ7FXYq7FX/1vVOKuxV2KuxVgv5gXXK+trYHaKMuR7uafqXOV7fyXOMP5o4noOxcfplL/NYpmhdy7FXYq7FXYq7FWI+Zm5a/br2VYh97k5OLl4foLLz1OQcRrFXYq7FXYq7FXYq7FXYq7FXYq7FU10EBfrMv8iU/Wf4Z0fs9juUz7ouk7an6Yj3pW5+I5qe0cnHqJn+k7HQw4cMR5NZhOUkfnheXlDVx/y7Ofu3zY9kmtVj/rf72TgdqC9PP+q8v8lf7y3X/GRf+I56aXzmXRkeLF2KuxV2KpP5rk4aLKP9+Mi/8MD/AAxVJPIa8vOWkjwm5f8AAoxzW9sGtJk/quz7Ijeph73vh655m+iOxVsfaGWYZcM4nulFryxuJHeE11NeelWcv8tFP0in8M6bt+N4oy/pf7t0PYsqySj5f7lKc5V6J2KuxV2KuxV2KuxV2KuxV2KuxVJvNv8Axx/+eqfxwx5t2n+tW8tOW0S3/wAnmPuc4lGYepM8DU7FXYq7FXYq3QHbGkh6h5ZujcaFZyE1YJwb5oeP8M7rs7Lx4Ik9zx+tx8GaQ800zOcV2KuxV2Kv/9f1TirsVdirsVeX+aLr6zr129dkb0l+SCn684XtTLx6iXl6Xrez8fBhj5+pKswXMdirsVdirsVdirDfMbU8xJ4L6P68nFy8P0MzPU5EuI1gV2KuxV2KuxV2KuxV2KuxV2KuxVONIFNOvG+Y+5D/AFzqvZ0eiZ/p/wC9i8720fXEf0UoPU5zGQ3Il38BUQPJrIM0o84AHyrq4P8AyyS/8RzN7OP+EQ/rOH2h/cT/AKryryV/vLdf8ZF/4jnqRfNTyZHgQ7FXYq7FUi84mmkqPGZf1HFUt/L4A+dNL/13/wCTT5qu3P8AFMn9V23Yv+NRe8Hrnm/R9BDsCuxJSAnFx8WgRk9mFPvOdd2t6tGD/wALea7NFak/56T5yL0jsVdirsVdirsVdirsVdirsVdiqS+bjTSQPGVP44Y827T/AFL/ACof9w0fs7/rwyTn+pN8i0OxV2KuxV2KuxVnX5f3XPT7i2PWGXkPk4/qDnV9g5LxmJ/hl/sXnO2YVkEv50WV5vXUB2KXYq7FX//Q9U4q7FXYqsnkEcTyN9lFLH6BXIzlQJTEWaeQTStLK8rGrSMXY+7Gpzzqc+KRl/OPE9vGPDED+aFmBLsVdirsVdirsVYX5m/475+UWTDl4foZoeuRLiOwK7FXYq7FXYq7FXYq7FXYq7FXYqnmnW90ukMPRf8A0ot6TkUUrQAktnX9hQMcJJH1S4vseZ7XmJZRR+kfpSq7tJLSX05CCSKgqaihzmtVpJ4JcMqv6vS77TamOaPFFQzFchKPOBA8q6uT/wAskv8AxHM3s0f4Rj/ruH2h/cT/AKry3yYlNOmf+aWlf9VRnqcub5qeTIMih2KuxV2KpD5y/wCOXH/xmX/iLYql35fH/nc9L/4yMP8Akm2avtv/ABTJ/Vdt2N/jUXvB655qX0F2KqttA88yxJQM/Qnpl2n08s0xCP1S/nMM2UY4mR5BOntLv9FS2ohMjwjnyQFlKBq1r7Z12vwn8pwDeURH/YPNaTLH8zxHaJtIM4t6h2KuxV2KuxV2KuxV2KuxV2KuxVI/N/8Axy0/4yr+o4Y827T/AFKnlP8A44yf8ZH/AF4ZJz/UnGRaXYodirsVdirsVZN5CufT1aWAnaeI7e6Gv6ic3fYOSspj/Pj/ALj/AKSdT2zjvGJfzT/umf51rzjsVdirsVf/0fVOKuxV2KpZ5kacaLdCBGkldOCqgJPxEA7D2OYevMvBlwgylXRydGI+LHiNRt5v+idU/wCWOf8A5Ft/TOLGjzfzMn+kL1X5rF/Oj83fonVf+WOf/kW39MP5TN/Myf6RH5rF/Oj83fonVf8Aljn/AORbf0x/KZv5mT/SL+axfzo/N36J1X/ljn/5Ft/TH8pm/mZP9Iv5rF/Oj83fonVf+WOf/kW39Mfymb+Zk/0i/msX86Pzd+idV/5Y5/8AkW39Mfymb+Zk/wBIv5rF/Oj83fonVf8Aljn/AORbf0x/KZv5mT/SL+axfzo/NiPmXy55gk1f1ItMunQpH8SwyEVHuBkho81fRP8A0rlYdbgEaM4f6Zlq6VqtB/oU/T/fbf0yP5TN/Mn/AKVxvzWH+fD/AEzf6K1T/ljn/wCRbf0x/J5v5k/9Kv5rD/Pj83forVP+WOf/AJFt/TH8nm/mT/0q/msP8+Pzd+itU/5Y5/8AkW39Mfyeb+ZP/Sr+aw/z4/N36K1T/ljn/wCRbf0x/J5v5k/9Kv5rD/Pj83forVP+WOf/AJFt/TH8nm/mT/0q/msP8+Pzd+itU/5Y5/8AkW39Mfyeb+ZP/Sr+aw/z4/N36K1T/ljn/wCRbf0x/J5v5k/9Kv5rD/Pj83forVP+WOf/AJFt/TH8nm/mT/0q/msP8+Pzd+itU/5Y5/8AkW39Mfyeb+ZP/Sr+aw/z4/N36K1T/ljn/wCRbf0x/J5v5k/9Kv5rD/Pj83forVP+WOf/AJFt/TB+TzfzJ/6VfzWL+fH5sw0LULq00ZIbuzmlWOq8PTPOldl4kb51fZ8zDTDjEuKP8HD6+f8ANeb1kBLOeEx4ZfxcXpSPXxc6jcRvbaRNbqikE+meT18aDtml7SOTPIGOLJGv6LtdAMeGJEskDfmlf6J1T/lin/5Ft/TNd+UzfzJ/6VzvzWH+fH5pN5z0XXJfKmqxQafcyzSW7KkaROzMTQUCgEnM/svTZBqYGUJxjxfxR8nD7R1GOWCYjKJNd7A/LXlDzTBpEayaNexuzuzI1vKrCpoNitegz0Y5Y3zeAOGfcU0/wx5l/wCrTef9I8v/ADTg8WHevgz7i7/DHmX/AKtN5/0jy/8ANOPiw718GfcXf4Y8y/8AVpvP+keX/mnHxYd6+DPuLv8ADHmX/q03n/SPL/zTj4sO9fBn3FJ/NXlHzXPpXGHRb6R1kVuKW0zGm9dguPiw70jBPuKU+S/KHnC282aXPPoWoxQpN+8ke0nVVBUipYoAOua/tUiemmI+qRj9LsOzImGoiZbRe4forU/+WOf/AJFt/TPO/wAnm/mZP9K91+axfzo/N36K1T/ljn/5Ft/TH8nm/mT/ANKv5rF/Oj80do0N3YXyz3GlzXMYBHAxtUHswqKVzM0EMmHJxyxzl/muJrZwyw4ROMf85k17q1xPpU62dlNbs6FeLRkOCRTZQM6TLn8TTyMROMuGXp4fXxOix4uHNESMZRv+d6WFjSNTA/3jnp/xjb+mcgdHm/mT/wBK9R+axfzo/wCmd+idT/5Y5/8AkW39Mfymb+ZP/Sr+axfzo/6YO/ROp/8ALHP/AMi2/pj+UzfzJ/6VfzWL+dH/AEwd+idT/wCWOf8A5Ft/TH8pm/mT/wBKv5rF/Oj/AKYO/ROp/wDLHP8A8i2/pj+UzfzJ/wClX81i/nR/0wd+idT/AOWOf/kW39Mfymb+ZP8A0q/msX86P+mDv0Tqf/LHP/yLb+mP5TN/Mn/pV/NYv50f9MHfonU/+WOf/kW39Mfymb+ZP/Sr+axfzo/6YO/ROp/8sc//ACLb+mP5TN/Mn/pV/NYv50f9MHfonU/+WOf/AJFt/TH8pm/mT/0q/msX86P+mDv0Tqf/ACxz/wDItv6Y/lM38yf+lX81i/nR/wBMEl82aHrc1hEkOn3MjeqCVWJyaBT4DEaPNf0T/wBK3YNXhEt5w/0yr5a0PWodJjSTT7lH5uSrRODufAjCdJm/mT/0qM2swmW04f6ZNP0Vqv8AyxXH/Itv6ZH8nm/mT/0rV+bxfz4f6Z36K1X/AJYrj/kW39Mfyeb+ZP8A0q/m8X8+H+md+itV/wCWK4/5Ft/TH8nm/mT/ANKv5vF/Ph/pnforVf8AliuP+Rbf0x/J5v5k/wDSr+bxfz4f6Z36K1X/AJYrj/kW39Mfyeb+ZP8A0q/m8X8+H+md+itV/wCWK4/5Ft/TH8nm/mT/ANKv5vF/Ph/pkw0C11O01m0ma0nSMSBZGMbABWqDXb3zM7PwZseeMjGQHX0/wuLrc2KeKQEok+96WM7R5d2KuxV2Kv8A/9k=" alt="Student Photo">
                    </div>
                </div>
            </div>

            <div class="marks-tables-container">

                <div class="marks-table">
            <div class="marks-table-exam-name">Final</div>
            <table>
                <thead>
                    <tr>
                        <th>Subject</th>
                        <th>Written</th>
                        <th>Oral</th>
                        <th>Total</th>
                        <th>Obtained</th>
                        <th>Grade</th>
                    </tr>
                </thead>
                <tbody><tr>
                <td>Bengali</td>
                <td>70</td>
                <td>10</td>
                <td>100</td>
                <td>80</td>
                <td><strong>A+</strong></td>
            </tr><tr>
                <td>English</td>
                <td>72</td>
                <td>12</td>
                <td>100</td>
                <td>84</td>
                <td><strong>A+</strong></td>
            </tr><tr>
                <td>Mathematics</td>
                <td>75</td>
                <td>15</td>
                <td>100</td>
                <td>90</td>
                <td><strong>AA</strong></td>
            </tr><tr>
                <td>History</td>
                <td>70</td>
                <td>4</td>
                <td>100</td>
                <td>74</td>
                <td><strong>A</strong></td>
            </tr><tr>
                <td>Drawing</td>
                <td>71</td>
                <td>11</td>
                <td>100</td>
                <td>82</td>
                <td><strong>A+</strong></td>
            </tr><tr>
                <td>G.k</td>
                <td>70</td>
                <td>11</td>
                <td>100</td>
                <td>81</td>
                <td><strong>A+</strong></td>
            </tr></tbody>
            </table>
        </div><div class="marks-table">
            <div class="marks-table-exam-name">True Final</div>
            <table>
                <thead>
                    <tr>
                        <th>Subject</th>
                        <th>Written</th>
                        <th>Oral</th>
                        <th>Total</th>
                        <th>Obtained</th>
                        <th>Grade</th>
                    </tr>
                </thead>
                <tbody><tr>
                <td>Bengali</td>
                <td>55</td>
                <td>9</td>
                <td>100</td>
                <td>64</td>
                <td><strong>B+</strong></td>
            </tr><tr>
                <td>English</td>
                <td>70</td>
                <td>5</td>
                <td>100</td>
                <td>75</td>
                <td><strong>A</strong></td>
            </tr><tr>
                <td>Mathematics</td>
                <td>61</td>
                <td>14</td>
                <td>100</td>
                <td>75</td>
                <td><strong>A</strong></td>
            </tr><tr>
                <td>History</td>
                <td>74</td>
                <td>12</td>
                <td>100</td>
                <td>86</td>
                <td><strong>A+</strong></td>
            </tr><tr>
                <td>Drawing</td>
                <td>75</td>
                <td>-</td>
                <td>100</td>
                <td>75</td>
                <td><strong>A</strong></td>
            </tr><tr>
                <td>G.k</td>
                <td>58</td>
                <td>11</td>
                <td>100</td>
                <td>69</td>
                <td><strong>B+</strong></td>
            </tr></tbody>
            </table>
        </div>

                <div class="marks-table grade-system-table">
                    <div class="marks-table-exam-name">Grade System</div>
                    <table class="grading-table">
                        <thead>
                            <tr>
                                <th>Marks Range</th>
                                <th>Grade</th>
                                <th>Performance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
            <td>90% - 100%</td>
            <td><strong>AA</strong></td>
            <td>Outstanding</td>
        </tr><tr>
            <td>80% - 89%</td>
            <td><strong>A+</strong></td>
            <td>Excellent</td>
        </tr><tr>
            <td>70% - 79%</td>
            <td><strong>A</strong></td>
            <td>Very Good</td>
        </tr><tr>
            <td>60% - 69%</td>
            <td><strong>B+</strong></td>
            <td>Good</td>
        </tr><tr>
            <td>50% - 59%</td>
            <td><strong>B</strong></td>
            <td>Satisfactory</td>
        </tr><tr>
            <td>40% - 49%</td>
            <td><strong>C+</strong></td>
            <td>Acceptable</td>
        </tr><tr>
            <td>35% - 39%</td>
            <td><strong>C</strong></td>
            <td>Basic</td>
        </tr><tr>
            <td>0% - 34%</td>
            <td><strong>D</strong></td>
            <td>Disqualified</td>
        </tr>
                        </tbody>
                    </table>
                </div>

                <div class="marks-table marks-table-overall">
                    <div class="marks-table-exam-name">Overall Marks</div>
                    <table class="overall-marks-table">
                        <thead>
                            <tr>
                                <th>Subject</th>
                                <th>Written</th>
                                <th>Oral</th>
                                <th>Total</th>
                                <th>Obtained</th>
                                <th>Grade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
            <td>Bengali</td>
            <td>63</td>
            <td>10</td>
            <td>100</td>
            <td>72</td>
            <td>A</td>
        </tr><tr>
            <td>English</td>
            <td>71</td>
            <td>9</td>
            <td>100</td>
            <td>80</td>
            <td>A</td>
        </tr><tr>
            <td>Mathematics</td>
            <td>68</td>
            <td>15</td>
            <td>100</td>
            <td>83</td>
            <td>A+</td>
        </tr><tr>
            <td>History</td>
            <td>72</td>
            <td>8</td>
            <td>100</td>
            <td>80</td>
            <td>A+</td>
        </tr><tr>
            <td>Drawing</td>
            <td>73</td>
            <td>6</td>
            <td>100</td>
            <td>79</td>
            <td>A</td>
        </tr><tr>
            <td>G.k</td>
            <td>64</td>
            <td>11</td>
            <td>100</td>
            <td>75</td>
            <td>A</td>
        </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="summary-table">
                <table>
                    <tr>
                        <th>Total Marks:</th>
                        <td>600</td>
                        <th>Obtained Marks:</th>
                        <td>468</td>
                        <th>Percentage:</th>
                        <td>77.9%</td>
                        <th>Overall Grade:</th>
                        <td>A</td>
                    </tr>
                    <tr>
                        <th>Position in Class:</th>
                        <td style="color:#420303;"><b>--</b></td>
                        <th>Result:</th>
                        <td><b style="color:#008000;">PASS</b></td>
                        <th>Remarks:</th>
                        <td>Very Good</td>
                    </tr>
                </table>
            </div>

            <div class="signatures">
                <div>
                    <p>Teacher's Sign</p>
                </div>
                <div>
                    <p>Date</p>
                </div>
                <div>
                    <p>Guardian's Sign</p>
                </div>
                <div>
                    <div>
                        <img src="<?=$principal_sign_base64?>" alt="Principal's Signature">
                        <p>Principal's Sign</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>