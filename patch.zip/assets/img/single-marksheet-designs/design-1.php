<?php
// design-1.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once(__DIR__ . '/../../../includes/config.php');

// 1. Fetch Real Settings (so the preview reflects actual color choices)
$stmt = $pdo->prepare("SELECT * FROM settings_marksheet LIMIT 1");
$stmt->execute();
$marksheet_settings = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$marksheet_settings) {
    die("Marksheet settings not found. Please save settings first.");
}

// 2. School Information (Real Data from config)
$school_name = $schoolInfo['name'] ?? 'Demo School Name';
$school_address = $schoolInfo['address'] ?? '123 School Street, City, Country';
$school_phone = $schoolInfo['phone'] ?? '+1234567890';
$school_email = $schoolInfo['email'] ?? 'info@demoschool.com';

// 3. Handle Images (With Fallbacks for Preview)
function getBase64Safe($path) {
    if (file_exists($path)) {
        return imageToBase64($path);
    }
    // Return a 1x1 transparent pixel or generic placeholder if file missing
    return 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII='; 
}

$school_logo_path = __DIR__ . '/../../../uploads/school/logo-square.png';
$school_logo_base64 = getBase64Safe($school_logo_path);

$principal_sign_path = __DIR__ . '/../../../uploads/school/principle_sign.png';
$principal_sign_base64 = getBase64Safe($principal_sign_path);

// 4. DUMMY STUDENT DATA (Replacing DB Query)
$result = [
    'exam_name'      => 'Annual Examination 2024-25',
    'student_id'     => 'STU-2025-001',
    'roll_no'        => '101',
    'name'           => 'John Doe',
    'father_name'    => 'Richard Doe',
    'class_name'     => 'Class 10',
    'section_name'   => 'A',
    'exam_date'      => date('Y-m-d'),
    'total_marks'    => 500,
    'obtained_marks' => 456.50,
    'percentage'     => 91.30,
    'grade'          => 'A+',
    'remarks'        => 'Outstanding',
    'is_promoted'    => 1
];

// Dummy Student Photo (Use a specific dummy path or the fallback)
$student_photo_path = __DIR__ . '/../../../uploads/students/default_student_dp.jpg'; // Ensure you have a dummy image or it uses fallback
$student_photo_base64 = getBase64Safe($student_photo_path);

// 5. DUMMY SUBJECT ROWS
$dummy_subjects = [
    ['name' => 'Mathematics', 'type' => 'Major', 'theory' => 75, 'practical' => 20, 'total' => 100, 'obtained' => 95, 'grade' => 'A+'],
    ['name' => 'English',     'type' => 'Major', 'theory' => 65, 'practical' => 18, 'total' => 100, 'obtained' => 83, 'grade' => 'A'],
    ['name' => 'Science',     'type' => 'Major', 'theory' => 70, 'practical' => 19, 'total' => 100, 'obtained' => 89, 'grade' => 'A'],
    ['name' => 'History',     'type' => 'Major', 'theory' => 80, 'practical' => 0,  'total' => 100, 'obtained' => 80, 'grade' => 'A'],
    ['name' => 'Computer',    'type' => 'Major', 'theory' => 40, 'practical' => 50, 'total' => 100, 'obtained' => 90, 'grade' => 'A+'],
    ['name' => 'Drawing',     'type' => 'Minor', 'theory' => 0,  'practical' => 50, 'total' => 50,  'obtained' => 45, 'grade' => 'A+']
];

$subject_rows = "";
foreach ($dummy_subjects as $sub) {
    // Mimic the logic for Minor subjects highlighting
    $tr_style = "";
    if (!$marksheet_settings['include_minor_subjects_marks'] && strtolower($sub['type']) == "minor") {
        $tr_style = "style='color:#ff8800;font-weight:bold;'";
    }

    $subject_rows .= "<tr $tr_style>
        <td>" . safe_htmlspecialchars($sub['name']) . "</td>
        <td>" . safe_htmlspecialchars($sub['type']) . "</td>
        <td>" . ($sub['theory'] > 0 ? (float)$sub['theory'] : '-') . "</td>
        <td>" . ($sub['practical'] > 0 ? (float)$sub['practical'] : '-') . "</td>
        <td>" . (float)$sub['total'] . "</td>
        <td>" . (float)$sub['obtained'] . "</td>
        <td><strong>" . safe_htmlspecialchars($sub['grade']) . "</strong></td>
    </tr>";
}

// 6. DUMMY GRADING SYSTEM
$dummy_grading = [
    ['range' => '90% - 100%', 'grade' => 'A+', 'remarks' => 'Outstanding'],
    ['range' => '80% - 89%',  'grade' => 'A',  'remarks' => 'Excellent'],
    ['range' => '70% - 79%',  'grade' => 'B',  'remarks' => 'Very Good'],
    ['range' => '60% - 69%',  'grade' => 'C',  'remarks' => 'Good'],
    ['range' => '0% - 39%',   'grade' => 'F',  'remarks' => 'Fail'],
];

$grading_rows = "";
foreach ($dummy_grading as $grade) {
    $grading_rows .= "<tr>
        <td>{$grade['range']}</td>
        <td><strong>{$grade['grade']}</strong></td>
        <td>{$grade['remarks']}</td>
    </tr>";
}

// 7. DUMMY TOP RANKERS
$dummy_rankers = [
    ['rank' => 1, 'name' => 'John Doe', 'percentage' => 91.30, 'grade' => 'A+'],
    ['rank' => 2, 'name' => 'Alice Smith', 'percentage' => 89.50, 'grade' => 'A'],
    ['rank' => 3, 'name' => 'Bob Johnson', 'percentage' => 88.00, 'grade' => 'A'],
    ['rank' => 3, 'name' => 'Sarfaraz Ahamed', 'percentage' => 88.00, 'grade' => 'A'],
    ['rank' => 3, 'name' => 'Jimmy Carter', 'percentage' => 88.00, 'grade' => 'A'],
];

$top_rankers_rows = "";
foreach ($dummy_rankers as $ranker) {
    // Assuming getOrdinal is defined in config.php, otherwise fallback
    $ordinal = function_exists('getOrdinal') ? getOrdinal($ranker['rank']) : $ranker['rank'];
    
    $top_rankers_rows .= "<tr>
        <td>{$ordinal}</td>
        <td>" . safe_htmlspecialchars($ranker['name']) . "</td>
        <td>" . number_format($ranker['percentage'], 2) . "%</td>
        <td>" . safe_htmlspecialchars($ranker['grade']) . "</td>
    </tr>";
}


// 9. DUMMY PROMOTION STATUS
$promotion_status_row = $result['is_promoted'] ? '' : '';


// 10. LOAD CSS & HTML
$css_style = file_get_contents('../../templates/marksheet-templates/single-marksheets/design1/style.css');
$css_style = str_replace(
    [
        '{{theme_primary}}',
        '{{theme_dark}}',
        '{{theme_light}}',
        '{{page_background_color}}',
        '{{school_name_text_color}}',
        '{{school_address_text_color}}'
    ],
    [
        $marksheet_settings['primary_theme_color'],
        $marksheet_settings['dark_theme_color'],
        $marksheet_settings['light_theme_color'],
        $marksheet_settings['background_color'],
        $marksheet_settings['school_name_text_color'],
        $marksheet_settings['school_address_text_color']
    ],
    $css_style
);
$css = "<style>" . $css_style . "</style>";

$header_html = file_get_contents('../../templates/marksheet-templates/header.html');
$header_html = str_replace('<link rel="stylesheet" href="style.css">', $css, $header_html);

$content_html = file_get_contents('../../templates/marksheet-templates/single-marksheets/design1/content.html');

// 11. COMBINE AND REPLACE PLACEHOLDERS
$all_html_content = $header_html;

$page_html = $content_html;

// Dummy Position Calculation (1st)
$dummy_position = function_exists('getOrdinal') ? getOrdinal(1) : '1st';

$placeholders = [
    '{{school_logo_base64}}'      => $school_logo_base64,
    '{{school_name}}'             => safe_htmlspecialchars($school_name),
    '{{school_address}}'          => safe_htmlspecialchars($school_address),
    '{{school_phone}}'            => safe_htmlspecialchars($school_phone),
    '{{school_email}}'            => safe_htmlspecialchars($school_email),
    '{{exam_name}}'               => strtoupper(safe_htmlspecialchars($result['exam_name'])),
    '{{student_id}}'              => safe_htmlspecialchars($result['student_id']),
    '{{roll_no}}'                 => safe_htmlspecialchars($result['roll_no']),
    '{{student_name}}'            => safe_htmlspecialchars($result['name']),
    '{{father_name}}'             => safe_htmlspecialchars($result['father_name']),
    '{{class_name}}'              => safe_htmlspecialchars($result['class_name']),
    '{{section_name}}'            => safe_htmlspecialchars($result['section_name']),
    '{{exam_date}}'               => safe_htmlspecialchars($result['exam_date']),
    '{{student_photo_base64}}'    => $student_photo_base64,
    '{{subject_rows}}'            => $subject_rows,
    '{{total_marks}}'             => (float) round($result['total_marks'], 2),
    '{{obtained_marks}}'          => (float) round($result['obtained_marks'], 2),
    '{{percentage}}'              => (float) round($result['percentage'], 2),
    '{{overall_grade}}'           => safe_htmlspecialchars($result['grade']),
    // Hardcoded position '1' because we can't calculate rank without full DB
    '{{position_in_class}}'       => $dummy_position, 
    '{{result_status}}'           => '<b style="color: green;">PASS</b>', // Hardcoded for preview
    '{{remarks}}'                 => safe_htmlspecialchars($result['remarks']),
    '{{promotion_status_row}}'    => $promotion_status_row,
    '{{grading_rows}}'            => $grading_rows,
    '{{top_rankers_rows}}'        => $top_rankers_rows,
    '{{principle_sign_base64}}'   => $principal_sign_base64
];

foreach ($placeholders as $key => $value) {
    $page_html = str_replace($key, $value, $page_html);
}

$all_html_content .= $page_html;
$all_html_content .= "</body></html>";

header("Content-Type: text/html; charset=UTF-8");
echo $all_html_content;
?>