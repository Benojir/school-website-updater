<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Device Login Notification</title>
    <style>
        body, table, td, div, p {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        
        body {
            background-color: #f5f5f5;
            color: #333333;
            line-height: 1.6;
        }
        
        .email-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .header {
            background-color: #2c3e50;
            color: #ffffff;
            padding: 25px;
            text-align: center;
        }
        
        .logo {
            max-width: 150px;
            height: auto;
        }
        
        .content {
            padding: 30px;
        }
        
        .alert-box {
            background-color: #fff8e1;
            border: 1px solid #ffc107;
            border-radius: 6px;
            padding: 20px;
            margin: 20px 0;
        }
        
        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin: 25px 0;
            background-color: #f8f9fa;
            border-radius: 6px;
            overflow: hidden;
        }
        
        .info-table td {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .info-table tr:last-child td {
            border-bottom: none;
        }
        
        .info-label {
            font-weight: bold;
            color: #2c3e50;
            width: 35%;
        }
        
        .info-value {
            color: #333333;
            font-family: 'Courier New', monospace;
            word-break: break-all;
        }
        
        .button {
            display: inline-block;
            background-color: #3498db;
            color: #ffffff;
            text-decoration: none;
            padding: 12px 30px;
            border-radius: 4px;
            font-weight: bold;
            margin: 10px 5px 10px 0;
            text-align: center;
        }
        
        .button-danger {
            background-color: #e74c3c;
        }
        
        .footer {
            background-color: #f8f9fa;
            padding: 25px;
            text-align: center;
            font-size: 12px;
            color: #777777;
            border-top: 1px solid #e0e0e0;
        }
        
        .footer-links {
            margin: 15px 0;
        }
        
        .footer-links a {
            color: #3498db;
            text-decoration: none;
            margin: 0 10px;
        }
        
        .device-icon {
            font-size: 20px;
            margin-right: 8px;
            vertical-align: middle;
        }
        
        .security-tips {
            background-color: #f8f9fa;
            border-left: 4px solid #3498db;
            padding: 15px;
            margin: 25px 0;
        }
        
        @media (max-width: 600px) {
            .content {
                padding: 20px;
            }
            
            .button {
                display: block;
                margin: 10px 0;
                width: 100%;
                box-sizing: border-box;
            }
        }
    </style>
</head>
<body>
    <div class="email-container">
        <!-- Header -->
        <div class="header">
            <h1><strong>{{school_name}}</strong></h1>
            <p>Security Notification</p>
        </div>
        
        <!-- Main Content -->
        <div class="content">
            <h2>New Device Login Detected</h2>
            <p>Hello <strong>{{user_full_name}}</strong>,</p>
            <p>We detected a new sign-in to your {{school_name}} administrator account. If this was you, you can safely ignore this email. If you don't recognize this activity, please secure your account immediately.</p>
            
            <div class="alert-box">
                <h3 style="margin-top: 0; color: #d35400;">⚠️ Security Alert</h3>
                <p style="margin-bottom: 0;">Review this login attempt below. If this wasn't you, someone else might be accessing your account.</p>
            </div>
            
            <h3>Login Details:</h3>
            <table class="info-table">
                <tr>
                    <td class="info-label">Device Name:</td>
                    <td class="info-value">
                        <span class="device-icon">💻</span> 
                        {{login_device_name}}
                    </td>
                </tr>
                <tr>
                    <td class="info-label">Source:</td>
                    <td class="info-value">{{login_source}}</td>
                </tr>
                <tr>
                    <td class="info-label">IP Address:</td>
                    <td class="info-value">{{detected_ip_address}}</td>
                </tr>
                <tr>
                    <td class="info-label">Login Time:</td>
                    <td class="info-value">{{login_time}}</td>
                </tr>
                <tr>
                    <td class="info-label">Account Email:</td>
                    <td class="info-value">{{user_email}}</td>
                </tr>
            </table>
            
            <p><strong>Is this you?</strong></p>
            <p>
                <a href="{{user_profile_url}}" class="button">✅ Yes, This Was Me</a>
                <a href="{{reset_password_url}}" class="button button-danger">🔒 No, Secure My Account</a>
            </p>
            
            <div class="security-tips">
                <h4 style="margin-top: 0;">Security Recommendations:</h4>
                <ul style="margin-bottom: 0;">
                    <li>Change your password if you don't recognize this activity</li>
                    <li>Enable two-factor authentication if available</li>
                    <li>Review your account's recent activity</li>
                    <li>Log out of all other sessions if suspicious</li>
                </ul>
            </div>
            
            <p>If you have any questions or concerns, please contact the {{school_name}} IT support team immediately.</p>
            
            <p>Best regards,<br><strong>{{school_name}} Security Team</strong></p>
        </div>
        
        <!-- Footer -->
        <div class="footer">
            <p>This is an automated security message from {{school_name}}.</p>
            <div class="footer-links">
                <a href="{{user_profile_url}}">Account Settings</a> | 
                <a href="{{reset_password_url}}">Reset Password</a> | 
                <a href="https://wa.me/+918348313317">Contact Support</a>
            </div>
            <p>© {{current_year}} {{school_name}}. All rights reserved.</p>
            <p style="font-size: 10px; margin-top: 15px; color: #999;">
                This email was sent to {{user_email}}.<br>
                Please do not reply to this automated message.
            </p>
        </div>
    </div>
</body>
</html>