<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Not Found | 404 Error</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
            overflow-x: hidden;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            padding: 40px 20px;
            background-color: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 24px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            position: relative;
            overflow: hidden;
        }
        
        .container::before {
            content: '';
            position: absolute;
            width: 300px;
            height: 300px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            top: -150px;
            right: -100px;
        }
        
        .container::after {
            content: '';
            position: absolute;
            width: 200px;
            height: 200px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.05);
            bottom: -100px;
            left: -80px;
        }
        
        .error-code {
            font-size: 12rem;
            font-weight: 900;
            line-height: 1;
            margin-bottom: 10px;
            text-shadow: 5px 5px 0 rgba(0, 0, 0, 0.2);
            position: relative;
            z-index: 1;
            background: linear-gradient(to right, #ff7e5f, #feb47b);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            animation: float 3s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }
        
        .error-title {
            font-size: 2.8rem;
            margin-bottom: 20px;
            font-weight: 700;
            letter-spacing: 1px;
        }
        
        .error-message {
            font-size: 1.3rem;
            max-width: 700px;
            line-height: 1.6;
            margin-bottom: 40px;
            opacity: 0.9;
            padding: 0 20px;
        }
        
        .search-box {
            width: 100%;
            max-width: 600px;
            margin-bottom: 40px;
            position: relative;
            z-index: 2;
        }
        
        .search-box input {
            width: 100%;
            padding: 18px 25px;
            border: none;
            border-radius: 50px;
            font-size: 1.1rem;
            background: rgba(255, 255, 255, 0.9);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }
        
        .search-box input:focus {
            outline: none;
            background: rgba(255, 255, 255, 1);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
            transform: translateY(-3px);
        }
        
        .search-box button {
            position: absolute;
            right: 6px;
            top: 6px;
            background: linear-gradient(to right, #6a11cb, #2575fc);
            border: none;
            color: white;
            padding: 12px 25px;
            border-radius: 50px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .search-box button:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }
        
        .actions {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            margin-bottom: 50px;
            z-index: 2;
            position: relative;
        }
        
        .action-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 16px 32px;
            background: rgba(255, 255, 255, 0.15);
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-radius: 50px;
            color: white;
            font-size: 1.1rem;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s ease;
            backdrop-filter: blur(5px);
        }
        
        .action-btn:hover {
            background: rgba(255, 255, 255, 0.25);
            border-color: rgba(255, 255, 255, 0.5);
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }
        
        .action-btn i {
            font-size: 1.2rem;
        }
        
        .illustration {
            width: 100%;
            max-width: 500px;
            margin: 30px 0;
            position: relative;
            z-index: 1;
        }
        
        .astronaut {
            width: 200px;
            height: 200px;
            position: relative;
            margin: 0 auto 40px;
            animation: float-astronaut 6s ease-in-out infinite;
        }
        
        @keyframes float-astronaut {
            0%, 100% { transform: translateY(0) rotate(0deg); }
            25% { transform: translateY(-20px) rotate(5deg); }
            75% { transform: translateY(10px) rotate(-5deg); }
        }
        
        .astronaut-helmet {
            width: 140px;
            height: 140px;
            background: #f0f0f0;
            border-radius: 50%;
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            overflow: hidden;
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.5);
        }
        
        .astronaut-visor {
            width: 100px;
            height: 60px;
            background: #0d1b2a;
            border-radius: 30px;
            position: absolute;
            top: 40px;
            left: 50%;
            transform: translateX(-50%);
            overflow: hidden;
        }
        
        .astronaut-visor::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 10px;
            background: rgba(255, 255, 255, 0.2);
            top: 15px;
        }
        
        .astronaut-body {
            width: 120px;
            height: 120px;
            background: #4a6572;
            border-radius: 50%;
            position: absolute;
            top: 90px;
            left: 50%;
            transform: translateX(-50%);
        }
        
        .floating-objects {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: 0;
        }
        
        .floating-object {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            animation: float-object 15s infinite linear;
        }
        
        @keyframes float-object {
            0% { transform: translateY(0) rotate(0deg); }
            100% { transform: translateY(-1000px) rotate(720deg); }
        }
        
        .footer {
            font-size: 0.9rem;
            opacity: 0.8;
            margin-top: 20px;
            z-index: 2;
            position: relative;
        }
        
        .footer a {
            color: #ffdd99;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .footer a:hover {
            color: #fff;
            text-decoration: underline;
        }
        
        @media (max-width: 768px) {
            .error-code {
                font-size: 8rem;
            }
            
            .error-title {
                font-size: 2.2rem;
            }
            
            .error-message {
                font-size: 1.1rem;
            }
            
            .actions {
                flex-direction: column;
                align-items: center;
            }
            
            .action-btn {
                width: 100%;
                max-width: 300px;
            }
        }
        
        @media (max-width: 480px) {
            .error-code {
                font-size: 6rem;
            }
            
            .error-title {
                font-size: 1.8rem;
            }
            
            .container {
                padding: 30px 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="error-code">404</h1>
        <h2 class="error-title">Oops! Page Lost in Space</h2>
        <p class="error-message">The page you are looking for might have been removed, had its name changed, or is temporarily unavailable. Don't worry, our astronaut will help you find your way back home!</p>
        
        <div class="illustration">
            <div class="astronaut">
                <div class="astronaut-helmet">
                    <div class="astronaut-visor"></div>
                </div>
                <div class="astronaut-body"></div>
            </div>
        </div>
        
        <div class="actions">
            <a href="/" class="action-btn" id="goHomeBtn">
                <i class="fas fa-home"></i> Back to Homepage
            </a>
            <a href="/pages/contact-us.php" class="action-btn" id="contactBtn">
                <i class="fas fa-envelope"></i> Contact Support
            </a>
        </div>
        
        <div class="footer">
            <p>Need help? <a href="#">Visit our help center</a> or <a href="#">report this issue</a></p>
            <p>&copy; 2026 SpaceWeb. All rights reserved.</p>
        </div>
        
        <div class="floating-objects" id="floatingObjects"></div>
    </div>

    <script>
        // Create floating objects
        const floatingObjects = document.getElementById('floatingObjects');
        for (let i = 0; i < 20; i++) {
            const object = document.createElement('div');
            object.classList.add('floating-object');
            
            // Random size between 5 and 30px
            const size = Math.random() * 25 + 5;
            object.style.width = `${size}px`;
            object.style.height = `${size}px`;
            
            // Random position
            object.style.left = `${Math.random() * 100}%`;
            object.style.top = `${Math.random() * 100}%`;
            
            // Random animation delay and duration
            object.style.animationDelay = `${Math.random() * 5}s`;
            object.style.animationDuration = `${Math.random() * 20 + 10}s`;
            
            floatingObjects.appendChild(object);
        }
        
        
        // Animate error code numbers individually
        const errorCode = document.querySelector('.error-code');
        const text = errorCode.textContent;
        errorCode.innerHTML = '';
        
        for (let i = 0; i < text.length; i++) {
            const span = document.createElement('span');
            span.textContent = text[i];
            span.style.animationDelay = `${i * 0.1}s`;
            span.style.display = 'inline-block';
            errorCode.appendChild(span);
        }
    </script>
</body>
</html>