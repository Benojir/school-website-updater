<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Page Vanished</title>
    <style>
        /* --- RESET & LAYOUT --- */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: white;
            overflow: hidden;
            text-align: center;
        }

        .container {
            position: relative;
            padding: 2rem;
            max-width: 600px;
        }

        /* --- THE GHOST ANIMATION WRAPPER --- */
        .ghost-container {
            width: 120px;
            height: 150px;
            margin: 0 auto 30px auto;
            position: relative;
            animation: float 3s ease-in-out infinite;
        }

        /* --- SVG STYLING --- */
        .ghost-svg {
            width: 100%;
            height: 100%;
            drop-shadow: 0 10px 15px rgba(0,0,0,0.1);
        }

        /* Eyes Blinking Animation */
        .ghost-eyes {
            animation: blink 4s infinite;
            transform-origin: center;
        }

        /* --- THE SHADOW UNDER THE GHOST --- */
        .shadow {
            width: 80px;
            height: 20px;
            background: rgba(0, 0, 0, 0.15);
            border-radius: 50%;
            margin: -20px auto 30px auto; /* Pull up to sit under ghost */
            animation: shadow-scale 3s ease-in-out infinite;
        }

        /* --- TYPOGRAPHY --- */
        h1 {
            font-size: 6rem;
            font-weight: 800;
            margin-bottom: 0;
            line-height: 1;
            opacity: 0.9;
        }

        h2 {
            font-size: 2rem;
            font-weight: 300;
            margin-bottom: 1rem;
            opacity: 0.9;
        }

        p {
            font-size: 1.1rem;
            margin-bottom: 2.5rem;
            line-height: 1.6;
            opacity: 0.8;
        }

        /* --- BUTTON STYLING --- */
        .btn {
            background-color: white;
            color: #764ba2;
            padding: 15px 35px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 700;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            transition: transform 0.2s, box-shadow 0.2s;
            display: inline-block;
        }

        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.3);
        }

        .btn:active {
            transform: translateY(1px);
        }

        /* --- KEYFRAME ANIMATIONS --- */
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
            100% { transform: translateY(0px); }
        }

        @keyframes shadow-scale {
            0% { transform: scale(1); opacity: 0.2; }
            50% { transform: scale(0.8); opacity: 0.1; }
            100% { transform: scale(1); opacity: 0.2; }
        }

        @keyframes blink {
            0%, 48%, 52%, 100% { transform: scaleY(1); }
            50% { transform: scaleY(0.1); }
        }

        /* --- RESPONSIVE --- */
        @media (max-width: 480px) {
            h1 { font-size: 4rem; }
            h2 { font-size: 1.5rem; }
            .ghost-container { width: 100px; }
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="ghost-container">
            <svg class="ghost-svg" viewBox="0 0 100 120" xmlns="http://www.w3.org/2000/svg">
                <path d="M10,60 Q10,10 50,10 T90,60 V100 Q80,110 70,100 T50,100 T30,100 T10,100 Z" fill="#f8f9fa"/>
                
                <g class="ghost-eyes" fill="#333">
                    <circle cx="35" cy="50" r="5" />
                    <circle cx="65" cy="50" r="5" />
                </g>
                <ellipse cx="50" cy="65" rx="6" ry="8" fill="#333" opacity="0.8"/>
                
                <circle cx="25" cy="60" r="3" fill="#ffb7b2" opacity="0.5"/>
                <circle cx="75" cy="60" r="3" fill="#ffb7b2" opacity="0.5"/>
            </svg>
        </div>
        
        <div class="shadow"></div>

        <h1>404</h1>
        <h2>Spooked!</h2>
        <p>The page you are looking for has vanished into thin air.<br>Don't be afraid, just head back home.</p>

        <a href="/" class="btn">Go Home</a>
    </div>

</body>
</html>