<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/uploads/school/favicon.png" type="image/x-icon">
    <title>404 - Lost in the Magical Forest</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Georgia', serif;
            overflow: hidden;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 30%, #0f3460 60%, #1a1a2e 100%);
            position: relative;
            height: 100vh;
        }

        .forest-container {
            position: relative;
            width: 100%;
            height: 100vh;
            overflow: hidden;
        }

        .stars {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                radial-gradient(2px 2px at 20px 30px, #ffffff, transparent),
                radial-gradient(2px 2px at 40px 70px, #e1c5ff, transparent),
                radial-gradient(1px 1px at 90px 40px, #ffffff, transparent),
                radial-gradient(1px 1px at 130px 80px, #c5e1ff, transparent),
                radial-gradient(2px 2px at 160px 30px, #ffffff, transparent);
            background-repeat: repeat;
            background-size: 200px 100px;
            animation: sparkle 10s linear infinite;
            z-index: 1;
        }

        .moon {
            position: absolute;
            top: 10%;
            right: 15%;
            width: 120px;
            height: 120px;
            background: radial-gradient(circle at 30% 30%, #fff9c4, #f5f5dc);
            border-radius: 50%;
            box-shadow: 
                0 0 50px rgba(255, 249, 196, 0.6),
                inset -10px -10px 20px rgba(0, 0, 0, 0.1);
            animation: moonGlow 4s ease-in-out infinite alternate;
            z-index: 2;
        }

        .trees {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 60%;
            background: linear-gradient(to top, #0d1b2a 0%, transparent 100%);
            z-index: 3;
        }

        .tree {
            position: absolute;
            bottom: 0;
            background: linear-gradient(to top, #2c3e50, #34495e);
            opacity: 0.8;
        }

        .tree:nth-child(1) { left: 5%; width: 8px; height: 40%; }
        .tree:nth-child(2) { left: 15%; width: 12px; height: 55%; }
        .tree:nth-child(3) { left: 25%; width: 6px; height: 35%; }
        .tree:nth-child(4) { right: 20%; width: 10px; height: 45%; }
        .tree:nth-child(5) { right: 8%; width: 14px; height: 50%; }

        .magical-particles {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 5;
        }

        .particle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: radial-gradient(circle, #ff69b4, #9370db);
            border-radius: 50%;
            animation: magicalFloat 12s ease-in-out infinite;
            opacity: 0;
        }

        .particle:nth-child(1) { top: 70%; left: 10%; animation-delay: 0s; }
        .particle:nth-child(2) { top: 30%; left: 80%; animation-delay: 2s; }
        .particle:nth-child(3) { top: 50%; left: 60%; animation-delay: 4s; }
        .particle:nth-child(4) { top: 20%; left: 30%; animation-delay: 6s; }
        .particle:nth-child(5) { top: 80%; left: 70%; animation-delay: 8s; }
        .particle:nth-child(6) { top: 40%; left: 20%; animation-delay: 10s; }

        .fairy-lights {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 4;
        }

        .fairy-light {
            position: absolute;
            width: 8px;
            height: 8px;
            background: radial-gradient(circle, #ffd700, #ffb347);
            border-radius: 50%;
            box-shadow: 0 0 20px #ffd700;
            animation: fairyDance 8s ease-in-out infinite;
            opacity: 0;
        }

        .fairy-light:nth-child(1) { top: 25%; left: 20%; animation-delay: 0s; }
        .fairy-light:nth-child(2) { top: 60%; left: 75%; animation-delay: 1.5s; }
        .fairy-light:nth-child(3) { top: 40%; left: 45%; animation-delay: 3s; }
        .fairy-light:nth-child(4) { top: 80%; left: 15%; animation-delay: 4.5s; }

        .content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            z-index: 10;
            color: #f8f8ff;
            max-width: 700px;
            padding: 2rem;
        }

        .error-code {
            font-size: clamp(4rem, 12vw, 8rem);
            font-weight: bold;
            background: linear-gradient(45deg, #ff69b4, #9370db, #00bfff, #ff69b4);
            background-size: 400% 400%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-shadow: 0 0 30px rgba(255, 105, 180, 0.5);
            margin-bottom: 1rem;
            animation: magicalGlow 6s ease-in-out infinite;
            letter-spacing: 0.1em;
        }

        .title {
            font-size: clamp(1.8rem, 4vw, 2.8rem);
            margin-bottom: 1rem;
            color: #e6e6fa;
            font-weight: 300;
            text-shadow: 
                0 0 10px rgba(230, 230, 250, 0.5),
                2px 2px 4px rgba(0,0,0,0.3);
            font-family: 'Georgia', serif;
        }

        .message {
            font-size: clamp(1rem, 2.5vw, 1.3rem);
            line-height: 1.7;
            margin-bottom: 2.5rem;
            color: #d8bfd8;
            opacity: 0;
            animation: fadeInUp 1s ease-out 2s forwards;
            font-family: 'Georgia', serif;
            font-style: italic;
        }

        .cta-button {
            display: inline-block;
            padding: 18px 40px;
            background: linear-gradient(45deg, #9370db, #ff69b4, #00bfff);
            background-size: 300% 300%;
            color: white;
            text-decoration: none;
            border-radius: 50px;
            font-weight: bold;
            font-size: 1.1rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            transition: all 0.4s ease;
            box-shadow: 
                0 10px 30px rgba(147, 112, 219, 0.4),
                inset 0 1px 0 rgba(255,255,255,0.2);
            opacity: 0;
            animation: fadeInUp 1s ease-out 2.5s forwards, buttonGlow 3s ease-in-out infinite;
            position: relative;
            overflow: hidden;
            border: 2px solid rgba(255, 255, 255, 0.1);
        }

        .cta-button:hover {
            transform: translateY(-5px) scale(1.05);
            box-shadow: 
                0 15px 40px rgba(147, 112, 219, 0.6),
                0 0 50px rgba(255, 105, 180, 0.3);
            animation: buttonGlow 1s ease-in-out infinite, magicalPulse 0.3s ease-out;
        }

        .cta-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            transition: left 0.6s;
        }

        .cta-button:hover::before {
            left: 100%;
        }

        .magical-sparkles {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 6;
        }

        .sparkle {
            position: absolute;
            font-size: 20px;
            color: #ffd700;
            animation: sparkleShine 3s ease-in-out infinite;
            opacity: 0;
        }

        .sparkle:nth-child(1) { top: 15%; left: 25%; animation-delay: 0s; }
        .sparkle:nth-child(2) { top: 70%; left: 80%; animation-delay: 1s; }
        .sparkle:nth-child(3) { top: 45%; left: 10%; animation-delay: 2s; }
        .sparkle:nth-child(4) { top: 85%; left: 50%; animation-delay: 3s; }

        .enchanted-text {
            position: absolute;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
            color: #d8bfd8;
            font-size: 1rem;
            font-style: italic;
            opacity: 0.8;
            animation: enchantedPulse 4s ease-in-out infinite;
            z-index: 15;
        }

        @keyframes sparkle {
            0%, 100% { opacity: 0; }
            50% { opacity: 1; }
        }

        @keyframes moonGlow {
            0% { box-shadow: 0 0 50px rgba(255, 249, 196, 0.6), inset -10px -10px 20px rgba(0, 0, 0, 0.1); }
            100% { box-shadow: 0 0 80px rgba(255, 249, 196, 0.9), inset -10px -10px 20px rgba(0, 0, 0, 0.1); }
        }

        @keyframes magicalFloat {
            0%, 100% { 
                opacity: 0; 
                transform: translateY(0px) translateX(0px) scale(1); 
            }
            10% { opacity: 1; }
            90% { opacity: 1; }
            50% { 
                transform: translateY(-50px) translateX(30px) scale(1.5); 
            }
        }

        @keyframes fairyDance {
            0%, 100% { 
                opacity: 0; 
                transform: translateY(0px) translateX(0px) rotate(0deg); 
            }
            25% { 
                opacity: 1; 
                transform: translateY(-30px) translateX(20px) rotate(90deg); 
            }
            50% { 
                opacity: 1; 
                transform: translateY(-60px) translateX(-10px) rotate(180deg); 
            }
            75% { 
                opacity: 1; 
                transform: translateY(-30px) translateX(-30px) rotate(270deg); 
            }
        }

        @keyframes magicalGlow {
            0%, 100% { 
                background-position: 0% 50%;
                filter: drop-shadow(0 0 20px rgba(255, 105, 180, 0.5));
            }
            50% { 
                background-position: 100% 50%;
                filter: drop-shadow(0 0 40px rgba(147, 112, 219, 0.8));
            }
        }

        @keyframes fadeInUp {
            0% { opacity: 0; transform: translateY(30px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        @keyframes buttonGlow {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        @keyframes magicalPulse {
            0% { transform: translateY(-5px) scale(1.05); }
            50% { transform: translateY(-5px) scale(1.1); }
            100% { transform: translateY(-5px) scale(1.05); }
        }

        @keyframes sparkleShine {
            0%, 100% { opacity: 0; transform: scale(0) rotate(0deg); }
            50% { opacity: 1; transform: scale(1.5) rotate(180deg); }
        }

        @keyframes enchantedPulse {
            0%, 100% { opacity: 0.8; transform: translateX(-50%) scale(1); }
            50% { opacity: 1; transform: translateX(-50%) scale(1.05); }
        }

        @media (max-width: 768px) {
            .content {
                padding: 1rem;
                max-width: 90%;
            }
            
            .moon {
                width: 80px;
                height: 80px;
                top: 8%;
                right: 10%;
            }

            .enchanted-text {
                bottom: 20px;
                font-size: 0.9rem;
                padding: 0 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="forest-container">
        <div class="stars"></div>
        <div class="moon"></div>
        
        <div class="trees">
            <div class="tree"></div>
            <div class="tree"></div>
            <div class="tree"></div>
            <div class="tree"></div>
            <div class="tree"></div>
        </div>

        <div class="magical-particles">
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
            <div class="particle"></div>
        </div>

        <div class="fairy-lights">
            <div class="fairy-light"></div>
            <div class="fairy-light"></div>
            <div class="fairy-light"></div>
            <div class="fairy-light"></div>
        </div>

        <div class="magical-sparkles">
            <div class="sparkle">✨</div>
            <div class="sparkle">⭐</div>
            <div class="sparkle">✨</div>
            <div class="sparkle">⭐</div>
        </div>

        <div class="content">
            <div class="error-code">404</div>
            <h1 class="title">Lost in the Enchanted Forest</h1>
            <p class="message">
                You've wandered into the mystical realm where ancient magic flows through moonlit trees. 
                The path you seek has been hidden by fairy dust and time itself. 
                But fear not, brave wanderer — the forest spirits will guide you back to familiar lands.
            </p>
            <a href="/" class="cta-button">Follow the Magic Home</a>
        </div>

        <div class="enchanted-text">
            🌙 The magic is strongest at midnight... 🌟
        </div>
    </div>

    <script>
        // Enhanced magical interactions
        document.addEventListener('mousemove', (e) => {
            const particles = document.querySelectorAll('.particle');
            const fairyLights = document.querySelectorAll('.fairy-light');
            
            particles.forEach((particle, index) => {
                const speed = (index + 1) * 0.02;
                const x = (e.clientX * speed) % window.innerWidth;
                const y = (e.clientY * speed) % window.innerHeight;
                particle.style.transform = `translate(${x * 0.05}px, ${y * 0.05}px)`;
            });

            fairyLights.forEach((light, index) => {
                const speed = (index + 1) * 0.015;
                const x = Math.sin(e.clientX * speed * 0.01) * 20;
                const y = Math.cos(e.clientY * speed * 0.01) * 20;
                light.style.transform = `translate(${x}px, ${y}px)`;
            });
        });

        // Magical click effects
        document.addEventListener('click', (e) => {
            // Create magical explosion
            for (let i = 0; i < 8; i++) {
                const sparkle = document.createElement('div');
                sparkle.style.position = 'absolute';
                sparkle.style.left = e.clientX + 'px';
                sparkle.style.top = e.clientY + 'px';
                sparkle.style.width = '6px';
                sparkle.style.height = '6px';
                sparkle.style.background = `radial-gradient(circle, ${['#ff69b4', '#9370db', '#00bfff', '#ffd700'][i % 4]}, transparent)`;
                sparkle.style.borderRadius = '50%';
                sparkle.style.pointerEvents = 'none';
                sparkle.style.zIndex = '20';
                sparkle.style.animation = 'magicalExplosion 1s ease-out forwards';
                
                const angle = (i / 8) * Math.PI * 2;
                const distance = 50;
                const endX = Math.cos(angle) * distance;
                const endY = Math.sin(angle) * distance;
                
                sparkle.style.setProperty('--end-x', endX + 'px');
                sparkle.style.setProperty('--end-y', endY + 'px');
                
                document.body.appendChild(sparkle);
                
                setTimeout(() => {
                    if (document.body.contains(sparkle)) {
                        document.body.removeChild(sparkle);
                    }
                }, 1000);
            }
        });

        // Add magical explosion animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes magicalExplosion {
                0% {
                    transform: translate(-50%, -50%) scale(0);
                    opacity: 1;
                }
                100% {
                    transform: translate(calc(-50% + var(--end-x)), calc(-50% + var(--end-y))) scale(1);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);

        // Add twinkling stars effect
        setInterval(() => {
            const stars = document.querySelector('.stars');
            const randomDelay = Math.random() * 2;
            stars.style.animationDelay = randomDelay + 's';
        }, 3000);
    </script>
</body>
</html>