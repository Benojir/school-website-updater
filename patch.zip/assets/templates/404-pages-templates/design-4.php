<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Adrift</title>
    <style>
        /* --- RESET & BASICS --- */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            background: linear-gradient(180deg, #aed9e0 0%, #ffffff 100%); /* Soft Sky Gradient */
            height: 100vh;
            overflow: hidden;
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            padding-top: 10vh;
            color: #5e6f80;
        }

        /* --- THE SUN --- */
        .sun {
            position: absolute;
            top: 10%;
            left: 50%;
            transform: translateX(-50%);
            width: 150px;
            height: 150px;
            background: #fff9e6;
            border-radius: 50%;
            z-index: 0;
            box-shadow: 0 0 60px rgba(255, 230, 150, 0.4);
        }

        /* --- CONTENT WRAPPER --- */
        .content {
            z-index: 10;
            text-align: center;
            position: relative;
        }

        h1 {
            font-size: 10rem;
            font-weight: 900;
            color: #fff;
            text-shadow: 0 10px 20px rgba(93, 169, 186, 0.2);
            margin-bottom: -20px;
            letter-spacing: -5px;
        }

        h2 {
            font-size: 2rem;
            margin-bottom: 20px;
            color: #5da9ba;
        }

        p {
            font-size: 1.2rem;
            max-width: 400px;
            margin: 0 auto 30px auto;
            line-height: 1.5;
        }

        .btn {
            display: inline-block;
            padding: 12px 30px;
            background: #ff6b6b;
            color: white;
            border-radius: 30px;
            text-decoration: none;
            font-weight: bold;
            box-shadow: 0 5px 15px rgba(255, 107, 107, 0.3);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(255, 107, 107, 0.4);
        }

        /* --- THE OCEAN (PURE CSS SHAPES) --- */
        .ocean {
            height: 50%;
            width: 100%;
            position: absolute;
            bottom: 0;
            left: 0;
            overflow: hidden;
            z-index: 1;
        }

        .wave {
            background: #5da9ba; /* Teal Blue */
            display: inline-block;
            height: 150%; /* Make them tall to cover bottom */
            width: 200%;
            position: absolute;
            border-radius: 40%; /* Creates the curve */
            bottom: -80%; /* Hide the bottom bulk */
            left: -50%;
            animation: drift 12s infinite linear;
            opacity: 0.7;
        }

        .wave:nth-child(2) {
            background: #4792a3; /* Darker Teal */
            bottom: -85%;
            animation: drift 18s infinite linear reverse;
            opacity: 0.6;
            z-index: 2;
        }

        .wave:nth-child(3) {
            background: #2a6f80; /* Deepest Teal */
            bottom: -90%;
            animation: drift 7s infinite linear;
            opacity: 0.8;
            z-index: 3;
        }

        /* --- THE BOAT (SVG) --- */
        .boat-container {
            position: absolute;
            bottom: 15%; /* Sit on top of waves roughly */
            left: 50%;
            width: 120px;
            z-index: 4;
            /* Combine animations: float up/down + rock left/right */
            animation: boat-float 4s ease-in-out infinite, boat-rock 3s ease-in-out infinite;
        }

        /* --- KEYFRAMES --- */
        @keyframes drift {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        @keyframes boat-float {
            0%, 100% { transform: translate(-50%, 0); }
            50% { transform: translate(-50%, -15px); }
        }

        @keyframes boat-rock {
            0%, 100% { transform: translate(-50%, 0) rotate(-3deg); }
            50% { transform: translate(-50%, 0) rotate(3deg); }
        }

        /* --- RESPONSIVE --- */
        @media (max-width: 600px) {
            h1 { font-size: 6rem; }
            h2 { font-size: 1.5rem; }
            p { padding: 0 20px; }
            .boat-container { width: 90px; bottom: 18%; }
        }
    </style>
</head>
<body>

    <div class="sun"></div>

    <div class="content">
        <h1>404</h1>
        <h2>Drifting Away...</h2>
        <p>Looks like you've sailed into uncharted waters. This page is currently lost at sea.</p>
        <a href="/" class="btn">Sail Home</a>
    </div>

    <!-- The Paper Boat SVG -->
    <div class="boat-container">
        <svg viewBox="0 0 100 60" fill="none" xmlns="http://www.w3.org/2000/svg">
            <!-- Back Sail -->
            <path d="M50 0 L50 40 L20 40 Z" fill="#e0e0e0"/>
            <!-- Front Sail -->
            <path d="M50 0 L80 40 L50 40 Z" fill="#ffffff"/>
            <!-- Hull Main -->
            <path d="M10 40 L25 60 L75 60 L90 40 Z" fill="#ff6b6b"/>
            <!-- Hull Shadow/Detail -->
            <path d="M25 60 L50 45 L75 60" fill="#cc4444"/>
        </svg>
    </div>

    <!-- The Waves -->
    <div class="ocean">
        <div class="wave"></div>
        <div class="wave"></div>
        <div class="wave"></div>
    </div>

</body>
</html>