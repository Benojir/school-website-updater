<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Page Abducted</title>
    <style>
        /* --- RESET & BASICS --- */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Courier New', Courier, monospace; /* Tech/Space font */
            background: radial-gradient(ellipse at bottom, #1b2735 0%, #090a0f 100%);
            height: 100vh;
            overflow: hidden; /* Prevent scrollbars */
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
            position: relative;
        }

        /* --- STARRY BACKGROUND (Pure CSS) --- */
        /* This creates stars using box-shadows to avoid hundreds of div elements */
        .stars {
            width: 1px;
            height: 1px;
            background: transparent;
            box-shadow: 1744px 122px #FFF , 134px 1321px #FFF , 92px 859px #FFF, 1668px 233px #FFF, 483px 1057px #FFF, 1070px 107px #FFF, 290px 421px #FFF, 1076px 1475px #FFF, 1690px 1424px #FFF;
            animation: twinkle 50s linear infinite;
            position: absolute;
            top: 0;
            left: 0;
        }
        
        .stars:after {
            content: " ";
            position: absolute;
            top: 2000px;
            width: 1px;
            height: 1px;
            background: transparent;
            box-shadow: 1744px 122px #FFF , 134px 1321px #FFF , 92px 859px #FFF, 1668px 233px #FFF, 483px 1057px #FFF, 1070px 107px #FFF, 290px 421px #FFF, 1076px 1475px #FFF, 1690px 1424px #FFF;
        }

        /* --- LAYOUT CONTAINER --- */
        .container {
            text-align: center;
            z-index: 10; /* Keep above stars */
            padding: 20px;
        }

        /* --- TYPOGRAPHY --- */
        h1 {
            font-size: 8rem;
            margin-bottom: 0;
            letter-spacing: -5px;
            background: -webkit-linear-gradient(#00ffcc, #007f66);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-shadow: 0px 0px 20px rgba(0, 255, 204, 0.5);
        }

        h2 {
            font-size: 2rem;
            margin-top: 0;
            margin-bottom: 20px;
            color: #ddd;
        }

        p {
            font-size: 1.1rem;
            color: #8892b0;
            margin-bottom: 40px;
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
        }

        /* --- THE UFO (SVG STYLING) --- */
        .ufo-container {
            width: 200px;
            height: auto;
            margin: 0 auto 20px auto;
            animation: float 4s ease-in-out infinite;
        }

        .beam {
            fill: rgba(0, 255, 204, 0.15);
            animation: beam-pulse 2s infinite alternate;
            transform-origin: center top;
        }
        
        /* --- BUTTON --- */
        .btn {
            display: inline-block;
            padding: 15px 30px;
            border: 2px solid #00ffcc;
            color: #00ffcc;
            text-decoration: none;
            font-weight: bold;
            font-size: 1rem;
            text-transform: uppercase;
            border-radius: 5px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .btn:hover {
            background: #00ffcc;
            color: #090a0f;
            box-shadow: 0 0 20px rgba(0, 255, 204, 0.6);
        }

        /* --- ANIMATIONS --- */
        @keyframes float {
            0% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(2deg); }
            100% { transform: translateY(0px) rotate(0deg); }
        }

        @keyframes beam-pulse {
            0% { opacity: 0.1; transform: scaleX(0.9); }
            100% { opacity: 0.4; transform: scaleX(1.1); }
        }

        @keyframes twinkle {
            from { transform: translateY(0px); }
            to { transform: translateY(-2000px); }
        }

        /* --- RESPONSIVENESS --- */
        @media (max-width: 600px) {
            h1 { font-size: 5rem; }
            h2 { font-size: 1.5rem; }
            .ufo-container { width: 150px; }
            .stars { display: none; /* Performance boost on mobile */ }
        }
    </style>
</head>
<body>

    <div class="stars"></div>

    <div class="container">
        <div class="ufo-container">
            <svg viewBox="0 0 200 150" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path class="beam" d="M100 110 L160 300 L40 300 Z" />
                
                <ellipse cx="100" cy="80" rx="80" ry="25" fill="#333" stroke="#00ffcc" stroke-width="3"/>
                <path d="M60 80 A 40 40 0 0 1 140 80" fill="#555" stroke="#00ffcc" stroke-width="2"/>
                <circle cx="50" cy="80" r="4" fill="#ff0055"/>
                <circle cx="100" cy="95" r="4" fill="#ff0055"/>
                <circle cx="150" cy="80" r="4" fill="#ff0055"/>
            </svg>
        </div>

        <h1>404</h1>
        <h2>Page Abducted</h2>
        <p>The page you are looking for has been beamed up to a galaxy far, far away. Or perhaps it never existed.</p>
        
        <a href="/" class="btn">Return to Earth</a>
    </div>

</body>
</html>