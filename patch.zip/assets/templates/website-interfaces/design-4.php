<?php

/** @var string $school_name
 * @var PDO $pdo
 * @var array $schoolSettings
 * @var array $websiteConfig
 * @var string $assets_version
 * @var string $logo_square
 * @var array $schoolInfo
 * @var string $theme_color
 */
include_once(__DIR__ . '/../../../includes/header-open.php');

// Fetch carousel images
$stmt = $pdo->prepare("SELECT * FROM carousel_images");
$stmt->execute();
$carousel_images = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo '<title>' . $seo_title . '</title>';

// Fetch all notices
$stmt = $pdo->prepare("SELECT * FROM notices ORDER BY notice_date DESC LIMIT 30");
$stmt->execute();
$notices = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch classes and class-wise fees
$stmt = $pdo->prepare("
SELECT 
classes.id, 
classes.class_name, 
class_wise_monthly_fees.amount AS monthly_fee,
class_wise_new_admission_fees.amount AS admission_fee
FROM 
classes 
INNER JOIN class_wise_monthly_fees ON class_wise_monthly_fees.class_id = classes.id
INNER JOIN class_wise_new_admission_fees ON class_wise_new_admission_fees.class_id = classes.id
ORDER BY classes.id ASC;
");
$stmt->execute();
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch teachers
// Only teachers the admin opted in are listed. Manually prioritised teachers come first
// (lowest number first); everyone without a priority follows in random order, as before.
$stmt = $pdo->prepare("
    SELECT * FROM teachers
    WHERE status = 'active' AND show_on_website = 1
    ORDER BY (display_priority IS NULL), display_priority ASC, RAND()
");
$stmt->execute();
$teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch gallery images
$stmt = $pdo->prepare("SELECT * FROM gallery ORDER BY event_date DESC");
$stmt->execute();
$galley_images = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch gallery videos
$stmt = $pdo->prepare("SELECT * FROM gallery_videos ORDER BY event_date DESC");
$stmt->execute();
$galley_videos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// আজ যাদের জন্মদিন সেই শিক্ষার্থীদের বিস্তারিত তথ্য (ক্লাস ও সেকশনসহ) আনা হচ্ছে
$stmt = $pdo->prepare("
    SELECT s.*, c.class_name, sec.section_name 
    FROM students s 
    JOIN classes c ON s.class_id = c.id
    LEFT JOIN sections sec ON s.section_id = sec.id
    WHERE MONTH(s.date_of_birth) = MONTH(CURRENT_DATE()) 
      AND DAY(s.date_of_birth) = DAY(CURRENT_DATE())
");

$stmt->execute();
$birthdayStudents = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- ============================================================
     FRONT PAGE — "Notebook & Frame" design system
     Signature idea: the hero never crops the school's photos.
     Every carousel image sits fully visible inside a mounted
     "frame", while a softly blurred version of the same photo
     fills the space around it — so 1920x1080 shots look
     intentional on a 24" monitor and on a phone in one hand.
     ============================================================ -->
<style>
    @import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600;9..144,700;9..144,800&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@500;600&display=swap');

    :root {
        --primary: <?= $theme_color ?>;
        --primary-ink: color-mix(in srgb, var(--primary) 78%, black);
        --primary-soft: color-mix(in srgb, var(--primary) 14%, white);
        --primary-softer: color-mix(in srgb, var(--primary) 7%, white);
        --ink: #171B21;
        --ink-soft: #5B6270;
        --paper: #FAF8F3;
        --paper-alt: #F1EDE1;
        --line: rgba(23, 27, 33, .10);
        --accent: #C89A4B;
        --accent-soft: color-mix(in srgb, var(--accent) 16%, white);
        --radius-lg: 28px;
        --radius-md: 18px;
        --radius-sm: 12px;
        --shadow-soft: 0 24px 60px -20px rgba(23, 27, 33, .28);
        --shadow-card: 0 14px 34px -16px rgba(23, 27, 33, .20);
        --font-display: 'Fraunces', Georgia, serif;
        --font-body: 'Plus Jakarta Sans', -apple-system, sans-serif;
        --font-mono: 'IBM Plex Mono', 'SFMono-Regular', monospace;
        --nav-h: 84px;
        --tab-h: 72px;
    }

    .main-container {
        font-family: var(--font-body);
        background: var(--paper);
        color: var(--ink);
        overflow-x: hidden;
        -webkit-font-smoothing: antialiased;
    }

    .main-container h1,
    .main-container h2,
    .main-container h3,
    .main-container h4 {
        font-family: var(--font-display);
        color: var(--ink);
        font-weight: 600;
        letter-spacing: -0.01em;
        margin: 0;
    }

    .main-container p {
        color: var(--ink-soft);
        line-height: 1.7;
    }

    .main-container a {
        text-decoration: none;
    }

    .main-container img {
        max-width: 100%;
    }

    @media (prefers-reduced-motion: reduce) {
        .main-container * {
            animation-duration: .01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: .01ms !important;
            scroll-behavior: auto !important;
        }
    }

    /* ---------- shared bits ---------- */
    .chip-label {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        font-family: var(--font-mono);
        font-size: .72rem;
        font-weight: 600;
        letter-spacing: .14em;
        text-transform: uppercase;
        color: var(--primary-ink);
        padding: 7px 14px 7px 10px;
        border: 1.5px dashed color-mix(in srgb, var(--primary) 45%, var(--line));
        border-radius: 999px;
        background: var(--primary-softer);
    }

    .chip-label::before {
        content: '';
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: var(--primary);
        flex-shrink: 0;
    }

    .section-head {
        max-width: 640px;
        margin: 0 auto 46px;
        text-align: center;
    }

    .section-head.text-start {
        margin-left: 0;
        text-align: left;
    }

    .section-head .chip-label {
        margin-bottom: 16px;
    }

    .section-head h2 {
        font-size: clamp(1.9rem, 3.4vw, 2.6rem);
        line-height: 1.15;
    }

    .section-head p {
        margin-top: 12px;
        font-size: 1.05rem;
    }

    .section-pad {
        padding: 88px 0;
    }

    .btn-cta {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        font-family: var(--font-body);
        font-weight: 700;
        font-size: .96rem;
        padding: 15px 28px;
        border-radius: 999px;
        border: 1.5px solid transparent;
        transition: transform .25s ease, box-shadow .25s ease, background .25s ease, color .25s ease;
        white-space: nowrap;
    }

    .btn-cta:hover {
        transform: translateY(-2px);
    }

    .btn-cta-primary {
        background: var(--primary);
        color: #fff;
        box-shadow: 0 12px 28px -10px color-mix(in srgb, var(--primary) 70%, transparent);
    }

    .btn-cta-primary:hover {
        color: #fff;
        box-shadow: 0 16px 34px -10px color-mix(in srgb, var(--primary) 80%, transparent);
    }

    .btn-cta-ghost {
        background: transparent;
        border-color: var(--line);
        color: var(--ink);
    }

    .btn-cta-ghost:hover {
        border-color: var(--primary);
        color: var(--primary-ink);
    }

    .btn-cta-light {
        background: #fff;
        color: var(--ink);
        box-shadow: var(--shadow-card);
    }

    /* Progressive enhancement: content is visible by default. Only when JS
       confirms it initialized (html.js-armed) do we hide-then-reveal on
       scroll — so a script error anywhere else can never blank the page. */
    .reveal {
        opacity: 1;
        transform: none;
    }

    html.js-armed .reveal {
        opacity: 0;
        transform: translateY(22px);
        transition: opacity .7s ease, transform .7s ease;
    }

    html.js-armed .reveal.in-view {
        opacity: 1;
        transform: none;
    }

    /* ---------- navigation ---------- */
    .site-nav {
        position: sticky;
        top: 0;
        z-index: 1000;
        height: var(--nav-h);
        display: flex;
        align-items: center;
        background: rgba(250, 248, 243, .78);
        backdrop-filter: blur(14px) saturate(1.4);
        -webkit-backdrop-filter: blur(14px) saturate(1.4);
        border-bottom: 1px solid var(--line);
        transition: box-shadow .3s ease, background .3s ease;
    }

    .site-nav.is-scrolled {
        box-shadow: 0 10px 30px -18px rgba(23, 27, 33, .35);
    }

    .nav-inner {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
    }

    .nav-logo img {
        height: 52px;
        width: auto;
        display: block;
    }

    .nav-menu {
        display: flex;
        align-items: center;
        gap: 4px;
        list-style: none;
        margin: 0;
        padding: 6px;
        background: #fff;
        border: 1px solid var(--line);
        border-radius: 999px;
    }

    .nav-menu>li {
        position: relative;
    }

    .nav-menu a.nav-link {
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: .88rem;
        font-weight: 600;
        color: var(--ink-soft);
        padding: 10px 16px;
        border-radius: 999px;
        transition: background .25s ease, color .25s ease;
    }

    .nav-menu a.nav-link:hover {
        background: var(--primary-softer);
        color: var(--primary-ink);
    }

    .nav-dropdown-panel {
        position: absolute;
        top: 100%;
        /* calc(100% + 10px) সরিয়ে এটি দিন */
        margin-top: 10px;
        /* মেনু নিচে নামানোর জন্য margin ব্যবহার করুন */
        left: 50%;
        transform: translateX(-50%);
        background: #fff;
        border: 1px solid var(--line);
        border-radius: var(--radius-sm);
        box-shadow: var(--shadow-soft);
        padding: 8px;
        min-width: 210px;
        opacity: 0;
        visibility: hidden;
        translate: 0 6px;
        transition: opacity .2s ease, translate .2s ease, visibility .2s;
        z-index: 20;
    }

    /* হোভার ধরে রাখার জন্য একটি অদৃশ্য ব্রিজ যুক্ত করুন */
    .nav-dropdown-panel::before {
        content: '';
        position: absolute;
        top: -10px;
        left: 0;
        width: 100%;
        height: 10px;
    }

    .nav-dropdown:hover .nav-dropdown-panel {
        opacity: 1;
        visibility: visible;
        translate: 0 0;
    }

    .nav-dropdown-panel a {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 10px 12px;
        border-radius: 10px;
        font-size: .87rem;
        font-weight: 600;
        color: var(--ink);
    }

    .nav-dropdown-panel a:hover {
        background: var(--primary-softer);
        color: var(--primary-ink);
    }

    .nav-actions {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .nav-toggle {
        display: none;
        width: 46px;
        height: 46px;
        border-radius: 50%;
        border: 1px solid var(--line);
        background: #fff;
        align-items: center;
        justify-content: center;
        font-size: 1.1rem;
        color: var(--ink);
    }

    .nav-overlay {
        position: fixed;
        inset: 0;
        z-index: 1100;
        background: var(--paper);
        display: flex;
        flex-direction: column;
        padding: 26px 26px 40px;
        transform: translateY(-100%);
        transition: transform .4s cubic-bezier(.4, 0, .2, 1);
        overflow-y: auto;
    }

    .nav-overlay.is-open {
        transform: translateY(0);
    }

    .nav-overlay-top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
    }

    .nav-overlay-links {
        list-style: none;
        margin: 0;
        padding: 0;
    }

    .nav-overlay-links li {
        border-bottom: 1px solid var(--line);
    }

    .nav-overlay-links a {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 18px 4px;
        font-family: var(--font-display);
        font-size: 1.35rem;
        color: var(--ink);
    }

    .nav-overlay-links a i {
        color: var(--primary);
        width: 26px;
        font-size: 1rem;
    }

    .nav-overlay-links .sub-link {
        padding-left: 30px;
        font-size: 1.05rem;
        font-family: var(--font-body);
        font-weight: 600;
        color: var(--ink-soft);
    }

    /* ---------- hero ---------- */
    .hero {
        padding: 56px 0 76px;
        position: relative;
    }

    .hero-grid {
        display: grid;
        grid-template-columns: 1.15fr 1fr;
        gap: 56px;
        align-items: center;
    }

    .hero-visual {
        position: relative;
        min-width: 0;
    }

    .hero-slider {
        border-radius: var(--radius-lg);
        overflow: hidden;
        box-shadow: var(--shadow-soft);
        aspect-ratio: 4 / 3.1;
        position: relative;
        background: var(--ink);
    }

    .hero-slide {
        position: relative;
        height: 100%;
    }

    .hero-slide-bg {
        position: absolute;
        inset: -6%;
        background-size: cover;
        background-position: center;
        filter: blur(38px) saturate(1.25) brightness(.72);
        transform: scale(1.1);
    }

    .hero-slide-bg::after {
        content: '';
        position: absolute;
        inset: 0;
        background: linear-gradient(180deg, color-mix(in srgb, var(--primary) 35%, transparent), rgba(23, 27, 33, .35));
    }

    .hero-slide-img {
        position: relative;
        z-index: 2;
        width: calc(100% - 52px);
        height: calc(100% - 52px);
        top: 26px;
        left: 26px;
        padding: 0;
        object-fit: cover;
        /* contain এর বদলে cover ব্যবহার করা হয়েছে */
        border-radius: var(--radius-md);
    }

    .hero-slide-caption {
        position: absolute;
        z-index: 3;
        left: 50%;
        bottom: 30px;
        transform: translateX(-50%);
        color: #fff;
        font-family: var(--font-mono);
        font-size: .75rem;
        letter-spacing: .05em;
        background: rgba(23, 27, 33, .45);
        backdrop-filter: blur(6px);
        padding: 8px 14px;
        border-radius: 999px;
        max-width: calc(100% - 44px);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .hero-slider .slick-dots {
        bottom: 3px;
    }

    /* Slick inserts its own .slick-list/.slick-track wrappers between
       .hero-slider and each .hero-slide, and neither gets a height by
       default — that breaks the height:100% chain the frame relies on
       for object-fit:contain, so the photo renders at its natural size
       instead of staying inside the frame. Force the chain through. */
    .hero-slider.slick-slider,
    .hero-slider .slick-list,
    .hero-slider .slick-track,
    .hero-slider .slick-slide {
        height: 100%;
    }

    .hero-slider .slick-slide>div {
        height: 100%;
    }

    .hero-slider .slick-dots li button:before {
        font-size: 9px;
        color: #fff;
        opacity: .55;
    }

    .hero-slider .slick-dots li.slick-active button:before {
        opacity: 1;
    }

    .hero-float {
        position: absolute;
        z-index: 5;
        background: #fff;
        border-radius: var(--radius-md);
        box-shadow: var(--shadow-card);
        padding: 14px 18px;
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .hero-float--admission {
        top: -22px;
        left: 26px;
        background: var(--ink);
        color: #fff;
        user-select: none;
        cursor: pointer;
    }

    /* ব্লিঙ্ক করানোর জন্য নতুন অ্যানিমেশন (যেকোনো জায়গায় রাখতে পারেন) */
    @keyframes blinkDot {
        0% {
            opacity: 1;
            transform: scale(1);
        }

        50% {
            opacity: 0.2;
            transform: scale(0.8);
        }

        100% {
            opacity: 1;
            transform: scale(1);
        }
    }

    /* আপনার আগের কোডের সাথে animation লাইনটি যুক্ত করা হলো */
    .hero-float--admission .chip-dot {
        width: 9px;
        height: 9px;
        border-radius: 50%;
        background: #6EE7A8;
        box-shadow: 0 0 0 4px rgba(110, 231, 168, .25);
        flex-shrink: 0;
        animation: blinkDot 1.2s infinite ease-in-out;
        /* এই লাইনটি আইকনটিকে ব্লিঙ্ক করাবে */
    }

    .hero-float--admission span {
        font-family: var(--font-mono);
        font-size: .72rem;
        letter-spacing: .08em;
        text-transform: uppercase;
        font-weight: 600;
    }

    .hero-float--stat {
        bottom: -20px;
        right: 24px;
    }

    .hero-float--stat .stat-num {
        font-family: var(--font-display);
        font-size: 1.6rem;
        font-weight: 700;
        color: var(--primary-ink);
        line-height: 1;
    }

    .hero-float--stat .stat-label {
        font-family: var(--font-mono);
        font-size: .66rem;
        letter-spacing: .06em;
        text-transform: uppercase;
        color: var(--ink-soft);
    }

    .hero-copy h1 {
        font-size: clamp(2.3rem, 4vw, 3.2rem);
        line-height: 1.08;
        margin: 16px 0 18px;
    }

    .hero-copy .hero-lead {
        font-size: 1.08rem;
        max-width: 460px;
        margin-bottom: 30px;
    }

    .hero-actions {
        display: flex;
        gap: 14px;
        flex-wrap: wrap;
        margin-bottom: 36px;
    }

    .hero-stats {
        display: flex;
        gap: 30px;
        padding-top: 26px;
        border-top: 1px solid var(--line);
    }

    .hero-stats .stat-num {
        font-family: var(--font-display);
        font-size: 1.5rem;
        font-weight: 700;
        color: var(--ink);
        display: block;
    }

    .hero-stats .stat-label {
        font-family: var(--font-mono);
        font-size: .66rem;
        letter-spacing: .06em;
        text-transform: uppercase;
        color: var(--ink-soft);
    }

    /* ---------- birthday ---------- */
    #birthday-section {
        padding: 10px 0 6px;
    }

    .bday-card {
        background: linear-gradient(120deg, var(--ink), color-mix(in srgb, var(--primary) 55%, var(--ink)));
        border-radius: var(--radius-lg);
        padding: 30px clamp(20px, 4vw, 46px);
        color: #fff;
        box-shadow: var(--shadow-soft);
    }

    .bday-photo {
        width: 92px;
        height: 92px;
        object-fit: cover;
        border: 3px solid rgba(255, 255, 255, .8);
    }

    .bday-emoji {
        top: -6px;
        right: -6px;
        font-size: 1.3rem;
    }

    .bday-card .bday-heading {
        color: #fff !important;
        font-size: 1.15rem;
        margin-bottom: 2px;
    }

    .bday-cake-emoji {
        font-size: 1rem;
    }

    .bday-card .bday-name {
        color: #fff !important;
        font-size: 1.5rem;
        margin-bottom: 10px;
    }

    .bday-badges {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }

    .bday-badge {
        font-family: var(--font-mono);
        font-size: .72rem;
        letter-spacing: .04em;
        background: rgba(255, 255, 255, .16);
        padding: 6px 12px;
        border-radius: 999px;
    }

    .bday-close {
        opacity: .7;
    }

    .birthday-slider .slick-dots {
        bottom: -20px;
    }

    .birthday-slider .slick-dots li button:before {
        color: var(--primary);
    }

    /* ---------- why-us bento ---------- */
    .why-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 22px;
    }

    .why-card {
        background: #fff;
        border: 1px solid var(--line);
        border-radius: var(--radius-md);
        padding: 34px 28px;
        transition: transform .35s ease, box-shadow .35s ease, border-color .35s ease;
        height: 100%;
    }

    .why-card:hover {
        transform: translateY(-6px);
        box-shadow: var(--shadow-card);
        border-color: color-mix(in srgb, var(--primary) 35%, var(--line));
    }

    .why-icon {
        width: 54px;
        height: 54px;
        border-radius: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.35rem;
        color: var(--primary-ink);
        background: var(--primary-softer);
        margin-bottom: 22px;
    }

    .why-card h4 {
        font-size: 1.18rem;
        margin-bottom: 10px;
    }

    .why-card p {
        font-size: .95rem;
        margin: 0;
    }

    /* ---------- notices ---------- */
    #notices {
        background: var(--paper-alt);
    }

    .notice-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 22px;
    }

    .notice-card {
        background: #fff;
        border-radius: var(--radius-md);
        padding: 26px 24px;
        border-left: 4px solid var(--primary);
        box-shadow: 0 8px 22px -14px rgba(23, 27, 33, .25);
        cursor: pointer;
        transition: transform .3s ease, box-shadow .3s ease;
        display: flex;
        flex-direction: column;
        height: 100%;
    }

    .notice-card:hover {
        transform: translateY(-5px);
        box-shadow: var(--shadow-card);
    }

    .notice-date-tag {
        font-family: var(--font-mono);
        font-size: .7rem;
        letter-spacing: .06em;
        text-transform: uppercase;
        color: var(--primary-ink);
        background: var(--primary-softer);
        display: inline-block;
        padding: 5px 11px;
        border-radius: 999px;
        margin-bottom: 14px;
        align-self: flex-start;
    }

    .notice-card h4 {
        font-size: 1.1rem;
        margin-bottom: 10px;
    }

    .notice-card p {
        font-size: .92rem;
        display: -webkit-box;
        line-clamp: 3;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
        flex-grow: 1;
    }

    .notice-card .read-more-btn {
        margin-top: 16px;
        font-weight: 700;
        font-size: .86rem;
        color: var(--primary-ink);
    }

    /* ---------- about ---------- */
    .about-grid {
        display: grid;
        grid-template-columns: .9fr 1.1fr;
        gap: 64px;
        align-items: center;
    }

    .about-frame {
        position: relative;
    }

    .about-frame::before {
        content: '';
        position: absolute;
        inset: 18px -18px -18px 18px;
        background: var(--primary-soft);
        border-radius: var(--radius-lg);
        z-index: 0;
    }

    .about-frame img {
        position: relative;
        z-index: 1;
        width: 100%;
        aspect-ratio: 4/3.3;
        object-fit: cover;
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-soft);
    }

    .about-copy p {
        font-size: 1.02rem;
    }

    /* ---------- academics / fees ---------- */
    #academics {
        background: var(--paper-alt);
    }

    .fee-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
        gap: 20px;
    }

    .fee-card {
        background: #fff;
        border-radius: var(--radius-md);
        padding: 26px 26px 22px;
        box-shadow: var(--shadow-card);
    }

    .fee-card h4 {
        font-size: 1.2rem;
        margin-bottom: 16px;
        padding-bottom: 14px;
        border-bottom: 1px solid var(--line);
    }

    .fee-row {
        display: flex;
        align-items: baseline;
        gap: 8px;
        font-family: var(--font-mono);
        font-size: .88rem;
        margin-bottom: 10px;
        color: var(--ink-soft);
    }

    .fee-row .fee-leader {
        flex: 1;
        border-bottom: 1.5px dotted var(--line);
        margin-bottom: 4px;
    }

    .fee-row .fee-value {
        font-weight: 600;
        color: var(--ink);
    }

    /* ---------- teachers ---------- */
    .teachers-carousel {
        margin: 0 -14px;
    }

    .teachers-carousel .slick-slide {
        padding: 6px 14px;
    }

    .teacher-card {
        text-align: center;
        background: #fff;
        padding: 34px 24px;
        border-radius: var(--radius-md);
        border: 1px solid var(--line);
        height: 100%;
    }

    .teacher-card img {
        width: 104px;
        height: 104px;
        border-radius: 50%;
        object-fit: cover;
        margin: 0 auto 20px;
        border: 4px solid #fff;
        box-shadow: 0 0 0 3px var(--primary);
    }

    .teacher-card h4 {
        font-size: 1.08rem;
        margin-bottom: 4px;
    }

    .teacher-card .qualification {
        font-family: var(--font-mono);
        font-size: .78rem;
        letter-spacing: .03em;
        color: var(--primary-ink);
        margin-bottom: 4px;
    }

    .teacher-card .position_in_school {
        font-size: .88rem;
        font-style: italic;
        color: var(--ink-soft);
    }

    /* বাটনগুলোকে একদম মাঝখানে (vertically middle) আনার জন্য */
    .teachers-carousel .slick-prev,
    .teachers-carousel .slick-next {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        width: 44px;
        height: 44px;
        background: #fff;
        border: 1px solid var(--line);
        border-radius: 50%;
        display: flex !important;
        align-items: center;
        justify-content: center;
        z-index: 10;
        box-shadow: var(--shadow-card);
        padding: 0;
        cursor: pointer;
    }

    /* পজিশন ঠিক রাখা */
    .teachers-carousel .slick-prev {
        left: -20px;
    }

    .teachers-carousel .slick-next {
        right: -20px;
    }

    /* বাটনের ভেতরে Arrow Icon যুক্ত করা (CSS-এর মাধ্যমে) */
    .teachers-carousel .slick-prev::before {
        content: '\f053' !important;
        /* FontAwesome Left Arrow */
        font-family: 'Font Awesome 5 Free' !important;
        font-weight: 900;
        color: var(--primary-ink);
        font-size: 1rem;
        opacity: 1;
    }

    .teachers-carousel .slick-next::before {
        content: '\f054' !important;
        /* FontAwesome Right Arrow */
        font-family: 'Font Awesome 5 Free' !important;
        font-weight: 900;
        color: var(--primary-ink);
        font-size: 1rem;
        opacity: 1;
    }

    /* আগের JS আইকন থাকলে সেটি হাইড করা (যাতে ডাবল না দেখায়) */
    .teachers-carousel .slick-prev i,
    .teachers-carousel .slick-next i {
        display: none !important;
    }

    /* ---------- gallery ---------- */
    #gallery {
        background: var(--paper);
    }

    .gallery-grid {
        display: grid;
        grid-template-columns: 1fr 1fr 1fr 1fr 1fr 1fr;
        gap: 14px;
    }

    .gallery-item {
        border-radius: var(--radius-sm);
        overflow: hidden;
        position: relative;
        display: block;
        aspect-ratio: 1 / 1;
    }

    .gallery-item img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform .5s ease;
    }

    .gallery-item::after {
        content: '\f00e';
        font-family: 'Font Awesome 5 Free';
        font-weight: 900;
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 1.3rem;
        background: rgba(23, 27, 33, 0);
        opacity: 0;
        transition: opacity .3s ease, background .3s ease;
    }

    .gallery-item:hover::after {
        opacity: 1;
        background: rgba(23, 27, 33, .38);
    }

    .gallery-item:hover img {
        transform: scale(1.08);
    }

    /* ---------- contact ---------- */
    .contact-panel {
        background: #fff;
        border-radius: var(--radius-lg);
        padding: clamp(26px, 4vw, 46px);
        box-shadow: var(--shadow-card);
        border: 1px solid var(--line);
    }

    .contact-form .form-floating>.form-control,
    .contact-form .form-floating>label {
        border-radius: var(--radius-sm);
    }

    .contact-form .form-control {
        border: 1.5px solid var(--line);
        background: var(--paper);
    }

    .contact-form .form-control:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 4px var(--primary-softer);
        background: #fff;
    }

    .contact-info-item {
        display: flex;
        gap: 16px;
        align-items: flex-start;
        margin-bottom: 22px;
    }

    .contact-info-item .icon-badge {
        width: 44px;
        height: 44px;
        border-radius: 12px;
        background: var(--primary-softer);
        color: var(--primary-ink);
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }

    .contact-info-item h6 {
        font-family: var(--font-mono);
        font-size: .7rem;
        letter-spacing: .06em;
        text-transform: uppercase;
        color: var(--ink-soft);
        margin-bottom: 3px;
    }

    .contact-info-item p,
    .contact-info-item a {
        margin: 0;
        color: var(--ink);
        font-weight: 600;
        font-size: .96rem;
    }

    .contact-map {
        border-radius: var(--radius-md);
        overflow: hidden;
        box-shadow: var(--shadow-card);
    }

    /* ---------- footer ---------- */
    .site-footer {
        background: var(--ink);
        color: rgba(255, 255, 255, .78);
        padding: 78px 0 26px;
    }

    .site-footer h5 {
        color: #fff;
        font-family: var(--font-display);
        font-size: 1.2rem;
        margin-bottom: 18px;
    }

    .site-footer a {
        color: rgba(255, 255, 255, .78);
        transition: color .2s ease;
    }

    .site-footer a:hover {
        color: var(--accent);
    }

    .site-footer .fw-logo {
        height: 46px;
        margin-bottom: 16px;
        filter: brightness(0) invert(1);
    }

    .footer-social-icons a {
        width: 40px;
        height: 40px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        background: rgba(255, 255, 255, .1);
        margin-right: 8px;
        transition: all .3s ease;
        /* ট্রানজিশন স্মুথ করার জন্য যুক্ত করা হলো */
    }

    /* নতুন হোভার স্টাইল (সাদা ব্যাকগ্রাউন্ড এবং ডার্ক আইকন) */
    .footer-social-icons a:hover {
        background: #ffffff;
        color: var(--ink);
        /* আইকনের রঙ ফুটারের ডার্ক কালারের সাথে ম্যাচ করবে */
        transform: translateY(-4px);
        /* হোভার করলে বাটনটি একটু উপরের দিকে উঠবে */
        box-shadow: 0 5px 15px rgba(255, 255, 255, 0.15);
        /* হালকা গ্লো ইফেক্ট */
    }

    .site-footer .list-unstyled a {
        font-size: .92rem;
    }

    .footer-tag-line {
        color: #afafaf !important;
    }

    /* ---------- floating whatsapp ---------- */
    .float-whatsapp {
        position: fixed;
        right: 22px;
        bottom: 22px;
        z-index: 900;
        width: 58px;
        height: 58px;
        border-radius: 50%;
        background: #25D366;
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        box-shadow: 0 14px 30px -10px rgba(37, 211, 102, .6);
        transition: transform .25s ease;
    }

    .float-whatsapp:hover {
        color: #fff;
        transform: scale(1.08);
    }

    /* ---------- mobile bottom tab bar ---------- */
    .mobile-tabbar {
        display: none;
    }

    /* ================= RESPONSIVE ================= */
    @media (max-width: 991px) {
        .nav-menu {
            display: none;
        }

        .nav-toggle {
            display: flex;
        }

        .hero-grid {
            grid-template-columns: 1fr;
            gap: 36px;
        }

        .hero-copy {
            text-align: center;
        }

        .hero-copy .hero-lead {
            margin-left: auto;
            margin-right: auto;
        }

        .hero-actions {
            justify-content: center;
        }

        .hero-stats {
            justify-content: center;
        }

        .about-grid {
            grid-template-columns: 1fr;
            gap: 40px;
        }

        .about-frame {
            max-width: 460px;
            margin: 0 auto;
        }

        .why-grid {
            grid-template-columns: 1fr 1fr;
        }

        .notice-grid {
            grid-template-columns: 1fr 1fr;
        }
    }

    @media (max-width: 767px) {
        :root {
            --nav-h: 70px;
        }

        .section-pad {
            padding: 62px 0;
        }

        .nav-logo img {
            height: 40px;
        }

        .hero {
            padding: 30px 0 40px;
        }

        .hero-slider {
            aspect-ratio: 4/3.6;
            border-radius: var(--radius-md);
        }

        .hero-slide-img {
            width: calc(100% - 28px);
            height: calc(100% - 28px);
            top: 14px;
            left: 14px;
            padding: 0;
            object-fit: cover;
            /* এখানেও cover নিশ্চিত করুন */
            border-radius: var(--radius-sm);
        }

        .hero-slide-caption {
            bottom: 35px;
            left: 50%;
            transform: translateX(-50%);
            max-width: calc(100% - 28px);
        }

        .hero-slider .slick-dots {
            bottom: 12px;
        }

        .hero-float {
            padding: 10px 14px;
        }

        .hero-float--admission {
            top: -14px;
            left: 14px;
        }

        .hero-float--stat {
            bottom: -16px;
            right: 14px;
        }

        .hero-float--stat .stat-num {
            font-size: 1.25rem;
        }

        .hero-copy {
            margin-top: 10px;
        }

        .hero-copy h1 {
            font-size: 2rem;
        }

        .hero-stats {
            gap: 22px;
        }

        .why-grid,
        .notice-grid {
            grid-template-columns: 1fr;
        }

        .gallery-grid {
            grid-template-columns: 1fr 1fr;
        }

        body {
            padding-bottom: var(--tab-h);
        }

        .mobile-tabbar {
            display: flex;
        }

        .float-whatsapp {
            bottom: calc(var(--tab-h) + 16px);
            width: 52px;
            height: 52px;
            font-size: 1.3rem;
        }
    }

    .mobile-tabbar {
        position: fixed;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 1000;
        height: var(--tab-h);
        background: rgba(255, 255, 255, .92);
        backdrop-filter: blur(14px);
        border-top: 1px solid var(--line);
        align-items: center;
        justify-content: space-around;
        padding: 0 6px;
    }

    .mobile-tabbar a {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 4px;
        color: var(--ink-soft);
        font-size: .64rem;
        font-weight: 700;
        font-family: var(--font-mono);
        letter-spacing: .01em;
        text-transform: uppercase;
    }

    .mobile-tabbar a i {
        font-size: 1.05rem;
    }

    .mobile-tabbar a.tab-cta {
        margin-top: -30px;
        width: 54px;
        height: 54px;
        border-radius: 50%;
        background: var(--primary);
        color: #fff;
        justify-content: center;
        box-shadow: 0 10px 22px -8px color-mix(in srgb, var(--primary) 70%, transparent);
    }

    .mobile-tabbar a.tab-cta i {
        font-size: 1.2rem;
    }

    .mobile-tabbar a.tab-cta span {
        display: none;
    }
</style>

<?php include_once(__DIR__ . '/../../../includes/header-close.php'); ?>

<div class="main-container">

    <!-- Navigation -->
    <header class="site-nav" id="siteNav">
        <div class="container nav-inner">
            <a href="#home" class="nav-logo">
                <img loading="lazy" src="<?= $logo_rectangle ?>" alt="School Logo" onerror="this.style.display='none'">
            </a>

            <ul class="nav-menu">
                <li><a href="#about" class="nav-link">About</a></li>
                <li><a href="#academics" class="nav-link">Academics</a></li>
                <li class="nav-dropdown">
                    <a href="#" class="nav-link">Teachers <i class="fas fa-chevron-down" style="font-size:.6rem"></i></a>
                    <div class="nav-dropdown-panel">
                        <?php if ($schoolSettings['show_teachers_on_front_page']): ?>
                            <a href="#teachers"><i class="fas fa-users"></i> All Teachers</a>
                        <?php endif; ?>
                        <?php if ($schoolSettings['teacher_application']): ?>
                            <a href="enquiries/form/teacher-application.php"><i class="fas fa-graduation-cap"></i> Apply as Teacher</a>
                        <?php endif; ?>
                    </div>
                </li>
                <li class="nav-dropdown">
                    <a href="#" class="nav-link">Gallery <i class="fas fa-chevron-down" style="font-size:.6rem"></i></a>
                    <div class="nav-dropdown-panel">
                        <a href="pages/photo-gallery.php"><i class="fas fa-camera-retro"></i> Photo Gallery</a>
                        <a href="pages/video-gallery.php"><i class="fas fa-video"></i> Video Gallery</a>
                    </div>
                </li>
                <li><a href="#notices" class="nav-link">Notices</a></li>
                <li><a href="#contact" class="nav-link">Contact</a></li>
            </ul>

            <div class="nav-actions">
                <?php if ($schoolSettings['admin_login_option_show']): ?>
                    <a href="management/" class="btn-cta btn-cta-primary d-none d-lg-inline-flex" style="padding:11px 20px;"><i class="fa-solid fa-lock"></i> Login</a>
                <?php endif; ?>
                <button class="nav-toggle" id="navToggle" aria-label="Open menu"><i class="fas fa-bars"></i></button>
            </div>
        </div>
    </header>

    <!-- Mobile full-screen menu -->
    <div class="nav-overlay" id="navOverlay">
        <div class="nav-overlay-top">
            <img src="<?= $logo_rectangle ?>" alt="School Logo" style="height:38px;" onerror="this.style.display='none'">
            <button class="nav-toggle" id="navClose" aria-label="Close menu"><i class="fas fa-times"></i></button>
        </div>
        <ul class="nav-overlay-links">
            <li><a href="#about"><i class="fas fa-school"></i> About</a></li>
            <li><a href="#academics"><i class="fas fa-book-open"></i> Academics</a></li>
            <?php if ($schoolSettings['show_teachers_on_front_page']): ?>
                <li><a href="#teachers"><i class="fas fa-chalkboard-teacher"></i> Teachers</a></li>
            <?php endif; ?>
            <?php if ($schoolSettings['teacher_application']): ?>
                <li><a class="sub-link" href="enquiries/form/teacher-application.php">Apply as Teacher</a></li>
            <?php endif; ?>
            <li><a href="pages/photo-gallery.php"><i class="fas fa-images"></i> Photo Gallery</a></li>
            <li><a class="sub-link" href="pages/video-gallery.php">Video Gallery</a></li>
            <li><a href="#notices"><i class="fas fa-bullhorn"></i> Notices</a></li>
            <li><a href="#contact"><i class="fas fa-paper-plane"></i> Contact</a></li>
            <?php if ($schoolSettings['admin_login_option_show']): ?>
                <li><a href="management/"><i class="fa-solid fa-lock"></i> Login</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <!-- ================= HERO ================= -->
    <section class="hero" id="home">
        <div class="container hero-grid">
            <div class="hero-visual reveal">
                <div class="hero-slider">
                    <?php if (!empty($carousel_images)): ?>
                        <?php foreach ($carousel_images as $image): ?>
                            <div class="hero-slide">
                                <div class="hero-slide-bg lazy-bg" data-bg="<?= $image['image_url'] ?>"></div>
                                <img
                                    class="hero-slide-img"
                                    loading="lazy"
                                    src="<?= $image['image_url'] ?>"
                                    alt="<?= safe_htmlspecialchars($image['caption'] ?? $schoolInfo['name']) ?>"
                                    data-fancybox="hero-slide-images"
                                    data-caption="<?= safe_htmlspecialchars($image['caption'] ?? $schoolInfo['name']) ?>">
                                <?php if (!empty($image['caption'])): ?>
                                    <span class="hero-slide-caption"><?= safe_htmlspecialchars($image['caption']) ?></span>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="hero-slide" style="background:var(--primary);display:flex;align-items:center;justify-content:center;">
                            <h3 style="color:#fff;">Welcome to <?= $schoolInfo['name'] ?></h3>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if ($schoolSettings['admission_open']): ?>
                    <div class="hero-float hero-float--admission">
                        <span class="chip-dot"></span>
                        <span>Admissions Open</span>
                    </div>
                <?php endif; ?>

                <?php if (!empty($teachers)): ?>
                    <div class="hero-float hero-float--stat">
                        <div class="stat-num"><?= count($teachers) ?>+</div>
                        <div class="stat-label">Teachers</div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="hero-copy reveal">
                <span class="chip-label">Welcome to <?= $schoolInfo['name'] ?></span>
                <h1>Where every learner<br>is known by name.</h1>
                <p class="hero-lead">A warm, well-equipped campus with dedicated teachers, modern classrooms and a curriculum built around every child's growth.</p>
                <div class="hero-actions">
                    <?php if ($schoolSettings['admission_open']): ?>
                        <a href="enquiries/form/admission-enquiry.php" class="btn-cta btn-cta-primary"><i class="fas fa-pen-nib"></i> Apply for Admission</a>
                    <?php endif; ?>
                    <a href="#contact" class="btn-cta btn-cta-ghost">Contact Us</a>
                </div>
                <div class="hero-stats">
                    <?php if (!empty($classes)): ?>
                        <div>
                            <span class="stat-num"><?= count($classes) ?></span>
                            <span class="stat-label">Classes</span>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($teachers)): ?>
                        <div>
                            <span class="stat-num"><?= count($teachers) ?>+</span>
                            <span class="stat-label">Teachers</span>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($galley_images)): ?>
                        <div>
                            <span class="stat-num"><?= count($galley_images) ?>+</span>
                            <span class="stat-label">Gallery Moments</span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- Birthday Section -->
    <?php if (!empty($birthdayStudents)): ?>
        <section id="birthday-section">
            <div class="container">
                <div class="birthday-slider">
                    <?php foreach ($birthdayStudents as $birthday_student): ?>
                        <div class="px-2">
                            <div class="bday-card position-relative overflow-hidden">
                                <button type="button" class="btn-close position-absolute bday-close" style="top:18px;right:18px;filter:invert(1);" onclick="document.getElementById('birthday-section').style.display='none'" aria-label="Close"></button>

                                <?php
                                $student_name = $birthday_student['name'] ?? $birthday_student['student_name'] ?? 'Student';
                                $first_letter = mb_substr($student_name, 0, 1, "UTF-8");
                                $student_image_db = $birthday_student['photo'] ?? $birthday_student['student_image'] ?? '';
                                $student_photo = (!empty($student_image_db)) ? 'uploads/students/' . $student_image_db : 'https://placehold.co/120x120/' . str_replace('#', '', $theme_color) . '/FFFFFF?text=' . urlencode($first_letter);
                                ?>

                                <div class="d-flex flex-column flex-md-row align-items-center text-center text-md-start position-relative" style="gap:22px;">
                                    <div class="position-relative flex-shrink-0">
                                        <img src="<?= $student_photo ?>" data-fancybox="Birthday Student" data-caption="<?= safe_htmlspecialchars($student_name) ?>" alt="<?= safe_htmlspecialchars($student_name) ?>" class="rounded-circle bday-photo" onerror="this.onerror=null;this.src='https://placehold.co/120x120/<?= str_replace('#', '', $theme_color) ?>/FFFFFF?text=<?= urlencode($first_letter) ?>';">
                                        <div class="position-absolute bday-emoji">🎉</div>
                                    </div>
                                    <div>
                                        <h3 class="bday-heading">Happy Birthday <span class="bday-cake-emoji">🎂</span></h3>
                                        <h4 class="bday-name"><?= safe_htmlspecialchars($student_name) ?></h4>
                                        <div class="bday-badges">
                                            <span class="bday-badge"><i class="fas fa-graduation-cap"></i> Class <?= safe_htmlspecialchars($birthday_student['class_name'] ?? 'N/A') ?></span>
                                            <?php if (!empty($birthday_student['section_name'])): ?>
                                                <span class="bday-badge"><i class="fas fa-layer-group"></i> Section <?= safe_htmlspecialchars($birthday_student['section_name']) ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <!-- ================= WHY US ================= -->
    <section class="section-pad">
        <div class="container">
            <div class="section-head reveal">
                <span class="chip-label">Why families choose us</span>
                <h2>A campus built around how children actually learn</h2>
            </div>
            <div class="why-grid reveal">
                <div class="why-card">
                    <div class="why-icon"><i class="fas fa-graduation-cap"></i></div>
                    <h4>Quality Education</h4>
                    <p>Modern teaching methods and well-equipped classrooms shape a curriculum that keeps pace with every learner.</p>
                </div>
                <div class="why-card">
                    <div class="why-icon"><i class="fas fa-user-friends"></i></div>
                    <h4>Experienced Teachers</h4>
                    <p>A qualified, dedicated faculty stays closely invested in each student's progress and development.</p>
                </div>
                <div class="why-card">
                    <div class="why-icon"><i class="fas fa-shield-alt"></i></div>
                    <h4>Safe & Fun Place</h4>
                    <p>A safe, stimulating environment with modern facilities where children are genuinely happy to be.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ================= NOTICES ================= -->
    <section id="notices" class="section-pad">
        <div class="container">
            <div class="section-head reveal">
                <span class="chip-label">Notice Board</span>
                <h2>What's happening this week</h2>
            </div>
            <div class="notice-grid reveal">
                <?php
                $i = 0;
                foreach ($notices as $notice) {
                    if ($i == 3) break;
                    $i++;
                ?>
                    <div class="notice-card read-more-btn"
                        data-notice-title="<?= safe_htmlspecialchars($notice['title']) ?>"
                        data-notice-content="<?= safe_htmlspecialchars($notice['content']) ?>"
                        data-notice-date="<?= (new DateTime($notice['notice_date']))->format('d F Y'); ?>">
                        <span class="notice-date-tag"><i class="far fa-calendar-alt me-1"></i> <?= (new DateTime($notice['notice_date']))->format('d M Y'); ?></span>
                        <h4><?= safe_htmlspecialchars($notice['title']) ?></h4>
                        <p><?= safe_htmlspecialchars($notice['content']) ?></p>
                        <span class="read-more-btn">Read More <i class="fas fa-arrow-right"></i></span>
                    </div>
                <?php } ?>
            </div>
            <div class="text-center mt-5">
                <a href="pages/notices.php" class="btn-cta btn-cta-ghost">View All Notices</a>
            </div>
        </div>
    </section>

    <!-- ================= ABOUT ================= -->
    <section id="about" class="section-pad">
        <div class="container">
            <div class="about-grid">
                <div class="about-frame reveal">
                    <?php if (!empty($carousel_images)): ?>
                        <img
                            src="<?= $carousel_images[random_int(0, count($carousel_images) - 1)]['image_url'] ?>"
                            alt="<?= safe_htmlspecialchars($schoolInfo['name']) ?>"
                            data-fancybox="galley-carousel"
                            loading="lazy" />
                    <?php elseif (!empty($galley_images)): ?>
                        <img
                            src="<?= $galley_images[0]['thumbnail_url'] ?>"
                            alt="<?= safe_htmlspecialchars($schoolInfo['name']) ?>"
                            loading="lazy" />
                    <?php else: ?>
                        <div style="aspect-ratio:4/3.3;border-radius:var(--radius-lg);background:var(--primary-soft);display:flex;align-items:center;justify-content:center;position:relative;z-index:1;box-shadow:var(--shadow-soft);">
                            <i class="fas fa-school" style="font-size:3rem;color:var(--primary-ink);"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="about-copy reveal">
                    <div class="section-head text-start" style="margin:0;">
                        <span class="chip-label">About Our School</span>
                        <h2><?= safe_htmlspecialchars($schoolInfo['name']) ?></h2>
                    </div>
                    <p><?= nl2br($schoolInfo['description']); ?></p>
                </div>
            </div>
        </div>
    </section>

    <!-- ================= ACADEMICS / FEES ================= -->
    <section id="academics" class="section-pad">
        <div class="container">
            <div class="section-head reveal">
                <span class="chip-label">Academics</span>
                <h2>Fee Structure</h2>
                <p>A clear, upfront look at monthly and admission fees for every class.</p>
            </div>
            <div class="fee-grid reveal">
                <?php foreach ($classes as $class) { ?>
                    <div class="fee-card">
                        <h4><?= $class['class_name'] ?></h4>
                        <div class="fee-row">
                            <span>Monthly Fee</span>
                            <span class="fee-leader"></span>
                            <span class="fee-value">₹<?= number_format($class['monthly_fee']) ?></span>
                        </div>
                        <div class="fee-row">
                            <span>Admission Fee</span>
                            <span class="fee-leader"></span>
                            <span class="fee-value">₹<?= number_format($class['admission_fee']) ?></span>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </section>

    <!-- ================= TEACHERS ================= -->
    <section id="teachers" class="section-pad">
        <div class="container">
            <div class="section-head reveal">
                <span class="chip-label">Our Faculty</span>
                <h2>Meet the teachers</h2>
            </div>
            <div class="teachers-carousel reveal">
                <?php
                $i = 0;
                foreach ($teachers as $index => $teacher) {
                    if ($i % 6 === 0) {
                        echo '<div><div class="row g-4">';
                    }
                ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="teacher-card">
                            <?php
                            if ($teacher['teacher_image'] == null || $teacher['teacher_image'] == '' || $teacher['teacher_image'] == 'default_teacher_dp.jpg') {
                                $teacher_dp_url = 'https://placehold.co/120x120/' . str_replace('#', '', $theme_color) . '/FFFFFF?text=' . substr($teacher['name'], 0, 1);
                            } else {
                                $teacher_dp_url = 'uploads/teachers/' . $teacher['teacher_image'];
                            }
                            ?>
                            <img loading="lazy" src="<?= $teacher_dp_url ?>" alt="<?= $teacher['name'] ?>" data-fancybox="teacher-image-gallery" data-caption="<?= $teacher['name'] ?>" onerror="this.onerror=null;this.src='https://placehold.co/120x120/<?= str_replace('#', '', $theme_color) ?>/FFFFFF?text=<?= substr($teacher['name'], 0, 1) ?>';">
                            <h4><?= $teacher['name'] ?></h4>
                            <p class="qualification"><?= $teacher['qualification'] ?></p>
                            <p class="position_in_school"><?= $teacher['position_in_school'] ?></p>
                        </div>
                    </div>
                <?php
                    $i++;
                    if ($i % 6 === 0 || $i === count($teachers)) {
                        echo '</div></div>';
                    }
                }
                ?>
            </div>
        </div>
    </section>

    <!-- ================= GALLERY ================= -->
    <section id="gallery" class="section-pad">
        <div class="container">
            <div class="section-head reveal">
                <span class="chip-label">Moments</span>
                <h2>School Gallery</h2>
            </div>
            <div class="gallery-grid reveal">
                <?php
                $i = 1;
                foreach ($galley_images as $image) {
                ?>
                    <a href="<?= $image['photo_url'] ?>" data-fancybox="gallery" data-caption="<?= $image['caption'] ?>" class="gallery-item">
                        <img src="<?= $image['thumbnail_url'] ?>" alt="<?= $image['caption'] ?>" loading="lazy" />
                    </a>
                <?php
                    if ($i == 6) break;
                    $i++;
                } ?>
            </div>
            <div class="text-center mt-5">
                <a href="pages/photo-gallery.php" class="btn-cta btn-cta-primary">View More Photos</a>
            </div>
        </div>
    </section>

    <!-- ================= CONTACT ================= -->
    <section id="contact" class="section-pad">
        <div class="container">
            <div class="section-head reveal">
                <span class="chip-label">Get in Touch</span>
                <h2>Contact Us</h2>
            </div>
            <div class="row g-4 reveal">
                <div class="col-lg-6">
                    <div class="contact-panel">
                        <h4 class="mb-4">Send us a Message</h4>
                        <form class="contact-form" action="mailto:<?= $schoolInfo['email'] ?>" method="post" enctype="text/plain">
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="cf_name" name="name" placeholder="Your Name" required>
                                <label for="cf_name">Your Name</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="tel" class="form-control" id="cf_phone" name="phone-number" placeholder="Your Phone" required>
                                <label for="cf_phone">Your Phone</label>
                            </div>
                            <div class="form-floating mb-3">
                                <textarea class="form-control" id="cf_message" style="height:130px" name="message" placeholder="Your Message" required></textarea>
                                <label for="cf_message">Your Message</label>
                            </div>
                            <button type="submit" class="btn-cta btn-cta-primary w-100">Send Message</button>
                        </form>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="contact-panel h-100">
                        <h4 class="mb-4">Find Us Here</h4>
                        <div class="contact-info-item">
                            <span class="icon-badge"><i class="fas fa-map-marker-alt"></i></span>
                            <div>
                                <h6>Address</h6>
                                <p><?= $schoolInfo['address']; ?></p>
                            </div>
                        </div>
                        <div class="contact-info-item">
                            <span class="icon-badge"><i class="fas fa-phone-alt"></i></span>
                            <div>
                                <h6>Phone</h6>
                                <p><?= $schoolInfo['phone']; ?> / <?= $schoolInfo['alternate_phone']; ?></p>
                            </div>
                        </div>
                        <div class="contact-info-item">
                            <span class="icon-badge"><i class="fas fa-envelope"></i></span>
                            <div>
                                <h6>Email</h6>
                                <p><?= $schoolInfo['email']; ?></p>
                            </div>
                        </div>
                        <div class="contact-map">
                            <iframe src="<?= $schoolInfo['google_map_embed_link']; ?>" width="100%" height="230" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Notice Modal -->
    <div class="modal fade" id="noticeModal" tabindex="-1" aria-labelledby="noticeModalLabel" aria-hidden="true">
        <!-- এখানে modal-dialog-scrollable যুক্ত করা হয়েছে -->
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content" style="border-radius: var(--radius-md); border:none;">
                <div class="modal-body p-4">
                    <div class="notice-modal-content">
                        <!-- Content will be loaded here dynamically -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-5 mb-lg-0 text-center text-lg-start">
                    <!-- লোগো এবং স্কুলের নাম -->
                    <div class="d-flex align-items-center justify-content-center justify-content-lg-start mb-3">
                        <img src="<?= $logo_square ?>" alt="School Logo" class="me-3" style="height: 48px; border-radius: 8px; background: #fff; padding: 3px;" onerror="this.style.display='none'">
                        <h5 class="mb-0"><?= $schoolInfo['name']; ?></h5>
                    </div>
                    <p class="footer-tag-line">Building a bright future, one child at a time.</p>
                    <div class="footer-social-icons mt-4">
                        <a href="<?= $schoolInfo['facebook'] ?>"><i class="fab fa-facebook-f"></i></a>
                        <a href="<?= $schoolInfo['whatsapp'] ?>"><i class="fab fa-whatsapp"></i></a>
                        <a href="<?= $schoolInfo['instagram'] ?>"><i class="fab fa-instagram"></i></a>
                        <a href="<?= $schoolInfo['youtube'] ?>"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>

                <div class="col-lg-2 text-center text-lg-start mb-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="pages/about-us.php"><i class="fas fa-angle-right me-2" style="font-size: 0.8rem;"></i> About Us</a></li>
                        <li class="mb-2"><a href="pages/contact-us.php"><i class="fas fa-angle-right me-2" style="font-size: 0.8rem;"></i> Contact Us</a></li>
                        <li class="mb-2"><a href="pages/privacy-and-policy.php"><i class="fas fa-angle-right me-2" style="font-size: 0.8rem;"></i> Privacy & Policy</a></li>
                        <li class="mb-2"><a href="pages/terms-and-conditions.php"><i class="fas fa-angle-right me-2" style="font-size: 0.8rem;"></i> Terms & Conditions</a></li>
                        <li class="mb-2"><a href="pages/refund-and-cancellation.php"><i class="fas fa-angle-right me-2" style="font-size: 0.8rem;"></i> Refund Policy</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 text-center text-lg-start mb-4">
                    <h5>Contact</h5>
                    <ul class="list-unstyled">
                        <li class="mb-3 d-flex align-items-start justify-content-center justify-content-lg-start">
                            <i class="fas fa-phone-alt me-2 mt-1 text-white-50"></i>
                            <div>
                                <a href="tel:<?= $schoolInfo['phone']; ?>"><?= $schoolInfo['phone']; ?></a><br>
                                <a href="tel:<?= $schoolInfo['alternate_phone']; ?>"><?= $schoolInfo['alternate_phone']; ?></a>
                            </div>
                        </li>
                        <li class="mb-2 d-flex align-items-center justify-content-center justify-content-lg-start">
                            <i class="fas fa-envelope me-2 text-white-50"></i>
                            <a href="mailto:<?= $schoolInfo['email']; ?>"><?= $schoolInfo['email']; ?></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 text-center text-lg-start">
                    <a target="_blank" href="<?= BASE_URL ?>/apps/" class="btn-cta bg-success text-white"><i class="fa-brands fa-google-play me-2"></i> Download Apps</a>
                </div>
            </div>

            <div class="text-center mt-5 pt-4 border-top border-secondary">
                <p>&copy; <?php echo date("Y"); ?> <?= $schoolInfo['name']; ?> | Developed with <i class="fas fa-heart text-danger"></i> by <a href="https://schoolsongi.com" class="text-warning">School Songi</a></p>
            </div>
        </div>
    </footer>

    <!-- Floating WhatsApp -->
    <?php if (!empty($schoolInfo['whatsapp'])): ?>
        <a href="<?= $schoolInfo['whatsapp'] ?>" target="_blank" class="float-whatsapp" aria-label="Chat on WhatsApp"><i class="fab fa-whatsapp"></i></a>
    <?php endif; ?>

    <!-- Mobile bottom tab bar -->
    <nav class="mobile-tabbar">
        <a href="#home"><i class="fas fa-house"></i><span>Home</span></a>
        <a href="#notices"><i class="fas fa-bullhorn"></i><span>Notices</span></a>
        <?php if ($schoolSettings['admission_open']): ?>
            <a href="enquiries/form/admission-enquiry.php" class="tab-cta"><i class="fas fa-pen-nib"></i><span>Apply</span></a>
        <?php else: ?>
            <a href="#contact" class="tab-cta"><i class="fas fa-paper-plane"></i><span>Contact</span></a>
        <?php endif; ?>
        <a href="#gallery"><i class="fas fa-images"></i><span>Gallery</span></a>
        <a href="<?= BASE_URL ?>/apps/"><i class="fa-solid fa-mobile-alt"></i><span>Apps</span></a>
    </nav>
</div>

<!-- Custom JS -->
<script>
    $(document).ready(function() {
        // Redirect to apply admission page when click
        $('.hero-float--admission').click(() => {
            window.location.href = '<?= BASE_URL ?>/enquiries/form/admission-enquiry.php';
        });

        // Progressive enhancement flag for the scroll-reveal effect.
        // If anything below throws, this line has already run, so
        // .reveal content still shows (see the CSS default above).
        document.documentElement.classList.add('js-armed');

        // Notice card -> modal
        $('.notice-card.read-more-btn').on('click', function(e) {
            e.preventDefault();

            var title = $(this).data('notice-title');
            var content = $(this).data('notice-content');
            var date = $(this).data('notice-date');

            $('.notice-modal-content').html(`
                <div class="notice-modal-header mb-3" style="border-bottom:2px solid var(--primary);padding-bottom:15px;">
                    <span class="badge bg-primary">${date}</span>
                    <h4 class="mt-2">${title}</h4>
                </div>
                <div class="notice-modal-body" style="padding:15px 0;line-height:1.6;">
                    <p>${content.replace(/\n/g, '<br>')}</p>
                </div>
            `);

            var noticeModal = new bootstrap.Modal(document.getElementById('noticeModal'));
            noticeModal.show();
        });

        // Navbar shadow on scroll
        $(window).on('scroll', function() {
            $('#siteNav').toggleClass('is-scrolled', $(window).scrollTop() > 10);
        });

        // Mobile full-screen nav
        $('#navToggle').on('click', function() {
            $('#navOverlay').addClass('is-open');
            $('body').css('overflow', 'hidden');
        });
        $('#navClose').on('click', closeMobileNav);
        $('.nav-overlay-links a').on('click', closeMobileNav);

        function closeMobileNav() {
            $('#navOverlay').removeClass('is-open');
            $('body').css('overflow', '');
        }

        // Smooth scrolling for in-page anchors
        $('a[href*="#"]').on('click', function(e) {
            var href = $(this).attr('href');
            if (href === '#' || href.indexOf('#') !== 0) {
                return;
            }
            var target = $(href);
            if (target.length) {
                e.preventDefault();
                closeMobileNav();
                $('html, body').animate({
                    scrollTop: target.offset().top - (window.innerWidth < 992 ? 60 : 84)
                }, 500, 'linear');
            }
        });

        // Each carousel/observer is wrapped independently so that if one
        // fails (missing plugin, unexpected markup, etc.) it can't take
        // the rest of the page's interactivity down with it.
        function safely(fn) {
            try {
                fn();
            } catch (err) {
                console.error(err);
            }
        }

        // Hero Slider
        safely(() => $('.hero-slider').slick({
            dots: true,
            infinite: true,
            speed: 500,
            fade: true,
            cssEase: 'linear',
            autoplay: true,
            autoplaySpeed: 5000,
            arrows: false
        }));

        // Birthday Slider
        safely(() => $('.birthday-slider').slick({
            dots: true,
            infinite: true,
            speed: 600,
            fade: true,
            cssEase: 'linear',
            autoplay: true,
            autoplaySpeed: 3500,
            arrows: false
        }));

        // Teachers Carousel
        safely(() => $('.teachers-carousel').slick({
            dots: true,
            infinite: true,
            speed: 300,
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: true,
            prevArrow: '<button type="button" class="slick-prev"><i class="fas fa-chevron-left"></i></button>',
            nextArrow: '<button type="button" class="slick-next"><i class="fas fa-chevron-right"></i></button>',
            responsive: [{
                breakpoint: 992,
                settings: {
                    arrows: false
                }
            }]
        }));

        // Lazy load hero backgrounds
        safely(() => {
            $('.lazy-bg').each(function() {
                const $el = $(this);
                const observer = new IntersectionObserver(function(entries, observer) {
                    entries.forEach(function(entry) {
                        if (entry.isIntersecting) {
                            $el.css('background-image', `url('${$el.data('bg')}')`);
                            observer.unobserve(entry.target);
                        }
                    });
                });
                observer.observe(this);
            });
        });

        // Scroll reveal
        safely(() => {
            const revealObserver = new IntersectionObserver(function(entries, obs) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('in-view');
                        obs.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.15
            });
            document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));
        });

        // Teacher show/hide
        if (<?= (int) ($schoolSettings['show_teachers_on_front_page'] ?? 1) ?> === 0) {
            $('#teachers').addClass('d-none');
        }

        // Academics show/hide
        if (<?= (int) ($schoolSettings['hide_fees_structure_from_website'] ?? 0) ?> === 1) {
            $('#academics').addClass('d-none');
        }
    });
</script>

<?php include_once(__DIR__ . '/../../../includes/body-close.php'); ?>