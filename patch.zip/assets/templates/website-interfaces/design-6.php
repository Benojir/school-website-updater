<?php

/** @var string $school_name
 * @var PDO $pdo
 * @var array $schoolSettings
 * @var array $websiteConfig
 * @var string $assets_version
 * @var string $logo_square
 * @var array $schoolInfo
 * @var string $theme_color
 */
include_once(__DIR__ . '/../../../includes/header-open.php');

// Fetch carousel images
$stmt = $pdo->prepare("SELECT * FROM carousel_images");
$stmt->execute();
$carousel_images = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo '<title>' . $seo_title . '</title>';

// Fetch all notices
$stmt = $pdo->prepare("SELECT * FROM notices ORDER BY notice_date DESC LIMIT 30");
$stmt->execute();
$notices = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch classes and class-wise fees
$stmt = $pdo->prepare("
SELECT 
classes.id, 
classes.class_name, 
class_wise_monthly_fees.amount AS monthly_fee,
class_wise_new_admission_fees.amount AS admission_fee
FROM 
classes 
INNER JOIN class_wise_monthly_fees ON class_wise_monthly_fees.class_id = classes.id
INNER JOIN class_wise_new_admission_fees ON class_wise_new_admission_fees.class_id = classes.id
ORDER BY classes.id ASC;
");
$stmt->execute();
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch teachers
// Only teachers the admin opted in are listed. Manually prioritised teachers come first
// (lowest number first); everyone without a priority follows in random order, as before.
$stmt = $pdo->prepare("
    SELECT * FROM teachers
    WHERE status = 'active' AND show_on_website = 1
    ORDER BY (display_priority IS NULL), display_priority ASC, RAND()
");
$stmt->execute();
$teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch gallery images
$stmt = $pdo->prepare("SELECT * FROM gallery ORDER BY event_date DESC");
$stmt->execute();
$galley_images = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch gallery videos
$stmt = $pdo->prepare("SELECT * FROM gallery_videos ORDER BY event_date DESC");
$stmt->execute();
$galley_videos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// আজ যাদের জন্মদিন সেই শিক্ষার্থীদের বিস্তারিত তথ্য (ক্লাস ও সেকশনসহ) আনা হচ্ছে
$stmt = $pdo->prepare("
    SELECT s.*, c.class_name, sec.section_name 
    FROM students s 
    JOIN classes c ON s.class_id = c.id
    LEFT JOIN sections sec ON s.section_id = sec.id
    WHERE MONTH(s.date_of_birth) = MONTH(CURRENT_DATE()) 
      AND DAY(s.date_of_birth) = DAY(CURRENT_DATE())
");

$stmt->execute();
$birthdayStudents = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- ============================================================
     FRONT PAGE — "Material You" design system (Material Design 3)
     Signature ideas:
       · Roboto type scale + M3 shape tokens (cards 16px, XL 28px)
       · Elevation shadows instead of borders wherever possible
       · Tonal color roles derived live from $theme_color
       · State-layer hovers + real ripple on every touch target
       · Mobile: left navigation drawer + M3 bottom navigation bar
       · Hero keeps the "blurred backdrop frame" so photos never crop
     ============================================================ -->
<style>
    @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap');

    :root {
        /* ---- M3 color roles, all derived from the school's theme color ---- */
        --md-primary: <?= $theme_color ?>;
        --md-on-primary: #FFFFFF;
        --md-primary-container: color-mix(in srgb, var(--md-primary) 14%, #FFFFFF);
        --md-on-primary-container: color-mix(in srgb, var(--md-primary) 45%, #1B1B1F);
        --md-secondary-container: color-mix(in srgb, var(--md-primary) 8%, #F2EFF4);
        --md-on-secondary-container: color-mix(in srgb, var(--md-primary) 30%, #1D1B20);
        --md-tertiary-container: #FFD8E4;
        --md-on-tertiary-container: #31111D;
        --md-surface: #FEFBFF;
        --md-surface-dim: #DED8E1;
        --md-surface-container-lowest: #FFFFFF;
        --md-surface-container-low: #F7F2FA;
        --md-surface-container: #F3EDF7;
        --md-surface-container-high: #ECE6F0;
        --md-on-surface: #1D1B20;
        --md-on-surface-variant: #49454F;
        --md-outline: #79747E;
        --md-outline-variant: #CAC4D0;
        --md-inverse-surface: #322F35;
        --md-inverse-on-surface: #F5EFF7;
        --md-inverse-primary: color-mix(in srgb, var(--md-primary) 55%, #FFFFFF);
        --md-scrim: rgba(0, 0, 0, .35);

        /* ---- M3 elevation ---- */
        --md-e1: 0 1px 2px rgba(0, 0, 0, .3), 0 1px 3px 1px rgba(0, 0, 0, .15);
        --md-e2: 0 1px 2px rgba(0, 0, 0, .3), 0 2px 6px 2px rgba(0, 0, 0, .15);
        --md-e3: 0 4px 8px 3px rgba(0, 0, 0, .15), 0 1px 3px rgba(0, 0, 0, .3);

        /* ---- M3 shape scale ---- */
        --md-r-sm: 8px;
        --md-r-md: 12px;
        --md-r-lg: 16px;
        --md-r-xl: 28px;
        --md-r-full: 999px;

        --md-font: 'Roboto', -apple-system, 'Segoe UI', sans-serif;
        --nav-h: 64px;
        --tab-h: 80px;

        /* M3 emphasized motion curve */
        --md-ease: cubic-bezier(.2, 0, 0, 1);
    }

    .main-container {
        font-family: var(--md-font);
        background: var(--md-surface);
        color: var(--md-on-surface);
        overflow-x: hidden;
        -webkit-font-smoothing: antialiased;
    }

    .main-container h1,
    .main-container h2,
    .main-container h3,
    .main-container h4 {
        font-family: var(--md-font);
        color: var(--md-on-surface);
        font-weight: 500;
        letter-spacing: 0;
        margin: 0;
    }

    .main-container p {
        color: var(--md-on-surface-variant);
        line-height: 1.6;
    }

    .main-container a {
        text-decoration: none;
    }

    .main-container img {
        max-width: 100%;
    }

    @media (prefers-reduced-motion: reduce) {
        .main-container * {
            animation-duration: .01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: .01ms !important;
            scroll-behavior: auto !important;
        }
    }

    /* ================= RIPPLE ================= */
    .md-ripple-host {
        position: relative;
        overflow: hidden;
        -webkit-tap-highlight-color: transparent;
    }

    .md-ripple {
        position: absolute;
        border-radius: 50%;
        background: currentColor;
        opacity: .18;
        transform: scale(0);
        pointer-events: none;
        animation: mdRipple .55s var(--md-ease) forwards;
    }

    @keyframes mdRipple {
        to {
            transform: scale(1);
            opacity: 0;
        }
    }

    /* ================= BUTTONS (M3) ================= */
    .md-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        height: 44px;
        padding: 0 24px;
        border-radius: var(--md-r-full);
        border: none;
        font-family: var(--md-font);
        font-size: .875rem;
        font-weight: 500;
        letter-spacing: .01em;
        cursor: pointer;
        white-space: nowrap;
        transition: box-shadow .2s var(--md-ease), background .2s var(--md-ease), color .2s var(--md-ease), transform .15s var(--md-ease);
    }

    .md-btn:active {
        transform: scale(.97);
    }

    /* Filled */
    .md-btn-filled {
        background: var(--md-primary);
        color: var(--md-on-primary);
    }

    .md-btn-filled:hover {
        color: var(--md-on-primary);
        box-shadow: var(--md-e1);
        background: color-mix(in srgb, var(--md-primary) 92%, #FFFFFF);
    }

    /* Tonal */
    .md-btn-tonal {
        background: var(--md-secondary-container);
        color: var(--md-on-secondary-container);
    }

    .md-btn-tonal:hover {
        color: var(--md-on-secondary-container);
        box-shadow: var(--md-e1);
        background: color-mix(in srgb, var(--md-secondary-container) 92%, var(--md-on-secondary-container));
    }

    /* Outlined */
    .md-btn-outlined {
        background: transparent;
        color: var(--md-primary);
        border: 1px solid var(--md-outline-variant);
    }

    .md-btn-outlined:hover {
        color: var(--md-primary);
        background: color-mix(in srgb, var(--md-primary) 8%, transparent);
        border-color: var(--md-outline);
    }

    /* ================= CHIPS (M3 assist chip) ================= */
    .md-chip {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        height: 32px;
        padding: 0 16px;
        border-radius: var(--md-r-sm);
        border: 1px solid var(--md-outline-variant);
        background: var(--md-surface-container-low);
        color: var(--md-primary);
        font-size: .8rem;
        font-weight: 500;
        letter-spacing: .02em;
    }

    .md-chip i {
        font-size: .8rem;
    }

    /* ================= SECTION HEADERS ================= */
    .section-head {
        max-width: 640px;
        margin: 0 auto 48px;
        text-align: center;
    }

    .section-head.text-start {
        margin-left: 0;
        text-align: left;
    }

    .section-head .md-chip {
        margin-bottom: 18px;
    }

    .section-head h2 {
        font-size: clamp(1.75rem, 3.2vw, 2.25rem);
        line-height: 1.2;
        font-weight: 500;
    }

    .section-head p {
        margin-top: 12px;
        font-size: 1rem;
    }

    .section-pad {
        padding: 80px 0;
    }

    /* Scroll reveal — safe by default, armed only when JS runs */
    .reveal {
        opacity: 1;
        transform: none;
    }

    html.js-armed .reveal {
        opacity: 0;
        transform: translateY(24px);
        transition: opacity .5s var(--md-ease), transform .5s var(--md-ease);
    }

    html.js-armed .reveal.in-view {
        opacity: 1;
        transform: none;
    }

    /* ================= TOP APP BAR ================= */
    .site-nav {
        position: sticky;
        top: 0;
        z-index: 1000;
        height: var(--nav-h);
        display: flex;
        align-items: center;
        background: color-mix(in srgb, var(--md-surface) 88%, transparent);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        transition: box-shadow .25s var(--md-ease), background .25s var(--md-ease);
    }

    .site-nav.is-scrolled {
        background: color-mix(in srgb, var(--md-surface-container) 92%, transparent);
        box-shadow: var(--md-e2);
    }

    .nav-inner {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
    }

    .nav-logo img {
        height: 44px;
        width: auto;
        display: block;
    }

    .nav-menu {
        display: flex;
        align-items: center;
        gap: 2px;
        list-style: none;
        margin: 0;
        padding: 0;
    }

    .nav-menu>li {
        position: relative;
    }

    /* M3 text-button style links */
    .nav-menu a.nav-link {
        display: flex;
        align-items: center;
        gap: 5px;
        font-size: .875rem;
        font-weight: 500;
        color: var(--md-on-surface-variant);
        padding: 10px 14px;
        border-radius: var(--md-r-full);
        transition: background .2s var(--md-ease), color .2s var(--md-ease);
    }

    .nav-menu a.nav-link:hover {
        background: color-mix(in srgb, var(--md-on-surface) 6%, transparent);
        color: var(--md-on-surface);
    }

    .nav-menu a.nav-link.active {
        background: var(--md-secondary-container);
        color: var(--md-on-secondary-container);
    }

    /* M3 menu (dropdown) */
    .nav-dropdown-panel {
        position: absolute;
        top: 100%;
        margin-top: 6px;
        left: 50%;
        transform: translateX(-50%);
        background: var(--md-surface-container);
        border: none;
        border-radius: var(--md-r-md);
        box-shadow: var(--md-e2);
        padding: 8px 0;
        min-width: 220px;
        opacity: 0;
        visibility: hidden;
        translate: 0 -4px;
        transition: opacity .15s var(--md-ease), translate .15s var(--md-ease), visibility .15s;
        z-index: 20;
    }

    .nav-dropdown-panel::before {
        content: '';
        position: absolute;
        top: -8px;
        left: 0;
        width: 100%;
        height: 8px;
    }

    .nav-dropdown:hover .nav-dropdown-panel {
        opacity: 1;
        visibility: visible;
        translate: 0 0;
    }

    .nav-dropdown-panel a {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px 16px;
        font-size: .875rem;
        font-weight: 500;
        color: var(--md-on-surface);
        transition: background .15s var(--md-ease);
    }

    .nav-dropdown-panel a i {
        width: 18px;
        text-align: center;
        color: var(--md-on-surface-variant);
        font-size: .85rem;
    }

    .nav-dropdown-panel a:hover {
        background: color-mix(in srgb, var(--md-on-surface) 8%, transparent);
    }

    .nav-actions {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    /* M3 icon button */
    .nav-toggle {
        display: none;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        border: none;
        background: transparent;
        align-items: center;
        justify-content: center;
        font-size: 1.05rem;
        color: var(--md-on-surface-variant);
        cursor: pointer;
        transition: background .2s var(--md-ease);
    }

    .nav-toggle:hover {
        background: color-mix(in srgb, var(--md-on-surface-variant) 10%, transparent);
    }

    /* ================= NAVIGATION DRAWER (mobile, M3 modal drawer) ================= */
    .nav-scrim {
        position: fixed;
        inset: 0;
        z-index: 1150;
        background: var(--md-scrim);
        opacity: 0;
        visibility: hidden;
        transition: opacity .25s var(--md-ease), visibility .25s;
    }

    .nav-scrim.is-open {
        opacity: 1;
        visibility: visible;
    }

    .nav-overlay {
        position: fixed;
        top: 0;
        left: 0;
        bottom: 0;
        width: min(320px, 85vw);
        z-index: 1200;
        background: var(--md-surface-container-low);
        border-radius: 0 var(--md-r-lg) var(--md-r-lg) 0;
        display: flex;
        flex-direction: column;
        padding: 16px 12px 24px;
        transform: translateX(-105%);
        transition: transform .3s var(--md-ease);
        overflow-y: auto;
        box-shadow: var(--md-e3);
    }

    .nav-overlay.is-open {
        transform: translateX(0);
    }

    .nav-overlay-top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 6px 12px 16px;
    }

    .nav-overlay-links {
        list-style: none;
        margin: 0;
        padding: 0;
    }

    /* M3 drawer item — pill shaped, active gets secondary container */
    .nav-overlay-links a {
        display: flex;
        align-items: center;
        gap: 14px;
        height: 52px;
        padding: 0 20px;
        margin: 2px 0;
        border-radius: var(--md-r-full);
        font-size: .9rem;
        font-weight: 500;
        color: var(--md-on-surface-variant);
        transition: background .2s var(--md-ease);
    }

    .nav-overlay-links a:hover {
        background: color-mix(in srgb, var(--md-on-surface) 6%, transparent);
    }

    .nav-overlay-links a.active {
        background: var(--md-secondary-container);
        color: var(--md-on-secondary-container);
    }

    .nav-overlay-links a i {
        width: 24px;
        text-align: center;
        font-size: .95rem;
    }

    .nav-overlay-links .sub-link {
        padding-left: 58px;
        font-size: .85rem;
        height: 44px;
    }

    /* ================= HERO ================= */
    .hero {
        padding: 48px 0 72px;
        background:
            radial-gradient(900px 420px at 85% -10%, color-mix(in srgb, var(--md-primary) 10%, transparent), transparent 60%),
            radial-gradient(700px 380px at -10% 20%, color-mix(in srgb, var(--md-primary) 7%, transparent), transparent 60%),
            var(--md-surface);
    }

    .hero-grid {
        display: grid;
        grid-template-columns: 1.15fr 1fr;
        gap: 56px;
        align-items: center;
    }

    .hero-visual {
        position: relative;
        min-width: 0;
    }

    /* Elevated XL-shape card holding the frame */
    .hero-slider {
        border-radius: var(--md-r-xl);
        overflow: hidden;
        box-shadow: var(--md-e3);
        aspect-ratio: 4 / 3.1;
        position: relative;
        background: var(--md-surface-dim);
    }

    .hero-slide {
        position: relative;
        height: 100%;
    }

    .hero-slide-bg {
        position: absolute;
        inset: -6%;
        background-size: cover;
        background-position: center;
        filter: blur(38px) saturate(1.2) brightness(.75);
        transform: scale(1.1);
    }

    .hero-slide-bg::after {
        content: '';
        position: absolute;
        inset: 0;
        background: linear-gradient(180deg, color-mix(in srgb, var(--md-primary) 25%, transparent), rgba(0, 0, 0, .25));
    }

    .hero-slide-img {
        position: relative;
        z-index: 2;
        width: calc(100% - 48px);
        height: calc(100% - 48px);
        top: 24px;
        left: 24px;
        object-fit: cover;
        border-radius: var(--md-r-lg);
        box-shadow: var(--md-e2);
        cursor: zoom-in;
    }

    /* M3 surface-tinted caption chip */
    .hero-slide-caption {
        position: absolute;
        z-index: 3;
        left: 50%;
        bottom: 30px;
        transform: translateX(-50%);
        color: var(--md-on-surface);
        font-size: .78rem;
        font-weight: 500;
        background: color-mix(in srgb, var(--md-surface-container-low) 85%, transparent);
        backdrop-filter: blur(8px);
        padding: 8px 16px;
        border-radius: var(--md-r-full);
        box-shadow: var(--md-e1);
        max-width: calc(100% - 44px);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .hero-slider .slick-dots {
        bottom: 0px;
    }

    .hero-slider.slick-slider,
    .hero-slider .slick-list,
    .hero-slider .slick-track,
    .hero-slider .slick-slide {
        height: 100%;
    }

    .hero-slider .slick-slide>div {
        height: 100%;
    }

    .hero-slider .slick-dots li button:before {
        font-size: 8px;
        color: #fff;
        opacity: .5;
    }

    .hero-slider .slick-dots li.slick-active button:before {
        opacity: 1;
    }

    /* Floating chips over the hero card */
    .hero-float {
        position: absolute;
        z-index: 5;
        background: var(--md-surface-container-lowest);
        border-radius: var(--md-r-lg);
        box-shadow: var(--md-e2);
        padding: 12px 18px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .hero-float--admission {
        top: -18px;
        left: 24px;
        background: var(--md-primary);
        color: var(--md-on-primary);
        user-select: none;
        cursor: pointer;
    }

    @keyframes blinkDot {

        0%,
        100% {
            opacity: 1;
            transform: scale(1);
        }

        50% {
            opacity: .25;
            transform: scale(.8);
        }
    }

    .hero-float--admission .chip-dot {
        width: 9px;
        height: 9px;
        border-radius: 50%;
        background: #A8F5C6;
        flex-shrink: 0;
        animation: blinkDot 1.2s infinite ease-in-out;
    }

    .hero-float--admission span {
        font-size: .78rem;
        letter-spacing: .04em;
        font-weight: 500;
    }

    .hero-float--stat {
        bottom: -18px;
        right: 24px;
        flex-direction: column;
        align-items: flex-start;
        gap: 2px;
    }

    .hero-float--stat .stat-num {
        font-size: 1.4rem;
        font-weight: 700;
        color: var(--md-primary);
        line-height: 1;
    }

    .hero-float--stat .stat-label {
        font-size: .68rem;
        letter-spacing: .04em;
        text-transform: uppercase;
        color: var(--md-on-surface-variant);
    }

    /* M3 type scale: display-ish headline */
    .hero-copy h1 {
        font-size: clamp(2.1rem, 3.8vw, 3rem);
        line-height: 1.15;
        font-weight: 400;
        margin: 18px 0 18px;
    }

    .hero-copy h1 strong {
        font-weight: 700;
        color: var(--md-primary);
    }

    .hero-copy .hero-lead {
        font-size: 1rem;
        max-width: 460px;
        margin-bottom: 28px;
    }

    .hero-actions {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
        margin-bottom: 34px;
    }

    /* Stats as a divided M3 list */
    .hero-stats {
        display: flex;
        gap: 0;
        border-top: 1px solid var(--md-outline-variant);
        padding-top: 20px;
    }

    .hero-stats>div {
        padding: 0 26px;
        border-left: 1px solid var(--md-outline-variant);
    }

    .hero-stats>div:first-child {
        padding-left: 0;
        border-left: none;
    }

    .hero-stats .stat-num {
        font-size: 1.45rem;
        font-weight: 700;
        color: var(--md-on-surface);
        display: block;
    }

    .hero-stats .stat-label {
        font-size: .68rem;
        letter-spacing: .05em;
        text-transform: uppercase;
        color: var(--md-on-surface-variant);
    }

    /* ================= BIRTHDAY (filled tonal banner) ================= */
    #birthday-section {
        padding: 12px 0 8px;
    }

    .bday-card {
        background: var(--md-primary-container);
        border-radius: var(--md-r-xl);
        padding: 28px clamp(20px, 4vw, 44px);
        color: var(--md-on-primary-container);
        box-shadow: var(--md-e1);
    }

    .bday-photo {
        width: 88px;
        height: 88px;
        object-fit: cover;
        border: 3px solid var(--md-surface-container-lowest);
        box-shadow: var(--md-e1);
    }

    .bday-emoji {
        top: -6px;
        right: -6px;
        font-size: 1.25rem;
    }

    .bday-card .bday-heading {
        color: var(--md-on-primary-container) !important;
        font-size: 1rem;
        font-weight: 500;
        margin-bottom: 2px;
    }

    .bday-cake-emoji {
        font-size: 1rem;
    }

    .bday-card .bday-name {
        color: var(--md-on-primary-container) !important;
        font-size: 1.5rem;
        font-weight: 700;
        margin-bottom: 12px;
    }

    .bday-badges {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }

    /* Assist chips on the birthday card */
    .bday-badge {
        font-size: .75rem;
        font-weight: 500;
        letter-spacing: .02em;
        color: var(--md-on-primary-container);
        background: color-mix(in srgb, var(--md-on-primary-container) 8%, transparent);
        border: 1px solid color-mix(in srgb, var(--md-on-primary-container) 25%, transparent);
        padding: 6px 14px;
        border-radius: var(--md-r-sm);
    }

    .bday-close {
        opacity: .6;
    }

    .birthday-slider .slick-dots {
        bottom: -16px;
    }

    .birthday-slider .slick-dots li button:before {
        color: var(--md-primary);
    }

    /* ================= WHY US (elevated cards) ================= */
    .why-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
    }

    .why-card {
        background: var(--md-surface-container-low);
        border: none;
        border-radius: var(--md-r-lg);
        padding: 28px 24px;
        height: 100%;
        transition: box-shadow .25s var(--md-ease), transform .25s var(--md-ease), background .25s var(--md-ease);
    }

    .why-card:hover {
        background: var(--md-surface-container-lowest);
        box-shadow: var(--md-e2);
        transform: translateY(-3px);
    }

    /* Tonal circle icon */
    .why-icon {
        width: 48px;
        height: 48px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.15rem;
        color: var(--md-on-primary-container);
        background: var(--md-primary-container);
        margin-bottom: 20px;
    }

    .why-card h4 {
        font-size: 1.05rem;
        font-weight: 500;
        margin-bottom: 8px;
    }

    .why-card p {
        font-size: .9rem;
        margin: 0;
    }

    /* ================= NOTICES (outlined cards) ================= */
    #notices {
        background: var(--md-surface-container-low);
    }

    .notice-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
    }

    .notice-card {
        background: var(--md-surface-container-lowest);
        border: 1px solid var(--md-outline-variant);
        border-radius: var(--md-r-md);
        padding: 20px 20px 12px;
        cursor: pointer;
        transition: box-shadow .2s var(--md-ease), border-color .2s var(--md-ease);
        display: flex;
        flex-direction: column;
        height: 100%;
    }

    .notice-card:hover {
        box-shadow: var(--md-e2);
        border-color: transparent;
    }

    /* Date as an M3 input-chip */
    .notice-date-tag {
        font-size: .72rem;
        font-weight: 500;
        letter-spacing: .02em;
        color: var(--md-on-secondary-container);
        background: var(--md-secondary-container);
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        border-radius: var(--md-r-sm);
        margin-bottom: 14px;
        align-self: flex-start;
    }

    .notice-card h4 {
        font-size: 1.05rem;
        font-weight: 500;
        margin-bottom: 8px;
    }

    .notice-card p {
        font-size: .875rem;
        display: -webkit-box;
        line-clamp: 3;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
        flex-grow: 1;
        margin-bottom: 0;
    }

    /* M3 text button, right aligned like a card action */
    .notice-card .read-more-btn {
        margin-top: 8px;
        align-self: flex-end;
        font-weight: 500;
        font-size: .85rem;
        color: var(--md-primary);
        padding: 8px 12px;
        border-radius: var(--md-r-full);
        transition: background .2s var(--md-ease);
    }

    .notice-card .read-more-btn:hover {
        background: color-mix(in srgb, var(--md-primary) 8%, transparent);
    }

    /* ================= ABOUT ================= */
    .about-grid {
        display: grid;
        grid-template-columns: .9fr 1.1fr;
        gap: 64px;
        align-items: center;
    }

    .about-frame {
        position: relative;
    }

    .about-frame::before {
        content: '';
        position: absolute;
        inset: 16px -16px -16px 16px;
        background: var(--md-secondary-container);
        border-radius: var(--md-r-xl);
        z-index: 0;
    }

    .about-frame img {
        position: relative;
        z-index: 1;
        width: 100%;
        aspect-ratio: 4/3.3;
        object-fit: cover;
        border-radius: var(--md-r-xl);
        box-shadow: var(--md-e2);
        cursor: zoom-in;
    }

    .about-copy p {
        font-size: .98rem;
    }

    /* ================= ACADEMICS / FEES ================= */
    #academics {
        background: var(--md-surface-container-low);
    }

    .fee-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
        gap: 16px;
    }

    .fee-card {
        background: var(--md-surface-container-lowest);
        border-radius: var(--md-r-lg);
        padding: 8px 0;
        box-shadow: var(--md-e1);
        transition: box-shadow .2s var(--md-ease);
    }

    .fee-card:hover {
        box-shadow: var(--md-e2);
    }

    .fee-card h4 {
        font-size: 1.05rem;
        font-weight: 500;
        padding: 14px 20px;
        margin: 0;
    }

    /* M3 list items with divider */
    .fee-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        font-size: .85rem;
        padding: 12px 20px;
        color: var(--md-on-surface-variant);
        border-top: 1px solid var(--md-outline-variant);
    }

    .fee-row .fee-value {
        font-weight: 700;
        font-size: .95rem;
        color: var(--md-primary);
    }

    /* ================= TEACHERS ================= */
    .teachers-carousel {
        margin: 0 -14px;
    }

    .teachers-carousel .slick-slide {
        padding: 8px 14px;
    }

    .teacher-card {
        text-align: center;
        background: var(--md-surface-container-lowest);
        padding: 32px 24px;
        border-radius: var(--md-r-lg);
        border: 1px solid var(--md-outline-variant);
        height: 100%;
        transition: box-shadow .2s var(--md-ease), border-color .2s var(--md-ease);
    }

    .teacher-card:hover {
        box-shadow: var(--md-e2);
        border-color: transparent;
    }

    .teacher-card img {
        width: 96px;
        height: 96px;
        border-radius: 50%;
        object-fit: cover;
        margin: 0 auto 18px;
        border: 3px solid var(--md-primary-container);
        cursor: zoom-in;
    }

    .teacher-card h4 {
        font-size: 1rem;
        font-weight: 500;
        margin-bottom: 4px;
    }

    .teacher-card .qualification {
        font-size: .78rem;
        font-weight: 500;
        letter-spacing: .02em;
        color: var(--md-primary);
        margin-bottom: 4px;
    }

    .teacher-card .position_in_school {
        font-size: .85rem;
        color: var(--md-on-surface-variant);
    }

    .teachers-carousel .slick-prev,
    .teachers-carousel .slick-next {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        width: 40px;
        height: 40px;
        background: var(--md-surface-container-lowest);
        border: none;
        border-radius: 50%;
        display: flex !important;
        align-items: center;
        justify-content: center;
        z-index: 10;
        box-shadow: var(--md-e2);
        padding: 0;
        cursor: pointer;
    }

    .teachers-carousel .slick-prev {
        left: -18px;
    }

    .teachers-carousel .slick-next {
        right: -18px;
    }

    .teachers-carousel .slick-prev::before {
        content: '\f053' !important;
        font-family: 'Font Awesome 5 Free' !important;
        font-weight: 900;
        color: var(--md-primary);
        font-size: .9rem;
        opacity: 1;
    }

    .teachers-carousel .slick-next::before {
        content: '\f054' !important;
        font-family: 'Font Awesome 5 Free' !important;
        font-weight: 900;
        color: var(--md-primary);
        font-size: .9rem;
        opacity: 1;
    }

    .teachers-carousel .slick-prev i,
    .teachers-carousel .slick-next i {
        display: none !important;
    }

    .teachers-carousel .slick-dots li button:before {
        color: var(--md-primary);
    }

    /* ================= GALLERY ================= */
    .gallery-grid {
        display: grid;
        grid-template-columns: repeat(6, 1fr);
        gap: 12px;
    }

    .gallery-item {
        border-radius: var(--md-r-md);
        overflow: hidden;
        position: relative;
        display: block;
        aspect-ratio: 1 / 1;
        box-shadow: var(--md-e1);
        transition: box-shadow .25s var(--md-ease);
    }

    .gallery-item:hover {
        box-shadow: var(--md-e3);
    }

    .gallery-item img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform .45s var(--md-ease);
    }

    /* M3 scrim on hover */
    .gallery-item::after {
        content: '\f00e';
        font-family: 'Font Awesome 5 Free';
        font-weight: 900;
        position: absolute;
        inset: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 1.2rem;
        background: color-mix(in srgb, var(--md-primary) 35%, rgba(0, 0, 0, .2));
        opacity: 0;
        transition: opacity .25s var(--md-ease);
    }

    .gallery-item:hover::after {
        opacity: 1;
    }

    .gallery-item:hover img {
        transform: scale(1.06);
    }

    /* ================= CONTACT ================= */
    .contact-panel {
        background: var(--md-surface-container-lowest);
        border-radius: var(--md-r-xl);
        padding: clamp(24px, 4vw, 40px);
        box-shadow: var(--md-e1);
        border: none;
        height: 100%;
    }

    .contact-panel h4 {
        font-size: 1.25rem;
        font-weight: 500;
    }

    /* M3 outlined text fields (built on Bootstrap floating labels) */
    .contact-form .form-floating>.form-control {
        border-radius: var(--md-r-md);
        border: 1px solid var(--md-outline);
        background: transparent;
        color: var(--md-on-surface);
        font-family: var(--md-font);
    }

    .contact-form .form-floating>label {
        color: var(--md-on-surface-variant);
        font-size: .9rem;
    }

    .contact-form .form-floating>.form-control:focus {
        border-color: var(--md-primary);
        border-width: 2px;
        box-shadow: none;
        background: transparent;
    }

    .contact-form .form-floating>.form-control:focus~label {
        color: var(--md-primary);
    }

    .contact-info-item {
        display: flex;
        gap: 16px;
        align-items: flex-start;
        margin-bottom: 20px;
    }

    .contact-info-item .icon-badge {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background: var(--md-primary-container);
        color: var(--md-on-primary-container);
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        font-size: .9rem;
    }

    .contact-info-item h6 {
        font-size: .7rem;
        font-weight: 500;
        letter-spacing: .06em;
        text-transform: uppercase;
        color: var(--md-on-surface-variant);
        margin-bottom: 2px;
    }

    .contact-info-item p,
    .contact-info-item a {
        margin: 0;
        color: var(--md-on-surface);
        font-weight: 500;
        font-size: .92rem;
    }

    .contact-map {
        border-radius: var(--md-r-lg);
        overflow: hidden;
        box-shadow: var(--md-e1);
    }

    /* ================= FOOTER (inverse surface) ================= */
    .site-footer {
        background: var(--md-inverse-surface);
        color: var(--md-inverse-on-surface);
        padding: 64px 0 24px;
        border-radius: var(--md-r-xl) var(--md-r-xl) 0 0;
    }

    .site-footer h5 {
        color: var(--md-inverse-on-surface);
        font-family: var(--md-font);
        font-weight: 500;
        font-size: 1.05rem;
        margin-bottom: 16px;
    }

    .site-footer a {
        color: color-mix(in srgb, var(--md-inverse-on-surface) 80%, transparent);
        transition: color .2s var(--md-ease);
    }

    .site-footer a:hover {
        color: var(--md-inverse-primary);
    }

    .footer-social-icons a {
        width: 40px;
        height: 40px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        background: rgba(255, 255, 255, .08);
        margin-right: 8px;
        transition: all .2s var(--md-ease);
    }

    .footer-social-icons a:hover {
        background: var(--md-inverse-primary);
        color: var(--md-inverse-surface);
        box-shadow: var(--md-e1);
    }

    .site-footer .list-unstyled a {
        font-size: .88rem;
    }

    .footer-tag-line {
        color: color-mix(in srgb, var(--md-inverse-on-surface) 65%, transparent) !important;
    }

    .site-footer .border-secondary {
        border-color: rgba(255, 255, 255, .12) !important;
    }

    /* ================= FLOATING ACTION BUTTON (WhatsApp) ================= */
    .float-whatsapp {
        position: fixed;
        right: 20px;
        bottom: 20px;
        z-index: 900;
        width: 56px;
        height: 56px;
        border-radius: var(--md-r-lg);
        /* M3 FAB shape */
        background: #25D366;
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        box-shadow: var(--md-e3);
        transition: box-shadow .2s var(--md-ease), transform .15s var(--md-ease);
    }

    .float-whatsapp:hover {
        color: #fff;
        box-shadow: 0 6px 10px 4px rgba(0, 0, 0, .15), 0 2px 3px rgba(0, 0, 0, .3);
    }

    .float-whatsapp:active {
        transform: scale(.94);
    }

    /* ================= M3 BOTTOM NAVIGATION BAR (mobile) ================= */
    .mobile-tabbar {
        display: none;
        position: fixed;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 1000;
        height: var(--tab-h);
        background: var(--md-surface-container);
        box-shadow: var(--md-e2);
        align-items: stretch;
        justify-content: space-around;
        padding: 8px 8px 12px;
    }

    .mobile-tabbar a {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 4px;
        flex: 1;
        color: var(--md-on-surface-variant);
        font-size: .68rem;
        font-weight: 500;
        border-radius: var(--md-r-md);
    }

    /* Icon pill indicator — the signature M3 nav-bar look */
    .mobile-tabbar a .tab-icon-pill {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 56px;
        height: 32px;
        border-radius: var(--md-r-full);
        transition: background .25s var(--md-ease);
        font-size: 1.05rem;
    }

    .mobile-tabbar a.active {
        color: var(--md-on-surface);
    }

    .mobile-tabbar a.active .tab-icon-pill {
        background: var(--md-secondary-container);
        color: var(--md-on-secondary-container);
    }

    /* ================= RESPONSIVE ================= */
    @media (max-width: 991px) {
        .nav-menu {
            display: none;
        }

        .nav-toggle {
            display: flex;
        }

        .hero-grid {
            grid-template-columns: 1fr;
            gap: 36px;
        }

        .hero-copy {
            text-align: center;
        }

        .hero-copy .hero-lead {
            margin-left: auto;
            margin-right: auto;
        }

        .hero-actions {
            justify-content: center;
        }

        .hero-stats {
            justify-content: center;
        }

        .hero-stats>div:first-child {
            padding-left: 26px;
            border-left: 1px solid var(--md-outline-variant);
        }

        .about-grid {
            grid-template-columns: 1fr;
            gap: 44px;
        }

        .about-frame {
            max-width: 460px;
            margin: 0 auto;
        }

        .why-grid {
            grid-template-columns: 1fr 1fr;
        }

        .notice-grid {
            grid-template-columns: 1fr 1fr;
        }

        .gallery-grid {
            grid-template-columns: repeat(3, 1fr);
        }
    }

    @media (max-width: 767px) {
        :root {
            --nav-h: 56px;
        }

        .section-pad {
            padding: 56px 0;
        }

        .nav-logo img {
            height: 36px;
        }

        .hero {
            padding: 24px 0 40px;
        }

        .hero-slider {
            aspect-ratio: 4/3.4;
            border-radius: var(--md-r-lg);
        }

        .hero-slide-img {
            width: calc(100% - 24px);
            height: calc(100% - 24px);
            top: 12px;
            left: 12px;
            border-radius: var(--md-r-md);
        }

        .hero-slide-caption {
            bottom: 34px;
            max-width: calc(100% - 28px);
        }

        .hero-slider .slick-dots {
            bottom: 12px;
        }

        .hero-float {
            padding: 9px 14px;
        }

        .hero-float--admission {
            top: -12px;
            left: 12px;
        }

        .hero-float--stat {
            bottom: -14px;
            right: 12px;
        }

        .hero-float--stat .stat-num {
            font-size: 1.15rem;
        }

        .hero-copy h1 {
            font-size: 1.9rem;
        }

        .why-grid,
        .notice-grid {
            grid-template-columns: 1fr;
        }

        .gallery-grid {
            grid-template-columns: 1fr 1fr;
        }

        body {
            padding-bottom: var(--tab-h);
        }

        .mobile-tabbar {
            display: flex;
        }

        .float-whatsapp {
            bottom: calc(var(--tab-h) + 14px);
            width: 52px;
            height: 52px;
            font-size: 1.35rem;
        }

        .site-footer {
            border-radius: 0;
        }
    }
</style>

<?php include_once(__DIR__ . '/../../../includes/header-close.php'); ?>

<div class="main-container">

    <!-- Top App Bar -->
    <header class="site-nav" id="siteNav">
        <div class="container nav-inner">
            <a href="#home" class="nav-logo">
                <img loading="lazy" src="<?= $logo_rectangle ?>" alt="School Logo" onerror="this.style.display='none'">
            </a>

            <ul class="nav-menu">
                <li><a href="#about" class="nav-link md-ripple-host" data-section="about">About</a></li>
                <li><a href="#academics" class="nav-link md-ripple-host" data-section="academics">Academics</a></li>
                <li class="nav-dropdown">
                    <a href="#" class="nav-link md-ripple-host" data-section="teachers">Teachers <i class="fas fa-chevron-down" style="font-size:.55rem"></i></a>
                    <div class="nav-dropdown-panel">
                        <?php if ($schoolSettings['show_teachers_on_front_page']): ?>
                            <a href="#teachers"><i class="fas fa-users"></i> All Teachers</a>
                        <?php endif; ?>
                        <?php if ($schoolSettings['teacher_application']): ?>
                            <a href="enquiries/form/teacher-application.php"><i class="fas fa-graduation-cap"></i> Apply as Teacher</a>
                        <?php endif; ?>
                    </div>
                </li>
                <li class="nav-dropdown">
                    <a href="#" class="nav-link md-ripple-host" data-section="gallery">Gallery <i class="fas fa-chevron-down" style="font-size:.55rem"></i></a>
                    <div class="nav-dropdown-panel">
                        <a href="pages/photo-gallery.php"><i class="fas fa-camera-retro"></i> Photo Gallery</a>
                        <a href="pages/video-gallery.php"><i class="fas fa-video"></i> Video Gallery</a>
                    </div>
                </li>
                <li><a href="#notices" class="nav-link md-ripple-host" data-section="notices">Notices</a></li>
                <li><a href="#contact" class="nav-link md-ripple-host" data-section="contact">Contact</a></li>
            </ul>

            <div class="nav-actions">
                <?php if ($schoolSettings['admin_login_option_show']): ?>
                    <a href="management/" class="md-btn md-btn-filled md-ripple-host d-none d-lg-inline-flex" style="height:40px;"><i class="fa-solid fa-lock"></i> Login</a>
                <?php endif; ?>
                <button class="nav-toggle" id="navToggle" aria-label="Open menu"><i class="fas fa-bars"></i></button>
            </div>
        </div>
    </header>

    <!-- Drawer scrim -->
    <div class="nav-scrim" id="navScrim"></div>

    <!-- Mobile navigation drawer -->
    <div class="nav-overlay" id="navOverlay">
        <div class="nav-overlay-top">
            <img src="<?= $logo_rectangle ?>" alt="School Logo" style="height:34px;" onerror="this.style.display='none'">
            <button class="nav-toggle" id="navClose" style="display:flex;" aria-label="Close menu"><i class="fas fa-times"></i></button>
        </div>
        <ul class="nav-overlay-links">
            <li><a href="#about" data-section="about"><i class="fas fa-school"></i> About</a></li>
            <li><a href="#academics" data-section="academics"><i class="fas fa-book-open"></i> Academics</a></li>
            <?php if ($schoolSettings['show_teachers_on_front_page']): ?>
                <li><a href="#teachers" data-section="teachers"><i class="fas fa-chalkboard-teacher"></i> Teachers</a></li>
            <?php endif; ?>
            <?php if ($schoolSettings['teacher_application']): ?>
                <li><a class="sub-link" href="enquiries/form/teacher-application.php">Apply as Teacher</a></li>
            <?php endif; ?>
            <li><a href="pages/photo-gallery.php"><i class="fas fa-images"></i> Photo Gallery</a></li>
            <li><a class="sub-link" href="pages/video-gallery.php">Video Gallery</a></li>
            <li><a href="#notices" data-section="notices"><i class="fas fa-bullhorn"></i> Notices</a></li>
            <li><a href="#contact" data-section="contact"><i class="fas fa-paper-plane"></i> Contact</a></li>
            <?php if ($schoolSettings['admin_login_option_show']): ?>
                <li><a href="management/"><i class="fa-solid fa-lock"></i> Login</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <!-- ================= HERO ================= -->
    <section class="hero" id="home">
        <div class="container hero-grid">
            <div class="hero-visual reveal">
                <div class="hero-slider">
                    <?php if (!empty($carousel_images)): ?>
                        <?php foreach ($carousel_images as $image): ?>
                            <div class="hero-slide">
                                <div class="hero-slide-bg lazy-bg" data-bg="<?= $image['image_url'] ?>"></div>
                                <img
                                    class="hero-slide-img"
                                    loading="lazy"
                                    src="<?= $image['image_url'] ?>"
                                    alt="<?= safe_htmlspecialchars($image['caption'] ?? $schoolInfo['name']) ?>"
                                    data-fancybox="hero-slide-images"
                                    data-caption="<?= safe_htmlspecialchars($image['caption'] ?? $schoolInfo['name']) ?>">
                                <?php if (!empty($image['caption'])): ?>
                                    <span class="hero-slide-caption"><?= safe_htmlspecialchars($image['caption']) ?></span>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="hero-slide" style="background:var(--md-primary);display:flex;align-items:center;justify-content:center;">
                            <h3 style="color:#fff;">Welcome to <?= $schoolInfo['name'] ?></h3>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if ($schoolSettings['admission_open']): ?>
                    <div class="hero-float hero-float--admission md-ripple-host">
                        <span class="chip-dot"></span>
                        <span>Admissions Open</span>
                    </div>
                <?php endif; ?>

                <?php if (!empty($teachers)): ?>
                    <div class="hero-float hero-float--stat">
                        <div class="stat-num"><?= count($teachers) ?>+</div>
                        <div class="stat-label">Teachers</div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="hero-copy reveal">
                <span class="md-chip"><i class="fas fa-school"></i> Welcome to <?= $schoolInfo['name'] ?></span>
                <h1>Where every learner<br><strong>is known by name.</strong></h1>
                <p class="hero-lead">A warm, well-equipped campus with dedicated teachers, modern classrooms and a curriculum built around every child's growth.</p>
                <div class="hero-actions">
                    <?php if ($schoolSettings['admission_open']): ?>
                        <a href="enquiries/form/admission-enquiry.php" class="md-btn md-btn-filled md-ripple-host"><i class="fas fa-pen-nib"></i> Apply for Admission</a>
                    <?php endif; ?>
                    <a href="#contact" class="md-btn md-btn-outlined md-ripple-host">Contact Us</a>
                </div>
                <div class="hero-stats">
                    <?php if (!empty($classes)): ?>
                        <div>
                            <span class="stat-num"><?= count($classes) ?></span>
                            <span class="stat-label">Classes</span>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($teachers)): ?>
                        <div>
                            <span class="stat-num"><?= count($teachers) ?>+</span>
                            <span class="stat-label">Teachers</span>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($galley_images)): ?>
                        <div>
                            <span class="stat-num"><?= count($galley_images) ?>+</span>
                            <span class="stat-label">Gallery Moments</span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- Birthday Section -->
    <?php if (!empty($birthdayStudents)): ?>
        <section id="birthday-section">
            <div class="container">
                <div class="birthday-slider">
                    <?php foreach ($birthdayStudents as $birthday_student): ?>
                        <div class="px-2">
                            <div class="bday-card position-relative overflow-hidden">
                                <button type="button" class="btn-close position-absolute bday-close" style="top:16px;right:16px;" onclick="document.getElementById('birthday-section').style.display='none'" aria-label="Close"></button>

                                <?php
                                $student_name = $birthday_student['name'] ?? $birthday_student['student_name'] ?? 'Student';
                                $first_letter = mb_substr($student_name, 0, 1, "UTF-8");
                                $student_image_db = $birthday_student['photo'] ?? $birthday_student['student_image'] ?? '';
                                $student_photo = (!empty($student_image_db)) ? 'uploads/students/' . $student_image_db : 'https://placehold.co/120x120/' . str_replace('#', '', $theme_color) . '/FFFFFF?text=' . urlencode($first_letter);
                                ?>

                                <div class="d-flex flex-column flex-md-row align-items-center text-center text-md-start position-relative" style="gap:22px;">
                                    <div class="position-relative flex-shrink-0">
                                        <img src="<?= $student_photo ?>" data-fancybox="Birthday Student" data-caption="<?= safe_htmlspecialchars($student_name) ?>" alt="<?= safe_htmlspecialchars($student_name) ?>" class="rounded-circle bday-photo" onerror="this.onerror=null;this.src='https://placehold.co/120x120/<?= str_replace('#', '', $theme_color) ?>/FFFFFF?text=<?= urlencode($first_letter) ?>';">
                                        <div class="position-absolute bday-emoji">🎉</div>
                                    </div>
                                    <div>
                                        <h3 class="bday-heading">Happy Birthday <span class="bday-cake-emoji">🎂</span></h3>
                                        <h4 class="bday-name"><?= safe_htmlspecialchars($student_name) ?></h4>
                                        <div class="bday-badges">
                                            <span class="bday-badge"><i class="fas fa-graduation-cap me-1"></i> Class <?= safe_htmlspecialchars($birthday_student['class_name'] ?? 'N/A') ?></span>
                                            <?php if (!empty($birthday_student['section_name'])): ?>
                                                <span class="bday-badge"><i class="fas fa-layer-group me-1"></i> Section <?= safe_htmlspecialchars($birthday_student['section_name']) ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <!-- ================= WHY US ================= -->
    <section class="section-pad">
        <div class="container">
            <div class="section-head reveal">
                <span class="md-chip"><i class="fas fa-star"></i> Why families choose us</span>
                <h2>A campus built around how children actually learn</h2>
            </div>
            <div class="why-grid reveal">
                <div class="why-card">
                    <div class="why-icon"><i class="fas fa-graduation-cap"></i></div>
                    <h4>Quality Education</h4>
                    <p>Modern teaching methods and well-equipped classrooms shape a curriculum that keeps pace with every learner.</p>
                </div>
                <div class="why-card">
                    <div class="why-icon"><i class="fas fa-user-friends"></i></div>
                    <h4>Experienced Teachers</h4>
                    <p>A qualified, dedicated faculty stays closely invested in each student's progress and development.</p>
                </div>
                <div class="why-card">
                    <div class="why-icon"><i class="fas fa-shield-alt"></i></div>
                    <h4>Safe & Fun Place</h4>
                    <p>A safe, stimulating environment with modern facilities where children are genuinely happy to be.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ================= NOTICES ================= -->
    <section id="notices" class="section-pad">
        <div class="container">
            <div class="section-head reveal">
                <span class="md-chip"><i class="fas fa-bullhorn"></i> Notice Board</span>
                <h2>What's happening this week</h2>
            </div>
            <div class="notice-grid reveal">
                <?php
                $i = 0;
                foreach ($notices as $notice) {
                    if ($i == 3) break;
                    $i++;
                ?>
                    <div class="notice-card read-more-btn md-ripple-host"
                        data-notice-title="<?= safe_htmlspecialchars($notice['title']) ?>"
                        data-notice-content="<?= safe_htmlspecialchars($notice['content']) ?>"
                        data-notice-date="<?= (new DateTime($notice['notice_date']))->format('d F Y'); ?>">
                        <span class="notice-date-tag"><i class="far fa-calendar-alt"></i> <?= (new DateTime($notice['notice_date']))->format('d M Y'); ?></span>
                        <h4><?= safe_htmlspecialchars($notice['title']) ?></h4>
                        <p><?= safe_htmlspecialchars($notice['content']) ?></p>
                        <span class="read-more-btn">Read More <i class="fas fa-arrow-right" style="font-size:.7rem"></i></span>
                    </div>
                <?php } ?>
            </div>
            <div class="text-center mt-5">
                <a href="pages/notices.php" class="md-btn md-btn-tonal md-ripple-host">View All Notices</a>
            </div>
        </div>
    </section>

    <!-- ================= ABOUT ================= -->
    <section id="about" class="section-pad">
        <div class="container">
            <div class="about-grid">
                <div class="about-frame reveal">
                    <?php if (!empty($carousel_images)): ?>
                        <img
                            src="<?= $carousel_images[random_int(0, count($carousel_images) - 1)]['image_url'] ?>"
                            alt="<?= safe_htmlspecialchars($schoolInfo['name']) ?>"
                            data-fancybox="galley-carousel"
                            loading="lazy" />
                    <?php elseif (!empty($galley_images)): ?>
                        <img
                            src="<?= $galley_images[0]['thumbnail_url'] ?>"
                            alt="<?= safe_htmlspecialchars($schoolInfo['name']) ?>"
                            loading="lazy" />
                    <?php else: ?>
                        <div style="aspect-ratio:4/3.3;border-radius:var(--md-r-xl);background:var(--md-primary-container);display:flex;align-items:center;justify-content:center;position:relative;z-index:1;box-shadow:var(--md-e2);">
                            <i class="fas fa-school" style="font-size:3rem;color:var(--md-on-primary-container);"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="about-copy reveal">
                    <div class="section-head text-start" style="margin:0;">
                        <span class="md-chip"><i class="fas fa-info-circle"></i> About Our School</span>
                        <h2><?= safe_htmlspecialchars($schoolInfo['name']) ?></h2>
                    </div>
                    <p><?= nl2br($schoolInfo['description']); ?></p>
                </div>
            </div>
        </div>
    </section>

    <!-- ================= ACADEMICS / FEES ================= -->
    <section id="academics" class="section-pad">
        <div class="container">
            <div class="section-head reveal">
                <span class="md-chip"><i class="fas fa-book-open"></i> Academics</span>
                <h2>Fee Structure</h2>
                <p>A clear, upfront look at monthly and admission fees for every class.</p>
            </div>
            <div class="fee-grid reveal">
                <?php foreach ($classes as $class) { ?>
                    <div class="fee-card">
                        <h4><?= $class['class_name'] ?></h4>
                        <div class="fee-row">
                            <span>Monthly Fee</span>
                            <span class="fee-value">₹<?= number_format($class['monthly_fee']) ?></span>
                        </div>
                        <div class="fee-row">
                            <span>Admission Fee</span>
                            <span class="fee-value">₹<?= number_format($class['admission_fee']) ?></span>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </section>

    <!-- ================= TEACHERS ================= -->
    <section id="teachers" class="section-pad">
        <div class="container">
            <div class="section-head reveal">
                <span class="md-chip"><i class="fas fa-chalkboard-teacher"></i> Our Faculty</span>
                <h2>Meet the teachers</h2>
            </div>
            <div class="teachers-carousel reveal">
                <?php
                $i = 0;
                foreach ($teachers as $index => $teacher) {
                    if ($i % 6 === 0) {
                        echo '<div><div class="row g-4">';
                    }
                ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="teacher-card">
                            <?php
                            if ($teacher['teacher_image'] == null || $teacher['teacher_image'] == '' || $teacher['teacher_image'] == 'default_teacher_dp.jpg') {
                                $teacher_dp_url = 'https://placehold.co/120x120/' . str_replace('#', '', $theme_color) . '/FFFFFF?text=' . substr($teacher['name'], 0, 1);
                            } else {
                                $teacher_dp_url = 'uploads/teachers/' . $teacher['teacher_image'];
                            }
                            ?>
                            <img loading="lazy" src="<?= $teacher_dp_url ?>" alt="<?= $teacher['name'] ?>" data-fancybox="teacher-image-gallery" data-caption="<?= $teacher['name'] ?>" onerror="this.onerror=null;this.src='https://placehold.co/120x120/<?= str_replace('#', '', $theme_color) ?>/FFFFFF?text=<?= substr($teacher['name'], 0, 1) ?>';">
                            <h4><?= $teacher['name'] ?></h4>
                            <p class="qualification"><?= $teacher['qualification'] ?></p>
                            <p class="position_in_school"><?= $teacher['position_in_school'] ?></p>
                        </div>
                    </div>
                <?php
                    $i++;
                    if ($i % 6 === 0 || $i === count($teachers)) {
                        echo '</div></div>';
                    }
                }
                ?>
            </div>
        </div>
    </section>

    <!-- ================= GALLERY ================= -->
    <section id="gallery" class="section-pad">
        <div class="container">
            <div class="section-head reveal">
                <span class="md-chip"><i class="fas fa-images"></i> Moments</span>
                <h2>School Gallery</h2>
            </div>
            <div class="gallery-grid reveal">
                <?php
                $i = 1;
                foreach ($galley_images as $image) {
                ?>
                    <a href="<?= $image['photo_url'] ?>" data-fancybox="gallery" data-caption="<?= $image['caption'] ?>" class="gallery-item">
                        <img src="<?= $image['thumbnail_url'] ?>" alt="<?= $image['caption'] ?>" loading="lazy" />
                    </a>
                <?php
                    if ($i == 6) break;
                    $i++;
                } ?>
            </div>
            <div class="text-center mt-5">
                <a href="pages/photo-gallery.php" class="md-btn md-btn-filled md-ripple-host">View More Photos</a>
            </div>
        </div>
    </section>

    <!-- ================= CONTACT ================= -->
    <section id="contact" class="section-pad">
        <div class="container">
            <div class="section-head reveal">
                <span class="md-chip"><i class="fas fa-paper-plane"></i> Get in Touch</span>
                <h2>Contact Us</h2>
            </div>
            <div class="row g-4 reveal">
                <div class="col-lg-6">
                    <div class="contact-panel">
                        <h4 class="mb-4">Send us a Message</h4>
                        <form class="contact-form" action="mailto:<?= $schoolInfo['email'] ?>" method="post" enctype="text/plain">
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="cf_name" name="name" placeholder="Your Name" required>
                                <label for="cf_name">Your Name</label>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="tel" class="form-control" id="cf_phone" name="phone-number" placeholder="Your Phone" required>
                                <label for="cf_phone">Your Phone</label>
                            </div>
                            <div class="form-floating mb-4">
                                <textarea class="form-control" id="cf_message" style="height:130px" name="message" placeholder="Your Message" required></textarea>
                                <label for="cf_message">Your Message</label>
                            </div>
                            <button type="submit" class="md-btn md-btn-filled md-ripple-host w-100">Send Message</button>
                        </form>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="contact-panel">
                        <h4 class="mb-4">Find Us Here</h4>
                        <div class="contact-info-item">
                            <span class="icon-badge"><i class="fas fa-map-marker-alt"></i></span>
                            <div>
                                <h6>Address</h6>
                                <p><?= $schoolInfo['address']; ?></p>
                            </div>
                        </div>
                        <div class="contact-info-item">
                            <span class="icon-badge"><i class="fas fa-phone-alt"></i></span>
                            <div>
                                <h6>Phone</h6>
                                <p><?= $schoolInfo['phone']; ?> / <?= $schoolInfo['alternate_phone']; ?></p>
                            </div>
                        </div>
                        <div class="contact-info-item">
                            <span class="icon-badge"><i class="fas fa-envelope"></i></span>
                            <div>
                                <h6>Email</h6>
                                <p><?= $schoolInfo['email']; ?></p>
                            </div>
                        </div>
                        <div class="contact-map">
                            <iframe src="<?= $schoolInfo['google_map_embed_link']; ?>" width="100%" height="230" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Notice Modal -->
    <div class="modal fade" id="noticeModal" tabindex="-1" aria-labelledby="noticeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content" style="border-radius: var(--md-r-xl); border:none; box-shadow: var(--md-e3);">
                <div class="modal-body p-4">
                    <div class="notice-modal-content">
                        <!-- Content will be loaded here dynamically -->
                    </div>
                </div>
                <div class="modal-footer" style="border-top:none;">
                    <button type="button" class="md-btn md-btn-tonal" data-bs-dismiss="modal" style="height:40px;">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-5 mb-lg-0 text-center text-lg-start">
                    <div class="d-flex align-items-center justify-content-center justify-content-lg-start mb-3">
                        <img src="<?= $logo_square ?>" alt="School Logo" class="me-3" style="height: 44px; border-radius: 10px; background: #fff; padding: 3px;" onerror="this.style.display='none'">
                        <h5 class="mb-0"><?= $schoolInfo['name']; ?></h5>
                    </div>
                    <p class="footer-tag-line">Building a bright future, one child at a time.</p>
                    <div class="footer-social-icons mt-4">
                        <a href="<?= $schoolInfo['facebook'] ?>"><i class="fab fa-facebook-f"></i></a>
                        <a href="<?= $schoolInfo['whatsapp'] ?>"><i class="fab fa-whatsapp"></i></a>
                        <a href="<?= $schoolInfo['instagram'] ?>"><i class="fab fa-instagram"></i></a>
                        <a href="<?= $schoolInfo['youtube'] ?>"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>

                <div class="col-lg-2 text-center text-lg-start mb-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="pages/about-us.php">About Us</a></li>
                        <li class="mb-2"><a href="pages/contact-us.php">Contact Us</a></li>
                        <li class="mb-2"><a href="pages/privacy-and-policy.php">Privacy & Policy</a></li>
                        <li class="mb-2"><a href="pages/terms-and-conditions.php">Terms & Conditions</a></li>
                        <li class="mb-2"><a href="pages/refund-and-cancellation.php">Refund Policy</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 text-center text-lg-start mb-4">
                    <h5>Contact</h5>
                    <ul class="list-unstyled">
                        <li class="mb-3 d-flex align-items-start justify-content-center justify-content-lg-start">
                            <i class="fas fa-phone-alt me-2 mt-1" style="opacity:.6"></i>
                            <div>
                                <a href="tel:<?= $schoolInfo['phone']; ?>"><?= $schoolInfo['phone']; ?></a><br>
                                <a href="tel:<?= $schoolInfo['alternate_phone']; ?>"><?= $schoolInfo['alternate_phone']; ?></a>
                            </div>
                        </li>
                        <li class="mb-2 d-flex align-items-center justify-content-center justify-content-lg-start">
                            <i class="fas fa-envelope me-2" style="opacity:.6"></i>
                            <a href="mailto:<?= $schoolInfo['email']; ?>"><?= $schoolInfo['email']; ?></a>
                        </li>
                    </ul>
                </div>

                <div class="col-lg-3 text-center text-lg-start">
                    <a target="_blank" href="<?= BASE_URL ?>/apps/" class="md-btn md-btn-filled md-ripple-host" style="background:#2E7D32;"><i class="fa-brands fa-google-play"></i> Download Apps</a>
                </div>
            </div>

            <div class="text-center mt-5 pt-4 border-top border-secondary">
                <p style="color:inherit;">&copy; <?php echo date("Y"); ?> <?= $schoolInfo['name']; ?> | Developed with <i class="fas fa-heart" style="color:#EF5350;"></i> by <a href="https://schoolsongi.com" style="color:var(--md-inverse-primary);">School Songi</a></p>
            </div>
        </div>
    </footer>

    <!-- Floating WhatsApp FAB -->
    <?php if (!empty($schoolInfo['whatsapp'])): ?>
        <a href="<?= $schoolInfo['whatsapp'] ?>" target="_blank" class="float-whatsapp md-ripple-host" aria-label="Chat on WhatsApp"><i class="fab fa-whatsapp"></i></a>
    <?php endif; ?>

    <!-- Mobile M3 bottom navigation bar -->
    <nav class="mobile-tabbar">
        <a href="#home" data-section="home" class="active"><span class="tab-icon-pill"><i class="fas fa-house"></i></span><span>Home</span></a>
        <a href="#notices" data-section="notices"><span class="tab-icon-pill"><i class="fas fa-bullhorn"></i></span><span>Notices</span></a>
        <?php if ($schoolSettings['admission_open']): ?>
            <a href="enquiries/form/admission-enquiry.php"><span class="tab-icon-pill"><i class="fas fa-pen-nib"></i></span><span>Apply</span></a>
        <?php else: ?>
            <a href="#contact" data-section="contact"><span class="tab-icon-pill"><i class="fas fa-paper-plane"></i></span><span>Contact</span></a>
        <?php endif; ?>
        <a href="#gallery" data-section="gallery"><span class="tab-icon-pill"><i class="fas fa-images"></i></span><span>Gallery</span></a>
        <a href="<?= BASE_URL ?>/apps/"><span class="tab-icon-pill"><i class="fa-solid fa-mobile-alt"></i></span><span>Apps</span></a>
    </nav>
</div>

<!-- Custom JS -->
<script>
    $(document).ready(function() {
        // Redirect to apply admission page when click
        $('.hero-float--admission').click(() => {
            window.location.href = '<?= BASE_URL ?>/enquiries/form/admission-enquiry.php';
        });

        // Progressive enhancement flag for the scroll-reveal effect.
        document.documentElement.classList.add('js-armed');

        // ---- Material ripple on every .md-ripple-host ----
        $(document).on('pointerdown', '.md-ripple-host', function(e) {
            const host = this;
            const rect = host.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height) * 2.2;
            const ripple = document.createElement('span');
            ripple.className = 'md-ripple';
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = (e.clientX - rect.left - size / 2) + 'px';
            ripple.style.top = (e.clientY - rect.top - size / 2) + 'px';
            host.appendChild(ripple);
            setTimeout(() => ripple.remove(), 600);
        });

        // Notice card -> modal
        $('.notice-card.read-more-btn').on('click', function(e) {
            e.preventDefault();

            var title = $(this).data('notice-title');
            var content = $(this).data('notice-content');
            var date = $(this).data('notice-date');

            $('.notice-modal-content').html(`
                <div class="notice-modal-header mb-3" style="border-bottom:1px solid var(--md-outline-variant);padding-bottom:15px;">
                    <span class="notice-date-tag" style="margin-bottom:0;">${date}</span>
                    <h4 class="mt-3" style="font-weight:500;">${title}</h4>
                </div>
                <div class="notice-modal-body" style="padding:10px 0;line-height:1.7;">
                    <p>${content.replace(/\n/g, '<br>')}</p>
                </div>
            `);

            var noticeModal = new bootstrap.Modal(document.getElementById('noticeModal'));
            noticeModal.show();
        });

        // App bar elevation on scroll
        $(window).on('scroll', function() {
            $('#siteNav').toggleClass('is-scrolled', $(window).scrollTop() > 8);
        });

        // Mobile navigation drawer + scrim
        $('#navToggle').on('click', function() {
            $('#navOverlay').addClass('is-open');
            $('#navScrim').addClass('is-open');
            $('body').css('overflow', 'hidden');
        });
        $('#navClose, #navScrim').on('click', closeMobileNav);
        $('.nav-overlay-links a').on('click', closeMobileNav);

        function closeMobileNav() {
            $('#navOverlay').removeClass('is-open');
            $('#navScrim').removeClass('is-open');
            $('body').css('overflow', '');
        }

        // Smooth scrolling for in-page anchors
        $('a[href*="#"]').on('click', function(e) {
            var href = $(this).attr('href');
            if (href === '#' || href.indexOf('#') !== 0) {
                return;
            }
            var target = $(href);
            if (target.length) {
                e.preventDefault();
                closeMobileNav();
                $('html, body').animate({
                    scrollTop: target.offset().top - (window.innerWidth < 992 ? 56 : 64)
                }, 450, 'swing');
            }
        });

        function safely(fn) {
            try {
                fn();
            } catch (err) {
                console.error(err);
            }
        }

        // Hero Slider
        safely(() => $('.hero-slider').slick({
            dots: true,
            infinite: true,
            speed: 500,
            fade: true,
            cssEase: 'cubic-bezier(.2,0,0,1)',
            autoplay: true,
            autoplaySpeed: 5000,
            arrows: false
        }));

        // Birthday Slider
        safely(() => $('.birthday-slider').slick({
            dots: true,
            infinite: true,
            speed: 500,
            fade: true,
            cssEase: 'cubic-bezier(.2,0,0,1)',
            autoplay: true,
            autoplaySpeed: 3500,
            arrows: false
        }));

        // Teachers Carousel
        safely(() => $('.teachers-carousel').slick({
            dots: true,
            infinite: true,
            speed: 300,
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: true,
            prevArrow: '<button type="button" class="slick-prev"><i class="fas fa-chevron-left"></i></button>',
            nextArrow: '<button type="button" class="slick-next"><i class="fas fa-chevron-right"></i></button>',
            responsive: [{
                breakpoint: 992,
                settings: {
                    arrows: false
                }
            }]
        }));

        // Lazy load hero backgrounds
        safely(() => {
            $('.lazy-bg').each(function() {
                const $el = $(this);
                const observer = new IntersectionObserver(function(entries, observer) {
                    entries.forEach(function(entry) {
                        if (entry.isIntersecting) {
                            $el.css('background-image', `url('${$el.data('bg')}')`);
                            observer.unobserve(entry.target);
                        }
                    });
                });
                observer.observe(this);
            });
        });

        // Scroll reveal
        safely(() => {
            const revealObserver = new IntersectionObserver(function(entries, obs) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('in-view');
                        obs.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.15
            });
            document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));
        });

        // Scrollspy — drives the active pill in the top bar,
        // the drawer, and the M3 bottom navigation bar.
        safely(() => {
            const sections = ['home', 'about', 'academics', 'teachers', 'gallery', 'notices', 'contact'];
            const spy = new IntersectionObserver(function(entries) {
                entries.forEach(function(entry) {
                    if (!entry.isIntersecting) return;
                    const id = entry.target.id;
                    if (!sections.includes(id)) return;
                    document.querySelectorAll('[data-section]').forEach(function(link) {
                        link.classList.toggle('active', link.dataset.section === id);
                    });
                });
            }, {
                rootMargin: '-40% 0px -55% 0px'
            });
            sections.forEach(function(id) {
                const el = document.getElementById(id);
                if (el) spy.observe(el);
            });
        });

        // Teacher show/hide
        if (<?= (int) ($schoolSettings['show_teachers_on_front_page'] ?? 1) ?> === 0) {
            $('#teachers').addClass('d-none');
        }

        // Academics show/hide
        if (<?= (int) ($schoolSettings['hide_fees_structure_from_website'] ?? 0) ?> === 1) {
            $('#academics').addClass('d-none');
        }
    });
</script>

<?php include_once(__DIR__ . '/../../../includes/body-close.php'); ?>