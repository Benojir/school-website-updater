<?php

/** @var string $school_name
 * @var PDO $pdo
 * @var array $schoolSettings
 * @var array $websiteConfig
 * @var string $assets_version
 * @var string $logo_square
 * @var array $schoolInfo
 */
include_once(__DIR__ . '/../../../includes/header-open.php');

if (!function_exists('safe_htmlspecialchars')) {
    function safe_htmlspecialchars($value)
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }
}

$theme_color = $theme_color ?? '#6D5DF6';
$logo_rectangle = $logo_rectangle ?? ($logo_square ?? '');
$logo_square = $logo_square ?? $logo_rectangle;
$schoolInfo = $schoolInfo ?? [];
$schoolSettings = $schoolSettings ?? [];
$seo_title = $seo_title ?? ($schoolInfo['name'] ?? 'School');

$showTeachers = !empty($schoolSettings['show_teachers_on_front_page']);
$teacherApplication = !empty($schoolSettings['teacher_application']);
$admissionOpen = !empty($schoolSettings['admission_open']);
$adminLogin = !empty($schoolSettings['admin_login_option_show']);
$hideFees = !empty($schoolSettings['hide_fees_structure_from_website']);

// Fetch carousel images
$stmt = $pdo->prepare("SELECT * FROM carousel_images");
$stmt->execute();
$carousel_images = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo '<title>' . $seo_title . '</title>';

// Fetch all notices
$stmt = $pdo->prepare("SELECT * FROM notices ORDER BY notice_date DESC LIMIT 30");
$stmt->execute();
$notices = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch classes and class-wise fees
$stmt = $pdo->prepare("
SELECT 
classes.id, 
classes.class_name, 
class_wise_monthly_fees.amount AS monthly_fee,
class_wise_new_admission_fees.amount AS admission_fee
FROM 
classes 
INNER JOIN class_wise_monthly_fees ON class_wise_monthly_fees.class_id = classes.id
INNER JOIN class_wise_new_admission_fees ON class_wise_new_admission_fees.class_id = classes.id
ORDER BY classes.id ASC;
");
$stmt->execute();
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch teachers
// Only teachers the admin opted in are listed. Manually prioritised teachers come first
// (lowest number first); everyone without a priority follows in random order, as before.
$stmt = $pdo->prepare("
    SELECT * FROM teachers
    WHERE status = 'active' AND show_on_website = 1
    ORDER BY (display_priority IS NULL), display_priority ASC, RAND()
");
$stmt->execute();
$teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch gallery images
$stmt = $pdo->prepare("SELECT * FROM gallery ORDER BY event_date DESC");
$stmt->execute();
$galley_images = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch gallery videos
$stmt = $pdo->prepare("SELECT * FROM gallery_videos ORDER BY event_date DESC");
$stmt->execute();
$galley_videos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Today's birthday students
$stmt = $pdo->prepare("
    SELECT s.*, c.class_name, sec.section_name 
    FROM students s 
    JOIN classes c ON s.class_id = c.id
    LEFT JOIN sections sec ON s.section_id = sec.id
    WHERE MONTH(s.date_of_birth) = MONTH(CURRENT_DATE()) 
      AND DAY(s.date_of_birth) = DAY(CURRENT_DATE())
");
$stmt->execute();
$birthdayStudents = $stmt->fetchAll(PDO::FETCH_ASSOC);

$fallbackHeroImage = !empty($carousel_images)
    ? $carousel_images[random_int(0, count($carousel_images) - 1)]['image_url']
    : (!empty($galley_images) ? $galley_images[0]['thumbnail_url'] : '');
?>

<style>
    @import url('https://fonts.googleapis.com/css2?family=Unbounded:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700;800&family=Space+Mono:wght@400;700&display=swap');

    :root {
        --d5-primary: <?= $theme_color ?>;
        --d5-primary-rgb: 109, 93, 246;
        --d5-cyan: #31E6FF;
        --d5-pink: #FF5D9E;
        --d5-lime: #B7FF5C;
        --d5-amber: #FFC857;
        --d5-bg: #070A18;
        --d5-bg-2: #0B1026;
        --d5-panel: rgba(255, 255, 255, .075);
        --d5-panel-strong: rgba(255, 255, 255, .12);
        --d5-text: #F5F7FF;
        --d5-muted: rgba(226, 232, 255, .68);
        --d5-line: rgba(255, 255, 255, .14);
        --d5-line-strong: rgba(255, 255, 255, .24);
        --d5-shadow: 0 40px 100px -35px rgba(0, 0, 0, .72);
        --d5-radius-xl: 34px;
        --d5-radius-lg: 24px;
        --d5-radius-md: 17px;
        --d5-radius-sm: 12px;
        --d5-display: 'Unbounded', 'Inter', sans-serif;
        --d5-body: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        --d5-mono: 'Space Mono', ui-monospace, monospace;
        --d5-nav-h: 82px;
        --d5-tab-h: 72px;
    }

    .design5-page {
        position: relative;
        min-height: 100vh;
        overflow-x: hidden;
        background:
            radial-gradient(circle at 12% 8%, color-mix(in srgb, var(--d5-primary) 42%, transparent) 0 26%, transparent 42%),
            radial-gradient(circle at 88% 12%, rgba(49, 230, 255, .22) 0 18%, transparent 38%),
            radial-gradient(circle at 70% 78%, rgba(255, 93, 158, .16) 0 20%, transparent 45%),
            linear-gradient(180deg, var(--d5-bg), var(--d5-bg-2) 42%, #050612 100%);
        color: var(--d5-text);
        font-family: var(--d5-body);
        -webkit-font-smoothing: antialiased;
        isolation: isolate;
    }

    .design5-page::before {
        content: '';
        position: fixed;
        inset: 0;
        z-index: -3;
        pointer-events: none;
        background-image:
            linear-gradient(rgba(255, 255, 255, .035) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255, 255, 255, .035) 1px, transparent 1px);
        background-size: 54px 54px;
        mask-image: radial-gradient(circle at 50% 18%, black 0 35%, transparent 78%);
    }

    .design5-page::after {
        content: '';
        position: fixed;
        inset: 0;
        z-index: -2;
        pointer-events: none;
        background:
            linear-gradient(120deg, transparent 0 20%, rgba(255, 255, 255, .045) 20.4% 20.7%, transparent 21% 100%),
            linear-gradient(300deg, transparent 0 62%, rgba(49, 230, 255, .08) 62.3% 62.7%, transparent 63% 100%);
        opacity: .7;
    }

    .design5-page h1,
    .design5-page h2,
    .design5-page h3,
    .design5-page h4 {
        font-family: var(--d5-display);
        color: var(--d5-text);
        letter-spacing: -.045em;
        margin: 0;
    }

    .design5-page p {
        color: var(--d5-muted);
        line-height: 1.75;
    }

    .design5-page a {
        color: inherit;
        text-decoration: none;
    }

    .design5-page img {
        max-width: 100%;
    }

    @media (prefers-reduced-motion: reduce) {
        .design5-page * {
            animation-duration: .01ms !important;
            animation-iteration-count: 1 !important;
            scroll-behavior: auto !important;
            transition-duration: .01ms !important;
        }
    }

    .d5-container {
        width: min(1180px, calc(100% - 40px));
        margin-inline: auto;
    }

    .d5-reveal {
        opacity: 1;
        transform: none;
    }

    html.d5-js .d5-reveal {
        opacity: 0;
        transform: translateY(28px) scale(.985);
        transition: opacity .8s ease, transform .8s cubic-bezier(.2, .8, .2, 1);
    }

    html.d5-js .d5-reveal.is-in {
        opacity: 1;
        transform: none;
    }

    .d5-kicker {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        font-family: var(--d5-mono);
        font-size: .72rem;
        font-weight: 700;
        letter-spacing: .18em;
        text-transform: uppercase;
        color: #fff;
        border: 1px solid var(--d5-line-strong);
        background: linear-gradient(135deg, rgba(255, 255, 255, .14), rgba(255, 255, 255, .05));
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, .2), 0 18px 45px -24px rgba(0, 0, 0, .8);
        border-radius: 999px;
        padding: 9px 15px 9px 11px;
        backdrop-filter: blur(16px);
    }

    .d5-kicker::before {
        content: '';
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: var(--d5-cyan);
        box-shadow: 0 0 0 6px rgba(49, 230, 255, .14), 0 0 24px rgba(49, 230, 255, .75);
    }

    .d5-section {
        padding: 96px 0;
        position: relative;
    }

    .d5-head {
        max-width: 760px;
        margin: 0 auto 52px;
        text-align: center;
    }

    .d5-head.d5-left {
        text-align: left;
        margin-left: 0;
    }

    .d5-head .d5-kicker {
        margin-bottom: 18px;
    }

    .d5-head h2 {
        font-size: clamp(2rem, 4vw, 3.3rem);
        line-height: 1.02;
    }

    .d5-head p {
        margin: 16px auto 0;
        max-width: 620px;
        font-size: 1.03rem;
    }

    .d5-head.d5-left p {
        margin-left: 0;
    }

    .d5-btn {
        position: relative;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        min-height: 52px;
        padding: 0 24px;
        border-radius: 999px;
        border: 1px solid var(--d5-line-strong);
        color: var(--d5-text);
        font-weight: 800;
        font-size: .94rem;
        letter-spacing: -.01em;
        background: rgba(255, 255, 255, .07);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, .16), 0 18px 42px -24px rgba(0, 0, 0, .85);
        backdrop-filter: blur(18px);
        transform-style: preserve-3d;
        transition: transform .25s ease, border-color .25s ease, background .25s ease, box-shadow .25s ease;
        white-space: nowrap;
    }

    .d5-btn:hover {
        color: #fff;
        transform: translateY(-3px);
        border-color: rgba(255, 255, 255, .42);
        background: rgba(255, 255, 255, .11);
    }

    .d5-btn-primary {
        border-color: color-mix(in srgb, var(--d5-primary) 70%, white);
        background:
            radial-gradient(circle at 25% 0%, rgba(255, 255, 255, .5), transparent 28%),
            linear-gradient(135deg, var(--d5-primary), #8B5CF6 48%, var(--d5-cyan));
        box-shadow: 0 24px 58px -22px color-mix(in srgb, var(--d5-primary) 85%, black), inset 0 1px 0 rgba(255, 255, 255, .38);
    }

    .d5-btn-primary:hover {
        box-shadow: 0 30px 70px -22px color-mix(in srgb, var(--d5-primary) 90%, black), inset 0 1px 0 rgba(255, 255, 255, .42);
    }

    .d5-glass {
        border: 1px solid var(--d5-line);
        background: linear-gradient(145deg, rgba(255, 255, 255, .12), rgba(255, 255, 255, .045));
        box-shadow: var(--d5-shadow), inset 0 1px 0 rgba(255, 255, 255, .16);
        backdrop-filter: blur(22px) saturate(1.25);
        border-radius: var(--d5-radius-xl);
    }

    .d5-depth {
        transform-style: preserve-3d;
    }

    .d5-depth>* {
        transform-style: preserve-3d;
    }

    .d5-tilt {
        transform: perspective(1100px) rotateX(0deg) rotateY(0deg) translateZ(0);
        transform-style: preserve-3d;
        transition: transform .22s ease, box-shadow .28s ease, border-color .28s ease;
        will-change: transform;
    }

    .d5-tilt:hover {
        border-color: rgba(255, 255, 255, .32);
    }

    .d5-card {
        position: relative;
        height: 100%;
        border: 1px solid var(--d5-line);
        border-radius: var(--d5-radius-lg);
        background:
            linear-gradient(145deg, rgba(255, 255, 255, .12), rgba(255, 255, 255, .045)),
            radial-gradient(circle at 18% 0%, rgba(255, 255, 255, .18), transparent 34%);
        box-shadow: 0 26px 70px -34px rgba(0, 0, 0, .78), inset 0 1px 0 rgba(255, 255, 255, .15);
        overflow: hidden;
        min-width: 0;
        box-sizing: border-box;
    }

    .d5-card::before {
        content: '';
        position: absolute;
        inset: 1px;
        border-radius: inherit;
        background: linear-gradient(135deg, rgba(255, 255, 255, .22), transparent 24%, transparent 72%, rgba(49, 230, 255, .14));
        opacity: .55;
        pointer-events: none;
        transform: translateZ(28px);
    }

    .d5-card::after {
        content: '';
        position: absolute;
        left: 18px;
        right: 18px;
        bottom: -16px;
        height: 36px;
        border-radius: 50%;
        background: rgba(0, 0, 0, .45);
        filter: blur(22px);
        transform: translateZ(-45px);
        pointer-events: none;
    }

    .d5-pad {
        padding: 30px;
        position: relative;
        z-index: 2;
        transform: translateZ(34px);
    }

    /* ---------- nav ---------- */
    .d5-nav {
        position: sticky;
        top: 0;
        z-index: 1000;
        height: var(--d5-nav-h);
        display: flex;
        align-items: center;
        background: rgba(5, 7, 18, .56);
        border-bottom: 1px solid rgba(255, 255, 255, .1);
        backdrop-filter: blur(22px) saturate(1.35);
        transition: background .3s ease, box-shadow .3s ease;
    }

    .d5-nav.is-scrolled {
        background: rgba(5, 7, 18, .82);
        box-shadow: 0 24px 70px -40px rgba(0, 0, 0, .9);
    }

    .d5-nav-inner {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 18px;
    }

    .d5-logo {
        display: inline-flex;
        align-items: center;
        gap: 12px;
        min-width: 0;
    }

    .d5-logo img {
        height: 48px;
        width: auto;
        filter: drop-shadow(0 10px 24px rgba(0, 0, 0, .55));
    }

    .d5-logo span {
        display: none;
        font-family: var(--d5-display);
        font-size: .82rem;
        color: #fff;
        max-width: 190px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .d5-menu {
        display: flex;
        align-items: center;
        gap: 4px;
        list-style: none;
        margin: 0;
        padding: 6px;
        border: 1px solid rgba(255, 255, 255, .12);
        border-radius: 999px;
        background: rgba(255, 255, 255, .055);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, .12);
    }

    .d5-menu>li {
        position: relative;
    }

    .d5-menu a.d5-nav-link {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        border-radius: 999px;
        padding: 10px 15px;
        color: rgba(235, 239, 255, .76);
        font-size: .85rem;
        font-weight: 800;
        transition: background .25s ease, color .25s ease, transform .25s ease;
    }

    .d5-menu a.d5-nav-link:hover {
        color: #fff;
        background: rgba(255, 255, 255, .1);
        transform: translateY(-1px);
    }

    .d5-drop {
        position: absolute;
        top: 100%;
        left: 50%;
        min-width: 235px;
        margin-top: 13px;
        padding: 9px;
        border-radius: 18px;
        border: 1px solid rgba(255, 255, 255, .14);
        background: rgba(10, 13, 31, .92);
        box-shadow: 0 34px 80px -30px rgba(0, 0, 0, .88), inset 0 1px 0 rgba(255, 255, 255, .12);
        backdrop-filter: blur(22px);
        opacity: 0;
        visibility: hidden;
        transform: translateX(-50%) translateY(12px) rotateX(-8deg);
        transform-origin: top center;
        transition: opacity .22s ease, transform .22s ease, visibility .22s;
    }

    .d5-drop::before {
        content: '';
        position: absolute;
        left: 0;
        right: 0;
        top: -13px;
        height: 13px;
    }

    .d5-has-drop:hover .d5-drop {
        opacity: 1;
        visibility: visible;
        transform: translateX(-50%) translateY(0) rotateX(0deg);
    }

    .d5-drop a {
        display: flex;
        align-items: center;
        gap: 11px;
        padding: 11px 12px;
        border-radius: 12px;
        color: rgba(239, 242, 255, .82);
        font-weight: 800;
        font-size: .87rem;
    }

    .d5-drop a i {
        color: var(--d5-cyan);
        width: 18px;
    }

    .d5-drop a:hover {
        color: #fff;
        background: rgba(255, 255, 255, .1);
    }

    /* ---------- 3D login dropdown ---------- */
    .d5-nav .dropdown-toggle::after {
        border: none;
        content: '\f078';
        font-family: 'Font Awesome 5 Free', 'Font Awesome 6 Free', sans-serif;
        font-weight: 900;
        font-size: .62rem;
        margin-left: 8px;
        vertical-align: middle;
        transition: transform .25s cubic-bezier(0.16, 1, 0.3, 1);
    }

    .d5-nav .dropdown.show .dropdown-toggle::after,
    .d5-nav .dropdown-toggle[aria-expanded="true"]::after {
        transform: rotate(180deg);
    }

    .d5-dropdown-menu {
        min-width: 225px;
        margin-top: 14px !important;
        padding: 8px;
        border-radius: 20px;
        border: 1px solid rgba(255, 255, 255, .18) !important;
        background: linear-gradient(150deg, rgba(14, 18, 42, .96), rgba(7, 9, 24, .95)) !important;
        box-shadow:
            0 32px 80px -20px rgba(0, 0, 0, .92),
            inset 0 1px 0 rgba(255, 255, 255, .22),
            0 0 0 1px rgba(49, 230, 255, .14) !important;
        backdrop-filter: blur(24px) saturate(1.35);
        -webkit-backdrop-filter: blur(24px) saturate(1.35);
        transform-style: preserve-3d;
        perspective: 800px;
    }

    .d5-dropdown-menu.show {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    .d5-dropdown-menu.show li {
        animation: d5DropItemIn .26s cubic-bezier(0.16, 1, 0.3, 1) backwards;
    }

    .d5-dropdown-menu.show li:nth-child(1) {
        animation-delay: .02s;
    }

    .d5-dropdown-menu.show li:nth-child(2) {
        animation-delay: .07s;
    }

    @keyframes d5DropItemIn {
        from {
            opacity: 0;
            transform: translateY(8px) scale(.95) rotateX(-14deg);
        }
        to {
            opacity: 1;
            transform: translateY(0) scale(1) rotateX(0deg);
        }
    }

    .d5-dropdown-item {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 10px 14px;
        border-radius: 14px;
        color: rgba(240, 244, 255, .88) !important;
        font-weight: 700;
        font-size: .88rem;
        letter-spacing: -.01em;
        background: transparent !important;
        border: 1px solid transparent;
        transform-style: preserve-3d;
        transition: transform .22s ease, background .22s ease, border-color .22s ease, box-shadow .22s ease, color .22s ease;
    }

    .d5-dropdown-item i {
        width: 34px;
        height: 34px;
        flex: 0 0 auto;
        display: grid;
        place-items: center;
        border-radius: 11px;
        background: rgba(255, 255, 255, .08);
        border: 1px solid rgba(255, 255, 255, .14);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, .2), 0 4px 10px -4px rgba(0, 0, 0, .5);
        color: var(--d5-cyan);
        font-size: .86rem;
        transform-style: preserve-3d;
        transition: transform .22s ease, background .22s ease, color .22s ease, border-color .22s ease, box-shadow .22s ease;
    }

    .d5-dropdown-item:hover,
    .d5-dropdown-item:focus {
        color: #fff !important;
        background: linear-gradient(135deg, rgba(255, 255, 255, .12), rgba(255, 255, 255, .05)) !important;
        border-color: rgba(255, 255, 255, .22);
        transform: translateX(4px) translateZ(8px);
        box-shadow: 0 12px 28px -10px rgba(0, 0, 0, .65), inset 0 1px 0 rgba(255, 255, 255, .2);
    }

    .d5-dropdown-item:hover i,
    .d5-dropdown-item:focus i {
        background: linear-gradient(135deg, var(--d5-cyan), var(--d5-primary));
        color: #060919;
        border-color: rgba(255, 255, 255, .4);
        box-shadow: 0 6px 16px -3px color-mix(in srgb, var(--d5-cyan) 80%, black);
        transform: scale(1.08) rotate(3deg);
    }

    .d5-nav-actions {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .d5-nav-toggle {
        display: none;
        width: 47px;
        height: 47px;
        border: 1px solid rgba(255, 255, 255, .16);
        border-radius: 50%;
        color: #fff;
        background: rgba(255, 255, 255, .08);
        align-items: center;
        justify-content: center;
    }

    .d5-overlay {
        position: fixed;
        inset: 0;
        z-index: 1200;
        padding: 24px 24px 42px;
        background:
            radial-gradient(circle at 20% 0%, color-mix(in srgb, var(--d5-primary) 38%, transparent), transparent 38%),
            linear-gradient(180deg, #070A18, #04050D);
        transform: translateY(-102%);
        transition: transform .42s cubic-bezier(.2, .8, .2, 1);
        overflow-y: auto;
    }

    .d5-overlay.is-open {
        transform: translateY(0);
    }

    .d5-overlay-top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 28px;
    }

    .d5-overlay-top img {
        height: 40px;
    }

    .d5-overlay-links {
        list-style: none;
        margin: 0;
        padding: 0;
        perspective: 900px;
    }

    .d5-overlay-links li {
        border-bottom: 1px solid rgba(255, 255, 255, .1);
        transform-style: preserve-3d;
    }

    .d5-overlay-links a {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 17px 4px;
        font-family: var(--d5-display);
        color: #fff;
        font-size: clamp(1.25rem, 5vw, 1.7rem);
        transition: transform .25s ease, color .25s ease;
    }

    .d5-overlay-links a:hover {
        color: var(--d5-cyan);
        transform: translateX(8px) rotateX(7deg);
    }

    .d5-overlay-links a i {
        width: 32px;
        height: 32px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        color: var(--d5-cyan);
        font-size: 1.05rem;
        flex-shrink: 0;
    }

    .d5-overlay-links .d5-sub {
        padding-left: 42px;
        font-family: var(--d5-body);
        font-weight: 800;
        font-size: 1rem;
        color: rgba(235, 239, 255, .68);
    }

    /* ---------- hero ---------- */
    .d5-hero {
        position: relative;
        min-height: calc(100vh - var(--d5-nav-h));
        display: grid;
        align-items: center;
        padding: 58px 0 82px;
    }

    .d5-hero-grid {
        position: relative;
        display: grid;
        grid-template-columns: .98fr 1.02fr;
        gap: 54px;
        align-items: center;
        perspective: 1400px;
    }

    .d5-orb {
        position: absolute;
        border-radius: 50%;
        pointer-events: none;
        filter: blur(.2px);
        transform-style: preserve-3d;
        animation: d5Float 8s ease-in-out infinite;
    }

    .d5-orb-a {
        width: 120px;
        height: 120px;
        left: -28px;
        top: 44px;
        background: radial-gradient(circle at 30% 25%, #fff, var(--d5-cyan) 18%, rgba(49, 230, 255, .12) 62%, transparent 72%);
        opacity: .52;
        animation-delay: -1s;
    }

    .d5-orb-b {
        width: 76px;
        height: 76px;
        right: 22px;
        top: -24px;
        background: radial-gradient(circle at 32% 28%, #fff, var(--d5-pink) 20%, rgba(255, 93, 158, .1) 66%, transparent 76%);
        opacity: .45;
        animation-delay: -3s;
    }

    .d5-orb-c {
        width: 52px;
        height: 52px;
        left: 44%;
        bottom: -22px;
        background: radial-gradient(circle at 32% 28%, #fff, var(--d5-lime) 22%, rgba(183, 255, 92, .1) 68%, transparent 78%);
        opacity: .38;
        animation-delay: -5s;
    }

    @keyframes d5Float {

        0%,
        100% {
            transform: translate3d(0, 0, 0) rotateX(0deg);
        }

        50% {
            transform: translate3d(0, -22px, 46px) rotateX(16deg);
        }
    }

    .d5-hero-copy {
        position: relative;
        z-index: 3;
        transform-style: preserve-3d;
    }

    .d5-hero-copy h1 {
        margin: 20px 0 20px;
        font-size: clamp(2.6rem, 6.1vw, 5.15rem);
        line-height: .94;
        text-shadow: 0 24px 70px rgba(0, 0, 0, .65);
    }

    .d5-hero-copy h1 .d5-grad {
        background: linear-gradient(100deg, #fff 0%, #DCE6FF 38%, var(--d5-cyan) 68%, var(--d5-pink) 100%);
        -webkit-background-clip: text;
        background-clip: text;
        color: transparent;
    }

    .d5-hero-lead {
        max-width: 560px;
        font-size: 1.08rem;
        margin-bottom: 32px;
    }

    .d5-hero-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 14px;
        margin-bottom: 38px;
    }

    .d5-hero-stats {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 14px;
        max-width: 580px;
    }

    .d5-stat {
        position: relative;
        padding: 18px 16px;
        border-radius: 20px;
        border: 1px solid rgba(255, 255, 255, .12);
        background: linear-gradient(145deg, rgba(255, 255, 255, .11), rgba(255, 255, 255, .045));
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, .13), 0 22px 48px -28px rgba(0, 0, 0, .8);
        transform-style: preserve-3d;
    }

    .d5-stat strong {
        display: block;
        font-family: var(--d5-display);
        font-size: 1.55rem;
        line-height: 1;
        color: #fff;
        transform: translateZ(26px);
    }

    .d5-stat span {
        display: block;
        margin-top: 7px;
        font-family: var(--d5-mono);
        color: rgba(232, 236, 255, .58);
        font-size: .66rem;
        font-weight: 700;
        letter-spacing: .12em;
        text-transform: uppercase;
        transform: translateZ(18px);
    }

    .d5-hero-stage {
        position: relative;
        min-width: 0;
        transform-style: preserve-3d;
    }

    .d5-frame {
        position: relative;
        aspect-ratio: 1 / .92;
        border-radius: 42px;
        padding: clamp(14px, 2vw, 22px);
        background:
            linear-gradient(145deg, rgba(255, 255, 255, .16), rgba(255, 255, 255, .04)),
            radial-gradient(circle at 20% 0%, rgba(255, 255, 255, .22), transparent 34%);
        border: 1px solid rgba(255, 255, 255, .17);
        box-shadow: 0 58px 120px -52px rgba(0, 0, 0, .9), inset 0 1px 0 rgba(255, 255, 255, .2);
        transform: rotateX(6deg) rotateY(-9deg) translateZ(0);
        transform-style: preserve-3d;
    }

    .d5-frame::before,
    .d5-frame::after {
        content: '';
        position: absolute;
        inset: 22px;
        border-radius: 34px;
        transform: translateZ(-46px);
        background: rgba(0, 0, 0, .5);
        filter: blur(24px);
        z-index: 0;
    }

    .d5-frame::after {
        inset: auto 10% -18px 10%;
        height: 42px;
        border-radius: 50%;
        transform: translateZ(-70px);
        background: color-mix(in srgb, var(--d5-primary) 44%, black);
        filter: blur(28px);
        opacity: .62;
    }

    .d5-slider {
        position: relative;
        z-index: 2;
        height: 100%;
        min-height: 430px;
        border-radius: 32px;
        overflow: hidden;
        background: #03040A;
        box-shadow: inset 0 0 0 1px rgba(255, 255, 255, .12);
        transform: translateZ(38px);
        transform-style: preserve-3d;
    }

    .d5-slide {
        position: absolute;
        inset: 0;
        opacity: 0;
        visibility: hidden;
        transform: scale(1.05) translateZ(-30px);
        transition: opacity .75s ease, visibility .75s, transform .9s ease;
    }

    .d5-slide.is-active {
        opacity: 1;
        visibility: visible;
        transform: scale(1) translateZ(0);
        z-index: 2;
    }

    .d5-slide-bg {
        position: absolute;
        inset: -8%;
        background-position: center;
        background-size: cover;
        filter: blur(30px) brightness(.58) saturate(1.25);
        transform: scale(1.12);
    }

    .d5-slide-bg::after {
        content: '';
        position: absolute;
        inset: 0;
        background:
            radial-gradient(circle at 50% 28%, transparent 0 28%, rgba(3, 4, 10, .18) 62%),
            linear-gradient(180deg, rgba(3, 4, 10, .12), rgba(3, 4, 10, .62));
    }

    .d5-slide-img {
        position: absolute;
        inset: 24px 24px 72px;
        width: calc(100% - 48px);
        height: calc(100% - 96px);
        object-fit: cover;
        border-radius: 25px;
        border: 1px solid rgba(255, 255, 255, .2);
        box-shadow: 0 34px 70px -34px rgba(0, 0, 0, .9), inset 0 1px 0 rgba(255, 255, 255, .18);
        transform: translateZ(42px);
    }

    .d5-caption {
        position: absolute;
        left: 34px;
        right: 34px;
        bottom: 27px;
        z-index: 4;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 12px 14px;
        border-radius: 18px;
        color: #fff;
        background: rgba(4, 6, 15, .52);
        border: 1px solid rgba(255, 255, 255, .16);
        backdrop-filter: blur(14px);
        transform: translateZ(62px);
    }

    .d5-caption span {
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-family: var(--d5-mono);
        font-size: .76rem;
        letter-spacing: .03em;
    }

    .d5-dots {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        flex-shrink: 0;
    }

    .d5-dot {
        width: 8px;
        height: 8px;
        border: 0;
        border-radius: 999px;
        padding: 0;
        background: rgba(255, 255, 255, .36);
        transition: width .25s ease, background .25s ease;
    }

    .d5-dot.is-active {
        width: 24px;
        background: #fff;
    }

    .d5-empty-slide {
        position: absolute;
        inset: 0;
        display: grid;
        place-items: center;
        text-align: center;
        padding: 30px;
        background:
            radial-gradient(circle at 50% 0%, color-mix(in srgb, var(--d5-primary) 50%, transparent), transparent 55%),
            #080B1B;
    }

    .d5-chip-float {
        position: absolute;
        z-index: 6;
        display: inline-flex;
        align-items: center;
        gap: 10px;
        border-radius: 999px;
        border: 1px solid rgba(255, 255, 255, .16);
        background: rgba(8, 11, 27, .72);
        box-shadow: 0 28px 65px -28px rgba(0, 0, 0, .9), inset 0 1px 0 rgba(255, 255, 255, .16);
        backdrop-filter: blur(18px);
        color: #fff;
        transform-style: preserve-3d;
    }

    .d5-chip-open {
        left: 24px;
        top: -19px;
        padding: 12px 16px;
        cursor: pointer;
        transform: translateZ(96px);
    }

    .d5-chip-open i {
        color: var(--d5-lime);
        animation: d5Pulse 1.2s infinite ease-in-out;
    }

    @keyframes d5Pulse {
        50% {
            opacity: .25;
            transform: scale(.75);
        }
    }

    .d5-chip-open span {
        font-family: var(--d5-mono);
        font-weight: 700;
        font-size: .7rem;
        letter-spacing: .13em;
        text-transform: uppercase;
    }

    .d5-chip-count {
        right: 28px;
        bottom: -22px;
        padding: 15px 18px;
        transform: translateZ(112px) rotateY(8deg);
    }

    .d5-chip-count strong {
        font-family: var(--d5-display);
        color: #fff;
        font-size: 1.4rem;
        line-height: 1;
    }

    .d5-chip-count small {
        font-family: var(--d5-mono);
        color: rgba(235, 239, 255, .62);
        font-size: .64rem;
        letter-spacing: .12em;
        text-transform: uppercase;
    }

    /* ---------- birthday ---------- */
    .d5-birthday {
        padding: 8px 0 22px;
    }

    .d5-bday-card {
        position: relative;
        overflow: hidden;
        border-radius: var(--d5-radius-xl);
        border: 1px solid rgba(255, 255, 255, .16);
        background:
            radial-gradient(circle at 12% 0%, rgba(255, 200, 87, .34), transparent 32%),
            linear-gradient(120deg, rgba(255, 255, 255, .13), rgba(255, 255, 255, .045)),
            linear-gradient(120deg, color-mix(in srgb, var(--d5-primary) 58%, #080B1B), #080B1B);
        box-shadow: var(--d5-shadow), inset 0 1px 0 rgba(255, 255, 255, .18);
        padding: 28px;
        margin-bottom: 28px;
    }

    .d5-bday-inner {
        display: flex;
        align-items: center;
        gap: 22px;
        position: relative;
        z-index: 2;
    }

    .d5-bday-photo-wrap {
        position: relative;
        flex: 0 0 auto;
        transform-style: preserve-3d;
    }

    .d5-bday-photo {
        width: 96px;
        height: 96px;
        border-radius: 30px;
        object-fit: cover;
        border: 1px solid rgba(255, 255, 255, .3);
        box-shadow: 0 24px 55px -24px rgba(0, 0, 0, .9);
        transform: rotateY(-10deg) rotateX(8deg);
    }

    .d5-bday-photo-wrap::after {
        content: '🎉';
        position: absolute;
        right: -12px;
        top: -14px;
        font-size: 1.6rem;
        filter: drop-shadow(0 10px 12px rgba(0, 0, 0, .45));
    }

    .d5-bday-card h3 {
        font-size: clamp(1.25rem, 2.5vw, 1.8rem);
    }

    .d5-bday-card h4 {
        margin: 4px 0 12px;
        font-family: var(--d5-body);
        font-weight: 900;
        color: #fff;
        font-size: clamp(1.25rem, 3vw, 2rem);
        letter-spacing: -.04em;
    }

    .d5-badges {
        display: flex;
        flex-wrap: wrap;
        gap: 9px;
    }

    .d5-badge {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        padding: 7px 11px;
        border-radius: 999px;
        color: #fff;
        background: rgba(255, 255, 255, .13);
        border: 1px solid rgba(255, 255, 255, .14);
        font-family: var(--d5-mono);
        font-size: .7rem;
        font-weight: 700;
    }

    .d5-bday-close {
        position: absolute;
        z-index: 4;
        right: 18px;
        top: 18px;
        width: 38px;
        height: 38px;
        border-radius: 50%;
        border: 1px solid rgba(255, 255, 255, .18);
        color: #fff;
        background: rgba(255, 255, 255, .08);
    }

    /* ---------- feature ---------- */
    .d5-feature-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
        perspective: 1300px;
    }

    .d5-feature {
        min-height: 100%;
    }

    .d5-feature .d5-pad {
        min-height: 265px;
        display: flex;
        flex-direction: column;
    }

    .d5-icon-cube {
        position: relative;
        width: 62px;
        height: 62px;
        margin-bottom: 24px;
        transform-style: preserve-3d;
        transform: rotateX(58deg) rotateZ(45deg);
    }

    .d5-icon-cube i {
        position: absolute;
        inset: 0;
        display: grid;
        place-items: center;
        border-radius: 18px;
        color: #fff;
        font-size: 1.3rem;
        background: linear-gradient(135deg, var(--d5-primary), var(--d5-cyan));
        box-shadow: 0 22px 48px -18px color-mix(in srgb, var(--d5-primary) 75%, black);
        transform: translateZ(30px) rotateZ(-45deg) rotateX(-58deg);
    }

    .d5-icon-cube::before,
    .d5-icon-cube::after {
        content: '';
        position: absolute;
        border-radius: 18px;
        background: color-mix(in srgb, var(--d5-primary) 68%, black);
    }

    .d5-icon-cube::before {
        inset: 0;
        transform: translateZ(0);
        opacity: .7;
    }

    .d5-icon-cube::after {
        inset: 0;
        transform: translateZ(-28px);
        opacity: .35;
        filter: blur(1px);
    }

    .d5-feature h4 {
        font-size: 1.22rem;
        margin-bottom: 11px;
    }

    .d5-feature p {
        margin: 0;
        font-size: .95rem;
    }

    /* ---------- notices ---------- */
    .d5-notice-band {
        background:
            radial-gradient(circle at 85% 10%, rgba(49, 230, 255, .16), transparent 30%),
            linear-gradient(180deg, rgba(255, 255, 255, .035), transparent);
        border-block: 1px solid rgba(255, 255, 255, .09);
    }

    .d5-notice-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
        perspective: 1200px;
    }

    .d5-notice-card {
        width: 100%;
        text-align: left;
        border: 0;
        color: inherit;
        cursor: pointer;
        font: inherit;
        background: none;
        padding: 0;
    }

    .d5-date {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 16px;
        padding: 7px 11px;
        border-radius: 999px;
        color: #06101F;
        background: linear-gradient(135deg, var(--d5-cyan), #fff);
        font-family: var(--d5-mono);
        font-weight: 700;
        font-size: .68rem;
        letter-spacing: .07em;
        text-transform: uppercase;
        box-shadow: 0 16px 38px -18px rgba(49, 230, 255, .8);
    }

    .d5-notice-card h4 {
        font-size: 1.2rem;
        margin-bottom: 10px;
    }

    .d5-notice-card p {
        display: -webkit-box;
        min-height: 96px;
        margin: 0;
        overflow: hidden;
        -webkit-line-clamp: 4;
        line-clamp: 4;
        -webkit-box-orient: vertical;
        font-size: .93rem;
    }

    .d5-read {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        margin-top: 18px;
        color: var(--d5-cyan);
        font-weight: 900;
        font-size: .87rem;
    }

    /* ---------- about ---------- */
    .d5-about-grid {
        display: grid;
        grid-template-columns: .92fr 1.08fr;
        gap: 58px;
        align-items: center;
        perspective: 1300px;
    }

    .d5-about-visual {
        position: relative;
        min-height: 420px;
        transform-style: preserve-3d;
    }

    .d5-about-img {
        position: absolute;
        inset: 34px 0 0 34px;
        width: calc(100% - 34px);
        height: calc(100% - 34px);
        object-fit: cover;
        border-radius: 34px;
        border: 1px solid rgba(255, 255, 255, .2);
        box-shadow: 0 44px 100px -48px rgba(0, 0, 0, .95);
        transform: rotateY(10deg) rotateX(6deg) translateZ(44px);
    }

    .d5-about-visual::before {
        content: '';
        position: absolute;
        inset: 0 34px 34px 0;
        border-radius: 34px;
        border: 1px solid rgba(255, 255, 255, .14);
        background:
            linear-gradient(135deg, color-mix(in srgb, var(--d5-primary) 46%, transparent), rgba(49, 230, 255, .12)),
            rgba(255, 255, 255, .055);
        transform: rotateY(-8deg) rotateX(7deg) translateZ(-30px);
    }

    .d5-about-visual::after {
        content: '';
        position: absolute;
        right: 0;
        bottom: -8px;
        width: 180px;
        height: 180px;
        border-radius: 50%;
        background: radial-gradient(circle at 30% 25%, #fff, var(--d5-pink) 18%, transparent 68%);
        opacity: .32;
        filter: blur(2px);
        transform: translateZ(80px);
    }

    .d5-about-copy p {
        font-size: 1.03rem;
    }

    /* ---------- fees ---------- */
    .d5-fees {
        background: linear-gradient(180deg, transparent, rgba(255, 255, 255, .035), transparent);
    }

    .d5-fee-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
        gap: 20px;
        perspective: 1200px;
    }

    .d5-fee-card .d5-pad {
        min-height: 220px;
    }

    .d5-fee-card h4 {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding-bottom: 16px;
        margin-bottom: 18px;
        border-bottom: 1px solid rgba(255, 255, 255, .12);
        font-size: 1.15rem;
    }

    .d5-fee-card h4 span {
        display: grid;
        place-items: center;
        width: 36px;
        height: 36px;
        border-radius: 13px;
        color: #07101F;
        background: linear-gradient(135deg, var(--d5-lime), #fff);
        font-family: var(--d5-mono);
        font-size: .78rem;
    }

    .d5-fee-row {
        display: flex;
        align-items: baseline;
        gap: 10px;
        margin-bottom: 12px;
        color: rgba(235, 239, 255, .66);
        font-family: var(--d5-mono);
        font-size: .86rem;
    }

    .d5-fee-leader {
        flex: 1;
        border-bottom: 1px dashed rgba(255, 255, 255, .18);
        transform: translateY(-4px);
    }

    .d5-fee-value {
        color: #fff;
        font-weight: 700;
    }

    /* ---------- teachers carousel ---------- */
    .teachers-carousel {
        position: relative;
    }

    .teachers-carousel .slick-list {
        padding: 22px 4px !important;
        margin: -22px -4px;
        overflow: hidden;
    }

    .teachers-carousel .slick-slide {
        padding: 6px 12px;
        outline: none;
        transform-style: preserve-3d;
    }

    .d5-teacher-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
        perspective: 1200px;
        transform-style: preserve-3d;
    }

    .d5-teacher {
        text-align: center;
    }

    .d5-teacher img {
        width: 112px;
        height: 112px;
        object-fit: cover;
        border-radius: 34px;
        margin: 0 auto 20px;
        border: 1px solid rgba(255, 255, 255, .24);
        box-shadow: 0 26px 60px -26px rgba(0, 0, 0, .9), 0 0 0 6px rgba(255, 255, 255, .06);
        transform: translateZ(44px) rotateX(7deg);
    }

    .d5-teacher h4 {
        font-size: 1.1rem;
        margin-bottom: 6px;
    }

    .d5-teacher .d5-qualification {
        margin: 0 0 4px;
        color: var(--d5-cyan);
        font-family: var(--d5-mono);
        font-size: .76rem;
        font-weight: 700;
        letter-spacing: .03em;
    }

    .d5-teacher .d5-position {
        margin: 0;
        font-size: .88rem;
        font-style: italic;
    }

    /* 3D Glassmorphic Navigation Arrows */
    .teachers-carousel .slick-prev,
    .teachers-carousel .slick-next {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        width: 48px;
        height: 48px;
        background: rgba(11, 16, 38, 0.85);
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid var(--d5-line-strong);
        border-radius: 50%;
        display: flex !important;
        align-items: center;
        justify-content: center;
        z-index: 10;
        box-shadow: 0 16px 36px -10px rgba(0, 0, 0, 0.85), inset 0 1px 0 rgba(255, 255, 255, 0.25);
        cursor: pointer;
        padding: 0;
        transform-style: preserve-3d;
        transition: transform .25s ease, background .25s ease, border-color .25s ease, box-shadow .25s ease;
    }

    .teachers-carousel .slick-prev {
        left: -22px;
    }

    .teachers-carousel .slick-next {
        right: -22px;
    }

    .teachers-carousel .slick-prev:hover,
    .teachers-carousel .slick-next:hover {
        background: rgba(255, 255, 255, 0.14);
        border-color: var(--d5-cyan);
        box-shadow: 0 20px 42px -10px color-mix(in srgb, var(--d5-cyan) 50%, black), inset 0 1px 0 rgba(255, 255, 255, 0.4);
        transform: translateY(-50%) scale(1.08);
    }

    .teachers-carousel .slick-prev::before {
        content: '\f053' !important;
        font-family: 'Font Awesome 5 Free', 'Font Awesome 6 Free', sans-serif !important;
        font-weight: 900;
        color: #fff !important;
        font-size: 1rem !important;
        opacity: 1 !important;
        line-height: 1 !important;
        transition: color .25s ease;
    }

    .teachers-carousel .slick-next::before {
        content: '\f054' !important;
        font-family: 'Font Awesome 5 Free', 'Font Awesome 6 Free', sans-serif !important;
        font-weight: 900;
        color: #fff !important;
        font-size: 1rem !important;
        opacity: 1 !important;
        line-height: 1 !important;
        transition: color .25s ease;
    }

    .teachers-carousel .slick-prev:hover::before,
    .teachers-carousel .slick-next:hover::before {
        color: var(--d5-cyan) !important;
    }

    .teachers-carousel .slick-prev i,
    .teachers-carousel .slick-next i {
        display: none !important;
    }

    .teachers-carousel .slick-disabled {
        opacity: 0.3;
        cursor: not-allowed;
        pointer-events: none;
    }

    /* 3D Futuristic Neon Dots */
    .teachers-carousel .slick-dots {
        position: static;
        margin-top: 32px;
        display: flex !important;
        align-items: center;
        justify-content: center;
        gap: 8px;
        list-style: none;
        padding: 0;
    }

    .teachers-carousel .slick-dots li {
        width: auto;
        height: auto;
        margin: 0;
        display: inline-flex;
    }

    .teachers-carousel .slick-dots li button {
        width: 12px;
        height: 12px;
        padding: 0;
        border-radius: 999px;
        background: rgba(255, 255, 255, 0.18);
        border: 1px solid rgba(255, 255, 255, 0.16);
        transition: all .28s cubic-bezier(0.16, 1, 0.3, 1);
        cursor: pointer;
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2);
        font-size: 0 !important;
        line-height: 0 !important;
        color: transparent !important;
    }

    .teachers-carousel .slick-dots li button::before {
        display: none !important;
    }

    .teachers-carousel .slick-dots li button:hover {
        background: rgba(255, 255, 255, 0.35);
        border-color: rgba(255, 255, 255, 0.4);
    }

    .teachers-carousel .slick-dots li.slick-active button {
        width: 34px;
        background: linear-gradient(90deg, var(--d5-primary), var(--d5-cyan));
        border-color: rgba(255, 255, 255, 0.5);
        box-shadow: 0 4px 18px color-mix(in srgb, var(--d5-cyan) 60%, transparent), inset 0 1px 0 rgba(255, 255, 255, 0.4);
    }

    /* ---------- gallery ---------- */
    .d5-gallery-grid {
        display: grid;
        grid-template-columns: repeat(6, 1fr);
        gap: 15px;
        perspective: 1200px;
    }

    .d5-gallery-item {
        position: relative;
        display: block;
        aspect-ratio: 1;
        overflow: hidden;
        border-radius: 24px;
        border: 1px solid rgba(255, 255, 255, .14);
        background: rgba(255, 255, 255, .06);
        box-shadow: 0 24px 55px -28px rgba(0, 0, 0, .85);
        transform-style: preserve-3d;
    }

    .d5-gallery-item img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transform: translateZ(18px) scale(1.001);
        transition: transform .5s ease, filter .5s ease;
    }

    .d5-gallery-item::after {
        content: '\f00e';
        position: absolute;
        inset: 0;
        display: grid;
        place-items: center;
        color: #fff;
        font-family: 'Font Awesome 5 Free';
        font-weight: 900;
        background: linear-gradient(180deg, rgba(4, 6, 15, 0), rgba(4, 6, 15, .62));
        opacity: 0;
        transform: translateZ(48px);
        transition: opacity .3s ease;
    }

    .d5-gallery-item:hover img {
        transform: translateZ(34px) scale(1.08);
        filter: saturate(1.2);
    }

    .d5-gallery-item:hover::after {
        opacity: 1;
    }

    /* ---------- contact ---------- */
    .d5-contact-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 22px;
        perspective: 1200px;
    }

    .d5-form .form-control,
    .d5-form textarea {
        width: 100%;
        border: 1px solid rgba(255, 255, 255, .14);
        border-radius: 18px;
        color: #fff;
        background: rgba(255, 255, 255, .065);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, .09);
        padding: 15px 16px;
        outline: none;
    }

    .d5-form .form-control::placeholder,
    .d5-form textarea::placeholder {
        color: rgba(235, 239, 255, .46);
    }

    .d5-form .form-control:focus,
    .d5-form textarea:focus {
        border-color: rgba(49, 230, 255, .62);
        box-shadow: 0 0 0 4px rgba(49, 230, 255, .12), inset 0 1px 0 rgba(255, 255, 255, .12);
    }

    .d5-info {
        display: grid;
        gap: 14px;
        margin: 22px 0;
        width: 100%;
        min-width: 0;
    }

    .d5-info-item {
        display: flex;
        gap: 14px;
        align-items: flex-start;
        padding: 15px;
        border: 1px solid rgba(255, 255, 255, .11);
        border-radius: 20px;
        background: rgba(255, 255, 255, .055);
        min-width: 0;
        width: 100%;
        box-sizing: border-box;
    }

    .d5-info-item > div {
        min-width: 0;
        flex: 1 1 auto;
    }

    .d5-info-icon {
        flex: 0 0 auto;
        display: grid;
        place-items: center;
        width: 45px;
        height: 45px;
        border-radius: 16px;
        color: #06101F;
        background: linear-gradient(135deg, var(--d5-cyan), #fff);
        box-shadow: 0 18px 40px -20px rgba(49, 230, 255, .85);
    }

    .d5-info-item h6 {
        margin: 0 0 3px;
        color: rgba(235, 239, 255, .56);
        font-family: var(--d5-mono);
        font-size: .68rem;
        letter-spacing: .1em;
        text-transform: uppercase;
    }

    .d5-info-item p,
    .d5-info-item a {
        margin: 0;
        color: #fff;
        font-weight: 800;
        word-break: break-word;
        overflow-wrap: anywhere;
    }

    .d5-map {
        overflow: hidden;
        border-radius: 24px;
        border: 1px solid rgba(255, 255, 255, .14);
        box-shadow: inset 0 0 0 1px rgba(255, 255, 255, .06);
        width: 100%;
        max-width: 100%;
        box-sizing: border-box;
    }

    .d5-map iframe {
        display: block;
        width: 100%;
        max-width: 100%;
        height: 230px;
        border: 0;
        filter: saturate(.85) contrast(1.06);
    }

    /* ---------- footer ---------- */
    .d5-footer {
        padding: 80px 0 28px;
        background:
            radial-gradient(circle at 50% 0%, color-mix(in srgb, var(--d5-primary) 30%, transparent), transparent 38%),
            #03040B;
        border-top: 1px solid rgba(255, 255, 255, .1);
    }

    .d5-footer h5 {
        margin: 0 0 18px;
        color: #fff;
        font-family: var(--d5-display);
        font-size: 1.08rem;
    }

    .d5-footer p,
    .d5-footer a {
        color: rgba(235, 239, 255, .66);
    }

    .d5-footer a:hover {
        color: var(--d5-cyan);
    }

    .d5-footer-brand {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 16px;
    }

    .d5-footer-brand img {
        width: 48px;
        height: 48px;
        object-fit: contain;
        border-radius: 15px;
        padding: 4px;
        background: #fff;
    }

    .d5-social {
        display: flex;
        gap: 9px;
        margin-top: 22px;
    }

    .d5-social a {
        display: grid;
        place-items: center;
        width: 42px;
        height: 42px;
        border: 1px solid rgba(255, 255, 255, .14);
        border-radius: 15px;
        background: rgba(255, 255, 255, .07);
        transition: transform .25s ease, background .25s ease, color .25s ease;
    }

    .d5-social a:hover {
        color: #06101F;
        background: #fff;
        transform: translateY(-4px) rotateX(12deg);
    }

    .d5-footer ul {
        list-style: none;
        margin: 0;
        padding: 0;
    }

    .d5-footer li {
        margin-bottom: 10px;
    }

    .d5-bottom {
        margin-top: 52px;
        padding-top: 24px;
        border-top: 1px solid rgba(255, 255, 255, .1);
        text-align: center;
    }

    /* ---------- floating / tabbar / modal ---------- */
    .d5-whatsapp {
        position: fixed;
        right: 22px;
        bottom: 22px;
        z-index: 950;
        display: grid;
        place-items: center;
        width: 58px;
        height: 58px;
        border-radius: 20px;
        color: #04130A;
        background: linear-gradient(135deg, #7CFFB2, #25D366);
        box-shadow: 0 24px 55px -20px rgba(37, 211, 102, .8);
        font-size: 1.45rem;
        transition: transform .25s ease;
    }

    .d5-whatsapp:hover {
        color: #04130A;
        transform: translateY(-4px) rotateX(14deg);
    }

    .d5-tabbar {
        display: none;
    }

    .d5-modal {
        position: fixed;
        inset: 0;
        z-index: 1400;
        display: grid;
        place-items: center;
        padding: 20px;
        background: rgba(2, 3, 8, .72);
        backdrop-filter: blur(12px);
        opacity: 0;
        visibility: hidden;
        transition: opacity .25s ease, visibility .25s;
    }

    .d5-modal.is-open {
        opacity: 1;
        visibility: visible;
    }

    .d5-modal-box {
        width: min(760px, 100%);
        max-height: min(82vh, 760px);
        overflow: auto;
        border-radius: 28px;
        border: 1px solid rgba(255, 255, 255, .16);
        background:
            radial-gradient(circle at 18% 0%, color-mix(in srgb, var(--d5-primary) 36%, transparent), transparent 38%),
            linear-gradient(145deg, rgba(255, 255, 255, .12), rgba(255, 255, 255, .05)),
            #080B1B;
        box-shadow: 0 55px 130px -55px rgba(0, 0, 0, 1);
        transform: translateY(24px) rotateX(8deg);
        transition: transform .25s ease;
    }

    .d5-modal.is-open .d5-modal-box {
        transform: none;
    }

    .d5-modal-head {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 18px;
        padding: 26px 26px 18px;
        border-bottom: 1px solid rgba(255, 255, 255, .1);
    }

    .d5-modal-head h3 {
        margin-top: 12px;
        font-size: 1.5rem;
    }

    .d5-modal-body {
        padding: 24px 26px 30px;
        color: rgba(235, 239, 255, .78);
        line-height: 1.8;
    }

    .d5-modal-close {
        flex: 0 0 auto;
        width: 42px;
        height: 42px;
        border: 1px solid rgba(255, 255, 255, .16);
        border-radius: 50%;
        color: #fff;
        background: rgba(255, 255, 255, .08);
    }

    /* ---------- responsive ---------- */
    @media (max-width: 991px) {
        .d5-menu {
            display: none;
        }

        .d5-nav-toggle {
            display: inline-flex;
        }

        .d5-logo span {
            display: none;
        }

        .d5-hero {
            min-height: auto;
            padding-top: 42px;
        }

        .d5-hero-grid,
        .d5-about-grid,
        .d5-contact-grid {
            grid-template-columns: minmax(0, 1fr);
        }

        .d5-hero-copy {
            text-align: center;
        }

        .d5-hero-lead,
        .d5-hero-stats {
            margin-left: auto;
            margin-right: auto;
        }

        .d5-hero-actions {
            justify-content: center;
        }

        .d5-frame {
            transform: none;
        }

        .d5-feature-grid,
        .d5-notice-grid,
        .d5-teacher-grid {
            grid-template-columns: 1fr 1fr;
        }

        .teachers-carousel .slick-prev,
        .teachers-carousel .slick-next {
            display: none !important;
        }

        .d5-gallery-grid {
            grid-template-columns: repeat(3, 1fr);
        }

        .d5-about-visual {
            min-height: 360px;
            max-width: 560px;
            margin-inline: auto;
            width: 100%;
        }
    }

    @media (max-width: 767px) {
        :root {
            --d5-nav-h: 70px;
        }

        body {
            padding-bottom: var(--d5-tab-h);
        }

        .d5-container {
            width: min(100% - 28px, 1180px);
        }

        .d5-section {
            padding: 66px 0;
        }

        .d5-pad {
            padding: 24px 18px;
        }

        .d5-info {
            gap: 12px;
            margin: 18px 0;
        }

        .d5-info-item {
            padding: 12px 14px;
            gap: 12px;
            border-radius: 16px;
        }

        .d5-info-icon {
            width: 40px;
            height: 40px;
            border-radius: 13px;
            font-size: .95rem;
        }

        .d5-info-item p,
        .d5-info-item a {
            font-size: .88rem;
            line-height: 1.45;
        }

        .d5-logo img {
            height: 40px;
        }

        .d5-logo span {
            display: none !important;
        }

        .d5-hero-copy h1 {
            font-size: clamp(2.2rem, 13vw, 3.4rem);
        }

        .d5-hero-stats,
        .d5-feature-grid,
        .d5-notice-grid,
        .d5-teacher-grid {
            grid-template-columns: 1fr;
        }

        .d5-frame {
            border-radius: 30px;
            padding: 12px;
        }

        .d5-slider {
            min-height: 360px;
            border-radius: 24px;
        }

        .d5-slide-img {
            inset: 14px 14px 66px;
            width: calc(100% - 28px);
            height: calc(100% - 80px);
            border-radius: 19px;
        }

        .d5-caption {
            left: 18px;
            right: 18px;
            bottom: 18px;
        }

        .d5-chip-open {
            left: 14px;
            top: -15px;
        }

        .d5-chip-count {
            right: 14px;
            bottom: -18px;
        }

        .d5-bday-inner {
            align-items: flex-start;
            flex-direction: column;
            text-align: left;
        }

        .d5-gallery-grid {
            grid-template-columns: repeat(2, 1fr);
        }

        .d5-whatsapp {
            bottom: calc(var(--d5-tab-h) + 16px);
            width: 52px;
            height: 52px;
            border-radius: 18px;
        }

        .d5-tabbar {
            position: fixed;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 1100;
            display: flex;
            align-items: center;
            justify-content: space-around;
            height: var(--d5-tab-h);
            padding: 0 8px;
            background: rgba(4, 6, 15, .86);
            border-top: 1px solid rgba(255, 255, 255, .12);
            backdrop-filter: blur(20px);
        }

        .d5-tabbar a {
            display: flex;
            min-width: 58px;
            align-items: center;
            flex-direction: column;
            gap: 4px;
            color: rgba(235, 239, 255, .64);
            font-family: var(--d5-mono);
            font-size: .62rem;
            font-weight: 700;
            letter-spacing: .04em;
            text-transform: uppercase;
        }

        .d5-tabbar a i {
            font-size: 1.02rem;
        }

        .d5-tabbar a.d5-tab-cta {
            width: 56px;
            height: 56px;
            margin-top: -30px;
            justify-content: center;
            border-radius: 20px;
            color: #fff;
            background: linear-gradient(135deg, var(--d5-primary), var(--d5-cyan));
            box-shadow: 0 20px 45px -20px color-mix(in srgb, var(--d5-primary) 90%, black);
        }

        .d5-tabbar a.d5-tab-cta span {
            display: none;
        }
    }
</style>

<?php include_once(__DIR__ . '/../../../includes/header-close.php'); ?>

<div class="design5-page" id="top">
    <header class="d5-nav" id="d5Nav">
        <div class="d5-container d5-nav-inner">
            <a href="#top" class="d5-logo" aria-label="<?= safe_htmlspecialchars($schoolInfo['name'] ?? 'School') ?>">
                <img src="<?= $logo_rectangle ?>" alt="School Logo" onerror="this.style.display='none'">
                <span><?= safe_htmlspecialchars($schoolInfo['name'] ?? '') ?></span>
            </a>

            <ul class="d5-menu">
                <li><a class="d5-nav-link" href="#about">About</a></li>
                <li><a class="d5-nav-link" href="#academics">Academics</a></li>
                <li class="d5-has-drop">
                    <a class="d5-nav-link" href="#teachers">Teachers <i class="fas fa-chevron-down" style="font-size:.62rem"></i></a>
                    <div class="d5-drop">
                        <?php if ($showTeachers): ?>
                            <a href="#teachers"><i class="fas fa-users"></i> All Teachers</a>
                        <?php endif; ?>
                        <?php if ($teacherApplication): ?>
                            <a href="enquiries/form/teacher-application.php"><i class="fas fa-graduation-cap"></i> Apply as Teacher</a>
                            <a href="enquiries/form/track-teacher-application.php"><i class="fas fa-magnifying-glass-chart"></i> Track / Edit Application</a>
                        <?php endif; ?>
                    </div>
                </li>
                <li class="d5-has-drop">
                    <a class="d5-nav-link" href="#gallery">Gallery <i class="fas fa-chevron-down" style="font-size:.62rem"></i></a>
                    <div class="d5-drop">
                        <a href="pages/photo-gallery.php"><i class="fas fa-camera-retro"></i> Photo Gallery</a>
                        <a href="pages/video-gallery.php"><i class="fas fa-video"></i> Video Gallery</a>
                    </div>
                </li>
                <li><a class="d5-nav-link" href="#notices">Notices</a></li>
                <li><a class="d5-nav-link" href="#contact">Contact</a></li>
            </ul>

            <div class="d5-nav-actions">
                <?php if ($adminLogin): ?>
                    <div class="dropdown d-none d-lg-inline-flex">
                        <a href="#" class="d5-btn d5-btn-primary dropdown-toggle" data-bs-toggle="dropdown" data-bs-display="static" aria-expanded="false" style="min-height:44px;padding:0 18px;">
                            <i class="fa-solid fa-lock"></i> Login
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end d5-dropdown-menu">
                            <li><a class="dropdown-item d5-dropdown-item" href="parent/"><i class="fa-solid fa-user-shield"></i> <span>Parent Login</span></a></li>
                            <li><a class="dropdown-item d5-dropdown-item" href="management/"><i class="fa-solid fa-cog"></i> <span>Admin Login</span></a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="parent/" class="d5-btn d5-btn-primary d-none d-lg-inline-flex" style="min-height:44px;padding:0 18px;"><i class="fa-solid fa-user-shield"></i> Login</a>
                <?php endif; ?>
                <button class="d5-nav-toggle" id="d5NavOpen" type="button" aria-label="Open menu"><i class="fas fa-bars"></i></button>
            </div>
        </div>
    </header>

    <div class="d5-overlay" id="d5Overlay" aria-hidden="true">
        <div class="d5-overlay-top">
            <img src="<?= $logo_rectangle ?>" alt="School Logo" onerror="this.style.display='none'">
            <button class="d5-nav-toggle" id="d5NavClose" type="button" aria-label="Close menu" style="display:inline-flex;"><i class="fas fa-times"></i></button>
        </div>
        <ul class="d5-overlay-links">
            <li><a href="#about"><i class="fas fa-school"></i> About</a></li>
            <li><a href="#academics"><i class="fas fa-book-open"></i> Academics</a></li>
            <?php if ($showTeachers): ?>
                <li><a href="#teachers"><i class="fas fa-chalkboard-teacher"></i> Teachers</a></li>
            <?php endif; ?>
            <?php if ($teacherApplication): ?>
                <li><a class="d5-sub" href="enquiries/form/teacher-application.php">Apply as Teacher</a></li>
                <li><a class="d5-sub" href="enquiries/form/track-teacher-application.php">Track / Edit Application</a></li>
            <?php endif; ?>
            <li><a href="pages/photo-gallery.php"><i class="fas fa-images"></i> Photo Gallery</a></li>
            <li><a class="d5-sub" href="pages/video-gallery.php">Video Gallery</a></li>
            <li><a href="#notices"><i class="fas fa-bullhorn"></i> Notices</a></li>
            <li><a href="#contact"><i class="fas fa-paper-plane"></i> Contact</a></li>
            <?php if ($adminLogin): ?>
                <li><a href="#"><i class="fa-solid fa-lock"></i> Login</a></li>
                <li><a class="d5-sub" href="parent/"><i class="fa-solid fa-user-shield"></i> Parent Login</a></li>
                <li><a class="d5-sub" href="management/"><i class="fa-solid fa-cog"></i> Admin Login</a></li>
            <?php else: ?>
                <li><a href="parent/"><i class="fa-solid fa-user-shield"></i> Login</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <section class="d5-hero" id="home">
        <div class="d5-container d5-hero-grid">
            <div class="d5-hero-copy d5-reveal">
                <span class="d5-kicker">Welcome to <?= safe_htmlspecialchars($schoolInfo['name'] ?? 'Our School') ?></span>
                <h1>Learning in<br><span class="d5-grad">another dimension.</span></h1>
                <p class="d5-hero-lead">A future-facing campus where dedicated teachers, modern classrooms and joyful curiosity come together around every child.</p>
                <div class="d5-hero-actions">
                    <?php if ($admissionOpen): ?>
                        <a href="enquiries/form/admission-enquiry.php" class="d5-btn d5-btn-primary"><i class="fas fa-pen-nib"></i> Apply for Admission</a>
                    <?php endif; ?>
                    <a href="#contact" class="d5-btn"><i class="fas fa-paper-plane"></i> Contact Us</a>
                </div>
                <div class="d5-hero-stats">
                    <?php if (!empty($classes)): ?>
                        <div class="d5-stat">
                            <strong data-count="<?= count($classes) ?>"><?= count($classes) ?></strong>
                            <span>Classes</span>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($teachers)): ?>
                        <div class="d5-stat">
                            <strong data-count="<?= count($teachers) ?>"><?= count($teachers) ?>+</strong>
                            <span>Teachers</span>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($galley_images)): ?>
                        <div class="d5-stat">
                            <strong data-count="<?= count($galley_images) ?>"><?= count($galley_images) ?>+</strong>
                            <span>Moments</span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="d5-hero-stage d5-reveal" data-depth-stage>
                <span class="d5-orb d5-orb-a" data-depth="38"></span>
                <span class="d5-orb d5-orb-b" data-depth="70"></span>
                <span class="d5-orb d5-orb-c" data-depth="54"></span>

                <div class="d5-frame d5-tilt" data-tilt data-max-tilt="5">
                    <div class="d5-slider" id="d5HeroSlider">
                        <?php if (!empty($carousel_images)): ?>
                            <?php foreach ($carousel_images as $index => $image): ?>
                                <div class="d5-slide <?= $index === 0 ? 'is-active' : '' ?>">
                                    <div class="d5-slide-bg" style="background-image:url('<?= safe_htmlspecialchars($image['image_url']) ?>')"></div>
                                    <img
                                        class="d5-slide-img"
                                        src="<?= $image['image_url'] ?>"
                                        alt="<?= safe_htmlspecialchars($image['caption'] ?? ($schoolInfo['name'] ?? 'School')) ?>"
                                        loading="<?= $index === 0 ? 'eager' : 'lazy' ?>"
                                        data-fancybox="d5-hero-gallery"
                                        data-caption="<?= safe_htmlspecialchars($image['caption'] ?? ($schoolInfo['name'] ?? 'School')) ?>">
                                    <div class="d5-caption">
                                        <span><?= safe_htmlspecialchars($image['caption'] ?? ($schoolInfo['name'] ?? 'School')) ?></span>
                                        <?php if (count($carousel_images) > 1): ?>
                                            <span class="d5-dots" aria-label="Hero slides">
                                                <?php foreach ($carousel_images as $dotIndex => $dotImage): ?>
                                                    <button class="d5-dot <?= $dotIndex === 0 ? 'is-active' : '' ?>" type="button" data-slide-to="<?= $dotIndex ?>" aria-label="Go to slide <?= $dotIndex + 1 ?>"></button>
                                                <?php endforeach; ?>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="d5-slide is-active">
                                <div class="d5-empty-slide">
                                    <div>
                                        <i class="fas fa-school" style="font-size:3rem;color:var(--d5-cyan);"></i>
                                        <h3 style="margin-top:18px;">Welcome to <?= safe_htmlspecialchars($schoolInfo['name'] ?? 'School') ?></h3>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ($admissionOpen): ?>
                    <a href="enquiries/form/admission-enquiry.php" class="d5-chip-float d5-chip-open">
                        <i class="fas fa-circle"></i>
                        <span>Admissions Open</span>
                    </a>
                <?php endif; ?>

                <?php if (!empty($teachers)): ?>
                    <div class="d5-chip-float d5-chip-count">
                        <strong><?= count($teachers) ?>+</strong>
                        <small>Teachers</small>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php if (!empty($birthdayStudents)): ?>
        <section class="d5-birthday" id="birthday-section">
            <div class="d5-container">
                <?php foreach ($birthdayStudents as $birthday_student): ?>
                    <?php
                    $student_name = $birthday_student['name'] ?? $birthday_student['student_name'] ?? 'Student';
                    $first_letter = mb_substr($student_name, 0, 1, 'UTF-8');
                    $student_image_db = $birthday_student['photo'] ?? $birthday_student['student_image'] ?? '';
                    $placeholder = 'https://placehold.co/160x160/' . str_replace('#', '', $theme_color) . '/FFFFFF?text=' . urlencode($first_letter);
                    $student_photo = !empty($student_image_db) ? 'uploads/students/' . $student_image_db : $placeholder;
                    ?>
                    <div class="d5-bday-card d5-reveal">
                        <button class="d5-bday-close" type="button" data-close-birthday aria-label="Close birthday section"><i class="fas fa-times"></i></button>
                        <div class="d5-bday-inner">
                            <div class="d5-bday-photo-wrap">
                                <img class="d5-bday-photo" src="<?= $student_photo ?>" alt="<?= safe_htmlspecialchars($student_name) ?>" data-fancybox="d5-birthday" data-caption="<?= safe_htmlspecialchars($student_name) ?>" onerror="this.onerror=null;this.src='<?= $placeholder ?>';">
                            </div>
                            <div>
                                <h3>Happy Birthday 🎂</h3>
                                <h4><?= safe_htmlspecialchars($student_name) ?></h4>
                                <div class="d5-badges">
                                    <span class="d5-badge"><i class="fas fa-graduation-cap"></i> Class <?= safe_htmlspecialchars($birthday_student['class_name'] ?? 'N/A') ?></span>
                                    <?php if (!empty($birthday_student['section_name'])): ?>
                                        <span class="d5-badge"><i class="fas fa-layer-group"></i> Section <?= safe_htmlspecialchars($birthday_student['section_name']) ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <section class="d5-section" id="why-us">
        <div class="d5-container">
            <div class="d5-head d5-reveal">
                <span class="d5-kicker">Why families choose us</span>
                <h2>Built like a world, tuned for a child</h2>
                <p>Three-dimensional thinking, warm mentoring and a safe campus designed around how students actually learn.</p>
            </div>
            <div class="d5-feature-grid">
                <div class="d5-card d5-feature d5-tilt d5-reveal" data-tilt>
                    <div class="d5-pad">
                        <div class="d5-icon-cube"><i class="fas fa-graduation-cap"></i></div>
                        <h4>Quality Education</h4>
                        <p>Modern teaching methods and well-equipped classrooms keep the curriculum close to every learner.</p>
                    </div>
                </div>
                <div class="d5-card d5-feature d5-tilt d5-reveal" data-tilt>
                    <div class="d5-pad">
                        <div class="d5-icon-cube"><i class="fas fa-user-friends"></i></div>
                        <h4>Experienced Teachers</h4>
                        <p>A qualified, dedicated faculty stays personally invested in each student's progress.</p>
                    </div>
                </div>
                <div class="d5-card d5-feature d5-tilt d5-reveal" data-tilt>
                    <div class="d5-pad">
                        <div class="d5-icon-cube"><i class="fas fa-shield-alt"></i></div>
                        <h4>Safe & Fun Place</h4>
                        <p>A secure, stimulating environment where children feel confident, curious and happy.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="d5-section d5-notice-band" id="notices">
        <div class="d5-container">
            <div class="d5-head d5-reveal">
                <span class="d5-kicker">Notice Board</span>
                <h2>Signals from campus</h2>
            </div>
            <div class="d5-notice-grid">
                <?php
                $noticeCount = 0;
                foreach ($notices as $notice):
                    if ($noticeCount === 3) break;
                    $noticeCount++;
                    $noticeDate = (new DateTime($notice['notice_date']))->format('d M Y');
                    $noticeDateLong = (new DateTime($notice['notice_date']))->format('d F Y');
                ?>
                    <button
                        type="button"
                        class="d5-card d5-notice-card d5-tilt d5-reveal"
                        data-tilt
                        data-notice-title="<?= safe_htmlspecialchars($notice['title']) ?>"
                        data-notice-content="<?= safe_htmlspecialchars($notice['content']) ?>"
                        data-notice-date="<?= safe_htmlspecialchars($noticeDateLong) ?>">
                        <span class="d5-pad" style="display:block;">
                            <span class="d5-date"><i class="far fa-calendar-alt"></i> <?= $noticeDate ?></span>
                            <h4><?= safe_htmlspecialchars($notice['title']) ?></h4>
                            <p><?= safe_htmlspecialchars($notice['content']) ?></p>
                            <span class="d5-read">Read More <i class="fas fa-arrow-right"></i></span>
                        </span>
                    </button>
                <?php endforeach; ?>
            </div>
            <div class="text-center mt-5">
                <a href="pages/notices.php" class="d5-btn">View All Notices</a>
            </div>
        </div>
    </section>

    <section class="d5-section" id="about">
        <div class="d5-container d5-about-grid">
            <div class="d5-about-visual d5-reveal">
                <?php if ($fallbackHeroImage): ?>
                    <img class="d5-about-img" src="<?= $fallbackHeroImage ?>" alt="<?= safe_htmlspecialchars($schoolInfo['name'] ?? 'School') ?>" loading="lazy" data-fancybox="d5-about" data-caption="<?= safe_htmlspecialchars($schoolInfo['name'] ?? 'School') ?>">
                <?php else: ?>
                    <div class="d5-about-img d5-glass" style="display:grid;place-items:center;">
                        <i class="fas fa-school" style="font-size:3rem;color:var(--d5-cyan);"></i>
                    </div>
                <?php endif; ?>
            </div>
            <div class="d5-about-copy d5-reveal">
                <div class="d5-head d5-left" style="margin:0 0 20px;">
                    <span class="d5-kicker">About Our School</span>
                    <h2><?= safe_htmlspecialchars($schoolInfo['name'] ?? 'Our School') ?></h2>
                </div>
                <p><?= nl2br($schoolInfo['description'] ?? '') ?></p>
            </div>
        </div>
    </section>

    <?php if (!$hideFees): ?>
        <section class="d5-section d5-fees" id="academics">
            <div class="d5-container">
                <div class="d5-head d5-reveal">
                    <span class="d5-kicker">Academics</span>
                    <h2>Fee structure, crystal clear</h2>
                    <p>Monthly and admission fees for every class, displayed upfront.</p>
                </div>
                <div class="d5-fee-grid">
                    <?php foreach ($classes as $class): ?>
                        <div class="d5-card d5-fee-card d5-tilt d5-reveal" data-tilt>
                            <div class="d5-pad">
                                <h4><?= safe_htmlspecialchars($class['class_name']) ?> <span><i class="fas fa-tag"></i></span></h4>
                                <div class="d5-fee-row">
                                    <span>Monthly Fee</span>
                                    <span class="d5-fee-leader"></span>
                                    <span class="d5-fee-value">₹<?= number_format($class['monthly_fee']) ?></span>
                                </div>
                                <div class="d5-fee-row">
                                    <span>Admission Fee</span>
                                    <span class="d5-fee-leader"></span>
                                    <span class="d5-fee-value">₹<?= number_format($class['admission_fee']) ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <?php if ($showTeachers && !empty($teachers)): ?>
        <section class="d5-section" id="teachers">
            <div class="d5-container">
                <div class="d5-head d5-reveal">
                    <span class="d5-kicker">Our Faculty</span>
                    <h2>Meet the mentors</h2>
                </div>
                <div class="teachers-carousel d5-reveal">
                    <?php
                    $i = 0;
                    $totalTeachers = count($teachers);
                    foreach ($teachers as $index => $teacher) {
                        if ($i % 6 === 0) {
                            echo '<div><div class="d5-teacher-grid">';
                        }
                        $teacherImage = $teacher['teacher_image'] ?? '';
                        $teacherPlaceholder = 'https://placehold.co/180x180/' . str_replace('#', '', $theme_color) . '/FFFFFF?text=' . urlencode(substr($teacher['name'], 0, 1));
                        $teacher_dp_url = ($teacherImage === '' || $teacherImage === 'default_teacher_dp.jpg')
                            ? $teacherPlaceholder
                            : 'uploads/teachers/' . $teacherImage;
                    ?>
                        <div class="d5-card d5-teacher d5-tilt" data-tilt>
                            <div class="d5-pad">
                                <img src="<?= $teacher_dp_url ?>" alt="<?= safe_htmlspecialchars($teacher['name']) ?>" loading="lazy" data-fancybox="d5-teachers" data-caption="<?= safe_htmlspecialchars($teacher['name']) ?>" onerror="this.onerror=null;this.src='<?= $teacherPlaceholder ?>';">
                                <h4><?= safe_htmlspecialchars($teacher['name']) ?></h4>
                                <p class="d5-qualification"><?= safe_htmlspecialchars($teacher['qualification']) ?></p>
                                <p class="d5-position"><?= safe_htmlspecialchars($teacher['position_in_school']) ?></p>
                            </div>
                        </div>
                    <?php
                        $i++;
                        if ($i % 6 === 0 || $i === $totalTeachers) {
                            echo '</div></div>';
                        }
                    }
                    ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <section class="d5-section" id="gallery">
        <div class="d5-container">
            <div class="d5-head d5-reveal">
                <span class="d5-kicker">Moments</span>
                <h2>Gallery in depth</h2>
            </div>
            <div class="d5-gallery-grid">
                <?php
                $galleryCount = 0;
                foreach ($galley_images as $image):
                    if ($galleryCount === 6) break;
                    $galleryCount++;
                ?>
                    <a class="d5-gallery-item d5-tilt d5-reveal" data-tilt data-max-tilt="7" href="<?= $image['photo_url'] ?>" data-fancybox="d5-gallery" data-caption="<?= safe_htmlspecialchars($image['caption']) ?>">
                        <img src="<?= $image['thumbnail_url'] ?>" alt="<?= safe_htmlspecialchars($image['caption']) ?>" loading="lazy">
                    </a>
                <?php endforeach; ?>
            </div>
            <div class="text-center mt-5">
                <a href="pages/photo-gallery.php" class="d5-btn d5-btn-primary">View More Photos</a>
            </div>
        </div>
    </section>

    <section class="d5-section" id="contact">
        <div class="d5-container">
            <div class="d5-head d5-reveal">
                <span class="d5-kicker">Get in touch</span>
                <h2>Contact us</h2>
            </div>
            <div class="d5-contact-grid">
                <div class="d5-card d5-tilt d5-reveal" data-tilt data-max-tilt="3">
                    <div class="d5-pad">
                        <h4 style="margin-bottom:22px;">Send us a message</h4>
                        <form class="d5-form" action="mailto:<?= safe_htmlspecialchars($schoolInfo['email'] ?? '') ?>" method="post" enctype="text/plain">
                            <input class="form-control mb-3" type="text" name="name" placeholder="Your Name" required>
                            <input class="form-control mb-3" type="tel" name="phone-number" placeholder="Your Phone" required>
                            <textarea class="mb-3" name="message" rows="5" placeholder="Your Message" required></textarea>
                            <button class="d5-btn d5-btn-primary w-100" type="submit">Send Message</button>
                        </form>
                    </div>
                </div>
                <div class="d5-card d5-tilt d5-reveal" data-tilt data-max-tilt="3">
                    <div class="d5-pad">
                        <h4>Find us here</h4>
                        <div class="d5-info">
                            <div class="d5-info-item">
                                <span class="d5-info-icon"><i class="fas fa-map-marker-alt"></i></span>
                                <div>
                                    <h6>Address</h6>
                                    <p><?= safe_htmlspecialchars($schoolInfo['address'] ?? '') ?></p>
                                </div>
                            </div>
                            <div class="d5-info-item">
                                <span class="d5-info-icon"><i class="fas fa-phone-alt"></i></span>
                                <div>
                                    <h6>Phone</h6>
                                    <p><?= safe_htmlspecialchars($schoolInfo['phone'] ?? '') ?><?= !empty($schoolInfo['alternate_phone']) ? ' / ' . safe_htmlspecialchars($schoolInfo['alternate_phone']) : '' ?></p>
                                </div>
                            </div>
                            <div class="d5-info-item">
                                <span class="d5-info-icon"><i class="fas fa-envelope"></i></span>
                                <div>
                                    <h6>Email</h6>
                                    <p><?= safe_htmlspecialchars($schoolInfo['email'] ?? '') ?></p>
                                </div>
                            </div>
                        </div>
                        <?php if (!empty($schoolInfo['google_map_embed_link'])): ?>
                            <div class="d5-map">
                                <iframe src="<?= $schoolInfo['google_map_embed_link'] ?>" loading="lazy" allowfullscreen referrerpolicy="no-referrer-when-downgrade" title="School map"></iframe>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer class="d5-footer">
        <div class="d5-container">
            <div class="row">
                <div class="col-lg-4 mb-5 mb-lg-0 text-center text-lg-start">
                    <div class="d5-footer-brand justify-content-center justify-content-lg-start">
                        <img src="<?= $logo_square ?>" alt="School Logo" onerror="this.style.display='none'">
                        <h5 style="margin:0;"><?= safe_htmlspecialchars($schoolInfo['name'] ?? '') ?></h5>
                    </div>
                    <p>Building a bright future, one child at a time.</p>
                    <div class="d5-social justify-content-center justify-content-lg-start">
                        <?php if (!empty($schoolInfo['facebook'])): ?><a href="<?= $schoolInfo['facebook'] ?>" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a><?php endif; ?>
                        <?php if (!empty($schoolInfo['whatsapp'])): ?><a href="<?= $schoolInfo['whatsapp'] ?>" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a><?php endif; ?>
                        <?php if (!empty($schoolInfo['instagram'])): ?><a href="<?= $schoolInfo['instagram'] ?>" aria-label="Instagram"><i class="fab fa-instagram"></i></a><?php endif; ?>
                        <?php if (!empty($schoolInfo['youtube'])): ?><a href="<?= $schoolInfo['youtube'] ?>" aria-label="YouTube"><i class="fab fa-youtube"></i></a><?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-2 text-center text-lg-start mb-4">
                    <h5>Quick Links</h5>
                    <ul>
                        <li><a href="pages/about-us.php">About Us</a></li>
                        <li><a href="pages/contact-us.php">Contact Us</a></li>
                        <li><a href="pages/privacy-and-policy.php">Privacy & Policy</a></li>
                        <li><a href="pages/terms-and-conditions.php">Terms & Conditions</a></li>
                        <li><a href="pages/refund-and-cancellation.php">Refund Policy</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 text-center text-lg-start mb-4">
                    <h5>Contact</h5>
                    <ul>
                        <?php if (!empty($schoolInfo['phone'])): ?><li><a href="tel:<?= $schoolInfo['phone'] ?>"><?= $schoolInfo['phone'] ?></a></li><?php endif; ?>
                        <?php if (!empty($schoolInfo['alternate_phone'])): ?><li><a href="tel:<?= $schoolInfo['alternate_phone'] ?>"><?= $schoolInfo['alternate_phone'] ?></a></li><?php endif; ?>
                        <?php if (!empty($schoolInfo['email'])): ?><li><a href="mailto:<?= $schoolInfo['email'] ?>"><?= $schoolInfo['email'] ?></a></li><?php endif; ?>
                    </ul>
                </div>
                <div class="col-lg-3 text-center text-lg-start">
                    <a target="_blank" href="<?= BASE_URL ?>/apps/" class="d5-btn d5-btn-primary"><i class="fa-brands fa-google-play"></i> Download Apps</a>
                </div>
            </div>
            <div class="d5-bottom">
                <p>&copy; <?= date('Y') ?> <?= safe_htmlspecialchars($schoolInfo['name'] ?? '') ?> | Developed with <i class="fas fa-heart" style="color:#FF5D9E;"></i> by <a href="https://schoolsongi.com" style="color:var(--d5-amber);">School Songi</a></p>
            </div>
        </div>
    </footer>

    <?php if (!empty($schoolInfo['whatsapp'])): ?>
        <a href="<?= $schoolInfo['whatsapp'] ?>" target="_blank" class="d5-whatsapp" aria-label="Chat on WhatsApp"><i class="fab fa-whatsapp"></i></a>
    <?php endif; ?>

    <nav class="d5-tabbar" aria-label="Mobile quick navigation">
        <a href="#home"><i class="fas fa-house"></i><span>Home</span></a>
        <a href="#notices"><i class="fas fa-bullhorn"></i><span>Notices</span></a>
        <?php if ($admissionOpen): ?>
            <a class="d5-tab-cta" href="enquiries/form/admission-enquiry.php"><i class="fas fa-pen-nib"></i><span>Apply</span></a>
        <?php else: ?>
            <a class="d5-tab-cta" href="#contact"><i class="fas fa-paper-plane"></i><span>Contact</span></a>
        <?php endif; ?>
        <a href="#gallery"><i class="fas fa-images"></i><span>Gallery</span></a>
        <a href="<?= BASE_URL ?>/apps/"><i class="fa-solid fa-mobile-alt"></i><span>Apps</span></a>
    </nav>

    <div class="d5-modal" id="d5NoticeModal" aria-hidden="true">
        <div class="d5-modal-box" role="dialog" aria-modal="true" aria-labelledby="d5NoticeTitle">
            <div class="d5-modal-head">
                <div>
                    <span class="d5-date" id="d5NoticeDate"></span>
                    <h3 id="d5NoticeTitle"></h3>
                </div>
                <button class="d5-modal-close" type="button" data-d5-modal-close aria-label="Close"><i class="fas fa-times"></i></button>
            </div>
            <div class="d5-modal-body" id="d5NoticeBody"></div>
        </div>
    </div>
</div>

<script>
    (function() {
        document.documentElement.classList.add('d5-js');

        var nav = document.getElementById('d5Nav');
        var overlay = document.getElementById('d5Overlay');
        var openBtn = document.getElementById('d5NavOpen');
        var closeBtn = document.getElementById('d5NavClose');

        function closeOverlay() {
            if (!overlay) return;
            overlay.classList.remove('is-open');
            overlay.setAttribute('aria-hidden', 'true');
            document.body.style.overflow = '';
        }

        if (openBtn && overlay) {
            openBtn.addEventListener('click', function() {
                overlay.classList.add('is-open');
                overlay.setAttribute('aria-hidden', 'false');
                document.body.style.overflow = 'hidden';
            });
        }
        if (closeBtn) closeBtn.addEventListener('click', closeOverlay);
        if (overlay) {
            overlay.querySelectorAll('a').forEach(function(link) {
                link.addEventListener('click', closeOverlay);
            });
        }

        window.addEventListener('scroll', function() {
            if (nav) nav.classList.toggle('is-scrolled', window.scrollY > 12);
        }, {
            passive: true
        });

        document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
            anchor.addEventListener('click', function(event) {
                var id = anchor.getAttribute('href');
                if (!id || id === '#') return;
                var target = document.querySelector(id);
                if (!target) return;
                event.preventDefault();
                closeOverlay();
                var offset = window.innerWidth < 992 ? 62 : 82;
                window.scrollTo({
                    top: target.getBoundingClientRect().top + window.scrollY - offset,
                    behavior: 'smooth'
                });
            });
        });

        // Teachers Carousel with Slick
        if (window.jQuery && typeof jQuery.fn.slick === 'function') {
            $('.teachers-carousel').each(function() {
                var $carousel = $(this);
                var slideCount = $carousel.children('div').length;
                $carousel.slick({
                    dots: true,
                    infinite: true,
                    speed: 300,
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    arrows: true,
                    prevArrow: '<button type="button" class="slick-prev" aria-label="Previous"><i class="fas fa-chevron-left"></i></button>',
                    nextArrow: '<button type="button" class="slick-next" aria-label="Next"><i class="fas fa-chevron-right"></i></button>',
                    responsive: [{
                        breakpoint: 992,
                        settings: {
                            arrows: false
                        }
                    }]
                });
            });
        }

        // 3D tilt cards
        var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        if (!reduceMotion) {
            function bindTilt(card) {
                if (card._hasTilt) return;
                card._hasTilt = true;
                var max = parseFloat(card.getAttribute('data-max-tilt') || '8');
                var raf = null;

                card.addEventListener('pointermove', function(event) {
                    var rect = card.getBoundingClientRect();
                    var px = (event.clientX - rect.left) / rect.width - 0.5;
                    var py = (event.clientY - rect.top) / rect.height - 0.5;
                    if (raf) cancelAnimationFrame(raf);
                    raf = requestAnimationFrame(function() {
                        card.style.transform = 'perspective(1100px) rotateX(' + (-py * max).toFixed(2) + 'deg) rotateY(' + (px * max).toFixed(2) + 'deg) translateY(-4px)';
                    });
                });

                card.addEventListener('pointerleave', function() {
                    if (raf) cancelAnimationFrame(raf);
                    card.style.transform = 'perspective(1100px) rotateX(0deg) rotateY(0deg) translateY(0)';
                });
            }

            document.querySelectorAll('[data-tilt]').forEach(bindTilt);

            // Hero orbital parallax
            document.querySelectorAll('[data-depth-stage]').forEach(function(stage) {
                var layers = stage.querySelectorAll('[data-depth]');
                stage.addEventListener('pointermove', function(event) {
                    var rect = stage.getBoundingClientRect();
                    var px = (event.clientX - rect.left) / rect.width - 0.5;
                    var py = (event.clientY - rect.top) / rect.height - 0.5;
                    layers.forEach(function(layer) {
                        var depth = parseFloat(layer.getAttribute('data-depth') || '30');
                        layer.style.translate = (px * depth) + 'px ' + (py * depth) + 'px';
                    });
                });
                stage.addEventListener('pointerleave', function() {
                    layers.forEach(function(layer) {
                        layer.style.translate = '0 0';
                    });
                });
            });
        }

        // Self-contained hero slider
        var slider = document.getElementById('d5HeroSlider');
        if (slider) {
            var slides = Array.prototype.slice.call(slider.querySelectorAll('.d5-slide'));
            var dots = Array.prototype.slice.call(slider.querySelectorAll('.d5-dot'));
            var active = 0;
            var timer = null;

            function go(index) {
                if (!slides.length) return;
                active = (index + slides.length) % slides.length;
                slides.forEach(function(slide, i) {
                    slide.classList.toggle('is-active', i === active);
                });
                dots.forEach(function(dot, i) {
                    dot.classList.toggle('is-active', i === active);
                });
            }

            function start() {
                if (slides.length < 2 || timer) return;
                timer = setInterval(function() {
                    go(active + 1);
                }, 5200);
            }

            function stop() {
                if (timer) clearInterval(timer);
                timer = null;
            }

            dots.forEach(function(dot) {
                dot.addEventListener('click', function(event) {
                    event.preventDefault();
                    event.stopPropagation();
                    stop();
                    go(parseInt(dot.getAttribute('data-slide-to') || '0', 10));
                    start();
                });
            });

            slider.addEventListener('pointerenter', stop);
            slider.addEventListener('pointerleave', start);
            start();
        }

        // Scroll reveal
        if ('IntersectionObserver' in window) {
            var revealObserver = new IntersectionObserver(function(entries, observer) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-in');
                        observer.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.14
            });
            document.querySelectorAll('.d5-reveal').forEach(function(el) {
                revealObserver.observe(el);
            });
        } else {
            document.querySelectorAll('.d5-reveal').forEach(function(el) {
                el.classList.add('is-in');
            });
        }

        // Animated counters
        function animateCount(el) {
            var target = parseInt(el.getAttribute('data-count') || '0', 10);
            if (!target || reduceMotion) return;
            var start = null;
            var suffix = el.textContent.indexOf('+') !== -1 ? '+' : '';

            function step(ts) {
                if (!start) start = ts;
                var progress = Math.min((ts - start) / 1100, 1);
                var eased = 1 - Math.pow(1 - progress, 3);
                el.textContent = Math.round(target * eased) + suffix;
                if (progress < 1) requestAnimationFrame(step);
            }
            requestAnimationFrame(step);
        }

        if ('IntersectionObserver' in window) {
            var countObserver = new IntersectionObserver(function(entries, observer) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        animateCount(entry.target);
                        observer.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.5
            });
            document.querySelectorAll('[data-count]').forEach(function(el) {
                countObserver.observe(el);
            });
        }

        // Birthday close
        document.querySelectorAll('[data-close-birthday]').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var section = document.getElementById('birthday-section');
                if (section) section.style.display = 'none';
            });
        });

        // Notice modal
        var modal = document.getElementById('d5NoticeModal');
        var modalTitle = document.getElementById('d5NoticeTitle');
        var modalDate = document.getElementById('d5NoticeDate');
        var modalBody = document.getElementById('d5NoticeBody');

        function openModal(title, content, date) {
            if (!modal) return;
            modalTitle.textContent = title || 'Notice';
            modalDate.innerHTML = '<i class="far fa-calendar-alt"></i> ' + (date || '');
            modalBody.innerHTML = String(content || '').replace(/\n/g, '<br>');
            modal.classList.add('is-open');
            modal.setAttribute('aria-hidden', 'false');
            document.body.style.overflow = 'hidden';
        }

        function closeModal() {
            if (!modal) return;
            modal.classList.remove('is-open');
            modal.setAttribute('aria-hidden', 'true');
            document.body.style.overflow = '';
        }

        document.querySelectorAll('.d5-notice-card').forEach(function(card) {
            card.addEventListener('click', function() {
                openModal(card.getAttribute('data-notice-title'), card.getAttribute('data-notice-content'), card.getAttribute('data-notice-date'));
            });
        });

        if (modal) {
            modal.addEventListener('click', function(event) {
                if (event.target === modal) closeModal();
            });
            modal.querySelectorAll('[data-d5-modal-close]').forEach(function(btn) {
                btn.addEventListener('click', closeModal);
            });
            document.addEventListener('keydown', function(event) {
                if (event.key === 'Escape') {
                    closeModal();
                    closeOverlay();
                }
            });
        }
    })();
</script>

<?php include_once(__DIR__ . '/../../../includes/body-close.php'); ?>