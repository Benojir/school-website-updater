<?php

/** @var string $school_name
 * @var PDO $pdo
 * @var array $additional_website_configs
 * @var array $websiteConfig
 * @var string $assets_version
 * @var string $logo_square
 * @var array $schoolInfo
 */
include_once(__DIR__ . '/../../../includes/header-open.php');

// Fetch carousel images
$stmt = $pdo->prepare("SELECT * FROM carousel_images");
$stmt->execute();
$carousel_images = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo '<title>' . $seo_title . '</title>';

// Fetch all notices
$stmt = $pdo->prepare("SELECT * FROM notices ORDER BY notice_date DESC LIMIT 30");
$stmt->execute();
$notices = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch classes and class-wise fees
$stmt = $pdo->prepare("
SELECT 
classes.id, 
classes.class_name, 
class_wise_monthly_fees.amount AS monthly_fee,
class_wise_new_admission_fees.amount AS admission_fee
FROM 
classes 
INNER JOIN class_wise_monthly_fees ON class_wise_monthly_fees.class_id = classes.id
INNER JOIN class_wise_new_admission_fees ON class_wise_new_admission_fees.class_id = classes.id
ORDER BY classes.id ASC;
");
$stmt->execute();
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch teachers
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE status = 'active' ORDER BY rand()");
$stmt->execute();
$teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch gallery images
$stmt = $pdo->prepare("SELECT * FROM gallery ORDER BY event_date DESC");
$stmt->execute();
$galley_images = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch gallery videos
$stmt = $pdo->prepare("SELECT * FROM gallery_videos ORDER BY event_date DESC");
$stmt->execute();
$galley_videos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// আজ যাদের জন্মদিন সেই শিক্ষার্থীদের বিস্তারিত তথ্য (ক্লাস ও সেকশনসহ) আনা হচ্ছে
$stmt = $pdo->prepare("
    SELECT s.*, c.class_name, sec.section_name 
    FROM students s 
    JOIN classes c ON s.class_id = c.id
    LEFT JOIN sections sec ON s.section_id = sec.id
    WHERE MONTH(s.date_of_birth) = MONTH(CURRENT_DATE()) 
      AND DAY(s.date_of_birth) = DAY(CURRENT_DATE())
");

$stmt->execute();
$birthdayStudents = $stmt->fetchAll(PDO::FETCH_ASSOC);
$birthday_student = [];
if (count($birthdayStudents) > 0) {
    $birthday_student = $birthdayStudents[mt_rand(0, count($birthdayStudents) - 1)];
}
?>

<!-- Custom CSS for the Kiddy Theme -->
<style>
    :root {
        --primary-color: <?= $theme_color ?>;
        --secondary-color: #ffc107;
        --accent-green: #198754;
        --accent-pink: #d63384;
        --bg-light: #f8f9fa;
        --bg-sky: #eef8ff;
        --text-dark: #343a40;
        --text-light: #FFFFFF;
        --border-radius-lg: 20px;
        --border-radius-md: 12px;
        --shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        --font-heading: 'Balsamiq Sans', cursive;
        --font-body: 'Nunito', sans-serif;
    }

    .main-container {
        font-family: var(--font-body);
        background-color: var(--text-light);
        color: var(--text-dark);
        overflow-x: hidden;
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
        font-family: var(--font-heading);
        color: var(--primary-color);
        font-weight: 700;
    }

    .section-title {
        font-size: 2.5rem;
        font-weight: 900;
        margin-bottom: 40px;
        text-align: center;
        text-shadow: 2px 2px 0 var(--bg-sky);
    }

    .btn-shine {
        --btn-bg: var(--primary-color);
        --shine-color: rgba(255, 255, 255, 0.6);
        position: relative;
        overflow: hidden;
        border: none;
    }

    /* moving shine */
    .btn-shine::before {
        content: "";
        position: absolute;
        top: -50%;
        left: -30%;
        width: 40%;
        height: 200%;
        background: linear-gradient(120deg, transparent 0%, var(--shine-color) 50%, transparent 100%);
        transform: rotate(20deg);
        filter: blur(6px);
        opacity: 0.9;
        animation: shine 2s linear infinite;
        pointer-events: none;
    }

    /* reduce motion support */
    @media (prefers-reduced-motion: reduce) {
        .btn-shine::before {
            animation: none;
            opacity: 0;
        }
    }

    /* timing */
    @keyframes shine {
        0% {
            transform: translateX(-250%) rotate(20deg);
        }

        50% {
            transform: translateX(250%) rotate(20deg);
        }

        100% {
            transform: translateX(650%) rotate(20deg);
        }
    }

    .btn-fun {
        border-radius: 50px;
        padding: 12px 30px;
        font-family: var(--font-heading);
        font-size: 1.1rem;
        transition: all 0.3s ease;
        border: none;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        text-decoration: none;
    }

    .btn-fun:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
    }

    .btn-primary.btn-fun {
        background-color: var(--primary-color);
        color: white;
    }

    .btn-secondary.btn-fun {
        background-color: var(--primary-color);
        color: var(--text-white);
    }

    .btn-light.btn-fun {
        background-color: #FFFFFF;
        color: var(--text-dark);
    }

    .btn-login {
        color: #FFFFFF;
    }

    .btn-login:hover {
        color: var(--primary-color);
    }

    /* Custom Navigation */
    .custom-nav-container {
        background: white;
        padding: 10px 0;
        box-shadow: var(--shadow);
        position: sticky;
        top: 0;
        z-index: 1000;
    }

    .custom-nav {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .school-logo {
        display: flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
    }

    .school-logo img {
        height: 50px;
        width: 50px;
        border-radius: 50%;
    }

    .school-logo .logo-text {
        font-family: "Montserrat", sans-serif;
        font-optical-sizing: auto;
        font-weight: 900;
        font-style: normal;
        font-size: 1.5rem;
        color: var(--primary-color);
        text-transform: uppercase;
        text-align: center;
        margin-left: 15px;
    }

    .nav-links {
        display: flex;
        gap: 10px;
    }

    .nav-links a {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-decoration: none;
        color: var(--text-dark);
        padding: 10px;
        border-radius: var(--border-radius-md);
        transition: all 0.3s ease;
    }

    .nav-links a i {
        font-size: 1.5rem;
        margin-bottom: 5px;
        transition: transform 0.3s ease;
    }

    .nav-links a span {
        font-family: var(--font-heading);
        font-size: 0.9rem;
    }

    .nav-links a:hover {
        background-color: var(--bg-sky);
    }

    .nav-links a:hover i {
        transform: scale(1.2) rotate(5deg);
    }

    .nav-links .btn-login {
        align-self: center;
    }

    /* Mobile Nav Toggler */
    .mobile-nav-toggle {
        display: none;
        font-size: 1.5rem;
        color: var(--primary-color);
        background: none;
        border: none;
        cursor: pointer;
        padding: 5px 10px;
    }

    .nav-dropdown {
        position: relative;
        display: inline-block;
    }

    .dropdown-menu {
        display: none;
        position: absolute;
        background-color: white;
        min-width: 200px;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        border-radius: var(--border-radius-md);
        z-index: 1001;
        padding: 10px 0;
        top: 100%;
        left: 50%;
        transform: translateX(-50%);
    }

    .nav-dropdown:hover .dropdown-menu {
        display: block;
    }

    .dropdown-menu a {
        display: flex !important;
        flex-direction: row !important;
        align-items: center;
        padding: 10px 20px !important;
        white-space: nowrap;
        border-radius: 0 !important;
        width: 100% !important;
        text-align: left;
    }

    .dropdown-menu a:hover {
        background-color: var(--bg-sky) !important;
    }

    .dropdown-menu a i {
        margin-right: 10px;
        font-size: 1rem !important;
        transform: none !important;
    }

    /* Hero Slider */
    .hero-slide {
        background-size: cover;
        background-position: center;
        color: white;
        height: 100vh;
        min-height: 500px;
        display: flex;
        align-items: center;
        position: relative;
    }

    .hero-slide::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.5);
    }

    .hero-content {
        position: relative;
        z-index: 2;
        text-align: center;
        display: flex;
        justify-content: center;
        flex-direction: column;
        align-items: center;
        width: 100%;
        height: 100%;
    }

    .hero-content h1 {
        font-family: var(--font-heading);
        font-size: 3.5rem;
        font-weight: 900;
        color: white;
        text-shadow: 3px 3px 0 rgba(0, 0, 0, 0.2);
        margin-bottom: 20px;
    }

    .hero-content .lead {
        font-size: 1.5rem;
        color: white;
        margin-bottom: 30px;
        max-width: 800px;
    }

    .hero-buttons {
        display: flex;
        gap: 15px;
        flex-wrap: wrap;
        justify-content: center;
    }

    /* Slick Slider Overrides */
    .slick-dots {
        bottom: 20px;
    }

    .slick-dots li button:before {
        font-size: 12px;
        color: white;
        opacity: 0.5;
    }

    .slick-dots li.slick-active button:before {
        color: white;
        opacity: 1;
    }

    /* Teachers Carousel */
    .teachers-carousel {
        margin: 0 -15px;
    }

    .teachers-carousel .slick-slide {
        padding: 0 15px;
    }

    .teachers-carousel .slick-prev,
    .teachers-carousel .slick-next {
        width: 50px;
        height: 50px;
        background-color: var(--primary-color);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.3s ease;
        z-index: 10;
    }

    .teachers-carousel .slick-prev::before,
    .teachers-carousel .slick-next::before {
        content: none !important;
    }

    .teachers-carousel .slick-prev:hover,
    .teachers-carousel .slick-next:hover {
        background-color: var(--secondary-color);
        /* transform: scale(1.1); */
    }

    .teachers-carousel .slick-prev {
        left: -60px;
    }

    .teachers-carousel .slick-next {
        right: -60px;
    }

    .teachers-carousel .slick-prev i,
    .teachers-carousel .slick-next i {
        color: white;
        font-size: 1.5rem;
    }

    /* Wavy Section Divider */
    .wavy-divider {
        position: relative;
        width: 100%;
        height: 100px;
        overflow: hidden;
    }

    .wavy-divider svg {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 100px;
    }

    /* Feature Cards */
    .feature-card {
        background: var(--text-light);
        border-radius: var(--border-radius-lg);
        padding: 30px;
        text-align: center;
        box-shadow: var(--shadow);
        border: 3px solid transparent;
        transition: all 0.4s ease-in-out;
        height: 100%;
    }

    .feature-card:hover {
        transform: translateY(-10px) rotate(2deg);
        border-color: var(--primary-color);
    }

    .feature-icon {
        font-size: 3rem;
        margin-bottom: 20px;
        display: inline-block;
        padding: 20px;
        border-radius: 50%;
        color: white;
    }

    .feature-card:nth-child(1) .feature-icon {
        background-color: var(--primary-color);
    }

    .feature-card:nth-child(2) .feature-icon {
        background-color: var(--accent-green);
    }

    .feature-card:nth-child(3) .feature-icon {
        background-color: var(--accent-pink);
    }

    /* Notice Board Section */
    #notices {
        background-color: var(--bg-sky);
        padding: 80px 0;
    }

    .notice-board {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 30px;
    }

    .notice-pin {
        background: white;
        padding: 25px;
        border-radius: var(--border-radius-md);
        box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.05);
        position: relative;
        transition: transform 0.3s ease;
    }

    .notice-pin:hover {
        transform: scale(1.05);
    }

    .notice-pin::before {
        content: '\f08d';
        font-family: 'Font Awesome 5 Free';
        font-weight: 900;
        position: absolute;
        top: -15px;
        left: 50%;
        transform: translateX(-50%);
        font-size: 2rem;
        color: var(--primary-color);
        text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);
    }

    .notice-pin h4 {
        color: var(--accent-pink);
    }

    .notice-pin p {
        display: -webkit-box;
        line-clamp: 4;
        -webkit-line-clamp: 4;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .notice-date {
        font-size: 0.8rem;
        font-weight: 700;
        color: #999;
        margin-bottom: 10px;
        display: block;
    }

    .notice-modal-header {
        border-bottom: 2px solid var(--primary-color);
        padding-bottom: 15px;
    }

    .notice-modal-body {
        padding: 15px 0;
        line-height: 1.6;
    }

    /* About Section */
    .about-img {
        border-radius: var(--border-radius-lg);
        box-shadow: var(--shadow);
        transform: rotate(-3deg);
        width: 100%;
        height: auto;
        object-fit: cover;
    }

    /* Teachers Section */
    .teacher-card {
        text-align: center;
        background-color: var(--bg-sky);
        padding: 30px;
        border-radius: var(--border-radius-lg);
        transition: all 0.3s ease;
        height: 100%;
    }

    .teacher-card img {
        width: 120px;
        height: 120px;
        border-radius: 50%;
        border: 5px solid white;
        box-shadow: 0 0 0 5px var(--primary-color);
        margin: 0 auto;
        margin-bottom: 25px;
        object-fit: cover;
    }

    .teacher-card h4 {
        color: var(--text-dark);
    }

    .teacher-card .qualification {
        color: var(--primary-color);
        font-size: 1.1rem;
    }

    .teacher-card .position_in_school {
        color: var(--text-dark);
        font-style: italic;
    }

    /* Gallery Section */
    .gallery-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
    }

    .gallery-item {
        border-radius: var(--border-radius-md);
        overflow: hidden;
        box-shadow: var(--shadow);
        position: relative;
        transition: transform 0.3s ease;
        aspect-ratio: 1/1;
    }

    .gallery-item:hover {
        transform: scale(1.05) rotate(1deg);
    }

    .gallery-item img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    /* Contact Section */
    .contact-form .form-control {
        border-radius: 50px;
        padding: 15px 20px;
        /* border: 2px solid grey; */
        background-color: var(--bg-sky);
        transition: border-color 0.3s ease;
        border-width: 2px;
    }

    .contact-form textarea.form-control {
        border-radius: 20px;
    }

    .contact-form .form-control:focus {
        border-color: var(--primary-color);
        box-shadow: none;
    }

    /* Footer */
    .site-footer {
        background-color: var(--text-dark);
        color: white;
        padding: 80px 0 30px;
    }

    .site-footer h5 {
        color: var(--secondary-color);
    }

    .site-footer a {
        color: white;
        text-decoration: none;
    }

    .site-footer a:hover {
        color: var(--secondary-color);
    }

    .footer-social-icons a {
        color: var(--text-dark);
        background-color: white;
        width: 40px;
        height: 40px;
        display: inline-flex;
        justify-content: center;
        align-items: center;
        border-radius: 50%;
        font-size: 1.2rem;
        margin-right: 10px;
        transition: all 0.3s ease;
    }

    .footer-social-icons a:hover {
        transform: translateY(-5px);
        background-color: var(--primary-color);
        color: var(--text-white);
    }

    /* Responsive Adjustments */
    @media (max-width: 1199px) {
        .school-logo .logo-text {
            font-size: 1.5rem;
        }

        .teachers-carousel .slick-prev {
            left: -30px;
        }

        .teachers-carousel .slick-next {
            right: -30px;
        }
    }

    @media (max-width: 991px) {
        .school-logo .logo-text {
            font-size: 2rem;
            color: var(--primary-color);
            /* background: #1800CF;
            background: linear-gradient(to right, #1800CF 0%, #FF6E20 100%);
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent; */
        }

        .nav-links {
            position: absolute;
            top: 100%;
            left: 50%;
            transform: translateX(-50%);
            padding: 20px;
            min-width: 50%;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            background-color: #FFFFFF;
            display: none;
            flex-direction: column;
            align-items: center;
            z-index: 999;
            width: max-content;
            /* shrink to fit content */
        }

        .nav-links.active {
            display: flex !important;
        }

        .nav-links a {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: row;
            width: auto !important;
            /* Shrink to fit */
            gap: 10px;
            padding: 10px 0;
            text-decoration: none;
        }

        .nav-links a i,
        .nav-links a span {
            display: inline-block;
        }

        .nav-links.active {
            display: flex !important;
            flex-direction: column;
        }


        .mobile-nav-toggle {
            display: block;
            cursor: pointer;
        }

        .nav-dropdown {
            width: 100%;
        }

        .dropdown-menu {
            position: static;
            transform: none;
            width: 100%;
            box-shadow: none;
            display: none;
            background-color: rgba(255, 255, 255, 0.1);
        }

        .nav-dropdown:hover .dropdown-menu,
        .nav-dropdown.active .dropdown-menu {
            display: block;
        }

        .nav-dropdown .dropdown-toggle {
            gap: 8px !important;
            /* Reduce the gap between icon and text */
            padding: 10px 0 !important;
            /* Adjust padding */
        }

        .nav-dropdown .dropdown-toggle i {
            margin-bottom: 0 !important;
            /* Remove the bottom margin that creates space */
        }

        .nav-dropdown .dropdown-toggle span {
            margin-left: 0 !important;
            /* Remove any left margin */
        }

        .dropdown-menu a {
            padding-left: 15px !important;
            /* Reduce left padding for dropdown items */
            gap: 8px !important;
            /* Consistent gap for dropdown items */
        }

        .dropdown-menu a i {
            font-size: 1rem !important;
            min-width: 20px;
            /* Ensure consistent icon width */
        }

        .section-title {
            font-size: 2rem;
        }

        .hero-content h1 {
            font-size: 2.5rem;
        }

        .hero-content .lead {
            font-size: 1.2rem;
        }

        .teachers-carousel .slick-prev,
        .teachers-carousel .slick-next {
            width: 40px;
            height: 40px;
        }
    }

    @media (max-width: 767px) {
        .school-logo .logo-text {
            font-size: 1.5rem;
        }

        .hero-slide {
            height: 70vh;
            min-height: 400px;
        }

        .teachers-carousel .row {
            flex-direction: column;
        }

        .teachers-carousel .col-lg-4 {
            margin-bottom: 20px;
        }

        .teachers-carousel .slick-prev {
            left: -15px;
        }

        .teachers-carousel .slick-next {
            right: -15px;
        }

        .section-title {
            font-size: 1.8rem;
        }

        .feature-card {
            padding: 20px;
        }

        /* .teacher-card {
            padding: 20px;
        } */

        .contact-form .form-control {
            padding: 12px 15px;
        }

        .footer-social-icons {
            justify-content: center;
        }

        .site-footer .text-center.text-lg-start {
            text-align: center !important;
            margin-top: 20px;
        }
    }

    @media (max-width: 575px) {
        .hero-slide {
            height: 60vh;
            min-height: 350px;
        }

        .hero-content h1 {
            font-size: 1.8rem;
        }

        .hero-buttons {
            flex-direction: column;
        }

        .school-logo .logo-text {
            font-size: 1.5rem;
        }

        .teachers-carousel .slick-prev,
        .teachers-carousel .slick-next {
            display: none !important;
        }
    }
</style>

<style>
    /* ===== Birthday Card — Enhanced =====
           Palette: sunset pink -> coral -> gold, one mint accent in the confetti.
           Motion: ONE orchestrated entrance (card + photo + confetti + staggered text),
           plus exactly one continuous ambient touch (the soft pulse ring on the photo). */

    #birthday-section {
        --bday-pink: #FF6F91;
        --bday-coral: #FF9A6C;
        --bday-gold: #FFC15E;
        --bday-cream: #FFF6E5;
        --bday-mint: #8FE3C4;
        --bday-shadow: rgba(122, 46, 69, .35);
    }

    /* Remove this @import if 'Fredoka' is already loaded in your site <head> */
    @import url('https://fonts.googleapis.com/css2?family=Fredoka:wght@500;600;700&display=swap');

    #birthday-section .bday-card {
        background: linear-gradient(135deg, var(--bday-pink) 0%, var(--bday-coral) 55%, var(--bday-gold) 100%);
        border-radius: var(--border-radius-lg, 24px);
        border: none;
        color: #fff;
        padding: 32px clamp(20px, 5vw, 44px);
        box-shadow: 0 18px 40px -14px var(--bday-shadow), var(--shadow, 0 8px 24px rgba(0, 0, 0, .12));
        animation: bdayCardIn .7s cubic-bezier(.22, 1, .36, 1) both;
        transition: transform .35s ease, box-shadow .35s ease;
    }

    #birthday-section .bday-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 26px 50px -14px var(--bday-shadow), var(--shadow, 0 8px 24px rgba(0, 0, 0, .12));
    }

    #birthday-section .bday-close {
        filter: invert(1);
        opacity: .85;
        z-index: 10;
    }

    /* Background watermark icons (static texture, not animated — the motion budget is spent elsewhere) */
    #birthday-section .bday-bg-icon {
        position: absolute;
        pointer-events: none;
        color: rgba(255, 255, 255, .14);
    }

    #birthday-section .bday-bg-icon--gift {
        top: -18px;
        right: 4px;
        font-size: 7.5rem;
        transform: rotate(15deg);
    }

    #birthday-section .bday-bg-icon--cake {
        bottom: -26px;
        left: -8px;
        font-size: 5.5rem;
        transform: rotate(-15deg);
    }

    #birthday-section .bday-content {
        position: relative;
        z-index: 2;
    }

    /* Photo */
    #birthday-section .bday-photo-wrap {
        position: relative;
        width: 100px;
        height: 100px;
        flex-shrink: 0;
        animation: bdayPhotoIn .7s cubic-bezier(.34, 1.56, .64, 1) .15s both;
    }

    #birthday-section .bday-photo {
        width: 100px;
        height: 100px;
        object-fit: cover;
        border: 4px solid rgba(255, 255, 255, .55);
        position: relative;
        z-index: 2;
        display: block;
    }

    #birthday-section .bday-photo-wrap::before {
        content: '';
        position: absolute;
        inset: -8px;
        border-radius: 50%;
        border: 2px solid rgba(255, 255, 255, .65);
        animation: bdayPulseRing 2.6s ease-out .9s infinite;
    }

    #birthday-section .bday-emoji {
        top: -6px;
        right: -6px;
        font-size: 1.4rem;
        z-index: 3;
        animation: bdayEmojiBounce 3s ease-in-out 1.2s infinite;
    }

    /* Text — staggered reveal, part of the one entrance moment */
    #birthday-section .bday-heading {
        font-family: var(--font-heading, 'Fredoka', sans-serif);
        font-weight: 600;
        font-size: clamp(1.3rem, 2.2vw, 1.7rem);
        color: #fff;
        text-shadow: 0 2px 8px rgba(122, 46, 69, .3);
        margin-bottom: 4px;
        opacity: 0;
        animation: bdayFadeUp .6s ease .35s both;
    }

    #birthday-section .bday-cake-emoji {
        display: inline-block;
        animation: bdayCakePop .6s cubic-bezier(.34, 1.56, .64, 1) .9s both;
    }

    #birthday-section .bday-name {
        font-family: var(--font-heading, 'Fredoka', sans-serif);
        font-weight: 700;
        font-size: clamp(1.15rem, 2vw, 1.4rem);
        color: var(--bday-cream);
        margin-bottom: 10px;
        opacity: 0;
        animation: bdayFadeUp .6s ease .5s both;
    }

    #birthday-section .bday-badges {
        opacity: 0;
        animation: bdayFadeUp .6s ease .65s both;
    }

    #birthday-section .bday-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: rgba(255, 255, 255, .2);
        border: 1px solid rgba(255, 255, 255, .35);
        color: #fff;
        padding: 5px 14px;
        border-radius: 50px;
        font-size: .85rem;
        font-weight: 600;
        margin: 3px 4px 0 0;
        backdrop-filter: blur(3px);
    }

    /* Confetti burst — fires once, settles, stays put */
    #birthday-section .bday-confetti {
        position: absolute;
        inset: 0;
        pointer-events: none;
        z-index: 1;
    }

    #birthday-section .bday-confetti span {
        position: absolute;
        top: 48%;
        left: 15%;
        width: var(--w, 7px);
        height: var(--h, 7px);
        background: var(--c, #fff);
        border-radius: var(--rad, 2px);
        opacity: 0;
        animation: bdayConfettiPop 1.3s cubic-bezier(.22, 1, .36, 1) var(--delay, 0s) both;
    }

    #birthday-section .bday-confetti span:nth-child(1) {
        --dx: -65px;
        --dy: -60px;
        --rot: 120deg;
        --delay: .05s;
        --c: var(--bday-gold);
    }

    #birthday-section .bday-confetti span:nth-child(2) {
        --dx: 35px;
        --dy: -75px;
        --rot: -90deg;
        --delay: .16s;
        --c: #fff;
        --rad: 50%;
    }

    #birthday-section .bday-confetti span:nth-child(3) {
        --dx: 95px;
        --dy: -15px;
        --rot: 200deg;
        --delay: .1s;
        --c: var(--bday-pink);
        --w: 5px;
        --h: 12px;
    }

    #birthday-section .bday-confetti span:nth-child(4) {
        --dx: -35px;
        --dy: -95px;
        --rot: 60deg;
        --delay: .26s;
        --c: var(--bday-mint);
        --rad: 50%;
    }

    #birthday-section .bday-confetti span:nth-child(5) {
        --dx: 60px;
        --dy: 55px;
        --rot: 300deg;
        --delay: .2s;
        --c: var(--bday-gold);
        --w: 5px;
        --h: 11px;
    }

    #birthday-section .bday-confetti span:nth-child(6) {
        --dx: -90px;
        --dy: 8px;
        --rot: 150deg;
        --delay: .3s;
        --c: #fff;
        --rad: 50%;
    }

    #birthday-section .bday-confetti span:nth-child(7) {
        --dx: 18px;
        --dy: 88px;
        --rot: 80deg;
        --delay: .06s;
        --c: var(--bday-pink);
    }

    #birthday-section .bday-confetti span:nth-child(8) {
        --dx: -55px;
        --dy: 72px;
        --rot: 220deg;
        --delay: .35s;
        --c: var(--bday-gold);
        --rad: 50%;
    }

    #birthday-section .bday-confetti span:nth-child(9) {
        --dx: 100px;
        --dy: 30px;
        --rot: 40deg;
        --delay: .14s;
        --c: var(--bday-mint);
        --w: 5px;
        --h: 10px;
    }

    /* Keyframes */
    @keyframes bdayCardIn {
        0% {
            opacity: 0;
            transform: translateY(18px) scale(.96);
        }

        100% {
            opacity: 1;
            transform: translateY(0) scale(1);
        }
    }

    @keyframes bdayPhotoIn {
        0% {
            opacity: 0;
            transform: scale(.5);
        }

        100% {
            opacity: 1;
            transform: scale(1);
        }
    }

    @keyframes bdayPulseRing {
        0% {
            transform: scale(.82);
            opacity: .9;
        }

        100% {
            transform: scale(1.3);
            opacity: 0;
        }
    }

    @keyframes bdayEmojiBounce {

        0%,
        100% {
            transform: translateY(0) rotate(0deg);
        }

        50% {
            transform: translateY(-6px) rotate(8deg);
        }
    }

    @keyframes bdayFadeUp {
        0% {
            opacity: 0;
            transform: translateY(10px);
        }

        100% {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @keyframes bdayCakePop {
        0% {
            transform: scale(0) rotate(-20deg);
        }

        100% {
            transform: scale(1) rotate(0deg);
        }
    }

    @keyframes bdayConfettiPop {
        0% {
            transform: translate(0, 0) rotate(0deg) scale(.3);
            opacity: 0;
        }

        20% {
            opacity: 1;
        }

        100% {
            transform: translate(var(--dx), var(--dy)) rotate(var(--rot)) scale(1);
            opacity: .85;
        }
    }

    /* Respect reduced motion: freeze everything in its final, fully-visible state; drop the confetti entirely */
    @media (prefers-reduced-motion: reduce) {

        #birthday-section .bday-card,
        #birthday-section .bday-card *:not(.bday-confetti span) {
            animation: none !important;
            opacity: 1 !important;
            transform: none !important;
            transition: none !important;
        }

        #birthday-section .bday-confetti {
            display: none;
        }
    }

    /* Mobile tuning */
    @media (max-width: 576px) {
        #birthday-section .bday-bg-icon--gift {
            font-size: 4.5rem;
        }

        #birthday-section .bday-bg-icon--cake {
            font-size: 3.5rem;
        }

        #birthday-section .bday-card {
            padding: 26px 18px;
        }
    }
</style>

<?php include_once(__DIR__ . '/../../../includes/header-close.php'); ?>

<div class="main-container">

    <!-- Custom Navigation Bar -->
    <header class="custom-nav-container">
        <div class="container custom-nav">
            <a href="#" class="school-logo">
                <img loading="lazy" src="<?= $logo_square ?>" alt="School Logo" onerror="this.style.display='none'">
                <span class="logo-text"><?= $schoolInfo['name']; ?></span>
            </a>
            <nav class="nav-links" id="navLinks">
                <a href="#about"><i class="fas fa-school text-primary"></i> <span>About</span></a>
                <a href="#academics"><i class="fas fa-book-open text-primary"></i> <span>Academics</span></a>
                <!-- Teachers dropdown -->
                <div class="nav-dropdown">
                    <a href="#" class="dropdown-toggle">
                        <i class="fas fa-chalkboard-teacher text-primary"></i>
                        <span>Teachers</span>
                    </a>
                    <div class="dropdown-menu">
                        <?php if ($additional_website_configs['show_teachers_on_front_page']): ?>
                            <a href="#teachers"><i class="fas fa-users text-primary"></i> <span>All Teachers</span></a>
                        <?php endif; ?>
                        <?php if ($additional_website_configs['teacher_application']): ?>
                            <a href="enquiries/form/teacher-application.php"><i class="fas fa-graduation-cap text-primary"></i> <span>Apply as Teacher</span></a>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- Gallery dropdown -->
                <div class="nav-dropdown">
                    <a href="#" class="dropdown-toggle">
                        <i class="fas fa-images text-primary"></i>
                        <span>Gallery</span>
                    </a>
                    <div class="dropdown-menu">
                        <a href="pages/photo-gallery.php"><i class="fas fa-camera-retro text-primary"></i> <span>Photo Gallery</span></a>
                        <a href="pages/video-gallery.php"><i class="fas fa-video text-primary"></i> <span>Video Gallery</span></a>
                    </div>
                </div>
                <a href="#notices"><i class="fas fa-bullhorn text-primary"></i> <span>Notices</span></a>
                <a href="#contact"><i class="fas fa-paper-plane text-primary"></i> <span>Contact</span></a>
                <?php if ($additional_website_configs['admin_login_option_show']): ?>
                    <div class="nav-dropdown">
                        <a class="btn-fun btn-primary btn-login dropdown-toggle" href="#" role="button" id="loginDropdownBtn"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fa-solid fa-lock"></i> Login
                        </a>
                        <div class="dropdown-menu" aria-labelledby="loginDropdownBtn">
                            <a href="parent/"><i class="fa-solid fa-user-shield text-primary"></i> <span>Parent Login</span></a>
                            <a href="management/"><i class="fa-solid fa-cog text-primary"></i> <span>Admin Login</span></a>
                        </div>
                    </div>
                <?php else: ?>
                    <a class="btn-fun btn-primary btn-login" href="parent/"><i class="fa-solid fa-lock"></i>Login</a>
                <?php endif; ?>
            </nav>
            <button class="mobile-nav-toggle" id="mobileNavToggle"><i class="fas fa-bars"></i></button>
        </div>
    </header>

    <!-- Hero Carousel Section -->
    <section class="hero-slider">
        <?php if (!empty($carousel_images)): ?>
            <?php foreach ($carousel_images as $image): ?>
                <div class="hero-slide lazy-bg" data-bg="<?= $image['image_url'] ?>">
                    <div class="hero-content">
                        <h1><?= safe_htmlspecialchars($image['caption'] ?? 'Welcome to Our School') ?></h1>
                        <div class="hero-buttons">
                            <?php if ($additional_website_configs['admission_open']): ?>
                                <a href="enquiries/form/admission-enquiry.php" class="btn-fun btn-secondary btn-shine animate__animated animate__rubberBand">Apply For Admission</a>
                            <?php endif; ?>
                            <a href="#contact" class="btn-fun btn-light">Contact Us</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <!-- Fallback hero content -->
            <div class="hero-slide" style="background-color: var(--primary-color);">
                <div class="hero-content">
                    <h1>Welcome to <?= $schoolInfo['name'] ?></h1>
                    <div class="hero-buttons">
                        <?php if ($additional_website_configs['admission_open']): ?>
                            <a href="enquiries/form/admission-enquiry.php" class="btn-fun btn-secondary btn-shine animate__animated animate__rubberBand">Apply For Admission</a>
                        <?php endif; ?>
                        <a href="#contact" class="btn-fun btn-light">Contact Us</a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </section>

    <!-- Birthday Section -->
    <?php if (!empty($birthdayStudents) && !empty($birthday_student)): ?>
        <section id="birthday-section" class="py-4">
            <div class="container">
                <div class="alert alert-dismissible fade show position-relative overflow-hidden mb-0 bday-card" role="alert">

                    <!-- Close Button -->
                    <button type="button" class="btn-close bday-close" data-bs-dismiss="alert" aria-label="Close"></button>

                    <!-- Confetti burst (purely decorative, plays once on load) -->
                    <div class="bday-confetti" aria-hidden="true">
                        <span></span><span></span><span></span><span></span><span></span>
                        <span></span><span></span><span></span><span></span>
                    </div>

                    <!-- Background watermark icons -->
                    <div class="bday-bg-icon bday-bg-icon--gift"><i class="fas fa-gift"></i></div>
                    <div class="bday-bg-icon bday-bg-icon--cake"><i class="fas fa-birthday-cake"></i></div>

                    <?php
                    // Get student name (handling possible database column variations like 'name' or 'student_name')
                    $student_name = $birthday_student['name'] ?? $birthday_student['student_name'] ?? 'Student';
                    $first_letter = mb_substr($student_name, 0, 1, "UTF-8");

                    // Get student image or initials placeholder
                    $student_image_db = $birthday_student['photo'] ?? $birthday_student['student_image'] ?? '';
                    $student_photo = (!empty($student_image_db)) ? 'uploads/students/' . $student_image_db : 'https://placehold.co/120x120/' . str_replace('#', '', $theme_color) . '/FFFFFF?text=' . urlencode($first_letter);
                    ?>

                    <!-- Content -->
                    <div class="d-flex flex-column flex-md-row align-items-center justify-content-center text-center text-md-start position-relative z-1 bday-content" style="gap: 25px;">

                        <!-- Student Image with Animation -->
                        <div class="bday-photo-wrap">
                            <img src="<?= $student_photo ?>" data-fancybox="Birthday Student" data-caption="<?= safe_htmlspecialchars($student_name) ?>" alt="<?= safe_htmlspecialchars($student_name) ?>" class="rounded-circle bday-photo" onerror="this.onerror=null;this.src='https://placehold.co/120x120/<?= str_replace('#', '', $theme_color) ?>/FFFFFF?text=<?= urlencode($first_letter) ?>';">
                            <div class="position-absolute bday-emoji">🎉</div>
                        </div>

                        <!-- Student Info -->
                        <div class="bday-info">
                            <h3 class="bday-heading">Happy Birthday! <span class="bday-cake-emoji">🎂</span></h3>
                            <h4 class="bday-name"><?= safe_htmlspecialchars($student_name) ?></h4>
                            <div class="bday-badges">
                                <span class="bday-badge"><i class="fas fa-graduation-cap"></i> Class <?= safe_htmlspecialchars($birthday_student['class_name'] ?? 'N/A') ?></span>
                                <?php if (!empty($birthday_student['section_name'])): ?>
                                    <span class="bday-badge"><i class="fas fa-layer-group"></i> Section <?= safe_htmlspecialchars($birthday_student['section_name']) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <!-- Features Section -->
    <section class="py-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="feature-card">
                        <div class="feature-icon"><i class="fas fa-graduation-cap"></i></div>
                        <h4>Quality Education</h4>
                        <p>We provide excellent education with modern teaching methods and well-equipped classrooms.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card">
                        <div class="feature-icon"><i class="fas fa-user-friends"></i></div>
                        <h4>Experienced Teachers</h4>
                        <p>Our qualified and dedicated teachers are committed to student success and development.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card">
                        <div class="feature-icon"><i class="fas fa-shield-alt"></i></div>
                        <h4>Safe & Fun Place</h4>
                        <p>Our school offers a safe and stimulating environment with modern facilities.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Notices Section -->
    <section id="notices" class="py-5">
        <div class="container">
            <h2 class="section-title">Notice Board</h2>
            <div class="notice-board">
                <?php
                $i = 0;
                foreach ($notices as $notice) {
                    if ($i == 3) break;
                    $i++;
                ?>
                    <div class="notice-pin">
                        <h4><?= safe_htmlspecialchars($notice['title']) ?></h4>
                        <span class="notice-date"><i class="far fa-calendar-alt me-2"></i><?= (new DateTime($notice['notice_date']))->format('d F Y'); ?></span>
                        <p><?= safe_htmlspecialchars($notice['content']) ?></p>
                        <a href="#" class="text-primary fw-bold read-more-btn"
                            data-notice-title="<?= safe_htmlspecialchars($notice['title']) ?>"
                            data-notice-content="<?= safe_htmlspecialchars($notice['content']) ?>"
                            data-notice-date="<?= (new DateTime($notice['notice_date']))->format('d F Y'); ?>">Read More <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                <?php } ?>
            </div>
            <div class="text-center mt-5">
                <a href="pages/notices.php" class="btn-fun btn-primary">View All Notices</a>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="py-5 my-5">
        <div class="container">
            <div class="row align-items-center g-5">
                <div class="col-lg-6">
                    <img
                        src="<?= $carousel_images[random_int(0, count($carousel_images) - 1)]['image_url'] ?>"
                        alt="School Fun"
                        class="img-fluid about-img"
                        data-fancybox="galley-carousel"
                        loading="lazy" />
                </div>
                <div class="col-lg-6">
                    <h2 class="section-title text-start">About Our School</h2>
                    <p class="fs-6 text-muted"><?= nl2br($schoolInfo['description']); ?></p>
                </div>
            </div>
        </div>
    </section>

    <!-- Academics Section -->
    <section id="academics" class="py-5 bg-light">
        <div class="container">
            <h2 class="section-title">Our Academics</h2>
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body p-4 p-md-5">
                            <h4 class="card-title text-center mb-4 fs-2">Fee Structure</h4>
                            <div class="table-responsive">
                                <table class="table table-striped table-hover text-center" style="border-radius: var(--border-radius-md); overflow:hidden;">
                                    <thead>
                                        <tr>
                                            <th class="py-3 fs-5 bg-primary text-white">Class</th>
                                            <th class="py-3 fs-5 bg-primary text-white">Monthly</th>
                                            <th class="py-3 fs-5 bg-primary text-white">Admission</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($classes as $class) { ?>
                                            <tr>
                                                <td class="py-3 fs-5"><?= $class['class_name'] ?></td>
                                                <td class="py-3 fs-5">₹<?= number_format($class['monthly_fee']) ?></td>
                                                <td class="py-3 fs-5">₹<?= number_format($class['admission_fee']) ?></td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Teachers Section -->
    <section id="teachers" class="py-5">
        <div class="container">
            <h2 class="section-title">Our Friendly Teachers</h2>
            <div class="teachers-carousel">
                <?php
                $i = 0;
                foreach ($teachers as $index => $teacher) {
                    // Start a new slide every 6 teachers
                    if ($i % 6 === 0) {
                        echo '<div><div class="row g-4">';
                    }
                ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="teacher-card">
                            <?php
                            if ($teacher['teacher_image'] == null || $teacher['teacher_image'] == '' || $teacher['teacher_image'] == 'default_teacher_dp.jpg') {
                                $teacher_dp_url = 'https://placehold.co/120x120/' . str_replace('#', '', $theme_color) . '/FFFFFF?text=' . substr($teacher['name'], 0, 1);
                            } else {
                                $teacher_dp_url = 'uploads/teachers/' . $teacher['teacher_image'];
                            }
                            ?>
                            <img loading="lazy" src="<?= $teacher_dp_url ?>" alt="<?= $teacher['name'] ?>" data-fancybox="teacher-image-gallery" data-caption="<?= $teacher['name'] ?>" onerror="this.onerror=null;this.src='https://placehold.co/120x120/<?= str_replace('#', '', $theme_color) ?>/FFFFFF?text=<?= substr($teacher['name'], 0, 1) ?>';">
                            <h4><?= $teacher['name'] ?></h4>
                            <p class="qualification fs-5"><?= $teacher['qualification'] ?></p>
                            <p class="position_in_school text-muted"><?= $teacher['position_in_school'] ?></p>
                        </div>
                    </div>
                <?php
                    $i++;
                    // Close the row and slide after every 6 teachers or at the end
                    if ($i % 6 === 0 || $i === count($teachers)) {
                        echo '</div></div>';
                    }
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Gallery Section -->
    <section id="gallery" class="py-5 bg-light">
        <div class="container">
            <h2 class="section-title">School Gallery</h2>
            <div class="gallery-grid">
                <?php
                $i = 1;
                foreach ($galley_images as $image) {
                ?>
                    <a href="<?= $image['photo_url'] ?>" data-fancybox="gallery" data-caption="<?= $image['caption'] ?>" class="gallery-item">
                        <img src="<?= $image['thumbnail_url'] ?>" alt="<?= $image['caption'] ?>" loading="lazy" />
                    </a>
                <?php
                    if ($i == 6) break;
                    $i++;
                } ?>
            </div>
            <div class="text-center mt-5">
                <a href="pages/photo-gallery.php" class="btn-fun btn-primary">View More Photos</a>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="py-5">
        <div class="container">
            <h2 class="section-title">Contact Us</h2>
            <div class="row g-4">
                <div class="col-lg-6">
                    <div class="p-4 p-md-5 rounded-3" style="background-color: var(--bg-sky);">
                        <h4 class="mb-4">Send us a Message!</h4>
                        <form class="contact-form" action="mailto:<?= $schoolInfo['email'] ?>" method="post" enctype="text/plain">
                            <div class="mb-3">
                                <input type="text" class="form-control" name="name" placeholder="Your Name" required>
                            </div>
                            <div class="mb-3">
                                <input type="tel" class="form-control" name="phone-number" placeholder="Your Phone" required>
                            </div>
                            <div class="mb-3">
                                <textarea class="form-control" rows="5" name="message" placeholder="Your Message" required></textarea>
                            </div>
                            <button type="submit" class="btn-fun btn-primary">Send Message</button>
                        </form>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="p-4 p-md-5">
                        <h4 class="mb-4">Find Us Here!</h4>
                        <p class="fs-5 mb-4"><i class="fas fa-map-marker-alt text-primary me-3"></i><?= $schoolInfo['address']; ?></p>
                        <p class="fs-5 mb-4"><i class="fas fa-phone-alt text-primary me-3"></i><?= $schoolInfo['phone']; ?></p>
                        <p class="fs-5 mb-4"><i class="fas fa-envelope text-primary me-3"></i><?= $schoolInfo['email']; ?></p>
                        <iframe src="<?= $schoolInfo['google_map_embed_link']; ?>" width="100%" height="300" style="border:0; border-radius: var(--border-radius-md);" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Notice Modal -->
    <div class="modal fade" id="noticeModal" tabindex="-1" aria-labelledby="noticeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="notice-modal-content">
                        <!-- Content will be loaded here dynamically -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-5 mb-lg-0 text-center text-lg-start">
                    <h5 class="mb-3"><?= $schoolInfo['name']; ?></h5>
                    <p>Building a bright future, one child at a time.</p>
                    <div class="footer-social-icons mt-4">
                        <a href="<?= $schoolInfo['facebook'] ?>"><i class="fab fa-facebook-f"></i></a>
                        <a href="<?= $schoolInfo['whatsapp'] ?>"><i class="fab fa-whatsapp"></i></a>
                        <a href="<?= $schoolInfo['instagram'] ?>"><i class="fab fa-instagram"></i></a>
                        <a href="<?= $schoolInfo['youtube'] ?>"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 text-center mb-3">
                    <h5 class="mb-3">Quick Links</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="pages/about-us.php">About Us</a></li>
                        <li class="mb-2"><a href="pages/contact-us.php">Contact Us</a></li>
                        <li class="mb-2"><a href="pages/privacy-and-policy.php">Privacy & Policy</a></li>
                        <li class="mb-2"><a href="pages/terms-and-conditions.php">Terms & Conditions</a></li>
                        <li class="mb-2"><a href="pages/refund-and-cancellation.php">Refund Policy</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 text-center mb-3">
                    <h5 class="mb-3">Contact</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="tel:<?= $schoolInfo['phone']; ?>"><?= $schoolInfo['phone']; ?></a></li>
                        <li class="mb-2"><a href="mailto:<?= $schoolInfo['email']; ?>"><?= $schoolInfo['email']; ?></a></li>
                    </ul>
                </div>
                <div class="col-lg-3 text-center text-lg-start">
                    <a target="_blank" href="<?= BASE_URL ?>/apps/" class="btn-fun bg-success"><i class="fa-brands fa-google-play me-2"></i> Download App</a>
                </div>
            </div>
            <div class="text-center mt-5 pt-4 border-top border-secondary">
                <p>&copy; <?php echo date("Y"); ?> <?= $schoolInfo['name']; ?> | Developed with <i class="fas fa-heart text-danger"></i> by <a href="https://dahukinfotech.com" class="text-warning">Dahuk Infotech</a></p>
            </div>
        </div>
    </footer>
</div>

<!-- Custom JS -->
<script>
    $(document).ready(function() {
        // Notice Modal functionality
        $('.read-more-btn').on('click', function(e) {
            e.preventDefault();

            var title = $(this).data('notice-title');
            var content = $(this).data('notice-content');
            var date = $(this).data('notice-date');

            // Populate modal content
            $('.notice-modal-content').html(`
                <div class="notice-modal-header mb-3">
                    <span class="badge bg-primary">${date}</span>
                    <h4 class="mt-2">${title}</h4>
                </div>
                <div class="notice-modal-body">
                    <p>${content.replace(/\n/g, '<br>')}</p>
                </div>
            `);

            // Show modal
            var noticeModal = new bootstrap.Modal(document.getElementById('noticeModal'));
            noticeModal.show();
        });

        // Mobile Nav Toggle
        // Modify your existing mobile nav toggle code to close dropdowns when menu closes
        $('#mobileNavToggle').on('click', function() {
            $('#navLinks').slideToggle();
            $(this).find('i').toggleClass('fa-bars fa-times');
            $('.nav-dropdown').removeClass('active');
            $('.dropdown-menu').slideUp();
        });

        // Smooth scrolling for navigation links
        $('a[href*="#"]').on('click', function(e) {
            if ($(this).attr('href') === '#') {
                e.preventDefault();
                return;
            }

            var target = $($(this).attr('href'));
            var screenWidth = $(window).width();
            if (target.length && screenWidth <= 991) {
                // Close mobile menu if open
                if ($('#navLinks').is(':visible')) {
                    $('#navLinks').slideUp();
                    $('#mobileNavToggle').find('i').toggleClass('fa-bars fa-times');
                }

                $('html, body').animate({
                    scrollTop: target.offset().top - 80
                }, 500, 'linear');
            }
        });

        // Mobile dropdown toggle
        $('.dropdown-toggle').on('click', function(e) {
            if ($(window).width() <= 991) {
                e.preventDefault();
                $(this).parent().toggleClass('active');
                $(this).next('.dropdown-menu').slideToggle();

                // Close other open dropdowns
                $('.nav-dropdown').not($(this).parent()).removeClass('active');
                $('.dropdown-menu').not($(this).next()).slideUp();
            }
        });

        // Hero Slider with Slick
        $('.hero-slider').slick({
            dots: true,
            infinite: true,
            speed: 500,
            fade: true,
            cssEase: 'linear',
            autoplay: true,
            autoplaySpeed: 5000,
            arrows: false
        });

        // Teachers Carousel with Slick
        $('.teachers-carousel').slick({
            dots: true,
            infinite: true,
            speed: 300,
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: true,
            prevArrow: '<button type="button" class="slick-prev"><i class="fas fa-chevron-left"></i></button>',
            nextArrow: '<button type="button" class="slick-next"><i class="fas fa-chevron-right"></i></button>',
            responsive: [{
                    breakpoint: 992,
                    settings: {
                        arrows: true
                    }
                },
                {
                    breakpoint: 768,
                    settings: {
                        arrows: false,
                        dots: true
                    }
                }
            ]
        });

        // Lazy load hero background image
        $('.lazy-bg').each(function() {
            const $el = $(this);
            const observer = new IntersectionObserver(function(entries, observer) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        $el.css('background-image', `url('${$el.data('bg')}')`);
                        observer.unobserve(entry.target);
                    }
                });
            });
            observer.observe(this);
        });

        // Loop apply admission button animation
        var isHovered = false;

        $('.btn-shine').hover(
            function() {
                isHovered = true;
            }, // mouse enters
            function() {
                isHovered = false;
            } // mouse leaves
        );

        setInterval(function() {
            var $btn = $('.btn-shine');

            // Only animate if not hovered
            if (!isHovered) {
                $btn.removeClass('animate__rubberBand');
                void $btn[0].offsetWidth; // trigger reflow
                $btn.addClass('animate__rubberBand');
            }
        }, 2000); // 2 seconds gap

        // Teacher show
        if (<?php echo $additional_website_configs['show_teachers_on_front_page'] ?> == 0) {
            $('#teachers').addClass('d-none');
        }

        // Academics show/hide
        if (<?php echo $additional_website_configs['hide_fees_structure_from_website'] ?? 0 ?> == 1) {
            $('#academics').addClass('d-none');
        }
    });
</script>

<?php include_once(__DIR__ . '/../../../includes/modals/parent/parent-app-ad.php'); ?>
<?php include_once(__DIR__ . '/../../../includes/body-close.php'); ?>