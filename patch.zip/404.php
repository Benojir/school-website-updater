<?php
if (!file_exists('install/installed.php')) {
    header('Location: install/index.php');
    exit();
}

include_once('includes/config.php');
if ($websiteConfig) {
    if ($websiteConfig['404_template']) {
        if (file_exists('assets/templates/404-pages-templates/' . $websiteConfig['404_template'] . '.php')) {
            include_once('assets/templates/404-pages-templates/' . $websiteConfig['404_template'] . '.php');
        } else {
            die('Template not found in local directory.');
        }
    } else {
        die('Database error');
    }
} else {
    die('Website configuration required.');
}
