<?php session_start();?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Payment Successful</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #f5f9ff;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }

    .success-container {
      background: #fff;
      padding: 40px;
      max-width: 500px;
      width: 100%;
      box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
      border-radius: 10px;
      text-align: center;
      border-top: 5px solid #28a745;
    }

    .success-icon {
      font-size: 60px;
      color: #28a745;
      margin-bottom: 20px;
    }

    .success-container h1 {
      font-size: 28px;
      margin-bottom: 10px;
      color: #333;
    }

    .success-container p {
      font-size: 16px;
      color: #666;
      margin-bottom: 20px;
    }

    .success-container .details {
      background: #f1f1f1;
      padding: 15px;
      border-radius: 8px;
      text-align: left;
      font-size: 14px;
      margin-bottom: 20px;
    }

    .success-container .details strong {
      display: inline-block;
      width: 130px;
      color: #333;
    }

    .success-container a.button {
      display: inline-block;
      padding: 12px 25px;
      background-color: #28a745;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      transition: background-color 0.3s;
    }

    .success-container a.button:hover {
      background-color: #218838;
    }

    @media (max-width: 600px) {
      .success-container {
        padding: 30px 20px;
      }
    }
  </style>
</head>

<body>

  <div class="success-container">
    <div class="success-icon">✔️</div>
    <h1>Payment Successful!</h1>
    <p>Thank you for your payment.</p>

    <div class="details">
      <?php if (isset($_SESSION['paymentId'])): ?>
        <p><strong>Payment ID:</strong> <?= $_SESSION['paymentId'] ?></p>
      <?php endif; ?>
      <?php if (isset($_SESSION['amount'])): ?>
        <p><strong>Amount Paid:</strong> ₹<?= $_SESSION['amount'] ?></p>
      <?php endif; ?>
      <p><strong>Date:</strong> <?= date('F j, Y') ?></p>
    </div>

    <a href="#" onclick="closeCurrentTab()" class="button">Close</a>
  </div>

  <script>
    function closeCurrentTab() {
      window.location.replace("/");
    }
  </script>

</body>

</html>