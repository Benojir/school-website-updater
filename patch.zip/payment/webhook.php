<?php
// webhook.php
require_once('../includes/config.php');
require_once('../vendor/autoload.php');

use Razorpay\Api\Api;
use Razorpay\Api\Utility;

$webhookSecret = $websiteConfig['razorpay_webhook_secret']; // Set in Razorpay Dashboard

// Get the raw POST data
$payload = file_get_contents('php://input');
$receivedSignature = $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'] ?? '';

try {
    // Create Utility instance
    $utility = new Utility();
    
    // Verify webhook signature
    $utility->verifyWebhookSignature($payload, $receivedSignature, $webhookSecret);
    
    // Process the payload
    $data = json_decode($payload, true);
    
    // Extract payment details
    $paymentId = $data['payload']['payment']['entity']['id'] ?? null;
    $orderId = $data['payload']['payment']['entity']['order_id'] ?? null;
    $status = $data['payload']['payment']['entity']['status'] ?? null;
    
    if ($paymentId && $orderId && $status) {
        // Update your database based on the payment status
        // updatePaymentStatus($paymentId, $orderId, $status);
        
        // Log successful verification
        // file_put_contents('webhook.log', date('Y-m-d H:i:s')." - Valid signature for payment $paymentId\n", FILE_APPEND);
    }
    
    http_response_code(200);
    echo "Webhook processed successfully";
    
} catch (\Exception $e) {
    // Log error
    // file_put_contents('webhook_errors.log', date('Y-m-d H:i:s')." - ".$e->getMessage()."\n", FILE_APPEND);
    
    http_response_code(400);
    echo "Webhook verification failed: " . $e->getMessage();
}
?>