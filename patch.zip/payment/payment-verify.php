<?php
// payment-verify.php
require_once('../includes/config.php');
require_once('../vendor/autoload.php');
require_once('additional-helper-functions.php');

use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

$keyId = $websiteConfig['razorpay_key_id'];
$keySecret = $websiteConfig['razorpay_key_secret'];

$api = new Api($keyId, $keySecret);

$required_fields = ['razorpay_payment_id', 'razorpay_order_id', 'razorpay_signature', 'unpaid_fee_id', 'type'];

foreach ($required_fields as $field) {
    if (empty($_POST[$field])) {
        die("Missing or empty field: $field");
    }
}

// Optional: Validate unpaid_fee_id is numeric
if (!is_numeric($_POST['unpaid_fee_id'])) {
    die("Invalid unpaid_fee_id.");
}

// Assign after validation
$paymentId = $_POST['razorpay_payment_id'];
$orderId = $_POST['razorpay_order_id'];
$signature = $_POST['razorpay_signature'];
$unpaid_fee_id = trim($_POST['unpaid_fee_id']);
$fee_type = trim($_POST['type']);

// Validate fee type
if (!in_array($fee_type, ['admission-fee', 'monthly-fee'])) {
    die('Invalid payment request.');
}

// Fetch unpaid fees data
$unpaid_fee_data = null;

if ($fee_type == "admission-fee") {
    $stmt = $pdo->prepare("SELECT * FROM student_admission_fees WHERE id = ? LIMIT 1");
    $stmt->execute([$unpaid_fee_id]);
    $unpaid_fee_data = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    $stmt = $pdo->prepare("SELECT * FROM student_unpaid_fees WHERE id = ? LIMIT 1");
    $stmt->execute([$unpaid_fee_id]);
    $unpaid_fee_data = $stmt->fetch(PDO::FETCH_ASSOC);
}

if (empty($unpaid_fee_data)) {
    die('No unpaid fees found.');
}

try {
    // Verify payment signature
    $attributes = array(
        'razorpay_order_id' => $orderId,
        'razorpay_payment_id' => $paymentId,
        'razorpay_signature' => $signature
    );

    $api->utility->verifyPaymentSignature($attributes);

    $_SESSION['paymentId'] = $paymentId;

    echo '<script>window.location.href="payment-success.php"</script>';

    // Payment successful - update your database
    if ($fee_type == "admission-fee") {
        updateAdmissionPaymentRecords($pdo, $unpaid_fee_data);
    } else {
        updateMonthlyPaymentRecords($pdo, $unpaid_fee_data);
    }

    // Send confirmation email (implement this function)
    // sendPaymentConfirmation($student_id, $amount, $paymentId);

    // Display success message
    // echo "Payment Successful! Payment ID: " . $paymentId;

} catch (SignatureVerificationError $e) {
    // Payment failed - log error
    // logError($e->getMessage());
    $_SESSION['reason'] = "Payment Verification Failed: " . $e->getMessage();
    echo '<script>window.location.href="payment-failed.php"</script>';
    // echo "Payment Verification Failed: " . $e->getMessage();
}
