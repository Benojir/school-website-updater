<?php
include_once("../../includes/config.php");
include_once("../../includes/imgbb-upload.php");

function clean($data)
{
    if ($data === NULL || $data === '') {
        return NULL;
    }
    return ucwords(safe_htmlspecialchars(trim($data)));
}

header('Content-Type: application/json');

try {
    // Verify hCaptcha
    if (!isset($_POST['h-captcha-response']) || empty($_POST['h-captcha-response'])) {
        throw new Exception('Please complete the captcha verification');
    }

    $captchaResponse = $_POST['h-captcha-response'];
    $secretKey = $websiteConfig['captcha_secret_key'];

    $verifyResponse = file_get_contents($captchaVerifyUrl . '?secret=' . $secretKey . '&response=' . $captchaResponse);
    $responseData = json_decode($verifyResponse);

    if (!$responseData->success) {
        throw new Exception('Captcha verification failed. Please try again.');
    }

    // Validate required fields
    $required_fields = ['name', 'email', 'phone_number', 'qualification', 'specialization', 'address', 'has_experience'];
    foreach ($required_fields as $field) {
        if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
            throw new Exception('Please fill in all required fields');
        }
    }

    // Validate email format
    if (!isValidEmail($_POST['email'])) {
        throw new Exception('Please enter a valid email address');
    }

    // Validate phone number (basic validation)
    if (!isValidPhoneNumber($_POST['phone_number'])) {
        throw new Exception('Please enter a valid phone number');
    }

    // Check for duplicate entries
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone_number']);

    $duplicateCheck = $pdo->prepare("SELECT id FROM teacher_applications WHERE email = ? OR phone_number = ?");
    $duplicateCheck->execute([$email, $phone]);

    if ($duplicateCheck->fetch()) {
        throw new Exception('An application with this email or phone number already exists');
    }

    // Validate experience field
    if ($_POST['has_experience'] === 'yes') {
        if (!isset($_POST['previous_school']) || empty(trim($_POST['previous_school']))) {
            throw new Exception('Please provide details about your previous teaching experience');
        }
    }

    // Validate and process photo
    if (!isset($_POST['cropped_image_data']) || empty($_POST['cropped_image_data'])) {
        throw new Exception('Please upload and crop your photo');
    }

    $imageData = $_POST['cropped_image_data'];

    // Validate base64 image data
    if (!preg_match('/^data:image\/(jpeg|png|jpg);base64,/', $imageData)) {
        throw new Exception('Invalid image format');
    }

    // Create temporary file for image upload
    $imageData = str_replace('data:image/jpeg;base64,', '', $imageData);
    $imageData = str_replace('data:image/png;base64,', '', $imageData);
    $imageData = str_replace('data:image/jpg;base64,', '', $imageData);
    $imageData = str_replace(' ', '+', $imageData);
    $decodedImage = base64_decode($imageData);

    if ($decodedImage === false) {
        throw new Exception('Failed to process image data');
    }

    // Create temporary file
    $tempFile = tempnam(sys_get_temp_dir(), 'teacher_photo_') . '.jpg';
    if (file_put_contents($tempFile, $decodedImage) === false) {
        throw new Exception('Failed to create temporary image file');
    }

    if (!isValidateImageFile($tempFile)) {
        throw new Exception('You\'re trying to upload an unsupported format or currupted image.');
    }

    $photo = uniqid('tch_') . '.jpg';

    $uploadFolder = '../../uploads/teachers/';

    if (!is_dir($uploadFolder)) {
       throw new Exception('No upload folder found.');
    }

    $destination = $uploadFolder . $photo;

    if (!copy($tempFile, $destination)) {
        throw new Exception('Failed to upload image.');
    }

    // Clean up temporary file
    unlink($tempFile);

    // Prepare data for insertion
    $name = clean($_POST['name']);
    $email = strtolower(trim($_POST['email']));
    $phone_number = clean($_POST['phone_number']);
    $qualification = safe_htmlspecialchars(trim($_POST['qualification']));
    $specialization = clean($_POST['specialization']);
    $address = clean($_POST['address']);
    $has_experience = $_POST['has_experience'];
    $previous_school = $has_experience === 'yes' ? clean($_POST['previous_school']) : null;

    // Insert into database
    $sql = "INSERT INTO teacher_applications (
        name, 
        email, 
        phone_number, 
        qualification, 
        specialization, 
        address, 
        has_experience, 
        previous_school, 
        applicant_image,
        application_date
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";

    $stmt = $pdo->prepare($sql);
    $result = $stmt->execute([
        $name,
        $email,
        $phone_number,
        $qualification,
        $specialization,
        $address,
        $has_experience,
        $previous_school,
        $photo
    ]);

    if (!$result) {
        throw new Exception('Failed to submit application. Please try again.');
    }

    $applicationId = $pdo->lastInsertId();

    // Send success response
    echo json_encode([
        'success' => true,
        'message' => 'Your application has been submitted successfully! Application ID: TA' . str_pad($applicationId, 4, '0', STR_PAD_LEFT),
        'application_id' => $applicationId
    ]);
} catch (Exception $e) {
    // Send error response
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} catch (PDOException $e) {
    // Database error
    error_log("Database error in teacher application: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Database error occurred. Please try again later.'
    ]);
} catch (Error $e) {
    // Fatal error
    error_log("Fatal error in teacher application: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'An unexpected error occurred. Please try again later.'
    ]);
}
