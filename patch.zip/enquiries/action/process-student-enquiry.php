<?php
ob_start();
include_once("../../includes/config.php");


// Sanitize function
function clean($data)
{
    if ($data === NULL || $data === '') {
        return NULL;
    }
    return ucwords(strtolower(safe_htmlspecialchars(trim($data))));
}

// Initial error
$response = [
    'success' => false,
    'message' => 'Invalid request.'
];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    throw new Exception("Invalid request.");
}

// Verify hCaptcha
$hcaptcha_response = $_POST['h-captcha-response'] ?? '';

$hcaptcha_secret = $websiteConfig['captcha_secret_key']; // Replace with your actual secret key

$verify_data = [
    'secret' => $hcaptcha_secret,
    'response' => $hcaptcha_response,
    'remoteip' => $_SERVER['REMOTE_ADDR']
];

$verify_response = file_get_contents($captchaVerifyUrl . '?' . http_build_query($verify_data));
$verify_result = json_decode($verify_response, true);

if (!$verify_result['success']) {
    throw new Exception("Captcha verification failed. Please try again.");
}

try {
    // Sanitize POST input
    $name                        = clean($_POST['name'] ?? '');
    $father_name                 = clean($_POST['father_name'] ?? '');
    $mother_name                 = clean($_POST['mother_name'] ?? '');
    $father_occupation           = clean($_POST['father_occupation'] ?? '');
    $mother_occupation           = clean($_POST['mother_occupation'] ?? '');
    $address                     = clean($_POST['address'] ?? '');
    $class                       = clean($_POST['class_id'] ?? '');
    $email                       = strtolower(clean($_POST['email'] ?? ''));
    $phone_number                = clean($_POST['phone_number'] ?? '');
    $alternate_phone_number      = clean($_POST['alternate_phone_number'] ?? '');
    $gender                      = clean($_POST['gender'] ?? '');
    $date_of_birth               = clean($_POST['date_of_birth'] ?? '');
    $blood_group                 = clean($_POST['blood_group'] ?? '');
    $preferred_by                = clean($_POST['preferred_by'] ?? '');
    $religion                    = clean($_POST['religion'] ?? '');

    // Validate required fields
    $required_fields = [
        'name',
        'gender',
        'date_of_birth',
        'phone_number',
        'alternate_phone_number',
        'email',
        'address',
        'father_name',
        'mother_name',
        'class_id',
        'religion'
    ];

    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            throw new Exception("All required fields must be filled.");
        }
    }

    // Validate phone number
    if (!isValidPhoneNumber($phone_number)) {
        throw new Exception("Invalid phone number format. It should be 10 digits.");
    }

    // Validate email
    if (!isValidEmail($email)) {
        throw new Exception("Invalid email id provided.");
    }

    // Validate alternate phone number
    if (!empty($alternate_phone_number)) {

        if (!isValidPhoneNumber($alternate_phone_number)) {
            throw new Exception("Invalid alternate phone number format. It should be 10 digits.");
        }

        // Check primary number and alternate number if same
        if ($phone_number == $alternate_phone_number) {
            throw new Exception("Primary phone number and alternate phone number must be different. You can leave blank the alternate phone number field.");
        }
    }

    // Check for duplicate student entry
    $checkID = $pdo->prepare("SELECT COUNT(*) FROM admission_enquiries WHERE name = :name AND class_id = :class AND father_name = :father_name");
    $checkID->execute([':name' => $name, ':class' => $class, ':father_name' => $father_name]);
    if ($checkID->fetchColumn() > 0) {
        throw new Exception("Student already applied for admission. Student name & father name are matched with existing data.");
    }

    // Check phone number if another father already used
    $checkPhone = $pdo->prepare("SELECT COUNT(*) FROM students WHERE phone_number = :phone_number AND father_name != :father_name");
    $checkPhone->execute([':phone_number' => $phone_number, ':father_name' => $father_name]);
    if ($checkPhone->fetchColumn() > 0) {
        throw new Exception("The phone number you provided is already used by another father. Please provide a different phone number.");
    }

    // Insert student enquiry
    $stmt = $pdo->prepare("
        INSERT INTO admission_enquiries (
            name, 
            father_name, 
            mother_name, 
            father_occupation, 
            mother_occupation,
            address, 
            class_id, 
            phone_number, 
            alternate_phone_number,
            gender, 
            email, 
            date_of_birth, 
            blood_group,
            preferred_by,
            religion
        ) VALUES (
            :name, 
            :father_name, 
            :mother_name, 
            :father_occupation, 
            :mother_occupation,
            :address, 
            :class, 
            :phone_number, 
            :alternate_phone_number,
            :gender, :email, 
            :date_of_birth, 
            :blood_group, 
            :preferred_by, 
            :religion
        )
    ");

    $stmt->execute([
        ':name'                        => $name,
        ':father_name'                 => $father_name,
        ':mother_name'                 => $mother_name,
        ':father_occupation'           => $father_occupation,
        ':mother_occupation'           => $mother_occupation,
        ':address'                     => $address,
        ':class'                       => $class,
        ':phone_number'                => $phone_number,
        ':alternate_phone_number'      => $alternate_phone_number,
        ':gender'                      => $gender,
        ':email'                       => $email,
        ':date_of_birth'               => $date_of_birth,
        ':blood_group'                 => $blood_group,
        ':preferred_by'                => $preferred_by,
        ':religion'                    => $religion
    ]);

    $response['success'] = true;
    $response['message'] = "Your enquiry has been received. We will contact you soon. Thank you for your enquiry.";
} catch (PDOException $e) {
    http_response_code(500);
    $response['message'] = "Database error: Please inform to school admin." . $e->getMessage();
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

// Replace the final lines with this:
$pdo = null; // Close connection

// Clean any output buffers
while (ob_get_level()) {
    ob_end_clean();
}

header('Content-Type: application/json');
echo json_encode($response);
exit();
