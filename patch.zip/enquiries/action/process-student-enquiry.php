<?php
ob_start();
include_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/academic/admission-enquiry-service.php';

$response = ['success' => false, 'message' => 'Invalid request.'];
$photo = null;
$saved = false;
try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') throw new InvalidArgumentException('Invalid request.');
    if ((int)($schoolSettings['admission_open'] ?? 0) !== 1) throw new InvalidArgumentException('Admission applications are currently closed.');
    $data = admissionEnquiryValidate($_POST);

    // Captcha remains mandatory even when optional personal fields are omitted.
    $token = $_POST['cf-turnstile-response'] ?? '';
    if (!is_string($token) || trim($token) === '') throw new InvalidArgumentException('Please complete the captcha verification.');
    $context = stream_context_create(['http' => [
        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
        'method' => 'POST', 'timeout' => 15, 'ignore_errors' => true,
        'content' => http_build_query([
            'secret' => $websiteConfig['captcha_secret_key'], 'response' => $token,
            'remoteip' => $_SERVER['REMOTE_ADDR'] ?? '',
        ]),
    ]]);
    $verification = @file_get_contents($captchaVerifyUrl, false, $context);
    $captcha = $verification === false ? null : json_decode($verification, true);
    if (empty($captcha['success'])) throw new InvalidArgumentException('Captcha verification failed. Please try again.');

    $class = $pdo->prepare('SELECT id FROM classes WHERE id = ?');
    $class->execute([$data['class_id']]);
    if (!$class->fetchColumn()) throw new InvalidArgumentException('Please select a valid class.');

    $duplicate = $pdo->prepare('SELECT COUNT(*) FROM admission_enquiries WHERE name = :name AND class_id = :class_id AND father_name = :father_name AND academic_year = :academic_year');
    $duplicate->execute(array_intersect_key($data, array_flip(['name', 'class_id', 'father_name', 'academic_year'])));
    if ($duplicate->fetchColumn() > 0) throw new InvalidArgumentException('This student has already applied for this class and academic year.');

    $phone = $pdo->prepare('SELECT COUNT(*) FROM students WHERE phone_number = :phone_number AND father_name != :father_name');
    $phone->execute(['phone_number' => $data['phone_number'], 'father_name' => $data['father_name']]);
    if ($phone->fetchColumn() > 0) throw new InvalidArgumentException('This phone number is already used by another father. Please provide a different phone number.');

    $photo = admissionEnquirySavePhoto($_FILES['student_image'] ?? null, $_POST['cropped_image_data'] ?? '');
    $data['student_image'] = $photo;
    foreach (['student', 'father', 'mother'] as $person) {
        $data[$person . '_adhaar_no'] = $data[$person . '_adhaar'];
        unset($data[$person . '_adhaar']);
    }
    // Column names come exclusively from the validated, fixed field list above.
    $columns = array_keys($data);
    $stmt = $pdo->prepare('INSERT INTO admission_enquiries (`' . implode('`, `', $columns) . '`) VALUES (:' . implode(', :', $columns) . ')');
    $stmt->execute($data);
    $saved = true;
    $response = ['success' => true, 'message' => 'Your application for academic year ' . $data['academic_year'] . ' has been received. We will contact you soon.'];
} catch (InvalidArgumentException $e) {
    $response['message'] = $e->getMessage();
} catch (Throwable $e) {
    error_log('Admission enquiry submission failed: ' . $e->getMessage());
    if ($e instanceof \PDOException && (string)$e->getCode() === '42S22') {
        http_response_code(503);
        $response['code'] = 'ADMISSION_UPDATE_REQUIRED';
        $response['message'] = 'Admission applications are temporarily unavailable because a required school system update is pending. Please contact the school.';
    } else {
        http_response_code(500);
        $response['message'] = 'The application could not be saved. Please contact the school or try again.';
    }
} finally {
    if (!$saved) admissionEnquiryRemovePhoto($photo);
}
while (ob_get_level()) ob_end_clean();
header('Content-Type: application/json');
echo json_encode($response);
exit;
