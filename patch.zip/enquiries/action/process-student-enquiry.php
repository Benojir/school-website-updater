<?php
/** @var PDO $pdo 
 * @var array $websiteConfig
 * @var array $schoolInfo
 */
ob_start();
include_once("../../includes/config.php");


// Sanitize function
function clean($data)
{
    if ($data === NULL || $data === '') {
        return NULL;
    }
    return ucwords(strtolower(safe_htmlspecialchars(trim($data))));
}

// Initial error
$response = [
    'success' => false,
    'message' => 'Invalid request.'
];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    throw new Exception("Invalid request.");
}

// Verify Cloudflare Turnstile
$turnstile_response = $_POST['cf-turnstile-response'] ?? '';

if (empty($turnstile_response)) {
    throw new Exception("Please complete the captcha verification");
}

$turnstile_secret = $websiteConfig['captcha_secret_key'];

$verify_data = [
    'secret' => $turnstile_secret,
    'response' => $turnstile_response,
    'remoteip' => $_SERVER['REMOTE_ADDR']
];

$verify_options = [
    'http' => [
        'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
        'method'  => 'POST',
        'content' => http_build_query($verify_data),
        'ignore_errors' => true
    ]
];
$verify_context = stream_context_create($verify_options);
$verify_response = file_get_contents($captchaVerifyUrl, false, $verify_context);
$verify_result = json_decode($verify_response, true);

if (!$verify_result || !$verify_result['success']) {
    throw new Exception("Captcha verification failed. Please try again.");
}

try {
    // Sanitize POST input
    $name                        = clean($_POST['name'] ?? '');
    $father_name                 = clean($_POST['father_name'] ?? '');
    $mother_name                 = clean($_POST['mother_name'] ?? '');
    $father_occupation           = clean($_POST['father_occupation'] ?? '');
    $mother_occupation           = clean($_POST['mother_occupation'] ?? '');
    $class                       = clean($_POST['class_id'] ?? '');
    $email                       = strtolower(clean($_POST['email'] ?? ''));
    $phone_number                = clean($_POST['phone_number'] ?? '');
    $alternate_phone_number      = clean($_POST['alternate_phone_number'] ?? '');
    $gender                      = clean($_POST['gender'] ?? '');
    $date_of_birth               = clean($_POST['date_of_birth'] ?? '');
    $blood_group                 = strtoupper(clean($_POST['blood_group'] ?? ''));
    $preferred_by                = clean($_POST['preferred_by'] ?? '');
    $religion                    = clean($_POST['religion'] ?? '');
    $student_adhaar              = clean($_POST['student_adhaar'] ?? '');
    $village                     = clean($_POST['village'] ?? '');
    $post_office                 = clean($_POST['post_office'] ?? '');
    $police_station              = clean($_POST['police_station'] ?? '');
    $district                    = clean($_POST['district'] ?? '');
    $pin_code                    = clean($_POST['pin_code'] ?? '');
    $father_adhaar               = clean($_POST['father_adhaar'] ?? '');
    $mother_adhaar               = clean($_POST['mother_adhaar'] ?? '');

    // Validate required fields
    $required_fields = [
        'name',
        'gender',
        'date_of_birth',
        'phone_number',
        'alternate_phone_number',
        'email',
        'father_name',
        'mother_name',
        'class_id',
        'religion',
        'student_adhaar',
        'village',
        'post_office',
        'police_station',
        'district',
        'pin_code',
        'father_adhaar',
        'mother_adhaar'
    ];

    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            throw new Exception("All required fields must be filled.");
        }
    }

    // Validate phone number
    if (!isValidPhoneNumber($phone_number)) {
        throw new Exception("Invalid phone number format. It should be 10 digits.");
    }

    // Validate email
    if (!isValidEmail($email)) {
        throw new Exception("Invalid email id provided.");
    }

    // Validate alternate phone number
    if (!empty($alternate_phone_number)) {

        if (!isValidPhoneNumber($alternate_phone_number)) {
            throw new Exception("Invalid alternate phone number format. It should be 10 digits.");
        }

        // Check primary number and alternate number if same
        if ($phone_number == $alternate_phone_number) {
            throw new Exception("Primary phone number and alternate phone number must be different. You can leave blank the alternate phone number field.");
        }
    }

    // Check for duplicate student entry
    $checkID = $pdo->prepare("SELECT COUNT(*) FROM admission_enquiries WHERE name = :name AND class_id = :class AND father_name = :father_name");
    $checkID->execute([':name' => $name, ':class' => $class, ':father_name' => $father_name]);
    if ($checkID->fetchColumn() > 0) {
        throw new Exception("Student already applied for admission. Student name & father name are matched with existing data.");
    }

    // Check phone number if another father already used
    $checkPhone = $pdo->prepare("SELECT COUNT(*) FROM students WHERE phone_number = :phone_number AND father_name != :father_name");
    $checkPhone->execute([':phone_number' => $phone_number, ':father_name' => $father_name]);
    if ($checkPhone->fetchColumn() > 0) {
        throw new Exception("The phone number you provided is already used by another father. Please provide a different phone number.");
    }

    // Building full address
    $address = "Vill- {$village}, P.O- {$post_office}, P.S- {$police_station}, Dist- {$district}, Pin- {$pin_code}";

    // Insert student enquiry
    $stmt = $pdo->prepare("
        INSERT INTO admission_enquiries (
            name, 
            father_name, 
            mother_name, 
            father_occupation, 
            mother_occupation,
            address, 
            class_id, 
            phone_number, 
            alternate_phone_number,
            gender, 
            email, 
            date_of_birth, 
            blood_group,
            preferred_by,
            religion,
            student_adhaar_no,
            village,
            post_office,
            police_station,
            district,
            pin_code,
            father_adhaar_no,
            mother_adhaar_no
        ) VALUES (
            :name, 
            :father_name, 
            :mother_name, 
            :father_occupation, 
            :mother_occupation,
            :address, 
            :class, 
            :phone_number, 
            :alternate_phone_number,
            :gender, :email, 
            :date_of_birth, 
            :blood_group, 
            :preferred_by, 
            :religion,
            :student_adhaar,
            :village,
            :post_office,
            :police_station,
            :district,
            :pin_code,
            :father_adhaar,
            :mother_adhaar
        )
    ");

    $stmt->execute([
        ':name'                        => $name,
        ':father_name'                 => $father_name,
        ':mother_name'                 => $mother_name,
        ':father_occupation'           => $father_occupation,
        ':mother_occupation'           => $mother_occupation,
        ':address'                     => $address,
        ':class'                       => $class,
        ':phone_number'                => $phone_number,
        ':alternate_phone_number'      => $alternate_phone_number,
        ':gender'                      => $gender,
        ':email'                       => $email,
        ':date_of_birth'               => $date_of_birth,
        ':blood_group'                 => $blood_group,
        ':preferred_by'                => $preferred_by,
        ':religion'                    => $religion,
        ':student_adhaar'              => $student_adhaar,
        ':village'                     => $village,
        ':post_office'                 => $post_office,
        ':police_station'              => $police_station,
        ':district'                    => $district,
        ':pin_code'                    => $pin_code,
        ':father_adhaar'               => $father_adhaar,
        ':mother_adhaar'               => $mother_adhaar
    ]);

    $response['success'] = true;
    $response['message'] = "Your enquiry has been received. We will contact you soon. Thank you for your enquiry.";
} catch (PDOException $e) {
    http_response_code(500);
    $response['message'] = "Database error: Please inform to school admin." . $e->getMessage();
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

// Replace the final lines with this:
$pdo = null; // Close connection

// Clean any output buffers
while (ob_get_level()) {
    ob_end_clean();
}

header('Content-Type: application/json');
echo json_encode($response);
exit();