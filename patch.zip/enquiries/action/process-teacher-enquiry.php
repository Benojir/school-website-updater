<?php

/** @var PDO $pdo 
 * @var array $websiteConfig
 * @var array $schoolInfo
 */
include_once("../../includes/config.php");
include_once("../../includes/imgbb-upload.php");
include_once("../../includes/phpmailer.php");

header('Content-Type: application/json');

try {
    // Verify hCaptcha
    if (!isset($_POST['h-captcha-response']) || empty($_POST['h-captcha-response'])) {
        throw new Exception('Please complete the captcha verification');
    }

    $captchaResponse = $_POST['h-captcha-response'];
    $secretKey = $websiteConfig['captcha_secret_key'];

    $verifyResponse = file_get_contents($captchaVerifyUrl . '?secret=' . $secretKey . '&response=' . $captchaResponse);
    $responseData = json_decode($verifyResponse);

    if (!$responseData->success) {
        throw new Exception('Captcha verification failed. Please try again.');
    }

    // Validate required fields
    $required_fields = ['name', 'email', 'phone_number', 'qualification', 'specialization', 'village', 'post_office', 'police_station', 'district', 'pincode'];
    foreach ($required_fields as $field) {
        if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
            throw new Exception('Please fill in all required fields. Missing: ' . str_replace('_', ' ', $field));
        }
    }

    // Input values
    $name = ucwords(sanitize_input($_POST['name'] ?? ''));
    $email = strtolower(sanitize_input($_POST['email'] ?? ''));
    $phone = sanitize_input($_POST['phone_number'] ?? '');
    $qualification = sanitize_input($_POST['qualification'] ?? '');
    $specialization = sanitize_input($_POST['specialization'] ?? '');
    $village = sanitize_input($_POST['village'] ?? '');
    $postOffice = sanitize_input($_POST['post_office'] ?? '');
    $policeStation = sanitize_input($_POST['police_station'] ?? '');
    $district = sanitize_input($_POST['district'] ?? '');
    $pincode = sanitize_input($_POST['pincode'] ?? '');
    $address = $village . ', ' . $postOffice . ', ' . $policeStation . ', ' . $district . ', ' . $pincode;
    $hasExperience = (isset($_POST['has_experience']) && $_POST['has_experience'] === 'yes') ? 'yes' : 'no';
    $previousSchool = sanitize_input($_POST['previous_school'] ?? '');


    // Check if email or phone number already exists
    $duplicateCheck = $pdo->prepare("SELECT id FROM teacher_applications WHERE email = ? OR phone_number = ?");
    $duplicateCheck->execute([$email, $phone]);

    if ($duplicateCheck->fetch()) {
        throw new Exception('An application with this email or phone number already exists');
    }

    // Validate experience field
    if ($hasExperience === 'yes') {
        if (empty($previousSchool)) {
            throw new Exception('Please provide details about your previous teaching experience');
        }
    }

    // Validate and process photo
    if (!isset($_POST['cropped_image_data']) || empty($_POST['cropped_image_data'])) {
        throw new Exception('Please upload and crop your photo');
    }

    $imageData = $_POST['cropped_image_data'] ?? '';

    if (empty($imageData)) {
        throw new Exception('Please upload and crop your photo');
    }

    // Validate base64 image data
    if (!preg_match('/^data:image\/(jpeg|png|jpg);base64,/', $imageData)) {
        throw new Exception('Invalid image format');
    }

    // Create temporary file for image upload
    $imageData = str_replace('data:image/jpeg;base64,', '', $imageData);
    $imageData = str_replace('data:image/png;base64,', '', $imageData);
    $imageData = str_replace('data:image/jpg;base64,', '', $imageData);
    $imageData = str_replace(' ', '+', $imageData);
    $decodedImage = base64_decode($imageData);

    if ($decodedImage === false) {
        throw new Exception('Failed to process image data');
    }

    // Create temporary file
    $tempFile = tempnam(sys_get_temp_dir(), 'teacher_photo_') . '.jpg';
    if (file_put_contents($tempFile, $decodedImage) === false) {
        throw new Exception('Failed to create temporary image file');
    }

    if (!isValidImageFile($tempFile)) {
        throw new Exception('You\'re trying to upload an unsupported format or currupted image.');
    }

    $photo = uniqid('tch_') . '.jpg';

    $uploadFolder = '../../uploads/teachers/';

    if (!is_dir($uploadFolder)) {
        throw new Exception('No upload folder found.');
    }

    $destination = $uploadFolder . $photo;

    if (!copy($tempFile, $destination)) {
        throw new Exception('Failed to upload image.');
    }

    // Clean up temporary file
    unlink($tempFile);


    // Insert into database
    // Insert into database
    $sql = "INSERT INTO teacher_applications (
        name, email, phone_number, qualification, specialization, 
        village, post_office, police_station, district, pincode,
        address, has_experience, previous_school, applicant_image, application_date
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";

    $stmt = $pdo->prepare($sql);
    $result = $stmt->execute([
        $name,
        $email,
        $phone,            // CHANGED from $phone_number
        $qualification,
        $specialization,
        $village,
        $postOffice,
        $policeStation,
        $district,
        $pincode,
        $address,
        $hasExperience,    // CHANGED from $has_experience
        $previousSchool,   // CHANGED from $previous_school
        $photo
    ]);

    if (!$result) {
        throw new Exception('Failed to submit application. Please try again.');
    }

    $applicationId = $pdo->lastInsertId();

    try {
        // Send email
        $applicant_image = BASE_URL . '/uploads/teachers/' . $photo;
        $template = file_get_contents(__DIR__ . '/../../assets/templates/email-templates/new-teacher-application-notification.html');
        $emailBody = str_replace(
            array(
                '{applicant_image}',
                '{applicant_name}',
                '{phone}',
                '{email}',
                '{qualification}',
                '{specialization}',
                '{previous_school}',
                '{address}',
                '{year}',
                '{school_name}'
            ),
            array(
                $applicant_image,
                $name,
                $phone,
                $email,
                $qualification,
                $specialization,
                $previousSchool,
                $address,
                date('Y'),
                $schoolInfo['name']
            ),
            $template
        );

        $senderName = $schoolInfo['name'] . ' Automated Notification';
        $recipientAddress = $schoolInfo['email'];
        $recipientName = $schoolInfo['name'];
        $subject = 'New Teacher Application Notification';

        sendMail($senderName, $recipientAddress, $recipientName, $subject, $emailBody, $emailBody);

    } catch (Exception $e) {
        error_log("Error sending email: " . $e->getMessage());
    }

    // Send success response
    echo json_encode([
        'success' => true,
        'message' => 'Your application has been submitted successfully! Application ID: TA' . str_pad($applicationId, 4, '0', STR_PAD_LEFT),
        'application_id' => $applicationId
    ]);
} catch (Exception $e) {
    // Send error response
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} catch (PDOException $e) {
    // Database error
    error_log("Database error in teacher application: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Database error occurred. Please try again later.'
    ]);
} catch (Error $e) {
    // Fatal error
    error_log("Fatal error in teacher application: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'An unexpected error occurred. Please try again later.'
    ]);
}
