<?php

/** @var PDO $pdo
 * @var array $websiteConfig
 * @var array $schoolInfo
 * @var string $captchaVerifyUrl
 */
include_once("../../includes/config.php");
include_once("../../includes/imgbb-upload.php");
include_once("../../includes/phpmailer.php");
include_once("../../includes/teacher/fun-teacher-application-access.php");

header('Content-Type: application/json');

try {
    // Verify Cloudflare Turnstile
    if (!isset($_POST['cf-turnstile-response']) || empty($_POST['cf-turnstile-response'])) {
        throw new Exception('Please complete the captcha verification');
    }

    $turnstileResponse = $_POST['cf-turnstile-response'];
    $secretKey = $websiteConfig['captcha_secret_key'];

    $verify_data = [
        'secret' => $secretKey,
        'response' => $turnstileResponse,
        'remoteip' => $_SERVER['REMOTE_ADDR'] ?? ''
    ];

    $verify_options = [
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($verify_data),
            'ignore_errors' => true
        ]
    ];
    $verify_context = stream_context_create($verify_options);
    $verifyResponse = file_get_contents($captchaVerifyUrl, false, $verify_context);
    $responseData = json_decode($verifyResponse);

    if (!$responseData || !$responseData->success) {
        throw new Exception('Captcha verification failed. Please try again.');
    }

    // Validate required fields
    $required_fields = ['name', 'email', 'phone', 'date_of_birth', 'gender', 'qualification', 'subject_specialization', 'village', 'post_office', 'police_station', 'district', 'pincode'];
    foreach ($required_fields as $field) {
        if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
            throw new Exception('Please fill in all required fields. Missing: ' . str_replace('_', ' ', $field));
        }
    }

    // ---------------------------------------------------------
    // Input values
    // ---------------------------------------------------------
    $name = ucwords(strtolower(sanitize_input($_POST['name'] ?? '')));
    $email = strtolower(sanitize_input($_POST['email'] ?? ''));
    $phone = sanitize_input($_POST['phone'] ?? '');

    $dateOfBirth = sanitize_input($_POST['date_of_birth'] ?? '');
    $gender = sanitize_input($_POST['gender'] ?? '');
    $bloodGroup = sanitize_input($_POST['blood_group'] ?? '');
    $casteCategory = sanitize_input($_POST['caste_category'] ?? '');
    $religion = sanitize_input($_POST['religion'] ?? '');
    $nationality = sanitize_input($_POST['nationality'] ?? '') ?: 'Indian';
    $aadhaarNumber = sanitize_input($_POST['aadhaar_card'] ?? '');

    $fatherName = sanitize_input($_POST['father_name'] ?? '');
    $fatherPhone = sanitize_input($_POST['father_phone'] ?? '');
    $motherName = sanitize_input($_POST['mother_name'] ?? '');
    $motherPhone = sanitize_input($_POST['mother_phone'] ?? '');

    $qualification = sanitize_input($_POST['qualification'] ?? '');
    $specialization = sanitize_input($_POST['subject_specialization'] ?? '');
    $positionInSchool = sanitize_input($_POST['position_in_school'] ?? '');

    $panNumber = strtoupper(sanitize_input($_POST['pan_number'] ?? '') ?? '');
    $voterEpicNumber = strtoupper(sanitize_input($_POST['voter_epic_number'] ?? '') ?? '');
    $bankName = sanitize_input($_POST['bank_name'] ?? '');
    $bankBranch = sanitize_input($_POST['bank_branch'] ?? '');
    $ifscCode = strtoupper(sanitize_input($_POST['ifsc_code'] ?? '') ?? '');
    $accountNumber = sanitize_input($_POST['account_number'] ?? '');

    $village = sanitize_input($_POST['village'] ?? '');
    $postOffice = sanitize_input($_POST['post_office'] ?? '');
    $policeStation = sanitize_input($_POST['police_station'] ?? '');
    $district = sanitize_input($_POST['district'] ?? '');
    $pincode = sanitize_input($_POST['pincode'] ?? '');
    $address = $village . ', ' . $postOffice . ', ' . $policeStation . ', ' . $district . ', ' . $pincode;

    $hasExperience = (isset($_POST['has_experience']) && $_POST['has_experience'] === 'yes') ? 'yes' : 'no';
    $previousSchool = sanitize_input($_POST['previous_school'] ?? '');

    // Uniqueness-sensitive identity fields: store as NULL when blank so the DB's
    // unique index doesn't treat two blank applications as duplicates of each other.
    $aadhaarNumber = $aadhaarNumber !== '' ? $aadhaarNumber : null;
    $panNumber = $panNumber !== '' ? $panNumber : null;
    $voterEpicNumber = $voterEpicNumber !== '' ? $voterEpicNumber : null;
    $bloodGroup = $bloodGroup !== '' ? $bloodGroup : null;
    $casteCategory = $casteCategory !== '' ? $casteCategory : null;

    // ---------------------------------------------------------
    // Validation
    // ---------------------------------------------------------
    if (!isValidEmail($email)) {
        throw new Exception('Please enter a valid email address');
    }

    if (!isValidPhoneNumber($phone)) {
        throw new Exception('Please enter a valid phone number');
    }

    if (!empty($fatherPhone) && !isValidPhoneNumber($fatherPhone)) {
        throw new Exception("Please enter a valid father's phone number");
    }

    if (!empty($motherPhone) && !isValidPhoneNumber($motherPhone)) {
        throw new Exception("Please enter a valid mother's phone number");
    }

    if (!in_array($gender, ['Male', 'Female', 'Other'], true)) {
        throw new Exception('Please select a valid gender');
    }

    if (!empty($panNumber) && !preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/', $panNumber)) {
        throw new Exception('Invalid PAN number format (e.g. ABCDE1234F)');
    }

    if (!empty($ifscCode) && !preg_match('/^[A-Z]{4}0[A-Z0-9]{6}$/', $ifscCode)) {
        throw new Exception('Invalid IFSC code format (e.g. SBIN0001234)');
    }

    if (!empty($voterEpicNumber) && !preg_match('/^[A-Z]{3}[0-9]{7}$/', $voterEpicNumber)) {
        throw new Exception('Invalid Voter EPIC number format (e.g. ABC1234567)');
    }

    // Validate experience field
    if ($hasExperience === 'yes' && empty($previousSchool)) {
        throw new Exception('Please provide details about your previous teaching experience');
    }

    // ---------------------------------------------------------
    // Duplicate checks against the teachers table, which now holds
    // applications too (status = 'pending' until the admin reviews them)
    // ---------------------------------------------------------
    $duplicateCheck = $pdo->prepare("SELECT status FROM teachers WHERE email = ? OR phone = ? LIMIT 1");
    $duplicateCheck->execute([$email, $phone]);
    $existing = $duplicateCheck->fetch(PDO::FETCH_ASSOC);

    if ($existing) {
        if (in_array($existing['status'], ['pending', 'archive'], true)) {
            throw new Exception('An application with this email or phone number is already under review.');
        }
        throw new Exception('This email or phone number is already registered with us. Please contact the school office.');
    }

    if (!empty($aadhaarNumber)) {
        $checkAadhaar = $pdo->prepare("SELECT id FROM teachers WHERE aadhaar_number = ?");
        $checkAadhaar->execute([$aadhaarNumber]);
        if ($checkAadhaar->fetch()) {
            throw new Exception('This Aadhaar number is already registered with us.');
        }
    }

    if (!empty($panNumber)) {
        $checkPan = $pdo->prepare("SELECT id FROM teachers WHERE pan_number = ?");
        $checkPan->execute([$panNumber]);
        if ($checkPan->fetch()) {
            throw new Exception('This PAN number is already registered with us.');
        }
    }

    if (!empty($voterEpicNumber)) {
        $checkEpic = $pdo->prepare("SELECT id FROM teachers WHERE voter_epic_number = ?");
        $checkEpic->execute([$voterEpicNumber]);
        if ($checkEpic->fetch()) {
            throw new Exception('This Voter EPIC number is already registered with us.');
        }
    }

    // ---------------------------------------------------------
    // Validate and process photo
    // ---------------------------------------------------------
    if (!isset($_POST['cropped_image_data']) || empty($_POST['cropped_image_data'])) {
        throw new Exception('Please upload and crop your photo');
    }

    $imageData = $_POST['cropped_image_data'] ?? '';

    if (empty($imageData)) {
        throw new Exception('Please upload and crop your photo');
    }

    // Validate base64 image data
    if (!preg_match('/^data:image\/(jpeg|png|jpg);base64,/', $imageData)) {
        throw new Exception('Invalid image format');
    }

    // Create temporary file for image upload
    $imageData = str_replace('data:image/jpeg;base64,', '', $imageData);
    $imageData = str_replace('data:image/png;base64,', '', $imageData);
    $imageData = str_replace('data:image/jpg;base64,', '', $imageData);
    $imageData = str_replace(' ', '+', $imageData);
    $decodedImage = base64_decode($imageData);

    if ($decodedImage === false) {
        throw new Exception('Failed to process image data');
    }

    // Create temporary file
    $tempFile = tempnam(sys_get_temp_dir(), 'teacher_photo_') . '.jpg';
    if (file_put_contents($tempFile, $decodedImage) === false) {
        throw new Exception('Failed to create temporary image file');
    }

    if (!isValidImageFile($tempFile)) {
        throw new Exception('You\'re trying to upload an unsupported format or currupted image.');
    }

    $photo = uniqid('tch_') . '.jpg';

    $uploadFolder = '../../uploads/teachers/';

    if (!is_dir($uploadFolder)) {
        throw new Exception('No upload folder found.');
    }

    $destination = $uploadFolder . $photo;

    if (!copy($tempFile, $destination)) {
        throw new Exception('Failed to upload image.');
    }

    // Clean up temporary file
    unlink($tempFile);

    // ---------------------------------------------------------
    // Document uploads (ImgBB) - two parallel arrays from the form:
    //   document_name[] -> label the applicant typed
    //   document_file[] -> the corresponding image
    // ---------------------------------------------------------
    $documents = [];

    if (!empty($_FILES['document_file']['name']) && is_array($_FILES['document_file']['name'])) {
        $docNames = $_POST['document_name'] ?? [];
        $docFiles = $_FILES['document_file'];
        $totalDocs = count($docFiles['name']);

        // Reject an over-limit submission before spending time on any upload
        $filledSlots = 0;
        for ($i = 0; $i < $totalDocs; $i++) {
            if ($docFiles['error'][$i] !== UPLOAD_ERR_NO_FILE) {
                $filledSlots++;
            }
        }

        if ($filledSlots > MAX_TEACHER_DOCUMENTS) {
            throw new Exception('You can attach a maximum of ' . MAX_TEACHER_DOCUMENTS . ' documents.');
        }

        for ($i = 0; $i < $totalDocs; $i++) {
            // Skip empty slots (row added but nothing selected)
            if ($docFiles['error'][$i] === UPLOAD_ERR_NO_FILE) {
                continue;
            }

            $docName = isset($docNames[$i]) ? sanitize_input($docNames[$i]) : '';
            if (empty($docName)) {
                throw new Exception('Every attached document must have a name.');
            }

            // Rebuild a single-file $_FILES-style array for this index
            $singleFile = [
                'name'     => $docFiles['name'][$i],
                'type'     => $docFiles['type'][$i],
                'tmp_name' => $docFiles['tmp_name'][$i],
                'error'    => $docFiles['error'][$i],
                'size'     => $docFiles['size'][$i],
            ];

            // Uploads to ImgBB and returns the direct image URL (throws on failure)
            $documents[] = [
                'document_name' => $docName,
                'document_url'  => uploadDocumentToImgBB($singleFile, $docName . ' - ' . $name),
            ];
        }
    }

    $documentsJson = !empty($documents) ? json_encode($documents) : null;

    // ---------------------------------------------------------
    // Store the application directly in the teachers table. It stays invisible
    // to the rest of the system until the admin approves it, because every
    // teacher-facing query filters on status = 'active'.
    //
    // joining_date is left NULL on purpose - the admin sets it on approval.
    // monthly_salary and assigned_sections are admin-managed and use their
    // column defaults.
    // ---------------------------------------------------------
    $sql = "INSERT INTO teachers (
        name, email, phone,
        date_of_birth, gender, blood_group, caste_category, religion, nationality, aadhaar_number,
        father_name, father_phone, mother_name, mother_phone,
        position_in_school, qualification, subject_specialization, has_experience, previous_school,
        pan_number, voter_epic_number, bank_name, bank_branch, ifsc_code, account_number,
        village, post_office, police_station, district, pincode, address,
        teacher_image, documents, application_date, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), 'pending')";

    $stmt = $pdo->prepare($sql);
    $result = $stmt->execute([
        $name,
        $email,
        $phone,
        $dateOfBirth,
        $gender,
        $bloodGroup,
        $casteCategory,
        $religion,
        $nationality,
        $aadhaarNumber,
        $fatherName,
        $fatherPhone,
        $motherName,
        $motherPhone,
        $positionInSchool,
        $qualification,
        $specialization,
        $hasExperience,
        $previousSchool,
        $panNumber,
        $voterEpicNumber,
        $bankName,
        $bankBranch,
        $ifscCode,
        $accountNumber,
        $village,
        $postOffice,
        $policeStation,
        $district,
        $pincode,
        $address,
        $photo,
        $documentsJson
    ]);

    if (!$result) {
        throw new Exception('Failed to submit application. Please try again.');
    }

    $applicationId = (int) $pdo->lastInsertId();
    $applicationRef = formatTeacherApplicationRef($applicationId);
    $trackingLink = BASE_URL . '/enquiries/form/track-teacher-application.php';

    try {
        // Send email
        $applicant_image = BASE_URL . '/uploads/teachers/' . $photo;
        $template = file_get_contents(__DIR__ . '/../../assets/templates/email-templates/new-teacher-application-notification.html');
        $emailBody = str_replace(
            array(
                '{applicant_image}',
                '{applicant_name}',
                '{phone}',
                '{email}',
                '{qualification}',
                '{specialization}',
                '{previous_school}',
                '{address}',
                '{year}',
                '{school_name}'
            ),
            array(
                $applicant_image,
                $name,
                $phone,
                $email,
                $qualification,
                $specialization,
                $previousSchool,
                $address,
                date('Y'),
                $schoolInfo['name']
            ),
            $template
        );

        $senderName = $schoolInfo['name'] . ' Automated Notification';
        $recipientAddress = $schoolInfo['email'];
        $recipientName = $schoolInfo['name'];
        $subject = 'New Teacher Application Notification';

        sendMail($senderName, $recipientAddress, $recipientName, $subject, $emailBody, $emailBody);
    } catch (Exception $e) {
        error_log("Error sending email: " . $e->getMessage());
    }

    // ---------------------------------------------------------
    // Confirmation to the applicant. This carries the application / teacher ID
    // they will need later to look the application up, so it is worth its own
    // try/catch - a mail failure must not undo a stored application.
    // ---------------------------------------------------------
    try {
        $applicantTemplate = file_get_contents(__DIR__ . '/../../assets/templates/email-templates/teacher-application-received.html');

        $applicantEmailBody = str_replace(
            array(
                '{applicant_name}',
                '{application_ref}',
                '{applicant_email}',
                '{date_of_birth}',
                '{submitted_on}',
                '{tracking_link}',
                '{school_name}',
                '{year}'
            ),
            array(
                $name,
                $applicationRef,
                $email,
                formatDate($dateOfBirth),
                date('d M Y, h:i A'),
                $trackingLink,
                $schoolInfo['name'],
                date('Y')
            ),
            $applicantTemplate
        );

        $applicantAltBody = "Dear $name,\n\n"
            . "Thank you for applying for a teaching position at " . $schoolInfo['name'] . ".\n"
            . "Your application has been received and is now under review.\n\n"
            . "Your Application / Teacher ID: $applicationRef\n"
            . "Registered Email: $email\n"
            . "Date of Birth: " . formatDate($dateOfBirth) . "\n\n"
            . "Please save this ID. You will need it, along with the email address and date of birth above, "
            . "to check your application status here:\n$trackingLink\n\n"
            . "While your application is still under review you can also correct any detail yourself, "
            . "including your photo and documents. Once the school has processed it, the application becomes "
            . "read-only but the status stays visible to you.\n\n"
            . "Best regards,\n" . $schoolInfo['name'] . " Hiring Committee";

        sendMail(
            $schoolInfo['name'],
            $email,
            $name,
            'Application Received (' . $applicationRef . ') - ' . $schoolInfo['name'],
            $applicantEmailBody,
            $applicantAltBody
        );
    } catch (Exception $e) {
        error_log("Error sending applicant confirmation email: " . $e->getMessage());
    }

    // Send success response
    echo json_encode([
        'success' => true,
        'message' => 'Your application has been submitted successfully! Your Application ID is ' . $applicationRef . ' - we have emailed it to ' . $email . '. Keep it safe: you will need it to check or edit your application later.',
        'application_id' => $applicationId,
        'application_ref' => $applicationRef,
        'tracking_link' => $trackingLink
    ]);
} catch (Exception $e) {
    // Send error response
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} catch (PDOException $e) {
    // Database error
    error_log("Database error in teacher application: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Database error occurred. Please try again later.'
    ]);
} catch (Error $e) {
    // Fatal error
    error_log("Fatal error in teacher application: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'An unexpected error occurred. Please try again later.'
    ]);
}
