<?php

/**
 * Verifies that the visitor owns a teacher application, using three values the
 * applicant supplied on the original form: application id + email + date of
 * birth. A match opens a short-lived session (see the access helper) which the
 * track page and the edit form rely on.
 *
 * @var PDO $pdo
 * @var array $websiteConfig
 * @var array $schoolSettings
 * @var string $captchaVerifyUrl
 */
include_once("../../includes/config.php");
include_once("../../includes/teacher/fun-teacher-application-access.php");

header('Content-Type: application/json');

// Wrong-guess throttle: 5 failures buys a 15 minute cool-off.
const TEACHER_APPLICATION_LOOKUP_MAX_ATTEMPTS = 5;
const TEACHER_APPLICATION_LOOKUP_WINDOW = 900;

try {
    if ($schoolSettings['teacher_application'] == 0) {
        throw new Exception('Teacher applications are not available at the moment.');
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method.');
    }

    // ---------------------------------------------------------
    // Throttle repeated failed lookups
    // ---------------------------------------------------------
    if (!isset($_SESSION['teacher_application_lookup_attempts'])) {
        $_SESSION['teacher_application_lookup_attempts'] = 0;
        $_SESSION['teacher_application_lookup_first_attempt'] = time();
    }

    if ($_SESSION['teacher_application_lookup_attempts'] >= TEACHER_APPLICATION_LOOKUP_MAX_ATTEMPTS) {
        $elapsed = time() - (int) $_SESSION['teacher_application_lookup_first_attempt'];

        if ($elapsed < TEACHER_APPLICATION_LOOKUP_WINDOW) {
            $minutesLeft = (int) ceil((TEACHER_APPLICATION_LOOKUP_WINDOW - $elapsed) / 60);
            throw new Exception('Too many failed attempts. Please try again after ' . $minutesLeft . ' minute(s).');
        }

        $_SESSION['teacher_application_lookup_attempts'] = 0;
        $_SESSION['teacher_application_lookup_first_attempt'] = time();
    }

    // ---------------------------------------------------------
    // Captcha
    // ---------------------------------------------------------
    if (empty($_POST['cf-turnstile-response'])) {
        throw new Exception('Please complete the captcha verification');
    }

    $verify_data = [
        'secret' => $websiteConfig['captcha_secret_key'],
        'response' => $_POST['cf-turnstile-response'],
        'remoteip' => $_SERVER['REMOTE_ADDR'] ?? ''
    ];

    $verify_context = stream_context_create([
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($verify_data),
            'timeout' => 10,
            'ignore_errors' => true
        ]
    ]);

    $verifyResponse = @file_get_contents($captchaVerifyUrl, false, $verify_context);
    $responseData = $verifyResponse !== false ? json_decode($verifyResponse) : null;

    if (!$responseData || !$responseData->success) {
        throw new Exception('Captcha verification failed. Please try again.');
    }

    // ---------------------------------------------------------
    // Credentials
    // ---------------------------------------------------------
    $applicationId = parseTeacherApplicationRef($_POST['application_ref'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $dateOfBirth = trim($_POST['date_of_birth'] ?? '');

    if ($applicationId === null || $email === '' || $dateOfBirth === '') {
        throw new Exception('Please enter your Application ID, email and date of birth.');
    }

    if (!isValidEmail($email)) {
        throw new Exception('Please enter a valid email address');
    }

    $dob = DateTime::createFromFormat('Y-m-d', $dateOfBirth);

    if (!$dob || $dob->format('Y-m-d') !== $dateOfBirth) {
        throw new Exception('Please enter a valid date of birth.');
    }

    // ---------------------------------------------------------
    // Match against the stored application
    // ---------------------------------------------------------
    $stmt = $pdo->prepare("SELECT id, email, date_of_birth FROM teachers WHERE id = ? LIMIT 1");
    $stmt->execute([$applicationId]);
    $application = $stmt->fetch(PDO::FETCH_ASSOC);

    $emailMatches = $application && strtolower(trim((string) $application['email'])) === $email;
    $dobMatches = $application
        && !empty($application['date_of_birth'])
        && $application['date_of_birth'] === $dateOfBirth;

    if (!$application || !$emailMatches || !$dobMatches) {
        $_SESSION['teacher_application_lookup_attempts']++;

        // One generic message on purpose - telling the visitor which of the
        // three values was wrong would turn this into an enumeration tool.
        throw new Exception('We could not find an application matching those details. Please check your Application ID, email and date of birth.');
    }

    // Successful match - clear the throttle and open the session
    $_SESSION['teacher_application_lookup_attempts'] = 0;
    $_SESSION['teacher_application_lookup_first_attempt'] = time();

    grantTeacherApplicationAccess((int) $application['id']);

    echo json_encode([
        'success' => true,
        'message' => 'Application found. Loading your application...',
        'application_ref' => formatTeacherApplicationRef((int) $application['id'])
    ]);
} catch (PDOException $e) {
    error_log("Database error in teacher application lookup: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error occurred. Please try again later.']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} catch (Error $e) {
    error_log("Fatal error in teacher application lookup: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An unexpected error occurred. Please try again later.']);
}
