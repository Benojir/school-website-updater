<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/academic/student-application-access.php';
header('Content-Type: application/json');
header('Cache-Control: private, no-store');
header('Referrer-Policy: no-referrer');

try {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        header('Allow: POST');
        throw new StudentApplicationAccessException('Use POST to save an application.', 405);
    }
    studentApplicationRequireCsrf($_POST);
    $updated = studentApplicationSaveVerified($pdo, $_POST, $_FILES['student_image'] ?? null, $schoolSettings);
    try {
        $photoUrl = schoolPhotoUrl('students', $updated['student_image'] ?? null);
    } catch (Throwable $e) {
        // The edit has committed; a CDN lookup error must not report a save failure.
        $photoUrl = schoolPhotoGatewayUrl('students', ($updated['student_image'] ?? null) ?: schoolPhotoCategories()['students'][2]);
    }
    echo json_encode(['success' => true, 'message' => 'Your application has been updated successfully. It is still pending approval.',
        'application_ref' => formatStudentApplicationRef((int)$updated['id']),
        'original_version' => admissionEnquiryVersion($updated), 'photo_url' => $photoUrl,
        'has_photo' => !empty($updated['student_image'])]);
} catch (StudentApplicationAccessException $e) {
    http_response_code($e->getCode());
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} catch (AdmissionEnquiryEditConflict $e) {
    http_response_code(409);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} catch (InvalidArgumentException $e) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} catch (Throwable $e) {
    error_log('Student application update failed: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'The application could not be saved. Please try again.']);
}
