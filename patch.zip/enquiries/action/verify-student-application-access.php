<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/academic/student-application-access.php';
header('Content-Type: application/json');
header('Cache-Control: private, no-store');
header('Referrer-Policy: no-referrer');

try {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        header('Allow: POST');
        throw new StudentApplicationAccessException('Use POST to look up an application.', 405);
    }
    studentApplicationRequireCsrf($_POST);
    revokeStudentApplicationAccess();
    studentApplicationLookupAllowed();
    studentApplicationRecordLookupAttempt();
    studentApplicationVerifyCaptcha($_POST, $websiteConfig, $captchaVerifyUrl);
    $credentials = studentApplicationCredentials($_POST);
    $application = fetchStudentApplicationById($pdo, $credentials['id']);
    if (!studentApplicationCredentialsMatch($application, $credentials)) {
        throw new InvalidArgumentException('We could not find an application matching those details. Please check your Application ID, registered phone number and date of birth.');
    }
    $_SESSION['student_application_lookup'] = ['started' => time(), 'count' => 0];
    grantStudentApplicationAccess((int)$application['id']);
    echo json_encode(['success' => true, 'message' => 'Application found. Loading your application...',
        'application_ref' => formatStudentApplicationRef((int)$application['id'])]);
} catch (StudentApplicationAccessException $e) {
    http_response_code($e->getCode());
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} catch (InvalidArgumentException $e) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} catch (Throwable $e) {
    error_log('Student application lookup failed: ' . $e->getMessage());
    http_response_code(503);
    echo json_encode(['success' => false, 'message' => 'Application lookup is temporarily unavailable. Please try again later or contact the school.']);
}
