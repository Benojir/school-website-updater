<?php

/**
 * Applies an applicant's own edits to a teacher application.
 *
 * Only reachable with a verified applicant session (see
 * verify-teacher-application-access.php) and only while the application is
 * still pending - once the school has approved, rejected or archived it, the
 * record becomes read-only for the applicant.
 *
 * @var PDO $pdo
 * @var array $websiteConfig
 * @var array $schoolSettings
 * @var array $schoolInfo
 * @var string $captchaVerifyUrl
 */
include_once("../../includes/config.php");
include_once("../../includes/imgbb-upload.php");
include_once("../../includes/teacher/fun-teacher-application-access.php");

header('Content-Type: application/json');

try {
    if ($schoolSettings['teacher_application'] == 0) {
        throw new Exception('Teacher applications are not available at the moment.');
    }

    if (empty($schoolSettings['allow_edit_teacher_application'])) {
        throw new Exception('Editing teacher applications is not allowed at the moment.');
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method.');
    }

    // ---------------------------------------------------------
    // Ownership + editability guards
    // ---------------------------------------------------------
    $applicationId = verifiedTeacherApplicationId();

    if ($applicationId === null) {
        throw new Exception('Your session has expired. Please look up your application again.');
    }

    $stmt = $pdo->prepare("SELECT * FROM teachers WHERE id = ? LIMIT 1");
    $stmt->execute([$applicationId]);
    $current = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$current) {
        revokeTeacherApplicationAccess();
        throw new Exception('This application no longer exists. Please contact the school office.');
    }

    if (!isTeacherApplicationEditable($current['status'])) {
        throw new Exception('This application has already been processed by the school and can no longer be edited.');
    }

    // ---------------------------------------------------------
    // Captcha
    // ---------------------------------------------------------
    if (empty($_POST['cf-turnstile-response'])) {
        throw new Exception('Please complete the captcha verification');
    }

    $verify_data = [
        'secret' => $websiteConfig['captcha_secret_key'],
        'response' => $_POST['cf-turnstile-response'],
        'remoteip' => $_SERVER['REMOTE_ADDR'] ?? ''
    ];

    $verify_context = stream_context_create([
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($verify_data),
            'timeout' => 10,
            'ignore_errors' => true
        ]
    ]);

    $verifyResponse = @file_get_contents($captchaVerifyUrl, false, $verify_context);
    $responseData = $verifyResponse !== false ? json_decode($verifyResponse) : null;

    if (!$responseData || !$responseData->success) {
        throw new Exception('Captcha verification failed. Please try again.');
    }

    // ---------------------------------------------------------
    // Required fields
    // ---------------------------------------------------------
    $required_fields = ['name', 'email', 'phone', 'date_of_birth', 'gender', 'qualification', 'subject_specialization', 'village', 'post_office', 'police_station', 'district', 'pincode'];

    foreach ($required_fields as $field) {
        if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
            throw new Exception('Please fill in all required fields. Missing: ' . str_replace('_', ' ', $field));
        }
    }

    // ---------------------------------------------------------
    // Input values (mirrors process-teacher-enquiry.php)
    // ---------------------------------------------------------
    $name = ucwords(strtolower(sanitize_input($_POST['name'] ?? '')));
    $email = strtolower(sanitize_input($_POST['email'] ?? ''));
    $phone = sanitize_input($_POST['phone'] ?? '');

    $dateOfBirth = sanitize_input($_POST['date_of_birth'] ?? '');
    $gender = sanitize_input($_POST['gender'] ?? '');
    $bloodGroup = sanitize_input($_POST['blood_group'] ?? '');
    $casteCategory = sanitize_input($_POST['caste_category'] ?? '');
    $religion = sanitize_input($_POST['religion'] ?? '');
    $nationality = sanitize_input($_POST['nationality'] ?? '') ?: 'Indian';
    $aadhaarNumber = sanitize_input($_POST['aadhaar_card'] ?? '');

    $fatherName = sanitize_input($_POST['father_name'] ?? '');
    $fatherPhone = sanitize_input($_POST['father_phone'] ?? '');
    $motherName = sanitize_input($_POST['mother_name'] ?? '');
    $motherPhone = sanitize_input($_POST['mother_phone'] ?? '');

    $qualification = sanitize_input($_POST['qualification'] ?? '');
    $specialization = sanitize_input($_POST['subject_specialization'] ?? '');
    $positionInSchool = sanitize_input($_POST['position_in_school'] ?? '');

    $panNumber = strtoupper(sanitize_input($_POST['pan_number'] ?? '') ?? '');
    $voterEpicNumber = strtoupper(sanitize_input($_POST['voter_epic_number'] ?? '') ?? '');
    $bankName = sanitize_input($_POST['bank_name'] ?? '');
    $bankBranch = sanitize_input($_POST['bank_branch'] ?? '');
    $ifscCode = strtoupper(sanitize_input($_POST['ifsc_code'] ?? '') ?? '');
    $accountNumber = sanitize_input($_POST['account_number'] ?? '');

    $village = sanitize_input($_POST['village'] ?? '');
    $postOffice = sanitize_input($_POST['post_office'] ?? '');
    $policeStation = sanitize_input($_POST['police_station'] ?? '');
    $district = sanitize_input($_POST['district'] ?? '');
    $pincode = sanitize_input($_POST['pincode'] ?? '');
    $address = $village . ', ' . $postOffice . ', ' . $policeStation . ', ' . $district . ', ' . $pincode;

    $hasExperience = (isset($_POST['has_experience']) && $_POST['has_experience'] === 'yes') ? 'yes' : 'no';
    $previousSchool = sanitize_input($_POST['previous_school'] ?? '');

    // Uniqueness-sensitive identity fields: store as NULL when blank so the DB's
    // unique index doesn't treat two blank applications as duplicates of each other.
    $aadhaarNumber = $aadhaarNumber !== '' ? $aadhaarNumber : null;
    $panNumber = $panNumber !== '' ? $panNumber : null;
    $voterEpicNumber = $voterEpicNumber !== '' ? $voterEpicNumber : null;
    $bloodGroup = $bloodGroup !== '' ? $bloodGroup : null;
    $casteCategory = $casteCategory !== '' ? $casteCategory : null;

    // ---------------------------------------------------------
    // Validation
    // ---------------------------------------------------------
    if (!isValidEmail($email)) {
        throw new Exception('Please enter a valid email address');
    }

    if (!isValidPhoneNumber($phone)) {
        throw new Exception('Please enter a valid phone number');
    }

    if (!empty($fatherPhone) && !isValidPhoneNumber($fatherPhone)) {
        throw new Exception("Please enter a valid father's phone number");
    }

    if (!empty($motherPhone) && !isValidPhoneNumber($motherPhone)) {
        throw new Exception("Please enter a valid mother's phone number");
    }

    if (!in_array($gender, ['Male', 'Female', 'Other'], true)) {
        throw new Exception('Please select a valid gender');
    }

    $dob = DateTime::createFromFormat('Y-m-d', $dateOfBirth);

    if (!$dob || $dob->format('Y-m-d') !== $dateOfBirth) {
        throw new Exception('Please enter a valid date of birth.');
    }

    if (!empty($panNumber) && !preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/', $panNumber)) {
        throw new Exception('Invalid PAN number format (e.g. ABCDE1234F)');
    }

    if (!empty($ifscCode) && !preg_match('/^[A-Z]{4}0[A-Z0-9]{6}$/', $ifscCode)) {
        throw new Exception('Invalid IFSC code format (e.g. SBIN0001234)');
    }

    if (!empty($voterEpicNumber) && !preg_match('/^[A-Z]{3}[0-9]{7}$/', $voterEpicNumber)) {
        throw new Exception('Invalid Voter EPIC number format (e.g. ABC1234567)');
    }

    if ($hasExperience === 'yes' && empty($previousSchool)) {
        throw new Exception('Please provide details about your previous teaching experience');
    }

    // ---------------------------------------------------------
    // Duplicate checks - every one of them skips this application's own row,
    // otherwise re-saving unchanged values would look like a clash with itself.
    // ---------------------------------------------------------
    $duplicateCheck = $pdo->prepare("SELECT status FROM teachers WHERE (email = ? OR phone = ?) AND id != ? LIMIT 1");
    $duplicateCheck->execute([$email, $phone, $applicationId]);
    $existing = $duplicateCheck->fetch(PDO::FETCH_ASSOC);

    if ($existing) {
        if (in_array($existing['status'], ['pending', 'archive'], true)) {
            throw new Exception('Another application with this email or phone number is already under review.');
        }
        throw new Exception('This email or phone number is already registered with us. Please contact the school office.');
    }

    if (!empty($aadhaarNumber)) {
        $checkAadhaar = $pdo->prepare("SELECT id FROM teachers WHERE aadhaar_number = ? AND id != ?");
        $checkAadhaar->execute([$aadhaarNumber, $applicationId]);
        if ($checkAadhaar->fetch()) {
            throw new Exception('This Aadhaar number is already registered with us.');
        }
    }

    if (!empty($panNumber)) {
        $checkPan = $pdo->prepare("SELECT id FROM teachers WHERE pan_number = ? AND id != ?");
        $checkPan->execute([$panNumber, $applicationId]);
        if ($checkPan->fetch()) {
            throw new Exception('This PAN number is already registered with us.');
        }
    }

    if (!empty($voterEpicNumber)) {
        $checkEpic = $pdo->prepare("SELECT id FROM teachers WHERE voter_epic_number = ? AND id != ?");
        $checkEpic->execute([$voterEpicNumber, $applicationId]);
        if ($checkEpic->fetch()) {
            throw new Exception('This Voter EPIC number is already registered with us.');
        }
    }

    // ---------------------------------------------------------
    // Photo - only replaced when the applicant re-cropped a new one.
    // The old file is removed after the row is safely updated.
    // ---------------------------------------------------------
    $uploadFolder = __DIR__ . '/../../uploads/teachers/';
    $photo = $current['teacher_image'] ?: 'default_teacher_dp.jpg';
    $oldPhotoToDelete = null;
    $imageData = $_POST['cropped_image_data'] ?? '';

    if (!empty($imageData)) {
        if (!preg_match('/^data:image\/(jpeg|png|jpg);base64,/', $imageData)) {
            throw new Exception('Invalid image format');
        }

        $imageData = str_replace(
            ['data:image/jpeg;base64,', 'data:image/png;base64,', 'data:image/jpg;base64,', ' '],
            ['', '', '', '+'],
            $imageData
        );
        $decodedImage = base64_decode($imageData);

        if ($decodedImage === false) {
            throw new Exception('Failed to process image data');
        }

        $tempFile = tempnam(sys_get_temp_dir(), 'teacher_photo_') . '.jpg';

        if (file_put_contents($tempFile, $decodedImage) === false) {
            throw new Exception('Failed to create temporary image file');
        }

        if (!isValidImageFile($tempFile)) {
            @unlink($tempFile);
            throw new Exception('You\'re trying to upload an unsupported format or currupted image.');
        }

        if (!is_dir($uploadFolder)) {
            @unlink($tempFile);
            throw new Exception('No upload folder found.');
        }

        $newPhoto = uniqid('tch_') . '.jpg';

        if (!copy($tempFile, $uploadFolder . $newPhoto)) {
            @unlink($tempFile);
            throw new Exception('Failed to upload image.');
        }

        unlink($tempFile);

        if ($photo !== 'default_teacher_dp.jpg') {
            $oldPhotoToDelete = $photo;
        }

        $photo = $newPhoto;
    }

    // ---------------------------------------------------------
    // Documents. The form posts back one hidden row per document the applicant
    // decided to keep, plus any brand new files. Anything missing from the
    // posted list was removed in the browser and is dropped here.
    //
    // Kept URLs are matched against the stored JSON instead of being trusted,
    // so an edited request can't smuggle an arbitrary image URL into the record.
    // ---------------------------------------------------------
    $storedDocuments = json_decode($current['documents'] ?? '[]', true);
    $storedDocuments = is_array($storedDocuments) ? $storedDocuments : [];

    $storedByUrl = [];
    foreach ($storedDocuments as $storedDocument) {
        if (!empty($storedDocument['document_url'])) {
            $storedByUrl[$storedDocument['document_url']] = $storedDocument;
        }
    }

    $documents = [];
    $keptUrls = $_POST['existing_document_url'] ?? [];
    $keptNames = $_POST['existing_document_name'] ?? [];

    if (is_array($keptUrls)) {
        foreach ($keptUrls as $index => $keptUrl) {
            if (!is_string($keptUrl) || !isset($storedByUrl[$keptUrl])) {
                continue; // not one of this application's own documents
            }

            $keptName = isset($keptNames[$index]) ? sanitize_input($keptNames[$index]) : '';

            if (empty($keptName)) {
                throw new Exception('Every attached document must have a name.');
            }

            $documents[] = [
                'document_name' => $keptName,
                'document_url'  => $keptUrl,
            ];

            // Guard against the same document being posted twice
            unset($storedByUrl[$keptUrl]);
        }
    }

    if (!empty($_FILES['document_file']['name']) && is_array($_FILES['document_file']['name'])) {
        $docNames = $_POST['document_name'] ?? [];
        $docFiles = $_FILES['document_file'];
        $totalDocs = count($docFiles['name']);

        // Reject an over-limit submission before spending time on any upload
        $filledSlots = 0;
        for ($i = 0; $i < $totalDocs; $i++) {
            if ($docFiles['error'][$i] !== UPLOAD_ERR_NO_FILE) {
                $filledSlots++;
            }
        }

        if (count($documents) + $filledSlots > MAX_TEACHER_DOCUMENTS) {
            throw new Exception('You can attach a maximum of ' . MAX_TEACHER_DOCUMENTS . ' documents. Please remove some before adding more.');
        }

        for ($i = 0; $i < $totalDocs; $i++) {
            // Skip empty slots (row added but nothing selected)
            if ($docFiles['error'][$i] === UPLOAD_ERR_NO_FILE) {
                continue;
            }

            $docName = isset($docNames[$i]) ? sanitize_input($docNames[$i]) : '';

            if (empty($docName)) {
                throw new Exception('Every attached document must have a name.');
            }

            $singleFile = [
                'name'     => $docFiles['name'][$i],
                'type'     => $docFiles['type'][$i],
                'tmp_name' => $docFiles['tmp_name'][$i],
                'error'    => $docFiles['error'][$i],
                'size'     => $docFiles['size'][$i],
            ];

            $documents[] = [
                'document_name' => $docName,
                'document_url'  => uploadDocumentToImgBB($singleFile, $docName . ' - ' . $name),
            ];
        }
    }

    if (count($documents) > MAX_TEACHER_DOCUMENTS) {
        throw new Exception('You can attach a maximum of ' . MAX_TEACHER_DOCUMENTS . ' documents.');
    }

    $documentsJson = !empty($documents) ? json_encode($documents) : null;

    // ---------------------------------------------------------
    // Save. The status guard in the WHERE clause makes sure an admin decision
    // taken while this form was open always wins over the applicant's edit.
    // ---------------------------------------------------------
    $sql = "UPDATE teachers SET
        name = ?, email = ?, phone = ?,
        date_of_birth = ?, gender = ?, blood_group = ?, caste_category = ?, religion = ?, nationality = ?, aadhaar_number = ?,
        father_name = ?, father_phone = ?, mother_name = ?, mother_phone = ?,
        position_in_school = ?, qualification = ?, subject_specialization = ?, has_experience = ?, previous_school = ?,
        pan_number = ?, voter_epic_number = ?, bank_name = ?, bank_branch = ?, ifsc_code = ?, account_number = ?,
        village = ?, post_office = ?, police_station = ?, district = ?, pincode = ?, address = ?,
        teacher_image = ?, documents = ?
        WHERE id = ? AND status = 'pending'";

    $stmt = $pdo->prepare($sql);
    $result = $stmt->execute([
        $name,
        $email,
        $phone,
        $dateOfBirth,
        $gender,
        $bloodGroup,
        $casteCategory,
        $religion,
        $nationality,
        $aadhaarNumber,
        $fatherName,
        $fatherPhone,
        $motherName,
        $motherPhone,
        $positionInSchool,
        $qualification,
        $specialization,
        $hasExperience,
        $previousSchool,
        $panNumber,
        $voterEpicNumber,
        $bankName,
        $bankBranch,
        $ifscCode,
        $accountNumber,
        $village,
        $postOffice,
        $policeStation,
        $district,
        $pincode,
        $address,
        $photo,
        $documentsJson,
        $applicationId
    ]);

    if (!$result) {
        throw new Exception('Failed to save your changes. Please try again.');
    }

    // Confirm the row was still pending when the UPDATE landed
    $statusCheck = $pdo->prepare("SELECT status FROM teachers WHERE id = ? LIMIT 1");
    $statusCheck->execute([$applicationId]);
    $statusNow = $statusCheck->fetchColumn();

    if ($statusNow !== 'pending') {
        // The admin decided on the application while this form was open, so the
        // edit was discarded. Drop the freshly uploaded photo to avoid orphans.
        if ($photo !== ($current['teacher_image'] ?: 'default_teacher_dp.jpg') && $photo !== 'default_teacher_dp.jpg') {
            @unlink($uploadFolder . $photo);
        }

        throw new Exception('The school processed your application while this form was open, so your changes were not saved. Please reload the page to see the latest status.');
    }

    // Safe to drop the replaced photo now that the new filename is persisted
    if ($oldPhotoToDelete !== null && $oldPhotoToDelete !== $photo) {
        $oldPhotoPath = $uploadFolder . $oldPhotoToDelete;

        if (file_exists($oldPhotoPath)) {
            @unlink($oldPhotoPath);
        }
    }

    echo json_encode([
        'success' => true,
        'message' => 'Your application has been updated successfully.',
        'application_ref' => formatTeacherApplicationRef((int) $applicationId)
    ]);
} catch (PDOException $e) {
    error_log("Database error in teacher application update: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error occurred. Please try again later.']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} catch (Error $e) {
    error_log("Fatal error in teacher application update: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An unexpected error occurred. Please try again later.']);
}
