<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/academic/student-application-access.php';
header('Cache-Control: private, no-store');
header('Referrer-Policy: no-referrer');
header('X-Robots-Tag: noindex, nofollow');
$h = static fn($value) => htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
$_SESSION['student_application_csrf'] ??= bin2hex(random_bytes(32));
$application = null;
$error = '';
$className = '';
try {
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['logout'])) {
        studentApplicationRequireCsrf($_POST);
        revokeStudentApplicationAccess();
        header('Location: track-student-application.php', true, 303);
        exit;
    }
    $application = fetchVerifiedStudentApplication($pdo);
    if ($application) {
        $class = $pdo->prepare('SELECT class_name FROM classes WHERE id = ?');
        $class->execute([$application['class_id']]);
        $className = $class->fetchColumn() ?: 'Class #' . $application['class_id'];
    }
} catch (Throwable $errorDetail) {
    error_log('Student application status: ' . $errorDetail->getMessage());
    http_response_code($errorDetail instanceof StudentApplicationAccessException ? $errorDetail->getCode() : 503);
    $error = $errorDetail instanceof StudentApplicationAccessException ? $errorDetail->getMessage()
        : 'Your application could not be loaded. Please try again later or contact the school.';
    $application = null;
}
$referenceId = parseStudentApplicationRef($_GET['ref'] ?? null);
$reference = $referenceId ? formatStudentApplicationRef($referenceId) : '';
$statusMeta = studentApplicationStatusMeta($application['status'] ?? null);
$isEditable = $application && isStudentApplicationEditable($application, $schoolSettings);
$detail = static function ($value) use ($h): string {
    return $value === null || $value === '' ? '<span class="text-muted">&mdash;</span>' : $h($value);
};
require_once __DIR__ . '/../../includes/header-open.php';
echo '<title>Track Student Application - ' . $h($school_name) . '</title>';
require_once __DIR__ . '/../../includes/header-close.php';
?>
<!-- student-application-tracker -->
<style>
    .application-tracker { max-width: 1000px; }
    .application-brand img { width: 80px; height: 80px; object-fit: contain; }
    .application-details dt { font-size: .85rem; color: #6c757d; }
    .application-details dd { overflow-wrap: anywhere; }
    .application-photo { width: 125px; height: 150px; object-fit: cover; }
</style>
<main class="container application-tracker py-4 mb-4">
    <div class="application-brand text-center mb-4">
        <a href="<?= $h(BASE_URL) ?>/" class="text-decoration-none">
            <img src="<?= $h($logo_square) ?>" alt="School Logo" class="rounded mb-2">
            <h1 class="h3 text-primary"><?= $h($school_name) ?></h1>
        </a>
    </div>
    <?php if ($error): ?><div class="alert alert-danger" role="alert"><?= $h($error) ?></div><?php endif; ?>
    <?php if (!$application): ?>
        <div class="card shadow-sm mx-auto" style="max-width:650px">
            <div class="card-header bg-primary text-white"><h2 class="h4 mb-0 py-2">Track Your Student Application</h2></div>
            <div class="card-body">
                <p class="text-muted">Enter your Application ID, the primary phone number provided on the application and the student's date of birth to view its status.</p>
                <div id="student-lookup-message" class="alert d-none" role="alert" aria-live="polite"></div>
                <form id="student-application-lookup" action="../action/verify-student-application-access.php" method="post" autocomplete="off">
                    <input type="hidden" name="csrf" value="<?= $h($_SESSION['student_application_csrf']) ?>">
                    <div class="mb-3">
                        <label for="application-ref" class="form-label">Application ID <span class="text-danger">*</span></label>
                        <input id="application-ref" name="application_ref" class="form-control" value="<?= $h($reference) ?>" maxlength="20" placeholder="SA000001" required>
                        <div class="form-text">Shown after you submitted the application. For an older application or a lost ID, please contact the school office.</div>
                    </div>
                    <div class="mb-3">
                        <label for="application-phone" class="form-label">Registered Primary Phone <span class="text-danger">*</span></label>
                        <input id="application-phone" name="phone_number" type="tel" inputmode="numeric" pattern="[0-9]{10}" maxlength="10" class="form-control" title="Enter the 10-digit primary phone number from your application" required>
                    </div>
                    <div class="mb-3">
                        <label for="application-dob" class="form-label">Student's Date of Birth <span class="text-danger">*</span></label>
                        <input id="application-dob" name="date_of_birth" type="date" max="<?= date('Y-m-d') ?>" class="form-control" required>
                    </div>
                    <div class="d-flex justify-content-center my-4"><div class="cf-turnstile" data-sitekey="<?= $h($websiteConfig['captcha_site_key'] ?? '') ?>"></div></div>
                    <button id="student-lookup-submit" type="submit" class="btn btn-primary w-100">View My Application</button>
                </form>
                <hr>
                <p class="small text-muted mb-0">Your details are private. Sign out when you finish, especially on a shared device.</p>
                <?php if (!empty($schoolSettings['admission_open'])): ?><a href="admission-enquiry.php" class="btn btn-outline-primary btn-sm mt-3">Apply for Admission</a><?php endif; ?>
            </div>
        </div>
        <script src="../../assets/js/student-application-track.js?v=<?= substr(hash_file('sha256', __DIR__ . '/../../assets/js/student-application-track.js'), 0, 16) ?>" defer></script>
    <?php else: ?>
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-primary text-white d-flex flex-wrap align-items-center justify-content-between gap-2">
                <h2 class="h4 mb-0 py-2">Application <?= $h(formatStudentApplicationRef((int)$application['id'])) ?></h2>
                <form method="post" action="track-student-application.php">
                    <input type="hidden" name="csrf" value="<?= $h($_SESSION['student_application_csrf']) ?>">
                    <button class="btn btn-light btn-sm" name="logout" value="1" type="submit">Sign Out</button>
                </form>
            </div>
            <div class="card-body">
                <div class="alert alert-<?= $h($statusMeta['badge']) ?>">
                    <h3 class="h5">Current Status: <span id="student-application-status"><?= $h($statusMeta['label']) ?></span></h3>
                    <p class="mb-0"><?= $h($statusMeta['description']) ?></p>
                </div>
                <dl class="row application-details mb-0">
                    <div class="col-sm-4"><dt>Submitted On</dt><dd><?= $detail($application['created_at'] ?? null) ?></dd></div>
                    <div class="col-sm-4"><dt>Applied Class</dt><dd><?= $detail($className) ?></dd></div>
                    <div class="col-sm-4"><dt>Academic Year</dt><dd><?= $detail($application['academic_year'] ?? null) ?></dd></div>
                    <?php if (!empty($application['processed_at'])): ?><div class="col-sm-6"><dt>Decision Date</dt><dd><?= $detail($application['processed_at']) ?></dd></div><?php endif; ?>
                    <?php if (!empty($application['student_id'])): ?><div class="col-sm-6"><dt>Student ID</dt><dd><?= $detail($application['student_id']) ?></dd></div><?php endif; ?>
                </dl>
                <?php if ($isEditable): ?>
                    <div class="alert alert-warning d-flex flex-wrap justify-content-between align-items-center gap-2 mb-0">
                        <span>Found a mistake? You can correct your application while it is under review.</span>
                        <a id="student-application-edit" href="edit-student-application.php" class="btn btn-warning">Edit Application</a>
                    </div>
                <?php elseif (($application['status'] ?? '') === 'pending'): ?>
                    <p class="alert alert-secondary mb-0">The school has disabled applicant edits. Please contact the school office if you need to correct your application.</p>
                <?php else: ?>
                    <p class="alert alert-secondary mb-0">The school has processed this application. Please contact the school office if any information needs to be corrected.</p>
                <?php endif; ?>
            </div>
        </div>
        <div class="card shadow-sm">
            <div class="card-header"><h2 class="h5 mb-0">Submitted Details</h2></div>
            <div class="card-body">
                <div class="d-flex flex-wrap align-items-center gap-3 mb-4">
                    <?php if (!empty($application['student_image'])): ?><img src="<?= $h(schoolPhotoUrl('students', $application['student_image'])) ?>" alt="Student photo" class="application-photo rounded border"><?php endif; ?>
                    <strong class="fs-5"><?= $h($application['name']) ?></strong>
                </div>
                <?php foreach ([
                    'Student' => ['gender' => 'Gender', 'date_of_birth' => 'Date of Birth', 'blood_group' => 'Blood Group', 'religion' => 'Religion', 'student_adhaar_no' => 'Student Aadhaar', 'preferred_by' => 'Referred / Preferred By'],
                    'Parents and Contact' => ['father_name' => "Father's Name", 'mother_name' => "Mother's Name", 'father_occupation' => "Father's Occupation", 'mother_occupation' => "Mother's Occupation", 'father_adhaar_no' => "Father's Aadhaar", 'mother_adhaar_no' => "Mother's Aadhaar", 'phone_number' => 'Primary Phone', 'alternate_phone_number' => 'Alternate Phone', 'email' => 'Email'],
                    'Address' => ['village' => 'Village / Town', 'post_office' => 'Post Office', 'police_station' => 'Police Station', 'district' => 'District', 'pin_code' => 'PIN Code', 'address' => 'Full Address'],
                ] as $section => $fields): ?>
                    <h3 class="h6 text-primary border-bottom pb-2"><?= $h($section) ?></h3>
                    <dl class="row application-details">
                        <?php foreach ($fields as $field => $label): ?><div class="col-sm-6 col-lg-4"><dt><?= $h($label) ?></dt><dd><?= $detail($application[$field] ?? null) ?></dd></div><?php endforeach; ?>
                    </dl>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
</main>
<?php require_once __DIR__ . '/../../includes/body-close.php'; ?>
