<?php
/** @var string $school_name
 * @var PDO $pdo
 * @var array $schoolSettings
 * @var array $websiteConfig
 * @var string $assets_version
 * @var string $logo_square
 * @var array $schoolInfo
 */
include_once("../../includes/header-open.php");
require_once __DIR__ . "/../../includes/academic/admission-enquiry-service.php";
$applicationYears = admissionEnquiryYears();
echo "<title>Student Application - " . $school_name . "</title>";
include_once("../../includes/header-close.php");

if ((int)($schoolSettings['admission_open'] ?? 0) !== 1) {
    echo '<script>location.replace("/");</script>';
    die();
}

// Fetch all classes
$classes = $pdo->query("SELECT * FROM classes")->fetchAll(PDO::FETCH_ASSOC);

// Blood group options
$blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

// Religion options
$religions = [
    'islam',
    'hindu',
    'christian',
    'buddhist',
    'jain',
    'sikh',
    'parsi',
    'judaism',
    'bahai',
    'atheist',
    'agnostic',
    'other'
];
?>

<style>
    /* ---------- Image field: clickable tile + camera/gallery picker ---------- */
    .image-field {
        display: flex;
        gap: 18px;
        align-items: flex-start;
        flex-wrap: wrap;
    }

    /* Document fields stack the tile above its Remove link instead of sitting side-by-side */
    .image-field.field-stacked {
        display: block;
    }

    .image-tile {
        position: relative;
        flex: 0 0 auto;
        border: 2px dashed #c7ced6;
        border-radius: 10px;
        background-color: #f8f9fa;
        cursor: pointer;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: border-color .18s ease, background-color .18s ease, box-shadow .18s ease;
    }

    /* Portrait tile for student / father / mother photos (5:6) */
    .image-tile.tile-portrait {
        width: 125px;
        height: 150px;
    }

    /* Landscape tile for ID cards & certificates */
    .image-tile.tile-landscape {
        width: 100%;
        height: 105px;
    }

    .image-tile:hover,
    .image-tile:focus-visible {
        border-color: var(--primary-color);
        background-color: #fff;
        box-shadow: 0 0 0 4px rgba(13, 110, 253, .10);
        outline: none;
    }

    .image-tile.has-image {
        border-style: solid;
        border-color: #dee2e6;
        background-color: #fff;
    }

    .image-tile .tile-preview {
        display: none;
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .image-tile.has-image .tile-preview {
        display: block;
    }

    .image-tile .tile-placeholder {
        text-align: center;
        color: #8a949e;
        font-size: 13px;
        line-height: 1.45;
        padding: 6px;
        pointer-events: none;
    }

    .image-tile .tile-placeholder i {
        display: block;
        margin-bottom: 6px;
        font-size: 21px;
        color: #adb5bd;
    }

    .image-tile.has-image .tile-placeholder {
        display: none;
    }

    .image-tile .tile-overlay {
        position: absolute;
        right: 0;
        bottom: 0;
        left: 0;
        padding: 4px 0;
        background-color: rgba(0, 0, 0, .55);
        color: #fff;
        font-size: 12px;
        text-align: center;
        opacity: 0;
        transition: opacity .18s ease;
        pointer-events: none;
    }

    .image-tile.has-image:hover .tile-overlay {
        opacity: 1;
    }

    .image-field-meta {
        flex: 1 1 190px;
        min-width: 170px;
    }

    .tile-clear {
        display: none;
    }

    /* Camera / Gallery source-picker popup */
    .photo-source-menu {
        display: none;
        position: absolute;
        z-index: 2000;
        background: #fff;
        border: 1px solid #ddd;
        border-radius: 6px;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.18);
        min-width: 150px;
        overflow: hidden;
    }

    .photo-source-menu button {
        display: block;
        width: 100%;
        border: none;
        background: none;
        padding: 10px 14px;
        text-align: left;
        font-size: 14px;
        cursor: pointer;
        white-space: nowrap;
    }

    .photo-source-menu button:hover,
    .photo-source-menu button:focus {
        background-color: #f1f3f5;
    }

    .photo-source-menu button i {
        width: 18px;
        margin-right: 6px;
        color: var(--primary-color);
    }

    .photo-source-menu .photo-source-divider {
        border-top: 1px solid #eee;
    }

    /* ---------- Cropper modal ---------- */
    #cropModal .modal-dialog {
        max-width: 90%;
    }

    .img-container {
        position: relative;
        overflow: hidden;
        margin: 0 auto;
        width: 100%;
        height: 70vh;
        min-height: 360px;
        max-height: 600px;
        background-color: #f8f9fa;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    #imageToCrop {
        display: block;
        max-width: 100%;
        max-height: 100%;
    }

    .cropper-container {
        width: 100% !important;
        height: 100% !important;
    }

    .cropper-modal {
        background-color: rgba(255, 255, 255, 0.8);
    }

    .cropper-view-box {
        outline: 2px solid #007bff;
        outline-color: rgba(0, 123, 255, 0.75);
    }

    .logo-container {
        align-items: center;
        text-align: center;
        padding: 0.8rem;
    }

    .logo-container .navbar-brand {
        display: block;
        align-items: center;
        justify-content: center;
        gap: 10px;
        text-decoration: none;
    }

    .navbar-brand img {
        height: 100px;
        width: 100px;
        object-fit: cover;
    }

    .navbar-brand-text {
        color: var(--primary-color);
        text-transform: uppercase;
        font-size: 2rem;
        white-space: normal;
        /* Allows word wrapping */
        word-wrap: break-word;
        /* Breaks long words if needed */
        text-align: center;
        /* Optional: center-align text */
        max-width: 100%;
        /* Prevent overflow */
        font-family: "Oswald", sans-serif;
        font-optical-sizing: auto;
        font-weight: 700;
        font-style: normal;
        margin: 1rem 0;
    }
</style>

<div class="container mt-4 mb-5">

    <!-- School Name & Logo Section -->
    <div class="logo-container container">
        <a class="navbar-brand" href="/">
            <img src="<?= $logo_square ?>" alt="School Logo" onerror="this.style.display='none'"
                class="rounded">
            <div class="navbar-brand-text"><?= $schoolInfo['name']; ?></div>
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0 py-2"><i class="fa-solid fa-graduation-cap"></i> Admission Enquiry</h4>
        </div>

        <div class="card-body">
            <form id="studentAdmissionForm" method="post" enctype="multipart/form-data">
                <div class="row g-3">
                    <!-- Personal Information Section -->
                    <div class="col-md-12">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-user-circle me-2"></i>Student Information
                        </h5>
                    </div>

                    <div class="col-md-4">
                        <label for="name" class="form-label">Student Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="name" name="name" maxlength="100" required placeholder="Student's full name">
                    </div>

                    <div class="col-md-4">
                        <label for="gender" class="form-label">Student Gender <span class="text-danger">*</span></label>
                        <select class="form-select" id="gender" name="gender" required>
                            <option value="" selected disabled>Select Gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="date_of_birth" class="form-label">Date of Birth <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" max="<?= date('Y-m-d') ?>" required>
                    </div>

                    <div class="col-md-4">
                        <label for="blood_group" class="form-label">Blood Group</label>
                        <select class="form-select" id="blood_group" name="blood_group">
                            <option value="" selected>Select Blood Group</option>
                            <?php foreach ($blood_groups as $group): ?>
                                <option value="<?= $group ?>"><?= $group ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="class_id" class="form-label">Class <span class="text-danger">*</span></label>
                        <select class="form-select" id="class_id" name="class_id" required>
                            <option value="" selected disabled>Select Class</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?= $class['id'] ?>"><?= safe_htmlspecialchars($class['class_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="religion" class="form-label">Religion</label>
                        <select class="form-select" id="religion" name="religion">
                            <option value="" selected>Select Religion</option>
                            <?php foreach ($religions as $religion): ?>
                                <option value="<?= $religion ?>"><?= ucwords($religion) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="student_adhaar" class="form-label">Student's Adhaar No.</label>
                        <input type="text" class="form-control" id="student_adhaar" name="student_adhaar" maxlength="20" placeholder="Enter student adhaar number"/>
                    </div>

                    <div class="col-md-4">
                        <label for="academic_year" class="form-label">Academic Year <span class="text-danger">*</span></label>
                        <select class="form-select" id="academic_year" name="academic_year" required>
                            <option value="" selected disabled>Select Academic Year</option>
                            <?php foreach ($applicationYears as $applicationYear): ?>
                                <option value="<?= $applicationYear ?>"><?= $applicationYear ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <div class="image-field" data-crop="1" data-crop-title="Crop Student Photo (5:6 ratio required)">
                            <div class="image-tile tile-portrait" tabindex="0" role="button" aria-label="Add student passport photo">
                                <img class="tile-preview" id="imagePreview" src="" alt="Student photo preview">
                                <div class="tile-placeholder">
                                    <i class="fas fa-camera"></i>
                                    Add photo
                                </div>
                                <div class="tile-overlay"><i class="fas fa-pen me-1"></i>Change</div>
                            </div>
                            <div class="image-field-meta">
                                <label class="form-label mb-1">Student Photo (optional, 5:6 Ratio)</label>
                                <small class="text-muted d-block">Click the box to take a photo with the camera, or pick one from the gallery. Saved at 500&times;600 pixels.</small>
                                <button type="button" class="btn btn-sm btn-link text-danger p-0 mt-2 tile-clear">
                                    <i class="fas fa-trash-alt me-1"></i>Remove photo
                                </button>
                            </div>
                            <input type="file" class="src-gallery d-none" id="student_image" name="student_image" accept="image/*">
                            <input type="file" class="src-camera d-none" accept="image/*" capture="environment">
                            <input type="hidden" class="cropped-data" id="cropped_image_data" name="cropped_image_data">
                        </div>
                    </div>

                    <!-- Address Information Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-location-dot me-2"></i>Address
                        </h5>
                    </div>

                    <div class="col-md-4">
                        <label for="village" class="form-label">Village/Town</label>
                        <input type="text" class="form-control" id="village" name="village" maxlength="50" placeholder="Enter village or town name">
                    </div>

                    <div class="col-md-4">
                        <label for="post_office" class="form-label">Post Office</label>
                        <input type="text" class="form-control" id="post_office" name="post_office" maxlength="50" placeholder="Enter post office">
                    </div>

                    <div class="col-md-4">
                        <label for="police_station" class="form-label">Police Station</label>
                        <input type="text" class="form-control" id="police_station" name="police_station" maxlength="50" placeholder="Enter police station">
                    </div>

                    <div class="col-md-4">
                        <label for="district" class="form-label">District</label>
                        <input type="text" class="form-control" id="district" name="district" maxlength="50" placeholder="Enter district name">
                    </div>

                    <div class="col-md-4">
                        <label for="pin_code" class="form-label">Pin Code</label>
                        <input type="text" class="form-control" id="pin_code" name="pin_code" maxlength="10" placeholder="Enter pin code">
                    </div>

                    <!-- Family Information Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-users me-2"></i>Family Information
                        </h5>
                    </div>

                    <div class="col-md-6">
                        <label for="father_name" class="form-label">Father's Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="father_name" name="father_name" maxlength="100" required placeholder="Father's name">
                    </div>

                    <div class="col-md-6">
                        <label for="mother_name" class="form-label">Mother's Name</label>
                        <input type="text" class="form-control" id="mother_name" name="mother_name" maxlength="100" placeholder="Mother's name">
                    </div>

                    <div class="col-md-6">
                        <label for="father_occupation" class="form-label">Father's Occupation</label>
                        <input type="text" class="form-control" id="father_occupation" name="father_occupation" maxlength="100" placeholder="Occupation">
                    </div>

                    <div class="col-md-6">
                        <label for="mother_occupation" class="form-label">Mother's Occupation</label>
                        <input type="text" class="form-control" id="mother_occupation" name="mother_occupation" maxlength="100" placeholder="Occupation">
                    </div>

                    <div class="col-md-6">
                        <label for="father_adhaar" class="form-label">Father's Adhaar No.</label>
                        <input type="text" class="form-control" id="father_adhaar" name="father_adhaar" maxlength="20" placeholder="Enter father adhaar number"/>
                    </div>

                    <div class="col-md-6">
                        <label for="mother_adhaar" class="form-label">Mother's Adhaar No.</label>
                        <input type="text" class="form-control" id="mother_adhaar" name="mother_adhaar" maxlength="20" placeholder="Enter mother adhaar number"/>
                    </div>

                    <div class="col-md-4">
                        <label for="phone_number" class="form-label">Father's Phone Number (Primary) <span class="text-danger"> *</span>
                            <i title="This phone number will be used as primary phone number. OTPs will be sent to this number. Enter phone number without country code." class="fa-solid fa-circle-question"></i>
                        </label>
                        <input type="tel" class="form-control" id="phone_number" name="phone_number" pattern="[0-9]{10}" maxlength="10" inputmode="numeric" required placeholder="10 digit phone number">
                    </div>

                    <div class="col-md-4">
                        <label for="alternate_phone_number" class="form-label">Alternate Phone Number
                            <i title="This phone number will be used as alternate phone number if primary number is not reachable. Enter phone number without country code." class="fa-solid fa-circle-question"></i>
                        </label>
                        <input type="tel" class="form-control" id="alternate_phone_number" name="alternate_phone_number" pattern="[0-9]{10}" maxlength="10" inputmode="numeric" placeholder="10 digit alternate phone number">
                    </div>

                    <div class="col-md-4">
                        <label for="email" class="form-label">Email Id</label>
                        <input type="email" class="form-control" id="email" name="email" maxlength="100" placeholder="Enter a permanent email id">
                    </div>

                    <!-- Other Information -->
                     <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fa-solid fa-info-circle"></i> Other Information
                        </h5>
                    </div>

                    <div class="col-md-6">
                        <label for="preferred_by" class="form-label">Preferred By</label> <i title="How did you hear about us?" class="fa-solid fa-circle-question"></i>
                        <input type="text" class="form-control" id="preferred_by" name="preferred_by" maxlength="100" placeholder="How did you know about us?">
                    </div>

                    <!-- Cloudflare Turnstile Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fa-solid fa-shield-halved"></i> Captcha Validation
                        </h5>
                    </div>
                    <div class="turnstile-container col-md-12 d-flex justify-content-center">
                        <div class="cf-turnstile" data-sitekey="<?= $websiteConfig['captcha_site_key'] ?>"></div>
                    </div>
                </div>

                <div class="mt-5 mb-3 text-center">
                    <button id="submitBtn" type="submit" class="btn btn-primary px-4 py-2">
                        <i class="fas fa-plus-circle me-2"></i> Apply Admission
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Shared Camera / Gallery source picker (student photo) -->
<div id="photoSourceMenu" class="photo-source-menu">
    <button type="button" class="photo-source-camera"><i class="fas fa-camera"></i> Camera</button>
    <div class="photo-source-divider"></div>
    <button type="button" class="photo-source-gallery"><i class="fas fa-image"></i> Gallery</button>
</div>

<!-- Shared cropper modal, student photo -->
<div class="modal fade" id="cropModal" tabindex="-1" aria-labelledby="cropModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cropModalLabel">Crop Photo (5:6 ratio required)</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <div class="img-container">
                    <img id="imageToCrop" src="" alt="Image to crop">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="cropImageBtn">
                    <i class="fas fa-crop-simple me-1"></i> Crop &amp; Save
                </button>
            </div>
        </div>
    </div>
</div>

<script>
    let turnstileWidgetId;

    // Initialize Turnstile when DOM is ready
    function initTurnstile() {
        const container = document.querySelector('.cf-turnstile');

        if (typeof turnstile !== 'undefined' && container && !turnstileWidgetId) {
            try {
                turnstileWidgetId = turnstile.render(container, {
                    sitekey: '<?= $websiteConfig['captcha_site_key'] ?>',
                    theme: 'light',
                    size: 'normal'
                });
                console.log('Turnstile initialized successfully');
            } catch (error) {
                console.error('Turnstile initialization error:', error);
                // Retry after a short delay
                setTimeout(initTurnstile, 500);
            }
        } else if (typeof turnstile === 'undefined') {
            // If Turnstile hasn't loaded yet, wait and try again
            setTimeout(initTurnstile, 200);
        }
    }

    // Helper function to reset Turnstile
    function resetTurnstile() {
        if (typeof turnstile !== 'undefined' && turnstileWidgetId !== undefined) {
            try {
                turnstile.reset(turnstileWidgetId);
            } catch (error) {
                console.error('Error resetting Turnstile:', error);
            }
        }
    }

    $(document).ready(function() {

        // Start initialization
        initTurnstile();

        // AJAX form submission
        $('#studentAdmissionForm').submit(function(e) {
            e.preventDefault();

            if ($('#student_image')[0].files.length && !$('#cropped_image_data').val()) {
                toastr.error('Please crop and save the student photo, or remove it.');
                return;
            }
            // Check if Turnstile is completed
            let turnstileResponse = '';
            if (typeof turnstile !== 'undefined' && turnstileWidgetId !== undefined) {
                try {
                    turnstileResponse = turnstile.getResponse(turnstileWidgetId);
                } catch (error) {
                    console.error('Error getting Turnstile response:', error);
                }
            }

            if (!turnstileResponse) {
                toastr.error('Please complete the captcha verification');
                return;
            }

            const formData = new FormData(this);
            formData.set('cf-turnstile-response', turnstileResponse);
            // Submit the saved crop only, including browsers without DataTransfer support.
            if ($('#cropped_image_data').val()) formData.delete('student_image');
            let btn = $('#submitBtn');
            let submitBtnHtml = $('#submitBtn').html();

            $.ajax({
                url: '../action/process-student-enquiry.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'json',
                beforeSend: function() {
                    btn.prop('disabled', true);
                    btn.html("Sending...");
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        // Show sweetalert2 message here
                        Swal.fire({
                            icon: 'success',
                            title: 'Application Submitted',
                            text: response.message,
                            confirmButtonColor: '#3085d6',
                        });
                        $('#studentAdmissionForm')[0].reset();
                        window.resetAllImageFields();

                    } else {
                        toastr.error(response.message);
                        // Show sweetalert2 error message here
                        Swal.fire({
                            icon: 'error',
                            title: 'Application Submission Failed',
                            text: response.message
                        });
                    }

                    btn.prop('disabled', false);
                    btn.html(submitBtnHtml);
                },
                error: function(xhr, status, error) {
                    let message = 'The application could not be submitted. Please try again or contact the school.';
                    if (xhr.responseJSON?.success === false && typeof xhr.responseJSON.message === 'string' && xhr.responseJSON.message.trim()) {
                        message = xhr.responseJSON.message;
                    } else if (xhr.status === 413) {
                        message = 'The uploaded data is too large. Please choose a smaller photo and try again.';
                    } else if (xhr.status === 0) {
                        message = 'Could not reach the school server. Please check your connection and try again.';
                    }
                    toastr.error(message);
                    Swal.fire({
                        icon: 'error',
                        title: 'Application Submission Failed',
                        text: message
                    });
                    btn.prop('disabled', false);
                    btn.html(submitBtnHtml);
                    console.error('Admission submission failed:', xhr.status, status);
                },
                complete: function() {
                    // Reset Turnstile after form submission
                    resetTurnstile();
                }
            });
        });
    });
    (function initImageFields() {
        const $sourceMenu = $('#photoSourceMenu');
        const cropModalEl = document.getElementById('cropModal');
        const cropModal = new bootstrap.Modal(cropModalEl);
        const imageToCrop = document.getElementById('imageToCrop');

        let $activeField = null; // field whose tile was last activated
        let cropper = null;
        let pickedFileName = 'photo.jpg';

        // ---- tile state -------------------------------------------------
        function showPreview($field, url) {
            const previous = $field.data('previewUrl');
            if (previous) URL.revokeObjectURL(previous);
            $field.data('previewUrl', url);

            $field.find('.tile-preview').attr('src', url);
            $field.find('.image-tile').addClass('has-image');
            $field.find('.tile-clear').css('display', 'inline-block');
        }

        function clearField($field) {
            const previous = $field.data('previewUrl');
            if (previous) URL.revokeObjectURL(previous);
            $field.removeData('previewUrl');

            $field.find('.tile-preview').attr('src', '');
            $field.find('.image-tile').removeClass('has-image');
            $field.find('.tile-clear').hide();
            $field.find('.src-gallery, .src-camera').val('');
            $field.find('.cropped-data').val('');
        }

        // Copy a File into the named input so it still arrives in $_FILES
        function assignToNamedInput($field, file) {
            try {
                const dt = new DataTransfer();
                dt.items.add(file);
                $field.find('.src-gallery')[0].files = dt.files;
            } catch (err) {
                // The saved crop still travels in .cropped-data on older browsers.
                console.warn('Could not attach the file to the form input:', err);
            }
        }

        // ---- Camera / Gallery popup -------------------------------------
        function openSourceMenu($tile) {
            $activeField = $tile.closest('.image-field');

            const offset = $tile.offset();
            const menuWidth = $sourceMenu.outerWidth() || 150;
            const maxLeft = $(window).width() - menuWidth - 12;

            $sourceMenu.css({
                top: offset.top + $tile.outerHeight() + 6,
                left: Math.max(12, Math.min(offset.left, maxLeft))
            }).show();
        }

        // Bound directly (not delegated) so stopPropagation actually keeps the
        // document-level close handler from firing on the same click.
        $('.image-tile').on('click', function(e) {
            e.stopPropagation();
            openSourceMenu($(this));
        });

        // The tiles are focusable, so keyboard users get the same picker
        $('.image-tile').on('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ' || e.key === 'Spacebar') {
                e.preventDefault();
                e.stopPropagation();
                openSourceMenu($(this));
            }
        });

        $sourceMenu.on('click', function(e) {
            e.stopPropagation();
        });

        $(document).on('click', function() {
            $sourceMenu.hide();
        });

        $(document).on('keydown', function(e) {
            if (e.key === 'Escape') $sourceMenu.hide();
        });

        $sourceMenu.find('.photo-source-camera').on('click', function() {
            $sourceMenu.hide();
            // Native click: guarantees the file dialog opens inside the gesture
            if ($activeField) $activeField.find('.src-camera')[0].click();
        });

        $sourceMenu.find('.photo-source-gallery').on('click', function() {
            $sourceMenu.hide();
            if ($activeField) $activeField.find('.src-gallery')[0].click();
        });

        // ---- a file arrived from either source ---------------------------
        $('.src-gallery, .src-camera').on('change', function() {
            const file = this.files && this.files[0];
            if (!file) return;

            const $field = $(this).closest('.image-field');
            $activeField = $field;

            if (!file.type || file.type.indexOf('image/') !== 0) {
                toastr.error('Please choose an image file.');
                this.value = '';
                return;
            }

            if (typeof Cropper === 'undefined') {
                toastr.error('The photo editor could not load. Please reload the page.');
                this.value = '';
                return;
            }
            pickedFileName = 'student-photo.jpg';

            // Photos: hand off to the shared 5:6 cropper
            const reader = new FileReader();
            reader.onload = function(event) {
                $('#cropModalLabel').text($field.data('crop-title') || 'Crop Photo (5:6 ratio required)');
                imageToCrop.src = event.target.result;
                cropModal.show();
            };
            reader.onerror = function() {
                $field.find('.src-gallery, .src-camera').val('');
                toastr.error('The selected photo could not be read. Please choose another image.');
            };
            reader.readAsDataURL(file);
        });

        imageToCrop.addEventListener('error', function() {
            if (!imageToCrop.getAttribute('src')) return;
            toastr.error('This image could not be opened. Please choose a JPG, PNG or WebP photo.');
            cropModal.hide();
        });

        // ---- cropper lifecycle ------------------------------------------
        $(cropModalEl).on('shown.bs.modal', function() {
            if (cropper) cropper.destroy();
            cropper = new Cropper(imageToCrop, {
                aspectRatio: 5 / 6,
                viewMode: 1,
                autoCropArea: 0.8,
                responsive: true,
                restore: false,
                guides: true,
                center: true,
                highlight: false,
                cropBoxMovable: true,
                cropBoxResizable: true,
                toggleDragModeOnDblclick: false
            });
        });

        $('#cropImageBtn').on('click', function() {
            if (!cropper || !$activeField) return;

            const canvas = cropper.getCroppedCanvas({
                width: 500,
                height: 600,
                fillColor: '#fff',
                imageSmoothingEnabled: true,
                imageSmoothingQuality: 'high'
            });
            if (!canvas) return;

            const $field = $activeField;
            const fileName = pickedFileName;

            canvas.toBlob(function(blob) {
                if (!blob) return;

                assignToNamedInput($field, new File([blob], fileName, {
                    type: 'image/jpeg',
                    lastModified: Date.now()
                }));

                // The camera input has done its job - clear it so it never submits
                $field.find('.src-camera').val('');

                $field.find('.cropped-data').val(canvas.toDataURL('image/jpeg', 0.9));
                showPreview($field, URL.createObjectURL(blob));

                cropModal.hide();
            }, 'image/jpeg', 0.9);
        });

        $(cropModalEl).on('hidden.bs.modal', function() {
            if (cropper) {
                cropper.destroy();
                cropper = null;
            }
            imageToCrop.src = '';

            // Closed without cropping: drop the raw pick so a half-finished
            // selection cannot be submitted. An earlier crop is left untouched.
            if ($activeField && !$activeField.find('.cropped-data').val()) {
                $activeField.find('.src-gallery, .src-camera').val('');
            }
        });

        // ---- remove ------------------------------------------------------
        $('.tile-clear').on('click', function(e) {
            e.stopPropagation();
            clearField($(this).closest('.image-field'));
        });

        // Reused by the reset path after a student is saved successfully
        window.resetAllImageFields = function() {
            $('.image-field').each(function() {
                clearField($(this));
            });
        };
    })();
</script>

<?php include_once("../../includes/body-close.php"); ?>
