<?php
/** @var string $school_name
 * @var PDO $pdo
 * @var array $schoolSettings
 * @var array $websiteConfig
 * @var string $assets_version
 * @var string $logo_square
 * @var array $schoolInfo
 */
include_once("../../includes/header-open.php");
echo "<title>Track Teacher Application - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/teacher/fun-teacher-application-access.php");

if ($schoolSettings['teacher_application'] == 0) {
    echo '<script>location.replace("/");</script>';
    die();
}

// Explicit sign-out, so a verified session is not left open on a shared device
if (isset($_GET['logout'])) {
    revokeTeacherApplicationAccess();
    echo '<script>location.replace("track-teacher-application.php");</script>';
    die();
}

$application = fetchVerifiedTeacherApplication($pdo);
$statusMeta = $application ? teacherApplicationStatusMeta($application['status']) : null;
$isEditable = $application ? (isTeacherApplicationEditable($application['status']) && !empty($schoolSettings['allow_edit_teacher_application'])) : false;

/**
 * Render a value in the read-only detail grid, falling back to a dash.
 */
function detailValue($value): string
{
    $value = is_string($value) ? trim($value) : $value;

    if ($value === null || $value === '' || $value === []) {
        return '<span class="text-muted">&mdash;</span>';
    }

    return safe_htmlspecialchars((string) $value);
}
?>

<style>
    .logo-container {
        align-items: center;
        text-align: center;
        padding: 0.8rem;
    }

    .logo-container .navbar-brand {
        display: block;
        text-decoration: none;
    }

    .navbar-brand img {
        height: 100px;
        width: 100px;
        object-fit: cover;
    }

    .navbar-brand-text {
        color: var(--primary-color);
        text-transform: uppercase;
        font-size: 2rem;
        white-space: normal;
        word-wrap: break-word;
        text-align: center;
        max-width: 100%;
        font-family: "Oswald", sans-serif;
        font-optical-sizing: auto;
        font-weight: 700;
        font-style: normal;
        margin: 1rem 0;
    }

    .status-hero {
        border-radius: 10px;
        padding: 1.5rem;
    }

    .status-hero .status-icon {
        font-size: 2.5rem;
    }

    .detail-grid dt {
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.03em;
        color: #6c757d;
        font-weight: 600;
        margin-bottom: 2px;
    }

    .detail-grid dd {
        margin-bottom: 1rem;
        font-weight: 500;
        word-break: break-word;
    }

    .applicant-photo {
        max-width: 160px;
        border-radius: 8px;
        object-fit: cover;
    }

    .doc-thumb {
        width: 100%;
        height: 130px;
        object-fit: cover;
        border-radius: 6px 6px 0 0;
        background-color: #f8f9fa;
    }

    .ref-chip {
        font-family: "Courier New", monospace;
        font-size: 1.1rem;
        letter-spacing: 0.08em;
    }
</style>

<div class="container mt-4 mb-5">
    <!-- School Name & Logo Section -->
    <div class="logo-container container">
        <a class="navbar-brand" href="/">
            <img src="<?= $logo_square ?>" alt="School Logo" onerror="this.style.display='none'" class="rounded">
            <div class="navbar-brand-text"><?= $schoolInfo['name']; ?></div>
        </a>
    </div>

    <?php if (!$application): ?>
        <!-- ============ Lookup form ============ -->
        <div class="row justify-content-center">
            <div class="col-lg-7">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0 py-2"><i class="fa-solid fa-magnifying-glass-chart"></i> Track Your Teacher Application</h4>
                    </div>
                    <div class="card-body">
                        <p class="text-muted">
                            Enter the details below to see the current status of your application. While your
                            application is still under review you can also correct anything you filled in
                            by mistake.
                        </p>

                        <form id="trackApplicationForm" method="post" autocomplete="off">
                            <div class="mb-3">
                                <label for="application_ref" class="form-label">Application ID <span class="text-danger">*</span></label>
                                <input type="text" class="form-control ref-chip" id="application_ref" name="application_ref"
                                    required placeholder="TA0001">
                                <small class="text-muted">
                                    Sent to your email right after you submitted the application (for example <strong>TA0001</strong>).
                                </small>
                            </div>

                            <div class="mb-3">
                                <label for="email" class="form-label">Registered Email <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>

                            <div class="mb-3">
                                <label for="date_of_birth" class="form-label">Date of Birth <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" required>
                            </div>

                            <div class="turnstile-container d-flex justify-content-center my-4">
                                <div class="cf-turnstile" data-sitekey="<?= $websiteConfig['captcha_site_key'] ?>"></div>
                            </div>

                            <div class="text-center">
                                <button type="submit" class="btn btn-primary px-4 py-2">
                                    <i class="fas fa-unlock-keyhole me-2"></i> View My Application
                                </button>
                            </div>
                        </form>

                        <hr class="my-4">

                        <p class="small text-muted mb-0">
                            Lost your Application ID? Please contact the school office at
                            <a href="mailto:<?= safe_htmlspecialchars($schoolInfo['email']) ?>"><?= safe_htmlspecialchars($schoolInfo['email']) ?></a>.
                            Haven't applied yet?
                            <a href="teacher-application.php">Apply as a teacher</a>.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <!-- ============ Verified: status + details ============ -->
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-primary text-white d-flex flex-wrap justify-content-between align-items-center gap-2">
                <h4 class="mb-0 py-2">
                    <i class="fa-solid fa-file-lines"></i> Application
                    <span class="ref-chip"><?= formatTeacherApplicationRef((int) $application['id']) ?></span>
                </h4>
                <a href="?logout=1" class="btn btn-sm btn-light">
                    <i class="fas fa-right-from-bracket me-1"></i> Sign Out
                </a>
            </div>

            <div class="card-body">
                <div class="status-hero bg-<?= $statusMeta['badge'] ?> bg-opacity-10 border border-<?= $statusMeta['badge'] ?> border-opacity-25">
                    <div class="d-flex align-items-start gap-3">
                        <div class="status-icon text-<?= $statusMeta['badge'] ?>">
                            <i class="fa-solid <?= $statusMeta['icon'] ?>"></i>
                        </div>
                        <div>
                            <h5 class="mb-1">
                                Current Status:
                                <span class="badge bg-<?= $statusMeta['badge'] ?>"><?= $statusMeta['label'] ?></span>
                            </h5>
                            <p class="mb-0 text-body-secondary"><?= $statusMeta['description'] ?></p>
                        </div>
                    </div>
                </div>

                <div class="row g-3 mt-4">
                    <div class="col-md-4">
                        <dl class="detail-grid mb-0">
                            <dt>Application ID</dt>
                            <dd class="ref-chip"><?= formatTeacherApplicationRef((int) $application['id']) ?></dd>
                        </dl>
                    </div>
                    <div class="col-md-4">
                        <dl class="detail-grid mb-0">
                            <dt>Submitted On</dt>
                            <dd><?= $application['application_date'] ? date('d M Y, h:i A', strtotime($application['application_date'])) : detailValue(null) ?></dd>
                        </dl>
                    </div>
                    <div class="col-md-4">
                        <dl class="detail-grid mb-0">
                            <dt>Last Updated</dt>
                            <dd><?= $application['updated_at'] ? date('d M Y, h:i A', strtotime($application['updated_at'])) : detailValue(null) ?></dd>
                        </dl>
                    </div>
                </div>

                <?php if ($isEditable): ?>
                    <div class="alert alert-warning d-flex flex-wrap justify-content-between align-items-center gap-2 mt-4 mb-0">
                        <div>
                            <i class="fas fa-pen-to-square me-1"></i>
                            Spotted a mistake? You can still edit every detail of this application
                            until the school makes a decision.
                        </div>
                        <a href="edit-teacher-application.php" class="btn btn-warning">
                            <i class="fas fa-pen me-1"></i> Edit Application
                        </a>
                    </div>
                <?php else: ?>
                    <div class="alert alert-secondary mt-4 mb-0">
                        <i class="fas fa-lock me-1"></i>
                        This application is no longer editable because the school has already
                        processed it. Please contact the school office if something needs to be corrected.
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="card-header bg-light">
                <h5 class="mb-0 py-1 text-primary"><i class="fas fa-list-check me-2"></i>Submitted Details</h5>
            </div>
            <div class="card-body">
                <div class="row g-4">
                    <div class="col-md-3 text-center">
                        <img src="<?= BASE_URL . '/uploads/teachers/' . rawurlencode($application['teacher_image'] ?: 'default_teacher_dp.jpg') ?>"
                            alt="Applicant Photo" class="applicant-photo img-fluid border"
                            onerror="this.style.display='none'">
                        <div class="mt-2 fw-semibold"><?= safe_htmlspecialchars($application['name']) ?></div>
                    </div>

                    <div class="col-md-9">
                        <h6 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-user-circle me-2"></i>Personal Information
                        </h6>
                        <div class="row detail-grid">
                            <div class="col-md-4"><dt>Full Name</dt>
                                <dd><?= detailValue($application['name']) ?></dd>
                            </div>
                            <div class="col-md-4"><dt>Email</dt>
                                <dd><?= detailValue($application['email']) ?></dd>
                            </div>
                            <div class="col-md-4"><dt>Phone</dt>
                                <dd><?= detailValue($application['phone']) ?></dd>
                            </div>
                            <div class="col-md-4"><dt>Date of Birth</dt>
                                <dd><?= $application['date_of_birth'] ? formatDate($application['date_of_birth']) : detailValue(null) ?></dd>
                            </div>
                            <div class="col-md-4"><dt>Gender</dt>
                                <dd><?= detailValue($application['gender']) ?></dd>
                            </div>
                            <div class="col-md-4"><dt>Blood Group</dt>
                                <dd><?= detailValue($application['blood_group']) ?></dd>
                            </div>
                            <div class="col-md-4"><dt>Caste Category</dt>
                                <dd><?= detailValue($application['caste_category']) ?></dd>
                            </div>
                            <div class="col-md-4"><dt>Religion</dt>
                                <dd><?= detailValue(ucwords((string) $application['religion'])) ?></dd>
                            </div>
                            <div class="col-md-4"><dt>Nationality</dt>
                                <dd><?= detailValue($application['nationality']) ?></dd>
                            </div>
                            <div class="col-md-4"><dt>Aadhaar No.</dt>
                                <dd><?= detailValue($application['aadhaar_number']) ?></dd>
                            </div>
                        </div>
                    </div>
                </div>

                <h6 class="border-bottom pb-2 text-primary mt-4">
                    <i class="fas fa-people-roof me-2"></i>Family Details
                </h6>
                <div class="row detail-grid">
                    <div class="col-md-3"><dt>Father's Name</dt>
                        <dd><?= detailValue($application['father_name']) ?></dd>
                    </div>
                    <div class="col-md-3"><dt>Father's Phone</dt>
                        <dd><?= detailValue($application['father_phone']) ?></dd>
                    </div>
                    <div class="col-md-3"><dt>Mother's Name</dt>
                        <dd><?= detailValue($application['mother_name']) ?></dd>
                    </div>
                    <div class="col-md-3"><dt>Mother's Phone</dt>
                        <dd><?= detailValue($application['mother_phone']) ?></dd>
                    </div>
                </div>

                <h6 class="border-bottom pb-2 text-primary mt-4">
                    <i class="fas fa-user-graduate me-2"></i>Professional Information
                </h6>
                <div class="row detail-grid">
                    <div class="col-md-4"><dt>Qualification</dt>
                        <dd><?= detailValue($application['qualification']) ?></dd>
                    </div>
                    <div class="col-md-4"><dt>Specialization</dt>
                        <dd><?= detailValue($application['subject_specialization']) ?></dd>
                    </div>
                    <div class="col-md-4"><dt>Position Applied For</dt>
                        <dd><?= detailValue($application['position_in_school']) ?></dd>
                    </div>
                    <div class="col-md-4"><dt>Previous Experience</dt>
                        <dd><?= $application['has_experience'] === 'yes' ? 'Yes' : 'No' ?></dd>
                    </div>
                    <?php if ($application['has_experience'] === 'yes'): ?>
                        <div class="col-md-8"><dt>Previous School / Institution</dt>
                            <dd><?= nl2br(detailValue($application['previous_school'])) ?></dd>
                        </div>
                    <?php endif; ?>
                </div>

                <h6 class="border-bottom pb-2 text-primary mt-4">
                    <i class="fas fa-building-columns me-2"></i>Bank &amp; Statutory Details
                </h6>
                <div class="row detail-grid">
                    <div class="col-md-4"><dt>PAN Card No.</dt>
                        <dd><?= detailValue($application['pan_number']) ?></dd>
                    </div>
                    <div class="col-md-4"><dt>Voter EPIC No.</dt>
                        <dd><?= detailValue($application['voter_epic_number']) ?></dd>
                    </div>
                    <div class="col-md-4"><dt>Bank Name</dt>
                        <dd><?= detailValue($application['bank_name']) ?></dd>
                    </div>
                    <div class="col-md-4"><dt>Branch</dt>
                        <dd><?= detailValue($application['bank_branch']) ?></dd>
                    </div>
                    <div class="col-md-4"><dt>IFSC Code</dt>
                        <dd><?= detailValue($application['ifsc_code']) ?></dd>
                    </div>
                    <div class="col-md-4"><dt>Account Number</dt>
                        <dd><?= detailValue($application['account_number']) ?></dd>
                    </div>
                </div>

                <h6 class="border-bottom pb-2 text-primary mt-4">
                    <i class="fas fa-map-marker me-2"></i>Address
                </h6>
                <div class="row detail-grid">
                    <div class="col-md-4"><dt>Village / Town</dt>
                        <dd><?= detailValue($application['village']) ?></dd>
                    </div>
                    <div class="col-md-4"><dt>Post Office</dt>
                        <dd><?= detailValue($application['post_office']) ?></dd>
                    </div>
                    <div class="col-md-4"><dt>Police Station</dt>
                        <dd><?= detailValue($application['police_station']) ?></dd>
                    </div>
                    <div class="col-md-4"><dt>District</dt>
                        <dd><?= detailValue($application['district']) ?></dd>
                    </div>
                    <div class="col-md-4"><dt>Pin Code</dt>
                        <dd><?= detailValue($application['pincode']) ?></dd>
                    </div>
                </div>

                <h6 class="border-bottom pb-2 text-primary mt-4">
                    <i class="fas fa-folder-open me-2"></i>Documents
                    <span class="badge bg-secondary ms-2"><?= count($application['documents']) ?></span>
                </h6>

                <?php if (empty($application['documents'])): ?>
                    <p class="text-muted small mb-0">No documents were attached to this application.</p>
                <?php else: ?>
                    <div class="row g-3">
                        <?php foreach ($application['documents'] as $document): ?>
                            <div class="col-6 col-md-3">
                                <div class="card h-100">
                                    <a href="<?= safe_htmlspecialchars($document['document_url'] ?? '#') ?>"
                                        data-fancybox="applicant-documents"
                                        data-caption="<?= safe_htmlspecialchars($document['document_name'] ?? 'Document') ?>">
                                        <img src="<?= safe_htmlspecialchars($document['document_url'] ?? '') ?>"
                                            alt="<?= safe_htmlspecialchars($document['document_name'] ?? 'Document') ?>"
                                            class="doc-thumb" loading="lazy">
                                    </a>
                                    <div class="card-body p-2">
                                        <div class="small fw-semibold text-truncate"
                                            title="<?= safe_htmlspecialchars($document['document_name'] ?? '') ?>">
                                            <?= detailValue($document['document_name'] ?? '') ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php if (!$application): ?>
    <script>
        let turnstileWidgetId;

        function initTurnstile() {
            const container = document.querySelector('.cf-turnstile');

            if (typeof turnstile !== 'undefined' && container && turnstileWidgetId === undefined) {
                try {
                    turnstileWidgetId = turnstile.render(container, {
                        sitekey: '<?= $websiteConfig['captcha_site_key'] ?>',
                        theme: 'light',
                        size: 'normal'
                    });
                } catch (error) {
                    console.error('Turnstile initialization error:', error);
                    setTimeout(initTurnstile, 500);
                }
            } else if (typeof turnstile === 'undefined') {
                setTimeout(initTurnstile, 200);
            }
        }

        function resetTurnstile() {
            if (typeof turnstile !== 'undefined' && turnstileWidgetId !== undefined) {
                try {
                    turnstile.reset(turnstileWidgetId);
                } catch (error) {
                    console.error('Error resetting Turnstile:', error);
                }
            }
        }

        $(document).ready(function() {
            initTurnstile();

            // Keep the reference tidy while the applicant types it
            $('#application_ref').on('input', function() {
                this.value = this.value.toUpperCase();
            });

            $('#trackApplicationForm').submit(function(e) {
                e.preventDefault();

                let turnstileResponse = '';
                if (typeof turnstile !== 'undefined' && turnstileWidgetId !== undefined) {
                    try {
                        turnstileResponse = turnstile.getResponse(turnstileWidgetId);
                    } catch (error) {
                        console.error('Error getting Turnstile response:', error);
                    }
                }

                if (!turnstileResponse) {
                    toastr.error('Please complete the captcha verification');
                    return;
                }

                const $submitBtn = $('button[type="submit"]', this);

                $.ajax({
                    url: '../action/verify-teacher-application-access.php',
                    type: 'POST',
                    data: new FormData(this),
                    processData: false,
                    contentType: false,
                    beforeSend: function() {
                        $submitBtn.prop('disabled', true)
                            .html('<i class="fas fa-spinner fa-spin me-2"></i> Checking...');
                    },
                    success: function(response) {
                        if (typeof response === 'string') {
                            try {
                                response = JSON.parse(response);
                            } catch (e) {
                                console.error('Failed to parse response:', response);
                                toastr.error('Invalid server response');
                                $submitBtn.prop('disabled', false)
                                    .html('<i class="fas fa-unlock-keyhole me-2"></i> View My Application');
                                return;
                            }
                        }

                        if (response.success) {
                            toastr.success(response.message || 'Application found');
                            setTimeout(() => location.reload(), 800);
                            return;
                        }

                        toastr.error(response.message || 'Operation failed');
                        $submitBtn.prop('disabled', false)
                            .html('<i class="fas fa-unlock-keyhole me-2"></i> View My Application');
                        resetTurnstile();
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error:', status, error, xhr.responseText);
                        toastr.error('An error occurred. Please try again.');
                        $submitBtn.prop('disabled', false)
                            .html('<i class="fas fa-unlock-keyhole me-2"></i> View My Application');
                        resetTurnstile();
                    }
                });
            });
        });
    </script>
<?php endif; ?>

<?php include_once("../../includes/body-close.php"); ?>
