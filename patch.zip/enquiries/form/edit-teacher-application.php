<?php
/** @var string $school_name
 * @var PDO $pdo
 * @var array $schoolSettings
 * @var array $websiteConfig
 * @var string $assets_version
 * @var string $logo_square
 * @var array $schoolInfo
 */
include_once("../../includes/header-open.php");
echo "<title>Edit Teacher Application - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/teacher/fun-teacher-application-access.php");

if ($schoolSettings['teacher_application'] == 0) {
    echo '<script>location.replace("/");</script>';
    die();
}

if (empty($schoolSettings['allow_edit_teacher_application'])) {
    echo '<script>location.replace("track-teacher-application.php");</script>';
    die();
}

$application = fetchVerifiedTeacherApplication($pdo);

// No live session, or the school has already decided - both belong on the
// track page, which explains the situation instead of showing a dead form.
if (!$application || !isTeacherApplicationEditable($application['status'])) {
    echo '<script>location.replace("track-teacher-application.php");</script>';
    die();
}

// Religions (kept in sync with add-teacher.php)
$religions = [
    'islam',
    'hindu',
    'christian',
    'buddhist',
    'jain',
    'sikh',
    'parsi',
    'judaism',
    'bahai',
    'atheist',
    'agnostic',
    'other'
];

$bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
$casteCategories = ['General', 'OBC-A', 'OBC-B', 'SC', 'ST', 'Other'];
$genders = ['Male', 'Female', 'Other'];

$documents = $application['documents'];
$currentPhoto = $application['teacher_image'] ?: 'default_teacher_dp.jpg';

/**
 * Echo `selected` when the stored value matches this option.
 */
function selectedIf($stored, $option): string
{
    return (string) $stored === (string) $option ? 'selected' : '';
}
?>

<style>
    /* Cropper modal styles */
    .modal-xl {
        max-width: 80%;
    }

    .img-container {
        overflow: hidden;
        margin: 0 auto;
        max-height: 500px;
        min-height: 400px;
        position: relative;
        width: 100%;
        background-color: #f8f9fa;
    }

    .modal-body {
        padding: 1.5rem;
    }

    .modal-dialog {
        margin: 1.75rem auto;
    }

    .logo-container {
        align-items: center;
        text-align: center;
        padding: 0.8rem;
    }

    .logo-container .navbar-brand {
        display: block;
        text-decoration: none;
    }

    .navbar-brand img {
        height: 100px;
        width: 100px;
        object-fit: cover;
    }

    .navbar-brand-text {
        color: var(--primary-color);
        text-transform: uppercase;
        font-size: 2rem;
        white-space: normal;
        word-wrap: break-word;
        text-align: center;
        max-width: 100%;
        font-family: "Oswald", sans-serif;
        font-optical-sizing: auto;
        font-weight: 700;
        font-style: normal;
        margin: 1rem 0;
    }

    .photo-upload-section {
        border: 2px dashed #dee2e6;
        border-radius: 8px;
        padding: 20px;
        text-align: center;
        transition: border-color 0.3s ease;
    }

    .photo-upload-section:hover {
        border-color: #007bff;
    }

    .photo-preview {
        max-width: 200px;
        max-height: 240px;
        object-fit: cover;
        border-radius: 8px;
        margin: 10px 0;
    }

    #experience_details {
        display: <?= $application['has_experience'] === 'yes' ? 'block' : 'none' ?>;
    }

    .document-row {
        background-color: #f8f9fa;
        border: 1px solid #e9ecef;
        border-radius: 6px;
        padding: 8px 6px;
    }

    .existing-document-row {
        background-color: #eef7ff;
        border: 1px solid #cfe6ff;
        border-radius: 6px;
        padding: 8px 6px;
    }

    .existing-doc-thumb {
        width: 46px;
        height: 46px;
        object-fit: cover;
        border-radius: 4px;
        background-color: #fff;
    }

    .ref-chip {
        font-family: "Courier New", monospace;
        letter-spacing: 0.08em;
    }
</style>

<div class="container mt-4 mb-5">
    <!-- School Name & Logo Section -->
    <div class="logo-container container">
        <a class="navbar-brand" href="/">
            <img src="<?= $logo_square ?>" alt="School Logo" onerror="this.style.display='none'" class="rounded">
            <div class="navbar-brand-text"><?= $schoolInfo['name']; ?></div>
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white d-flex flex-wrap justify-content-between align-items-center gap-2">
            <h4 class="mb-0 py-2">
                <i class="fa-solid fa-pen-to-square"></i> Edit Application
                <span class="ref-chip"><?= formatTeacherApplicationRef((int) $application['id']) ?></span>
            </h4>
            <a href="track-teacher-application.php" class="btn btn-sm btn-light">
                <i class="fas fa-arrow-left me-1"></i> Back to Status
            </a>
        </div>

        <div class="card-body">
            <div class="alert alert-info">
                <i class="fas fa-circle-info me-1"></i>
                Your application is still under review, so you can correct anything here.
                Changing your email or date of birth also changes the details you will need
                the next time you look this application up.
            </div>

            <form id="editApplicationForm" method="post" enctype="multipart/form-data">
                <div class="row g-3">
                    <!-- Personal Information Section -->
                    <div class="col-md-12">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-user-circle me-2"></i>Personal Information
                        </h5>
                    </div>

                    <div class="col-md-4">
                        <label for="name" class="form-label">Full Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="name" name="name" required
                            value="<?= safe_htmlspecialchars($application['name']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                        <input type="email" class="form-control" id="email" name="email" required
                            value="<?= safe_htmlspecialchars($application['email']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label for="phone" class="form-label">Phone Number <span class="text-danger">*</span></label>
                        <input type="tel" class="form-control" id="phone" name="phone" required
                            value="<?= safe_htmlspecialchars($application['phone']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label for="date_of_birth" class="form-label">Date of Birth <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" required
                            value="<?= safe_htmlspecialchars($application['date_of_birth']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label for="gender" class="form-label">Gender <span class="text-danger">*</span></label>
                        <select class="form-select" id="gender" name="gender" required>
                            <option value="" disabled <?= empty($application['gender']) ? 'selected' : '' ?>>Select</option>
                            <?php foreach ($genders as $gender): ?>
                                <option value="<?= $gender ?>" <?= selectedIf($application['gender'], $gender) ?>><?= $gender ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="blood_group" class="form-label">Blood Group</label>
                        <select class="form-select" id="blood_group" name="blood_group">
                            <option value="">Select</option>
                            <?php foreach ($bloodGroups as $bloodGroup): ?>
                                <option value="<?= $bloodGroup ?>" <?= selectedIf($application['blood_group'], $bloodGroup) ?>><?= $bloodGroup ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="caste_category" class="form-label">Caste Category</label>
                        <select class="form-select" id="caste_category" name="caste_category">
                            <option value="">Select</option>
                            <?php foreach ($casteCategories as $casteCategory): ?>
                                <option value="<?= $casteCategory ?>" <?= selectedIf($application['caste_category'], $casteCategory) ?>><?= $casteCategory ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="religion" class="form-label">Religion</label>
                        <select class="form-select" id="religion" name="religion">
                            <option value="">Select Religion</option>
                            <?php foreach ($religions as $religion): ?>
                                <option value="<?= $religion ?>" <?= selectedIf($application['religion'], $religion) ?>><?= ucwords($religion) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="nationality" class="form-label">Nationality</label>
                        <input type="text" class="form-control" id="nationality" name="nationality"
                            value="<?= safe_htmlspecialchars($application['nationality'] ?: 'Indian') ?>">
                    </div>

                    <div class="col-md-6">
                        <label for="aadhaar_card" class="form-label">Aadhaar No.</label>
                        <input type="text" class="form-control" id="aadhaar_card" name="aadhaar_card"
                            placeholder="12 digit Aadhaar number"
                            value="<?= safe_htmlspecialchars($application['aadhaar_number']) ?>">
                    </div>

                    <!-- Family Details Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-people-roof me-2"></i>Family Details
                        </h5>
                    </div>

                    <div class="col-md-3">
                        <label for="father_name" class="form-label">Father's Name</label>
                        <input type="text" class="form-control" id="father_name" name="father_name"
                            value="<?= safe_htmlspecialchars($application['father_name']) ?>">
                    </div>

                    <div class="col-md-3">
                        <label for="father_phone" class="form-label">Father's Phone</label>
                        <input type="tel" class="form-control" id="father_phone" name="father_phone"
                            value="<?= safe_htmlspecialchars($application['father_phone']) ?>">
                    </div>

                    <div class="col-md-3">
                        <label for="mother_name" class="form-label">Mother's Name</label>
                        <input type="text" class="form-control" id="mother_name" name="mother_name"
                            value="<?= safe_htmlspecialchars($application['mother_name']) ?>">
                    </div>

                    <div class="col-md-3">
                        <label for="mother_phone" class="form-label">Mother's Phone</label>
                        <input type="tel" class="form-control" id="mother_phone" name="mother_phone"
                            value="<?= safe_htmlspecialchars($application['mother_phone']) ?>">
                    </div>

                    <!-- Professional Information Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-user-graduate me-2"></i>Professional Information
                        </h5>
                    </div>

                    <div class="col-md-4">
                        <label for="qualification" class="form-label">Qualification <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="qualification" name="qualification" required
                            value="<?= safe_htmlspecialchars($application['qualification']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label for="subject_specialization" class="form-label">Specialization (Comma Separated) <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="subject_specialization" name="subject_specialization" required
                            value="<?= safe_htmlspecialchars($application['subject_specialization']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label for="position_in_school" class="form-label">Position Applying For</label>
                        <input type="text" class="form-control" id="position_in_school" name="position_in_school"
                            value="<?= safe_htmlspecialchars($application['position_in_school']) ?>">
                    </div>

                    <div class="col-md-12">
                        <label class="form-label">Do you have any previous teaching experience? <span class="text-danger">*</span></label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="has_experience" id="experience_yes" value="yes" required
                                <?= $application['has_experience'] === 'yes' ? 'checked' : '' ?>>
                            <label class="form-check-label" for="experience_yes">Yes</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="has_experience" id="experience_no" value="no" required
                                <?= $application['has_experience'] !== 'yes' ? 'checked' : '' ?>>
                            <label class="form-check-label" for="experience_no">No</label>
                        </div>
                    </div>

                    <div class="col-md-12" id="experience_details">
                        <label for="previous_school" class="form-label">Previous School/Institution <span class="text-danger">*</span></label>
                        <textarea class="form-control" id="previous_school" name="previous_school" rows="3"
                            placeholder="Please mention the school/institution names and duration of work"
                            <?= $application['has_experience'] === 'yes' ? 'required' : '' ?>><?= safe_htmlspecialchars($application['previous_school']) ?></textarea>
                    </div>

                    <!-- Bank Details Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-building-columns me-2"></i>Bank &amp; Statutory Details
                        </h5>
                        <small class="text-muted">Optional, but filling these in now saves paperwork later if your application is approved.</small>
                    </div>

                    <div class="col-md-4">
                        <label for="pan_number" class="form-label">PAN Card No.</label>
                        <input type="text" class="form-control text-uppercase-input" id="pan_number" name="pan_number"
                            maxlength="10" placeholder="ABCDE1234F" style="text-transform:uppercase;"
                            value="<?= safe_htmlspecialchars($application['pan_number']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label for="voter_epic_number" class="form-label">Voter EPIC No.</label>
                        <input type="text" class="form-control text-uppercase-input" id="voter_epic_number" name="voter_epic_number"
                            placeholder="ABC1234567" style="text-transform:uppercase;"
                            value="<?= safe_htmlspecialchars($application['voter_epic_number']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label for="bank_name" class="form-label">Bank Name</label>
                        <input type="text" class="form-control" id="bank_name" name="bank_name"
                            value="<?= safe_htmlspecialchars($application['bank_name']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label for="bank_branch" class="form-label">Branch Name</label>
                        <input type="text" class="form-control" id="bank_branch" name="bank_branch"
                            value="<?= safe_htmlspecialchars($application['bank_branch']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label for="ifsc_code" class="form-label">IFSC Code</label>
                        <input type="text" class="form-control text-uppercase-input" id="ifsc_code" name="ifsc_code"
                            placeholder="SBIN0001234" style="text-transform:uppercase;"
                            value="<?= safe_htmlspecialchars($application['ifsc_code']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label for="account_number" class="form-label">Account Number</label>
                        <input type="text" class="form-control" id="account_number" name="account_number"
                            value="<?= safe_htmlspecialchars($application['account_number']) ?>">
                    </div>

                    <!-- Address Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-map-marker me-2"></i>Address
                        </h5>
                    </div>

                    <div class="col-md-4">
                        <label for="village" class="form-label">Village/Town <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="village" name="village" required
                            value="<?= safe_htmlspecialchars($application['village']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label for="post_office" class="form-label">Post Office <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="post_office" name="post_office" required
                            value="<?= safe_htmlspecialchars($application['post_office']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label for="police_station" class="form-label">Police Station <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="police_station" name="police_station" required
                            value="<?= safe_htmlspecialchars($application['police_station']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label for="district" class="form-label">District <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="district" name="district" required
                            value="<?= safe_htmlspecialchars($application['district']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label for="pincode" class="form-label">Pin Code <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="pincode" name="pincode" required
                            value="<?= safe_htmlspecialchars($application['pincode']) ?>">
                    </div>

                    <!-- Documents Section -->
                    <div class="col-md-12 mt-4">
                        <div class="d-flex justify-content-between align-items-center border-bottom pb-2">
                            <h5 class="text-primary mb-0">
                                <i class="fas fa-folder-open me-2"></i>Documents
                                <span id="documentsCounter" class="badge bg-secondary ms-2">0 / <?= MAX_TEACHER_DOCUMENTS ?></span>
                            </h5>
                            <button type="button" id="addDocumentBtn" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-plus me-1"></i> Add Document
                            </button>
                        </div>
                    </div>

                    <div class="col-md-12">
                        <div id="existingDocumentsContainer">
                            <?php foreach ($documents as $document): ?>
                                <?php if (empty($document['document_url'])) continue; ?>
                                <div class="existing-document-row row g-2 align-items-center mb-2">
                                    <input type="hidden" name="existing_document_url[]"
                                        value="<?= safe_htmlspecialchars($document['document_url']) ?>">
                                    <div class="col-auto">
                                        <a href="<?= safe_htmlspecialchars($document['document_url']) ?>"
                                            data-fancybox="existing-documents"
                                            data-caption="<?= safe_htmlspecialchars($document['document_name'] ?? 'Document') ?>">
                                            <img src="<?= safe_htmlspecialchars($document['document_url']) ?>"
                                                class="existing-doc-thumb border" alt="Document" loading="lazy">
                                        </a>
                                    </div>
                                    <div class="col">
                                        <input type="text" name="existing_document_name[]" class="form-control"
                                            placeholder="Document Name" required
                                            value="<?= safe_htmlspecialchars($document['document_name'] ?? '') ?>">
                                    </div>
                                    <div class="col-auto">
                                        <span class="badge bg-light text-secondary border">Already uploaded</span>
                                    </div>
                                    <div class="col-auto text-end">
                                        <button type="button" class="btn btn-outline-danger btn-sm remove-existing-document-btn" title="Remove">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <div id="documentsContainer">
                            <!-- Newly added document rows are injected here by JS -->
                        </div>

                        <div id="noDocumentsMsg" class="text-muted small">
                            Optional. Click "Add Document" to attach certificates, Aadhaar card, PAN card, etc. (JPG/PNG, max 2MB each)
                        </div>
                        <div id="documentsLimitMsg" class="text-danger small" style="display:none;">
                            <i class="fas fa-circle-exclamation me-1"></i> Maximum of <?= MAX_TEACHER_DOCUMENTS ?> documents reached. Remove one to add another.
                        </div>
                    </div>

                    <!-- Photo Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-camera me-2"></i>Photo
                        </h5>
                    </div>

                    <div class="col-md-12">
                        <div class="photo-upload-section">
                            <div class="mb-3">
                                <div class="small text-muted mb-2">Current photo</div>
                                <img src="<?= BASE_URL . '/uploads/teachers/' . rawurlencode($currentPhoto) ?>"
                                    class="photo-preview border" alt="Current Photo" id="currentPhoto"
                                    onerror="this.style.display='none'">
                            </div>

                            <label for="photo" class="form-label">Replace Photo (optional)</label>
                            <input type="file" class="form-control" id="photo" name="photo" accept="image/*">
                            <small class="text-muted">
                                Leave this empty to keep your current photo. If you pick a new one you must
                                crop it to the 5:6 ratio before saving.
                            </small>

                            <div id="photoPreview" style="display: none;">
                                <div class="small text-muted mt-3 mb-2">New photo</div>
                                <img id="previewImage" class="photo-preview" alt="Photo Preview">
                                <div class="mt-2">
                                    <button type="button" class="btn btn-sm btn-danger" id="removePhoto">
                                        <i class="fas fa-trash me-1"></i>Discard New Photo
                                    </button>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="cropped_image_data" name="cropped_image_data">
                    </div>

                    <!-- Cloudflare Turnstile Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fa-solid fa-shield-halved"></i> Captcha Validation
                        </h5>
                    </div>
                    <div class="turnstile-container col-md-12 d-flex justify-content-center">
                        <div class="cf-turnstile" data-sitekey="<?= $websiteConfig['captcha_site_key'] ?>"></div>
                    </div>
                </div>

                <div class="mt-5 mb-3 text-center">
                    <a href="track-teacher-application.php" class="btn btn-outline-secondary px-4 py-2 me-2">
                        <i class="fas fa-xmark me-2"></i> Cancel
                    </a>
                    <button type="submit" class="btn btn-primary px-4 py-2">
                        <i class="fas fa-floppy-disk me-2"></i> Save Changes
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Image Cropper Modal -->
<div class="modal fade" id="cropperModal" tabindex="-1" aria-labelledby="cropperModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cropperModalLabel">
                    <i class="fas fa-crop me-2"></i>Crop Your Photo
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    Please crop your photo to the required 5:6 ratio. You can drag and resize the crop area.
                </div>
                <div class="img-container">
                    <img id="cropperImage" style="max-width: 100%;">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="fas fa-times me-1"></i>Cancel
                </button>
                <button type="button" class="btn btn-primary" id="confirmCrop">
                    <i class="fas fa-check me-1"></i>Apply Crop & Continue
                </button>
            </div>
        </div>
    </div>
</div>

<script>
    let turnstileWidgetId;
    let cropper;
    let originalImageFile;
    let documentRowIndex = 0;
    const MAX_DOCUMENTS = <?= MAX_TEACHER_DOCUMENTS ?>;

    function initTurnstile() {
        const container = document.querySelector('.cf-turnstile');

        if (typeof turnstile !== 'undefined' && container && turnstileWidgetId === undefined) {
            try {
                turnstileWidgetId = turnstile.render(container, {
                    sitekey: '<?= $websiteConfig['captcha_site_key'] ?>',
                    theme: 'light',
                    size: 'normal'
                });
            } catch (error) {
                console.error('Turnstile initialization error:', error);
                setTimeout(initTurnstile, 500);
            }
        } else if (typeof turnstile === 'undefined') {
            setTimeout(initTurnstile, 200);
        }
    }

    function resetTurnstile() {
        if (typeof turnstile !== 'undefined' && turnstileWidgetId !== undefined) {
            try {
                turnstile.reset(turnstileWidgetId);
            } catch (error) {
                console.error('Error resetting Turnstile:', error);
            }
        }
    }

    // ===================== Documents =====================
    // Existing (already uploaded) rows and newly added rows share the same limit.
    function countDocumentRows() {
        return $('#existingDocumentsContainer .existing-document-row').length +
            $('#documentsContainer .document-row').length;
    }

    function refreshDocumentsUI() {
        const total = countDocumentRows();
        const limitReached = total >= MAX_DOCUMENTS;

        $('#documentsCounter').text(total + ' / ' + MAX_DOCUMENTS)
            .toggleClass('bg-secondary', !limitReached)
            .toggleClass('bg-danger', limitReached);
        $('#noDocumentsMsg').toggle(total === 0);
        $('#documentsLimitMsg').toggle(limitReached);
        $('#addDocumentBtn').prop('disabled', limitReached);
    }

    function addDocumentRow() {
        if (countDocumentRows() >= MAX_DOCUMENTS) {
            toastr.error(`You can attach a maximum of ${MAX_DOCUMENTS} documents.`);
            return;
        }

        documentRowIndex++;
        const rowHtml = `
            <div class="document-row row g-2 align-items-center mb-2" id="docRow_${documentRowIndex}">
                <div class="col-md-5">
                    <input type="text" name="document_name[]" class="form-control" placeholder="Document Name (e.g. PAN Card)" required>
                </div>
                <div class="col-md-6">
                    <input type="file" name="document_file[]" class="form-control" accept="image/jpeg,image/png" required>
                </div>
                <div class="col-md-1 text-end">
                    <button type="button" class="btn btn-outline-danger btn-sm remove-document-btn" title="Remove">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `;

        $('#documentsContainer').append(rowHtml);
        refreshDocumentsUI();
    }

    // ===================== Cropper =====================
    function initializeCropper() {
        if (cropper) {
            cropper.destroy();
        }

        setTimeout(() => {
            cropper = new Cropper($('#cropperImage')[0], {
                aspectRatio: 5 / 6,
                viewMode: 1,
                autoCropArea: 0.8,
                responsive: true,
                restore: false,
                guides: true,
                center: true,
                highlight: false,
                cropBoxMovable: true,
                cropBoxResizable: true,
                toggleDragModeOnDblclick: false,
                ready: function() {
                    this.cropper.resize();

                    const containerData = this.cropper.getContainerData();
                    const maxWidth = containerData.width * 0.8;
                    const maxHeight = containerData.height * 0.8;
                    const aspectRatio = 5 / 6;

                    let cropWidth, cropHeight;
                    if (maxWidth / aspectRatio <= maxHeight) {
                        cropWidth = maxWidth;
                        cropHeight = maxWidth / aspectRatio;
                    } else {
                        cropHeight = maxHeight;
                        cropWidth = maxHeight * aspectRatio;
                    }

                    this.cropper.setCropBoxData({
                        width: cropWidth,
                        height: cropHeight,
                        left: (containerData.width - cropWidth) / 2,
                        top: (containerData.height - cropHeight) / 2
                    });
                }
            });
        }, 100);
    }

    $(document).ready(function() {
        initTurnstile();
        refreshDocumentsUI();

        $('#addDocumentBtn').click(function() {
            addDocumentRow();
        });

        $('#documentsContainer').on('click', '.remove-document-btn', function() {
            $(this).closest('.document-row').remove();
            refreshDocumentsUI();
        });

        // Removing an already uploaded document simply drops its row, so it is
        // no longer posted back and the server treats it as deleted.
        $('#existingDocumentsContainer').on('click', '.remove-existing-document-btn', function() {
            $(this).closest('.existing-document-row').remove();
            refreshDocumentsUI();
            toastr.info('Document removed. It will be deleted when you save your changes.');
        });

        // Auto-uppercase PAN / IFSC / Voter EPIC as the applicant types
        $('.text-uppercase-input').on('input', function() {
            this.value = this.value.toUpperCase();
        });

        // Experience radio button change handler
        $('input[name="has_experience"]').change(function() {
            if ($(this).val() === 'yes') {
                $('#experience_details').show();
                $('#previous_school').attr('required', true);
            } else {
                $('#experience_details').hide();
                $('#previous_school').attr('required', false).val('');
            }
        });

        $(window).resize(function() {
            if (cropper && $('#cropperModal').hasClass('show')) {
                cropper.resize();
            }
        });

        // Photo upload handler
        $('#photo').change(function(e) {
            const files = e.target.files;

            if (files && files.length > 0) {
                originalImageFile = files[0];
                const reader = new FileReader();

                reader.onload = function(event) {
                    $('#cropperImage').attr('src', event.target.result);
                    $('#cropperModal').modal('show');
                };
                reader.readAsDataURL(originalImageFile);
            } else {
                $('#photoPreview').hide();
                $('#cropped_image_data').val('');
                originalImageFile = null;
            }
        });

        // Apply the crop
        $('#confirmCrop').click(function() {
            if (!cropper) {
                return;
            }

            const canvas = cropper.getCroppedCanvas({
                width: 500,
                height: 600,
                minWidth: 500,
                minHeight: 600,
                maxWidth: 500,
                maxHeight: 600,
                fillColor: '#fff',
                imageSmoothingEnabled: true,
                imageSmoothingQuality: 'high',
            });

            if (!canvas) {
                return;
            }

            canvas.toBlob(function(blob) {
                const file = new File([blob], originalImageFile.name, {
                    type: 'image/jpeg',
                    lastModified: Date.now()
                });

                const dataTransfer = new DataTransfer();
                dataTransfer.items.add(file);
                $('#photo')[0].files = dataTransfer.files;

                $('#previewImage')[0].src = URL.createObjectURL(blob);
                $('#photoPreview').show();

                $('#cropped_image_data').val(canvas.toDataURL('image/jpeg'));
                $('#cropperModal').modal('hide');

                cropper.destroy();
                cropper = null;

                toastr.success('Photo cropped successfully!');
            }, 'image/jpeg', 0.9);
        });

        $('#cropperModal').on('shown.bs.modal', function() {
            const imageElement = $('#cropperImage')[0];

            if (imageElement.complete) {
                initializeCropper();
            } else {
                imageElement.onload = function() {
                    initializeCropper();
                };
            }
        });

        $('#cropperModal').on('hidden.bs.modal', function() {
            if (cropper) {
                cropper.destroy();
                cropper = null;
            }

            // Closed without cropping - fall back to the existing photo
            if (!$('#cropped_image_data').val()) {
                $('#photo').val('');
                $('#photoPreview').hide();
                originalImageFile = null;
            }
        });

        // Discard the newly picked photo and keep the stored one
        $('#removePhoto').click(function() {
            $('#photo').val('');
            $('#photoPreview').hide();
            $('#cropped_image_data').val('');
            originalImageFile = null;

            if (cropper) {
                cropper.destroy();
                cropper = null;
            }

            toastr.info('Your current photo will be kept');
        });

        // AJAX form submission
        $('#editApplicationForm').submit(function(e) {
            e.preventDefault();

            let turnstileResponse = '';
            if (typeof turnstile !== 'undefined' && turnstileWidgetId !== undefined) {
                try {
                    turnstileResponse = turnstile.getResponse(turnstileWidgetId);
                } catch (error) {
                    console.error('Error getting Turnstile response:', error);
                }
            }

            if (!turnstileResponse) {
                toastr.error('Please complete the captcha verification');
                return;
            }

            // A picked-but-uncropped photo would silently be ignored, so block it
            if ($('#photo')[0].files.length > 0 && !$('#cropped_image_data').val()) {
                toastr.error('Please crop your new photo before saving');
                return;
            }

            const $submitBtn = $('button[type="submit"]', this);
            const resetBtn = () => $submitBtn.prop('disabled', false)
                .html('<i class="fas fa-floppy-disk me-2"></i> Save Changes');

            $.ajax({
                url: '../action/update-teacher-application.php',
                type: 'POST',
                data: new FormData(this),
                processData: false,
                contentType: false,
                beforeSend: function() {
                    $submitBtn.prop('disabled', true)
                        .html('<i class="fas fa-spinner fa-spin me-2"></i> Saving...');
                },
                success: function(response) {
                    if (typeof response === 'string') {
                        try {
                            response = JSON.parse(response);
                        } catch (e) {
                            console.error('Failed to parse response:', response);
                            toastr.error('Invalid server response');
                            resetBtn();
                            return;
                        }
                    }

                    if (response.success) {
                        toastr.success(response.message || 'Application updated successfully!');
                        setTimeout(() => location.replace('track-teacher-application.php'), 1200);
                        return;
                    }

                    toastr.error(response.message || 'Operation failed');
                    resetBtn();
                    resetTurnstile();
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', status, error, xhr.responseText);

                    try {
                        const response = JSON.parse(xhr.responseText);
                        toastr.error(response.message || 'An error occurred');
                    } catch (e) {
                        toastr.error('An error occurred. Please try again.');
                    }

                    resetBtn();
                    resetTurnstile();
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>
