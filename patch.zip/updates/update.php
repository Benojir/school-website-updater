<?php
include_once("../includes/auth-check.php");
include_once("../includes/permission-check.php");
include_once("../includes/header-open.php");
echo "<title>Updating Website - " . $school_name . "</title>";
include_once("../includes/header-close.php");

// Check if user is superadmin only
if ($_SESSION['user']['role'] !== 'superadmin') {
    include_once("../includes/permission-denied.php");
    exit();
}

$new_update = checkForUpdates();

// Validate update data
if (!isset($new_update['is_update_available']) || !$new_update['is_update_available']) {
    die("<div class='container py-5'><div class='alert alert-info'>No updates available.</div></div>");
}

// Validate patch URL
if (empty($new_update['patch_url']) || !filter_var($new_update['patch_url'], FILTER_VALIDATE_URL)) {
    die("<div class='container py-5'><div class='alert alert-danger'>Invalid update URL provided.</div></div>");
}
?>
<div class="container py-5">
    <h1 class="mt-5 text-center text-danger mb-5">Updating the website. Don't refresh the page. Please wait...</h1>
    <div class="console" style="font-family: monospace; color: white; background: #222222; padding: 1rem;">
        <?php
        // Configuration
        $zipUrl = $new_update['patch_url'];
        $localZip = __DIR__ . '/latest_' . time() . '.zip'; // Unique filename
        $extractTo = realpath(__DIR__ . '/../') . DIRECTORY_SEPARATOR; // Normalized path
        $migrateFile = __DIR__ . '/../migrate.php';
        $deleteFiles = [
            $localZip,
            $migrateFile
        ];

        // Enable output buffering for real-time display
        ob_implicit_flush(true);
        ob_end_flush();

        function log_message($message) {
            echo $message . "<br>\n";
            flush();
        }

        function update_version_file($newVersionCode) {
            $versionFile = __DIR__ . '/../updates/version.json';
            if (!file_exists($versionFile)) {
                throw new Exception("Version file does not exist.");
            }
            $versionData = json_decode(file_get_contents($versionFile), true);
            $versionData['version-code'] = $newVersionCode;
            if (file_put_contents($versionFile, json_encode($versionData, JSON_PRETTY_PRINT)) === false) {
                throw new Exception("Failed to update version file.");
            }
            log_message("Version file updated successfully.");
        }

        try {
            // Step 1: Download the ZIP
            log_message("Starting update process...");
            log_message("Downloading update from: " . $zipUrl);
            
            $context = stream_context_create([
                'ssl' => [
                    'verify_peer' => true,
                    'verify_peer_name' => true,
                ]
            ]);
            
            $zipContent = file_get_contents($zipUrl, false, $context);
            if ($zipContent === false) {
                throw new Exception("Failed to download ZIP file.");
            }

            if (file_put_contents($localZip, $zipContent) === false) {
                throw new Exception("Failed to save ZIP file locally.");
            }
            log_message("Download complete. Saved to: " . $localZip);

            // Verify ZIP integrity
            if (filesize($localZip) === 0) {
                throw new Exception("Downloaded ZIP file is empty.");
            }

            // Step 2: Extract ZIP
            $zip = new ZipArchive();
            if ($zip->open($localZip) !== true) {
                throw new Exception("Failed to open ZIP file. Error code: " . $zip->status);
            }

            // Check if extraction directory is writable
            if (!is_writable($extractTo)) {
                throw new Exception("Extraction directory is not writable: " . $extractTo);
            }

            log_message("Extracting files...");
            if (!$zip->extractTo($extractTo)) {
                throw new Exception("Failed to extract ZIP file. Error code: " . $zip->status);
            }
            $zip->close();
            log_message("Extraction complete.");

            // Step 3: Migrate database and other changes
            if (file_exists($migrateFile)) {
                log_message("Running migration script...");
                try {
                    include_once($migrateFile);
                    log_message("Migration completed successfully.");
                } catch (Exception $e) {
                    throw new Exception("Migration failed: " . $e->getMessage());
                }
            } else {
                log_message("No migration script found - skipping this step.");
            }

            // Step 4: Clean up temporary files
            log_message("Cleaning up temporary files...");
            foreach ($deleteFiles as $file) {
                if (file_exists($file)) {
                    if (!unlink($file)) {
                        log_message("Warning: Could not delete temporary file: " . $file);
                    } else {
                        log_message("Deleted temporary file: " . $file);
                    }
                }
            }

            // Step 5: Update version file
            log_message("Updating version file...");
            if (isset($new_update['latest_version'])) {
                update_version_file($new_update['latest_version']);
            } else {
                throw new Exception("Latest version information is missing.");
            }

            log_message("Update process completed successfully!");
            log_message("<strong class='text-success'>Your system is now up to date.</strong>");

        } catch (Exception $e) {
            log_message("<strong class='text-danger'>ERROR: " . safe_htmlspecialchars($e->getMessage()) . "</strong>");
            log_message("Update process failed. Please contact support.");
            
            // Attempt to clean up even after failure
            if (file_exists($localZip)) {
                @unlink($localZip);
            }
        }
        ?>
    </div>
</div>