<?php
include_once __DIR__ . '/../includes/config.php'; // Include your configuration file
echo json_encode(cleanupOrphanedParentAccounts($pdo));

/**
 * Deletes parent accounts that don't have associated student records
 * 
 * @param PDO $pdo PDO database connection instance
 * @return array Returns an array with status, message, and deletion count
 */
function cleanupOrphanedParentAccounts(PDO $pdo): array {
    try {
        // Start transaction
        $pdo->beginTransaction();

        // Get all parent phone numbers
        $parentPhonesStmt = $pdo->query("SELECT phone_number FROM parent_accounts");
        $parentPhones = $parentPhonesStmt->fetchAll(PDO::FETCH_COLUMN);

        $deletedCount = 0;

        foreach ($parentPhones as $phone) {
            // Check if phone exists in students table
            $studentCheckStmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE phone_number = ?");
            $studentCheckStmt->execute([$phone]);
            $studentExists = $studentCheckStmt->fetchColumn();

            if ($studentExists == 0) {
                // Delete the parent account if no student exists
                $deleteStmt = $pdo->prepare("DELETE FROM parent_accounts WHERE phone_number = ?");
                $deleteStmt->execute([$phone]);
                $deletedCount += $deleteStmt->rowCount();
            }
        }

        $pdo->commit();

        return [
            'status' => 'success',
            'message' => "Deleted $deletedCount orphaned parent accounts.",
            'deleted_count' => $deletedCount
        ];

    } catch (PDOException $e) {
        $pdo->rollBack();
        return [
            'status' => 'error',
            'message' => "Database error: " . $e->getMessage(),
            'deleted_count' => 0
        ];
    }
}