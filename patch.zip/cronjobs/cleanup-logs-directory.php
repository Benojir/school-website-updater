<?php

deleteAllFilesInFolder(__DIR__ . '/../logs', true);

/**
 * Deletes all files inside a directory (but not the directory itself)
 * 
 * @param string $folderPath The path to the directory to clean
 * @param bool $deleteSubdirectories Whether to also delete subdirectories and their contents
 * @return bool True on success, false on failure
 */
function deleteAllFilesInFolder(string $folderPath, bool $deleteSubdirectories = false): bool {
    // Check if the path exists and is a directory
    if (!file_exists($folderPath) || !is_dir($folderPath)) {
        return false;
    }

    // Open the directory
    $dir = new DirectoryIterator($folderPath);
    
    foreach ($dir as $fileInfo) {
        // Skip current and parent directory pointers
        if ($fileInfo->isDot()) {
            continue;
        }

        $fullPath = $fileInfo->getPathname();

        if ($fileInfo->isFile()) {
            // Delete the file
            if (!unlink($fullPath)) {
                return false;
            }
        } elseif ($deleteSubdirectories && $fileInfo->isDir()) {
            // Recursively delete subdirectory if enabled
            deleteAllFilesInFolder($fullPath, true);
            if (!rmdir($fullPath)) {
                return false;
            }
        }
    }

    return true;
}