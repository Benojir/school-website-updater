<?php
/**
 * Cron job to clean up expired remember me tokens
 * Minimal version without logging
 */

// Database configuration
require_once('../includes/db.php');

try {
    // Delete expired tokens
    $stmt = $pdo->prepare("UPDATE users SET remember_token = NULL, token_expiry = NULL WHERE token_expiry < NOW()");
    $stmt->execute();
    
    // Optional: Output result if run manually (won't show in cron)
    if (php_sapi_name() === 'cli') {
        echo "Cleaned up " . $stmt->rowCount() . " expired tokens\n";
    }
    
} catch (PDOException $e) {
    // Optional: Output error if run manually
    if (php_sapi_name() === 'cli') {
        echo "ERROR: " . $e->getMessage() . "\n";
    }
    // You might want to add error notification here in production
}