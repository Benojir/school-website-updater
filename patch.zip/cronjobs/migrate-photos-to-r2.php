<?php
// CLI only. This file is intentionally never run by development tools.
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('CLI only.'); }
$options = getopt('', ['help', 'batch:', 'remove-local', 'cleanup', 'cleanup-only', 'rescan', 'status', 'dry-run']);
if (isset($options['help'])) {
    echo "Usage: php migrate-photos-to-r2.php --batch=25 [--remove-local] [--cleanup] [--cleanup-only] [--rescan] [--status] [--dry-run]\n";
    echo "Run separately for each school. Copy-only by default. See docs/r2-photo-storage.md.\n";
    echo "Photo batch range: 1-1000 (default 25); cleanup/recovery remain limited to 100 per run.\n";
    exit;
}
require_once __DIR__ . '/../includes/photo-migration.php';
try { $lock = schoolPhotoMaintenanceLock(__DIR__ . '/../includes/.r2-maintenance.lock'); }
catch (Throwable $e) { fwrite(STDERR, $e->getMessage() . "\n"); exit(1); }
if ($lock === null) exit("Another photo maintenance job is running.\n");
require_once __DIR__ . '/../includes/db.php';
$websiteConfig = $pdo->query('SELECT * FROM website_config LIMIT 1')->fetch(PDO::FETCH_ASSOC) ?: [];
$batch = max(1, min(1000, (int)($options['batch'] ?? 25)));
$maintenanceBatch = min(100, $batch);
$statePath = __DIR__ . '/../includes/.r2-migration-state.php';
$state = ['cursor' => '', 'complete' => false, 'counts' => [], 'recent_errors' => []];
if (is_file($statePath)) $state = json_decode(substr(file_get_contents($statePath), strlen("<?php exit; ?>\n")), true, 32, JSON_THROW_ON_ERROR);
if (isset($options['rescan'])) { $state['cursor'] = ''; $state['complete'] = false; }
if (isset($options['status'])) { echo json_encode($state, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n"; exit; }
try {
    if (empty($websiteConfig['r2_enabled']) && !isset($options['cleanup-only'])) throw new RuntimeException('Enable and test R2 in Website Configuration first.');
    schoolR2Config();
    if (!isset($options['dry-run'])) {
        $recovery = schoolPhotoRecoverJournals($maintenanceBatch);
        if ($recovery['recovered'] || $recovery['errors']) echo json_encode(['recovery' => $recovery]) . "\n";
        if (isset($options['cleanup']) || isset($options['cleanup-only'])) echo json_encode(['cleanup' => schoolPhotoCleanupBatch($maintenanceBatch)]) . "\n";
    }
    if (isset($options['cleanup-only'])) exit;
    $rows = $state['complete'] ? [] : schoolPhotoMigrationCandidates($state['cursor'], $batch);
    foreach ($rows as $row) {
        $label = $row['category'] . '/' . $row['filename'];
        if (isset($options['dry-run'])) { echo 'Candidate: ' . $label . "\n"; continue; }
        try { $status = schoolPhotoMigrateOne($row['category'], $row['filename'], isset($options['remove-local'])); }
        catch (Throwable $e) {
            $status = 'failed';
            $state['recent_errors'][] = $label . ': ' . $e->getMessage();
            $state['recent_errors'] = array_slice($state['recent_errors'], -20);
        }
        $state['counts'][$status] = ($state['counts'][$status] ?? 0) + 1;
        $state['cursor'] = $label;
        $state['updated_at'] = gmdate('c');
        $content = "<?php exit; ?>\n" . json_encode($state, JSON_THROW_ON_ERROR);
        $tmp = $statePath . '.tmp.php';
        if (file_put_contents($tmp, $content, LOCK_EX) !== strlen($content) || !rename($tmp, $statePath)) throw new RuntimeException('Could not save migration cursor; safe to retry.');
        echo "$status: $label\n";
        usleep(100000); // sequential uploads rather than a burst from 1000–2000 records
    }
    if (!$rows && !isset($options['dry-run'])) {
        $state['complete'] = true;
        file_put_contents($statePath, "<?php exit; ?>\n" . json_encode($state, JSON_THROW_ON_ERROR), LOCK_EX);
        echo "Scan complete. Review missing/failed counts and recent_errors; use --rescan to retry.\n";
    }
    echo json_encode($state, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";
} catch (Throwable $e) { fwrite(STDERR, $e->getMessage() . "\n"); exit(1); }
