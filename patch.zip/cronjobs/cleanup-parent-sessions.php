<?php
require_once '../includes/config.php';

// Delete sessions inactive for more than 90 days
$inactiveThreshold = date('Y-m-d H:i:s', strtotime('-90 days'));
$stmt = $pdo->prepare("DELETE FROM parent_auth_sessions WHERE last_activity < ?");
$stmt->execute([$inactiveThreshold]);

$deletedCount = $stmt->rowCount();