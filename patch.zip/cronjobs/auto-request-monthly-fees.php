<?php
// Supports existing web cron calls as well as direct PHP CLI execution.
require_once __DIR__ . '/../includes/financial/auto-monthly-fees.php';

$isCli = PHP_SAPI === 'cli';
if (!$isCli) {
    header('Content-Type: application/json');
    ignore_user_abort(true);
}
if (function_exists('set_time_limit')) set_time_limit(0);
$startedAt = microtime(true);
$jobLock = null;
$exitCode = 0;

try {
    // Acquire before loading config/database, and retain through mail delivery.
    $jobLock = autoMonthlyFeesAcquireLock();
    if ($jobLock === null) {
        echo json_encode(['success' => true, 'status' => 'already_running', 'message' => 'Monthly fee generation is already running.']);
        exit(0);
    }
    include_once __DIR__ . '/../includes/auth-check.php';
    include_once __DIR__ . '/../includes/phpmailer.php';
    if (session_status() === PHP_SESSION_ACTIVE) session_write_close();

    if ((int)($schoolSettings['auto_request_monthly_fees'] ?? 0) !== 1) {
        echo json_encode(['success' => false, 'status' => 'skipped', 'message' => 'Auto Request Monthly Fees is disabled.']);
        exit(0);
    }
    // Freeze month/day/year after config applies the school's timezone.
    $billingDate = new DateTimeImmutable('now');
    if ((int)$billingDate->format('j') !== (int)($schoolSettings['auto_request_monthly_fees_day'] ?? 28)) {
        echo json_encode(['success' => false, 'status' => 'skipped', 'message' => 'Auto Request Monthly Fees is not scheduled for today.']);
        exit(0);
    }
    $currency_symbol = $currency_symbol ?? '₹';
    $senderName = 'Automated Fee Requester';
    $recipientAddress = $schoolInfo['email'] ?? 'mr.nuralam.com@gmail.com';
    $recipientName = $schoolInfo['principal_name'] ?? 'Principal';
    $month_year = $billingDate->format('F Y');
    $subject = 'Monthly Fee Generation Report - ' . $month_year;
    $report = (new AutoMonthlyFeesJob($pdo))->run($billingDate, $currency_symbol,
        static function (array $studentIds, string $month) use ($pdo): array {
            $tokens = getFCMTokensFromDatabase($pdo, $studentIds);
            if (!$tokens) return ['success' => true];
            $title = 'Payment Reminder';
            $body = "Your monthly fee for $month has been generated. Please check your account.";
            $delivery = sendFirebaseNotification($pdo, $studentIds, $tokens, $title, $body,
                ['title' => $title, 'message' => $body], true, 30);
            return is_array($delivery) ? $delivery : ['success' => false, 'message' => 'Invalid notification response.'];
        }, static function (string $message): void { error_log('[monthly-fees] ' . $message); });
    $results = $report['results'];
    if (isset($report['fatal_error'])) {
        $results[] = ['name' => 'SYSTEM SCRIPT ERROR', 'student_id' => 'N/A', 'success' => false,
            'action' => 'FATAL', 'message' => $report['fatal_error']];
    }
    $processedCount = $report['processed'];
    $skippedCount = $report['skipped'];

    // -----------------------------------------------------
    // BUILD HTML EMAIL REPORT (Using Inline CSS for Email)
    // -----------------------------------------------------
    $totalStudents = $processedCount + $skippedCount;
    $reportNote = $report['results_omitted'] > 0
        ? 'Showing the first ' . count($report['results']) . ' results; ' . $report['results_omitted'] . ' more results omitted from this email.' : '';
    $deliveryNote = 'Billing errors: ' . $report['errors'] . '; failed notification batches: ' . $report['notification_batches_failed'] . '.';

    $htmlBody = "
    <div style='font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; color: #333;'>
        <h2 style='color: #0d6efd; border-bottom: 2px solid #eee; padding-bottom: 10px;'>Automated Fee Generation Report</h2>
        <p><strong>Month/Year:</strong> {$month_year}</p>

        <div style='background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin-bottom: 20px; display: flex; gap: 20px;'>
            <div style='background: #fff; padding: 10px 20px; border: 1px solid #ddd; border-radius: 5px;'><strong>Total:</strong> {$totalStudents}</div>
            <div style='background: #e6f8ec; padding: 10px 20px; border: 1px solid #c3e6cb; border-radius: 5px; color: #155724;'><strong>Processed:</strong> {$processedCount}</div>
            <div style='background: #fdf3f4; padding: 10px 20px; border: 1px solid #f5c6cb; border-radius: 5px; color: #721c24;'><strong>Skipped:</strong> {$skippedCount}</div>
        </div>

        <p>{$reportNote}</p><p>{$deliveryNote}</p>
        <table style='width: 100%; border-collapse: collapse; font-size: 14px;'>
            <thead>
                <tr style='background-color: #343a40; color: #fff; text-align: left;'>
                    <th style='padding: 10px; border: 1px solid #ddd;'>Student Details</th>
                    <th style='padding: 10px; border: 1px solid #ddd;'>Status</th>
                    <th style='padding: 10px; border: 1px solid #ddd;'>Remarks</th>
                </tr>
            </thead>
            <tbody>";

    if (!empty($results)) {
        foreach ($results as $res) {
            $statusColor = $res['success'] ? '#28a745' : '#dc3545';
            $statusBg = $res['success'] ? '#ffffff' : '#fdf3f4';
            $actionText = strtoupper($res['action']);
            $res = array_map(static fn($value) => htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'), $res);

            $htmlBody .= "
                <tr style='background-color: {$statusBg};'>
                    <td style='padding: 10px; border: 1px solid #ddd;'>
                        <strong>{$res['name']}</strong><br>
                        <span style='color: #666; font-size: 12px;'>ID: {$res['student_id']}</span>
                    </td>
                    <td style='padding: 10px; border: 1px solid #ddd; color: {$statusColor}; font-weight: bold;'>
                        {$actionText}
                    </td>
                    <td style='padding: 10px; border: 1px solid #ddd; color: #555;'>
                        {$res['message']}
                    </td>
                </tr>";
        }
    } else {
        $htmlBody .= "<tr><td colspan='3' style='padding: 15px; text-align: center; border: 1px solid #ddd;'>No students found to process.</td></tr>";
    }

    $htmlBody .= "
            </tbody>
        </table>
        <p style='margin-top: 20px; font-size: 12px; color: #888; text-align: center;'>This is an automated message from your School Management System.</p>
    </div>";

    // Plain text alternative for email clients that block HTML
    $altBody = "Automated Fee Report for $month_year\n";
    $altBody .= "Total: $totalStudents | Processed: $processedCount | Skipped: $skippedCount\n";
    $altBody .= "Check your admin dashboard for more details.";

    // Report delivery failure separately; committed fees are never rolled back here.
    try {
        $mailResult = sendMail($senderName, $recipientAddress, $recipientName, $subject, $htmlBody, $altBody, 30);
    } catch (Throwable $error) {
        $mailResult = ['success' => false, 'message' => $error->getMessage()];
    }
    $response = $report;
    unset($response['results']);
    $response['email_sent'] = is_array($mailResult) && !empty($mailResult['success']);
    $response['email_sent_to'] = $recipientAddress;
    if (!$response['email_sent']) {
        $response['success'] = false;
        $response['email_error'] = is_array($mailResult) ? ($mailResult['message'] ?? 'Email failed.') : 'Invalid mailer response.';
        error_log('[monthly-fees] ' . $response['email_error']);
    }
    $response['status'] = $response['success'] ? 'completed' : 'completed_with_errors';
} catch (Throwable $error) {
    $response = ['success' => false, 'billing_success' => false, 'status' => 'failed', 'message' => $error->getMessage()];
    error_log('[monthly-fees] ' . $error->getMessage());
} finally {
    if (is_resource($jobLock)) {
        flock($jobLock, LOCK_UN);
        fclose($jobLock);
    }
}
$response['duration_seconds'] = round(microtime(true) - $startedAt, 3);
if (!$response['success']) {
    $exitCode = 1;
    if (!$isCli) http_response_code(500);
}
echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
exit($exitCode);
