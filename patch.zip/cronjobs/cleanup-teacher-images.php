<?php
include_once __DIR__ . '/../includes/config.php';
$folderPath = realpath(__DIR__ . '/../uploads/teachers/');

echo json_encode(cleanupUnusedTeacherImages($pdo, $folderPath));

/**
 * Cleans up teacher image directory by removing unused images
 * 
 * @param PDO $pdo Database connection
 * @param string $imageDirectory Path to teacher images directory
 * @return array Result with status and deletion information
 */
function cleanupUnusedTeacherImages(PDO $pdo, string $imageDirectory): array {
    $result = [
        'status' => 'success',
        'kept_images' => 0,
        'deleted_images' => 0,
        'errors' => [],
        'deleted_files' => [],
        'kept_files' => []
    ];

    try {
        // Verify directory exists
        if (!is_dir($imageDirectory)) {
            throw new Exception("Image directory does not exist");
        }

        // Get all image files in directory
        $imageFiles = array_filter(scandir($imageDirectory), function($file) {
            return $file !== '.' && $file !== '..' && preg_match('/\.(jpg|jpeg|png|gif)$/i', $file);
        });

        // Prepare database statement for checking images
        $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM teachers WHERE teacher_image = ?");

        foreach ($imageFiles as $imageFile) {
            // Skip default image
            if ($imageFile === 'default_teacher_dp.jpg') {
                $result['kept_images']++;
                $result['kept_files'][] = $imageFile;
                continue;
            }

            // Check if image exists in database
            $checkStmt->execute([$imageFile]);
            $existsInDb = $checkStmt->fetchColumn();

            if ($existsInDb > 0) {
                // Image is in use - keep it
                $result['kept_images']++;
                $result['kept_files'][] = $imageFile;
            } else {
                // Image not in use - delete it
                $filePath = rtrim($imageDirectory, '/') . '/' . $imageFile;
                if (file_exists($filePath)) {
                    if (unlink($filePath)) {
                        $result['deleted_images']++;
                        $result['deleted_files'][] = $imageFile;
                    } else {
                        $result['errors'][] = "Failed to delete: $imageFile";
                    }
                }
            }
        }

    } catch (Exception $e) {
        $result['status'] = 'error';
        $result['errors'][] = $e->getMessage();
    }

    return $result;
}