<?php
include_once __DIR__ . '/../includes/config.php'; // Include your configuration file

echo json_encode(deleteExamsOlderThan10Years($pdo));

/**
 * Deletes exam records older than 10 years from the exams table
 * 
 * @param PDO $pdo PDO database connection instance
 * @return array Returns an array with status and message
 */
function deleteExamsOlderThan10Years(PDO $pdo): array {
    try {
        // Calculate the date 10 years ago from today
        $tenYearsAgo = (new DateTime())->modify('-10 years')->format('Y-m-d H:i:s');
        
        // Prepare the DELETE statement
        $stmt = $pdo->prepare("DELETE FROM exams WHERE created_at < :tenYearsAgo");
        
        // Bind the parameter and execute
        $stmt->bindParam(':tenYearsAgo', $tenYearsAgo, PDO::PARAM_STR);
        $stmt->execute();
        
        // Get the number of affected rows
        $deletedCount = $stmt->rowCount();
        
        return [
            'status' => 'success',
            'message' => "Successfully deleted $deletedCount exam records older than 10 years.",
            'deleted_count' => $deletedCount
        ];
        
    } catch (PDOException $e) {
        return [
            'status' => 'error',
            'message' => "Database error: " . $e->getMessage()
        ];
    }
}