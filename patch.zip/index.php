<?php
/** @var array $websiteConfig */
include_once('includes/config.php');
if ($websiteConfig) {
    if ($websiteConfig['website_template']) {
        if (file_exists('assets/templates/website-interfaces/' . $websiteConfig['website_template'] . '.php')) {
            include_once('assets/templates/website-interfaces/' . $websiteConfig['website_template'] . '.php');
        } else {
            die('Template not found in local directory.');
        }
    } else {
        die('Database error');
    }
} else {
    die('Website configuration required.');
}
