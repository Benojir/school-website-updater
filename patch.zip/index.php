<?php
if (!file_exists('install/installed.php')) {
    header('Location: install/index.php');
    exit();
}

include_once('includes/config.php');
if ($websiteConfig) {
    if ($websiteConfig['website_template']) {
        if (file_exists('designs/' . $websiteConfig['website_template'] . '.php')) {
            include_once('designs/' . $websiteConfig['website_template'] . '.php');
        } else {
            die('Template not found in local directory.');
        }
    } else {
        die('Database error');
    }
} else {
    die('Website configuration required.');
}
