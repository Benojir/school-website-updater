<?php
/** @var string $school_name */
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Add New Student - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    include_once("../../includes/permission-denied.php");
}

// Fetch all classes
$classes = $pdo->query("SELECT * FROM classes")->fetchAll(PDO::FETCH_ASSOC);

// Fetch all sections grouped by class_id
$sections_stmt = $pdo->query("SELECT * FROM sections ORDER BY section_name");
$sections_by_class = [];
while ($section = $sections_stmt->fetch(PDO::FETCH_ASSOC)) {
    $sections_by_class[$section['class_id']][] = $section;
}

// Blood group options
$blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

// Religions
$religions = [
    'islam',
    'hindu',
    'christian',
    'buddhist',
    'jain',
    'sikh',
    'parsi',
    'judaism',
    'bahai',
    'atheist',
    'agnostic',
    'other'
];

// Get all driving routes for the car route dropdown.
$routes = $pdo->query("SELECT id, route_name FROM driving_routes ORDER BY route_name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Get all drivers
$drivers = $pdo->query("SELECT * FROM drivers WHERE status = 'active' ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Detect admission type. Default value (new-admission)
$admission_type = 'new-admission';
if (!empty($_REQUEST['admission-type']) && strtolower(trim($_REQUEST['admission-type'])) === 're-admission') {
    $admission_type = 're-admission';
}
?>

<style>
    /* ---------- Image field: clickable tile + camera/gallery picker ---------- */
    .image-field {
        display: flex;
        gap: 18px;
        align-items: flex-start;
        flex-wrap: wrap;
    }

    /* Document fields stack the tile above its Remove link instead of sitting side-by-side */
    .image-field.field-stacked {
        display: block;
    }

    .image-tile {
        position: relative;
        flex: 0 0 auto;
        border: 2px dashed #c7ced6;
        border-radius: 10px;
        background-color: #f8f9fa;
        cursor: pointer;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: border-color .18s ease, background-color .18s ease, box-shadow .18s ease;
    }

    /* Portrait tile for student / father / mother photos (5:6) */
    .image-tile.tile-portrait {
        width: 125px;
        height: 150px;
    }

    /* Landscape tile for ID cards & certificates */
    .image-tile.tile-landscape {
        width: 100%;
        height: 105px;
    }

    .image-tile:hover,
    .image-tile:focus-visible {
        border-color: var(--primary-color);
        background-color: #fff;
        box-shadow: 0 0 0 4px rgba(13, 110, 253, .10);
        outline: none;
    }

    .image-tile.has-image {
        border-style: solid;
        border-color: #dee2e6;
        background-color: #fff;
    }

    .image-tile .tile-preview {
        display: none;
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .image-tile.has-image .tile-preview {
        display: block;
    }

    .image-tile .tile-placeholder {
        text-align: center;
        color: #8a949e;
        font-size: 13px;
        line-height: 1.45;
        padding: 6px;
        pointer-events: none;
    }

    .image-tile .tile-placeholder i {
        display: block;
        margin-bottom: 6px;
        font-size: 21px;
        color: #adb5bd;
    }

    .image-tile.has-image .tile-placeholder {
        display: none;
    }

    .image-tile .tile-overlay {
        position: absolute;
        right: 0;
        bottom: 0;
        left: 0;
        padding: 4px 0;
        background-color: rgba(0, 0, 0, .55);
        color: #fff;
        font-size: 12px;
        text-align: center;
        opacity: 0;
        transition: opacity .18s ease;
        pointer-events: none;
    }

    .image-tile.has-image:hover .tile-overlay {
        opacity: 1;
    }

    .image-field-meta {
        flex: 1 1 190px;
        min-width: 170px;
    }

    .tile-clear {
        display: none;
    }

    /* Camera / Gallery source-picker popup */
    .photo-source-menu {
        display: none;
        position: absolute;
        z-index: 2000;
        background: #fff;
        border: 1px solid #ddd;
        border-radius: 6px;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.18);
        min-width: 150px;
        overflow: hidden;
    }

    .photo-source-menu button {
        display: block;
        width: 100%;
        border: none;
        background: none;
        padding: 10px 14px;
        text-align: left;
        font-size: 14px;
        cursor: pointer;
        white-space: nowrap;
    }

    .photo-source-menu button:hover,
    .photo-source-menu button:focus {
        background-color: #f1f3f5;
    }

    .photo-source-menu button i {
        width: 18px;
        margin-right: 6px;
        color: var(--primary-color);
    }

    .photo-source-menu .photo-source-divider {
        border-top: 1px solid #eee;
    }

    /* ---------- Cropper modal ---------- */
    #cropModal .modal-dialog {
        max-width: 90%;
    }

    .img-container {
        position: relative;
        overflow: hidden;
        margin: 0 auto;
        width: 100%;
        height: 70vh;
        min-height: 360px;
        max-height: 600px;
        background-color: #f8f9fa;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    #imageToCrop {
        display: block;
        max-width: 100%;
        max-height: 100%;
    }

    .cropper-container {
        width: 100% !important;
        height: 100% !important;
    }

    .cropper-modal {
        background-color: rgba(255, 255, 255, 0.8);
    }

    .cropper-view-box {
        outline: 2px solid #007bff;
        outline-color: rgba(0, 123, 255, 0.75);
    }
</style>

<div class="container mt-4 mb-5">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0"><i class="fas fa-user-plus me-2"></i> <?= ($admission_type == 're-admission') ? 'Re-Admission' : 'New Admission' ?></h4>
        </div>

        <div class="card-body">
            <form id="addStudentForm" method="post" action="<?= BASE_URL ?>/api/admin/put/student/process-add-student.php" enctype="multipart/form-data">

                <input type="hidden" name="admission_type" value="<?= $admission_type ?>" required />

                <div class="row g-3">
                    <!-- Personal Information Section -->
                    <div class="col-md-12">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-user-circle me-2"></i>Student Information
                        </h5>
                    </div>

                    <div class="col-md-4">
                        <label for="name" class="form-label">Full Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="name" name="name" required placeholder="John Doe">
                    </div>

                    <div class="col-md-4">
                        <label for="gender" class="form-label">Gender <span class="text-danger">*</span></label>
                        <select class="form-select" id="gender" name="gender" required>
                            <option value="" selected disabled>Select Gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="date_of_birth" class="form-label">Date of Birth <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" required>
                    </div>

                    <div class="col-md-4">
                        <label for="blood_group" class="form-label">Blood Group</label>
                        <select class="form-select" id="blood_group" name="blood_group">
                            <option value="" selected disabled>Select Blood Group</option>
                            <?php foreach ($blood_groups as $group): ?>
                                <option value="<?= $group ?>"><?= $group ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="religion" class="form-label">Religion</label>
                        <select class="form-select" id="religion" name="religion">
                            <option value="" selected>Select Religion</option>
                            <?php foreach ($religions as $religion): ?>
                                <option value="<?= $religion ?>"><?= ucwords($religion) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="caste" class="form-label">Caste (Optional)</label>
                        <select class="form-select" id="caste" name="caste">
                            <option value="" selected disabled>Select Caste</option>
                            <option value="General">General</option>
                            <option value="SC">SC</option>
                            <option value="ST">ST</option>
                            <option value="OBC-A">OBC-A</option>
                            <option value="OBC-B">OBC-B</option>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="student_adhaar" class="form-label">Student's Adhaar No.</label>
                        <input type="text" class="form-control" id="student_adhaar" name="student_adhaar" placeholder="Enter student adhaar number"/>
                    </div>

                    <!-- Family Information Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-users me-2"></i>Family Information
                        </h5>
                    </div>

                    <div class="col-md-6">
                        <label for="father_name" class="form-label">Father's Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="father_name" name="father_name" required placeholder="Father's name">
                    </div>

                    <div class="col-md-6">
                        <label for="mother_name" class="form-label">Mother's Name</label>
                        <input type="text" class="form-control" id="mother_name" name="mother_name" placeholder="Mother's name">
                    </div>

                    <div class="col-md-6">
                        <label for="father_occupation" class="form-label">Father's Occupation</label>
                        <input type="text" class="form-control" id="father_occupation" name="father_occupation" placeholder="Occupation">
                    </div>

                    <div class="col-md-6">
                        <label for="mother_occupation" class="form-label">Mother's Occupation</label>
                        <input type="text" class="form-control" id="mother_occupation" name="mother_occupation" placeholder="Occupation">
                    </div>

                    <!-- ... ফ্যামিলির অন্যান্য তথ্যগুলোর নিচে ... -->
                    <div class="col-md-6">
                        <label for="father_annual_income" class="form-label">Father's Annual Income (Optional)</label>
                        <input type="number" class="form-control" id="father_annual_income" name="father_annual_income" placeholder="e.g. 300000">
                    </div>

                    <div class="col-md-6">
                        <label for="mother_annual_income" class="form-label">Mother's Annual Income (Optional)</label>
                        <input type="number" class="form-control" id="mother_annual_income" name="mother_annual_income" placeholder="e.g. 250000">
                    </div>

                    <div class="col-md-6">
                        <label for="father_adhaar" class="form-label">Father's Adhaar No.</label>
                        <input type="text" class="form-control" id="father_adhaar" name="father_adhaar" placeholder="Enter father adhaar number"/>
                    </div>

                    <div class="col-md-6">
                        <label for="mother_adhaar" class="form-label">Mother's Adhaar No.</label>
                        <input type="text" class="form-control" id="mother_adhaar" name="mother_adhaar" placeholder="Enter mother adhaar number"/>
                    </div>

                    <div class="col-md-6">
                        <label for="father_pan_no" class="form-label">Father's PAN Card No. (Optional)</label>
                        <input type="text" class="form-control" id="father_pan_no" name="father_pan_no" placeholder="Enter father's PAN card number"/>
                    </div>

                    <div class="col-md-6">
                        <label for="father_voter_no" class="form-label">Father's Voter Card No. (Optional)</label>
                        <input type="text" class="form-control" id="father_voter_no" name="father_voter_no" placeholder="Enter father's voter card number"/>
                    </div>

                    <div class="col-md-6">
                        <label for="mother_pan_no" class="form-label">Mother's PAN Card No. (Optional)</label>
                        <input type="text" class="form-control" id="mother_pan_no" name="mother_pan_no" placeholder="Enter mother's PAN card number"/>
                    </div>

                    <div class="col-md-6">
                        <label for="mother_voter_no" class="form-label">Mother's Voter Card No. (Optional)</label>
                        <input type="text" class="form-control" id="mother_voter_no" name="mother_voter_no" placeholder="Enter mother's voter card number"/>
                    </div>

                    <div class="col-md-4">
                        <label for="phone_number" class="form-label">Father's Phone Number <span class="text-danger"> *</span>
                            <i title="This phone number will be used as primary phone number. OTPs will be sent to this number. Enter phone number without country code." class="fa-solid fa-circle-question"></i>
                        </label>
                        <input type="tel" class="form-control" id="phone_number" name="phone_number" required placeholder="1234567890">
                    </div>

                    <div class="col-md-4">
                        <label for="alternate_phone_number" class="form-label">Mother's Phone Number
                            <i title="This phone number will be used as alternate phone number if primary number is not reachable. Enter phone number without country code." class="fa-solid fa-circle-question"></i>
                        </label>
                        <input type="tel" class="form-control" id="alternate_phone_number" name="alternate_phone_number" placeholder="1234567890">
                    </div>

                    <div class="col-md-4">
                        <label for="email" class="form-label">Email Id</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="example@example.com">
                    </div>

                    <!-- Parent Bank Account Information Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-university me-2"></i>Parent Bank Account Info (Optional)
                        </h5>
                    </div>

                    <div class="col-md-3">
                        <label for="bank_name" class="form-label">Bank Name</label>
                        <input type="text" class="form-control" id="bank_name" name="bank_name" placeholder="Enter bank name">
                    </div>

                    <div class="col-md-3">
                        <label for="bank_branch_name" class="form-label">Branch Name</label>
                        <input type="text" class="form-control" id="bank_branch_name" name="bank_branch_name" placeholder="Enter branch name">
                    </div>

                    <div class="col-md-3">
                        <label for="bank_account_no" class="form-label">Account Number</label>
                        <input type="text" class="form-control" id="bank_account_no" name="bank_account_no" placeholder="Enter account number">
                    </div>

                    <div class="col-md-3">
                        <label for="ifsc_code" class="form-label">IFSC Code</label>
                        <input type="text" class="form-control" id="ifsc_code" name="ifsc_code" placeholder="Enter IFSC code">
                    </div>

                    <!-- Address Information Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-location-dot me-2"></i>Address
                        </h5>
                    </div>

                    <div class="col-md-4">
                        <label for="village" class="form-label">Village/Town</label>
                        <input type="text" class="form-control" id="village" name="village" placeholder="Enter village or town name">
                    </div>

                    <div class="col-md-4">
                        <label for="post_office" class="form-label">Post Office</label>
                        <input type="text" class="form-control" id="post_office" name="post_office" placeholder="Enter post office">
                    </div>

                    <div class="col-md-4">
                        <label for="police_station" class="form-label">Police Station</label>
                        <input type="text" class="form-control" id="police_station" name="police_station" placeholder="Enter police station">
                    </div>

                    <div class="col-md-4">
                        <label for="district" class="form-label">District</label>
                        <input type="text" class="form-control" id="district" name="district" placeholder="Enter district name">
                    </div>

                    <div class="col-md-4">
                        <label for="pin_code" class="form-label">Pin Code</label>
                        <input type="text" class="form-control" id="pin_code" name="pin_code" placeholder="Enter pin code">
                    </div>

                    <!-- Academic Information Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-graduation-cap me-2"></i>Academic Information
                        </h5>
                    </div>

                    <div class="col-md-4">
                        <label for="registration_no" class="form-label">Registration No</label>
                        <input type="text" class="form-control" id="registration_no" name="registration_no">
                    </div>

                    <!-- ... Registration No এর নিচে বা আশেপাশে ... -->
                    <div class="col-md-4">
                        <label for="banglar_shiksha_code" class="form-label">Banglar Shiksha Code (Optional)</label>
                        <input type="text" class="form-control" id="banglar_shiksha_code" name="banglar_shiksha_code" placeholder="Must be unique if provided">
                    </div>

                    <div class="col-md-4">
                        <label for="class_id" class="form-label">Class <span class="text-danger">*</span></label>
                        <select class="form-select" id="class_id" name="class_id" required onchange="updateSectionDropdown()">
                            <option value="" selected disabled>Select Class</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?= $class['id'] ?>"><?= htmlspecialchars($class['class_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="section_id" class="form-label">Section</label>
                        <select class="form-select" id="section_id" name="section_id">
                            <option value="" selected>Select Section</option>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="roll_no" class="form-label">Roll No</label>
                        <input type="number" class="form-control" id="roll_no" name="roll_no" placeholder="Roll number">
                    </div>

                    <div class="col-md-4">
                        <label for="admission_date" class="form-label">Admission Date <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="admission_date" name="admission_date" required>
                    </div>

                    <div class="col-md-4">
                        <label for="academic_year" class="form-label">Academic Year <span class="text-danger">*</span></label>
                        <select class="form-control" id="academic_year" name="academic_year" required>
                            <?php
                            $current_year = date('Y');
                            for ($year = $current_year - 1; $year <= $current_year + 2; $year++) {
                                $selected = ($year == $current_year + 0) ? 'selected' : '';
                                echo "<option value='$year' $selected>$year</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <!-- Additional Information Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-info-circle me-2"></i>Additional Information
                        </h5>
                    </div>

                    <div class="col-md-4">
                        <label for="admission_fee_discount" class="form-label">Admission Fee Discount</label>
                        <input type="number" class="form-control" id="admission_fee_discount" name="admission_fee_discount" placeholder="Admission fee discount if applicable">
                    </div>

                    <div class="col-md-4 ">
                        <label class="form-label">Hosteler</label>
                        <div class="d-flex align-items-center">
                            <div class="form-check me-3">
                                <input class="form-check-input" type="radio" name="is_hosteler" id="hosteler_yes" value="1">
                                <label class="form-check-label" for="hosteler_yes">Yes</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="is_hosteler" id="hosteler_no" value="0" checked>
                                <label class="form-check-label" for="hosteler_no">No</label>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4" style="display: none;">
                        <label for="hostel_fee" class="form-label">Hostel Fee</label>
                        <input type="number" class="form-control" id="hostel_fee" name="hostel_fee" placeholder="Hostel fees amount">
                    </div>

                    <div class="col-md-4">
                        <label for="custom_class_fee" class="form-label">Custom School Fee</label>
                        <input type="number" class="form-control" id="custom_class_fee" name="custom_class_fee" placeholder="Custom school fees if applicable">
                    </div>

                    <div class="col-md-4 ">
                        <label class="form-label">Uses School Car</label>
                        <select class="form-select" id="uses_school_car">
                            <option value="yes">Yes</option>
                            <option value="no" selected>No</option>
                        </select>
                    </div>

                    <div class="col-md-4 car_items" style="display: none;">
                        <label for="driver" class="form-label">Driver</label>
                        <select class="form-select select2" id="driver" name="driver_id">
                            <option value="" selected>Select Driver</option>
                            <?php foreach ($drivers as $driver): ?>
                                <option value="<?= $driver['id'] ?>"><?= safe_htmlspecialchars($driver['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4 car_items" style="display: none;">
                        <label for="driving_route" class="form-label">Driving Route</label>
                        <select class="form-select select2" id="driving_route" name="driving_route">
                            <option value="" selected>Select Driving Route</option>
                        </select>
                    </div>

                    <div class="col-md-4 car_items" style="display: none;">
                        <label for="car_fee" class="form-label">Car Fee</label>
                        <input type="number" class="form-control" id="car_fee" name="car_fee" placeholder="Car fees amount">
                    </div>

                    <div class="col-md-4">
                        <label for="coaching_fee" class="form-label">Coaching Fee</label>
                        <input type="number" class="form-control" id="coaching_fee" name="coaching_fee" placeholder="Coaching fee if applicable">
                    </div>

                    <div class="col-md-4">
                        <label for="tiffin_fee" class="form-label">Tiffin Fee</label>
                        <input type="number" class="form-control" id="tiffin_fee" name="tiffin_fee" placeholder="Tiffin fee if applicable">
                    </div>

                    <!-- Additional Information Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-info-circle me-2"></i>Extra Options
                        </h5>
                    </div>

                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="auto_include_admission_fee" name="auto_include_admission_fee">
                            <label class="form-check-label" for="auto_include_admission_fee">
                                Auto include admission fee
                            </label>
                        </div>
                    </div>

                    <!-- Photo Upload Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-camera me-2"></i>Student Photo
                        </h5>
                    </div>

                    <div class="col-md-6">
                        <div class="image-field" data-crop="1" data-crop-title="Crop Student Photo (5:6 ratio required)">
                            <div class="image-tile tile-portrait" tabindex="0" role="button" aria-label="Add student passport photo">
                                <img class="tile-preview" id="imagePreview" src="" alt="Student photo preview">
                                <div class="tile-placeholder">
                                    <i class="fas fa-camera"></i>
                                    Add photo
                                </div>
                                <div class="tile-overlay"><i class="fas fa-pen me-1"></i>Change</div>
                            </div>
                            <div class="image-field-meta">
                                <label class="form-label mb-1">Passport Photo (5:6 Ratio)</label>
                                <small class="text-muted d-block">Click the box to take a photo with the camera, or pick one from the gallery. Saved at 500&times;600 pixels.</small>
                                <button type="button" class="btn btn-sm btn-link text-danger p-0 mt-2 tile-clear">
                                    <i class="fas fa-trash-alt me-1"></i>Remove photo
                                </button>
                            </div>
                            <input type="file" class="src-gallery d-none" id="student_image" name="student_image" accept="image/*">
                            <input type="file" class="src-camera d-none" accept="image/*" capture="environment">
                            <input type="hidden" class="cropped-data" id="cropped_image_data" name="cropped_image_data">
                        </div>
                    </div>

                    <!-- Father's Photo & Documents Section (All Optional) -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-id-card me-2"></i>Father's Photo & Documents (Optional)
                        </h5>
                    </div>

                    <div class="col-md-6">
                        <div class="image-field" data-crop="1" data-crop-title="Crop Father's Photo (5:6 ratio required)">
                            <div class="image-tile tile-portrait" tabindex="0" role="button" aria-label="Add father's photo">
                                <img class="tile-preview" id="fatherImagePreview" src="" alt="Father's photo preview">
                                <div class="tile-placeholder">
                                    <i class="fas fa-camera"></i>
                                    Add photo
                                </div>
                                <div class="tile-overlay"><i class="fas fa-pen me-1"></i>Change</div>
                            </div>
                            <div class="image-field-meta">
                                <label class="form-label mb-1">Father's Photo (5:6 Ratio)</label>
                                <small class="text-muted d-block">Click the box to take a photo with the camera, or pick one from the gallery. Saved at 500&times;600 pixels.</small>
                                <button type="button" class="btn btn-sm btn-link text-danger p-0 mt-2 tile-clear">
                                    <i class="fas fa-trash-alt me-1"></i>Remove photo
                                </button>
                            </div>
                            <input type="file" class="src-gallery d-none" id="father_image" name="father_image" accept="image/*">
                            <input type="file" class="src-camera d-none" accept="image/*" capture="environment">
                            <input type="hidden" class="cropped-data" id="cropped_father_image_data" name="cropped_father_image_data">
                        </div>
                    </div>

                    <div class="col-md-6"></div>

                    <div class="col-md-4">
                        <label class="form-label">Father's Aadhaar Card Image</label>
                        <div class="image-field field-stacked" data-crop="0">
                            <div class="image-tile tile-landscape" tabindex="0" role="button" aria-label="Add father's Aadhaar card image">
                                <img class="tile-preview" src="" alt="Father's Aadhaar card preview">
                                <div class="tile-placeholder">
                                    <i class="fas fa-camera"></i>
                                    Camera or gallery
                                </div>
                                <div class="tile-overlay"><i class="fas fa-pen me-1"></i>Change</div>
                            </div>
                            <button type="button" class="btn btn-sm btn-link text-danger p-0 mt-1 tile-clear">
                                <i class="fas fa-trash-alt me-1"></i>Remove
                            </button>
                            <input type="file" class="src-gallery d-none" id="father_aadhaar_image" name="father_aadhaar_image" accept="image/jpeg,image/png">
                            <input type="file" class="src-camera d-none" accept="image/*" capture="environment">
                        </div>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Father's Voter Card Image</label>
                        <div class="image-field field-stacked" data-crop="0">
                            <div class="image-tile tile-landscape" tabindex="0" role="button" aria-label="Add father's voter card image">
                                <img class="tile-preview" src="" alt="Father's voter card preview">
                                <div class="tile-placeholder">
                                    <i class="fas fa-camera"></i>
                                    Camera or gallery
                                </div>
                                <div class="tile-overlay"><i class="fas fa-pen me-1"></i>Change</div>
                            </div>
                            <button type="button" class="btn btn-sm btn-link text-danger p-0 mt-1 tile-clear">
                                <i class="fas fa-trash-alt me-1"></i>Remove
                            </button>
                            <input type="file" class="src-gallery d-none" id="father_voter_image" name="father_voter_image" accept="image/jpeg,image/png">
                            <input type="file" class="src-camera d-none" accept="image/*" capture="environment">
                        </div>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Father's PAN Card Image</label>
                        <div class="image-field field-stacked" data-crop="0">
                            <div class="image-tile tile-landscape" tabindex="0" role="button" aria-label="Add father's PAN card image">
                                <img class="tile-preview" src="" alt="Father's PAN card preview">
                                <div class="tile-placeholder">
                                    <i class="fas fa-camera"></i>
                                    Camera or gallery
                                </div>
                                <div class="tile-overlay"><i class="fas fa-pen me-1"></i>Change</div>
                            </div>
                            <button type="button" class="btn btn-sm btn-link text-danger p-0 mt-1 tile-clear">
                                <i class="fas fa-trash-alt me-1"></i>Remove
                            </button>
                            <input type="file" class="src-gallery d-none" id="father_pan_image" name="father_pan_image" accept="image/jpeg,image/png">
                            <input type="file" class="src-camera d-none" accept="image/*" capture="environment">
                        </div>
                    </div>

                    <!-- Mother's Photo & Documents Section (All Optional) -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-id-card me-2"></i>Mother's Photo & Documents (Optional)
                        </h5>
                    </div>

                    <div class="col-md-6">
                        <div class="image-field" data-crop="1" data-crop-title="Crop Mother's Photo (5:6 ratio required)">
                            <div class="image-tile tile-portrait" tabindex="0" role="button" aria-label="Add mother's photo">
                                <img class="tile-preview" id="motherImagePreview" src="" alt="Mother's photo preview">
                                <div class="tile-placeholder">
                                    <i class="fas fa-camera"></i>
                                    Add photo
                                </div>
                                <div class="tile-overlay"><i class="fas fa-pen me-1"></i>Change</div>
                            </div>
                            <div class="image-field-meta">
                                <label class="form-label mb-1">Mother's Photo (5:6 Ratio)</label>
                                <small class="text-muted d-block">Click the box to take a photo with the camera, or pick one from the gallery. Saved at 500&times;600 pixels.</small>
                                <button type="button" class="btn btn-sm btn-link text-danger p-0 mt-2 tile-clear">
                                    <i class="fas fa-trash-alt me-1"></i>Remove photo
                                </button>
                            </div>
                            <input type="file" class="src-gallery d-none" id="mother_image" name="mother_image" accept="image/*">
                            <input type="file" class="src-camera d-none" accept="image/*" capture="environment">
                            <input type="hidden" class="cropped-data" id="cropped_mother_image_data" name="cropped_mother_image_data">
                        </div>
                    </div>

                    <div class="col-md-6"></div>

                    <div class="col-md-4">
                        <label class="form-label">Mother's Aadhaar Card Image</label>
                        <div class="image-field field-stacked" data-crop="0">
                            <div class="image-tile tile-landscape" tabindex="0" role="button" aria-label="Add mother's Aadhaar card image">
                                <img class="tile-preview" src="" alt="Mother's Aadhaar card preview">
                                <div class="tile-placeholder">
                                    <i class="fas fa-camera"></i>
                                    Camera or gallery
                                </div>
                                <div class="tile-overlay"><i class="fas fa-pen me-1"></i>Change</div>
                            </div>
                            <button type="button" class="btn btn-sm btn-link text-danger p-0 mt-1 tile-clear">
                                <i class="fas fa-trash-alt me-1"></i>Remove
                            </button>
                            <input type="file" class="src-gallery d-none" id="mother_aadhaar_image" name="mother_aadhaar_image" accept="image/jpeg,image/png">
                            <input type="file" class="src-camera d-none" accept="image/*" capture="environment">
                        </div>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Mother's Voter Card Image</label>
                        <div class="image-field field-stacked" data-crop="0">
                            <div class="image-tile tile-landscape" tabindex="0" role="button" aria-label="Add mother's voter card image">
                                <img class="tile-preview" src="" alt="Mother's voter card preview">
                                <div class="tile-placeholder">
                                    <i class="fas fa-camera"></i>
                                    Camera or gallery
                                </div>
                                <div class="tile-overlay"><i class="fas fa-pen me-1"></i>Change</div>
                            </div>
                            <button type="button" class="btn btn-sm btn-link text-danger p-0 mt-1 tile-clear">
                                <i class="fas fa-trash-alt me-1"></i>Remove
                            </button>
                            <input type="file" class="src-gallery d-none" id="mother_voter_image" name="mother_voter_image" accept="image/jpeg,image/png">
                            <input type="file" class="src-camera d-none" accept="image/*" capture="environment">
                        </div>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Mother's PAN Card Image</label>
                        <div class="image-field field-stacked" data-crop="0">
                            <div class="image-tile tile-landscape" tabindex="0" role="button" aria-label="Add mother's PAN card image">
                                <img class="tile-preview" src="" alt="Mother's PAN card preview">
                                <div class="tile-placeholder">
                                    <i class="fas fa-camera"></i>
                                    Camera or gallery
                                </div>
                                <div class="tile-overlay"><i class="fas fa-pen me-1"></i>Change</div>
                            </div>
                            <button type="button" class="btn btn-sm btn-link text-danger p-0 mt-1 tile-clear">
                                <i class="fas fa-trash-alt me-1"></i>Remove
                            </button>
                            <input type="file" class="src-gallery d-none" id="mother_pan_image" name="mother_pan_image" accept="image/jpeg,image/png">
                            <input type="file" class="src-camera d-none" accept="image/*" capture="environment">
                        </div>
                    </div>

                    <!-- Student Documents Section (All Optional) -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-file-alt me-2"></i>Student Documents (Optional)
                        </h5>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Birth Certificate</label>
                        <div class="image-field field-stacked" data-crop="0">
                            <div class="image-tile tile-landscape" tabindex="0" role="button" aria-label="Add birth certificate image">
                                <img class="tile-preview" src="" alt="Birth certificate preview">
                                <div class="tile-placeholder">
                                    <i class="fas fa-camera"></i>
                                    Camera or gallery
                                </div>
                                <div class="tile-overlay"><i class="fas fa-pen me-1"></i>Change</div>
                            </div>
                            <button type="button" class="btn btn-sm btn-link text-danger p-0 mt-1 tile-clear">
                                <i class="fas fa-trash-alt me-1"></i>Remove
                            </button>
                            <input type="file" class="src-gallery d-none" id="student_birth_certificate" name="student_birth_certificate" accept="image/jpeg,image/png">
                            <input type="file" class="src-camera d-none" accept="image/*" capture="environment">
                        </div>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Aadhaar Card Image</label>
                        <div class="image-field field-stacked" data-crop="0">
                            <div class="image-tile tile-landscape" tabindex="0" role="button" aria-label="Add student's Aadhaar card image">
                                <img class="tile-preview" src="" alt="Student's Aadhaar card preview">
                                <div class="tile-placeholder">
                                    <i class="fas fa-camera"></i>
                                    Camera or gallery
                                </div>
                                <div class="tile-overlay"><i class="fas fa-pen me-1"></i>Change</div>
                            </div>
                            <button type="button" class="btn btn-sm btn-link text-danger p-0 mt-1 tile-clear">
                                <i class="fas fa-trash-alt me-1"></i>Remove
                            </button>
                            <input type="file" class="src-gallery d-none" id="student_aadhaar_image" name="student_aadhaar_image" accept="image/jpeg,image/png">
                            <input type="file" class="src-camera d-none" accept="image/*" capture="environment">
                        </div>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Previous School's Transfer Certificate</label>
                        <div class="image-field field-stacked" data-crop="0">
                            <div class="image-tile tile-landscape" tabindex="0" role="button" aria-label="Add transfer certificate image">
                                <img class="tile-preview" src="" alt="Transfer certificate preview">
                                <div class="tile-placeholder">
                                    <i class="fas fa-camera"></i>
                                    Camera or gallery
                                </div>
                                <div class="tile-overlay"><i class="fas fa-pen me-1"></i>Change</div>
                            </div>
                            <button type="button" class="btn btn-sm btn-link text-danger p-0 mt-1 tile-clear">
                                <i class="fas fa-trash-alt me-1"></i>Remove
                            </button>
                            <input type="file" class="src-gallery d-none" id="student_transfer_certificate" name="student_transfer_certificate" accept="image/jpeg,image/png">
                            <input type="file" class="src-camera d-none" accept="image/*" capture="environment">
                        </div>
                    </div>
                </div>

                <div class="mt-4 text-center">
                    <button type="submit" class="btn btn-primary px-4 py-2">
                        <i class="fas fa-plus-circle me-2"></i> Add Student
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Shared Camera / Gallery source picker (one instance serves every image field) -->
<div id="photoSourceMenu" class="photo-source-menu">
    <button type="button" class="photo-source-camera"><i class="fas fa-camera"></i> Camera</button>
    <div class="photo-source-divider"></div>
    <button type="button" class="photo-source-gallery"><i class="fas fa-image"></i> Gallery</button>
</div>

<!-- Shared cropper modal, reused by the student / father / mother photo fields -->
<div class="modal fade" id="cropModal" tabindex="-1" aria-labelledby="cropModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cropModalLabel">Crop Photo (5:6 ratio required)</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <div class="img-container">
                    <img id="imageToCrop" src="" alt="Image to crop">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="cropImageBtn">
                    <i class="fas fa-crop-simple me-1"></i> Crop &amp; Save
                </button>
            </div>
        </div>
    </div>
</div>

<script>
    
    function updateSectionDropdown() {
        const sectionsByClass = <?= json_encode($sections_by_class) ?>;
        let classId = $('#class_id').val();
         $('#section_id').html('<option value="" disabled selected>Select Section</option>');

        if (sectionsByClass[classId]) {
            sectionsByClass[classId].forEach(section => {
                $('#section_id').append(`<option value="${section.id}">${section.section_name}</option>`);
            });
        }
    }

    // Document ready
    $(document).ready(function() {

        // Show or hide inputbox accordingly
        $('input[name="is_hosteler"]').on('change', function() {
            var selectedValue = $(this).val();

            if (selectedValue === "1") {
                $('#hostel_fee').parent().show();
            } else {
                $('#hostel_fee').parent().hide();
                $('#hostel_fee').val("");
            }
        });

        // Action when driving route is changed
        $('#uses_school_car').on('change', function() {
            if ($('#uses_school_car').val().trim() == "no") {
                $('.car_items').hide();
                $('#car_fee').val("");
                $('#driver').val('').trigger('change');
            } else {
                $('.car_items').show();
            }
        });

        // Action when driver selected
        $('#driver').on('change', function() {
            let driverId = $(this).val();
            if (driverId !== "") {
                let routes = <?= json_encode($routes) ?>;
                let allDrivers = <?= json_encode($drivers) ?>;
                let driverRoutes = allDrivers.find(driver => driver.id == driverId).route_ids;
                let options = '<option value="" disabled selected>Select Route</option>';

                if (!driverRoutes || driverRoutes.trim() === "" || driverRoutes === "null") {
                    options = '<option value="" disabled selected>No routes available for this driver</option>';
                    $('#driving_route').html(options);
                    return;
                }

                driverRoutes = JSON.parse(driverRoutes);

                driverRoutes.forEach(routeId => {
                    let routeName = routes.find(route => route.id == routeId).route_name;
                    options += `<option value="${routeId}">${routeName}</option>`;
                });

                $('#driving_route').html(options);
            }
        });

        // AJAX form submission
        $('#addStudentForm').submit(function(e) {
            e.preventDefault();

            const formData = new FormData(this);

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/put/student/process-add-student.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                beforeSend: function() {
                    // Show loading state
                    $('button[type="submit"]').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i> Processing...');
                },
                success: function(response) {

                    $('button[type="submit"]').prop('disabled', false).html('<i class="fas fa-plus-circle me-2"></i> Add Student');

                    // First check if response is already parsed
                    if (typeof response === 'string') {
                        try {
                            response = JSON.parse(response);
                        } catch (e) {
                            console.error("Failed to parse response:", response);
                            toastr.error("Invalid server response");
                            return;
                        }
                    }

                    if (response.success) {
                        toastr.success(response.message || 'Student added successfully!');
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message || 'Student added successfully!',
                            confirmButtonText: 'OK',
                            allowOutsideClick: false,
                            customClass: {
                                confirmButton: 'btn btn-primary',
                                popup: 'rounded-4 shadow-lg'
                            },
                            allowEscapeKey: false
                        }).then(() => {
                            // Reset form after OK click
                            $('#addStudentForm')[0].reset();
                            $('#section_id').html('<option value="" disabled selected>Select Section</option>');
                            // Clears previews, tile state, file inputs and base64 fields
                            resetAllImageFields();
                        });
                    } else {
                        toastr.error(response.message || 'Operation failed');
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: response.message || 'Operation failed',
                            customClass: {
                                confirmButton: 'btn btn-danger',
                                popup: 'rounded-4 shadow-lg'
                            },
                            confirmButtonText: 'OK'
                        });
                    }
                },
                error: function(xhr, status, error) {
                    $('button[type="submit"]').prop('disabled', false).html('<i class="fas fa-plus-circle me-2"></i> Add Student');

                    console.error("AJAX Error:", status, error, xhr.responseText);
                    try {
                        const response = JSON.parse(xhr.responseText);
                        toastr.error(response.message || 'An error occurred');
                    } catch (e) {
                        toastr.error('An error occurred. Please check console for details.');
                    }
                }
            });
        });
    });

    // ---------------------------------------------------------------------
    // Image fields: Camera / Gallery source picker + shared 5:6 cropper
    //
    // Every image field is an .image-field wrapper holding two file inputs:
    //   .src-gallery - carries the name= that the backend reads from $_FILES
    //   .src-camera  - capture="environment", deliberately unnamed so it is
    //                  never submitted; it is only a capture source
    // Whichever source the user picks from, the resulting file is copied into
    // .src-gallery, so the server side keeps working exactly as before.
    //
    // Fields marked data-crop="1" (student / father / mother photos) also hold
    // a .cropped-data hidden input and route the picked image through the
    // shared cropper, which stores a base64 copy the backend prefers.
    // Document fields (data-crop="0") skip cropping and just preview.
    // ---------------------------------------------------------------------
    (function initImageFields() {
        const $sourceMenu = $('#photoSourceMenu');
        const cropModalEl = document.getElementById('cropModal');
        const cropModal = new bootstrap.Modal(cropModalEl);
        const imageToCrop = document.getElementById('imageToCrop');

        let $activeField = null; // field whose tile was last activated
        let cropper = null;
        let pickedFileName = 'photo.jpg';

        // ---- tile state -------------------------------------------------
        function showPreview($field, url) {
            const previous = $field.data('previewUrl');
            if (previous) URL.revokeObjectURL(previous);
            $field.data('previewUrl', url);

            $field.find('.tile-preview').attr('src', url);
            $field.find('.image-tile').addClass('has-image');
            $field.find('.tile-clear').css('display', 'inline-block');
        }

        function clearField($field) {
            const previous = $field.data('previewUrl');
            if (previous) URL.revokeObjectURL(previous);
            $field.removeData('previewUrl');

            $field.find('.tile-preview').attr('src', '');
            $field.find('.image-tile').removeClass('has-image');
            $field.find('.tile-clear').hide();
            $field.find('.src-gallery, .src-camera').val('');
            $field.find('.cropped-data').val('');
        }

        // Copy a File into the named input so it still arrives in $_FILES
        function assignToNamedInput($field, file) {
            try {
                const dt = new DataTransfer();
                dt.items.add(file);
                $field.find('.src-gallery')[0].files = dt.files;
            } catch (err) {
                // Older browsers without DataTransfer: photos still travel as
                // base64 in .cropped-data, so only documents would be affected.
                console.warn('Could not attach the file to the form input:', err);
            }
        }

        // ---- Camera / Gallery popup -------------------------------------
        function openSourceMenu($tile) {
            $activeField = $tile.closest('.image-field');

            const offset = $tile.offset();
            const menuWidth = $sourceMenu.outerWidth() || 150;
            const maxLeft = $(window).width() - menuWidth - 12;

            $sourceMenu.css({
                top: offset.top + $tile.outerHeight() + 6,
                left: Math.max(12, Math.min(offset.left, maxLeft))
            }).show();
        }

        // Bound directly (not delegated) so stopPropagation actually keeps the
        // document-level close handler from firing on the same click.
        $('.image-tile').on('click', function(e) {
            e.stopPropagation();
            openSourceMenu($(this));
        });

        // The tiles are focusable, so keyboard users get the same picker
        $('.image-tile').on('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ' || e.key === 'Spacebar') {
                e.preventDefault();
                e.stopPropagation();
                openSourceMenu($(this));
            }
        });

        $sourceMenu.on('click', function(e) {
            e.stopPropagation();
        });

        $(document).on('click', function() {
            $sourceMenu.hide();
        });

        $(document).on('keydown', function(e) {
            if (e.key === 'Escape') $sourceMenu.hide();
        });

        $sourceMenu.find('.photo-source-camera').on('click', function() {
            $sourceMenu.hide();
            // Native click: guarantees the file dialog opens inside the gesture
            if ($activeField) $activeField.find('.src-camera')[0].click();
        });

        $sourceMenu.find('.photo-source-gallery').on('click', function() {
            $sourceMenu.hide();
            if ($activeField) $activeField.find('.src-gallery')[0].click();
        });

        // ---- a file arrived from either source ---------------------------
        $('.src-gallery, .src-camera').on('change', function() {
            const file = this.files && this.files[0];
            if (!file) return;

            const $field = $(this).closest('.image-field');
            $activeField = $field;

            if (!file.type || file.type.indexOf('image/') !== 0) {
                toastr.error('Please choose an image file.');
                this.value = '';
                return;
            }

            pickedFileName = file.name || 'photo.jpg';

            // Documents: preview only, no cropping
            if (String($field.data('crop')) !== '1') {
                if ($(this).hasClass('src-camera')) {
                    assignToNamedInput($field, file);
                    this.value = ''; // release the camera input
                }
                showPreview($field, URL.createObjectURL(file));
                return;
            }

            // Photos: hand off to the shared 5:6 cropper
            const reader = new FileReader();
            reader.onload = function(event) {
                $('#cropModalLabel').text($field.data('crop-title') || 'Crop Photo (5:6 ratio required)');
                imageToCrop.src = event.target.result;
                cropModal.show();
            };
            reader.readAsDataURL(file);
        });

        // ---- cropper lifecycle ------------------------------------------
        $(cropModalEl).on('shown.bs.modal', function() {
            if (cropper) cropper.destroy();
            cropper = new Cropper(imageToCrop, {
                aspectRatio: 5 / 6,
                viewMode: 1,
                autoCropArea: 0.8,
                responsive: true,
                restore: false,
                guides: true,
                center: true,
                highlight: false,
                cropBoxMovable: true,
                cropBoxResizable: true,
                toggleDragModeOnDblclick: false
            });
        });

        $('#cropImageBtn').on('click', function() {
            if (!cropper || !$activeField) return;

            const canvas = cropper.getCroppedCanvas({
                width: 500,
                height: 600,
                fillColor: '#fff',
                imageSmoothingEnabled: true,
                imageSmoothingQuality: 'high'
            });
            if (!canvas) return;

            const $field = $activeField;
            const fileName = pickedFileName;

            canvas.toBlob(function(blob) {
                if (!blob) return;

                assignToNamedInput($field, new File([blob], fileName, {
                    type: 'image/jpeg',
                    lastModified: Date.now()
                }));

                // The camera input has done its job - clear it so it never submits
                $field.find('.src-camera').val('');

                $field.find('.cropped-data').val(canvas.toDataURL('image/jpeg', 0.9));
                showPreview($field, URL.createObjectURL(blob));

                cropModal.hide();
            }, 'image/jpeg', 0.9);
        });

        $(cropModalEl).on('hidden.bs.modal', function() {
            if (cropper) {
                cropper.destroy();
                cropper = null;
            }
            imageToCrop.src = '';

            // Closed without cropping: drop the raw pick so a half-finished
            // selection cannot be submitted. An earlier crop is left untouched.
            if ($activeField && !$activeField.find('.cropped-data').val()) {
                $activeField.find('.src-gallery, .src-camera').val('');
            }
        });

        // ---- remove ------------------------------------------------------
        $('.tile-clear').on('click', function(e) {
            e.stopPropagation();
            clearField($(this).closest('.image-field'));
        });

        // Reused by the reset path after a student is saved successfully
        window.resetAllImageFields = function() {
            $('.image-field').each(function() {
                clearField($(this));
            });
        };
    })();
</script>

<?php include_once("../../includes/body-close.php"); ?>