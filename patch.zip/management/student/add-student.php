<?php
/** @var string $school_name */
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Add New Student - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    include_once("../../includes/permission-denied.php");
}

// Fetch all classes
$classes = $pdo->query("SELECT * FROM classes")->fetchAll(PDO::FETCH_ASSOC);

// Fetch all sections grouped by class_id
$sections_stmt = $pdo->query("SELECT * FROM sections ORDER BY section_name");
$sections_by_class = [];
while ($section = $sections_stmt->fetch(PDO::FETCH_ASSOC)) {
    $sections_by_class[$section['class_id']][] = $section;
}

// Blood group options
$blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

// Religions
$religions = [
    'islam',
    'hindu',
    'christian',
    'buddhist',
    'jain',
    'sikh',
    'parsi',
    'judaism',
    'bahai',
    'atheist',
    'agnostic',
    'other'
];

// Get all driving routes for the car route dropdown.
$routes = $pdo->query("SELECT id, route_name FROM driving_routes ORDER BY route_name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Get all drivers
$drivers = $pdo->query("SELECT * FROM drivers WHERE status = 'active' ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Detect admission type. Default value (new-admission)
$admission_type = 'new-admission';
if (!empty($_REQUEST['admission-type']) && strtolower(trim($_REQUEST['admission-type'])) === 're-admission') {
    $admission_type = 're-admission';
}
?>

<style>
    /* Cropper modal styles */
    .modal-xl {
        max-width: 50%;
    }

    .img-container {
        overflow: hidden;
        margin: 0 auto;
    }

    .cropper-container {
        width: 100% !important;
        height: 100% !important;
    }

    .cropper-modal {
        background-color: rgba(255, 255, 255, 0.8);
    }

    .cropper-view-box {
        outline: 2px solid #007bff;
        outline-color: rgba(0, 123, 255, 0.75);
    }
</style>

<div class="container mt-4 mb-5">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0"><i class="fas fa-user-plus me-2"></i> <?= ($admission_type == 're-admission') ? 'Re-Admission' : 'New Admission' ?></h4>
        </div>

        <div class="card-body">
            <form id="addStudentForm" method="post" action="../../api/admin/put/student/process-add-student.php" enctype="multipart/form-data">

                <input type="hidden" name="admission_type" value="<?= $admission_type ?>" required />

                <div class="row g-3">
                    <!-- Personal Information Section -->
                    <div class="col-md-12">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-user-circle me-2"></i>Student Information
                        </h5>
                    </div>

                    <div class="col-md-4">
                        <label for="name" class="form-label">Full Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="name" name="name" required placeholder="John Doe">
                    </div>

                    <div class="col-md-4">
                        <label for="gender" class="form-label">Gender <span class="text-danger">*</span></label>
                        <select class="form-select" id="gender" name="gender" required>
                            <option value="" selected disabled>Select Gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="date_of_birth" class="form-label">Date of Birth <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" required>
                    </div>

                    <div class="col-md-4">
                        <label for="blood_group" class="form-label">Blood Group</label>
                        <select class="form-select" id="blood_group" name="blood_group">
                            <option value="" selected disabled>Select Blood Group</option>
                            <?php foreach ($blood_groups as $group): ?>
                                <option value="<?= $group ?>"><?= $group ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="religion" class="form-label">Religion</label>
                        <select class="form-select" id="religion" name="religion">
                            <option value="" selected>Select Religion</option>
                            <?php foreach ($religions as $religion): ?>
                                <option value="<?= $religion ?>"><?= ucwords($religion) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="student_adhaar" class="form-label">Student's Adhaar No.</label>
                        <input type="text" class="form-control" id="student_adhaar" name="student_adhaar" placeholder="Enter student adhaar number"/>
                    </div>

                    <!-- Family Information Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-users me-2"></i>Family Information
                        </h5>
                    </div>

                    <div class="col-md-6">
                        <label for="father_name" class="form-label">Father's Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="father_name" name="father_name" required placeholder="Father's name">
                    </div>

                    <div class="col-md-6">
                        <label for="mother_name" class="form-label">Mother's Name</label>
                        <input type="text" class="form-control" id="mother_name" name="mother_name" placeholder="Mother's name">
                    </div>

                    <div class="col-md-6">
                        <label for="father_occupation" class="form-label">Father's Occupation</label>
                        <input type="text" class="form-control" id="father_occupation" name="father_occupation" placeholder="Occupation">
                    </div>

                    <div class="col-md-6">
                        <label for="mother_occupation" class="form-label">Mother's Occupation</label>
                        <input type="text" class="form-control" id="mother_occupation" name="mother_occupation" placeholder="Occupation">
                    </div>

                    <div class="col-md-6">
                        <label for="father_adhaar" class="form-label">Father's Adhaar No.</label>
                        <input type="text" class="form-control" id="father_adhaar" name="father_adhaar" placeholder="Enter father adhaar number"/>
                    </div>

                    <div class="col-md-6">
                        <label for="mother_adhaar" class="form-label">Mother's Adhaar No.</label>
                        <input type="text" class="form-control" id="mother_adhaar" name="mother_adhaar" placeholder="Enter mother adhaar number"/>
                    </div>

                    <div class="col-md-4">
                        <label for="phone_number" class="form-label">Father's Phone Number <span class="text-danger"> *</span>
                            <i title="This phone number will be used as primary phone number. OTPs will be sent to this number. Enter phone number without country code." class="fa-solid fa-circle-question"></i>
                        </label>
                        <input type="tel" class="form-control" id="phone_number" name="phone_number" required placeholder="1234567890">
                    </div>

                    <div class="col-md-4">
                        <label for="alternate_phone_number" class="form-label">Mother's Phone Number
                            <i title="This phone number will be used as alternate phone number if primary number is not reachable. Enter phone number without country code." class="fa-solid fa-circle-question"></i>
                        </label>
                        <input type="tel" class="form-control" id="alternate_phone_number" name="alternate_phone_number" placeholder="1234567890">
                    </div>

                    <div class="col-md-4">
                        <label for="email" class="form-label">Email Id</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="example@example.com">
                    </div>

                    <!-- Address Information Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-location-dot me-2"></i>Address
                        </h5>
                    </div>

                    <div class="col-md-4">
                        <label for="village" class="form-label">Village/Town</label>
                        <input type="text" class="form-control" id="village" name="village" placeholder="Enter village or town name">
                    </div>

                    <div class="col-md-4">
                        <label for="post_office" class="form-label">Post Office</label>
                        <input type="text" class="form-control" id="post_office" name="post_office" placeholder="Enter post office">
                    </div>

                    <div class="col-md-4">
                        <label for="police_station" class="form-label">Police Station</label>
                        <input type="text" class="form-control" id="police_station" name="police_station" placeholder="Enter police station">
                    </div>

                    <div class="col-md-4">
                        <label for="district" class="form-label">District</label>
                        <input type="text" class="form-control" id="district" name="district" placeholder="Enter district name">
                    </div>

                    <div class="col-md-4">
                        <label for="pin_code" class="form-label">Pin Code</label>
                        <input type="text" class="form-control" id="pin_code" name="pin_code" placeholder="Enter pin code">
                    </div>

                    <!-- Academic Information Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-graduation-cap me-2"></i>Academic Information
                        </h5>
                    </div>

                    <div class="col-md-4">
                        <label for="registration_no" class="form-label">Registration No</label>
                        <input type="text" class="form-control" id="registration_no" name="registration_no">
                    </div>

                    <div class="col-md-4">
                        <label for="class_id" class="form-label">Class <span class="text-danger">*</span></label>
                        <select class="form-select" id="class_id" name="class_id" required onchange="updateSectionDropdown()">
                            <option value="" selected disabled>Select Class</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?= $class['id'] ?>"><?= htmlspecialchars($class['class_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="section_id" class="form-label">Section</label>
                        <select class="form-select" id="section_id" name="section_id">
                            <option value="" selected>Select Section</option>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="roll_no" class="form-label">Roll No</label>
                        <input type="number" class="form-control" id="roll_no" name="roll_no" placeholder="Roll number">
                    </div>

                    <div class="col-md-4">
                        <label for="admission_date" class="form-label">Admission Date <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" id="admission_date" name="admission_date" required>
                    </div>

                    <div class="col-md-4">
                        <label for="academic_year" class="form-label">Academic Year <span class="text-danger">*</span></label>
                        <select class="form-control" id="academic_year" name="academic_year" required>
                            <?php
                            $current_year = date('Y');
                            for ($year = $current_year - 1; $year <= $current_year + 2; $year++) {
                                $selected = ($year == $current_year + 0) ? 'selected' : '';
                                echo "<option value='$year' $selected>$year</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <!-- Additional Information Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-info-circle me-2"></i>Additional Information
                        </h5>
                    </div>

                    <div class="col-md-4">
                        <label for="admission_fee_discount" class="form-label">Admission Fee Discount</label>
                        <input type="number" class="form-control" id="admission_fee_discount" name="admission_fee_discount" placeholder="Admission fee discount if applicable">
                    </div>

                    <div class="col-md-4 ">
                        <label class="form-label">Hosteler</label>
                        <div class="d-flex align-items-center">
                            <div class="form-check me-3">
                                <input class="form-check-input" type="radio" name="is_hosteler" id="hosteler_yes" value="1">
                                <label class="form-check-label" for="hosteler_yes">Yes</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="is_hosteler" id="hosteler_no" value="0" checked>
                                <label class="form-check-label" for="hosteler_no">No</label>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4" style="display: none;">
                        <label for="hostel_fee" class="form-label">Hostel Fee</label>
                        <input type="number" class="form-control" id="hostel_fee" name="hostel_fee" placeholder="Hostel fees amount">
                    </div>

                    <div class="col-md-4">
                        <label for="custom_class_fee" class="form-label">Custom School Fee</label>
                        <input type="number" class="form-control" id="custom_class_fee" name="custom_class_fee" placeholder="Custom school fees if applicable">
                    </div>

                    <div class="col-md-4 ">
                        <label class="form-label">Uses School Car</label>
                        <select class="form-select" id="uses_school_car">
                            <option value="yes">Yes</option>
                            <option value="no" selected>No</option>
                        </select>
                    </div>

                    <div class="col-md-4 car_items" style="display: none;">
                        <label for="driver" class="form-label">Driver</label>
                        <select class="form-select select2" id="driver" name="driver_id">
                            <option value="" selected>Select Driver</option>
                            <?php foreach ($drivers as $driver): ?>
                                <option value="<?= $driver['id'] ?>"><?= safe_htmlspecialchars($driver['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4 car_items" style="display: none;">
                        <label for="driving_route" class="form-label">Driving Route</label>
                        <select class="form-select select2" id="driving_route" name="driving_route">
                            <option value="" selected>Select Driving Route</option>
                        </select>
                    </div>

                    <div class="col-md-4 car_items" style="display: none;">
                        <label for="car_fee" class="form-label">Car Fee</label>
                        <input type="number" class="form-control" id="car_fee" name="car_fee" placeholder="Car fees amount">
                    </div>

                    <div class="col-md-4">
                        <label for="coaching_fee" class="form-label">Coaching Fee</label>
                        <input type="number" class="form-control" id="coaching_fee" name="coaching_fee" placeholder="Coaching fee if applicable">
                    </div>

                    <div class="col-md-4">
                        <label for="tiffin_fee" class="form-label">Tiffin Fee</label>
                        <input type="number" class="form-control" id="tiffin_fee" name="tiffin_fee" placeholder="Tiffin fee if applicable">
                    </div>

                    <!-- Additional Information Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-info-circle me-2"></i>Extra Options
                        </h5>
                    </div>

                    <div class="col-md-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="auto_include_admission_fee" name="auto_include_admission_fee">
                            <label class="form-check-label" for="auto_include_admission_fee">
                                Auto include admission fee
                            </label>
                        </div>
                    </div>

                    <!-- Photo Upload Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-camera me-2"></i>Student Photo
                        </h5>
                    </div>

                    <div class="col-md-6">
                        <label for="student_image" class="form-label">Passport Photo (5:6 Ratio)</label>
                        <input type="file" class="form-control" id="student_image" name="student_image" accept="image/*">
                        <small class="text-muted">Please upload a photo with recommended dimensions of 500×600 pixels</small>
                        <!-- Hidden input to store cropped image data -->
                        <input type="hidden" id="cropped_image_data" name="cropped_image_data">
                    </div>

                    <div class="col-md-6">
                        <div class="image-preview-container">
                            <img id="imagePreview" src="#" alt="Image Preview" style="display: none; max-width: 150px; max-height: 180px; border: 1px solid #ddd; padding: 5px;">
                        </div>
                    </div>

                    <!-- Cropping Modal -->
                    <div class="modal fade" id="cropModal" tabindex="-1" aria-labelledby="cropModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-xl"> <!-- Changed to modal-xl for larger size -->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="cropModalLabel">Crop Student Photo</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body p-0"> <!-- Added p-0 to remove padding -->
                                    <div class="img-container" style="width: 100%; height: 70vh;"> <!-- Set fixed height -->
                                        <img id="imageToCrop" src="#" alt="Image to crop" style="max-width: 100%; max-height: 100%; display: block;">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    <button type="button" class="btn btn-primary" id="cropImageBtn">Crop & Save</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="mt-4 text-center">
                    <button type="submit" class="btn btn-primary px-4 py-2">
                        <i class="fas fa-plus-circle me-2"></i> Add Student
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    
    function updateSectionDropdown() {
        const sectionsByClass = <?= json_encode($sections_by_class) ?>;
        let classId = $('#class_id').val();
         $('#section_id').html('<option value="" disabled selected>Select Section</option>');

        if (sectionsByClass[classId]) {
            sectionsByClass[classId].forEach(section => {
                $('#section_id').append(`<option value="${section.id}">${section.section_name}</option>`);
            });
        }
    }

    // Image preview functionality
    $('#student_image').on('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(event) {
                const img = $('#imagePreview');
                img.src = event.target.result;
                img.style.display = 'block';

                // Check image dimensions
                const image = new Image();
                image.onload = function() {
                    if (this.width !== 500 || this.height !== 600) {
                        console.error('Image dimensions are not 500x600 and recommended dimensions are 500x600. Current dimensions:', this.width, 'x', this.height);
                    }
                };
                image.src = event.target.result;
            };
            reader.readAsDataURL(file);
        }
    });

    // Document ready
    $(document).ready(function() {

        // Show or hide inputbox accordingly
        $('input[name="is_hosteler"]').on('change', function() {
            var selectedValue = $(this).val();

            if (selectedValue === "1") {
                $('#hostel_fee').parent().show();
            } else {
                $('#hostel_fee').parent().hide();
                $('#hostel_fee').val("");
            }
        });

        // Action when driving route is changed
        $('#uses_school_car').on('change', function() {
            if ($('#uses_school_car').val().trim() == "no") {
                $('.car_items').hide();
                $('#car_fee').val("");
                $('#driver').val('').trigger('change');
            } else {
                $('.car_items').show();
            }
        });

        // Action when driver selected
        $('#driver').on('change', function() {
            let driverId = $(this).val();
            if (driverId !== "") {
                let routes = <?= json_encode($routes) ?>;
                let allDrivers = <?= json_encode($drivers) ?>;
                let driverRoutes = allDrivers.find(driver => driver.id == driverId).route_ids;
                let options = '<option value="" disabled selected>Select Route</option>';

                if (!driverRoutes || driverRoutes.trim() === "" || driverRoutes === "null") {
                    options = '<option value="" disabled selected>No routes available for this driver</option>';
                    $('#driving_route').html(options);
                    return;
                }

                driverRoutes = JSON.parse(driverRoutes);

                driverRoutes.forEach(routeId => {
                    let routeName = routes.find(route => route.id == routeId).route_name;
                    options += `<option value="${routeId}">${routeName}</option>`;
                });

                $('#driving_route').html(options);
            }
        });

        // AJAX form submission
        $('#addStudentForm').submit(function(e) {
            e.preventDefault();

            const formData = new FormData(this);

            $.ajax({
                url: '../../api/admin/put/student/process-add-student.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                beforeSend: function() {
                    // Show loading state
                    $('button[type="submit"]').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i> Processing...');
                },
                success: function(response) {

                    $('button[type="submit"]').prop('disabled', false).html('<i class="fas fa-plus-circle me-2"></i> Add Student');

                    // First check if response is already parsed
                    if (typeof response === 'string') {
                        try {
                            response = JSON.parse(response);
                        } catch (e) {
                            console.error("Failed to parse response:", response);
                            toastr.error("Invalid server response");
                            return;
                        }
                    }

                    if (response.success) {
                        toastr.success(response.message || 'Student added successfully!');
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message || 'Student added successfully!',
                            confirmButtonText: 'OK',
                            allowOutsideClick: false,
                            customClass: {
                                confirmButton: 'btn btn-primary',
                                popup: 'rounded-4 shadow-lg'
                            },
                            allowEscapeKey: false
                        }).then(() => {
                            // Reset form after OK click
                            $('#addStudentForm')[0].reset();
                            $('#imagePreview').hide();
                            $('#section_id').html('<option value="" disabled selected>Select Section</option>');
                            $('#cropped_image_data').val("");
                        });
                    } else {
                        toastr.error(response.message || 'Operation failed');
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: response.message || 'Operation failed',
                            customClass: {
                                confirmButton: 'btn btn-danger',
                                popup: 'rounded-4 shadow-lg'
                            },
                            confirmButtonText: 'OK'
                        });
                    }
                },
                error: function(xhr, status, error) {
                    $('button[type="submit"]').prop('disabled', false).html('<i class="fas fa-plus-circle me-2"></i> Add Student');

                    console.error("AJAX Error:", status, error, xhr.responseText);
                    try {
                        const response = JSON.parse(xhr.responseText);
                        toastr.error(response.message || 'An error occurred');
                    } catch (e) {
                        toastr.error('An error occurred. Please check console for details.');
                    }
                }
            });
        });
    });

    // Image cropping functionality
    // Initialize cropper when modal is shown
    let cropper;
    const imageToCrop = document.getElementById('imageToCrop');
    const cropModal = new bootstrap.Modal(document.getElementById('cropModal'));

    $('#student_image').on('change', function(e) {
        const files = e.target.files;
        if (files && files.length > 0) {
            const file = files[0];
            const reader = new FileReader();

            reader.onload = function(event) {
                // Show the cropping modal
                imageToCrop.src = event.target.result;
                cropModal.show();

                // Initialize cropper after image is loaded
                imageToCrop.onload = function() {
                    if (cropper) {
                        cropper.destroy();
                    }

                    cropper = new Cropper(imageToCrop, {
                        aspectRatio: 5 / 6,
                        viewMode: 1, // Ensure the crop box doesn't exceed the image
                        autoCropArea: 0.8, // Automatically select 80% of the image
                        responsive: true,
                        restore: false,
                        guides: false,
                        center: false,
                        highlight: false,
                        cropBoxMovable: true,
                        cropBoxResizable: true,
                        toggleDragModeOnDblclick: false,
                        minContainerWidth: 800,
                        minContainerHeight: 600,
                        ready: function() {
                            // Fit the image to the container when ready
                            this.cropper.setCropBoxData({
                                width: 500,
                                height: 600
                            });
                        }
                    });
                };
            };
            reader.readAsDataURL(file);
        }
    });

    // Handle crop button click
    $('#cropImageBtn').on('click', function() {
        if (cropper) {
            // Get cropped canvas
            const canvas = cropper.getCroppedCanvas({
                width: 500,
                height: 600,
                minWidth: 500,
                minHeight: 600,
                maxWidth: 500,
                maxHeight: 600,
                fillColor: '#fff',
                imageSmoothingEnabled: true,
                imageSmoothingQuality: 'high',
            });

            if (canvas) {
                // Convert canvas to blob
                canvas.toBlob(function(blob) {
                    // Create a new File from the blob
                    const file = new File([blob], document.getElementById('student_image').files[0].name, {
                        type: 'image/jpeg',
                        lastModified: Date.now()
                    });

                    // Create a new DataTransfer to replace the file input
                    const dataTransfer = new DataTransfer();
                    dataTransfer.items.add(file);
                    document.getElementById('student_image').files = dataTransfer.files;

                    // Update preview
                    const img = document.getElementById('imagePreview');
                    img.src = URL.createObjectURL(blob);
                    img.style.display = 'block';

                    // Also store the base64 version for AJAX submission
                    const croppedImageData = canvas.toDataURL('image/jpeg');
                    document.getElementById('cropped_image_data').value = croppedImageData;

                    // Close the modal
                    cropModal.hide();

                    // Destroy cropper
                    cropper.destroy();
                    cropper = null;
                }, 'image/jpeg', 0.9);
            }
        }
    });

    // Clean up when modal is closed
    $('#cropModal').on('hidden.bs.modal', function() {
        if (cropper) {
            cropper.destroy();
            cropper = null;
        }
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>