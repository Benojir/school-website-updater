<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/academic/fun-academic-functions.php");

echo "<pre>";
print_r(getTopRankersForSingleMarksheet($pdo, 29, 12, false, null, 5000));
echo "\n\n";
echo getOrdinal(getStudentPositionInClass($pdo, 12, 29, "STU20253359", false, 62));
echo "</pre>";