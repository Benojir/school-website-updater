<?php
ini_set('memory_limit', '512M');
include_once(__DIR__ . "/../../includes/auth-check.php");
include_once("../../includes/header-open.php");
/**@var string $school_name */
echo "<title>Bulk Import Students - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    include_once("../../includes/permission-denied.php");
    exit();
}

require_once '../../../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

// Initialize response variable
$response = null;

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['student_file'])) {
    $response = processBulkImport($_FILES['student_file'], $pdo);
}

// Fetch all classes for validation
$classes = $pdo->query("SELECT id, class_name FROM classes")->fetchAll(PDO::FETCH_KEY_PAIR);
?>

<div class="container mt-4 mb-5">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0"><i class="fas fa-users me-2"></i> Bulk Import Students</h4>
        </div>

        <div class="card-body">
            <?php if ($response !== null): ?>
                <div class="alert alert-<?= $response['success'] ? 'success' : 'danger' ?>">
                    <?= safe_htmlspecialchars($response['message']) ?>
                    <?php if (!empty($response['errors'])): ?>
                        <ul class="mt-2 mb-0">
                            <?php foreach ($response['errors'] as $error): ?>
                                <li><?= safe_htmlspecialchars($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                    <?php if ($response['success'] && ($response['imported'] > 0 || $response['skipped'] > 0)): ?>
                        <div class="mt-2">
                            <strong>Summary:</strong>
                            <?= $response['imported'] ?> imported,
                            <?= $response['skipped'] ?> skipped
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-8">
                    <form id="bulkImportForm" method="post" enctype="multipart/form-data">
                        <div class="mb-4">
                            <label for="student_file" class="form-label">Select Excel File <span class="text-danger">*</span></label>
                            <div class="file-upload-wrapper">
                                <input type="file" class="form-control" id="student_file" name="student_file" accept=".xlsx,.xls" required>
                                <small class="text-muted">Only .xlsx or .xls files are allowed</small>
                            </div>
                        </div>

                        <div class="mb-4">
                            <h5 class="text-primary">File Requirements:</h5>
                            <ul>
                                <li>File must be in Excel format (.xlsx or .xls)</li>
                                <li><strong>Required columns:</strong> Name, Class, Admission Date</li>
                                <li><strong>Optional columns:</strong> Father Name, Mother Name, Date Of Birth, Gender, Phone Number, Alternate Phone Number, Roll Number, Section, Address, Landmark, Car Route, Car Fee, Custom Class Fee, Hostel Fee, Registration No, Religion</li>
                                <li>Any optional column left blank will simply be saved as empty for that student</li>
                                <li>Class names must match existing classes in the system</li>
                                <li>Section is matched against the section list for that student's Class (e.g. A, B, C). If it doesn't match, the student is still imported with no section set</li>
                                <li>Gender, if provided, must be one of: Male, Female, Other</li>
                                <li>Dates, if provided, should be in DD/MM/YYYY or YYYY-MM-DD format</li>
                                <li>Car Fee, Custom Class Fee, and Hostel Fee must be numeric values (integers or decimals)</li>
                                <li>If Hostel Fee is greater than 0, student will be marked as hosteler automatically</li>
                                <li><strong>Duplicate Check:</strong> Students with the same name and father name will be skipped</li>
                                <li>Any missing or invalid value other than Name or Class (Admission Date, Date of Birth, Gender, etc.) is imported as empty instead of skipping the student; invalid Car Fee, Custom Class Fee, or Hostel Fee is imported as 0</li>
                            </ul>
                        </div>

                        <div class="text-center">
                            <button type="submit" class="btn btn-primary px-4 py-2" id="submitBtn">
                                <i class="fas fa-upload me-2"></i> Upload & Import
                            </button>
                            <a href="../../assets/sample-files/Demo-Bulk-Students-Data.xlsx" class="btn btn-outline-secondary ms-2">
                                <i class="fas fa-download me-2"></i> Download Sample File
                            </a>
                        </div>
                    </form>
                </div>

                <div class="col-md-4">
                    <div class="card border-info">
                        <div class="card-header bg-info text-white">
                            <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i> Instructions</h5>
                        </div>
                        <div class="card-body">
                            <ol>
                                <li>Download the sample file to see the required format</li>
                                <li>Fill in student data keeping the column headers</li>
                                <li>Upload the completed file</li>
                                <li>Review any errors and correct your file if needed</li>
                                <li>Students will be added to their respective classes</li>
                            </ol>
                            <div class="alert alert-warning mt-3">
                                <strong>Important Notes:</strong>
                                <ul class="mb-0 mt-2">
                                    <li>Only Name and Class are mandatory - if either is missing, the student is skipped</li>
                                    <li>Any other missing or invalid value (Admission Date, Date of Birth, Gender, etc.) is imported as empty; invalid Car Fee, Custom Class Fee, or Hostel Fee is imported as 0</li>
                                    <li>Duplicate students (same name + father name) will be automatically skipped</li>
                                    <li>Phone numbers can repeat freely across students - no uniqueness check is applied</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#bulkImportForm').submit(function(e) {
            var fileInput = $('#student_file')[0];

            if (!fileInput.files.length) {
                toastr.error('Please select a file to upload.');
                e.preventDefault();
                return false;
            }

            var fileName = fileInput.files[0].name;
            var fileExt = fileName.split('.').pop().toLowerCase();

            if (!['xlsx', 'xls'].includes(fileExt)) {
                toastr.error('Please select a valid Excel file (.xlsx or .xls)');
                e.preventDefault();
                return false;
            }

            $('#submitBtn').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i> Processing...');
            return true;
        });
    });
</script>

<?php
include_once("../../includes/body-close.php");

function processBulkImport($file, $pdo)
{
    global $websiteConfig;

    $response = [
        'success' => false,
        'message' => '',
        'errors' => [],
        'imported' => 0,
        'skipped' => 0
    ];

    try {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $upload_errors = [
                UPLOAD_ERR_INI_SIZE => 'File is too large (exceeds upload_max_filesize)',
                UPLOAD_ERR_FORM_SIZE => 'File is too large (exceeds MAX_FILE_SIZE)',
                UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
                UPLOAD_ERR_NO_FILE => 'No file was uploaded',
                UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
                UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
                UPLOAD_ERR_EXTENSION => 'File upload stopped by extension'
            ];

            $error_msg = isset($upload_errors[$file['error']]) ? $upload_errors[$file['error']] : 'Unknown upload error';
            throw new Exception("File upload error: " . $error_msg);
        }

        $allowed_extensions = ['xlsx', 'xls'];
        $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if (!in_array($file_ext, $allowed_extensions)) {
            throw new Exception("Invalid file type. Only Excel files (.xlsx, .xls) are allowed.");
        }

        if ($file['size'] > 5 * 1024 * 1024) {
            throw new Exception("File is too large. Maximum file size is 5MB.");
        }

        try {
            $spreadsheet = IOFactory::load($file['tmp_name']);
        } catch (Exception $e) {
            throw new Exception("Failed to read Excel file. Please ensure it's a valid Excel file.");
        }

        $worksheet = $spreadsheet->getActiveSheet();
        $rows = $worksheet->toArray(null, true, true, true);

        if (count($rows) < 2) {
            throw new Exception("The Excel file appears to be empty or has no data rows.");
        }

        $header_row = array_shift($rows);
        $header = array_map(function ($cell) {
            return trim(strtolower($cell ?? ''));
        }, $header_row);

        $required_headers = ['name', 'class', 'admission date'];
        $missing_headers = [];

        foreach ($required_headers as $req_header) {
            if (!in_array($req_header, $header)) {
                $missing_headers[] = ucwords($req_header);
            }
        }

        if (!empty($missing_headers)) {
            throw new Exception("Missing required columns: " . implode(', ', $missing_headers));
        }

        $name_index = array_search('name', $header);
        $class_index = array_search('class', $header);
        $admission_index = array_search('admission date', $header);

        $father_index = array_search('father name', $header);
        $mother_index = array_search('mother name', $header);
        $dob_index = array_search('date of birth', $header);
        $gender_index = array_search('gender', $header);
        $phone_index = array_search('phone number', $header);
        $alt_phone_index = array_search('alternate phone number', $header);
        $roll_no_index = array_search('roll number', $header);
        $section_index = array_search('section', $header);
        $address_index = array_search('address', $header);
        $landmark_index = array_search('landmark', $header);
        $car_route_index = array_search('car route', $header);
        $car_fee_index = array_search('car fee', $header);
        $custom_class_fee_index = array_search('custom class fee', $header);
        $hostel_fee_index = array_search('hostel fee', $header);
        $registration_no_index = array_search('registration no', $header);
        $religion_index = array_search('religion', $header);

        $classes = $pdo->query("SELECT id, class_name FROM classes")->fetchAll(PDO::FETCH_KEY_PAIR);

        $sections_by_class = [];
        $section_rows = $pdo->query("SELECT id, class_id, section_name FROM sections")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($section_rows as $srow) {
            $sections_by_class[$srow['class_id']][strtolower(trim($srow['section_name']))] = $srow['id'];
        }

        $pdo->beginTransaction();

        $row_number = 1; 

        foreach ($rows as $row) {
            $row_number++;

            $row_values = array_values($row);
            if (empty(array_filter($row_values, function ($val) {
                return !empty(trim($val ?? ''));
            }))) {
                continue;
            }

            $name = trim($row[$name_index] ?? '');
            $class_name = trim($row[$class_index] ?? '');
            $admission_date = trim($row[$admission_index] ?? '');

            $father_name = ($father_index !== false) ? trim($row[$father_index] ?? '') : '';
            $mother_name = ($mother_index !== false) ? trim($row[$mother_index] ?? '') : '';
            $dob = ($dob_index !== false) ? trim($row[$dob_index] ?? '') : '';
            $gender = ($gender_index !== false) ? trim($row[$gender_index] ?? '') : '';
            $phone = ($phone_index !== false) ? trim($row[$phone_index] ?? '') : '';
            $alt_phone = ($alt_phone_index !== false) ? trim($row[$alt_phone_index] ?? '') : '';
            $roll_no = ($roll_no_index !== false) ? trim($row[$roll_no_index] ?? '') : '';
            $section_name = ($section_index !== false) ? trim($row[$section_index] ?? '') : '';
            $address = ($address_index !== false) ? trim($row[$address_index] ?? '') : '';
            $landmark = ($landmark_index !== false) ? trim($row[$landmark_index] ?? '') : '';
            $car_route = ($car_route_index !== false) ? trim($row[$car_route_index] ?? '') : '';
            $car_fee = ($car_fee_index !== false) ? trim($row[$car_fee_index] ?? '') : '';
            $custom_class_fee = ($custom_class_fee_index !== false) ? trim($row[$custom_class_fee_index] ?? '') : '';
            $hostel_fee = ($hostel_fee_index !== false) ? trim($row[$hostel_fee_index] ?? '') : '';
            $registration_no = ($registration_no_index !== false) ? trim($row[$registration_no_index] ?? '') : '';
            $religion = ($religion_index !== false) ? trim($row[$religion_index] ?? '') : '';

            $row_errors = [];   
            $row_warnings = []; 

            if (empty($name)) {
                $row_errors[] = "Row $row_number: Name is required";
            }

            if (!empty($dob)) {
                $dob_formatted = validateAndFormatDate($dob, "Row $row_number: Date of Birth");
                if ($dob_formatted === false) {
                    $row_warnings[] = "Row $row_number: Invalid Date of Birth format - imported as empty";
                    $dob_formatted = null;
                }
            } else {
                $dob_formatted = null;
            }

            if (!empty($name) && !empty($father_name)) {
                $stmt = $pdo->prepare("
                    SELECT COUNT(*) FROM students 
                    WHERE LOWER(TRIM(name)) = LOWER(TRIM(?)) 
                    AND LOWER(TRIM(father_name)) = LOWER(TRIM(?))
                ");
                $stmt->execute([$name, $father_name]);
                if ($stmt->fetchColumn() > 0) {
                    $row_errors[] = "Row $row_number: Student '$name' with father '$father_name' already exists in the database";
                }
            }

            $father_name = !empty($father_name) ? $father_name : null;
            $mother_name = !empty($mother_name) ? $mother_name : null;

            if (!empty($phone)) {
                $phone = preg_replace('/[^\d]/', '', $phone);
                if ($phone === '') {
                    $phone = null;
                }
            } else {
                $phone = null;
            }

            if (!empty($alt_phone)) {
                $alt_phone = preg_replace('/[^\d]/', '', $alt_phone);
                if ($alt_phone === '') {
                    $alt_phone = null;
                }
            } else {
                $alt_phone = null;
            }

            $valid_genders = ['male', 'female', 'other'];
            if (!empty($gender)) {
                if (!in_array(strtolower($gender), $valid_genders)) {
                    $row_warnings[] = "Row $row_number: Invalid Gender (must be Male, Female, or Other) - imported as empty";
                    $gender = null;
                } else {
                    $gender = ucfirst(strtolower($gender));
                }
            } else {
                $gender = null;
            }

            $class_id = null;
            if (empty($class_name)) {
                $row_errors[] = "Row $row_number: Class is required";
            } else {
                $class_found = false;
                foreach ($classes as $id => $db_class_name) {
                    if (strcasecmp($db_class_name, $class_name) === 0) {
                        $class_id = $id;
                        $class_found = true;
                        break;
                    }
                }

                if (!$class_found) {
                    $available_classes = implode(', ', $classes);
                    $row_warnings[] = "Row $row_number: Class '$class_name' not found (available: $available_classes) - imported as empty";
                }
            }

            $section_id = null;
            if (!empty($section_name) && $class_id !== null && isset($sections_by_class[$class_id])) {
                $section_key = strtolower($section_name);
                if (isset($sections_by_class[$class_id][$section_key])) {
                    $section_id = $sections_by_class[$class_id][$section_key];
                }
            }

            if (!empty($roll_no) && is_numeric($roll_no)) {
                $roll_no = (int)$roll_no;
            } else {
                $roll_no = null;
            }

            $landmark = !empty($landmark) ? $landmark : null;

            if (!empty($admission_date)) {
                $admission_formatted = validateAndFormatDate($admission_date, "Row $row_number: Admission Date");
                if ($admission_formatted === false) {
                    $row_warnings[] = "Row $row_number: Invalid Admission Date format - imported as empty";
                    $admission_formatted = null;
                }
            } else {
                $admission_formatted = null;
                $row_warnings[] = "Row $row_number: Admission Date missing - imported as empty";
            }

            $car_fee_value = 0;
            $custom_class_fee_value = 0;
            $hostel_fee_value = 0;
            $is_hosteler = 0;

            if (!empty($car_fee)) {
                if (!is_numeric($car_fee) || $car_fee < 0) {
                    $row_warnings[] = "Row $row_number: Invalid Car Fee - imported as 0";
                } else {
                    $car_fee_value = (float)$car_fee;
                }
            }

            if (!empty($custom_class_fee)) {
                if (!is_numeric($custom_class_fee) || $custom_class_fee < 0) {
                    $row_warnings[] = "Row $row_number: Invalid Custom Class Fee - imported as 0";
                } else {
                    $custom_class_fee_value = (float)$custom_class_fee;
                }
            }

            if (!empty($hostel_fee)) {
                if (!is_numeric($hostel_fee) || $hostel_fee < 0) {
                    $row_warnings[] = "Row $row_number: Invalid Hostel Fee - imported as 0";
                } else {
                    $hostel_fee_value = (float)$hostel_fee;
                    $is_hosteler = ($hostel_fee_value > 0) ? 1 : 0;
                }
            }

            if (!empty($row_errors)) {
                $response['errors'] = array_merge($response['errors'], $row_errors);
                $response['skipped']++;
                continue;
            }

            if (!empty($row_warnings)) {
                $response['errors'] = array_merge($response['errors'], $row_warnings);
            }

            $student_id = generateUniqueStudentId($pdo, $websiteConfig['student_id_prefix']);

            try {
                $stmt = $pdo->prepare("
                    INSERT INTO students (
                        student_id, name, father_name, mother_name, date_of_birth, phone_number, alternate_phone_number,
                        gender, class_id, section_id, roll_no, admission_date, address, landmark, driving_route_id, registration_no, religion, car_fee, 
                        custom_class_fee, hostel_fee, is_hosteler, status, updated_at
                    ) VALUES (
                        :student_id, :name, :father_name, :mother_name, :date_of_birth, :phone_number, :alternate_phone_number,
                        :gender, :class_id, :section_id, :roll_no, :admission_date, :address, :landmark, :driving_route_id, :registration_no, :religion, :car_fee,
                        :custom_class_fee, :hostel_fee, :is_hosteler, 'Active', NOW()
                    )
                ");

                $stmt->execute([
                    ':student_id' => $student_id,
                    ':name' => $name,
                    ':father_name' => $father_name,
                    ':mother_name' => $mother_name,
                    ':date_of_birth' => $dob_formatted,
                    ':phone_number' => $phone,
                    ':alternate_phone_number' => $alt_phone,
                    ':gender' => $gender,
                    ':class_id' => $class_id,
                    ':section_id' => $section_id,
                    ':roll_no' => $roll_no,
                    ':admission_date' => $admission_formatted,
                    ':address' => !empty($address) ? $address : null,
                    ':landmark' => $landmark,
                    ':driving_route_id' => null,
                    ':registration_no' => !empty($registration_no) ? $registration_no : null,
                    ':religion' => !empty($religion) ? strtolower($religion) : null,
                    ':car_fee' => $car_fee_value,
                    ':custom_class_fee' => $custom_class_fee_value,
                    ':hostel_fee' => $hostel_fee_value,
                    ':is_hosteler' => $is_hosteler
                ]);

                $response['imported']++;
            } catch (PDOException $e) {
                $response['errors'][] = "Row $row_number: Database error - " . $e->getMessage();
                $response['skipped']++;
                continue;
            }
        }

        if ($response['imported'] > 0) {
            $pdo->commit();
            $response['success'] = true;

            if ($response['skipped'] > 0) {
                $response['message'] = "Import completed with some issues. {$response['imported']} students imported successfully, {$response['skipped']} records skipped due to errors.";
            } else {
                $response['message'] = "All {$response['imported']} students imported successfully!";
            }
        } else {
            $pdo->rollBack();
            $response['success'] = false;
            $response['message'] = "No students were imported. Please check the errors below and correct your file.";
        }
    } catch (Exception $e) {
        if (isset($pdo) && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $response['success'] = false;
        $response['message'] = "Import failed: " . $e->getMessage();
    }

    return $response;
}

function validateAndFormatDate($dateString, $context = '')
{
    if (empty($dateString)) {
        return false;
    }

    if (is_numeric($dateString)) {
        try {
            $date = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($dateString);
            return $date->format('Y-m-d');
        } catch (Exception $e) {
            return false;
        }
    }

    $dateString = trim($dateString);
    $separators = ['/', '-', '.'];

    foreach ($separators as $sep) {
        if (strpos($dateString, $sep) !== false) {
            $parts = explode($sep, $dateString);

            if (count($parts) === 3) {
                $part1 = trim($parts[0]);
                $part2 = trim($parts[1]);
                $part3 = trim($parts[2]);

                if (strlen($part3) === 4 && $part3 >= 1900 && $part3 <= 2100) {
                    $day = intval($part1);
                    $month = intval($part2);
                    $year = intval($part3);

                    if ($day >= 1 && $day <= 31 && $month >= 1 && $month <= 12) {
                        if (checkdate($month, $day, $year)) {
                            return sprintf('%04d-%02d-%02d', $year, $month, $day);
                        }
                    }
                }

                if (strlen($part1) === 4 && $part1 >= 1900 && $part1 <= 2100) {
                    $year = intval($part1);
                    $month = intval($part2);
                    $day = intval($part3);

                    if ($day >= 1 && $day <= 31 && $month >= 1 && $month <= 12) {
                        if (checkdate($month, $day, $year)) {
                            return sprintf('%04d-%02d-%02d', $year, $month, $day);
                        }
                    }
                }

                if (strlen($part3) === 4 && $part3 >= 1900 && $part3 <= 2100) {
                    $month = intval($part1);
                    $day = intval($part2);
                    $year = intval($part3);

                    if ($day > 12 || $month > 12) {
                        if ($day >= 1 && $day <= 31 && $month >= 1 && $month <= 12) {
                            if (checkdate($month, $day, $year)) {
                                return sprintf('%04d-%02d-%02d', $year, $month, $day);
                            }
                        }
                    }
                }
            }
        }
    }

    $formats = ['Y-m-d', 'Y/m/d', 'd-m-Y', 'd/m/Y', 'm-d-Y', 'm/d/Y'];

    foreach ($formats as $format) {
        $date = DateTime::createFromFormat($format, $dateString);
        if ($date && $date->format($format) === $dateString) {
            return $date->format('Y-m-d');
        }
    }

    return false;
}

?>