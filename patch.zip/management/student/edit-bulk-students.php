<?php

/** @var string $school_name */
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Bulk Edit Students - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    include_once("../../includes/permission-denied.php");
    exit();
}

// Get student IDs from query string
$student_ids = $_GET['student_ids'] ?? '';
if (!$student_ids) {
    die("Student IDs are required.");
}

// Convert comma-separated string to array
$student_ids_array = explode(',', $student_ids);
$student_ids_array = array_map('trim', $student_ids_array);
$student_ids_array = array_filter($student_ids_array);

if (empty($student_ids_array)) {
    die("No valid student IDs provided.");
}

// Fetch students data
$placeholders = implode(',', array_fill(0, count($student_ids_array), '?'));
$stmt = $pdo->prepare("SELECT * FROM students WHERE student_id IN ($placeholders)");
$stmt->execute($student_ids_array);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($students)) {
    die("No students found with the provided IDs.");
}

// Re-order the rows to match the order the admin selected them in (the order of the
// student_ids query string). MySQL returns IN() results in its own order, so without
// this the "Default" sort option would have nothing to fall back to.
$students_by_id = [];
foreach ($students as $student) {
    $students_by_id[$student['student_id']] = $student;
}

$ordered_students = [];
foreach ($student_ids_array as $selected_id) {
    if (isset($students_by_id[$selected_id])) {
        $ordered_students[] = $students_by_id[$selected_id];
        unset($students_by_id[$selected_id]); // guards against a duplicated id in the query string
    }
}

// Anything the loop above didn't match keeps its original position, appended at the end
foreach ($students_by_id as $leftover_student) {
    $ordered_students[] = $leftover_student;
}

$students = $ordered_students;

// Check if all students are from the same class
// 1. Fetch All Active Classes for the Dropdown
$allClasses = $pdo->query("SELECT id, class_name FROM classes ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

// 2. Fetch All Sections (We will organize them by Class ID in PHP to use in JS)
$allSections = $pdo->query("SELECT id, section_name, class_id FROM sections ORDER BY section_name ASC")->fetchAll(PDO::FETCH_ASSOC);

// 3. Group Sections by Class ID for JavaScript
$sectionsByClass = [];
foreach ($allSections as $sec) {
    $sectionsByClass[$sec['class_id']][] = [
        'id' => $sec['id'],
        'name' => $sec['section_name']
    ];
}

// ---- START: NEW CODE ----
// Get all driving routes for the car route dropdown.
$routes = $pdo->query("SELECT id, route_name FROM driving_routes ORDER BY route_name ASC")->fetchAll(PDO::FETCH_ASSOC);
// Get all active drivers and their JSON route_ids for filtering in JS
$all_active_drivers = $pdo->query("SELECT id, name, route_ids FROM drivers WHERE status = 'active' ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
// ---- END: NEW CODE ----

// Data for dropdowns
$blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
$religions = ['islam', 'hindu', 'christian', 'buddhist', 'jain', 'sikh', 'parsi', 'judaism', 'bahai', 'atheist', 'agnostic', 'other'];
$statusValues = ['Active', 'Left', 'Alumni'];

$castes = ['General', 'SC', 'ST', 'OBC-A', 'OBC-B'];
$current_year = date('Y');

// Inline placeholder used when a father/mother photo hasn't been uploaded yet
$no_photo_placeholder = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='50' height='60'%3E%3Crect width='50' height='60' fill='%23e9ecef'/%3E%3Ctext x='25' y='33' font-size='9' text-anchor='middle' fill='%236c757d'%3ENo Photo%3C/text%3E%3C/svg%3E";
?>

<style>
    /* Your existing styles remain unchanged */
    .editable-field {
        border: 1px solid #ddd;
        padding: 5px;
        min-width: 100px;
    }

    .editable-field:focus {
        border-color: #80bdff;
        outline: 0;
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    }

    .student-row.changed {
        background-color: #fffde7;
    }

    .update-btn {
        display: none;
    }

    .student-row.changed .update-btn {
        display: inline-block;
    }

    .field-checkboxes {
        background-color: #f8f9fa;
        padding: 15px;
        border-radius: 5px;
        margin-bottom: 20px;
    }

    .field-checkboxes label {
        margin-right: 15px;
        font-weight: normal;
    }

    .photo-preview {
        width: 50px;
        height: 60px;
        object-fit: cover;
        cursor: pointer;
    }

    /* Camera / Gallery source-picker popup */
    .photo-source-menu {
        display: none;
        position: absolute;
        z-index: 2000;
        background: #fff;
        border: 1px solid #ddd;
        border-radius: 6px;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.18);
        min-width: 140px;
        overflow: hidden;
    }

    .photo-source-menu button {
        display: block;
        width: 100%;
        border: none;
        background: none;
        padding: 9px 14px;
        text-align: left;
        font-size: 14px;
        cursor: pointer;
        white-space: nowrap;
    }

    .photo-source-menu button:hover,
    .photo-source-menu button:focus {
        background-color: #f1f3f5;
    }

    .photo-source-menu button i {
        width: 18px;
        margin-right: 6px;
        color: #007bff;
    }

    .photo-source-menu .photo-source-divider {
        border-top: 1px solid #eee;
    }

    /* Cropper modal styles */
    .modal-xl {
        max-width: 80%;
    }

    .img-container {
        overflow: hidden;
        margin: 0 auto;
        height: 70vh;
    }

    .cropper-view-box {
        outline: 2px solid #007bff;
        outline-color: rgba(0, 123, 255, 0.75);
    }

    #imageToCrop {
        max-width: 100%;
    }

    /* Enhanced Cropper Modal Styles */
    .modal-xl {
        max-width: 90%;
    }

    .img-container {
        position: relative;
        overflow: hidden;
        margin: 0 auto;
        height: 70vh;
        min-height: 400px;
        max-height: 600px;
        background-color: #f8f9fa;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    #imageToCrop {
        max-width: 100%;
        max-height: 100%;
        width: auto;
        height: auto;
        display: block;
    }

    .cropper-container {
        direction: ltr;
        font-size: 0;
        line-height: 0;
        position: relative;
        touch-action: none;
        user-select: none;
        width: 100% !important;
        height: 100% !important;
    }

    .cropper-wrap-box,
    .cropper-canvas,
    .cropper-drag-box,
    .cropper-crop-box,
    .cropper-modal {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
    }

    .cropper-wrap-box {
        overflow: hidden;
    }

    .cropper-drag-box {
        opacity: 0;
        background-color: #fff;
    }

    .cropper-modal {
        opacity: .5;
        background-color: #000;
    }

    .cropper-view-box {
        display: block;
        overflow: hidden;
        width: 100%;
        height: 100%;
        outline: 2px solid #007bff;
        outline-color: rgba(0, 123, 255, .75);
    }

    .cropper-dashed {
        position: absolute;
        display: block;
        opacity: .5;
        border: 0 dashed #eee;
    }

    .cropper-dashed.dashed-h {
        top: 33.33333%;
        left: 0;
        width: 100%;
        height: 33.33333%;
        border-top-width: 1px;
        border-bottom-width: 1px;
    }

    .cropper-dashed.dashed-v {
        top: 0;
        left: 33.33333%;
        width: 33.33333%;
        height: 100%;
        border-right-width: 1px;
        border-left-width: 1px;
    }

    .cropper-center {
        position: absolute;
        top: 50%;
        left: 50%;
        display: block;
        width: 0;
        height: 0;
        opacity: .75;
    }

    .cropper-center:before,
    .cropper-center:after {
        position: absolute;
        display: block;
        content: ' ';
        background-color: #eee;
    }

    .cropper-center:before {
        top: 0;
        left: -3px;
        width: 7px;
        height: 1px;
    }

    .cropper-center:after {
        top: -3px;
        left: 0;
        width: 1px;
        height: 7px;
    }

    .cropper-face,
    .cropper-line,
    .cropper-point {
        position: absolute;
        display: block;
        width: 100%;
        height: 100%;
        opacity: .1;
    }

    .cropper-face {
        top: 0;
        left: 0;
        background-color: #fff;
    }

    .cropper-line {
        background-color: #007bff;
    }

    .cropper-line.line-e {
        top: 0;
        right: -3px;
        width: 5px;
        cursor: e-resize;
    }

    .cropper-line.line-n {
        top: -3px;
        left: 0;
        height: 5px;
        cursor: n-resize;
    }

    .cropper-line.line-w {
        top: 0;
        left: -3px;
        width: 5px;
        cursor: w-resize;
    }

    .cropper-line.line-s {
        bottom: -3px;
        left: 0;
        height: 5px;
        cursor: s-resize;
    }

    .cropper-point {
        width: 5px;
        height: 5px;
        opacity: .75;
        background-color: #007bff;
    }

    .cropper-point.point-e {
        top: 50%;
        right: -3px;
        margin-top: -3px;
        cursor: e-resize;
    }

    .cropper-point.point-n {
        top: -3px;
        left: 50%;
        margin-left: -3px;
        cursor: n-resize;
    }

    .cropper-point.point-w {
        top: 50%;
        left: -3px;
        margin-top: -3px;
        cursor: w-resize;
    }

    .cropper-point.point-s {
        bottom: -3px;
        left: 50%;
        margin-left: -3px;
        cursor: s-resize;
    }

    .cropper-point.point-ne {
        top: -3px;
        right: -3px;
        cursor: ne-resize;
    }

    .cropper-point.point-nw {
        top: -3px;
        left: -3px;
        cursor: nw-resize;
    }

    .cropper-point.point-sw {
        bottom: -3px;
        left: -3px;
        cursor: sw-resize;
    }

    .cropper-point.point-se {
        right: -3px;
        bottom: -3px;
        width: 5px;
        height: 5px;
        cursor: se-resize;
        opacity: 1;
    }

    .cropper-point.point-se:before {
        position: absolute;
        right: -50%;
        bottom: -50%;
        display: block;
        width: 200%;
        height: 200%;
        content: ' ';
        opacity: 0;
        background-color: #007bff;
    }

    table th,
    table td {
        text-align: center;
        vertical-align: middle;
    }

    .th-min-width {
        min-width: 170px;
        white-space: nowrap;
    }

    .td-min-width input.editable-field,
    .td-min-width textarea.editable-field,
    .td-min-width select.editable-field {
        min-width: 150px;
    }

    @media (max-width: 768px) {
        .modal-xl {
            max-width: 95%;
        }

        .img-container {
            height: 60vh;
            min-height: 300px;
        }
    }
</style>

<div class="container-fluid mt-4 mb-5">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0"><i class="fas fa-users-cog me-2"></i> Bulk Edit Students</h4>
        </div>

        <div class="card-body">
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i> You are editing <?= count($students) ?> students. Only changed fields will be updated.
            </div>

            <div class="row mb-3 align-items-center">
                <div class="col-md-4">
                    <div class="input-group">
                        <label class="input-group-text" for="sort-students-select"><i class="fas fa-sort-amount-down me-2"></i>Sort By</label>
                        <select class="form-select" id="sort-students-select">
                            <option value="default" selected>Default (Selection Order)</option>
                            <option value="roll_asc">Roll Number (Low to High)</option>
                            <option value="roll_desc">Roll Number (High to Low)</option>
                            <option value="name_asc">Name (A-Z)</option>
                            <option value="name_desc">Name (Z-A)</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="field-checkboxes mb-4">
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="check-name">
                    <label class="form-check-label" for="check-name"><b>Edit Name</b></label>
                </div>
                <hr>
                <h5><i class="fas fa-check-square me-2"></i> Fields to Display:</h5>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-image" value="student_image" checked>
                    <label class="form-check-label" for="toggle-image">Photo</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-father-name" value="father_name" checked>
                    <label class="form-check-label" for="toggle-father-name">Father's Name</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-mother" value="mother_name">
                    <label class="form-check-label" for="toggle-mother">Mother's Name</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-class" value="class_id" checked>
                    <label class="form-check-label" for="toggle-class">Class</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-section" value="section_id" checked>
                    <label class="form-check-label" for="toggle-section">Section</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-roll" value="roll_no" checked>
                    <label class="form-check-label" for="toggle-roll">Roll No</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-reg-no" value="registration_no">
                    <label class="form-check-label" for="toggle-reg-no">Reg. No</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-status" value="status">
                    <label class="form-check-label" for="toggle-status">Status</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-gender" value="gender">
                    <label class="form-check-label" for="toggle-gender">Gender</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-dob" value="date_of_birth">
                    <label class="form-check-label" for="toggle-dob">Date of Birth</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-phone" value="phone_number" checked>
                    <label class="form-check-label" for="toggle-phone">Phone</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-alt-phone" value="alternate_phone_number">
                    <label class="form-check-label" for="toggle-alt-phone">Alt. Phone</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-email" value="email">
                    <label class="form-check-label" for="toggle-email">Email</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-religion" value="religion">
                    <label class="form-check-label" for="toggle-religion">Religion</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-blood" value="blood_group">
                    <label class="form-check-label" for="toggle-blood">Blood Group</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-father-occupation" value="father_occupation">
                    <label class="form-check-label" for="toggle-father-occupation">Father's Occupation</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-mother-occupation" value="mother_occupation">
                    <label class="form-check-label" for="toggle-mother-occupation">Mother's Occupation</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-admission-date" value="admission_date">
                    <label class="form-check-label" for="toggle-admission-date">Admission Date</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-academic-year" value="academic_year">
                    <label class="form-check-label" for="toggle-academic-year">Academic Year</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-banglar-shiksha" value="banglar_shiksha_code">
                    <label class="form-check-label" for="toggle-banglar-shiksha">Banglar Shiksha Code</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-caste" value="caste">
                    <label class="form-check-label" for="toggle-caste">Caste</label>
                </div>
                <!-- Bank and Income Checkboxes -->
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-incomes" value="father_annual_income,mother_annual_income">
                    <label class="form-check-label" for="toggle-incomes">Parents Income</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-bank" value="bank_name,bank_branch_name,bank_account_no,ifsc_code">
                    <label class="form-check-label" for="toggle-bank">Bank Details</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-parent-ids" value="father_pan_no,father_voter_no,mother_pan_no,mother_voter_no">
                    <label class="form-check-label" for="toggle-parent-ids">Parent PAN/Voter No.</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-student-adhaar" value="student_adhaar_no">
                    <label class="form-check-label" for="toggle-student-adhaar">Student Aadhaar</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-father-adhaar" value="father_adhaar_no">
                    <label class="form-check-label" for="toggle-father-adhaar">Father Aadhaar</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-mother-adhaar" value="mother_adhaar_no">
                    <label class="form-check-label" for="toggle-mother-adhaar">Mother Aadhaar</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-village" value="village">
                    <label class="form-check-label" for="toggle-village">Village</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-post-office" value="post_office">
                    <label class="form-check-label" for="toggle-post-office">Post Office</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-police-station" value="police_station">
                    <label class="form-check-label" for="toggle-police-station">Police Station</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-district" value="district">
                    <label class="form-check-label" for="toggle-district">District</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-pin-code" value="pin_code">
                    <label class="form-check-label" for="toggle-pin-code">Pin Code</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-car-route" value="driving_route,driver">
                    <label class="form-check-label" for="toggle-car-route">Driving Route & Driver</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-car-fee" value="car_fee">
                    <label class="form-check-label" for="toggle-car-fee">Car Fee</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-hostel-fee" value="hostel_fee">
                    <label class="form-check-label" for="toggle-hostel-fee">Hostel Fee</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-custom-fee" value="custom_class_fee">
                    <label class="form-check-label" for="toggle-custom-fee">Custom Class Fee</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-coaching-fee" value="coaching_fee">
                    <label class="form-check-label" for="toggle-coaching-fee">Coaching Fee</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-tiffin-fee" value="tiffin_fee">
                    <label class="form-check-label" for="toggle-tiffin-fee">Tiffin Fee</label>
                </div>
                <hr>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-father-image" value="father_image">
                    <label class="form-check-label" for="toggle-father-image">Father's Photo</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-mother-image" value="mother_image">
                    <label class="form-check-label" for="toggle-mother-image">Mother's Photo</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-father-docs" value="father_aadhaar_image,father_voter_image,father_pan_image">
                    <label class="form-check-label" for="toggle-father-docs">Father's Documents (Aadhaar/Voter/PAN)</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-mother-docs" value="mother_aadhaar_image,mother_voter_image,mother_pan_image">
                    <label class="form-check-label" for="toggle-mother-docs">Mother's Documents (Aadhaar/Voter/PAN)</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-student-docs" value="student_birth_certificate,student_aadhaar_image,student_transfer_certificate">
                    <label class="form-check-label" for="toggle-student-docs">Student Documents (Birth Cert./Aadhaar/TC)</label>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-light table-hover" id="studentsTable">
                    <thead>
                        <tr>
                            <th class="bg-dark text-white th-min-width">Name</th>
                            <th class="field-column bg-dark text-white" data-field="student_image">Photo</th>
                            <th class="field-column bg-dark text-white" data-field="father_image">Father's Photo</th>
                            <th class="field-column bg-dark text-white" data-field="mother_image">Mother's Photo</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="father_name">Father's Name</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="mother_name">Mother's Name</th>
                            <th class="field-column bg-dark text-white" data-field="class_id">Class</th>
                            <th class="field-column bg-dark text-white" data-field="section_id">Section</th>
                            <th class="field-column bg-dark text-white" data-field="roll_no">Roll No</th>
                            <th class="field-column bg-dark text-white" data-field="registration_no">Reg. No</th>
                            <th class="field-column bg-dark text-white" data-field="status">Status</th>
                            <th class="field-column bg-dark text-white" data-field="gender">Gender</th>
                            <th class="field-column bg-dark text-white" data-field="date_of_birth">Date of Birth</th>
                            <th class="field-column bg-dark text-white" data-field="phone_number">Phone</th>
                            <th class="field-column bg-dark text-white" data-field="alternate_phone_number">Alt. Phone</th>
                            <th class="field-column bg-dark text-white" data-field="email">Email</th>
                            <th class="field-column bg-dark text-white" data-field="religion">Religion</th>
                            <th class="field-column bg-dark text-white" data-field="blood_group">Blood Group</th>
                            <th class="field-column bg-dark text-white" data-field="father_occupation">Father's Occupation</th>
                            <th class="field-column bg-dark text-white" data-field="mother_occupation">Mother's Occupation</th>
                            <th class="field-column bg-dark text-white" data-field="admission_date">Admission Date</th>
                            <th class="field-column bg-dark text-white" data-field="academic_year">Academic Year</th>
                            <th class="field-column bg-dark text-white" data-field="banglar_shiksha_code">Banglar Shiksha Code</th>
                            <th class="field-column bg-dark text-white" data-field="caste">Caste</th>
                            <th class="field-column bg-dark text-white" data-field="father_annual_income">Father's Income</th>
                            <th class="field-column bg-dark text-white" data-field="mother_annual_income">Mother's Income</th>
                            <th class="field-column bg-dark text-white" data-field="bank_name">Bank Name</th>
                            <th class="field-column bg-dark text-white" data-field="bank_branch_name">Bank Branch</th>
                            <th class="field-column bg-dark text-white" data-field="bank_account_no">Account No</th>
                            <th class="field-column bg-dark text-white" data-field="ifsc_code">IFSC Code</th>
                            <th class="field-column bg-dark text-white" data-field="student_adhaar_no">Student Aadhaar</th>
                            <th class="field-column bg-dark text-white" data-field="father_adhaar_no">Father Aadhaar</th>
                            <th class="field-column bg-dark text-white" data-field="mother_adhaar_no">Mother Aadhaar</th>
                            <th class="field-column bg-dark text-white" data-field="father_pan_no">Father PAN No</th>
                            <th class="field-column bg-dark text-white" data-field="father_voter_no">Father Voter No</th>
                            <th class="field-column bg-dark text-white" data-field="mother_pan_no">Mother PAN No</th>
                            <th class="field-column bg-dark text-white" data-field="mother_voter_no">Mother Voter No</th>
                            <th class="field-column bg-dark text-white" data-field="village">Village</th>
                            <th class="field-column bg-dark text-white" data-field="post_office">Post Office</th>
                            <th class="field-column bg-dark text-white" data-field="police_station">Police Station</th>
                            <th class="field-column bg-dark text-white" data-field="district">District</th>
                            <th class="field-column bg-dark text-white" data-field="pin_code">Pin Code</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="driving_route">
                                Driving Route
                                <button type="button" class="btn btn-sm btn-outline-light py-0 px-2 ms-1 apply-first-to-all" data-target="route"
                                    title="Apply the first student's driving route to everyone below. Students whose driver does not run that route are skipped.">
                                    <i class="fas fa-angles-down"></i> All
                                </button>
                            </th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="driver">
                                Driver
                                <button type="button" class="btn btn-sm btn-outline-light py-0 px-2 ms-1 apply-first-to-all" data-target="driver"
                                    title="Apply the first student's driver to everyone below. Each student's route list is refilled for the new driver.">
                                    <i class="fas fa-angles-down"></i> All
                                </button>
                            </th>
                            <th class="field-column bg-dark text-white" data-field="car_fee">Car Fee</th>
                            <th class="field-column bg-dark text-white" data-field="hostel_fee">Hostel Fee</th>
                            <th class="field-column bg-dark text-white" data-field="custom_class_fee">Custom Fee</th>
                            <th class="field-column bg-dark text-white" data-field="coaching_fee">Coaching Fee</th>
                            <th class="field-column bg-dark text-white" data-field="tiffin_fee">Tiffin Fee</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="father_aadhaar_image">Father Aadhaar Img</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="father_voter_image">Father Voter Img</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="father_pan_image">Father PAN Img</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="mother_aadhaar_image">Mother Aadhaar Img</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="mother_voter_image">Mother Voter Img</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="mother_pan_image">Mother PAN Img</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="student_birth_certificate">Birth Certificate</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="student_aadhaar_image">Student Aadhaar Img</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="student_transfer_certificate">Transfer Certificate</th>
                            <th class="bg-dark text-white">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $default_index => $student): ?>
                            <tr class="student-row" data-student-id="<?= safe_htmlspecialchars($student['student_id']) ?>" data-default-index="<?= $default_index ?>">
                                <td class="td-min-width">
                                    <div class="row m-0 p-0">
                                        <div class="col-md-12">
                                            <input type="text" class="form-control form-control-sm editable-field name-input text-center" value="<?= safe_htmlspecialchars($student['name']) ?>" disabled>
                                        </div>
                                        <div class="col-md-12 mt-2">
                                            <small class="text-muted" style="font-size: 0.8rem;"><?= safe_htmlspecialchars($student['student_id']) ?></small>
                                        </div>
                                    </div>
                                </td>

                                <td class="field-column" data-field="student_image">
                                    <?php if (!empty($student['student_image'])): ?>
                                        <img src="../../uploads/students/<?= safe_htmlspecialchars($student['student_image']) ?>" class="photo-preview">
                                    <?php else: ?>
                                        <img src="../../uploads/students/default_student_dp.jpg" class="photo-preview">
                                    <?php endif; ?>
                                    <input type="file" class="form-control mt-1 image-upload" style="display: none;" accept="image/*">
                                    <input type="file" class="form-control mt-1 image-upload-camera" style="display: none;" accept="image/*" capture="environment">
                                    <input type="hidden" class="current-image" value="<?= safe_htmlspecialchars($student['student_image']) ?>">
                                    <input type="hidden" class="cropped-image-data">
                                </td>

                                <td class="field-column" data-field="father_image">
                                    <?php if (!empty($student['father_image'])): ?>
                                        <img src="../../uploads/fathers/<?= safe_htmlspecialchars($student['father_image']) ?>" class="photo-preview">
                                    <?php else: ?>
                                        <img src="<?= $no_photo_placeholder ?>" class="photo-preview">
                                    <?php endif; ?>
                                    <input type="file" class="form-control mt-1 image-upload" style="display: none;" accept="image/*">
                                    <input type="file" class="form-control mt-1 image-upload-camera" style="display: none;" accept="image/*" capture="environment">
                                    <input type="hidden" class="current-image" value="<?= safe_htmlspecialchars($student['father_image'] ?? '') ?>">
                                    <input type="hidden" class="cropped-image-data">
                                </td>

                                <td class="field-column" data-field="mother_image">
                                    <?php if (!empty($student['mother_image'])): ?>
                                        <img src="../../uploads/mothers/<?= safe_htmlspecialchars($student['mother_image']) ?>" class="photo-preview">
                                    <?php else: ?>
                                        <img src="<?= $no_photo_placeholder ?>" class="photo-preview">
                                    <?php endif; ?>
                                    <input type="file" class="form-control mt-1 image-upload" style="display: none;" accept="image/*">
                                    <input type="file" class="form-control mt-1 image-upload-camera" style="display: none;" accept="image/*" capture="environment">
                                    <input type="hidden" class="current-image" value="<?= safe_htmlspecialchars($student['mother_image'] ?? '') ?>">
                                    <input type="hidden" class="cropped-image-data">
                                </td>

                                <td class="field-column td-min-width" data-field="father_name">
                                    <input type="text" class="form-control form-control-sm editable-field father-name-input" value="<?= safe_htmlspecialchars($student['father_name']) ?>">
                                </td>

                                <td class="field-column td-min-width" data-field="mother_name">
                                    <input type="text" class="form-control form-control-sm editable-field mother-name-input" value="<?= safe_htmlspecialchars($student['mother_name']) ?>">
                                </td>

                                <td class="field-column" data-field="class_id">
                                    <select class="form-control form-control-sm editable-field class-select">
                                        <?php foreach ($allClasses as $class): ?>
                                            <option value="<?= $class['id'] ?>" <?= $student['class_id'] == $class['id'] ? 'selected' : '' ?>>
                                                <?= safe_htmlspecialchars($class['class_name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>

                                <td class="field-column" data-field="section_id">
                                    <select class="form-control form-control-sm editable-field section-select" data-current-section="<?= $student['section_id'] ?>">
                                    </select>
                                </td>

                                <td class="field-column" data-field="roll_no">
                                    <input type="number" class="form-control form-control-sm editable-field roll-no-input" value="<?= safe_htmlspecialchars($student['roll_no']) ?>">
                                </td>

                                <td class="field-column" data-field="registration_no">
                                    <input type="text" class="form-control form-control-sm editable-field registration-no-input" value="<?= safe_htmlspecialchars($student['registration_no']) ?>">
                                </td>

                                <td class="field-column" data-field="status">
                                    <select class="form-control form-control-sm editable-field status-select">
                                        <?php foreach ($statusValues as $status): ?>
                                            <option value="<?= $status ?>" <?= $student['status'] === $status ? 'selected' : '' ?>>
                                                <?= $status ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>

                                <td class="field-column" data-field="gender">
                                    <select class="form-control form-control-sm editable-field gender-select">
                                        <option value="Male" <?= $student['gender'] === 'Male' ? 'selected' : '' ?>>Male</option>
                                        <option value="Female" <?= $student['gender'] === 'Female' ? 'selected' : '' ?>>Female</option>
                                        <option value="Other" <?= $student['gender'] === 'Other' ? 'selected' : '' ?>>Other</option>
                                    </select>
                                </td>

                                <td class="field-column" data-field="date_of_birth">
                                    <input type="date" class="form-control form-control-sm editable-field dob-input" value="<?= safe_htmlspecialchars($student['date_of_birth'] ?? '') ?>">
                                </td>

                                <td class="field-column" data-field="phone_number">
                                    <input type="tel" class="form-control form-control-sm editable-field phone-input" value="<?= safe_htmlspecialchars($student['phone_number']) ?>">
                                </td>

                                <td class="field-column" data-field="alternate_phone_number">
                                    <input type="tel" class="form-control form-control-sm editable-field alt-phone-input" value="<?= safe_htmlspecialchars($student['alternate_phone_number']) ?>">
                                </td>

                                <td class="field-column" data-field="email">
                                    <input type="email" class="form-control form-control-sm editable-field email-input" value="<?= safe_htmlspecialchars($student['email']) ?>">
                                </td>

                                <td class="field-column" data-field="religion">
                                    <select class="form-control form-control-sm editable-field religion-select">
                                        <option value="">Select</option>
                                        <?php foreach ($religions as $religion): ?>
                                            <option value="<?= $religion ?>" <?= strtolower((string) $student['religion']) === $religion ? 'selected' : '' ?>>
                                                <?= ucfirst($religion) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>

                                <td class="field-column" data-field="blood_group">
                                    <select class="form-control form-control-sm editable-field blood-group-select">
                                        <option value="">Select</option>
                                        <?php foreach ($blood_groups as $group): ?>
                                            <option value="<?= $group ?>" <?= $student['blood_group'] === $group ? 'selected' : '' ?>>
                                                <?= $group ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>

                                <td class="field-column" data-field="father_occupation">
                                    <input type="text" class="form-control form-control-sm editable-field father-occupation-input" value="<?= safe_htmlspecialchars($student['father_occupation']) ?>">
                                </td>

                                <td class="field-column" data-field="mother_occupation">
                                    <input type="text" class="form-control form-control-sm editable-field mother-occupation-input" value="<?= safe_htmlspecialchars($student['mother_occupation']) ?>">
                                </td>

                                <td class="field-column" data-field="admission_date">
                                    <input type="date" class="form-control form-control-sm editable-field admission-date-input" value="<?= safe_htmlspecialchars($student['admission_date'] ?? '') ?>">
                                </td>

                                <td class="field-column" data-field="academic_year">
                                    <select class="form-control form-control-sm editable-field academic-year-select">
                                        <?php for ($y = $current_year - 1; $y <= $current_year + 2; $y++): ?>
                                            <option value="<?= $y ?>" <?= (isset($student['academic_year']) && $student['academic_year'] == $y) ? 'selected' : '' ?>><?= $y ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </td>

                                <td class="field-column" data-field="banglar_shiksha_code">
                                    <input type="text" class="form-control form-control-sm editable-field banglar-shiksha-input" value="<?= safe_htmlspecialchars($student['banglar_shiksha_code'] ?? '') ?>">
                                </td>

                                <td class="field-column" data-field="caste">
                                    <select class="form-control form-control-sm editable-field caste-select">
                                        <option value="">Select</option>
                                        <?php foreach ($castes as $caste): ?>
                                            <option value="<?= $caste ?>" <?= (isset($student['caste']) && $student['caste'] === $caste) ? 'selected' : '' ?>><?= $caste ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>

                                <td class="field-column" data-field="father_annual_income">
                                    <input type="number" class="form-control form-control-sm editable-field f-income-input" value="<?= safe_htmlspecialchars($student['father_annual_income'] ?? '') ?>">
                                </td>

                                <td class="field-column" data-field="mother_annual_income">
                                    <input type="number" class="form-control form-control-sm editable-field m-income-input" value="<?= safe_htmlspecialchars($student['mother_annual_income'] ?? '') ?>">
                                </td>

                                <td class="field-column" data-field="bank_name">
                                    <input type="text" class="form-control form-control-sm editable-field bank-name-input" value="<?= safe_htmlspecialchars($student['bank_name'] ?? '') ?>">
                                </td>

                                <td class="field-column" data-field="bank_branch_name">
                                    <input type="text" class="form-control form-control-sm editable-field bank-branch-input" value="<?= safe_htmlspecialchars($student['bank_branch_name'] ?? '') ?>">
                                </td>

                                <td class="field-column" data-field="bank_account_no">
                                    <input type="text" class="form-control form-control-sm editable-field account-no-input" value="<?= safe_htmlspecialchars($student['bank_account_no'] ?? '') ?>">
                                </td>

                                <td class="field-column" data-field="ifsc_code">
                                    <input type="text" class="form-control form-control-sm editable-field ifsc-input" value="<?= safe_htmlspecialchars($student['ifsc_code'] ?? '') ?>">
                                </td>

                                <td class="field-column" data-field="student_adhaar_no">
                                    <input type="text" class="form-control form-control-sm editable-field student-adhaar-input" value="<?= safe_htmlspecialchars($student['student_adhaar_no']) ?>">
                                </td>
                                <td class="field-column" data-field="father_adhaar_no">
                                    <input type="text" class="form-control form-control-sm editable-field father-adhaar-input" value="<?= safe_htmlspecialchars($student['father_adhaar_no']) ?>">
                                </td>
                                <td class="field-column" data-field="mother_adhaar_no">
                                    <input type="text" class="form-control form-control-sm editable-field mother-adhaar-input" value="<?= safe_htmlspecialchars($student['mother_adhaar_no']) ?>">
                                </td>
                                <td class="field-column" data-field="father_pan_no">
                                    <input type="text" class="form-control form-control-sm editable-field father-pan-input" value="<?= safe_htmlspecialchars($student['father_pan_no'] ?? '') ?>">
                                </td>
                                <td class="field-column" data-field="father_voter_no">
                                    <input type="text" class="form-control form-control-sm editable-field father-voter-input" value="<?= safe_htmlspecialchars($student['father_voter_no'] ?? '') ?>">
                                </td>
                                <td class="field-column" data-field="mother_pan_no">
                                    <input type="text" class="form-control form-control-sm editable-field mother-pan-input" value="<?= safe_htmlspecialchars($student['mother_pan_no'] ?? '') ?>">
                                </td>
                                <td class="field-column" data-field="mother_voter_no">
                                    <input type="text" class="form-control form-control-sm editable-field mother-voter-input" value="<?= safe_htmlspecialchars($student['mother_voter_no'] ?? '') ?>">
                                </td>
                                <td class="field-column" data-field="village">
                                    <input type="text" class="form-control form-control-sm editable-field village-input" value="<?= safe_htmlspecialchars($student['village']) ?>">
                                </td>
                                <td class="field-column" data-field="post_office">
                                    <input type="text" class="form-control form-control-sm editable-field post-office-input" value="<?= safe_htmlspecialchars($student['post_office']) ?>">
                                </td>
                                <td class="field-column" data-field="police_station">
                                    <input type="text" class="form-control form-control-sm editable-field police-station-input" value="<?= safe_htmlspecialchars($student['police_station']) ?>">
                                </td>
                                <td class="field-column" data-field="district">
                                    <input type="text" class="form-control form-control-sm editable-field district-input" value="<?= safe_htmlspecialchars($student['district']) ?>">
                                </td>
                                <td class="field-column" data-field="pin_code">
                                    <input type="text" class="form-control form-control-sm editable-field pin-code-input" value="<?= safe_htmlspecialchars($student['pin_code']) ?>">
                                </td>

                                <td class="field-column td-min-width" data-field="driving_route">
                                    <select class="form-select form-select-sm editable-field car-route-select">
                                        <option value="">Select Driving Route</option>
                                        <?php
                                        // Only show routes belonging to the student's currently assigned driver (if any).
                                        // Stays empty until a driver is picked — mirrors the driver-first flow.
                                        if (!empty($student['driver_id'])) {
                                            foreach ($all_active_drivers as $driver) {
                                                if ($driver['id'] == $student['driver_id']) {
                                                    $driver_route_ids = json_decode($driver['route_ids'] ?? '[]', true);
                                                    if (is_array($driver_route_ids)) {
                                                        foreach ($routes as $route) {
                                                            if (in_array($route['id'], $driver_route_ids)) {
                                                                $selected = ($student['driving_route_id'] == $route['id']) ? 'selected' : '';
                                                                echo "<option value='" . safe_htmlspecialchars($route['id']) . "' $selected>" . safe_htmlspecialchars($route['route_name']) . "</option>";
                                                            }
                                                        }
                                                    }
                                                    break;
                                                }
                                            }
                                        }
                                        ?>
                                    </select>
                                </td>

                                <td class="field-column td-min-width" data-field="driver">
                                    <select class="form-select form-select-sm editable-field driver-select select2">
                                        <option value="">Select Driver</option>
                                        <?php
                                        // Show ALL active drivers up front — route list is filtered based on the chosen driver, not the other way around
                                        foreach ($all_active_drivers as $driver) {
                                            $selected = ($student['driver_id'] == $driver['id']) ? 'selected' : '';
                                            echo "<option value='" . safe_htmlspecialchars($driver['id']) . "' $selected>" . safe_htmlspecialchars($driver['name']) . "</option>";
                                        }
                                        ?>
                                    </select>
                                </td>
                                <td class="field-column" data-field="car_fee">
                                    <input type="number" step="0.01" class="form-control form-control-sm editable-field car-fee-input" value="<?= safe_htmlspecialchars($student['car_fee']) ?>">
                                </td>
                                <td class="field-column" data-field="hostel_fee">
                                    <input type="number" step="0.01" class="form-control form-control-sm editable-field hostel-fee-input" value="<?= safe_htmlspecialchars($student['hostel_fee']) ?>">
                                </td>
                                <td class="field-column" data-field="custom_class_fee">
                                    <input type="number" step="0.01" class="form-control form-control-sm editable-field custom-fee-input" value="<?= safe_htmlspecialchars($student['custom_class_fee']) ?>">
                                </td>
                                <td class="field-column" data-field="coaching_fee">
                                    <input type="number" step="0.01" class="form-control form-control-sm editable-field coaching-fee-input" value="<?= safe_htmlspecialchars($student['coaching_fee'] ?? '') ?>">
                                </td>
                                <td class="field-column" data-field="tiffin_fee">
                                    <input type="number" step="0.01" class="form-control form-control-sm editable-field tiffin-fee-input" value="<?= safe_htmlspecialchars($student['tiffin_fee'] ?? '') ?>">
                                </td>

                                <?php
                                // Document fields: each shows a "View" link if already uploaded, plus a file input to replace/add it
                                $document_fields_for_row = [
                                    'father_aadhaar_image'          => "Father's Aadhaar",
                                    'father_voter_image'            => "Father's Voter",
                                    'father_pan_image'              => "Father's PAN",
                                    'mother_aadhaar_image'          => "Mother's Aadhaar",
                                    'mother_voter_image'            => "Mother's Voter",
                                    'mother_pan_image'              => "Mother's PAN",
                                    'student_birth_certificate'     => "Birth Certificate",
                                    'student_aadhaar_image'         => "Student Aadhaar",
                                    'student_transfer_certificate'  => "Transfer Certificate",
                                ];
                                foreach ($document_fields_for_row as $doc_field => $doc_label):
                                ?>
                                <td class="field-column td-min-width" data-field="<?= $doc_field ?>">
                                    <?php if (!empty($student[$doc_field])): ?>
                                        <a href="<?= safe_htmlspecialchars($student[$doc_field]) ?>" target="_blank" class="d-block small mb-1 doc-current-link"><i class="fas fa-eye"></i> View</a>
                                    <?php else: ?>
                                        <span class="text-muted small d-block mb-1 doc-current-link">Not uploaded</span>
                                    <?php endif; ?>
                                    <input type="file" class="form-control form-control-sm document-upload" data-doc-field="<?= $doc_field ?>" accept="image/jpeg,image/png" title="Upload <?= $doc_label ?>">
                                </td>
                                <?php endforeach; ?>

                                <td>
                                    <button class="btn btn-sm btn-primary update-btn" data-student-id="<?= safe_htmlspecialchars($student['student_id']) ?>">
                                        <i class="fas fa-save"></i> Update
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="text-center mt-4">
                <button id="updateAllBtn" class="btn btn-primary px-4 py-2">
                    <i class="fas fa-save me-2"></i> Update All Changes
                </button>
                <a href="../student/list-students.php" class="btn btn-secondary px-4 py-2 ms-2">
                    <i class="fas fa-times me-2"></i> Cancel
                </a>
            </div>
        </div>
    </div>
</div>

<div id="photoSourceMenu" class="photo-source-menu">
    <button type="button" class="photo-source-camera"><i class="fas fa-camera"></i> Camera</button>
    <div class="photo-source-divider"></div>
    <button type="button" class="photo-source-gallery"><i class="fas fa-image"></i> Gallery</button>
</div>

<div class="modal fade" id="cropModal" tabindex="-1" aria-labelledby="cropModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cropModalLabel">Crop Student Photo (5:6 ratio required)</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <div class="img-container">
                    <img id="imageToCrop" src="#" alt="Image to crop">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="cropImageBtn">Crop & Save</button>
            </div>
        </div>
    </div>
</div>


<script>
    $(document).ready(function() {
        let cropper;
        let currentImageRow;
        const cropModal = new bootstrap.Modal(document.getElementById('cropModal'));
        let rollNumbers = {};
        let registrationNumbers = {};

        // Pass PHP Drivers Data to JS for filtering without AJAX
        const allDrivers = <?= json_encode($all_active_drivers) ?>;
        // Pass PHP Routes Data to JS so we can filter routes by the selected driver
        const allRoutes = <?= json_encode($routes) ?>;

        $('#check-name').change(function() {
            const isChecked = $(this).is(':checked');
            $('.name-input').prop('disabled', !isChecked);
        });

        function initializeUniqueFields() {
            $('.student-row').each(function() {
                const $row = $(this);
                const studentId = $row.data('student-id');
                const rollNo = parseInt($row.find('.roll-no-input').val());
                const sectionId = $row.find('.section-select').val();

                if (rollNo > 0) {
                    rollNumbers[studentId] = {
                        roll: rollNo,
                        section: sectionId
                    };
                }

                const regNo = $row.find('.registration-no-input').val().trim();
                if (regNo) {
                    registrationNumbers[studentId] = regNo;
                }
            });
        }

        function validateRollNumber(studentId, newRollNo) {
            if (newRollNo <= 0) {
                return {
                    valid: false,
                    message: 'Roll number must be a positive number'
                };
            }

            const currentStudentRow = $(`tr[data-student-id="${studentId}"]`);
            const currentSectionId = currentStudentRow.find('.section-select').val();

            if (!currentSectionId) {
                return {
                    valid: false,
                    message: 'Section is required.'
                };
            }

            let isDuplicate = false;

            $('.student-row').each(function() {
                const row = $(this);
                const otherStudentId = row.data('student-id').toString();

                if (otherStudentId === studentId.toString()) {
                    return;
                }

                const otherRollInput = row.find('.roll-no-input').val();
                const otherRoll = parseInt(otherRollInput);
                const otherSectionId = row.find('.section-select').val();

                if (otherRoll === parseInt(newRollNo) && otherSectionId == currentSectionId) {
                    isDuplicate = true;
                    return false;
                }
            });

            if (isDuplicate) {
                return {
                    valid: false,
                    message: `Roll no ${newRollNo} is already used in this section.`
                };
            }

            return {
                valid: true,
                message: ''
            };
        }


        function validateRegistrationNumber(studentId, newRegNo) {
            if (!newRegNo) return {
                valid: true,
                message: ''
            };
            for (let [otherId, otherReg] of Object.entries(registrationNumbers)) {
                if (otherId !== studentId && otherReg === newRegNo) {
                    return {
                        valid: false,
                        message: `Reg. no ${newRegNo} is already assigned`
                    };
                }
            }
            return {
                valid: true,
                message: ''
            };
        }

        initializeUniqueFields();

        function createValidator(inputClass, validationFn, dataStore) {
            $(document).on('input blur', inputClass, function() {
                const $input = $(this);
                const $row = $input.closest('.student-row');
                const studentId = $row.data('student-id').toString();
                const newValue = (inputClass === '.roll-no-input') ? parseInt($input.val()) : $input.val().trim();

                $input.siblings('.validation-feedback').remove();
                $input.removeClass('is-invalid is-valid');

                if (($input.val() && !isNaN(newValue)) || (typeof newValue === 'string' && newValue)) {
                    const validation = validationFn(studentId, newValue);
                    if (!validation.valid) {
                        $input.addClass('is-invalid');
                        $input.after(`<div class="invalid-feedback d-block validation-feedback">${validation.message}</div>`);
                    } else {
                        $input.addClass('is-valid');
                        if (inputClass === '.roll-no-input') {
                            const sectionId = $row.find('.section-select').val();
                            dataStore[studentId] = {
                                roll: newValue,
                                section: sectionId
                            };
                        } else {
                            dataStore[studentId] = newValue;
                        }
                    }
                } else {
                    delete dataStore[studentId];
                }
            });
        }

        createValidator('.roll-no-input', validateRollNumber, rollNumbers);
        createValidator('.registration-no-input', validateRegistrationNumber, registrationNumbers);

        $(document).on('change', '.section-select', function() {
            const $row = $(this).closest('.student-row');
            const studentId = $row.data('student-id').toString();
            const newSectionId = $(this).val();

            if (rollNumbers[studentId]) {
                rollNumbers[studentId].section = newSectionId;
            }

            $row.find('.roll-no-input').trigger('blur');
        });

        const photoFieldLabels = {
            student_image: "Crop Student Photo (5:6 ratio required)",
            father_image: "Crop Father's Photo (5:6 ratio required)",
            mother_image: "Crop Mother's Photo (5:6 ratio required)"
        };

        const $photoSourceMenu = $('#photoSourceMenu');

        $('.photo-preview').click(function(e) {
            e.stopPropagation();
            currentImageRow = $(this).closest('td');
            const dataField = currentImageRow.data('field');
            $('#cropModalLabel').text(photoFieldLabels[dataField] || 'Crop Photo (5:6 ratio required)');

            const offset = $(this).offset();
            $photoSourceMenu.css({
                top: offset.top + $(this).outerHeight() + 4,
                left: offset.left
            }).show();
        });

        // Prevent clicks inside the popup from bubbling up and closing it immediately
        $photoSourceMenu.on('click', function(e) {
            e.stopPropagation();
        });

        // Close the popup when clicking anywhere else on the page
        $(document).on('click', function() {
            $photoSourceMenu.hide();
        });

        $('.photo-source-camera').click(function() {
            $photoSourceMenu.hide();
            if (currentImageRow) currentImageRow.find('.image-upload-camera').click();
        });

        $('.photo-source-gallery').click(function() {
            $photoSourceMenu.hide();
            if (currentImageRow) currentImageRow.find('.image-upload').click();
        });

        $(document).on('change', '.image-upload, .image-upload-camera', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    $('#imageToCrop').attr('src', e.target.result);
                    cropModal.show();
                }
                reader.readAsDataURL(file);
            }
        });

        $('#cropModal').on('shown.bs.modal', function() {
            if (cropper) cropper.destroy();
            const image = document.getElementById('imageToCrop');
            cropper = new Cropper(image, {
                aspectRatio: 5 / 6,
                viewMode: 1,
                autoCropArea: 0.8,
                responsive: true,
                restore: false,
                guides: true,
                center: true,
                highlight: false,
                cropBoxMovable: true,
                cropBoxResizable: true,
                toggleDragModeOnDblclick: false,
            });
        });

        $('#cropImageBtn').click(function() {
            if (!cropper) return;
            const canvas = cropper.getCroppedCanvas({
                width: 500,
                height: 600,
                fillColor: '#fff'
            });
            if (!canvas) return;

            canvas.toBlob(function(blob) {
                const previewUrl = URL.createObjectURL(blob);
                currentImageRow.find('.photo-preview').attr('src', previewUrl);
                const reader = new FileReader();
                reader.onload = () => {
                    currentImageRow.find('.cropped-image-data').val(reader.result);
                    currentImageRow.closest('.student-row').addClass('changed');
                };
                reader.readAsDataURL(blob);
                cropModal.hide();
            }, 'image/jpeg', 0.9);
        });

        $('#cropModal').on('hidden.bs.modal', function() {
            if (cropper) {
                cropper.destroy();
                cropper = null;
            }
            $('#imageToCrop').attr('src', '#');
            if (currentImageRow) currentImageRow.find('.image-upload, .image-upload-camera').val('');
        });

        $('#sort-students-select').on('change', function() {
            const sortOption = $(this).val();
            let rows = $('#studentsTable tbody tr').get();

            rows.sort(function(a, b) {
                let valA, valB;

                switch (sortOption) {
                    case 'default':
                        // Selection order — the order the ids arrived in the student_ids query string
                        valA = parseInt($(a).data('default-index')) || 0;
                        valB = parseInt($(b).data('default-index')) || 0;
                        return valA - valB;
                    case 'name_asc':
                        valA = $(a).find('.name-input').val().trim().toLowerCase();
                        valB = $(b).find('.name-input').val().trim().toLowerCase();
                        return valA.localeCompare(valB);
                    case 'name_desc':
                        valA = $(a).find('.name-input').val().trim().toLowerCase();
                        valB = $(b).find('.name-input').val().trim().toLowerCase();
                        return valB.localeCompare(valA);
                    case 'roll_asc':
                        valA = parseInt($(a).find('.roll-no-input').val()) || 0;
                        valB = parseInt($(b).find('.roll-no-input').val()) || 0;
                        return valA - valB;
                    case 'roll_desc':
                        valA = parseInt($(a).find('.roll-no-input').val()) || 0;
                        valB = parseInt($(b).find('.roll-no-input').val()) || 0;
                        return valB - valA;
                    default:
                        return 0;
                }
            });

            $.each(rows, function(index, row) {
                $('#studentsTable tbody').append(row);
            });
        });

        $('.field-toggle').change(function() {
            const fields = $(this).val().split(',');
            const isChecked = $(this).is(':checked');
            fields.forEach(field => {
                $(`.field-column[data-field="${field}"]`).toggle(isChecked);
            });
        }).trigger('change');

        $('.editable-field, .image-upload, .image-upload-camera, .document-upload').on('input change', function() {
            $(this).closest('.student-row').addClass('changed');
        });

        // Reads a driver's assigned route ids out of the JSON column.
        // Everything is normalised to strings because route_ids may hold ints or numeric strings.
        function getDriverRouteIds(driverId) {
            const driver = allDrivers.find(d => String(d.id) === String(driverId));
            if (!driver) return [];
            try {
                const ids = JSON.parse(driver.route_ids || '[]');
                return Array.isArray(ids) ? ids.map(String) : [];
            } catch (e) {
                return [];
            }
        }

        // The driver ↔ route relation: a route is only valid for a student if that
        // student's own driver actually runs it.
        function driverHasRoute(driverId, routeId) {
            if (!driverId || !routeId) return false;
            return getDriverRouteIds(driverId).includes(String(routeId));
        }

        // Rebuilds a row's route dropdown so it only lists the chosen driver's routes.
        // keepRouteId is re-selected when it belongs to that driver; otherwise the row
        // ends up with no route selected — the driver-first flow this page always had.
        function populateRoutesForDriver(row, driverId, keepRouteId) {
            const routeSelect = row.find('.car-route-select');

            if (!driverId) {
                routeSelect.html('<option value="">Select Driving Route</option>');
                return;
            }

            const routeIds = getDriverRouteIds(driverId);
            let options = '<option value="">Select Driving Route</option>';
            let found = false;

            allRoutes.forEach(route => {
                // Check if this route is in the selected driver's route_ids array
                if (routeIds.includes(String(route.id))) {
                    const selected = (keepRouteId && String(keepRouteId) === String(route.id)) ? ' selected' : '';
                    options += `<option value="${route.id}"${selected}>${route.route_name}</option>`;
                    found = true;
                }
            });

            if (!found) {
                options += '<option value="" disabled>No routes assigned to this driver</option>';
            }
            routeSelect.html(options);
        }

        // Updated Route filter via JSON — driver is selected first, then routes are filtered to that driver's assigned routes
        $(document).on('change', '.driver-select', function() {
            populateRoutesForDriver($(this).closest('.student-row'), $(this).val());
        });

        // Bulk shortcut: copy the FIRST student's driver (or route) down to every other
        // student, instead of picking it row by row. The per-row dropdowns keep working
        // exactly as before — this is just a faster way to reach the same result.
        $(document).on('click', '.apply-first-to-all', function() {
            const target = $(this).data('target');
            const rows = $('#studentsTable tbody tr.student-row');

            if (rows.length < 2) {
                toastr.info('There is only one student in the list.');
                return;
            }

            const firstRow = rows.first();
            const restRows = rows.slice(1);

            if (target === 'driver') {
                const driverId = firstRow.find('.driver-select').val();

                if (!driverId) {
                    toastr.warning("Select a driver for the first student first.");
                    return;
                }

                let applied = 0,
                    alreadySet = 0;

                restRows.each(function() {
                    const row = $(this);
                    const driverSelect = row.find('.driver-select');

                    // Already on this driver — leave the row alone so its own route stays intact
                    if (String(driverSelect.val()) === String(driverId)) {
                        alreadySet++;
                        return;
                    }

                    // trigger('change') updates the select2 display and refills the route list
                    driverSelect.val(driverId).trigger('change');
                    row.addClass('changed');
                    applied++;
                });

                let message = `Driver applied to ${applied} student(s).`;
                if (alreadySet > 0) {
                    message += ` ${alreadySet} already had this driver.`;
                }
                message += ' Pick the route for the first student, then use its "All" button.';

                applied > 0 ? toastr.success(message) : toastr.info(message);
                return;
            }

            if (target === 'route') {
                const routeId = firstRow.find('.car-route-select').val();

                if (!routeId) {
                    toastr.warning("Select a driving route for the first student first.");
                    return;
                }

                let applied = 0,
                    skipped = 0;

                restRows.each(function() {
                    const row = $(this);
                    const driverId = row.find('.driver-select').val();

                    // Relation guard: skip students whose driver doesn't run this route
                    // (including students with no driver assigned at all).
                    if (!driverHasRoute(driverId, routeId)) {
                        skipped++;
                        return;
                    }

                    const routeSelect = row.find('.car-route-select');

                    if (routeSelect.find(`option[value="${routeId}"]`).length === 0) {
                        // Option isn't in this row's list yet — refill from the driver, keeping this route selected
                        populateRoutesForDriver(row, driverId, routeId);
                    } else {
                        routeSelect.val(routeId);
                    }

                    row.addClass('changed');
                    applied++;
                });

                let message = `Driving route applied to ${applied} student(s).`;
                if (skipped > 0) {
                    message += ` ${skipped} skipped — their driver does not run this route.`;
                }

                applied > 0 ? toastr.success(message) : toastr.warning(message);
            }
        });

        $(document).on('click', '.update-btn', function() {
            const studentId = $(this).data('student-id');
            const row = $(`tr[data-student-id="${studentId}"]`);
            if (row.find('.is-invalid').length > 0) {
                toastr.error('Please fix validation errors before updating.');
                return;
            }
            updateStudent(studentId);
        });

        $('#updateAllBtn').click(function() {
            if ($('.is-invalid').length > 0) {
                toastr.error('Please fix all validation errors before updating.');
                return;
            }
            const changedRows = $('.student-row.changed');
            if (changedRows.length === 0) {
                toastr.info('No changes detected.');
                return;
            }
            let updateCount = 0,
                errorCount = 0;
            const progressToast = toastr.info(`Updating ${changedRows.length} students...`, 'Progress', {
                timeOut: 0
            });
            changedRows.each((index, row) => {
                const studentId = $(row).data('student-id');
                setTimeout(() => {
                    updateStudent(studentId, success => {
                        success ? updateCount++ : errorCount++;
                        if (updateCount + errorCount === changedRows.length) {
                            toastr.clear(progressToast);
                            if (errorCount === 0) {
                                toastr.success(`All ${updateCount} students updated successfully!`);
                            } else {
                                toastr.warning(`${updateCount} updated, ${errorCount} failed.`);
                            }
                        }
                    });
                }, index * 200);
            });
        });

        function updateStudent(studentId, callback) {
            const row = $(`tr[data-student-id="${studentId}"]`);
            const formData = new FormData();
            formData.append('student_id', studentId);
            let hasChanges = false;

            const fields = [{
                    selector: '.name-input',
                    name: 'name'
                },
                {
                    selector: '.class-select',
                    name: 'class_id'
                },
                {
                    selector: '.section-select',
                    name: 'section_id'
                },
                {
                    selector: '.roll-no-input',
                    name: 'roll_no'
                },
                {
                    selector: '.phone-input',
                    name: 'phone_number'
                },
                {
                    selector: '.alt-phone-input',
                    name: 'alternate_phone_number'
                },
                {
                    selector: '.blood-group-select',
                    name: 'blood_group'
                },
                {
                    selector: '.mother-name-input',
                    name: 'mother_name'
                },
                {
                    selector: '.father-occupation-input',
                    name: 'father_occupation'
                },
                {
                    selector: '.mother-occupation-input',
                    name: 'mother_occupation'
                },
                {
                    selector: '.admission-date-input',
                    name: 'admission_date'
                },
                {
                    selector: '.academic-year-select',
                    name: 'academic_year'
                },
                {
                    selector: '.banglar-shiksha-input',
                    name: 'banglar_shiksha_code'
                },
                {
                    selector: '.caste-select',
                    name: 'caste'
                },
                {
                    selector: '.f-income-input',
                    name: 'father_annual_income'
                },
                {
                    selector: '.m-income-input',
                    name: 'mother_annual_income'
                },
                {
                    selector: '.bank-name-input',
                    name: 'bank_name'
                },
                {
                    selector: '.account-no-input',
                    name: 'bank_account_no'
                },
                {
                    selector: '.ifsc-input',
                    name: 'ifsc_code'
                },
                {
                    selector: '.student-adhaar-input',
                    name: 'student_adhaar_no'
                },
                {
                    selector: '.father-adhaar-input',
                    name: 'father_adhaar_no'
                },
                {
                    selector: '.mother-adhaar-input',
                    name: 'mother_adhaar_no'
                },
                {
                    selector: '.village-input',
                    name: 'village'
                },
                {
                    selector: '.post-office-input',
                    name: 'post_office'
                },
                {
                    selector: '.police-station-input',
                    name: 'police_station'
                },
                {
                    selector: '.district-input',
                    name: 'district'
                },
                {
                    selector: '.pin-code-input',
                    name: 'pin_code'
                },
                {
                    selector: '.car-route-select',
                    name: 'driving_route_id'
                },
                {
                    selector: '.driver-select',
                    name: 'driver_id'
                },
                {
                    selector: '.car-fee-input',
                    name: 'car_fee'
                },
                {
                    selector: '.hostel-fee-input',
                    name: 'hostel_fee'
                },
                {
                    selector: '.custom-fee-input',
                    name: 'custom_class_fee'
                },
                {
                    selector: '.coaching-fee-input',
                    name: 'coaching_fee'
                },
                {
                    selector: '.tiffin-fee-input',
                    name: 'tiffin_fee'
                },
                {
                    selector: '.father-name-input',
                    name: 'father_name'
                },
                {
                    selector: '.gender-select',
                    name: 'gender'
                },
                {
                    selector: '.religion-select',
                    name: 'religion'
                },
                {
                    selector: '.registration-no-input',
                    name: 'registration_no'
                },
                {
                    selector: '.email-input',
                    name: 'email'
                },
                {
                    selector: '.status-select',
                    name: 'status'
                },
                {
                    selector: '.dob-input',
                    name: 'date_of_birth'
                },
                {
                    selector: '.bank-branch-input',
                    name: 'bank_branch_name'
                },
                {
                    selector: '.father-pan-input',
                    name: 'father_pan_no'
                },
                {
                    selector: '.father-voter-input',
                    name: 'father_voter_no'
                },
                {
                    selector: '.mother-pan-input',
                    name: 'mother_pan_no'
                },
                {
                    selector: '.mother-voter-input',
                    name: 'mother_voter_no'
                }
            ];

            fields.forEach(field => {
                const element = row.find(field.selector);
                if (element.data('original-value') !== undefined && element.val() != element.data('original-value')) {
                    formData.append(field.name, element.val());
                    hasChanges = true;
                }
            });

            // Photo fields (student/father/mother) - each cell is looked up individually since
            // there are now multiple .cropped-image-data / .current-image inputs per row.
            const photoConfigs = [
                { dataField: 'student_image', croppedParam: 'cropped_image_data', currentParam: 'current_image' },
                { dataField: 'father_image', croppedParam: 'cropped_father_image_data', currentParam: 'current_father_image' },
                { dataField: 'mother_image', croppedParam: 'cropped_mother_image_data', currentParam: 'current_mother_image' }
            ];
            photoConfigs.forEach(function(pc) {
                const cell = row.find(`.field-column[data-field="${pc.dataField}"]`);
                if (cell.length === 0) return;
                const croppedVal = cell.find('.cropped-image-data').val();
                if (croppedVal) {
                    formData.append(pc.croppedParam, croppedVal);
                    hasChanges = true;
                }
                formData.append(pc.currentParam, cell.find('.current-image').val() || '');
            });

            // Document uploads (Aadhaar/Voter/PAN/Birth Cert/Transfer Cert) - actual files, sent as-is
            const documentFields = [
                'father_aadhaar_image', 'father_voter_image', 'father_pan_image',
                'mother_aadhaar_image', 'mother_voter_image', 'mother_pan_image',
                'student_birth_certificate', 'student_aadhaar_image', 'student_transfer_certificate'
            ];
            documentFields.forEach(function(fieldName) {
                const input = row.find(`.document-upload[data-doc-field="${fieldName}"]`)[0];
                if (input && input.files && input.files.length > 0) {
                    formData.append(fieldName, input.files[0]);
                    hasChanges = true;
                }
            });

            if (!hasChanges) {
                toastr.info(`No changes for student ID ${studentId}.`);
                row.removeClass('changed');
                if (callback) callback(true);
                return;
            }

            const btn = row.find('.update-btn');
            const originalBtnText = btn.html();
            btn.html('<i class="fas fa-spinner fa-spin"></i>').prop('disabled', true);

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/put/student/process-bulk-edit-student.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    try {
                        response = typeof response === 'string' ? JSON.parse(response) : response;
                        if (response.success) {
                            toastr.success(`Student ${studentId} updated.`);
                            row.removeClass('changed');
                            fields.forEach(field => {
                                const element = row.find(field.selector);
                                element.data('original-value', element.val());
                                element.removeClass('is-invalid is-valid');
                            });
                            row.find('.validation-feedback').remove();

                            if (response.new_image) {
                                const studentCell = row.find('.field-column[data-field="student_image"]');
                                studentCell.find('.current-image').val(response.new_image);
                                studentCell.find('.cropped-image-data').val('');
                            }
                            if (response.new_father_image) {
                                const fatherCell = row.find('.field-column[data-field="father_image"]');
                                fatherCell.find('.current-image').val(response.new_father_image);
                                fatherCell.find('.cropped-image-data').val('');
                            }
                            if (response.new_mother_image) {
                                const motherCell = row.find('.field-column[data-field="mother_image"]');
                                motherCell.find('.current-image').val(response.new_mother_image);
                                motherCell.find('.cropped-image-data').val('');
                            }
                            if (response.updated_documents) {
                                Object.keys(response.updated_documents).forEach(function(fieldName) {
                                    const cell = row.find(`.field-column[data-field="${fieldName}"]`);
                                    const url = response.updated_documents[fieldName];
                                    cell.find('.document-upload').val('');
                                    const currentLink = cell.find('.doc-current-link');
                                    const newLink = $(`<a href="${url}" target="_blank" class="d-block small mb-1 doc-current-link"><i class="fas fa-eye"></i> View</a>`);
                                    if (currentLink.length) {
                                        currentLink.replaceWith(newLink);
                                    } else {
                                        cell.prepend(newLink);
                                    }
                                });
                            }

                            if (callback) callback(true);
                        } else {
                            toastr.error(response.message || 'Update failed.');
                            if (callback) callback(false);
                        }
                    } catch (e) {
                        toastr.error('Invalid server response.');
                        if (callback) callback(false);
                    }
                },
                error: function(xhr) {
                    toastr.error('An error occurred. Check console.');
                    console.error(xhr.responseText);
                    if (callback) callback(false);
                },
                complete: function() {
                    btn.html(originalBtnText).prop('disabled', false);
                }
            });
        }

        $('.student-row').each(function() {
            const row = $(this);
            row.find('.editable-field').each(function() {
                $(this).data('original-value', $(this).val());
            });
        });

        // Pass PHP data to JS
        const sectionsByClass = <?= json_encode($sectionsByClass) ?>;

        function populateSections(row) {
            const classId = row.find('.class-select').val();
            const sectionSelect = row.find('.section-select');
            const currentSectionId = sectionSelect.data('current-section');

            sectionSelect.empty();
            sectionSelect.append('<option value="">Select Section</option>');

            if (sectionsByClass[classId]) {
                sectionsByClass[classId].forEach(sec => {
                    const isSelected = (sec.id == currentSectionId) ? 'selected' : '';
                    sectionSelect.append(`<option value="${sec.id}" ${isSelected}>${sec.name}</option>`);
                });
            }
        }

        $('.student-row').each(function() {
            populateSections($(this));

            const status = $(this).find('.status-select').val();
            if (status === 'Left' || status === 'Alumni') {
                $(this).find('.roll-no-input').val('').prop('disabled', true);
            }
        });

        $(document).on('change', '.class-select', function() {
            const row = $(this).closest('.student-row');
            row.find('.section-select').data('current-section', '');
            populateSections(row);
            row.find('.roll-no-input').trigger('blur');
        });

        $(document).on('change', '.status-select', function() {
            const row = $(this).closest('.student-row');
            const status = $(this).val();
            const rollInput = row.find('.roll-no-input');

            if (status === 'Left' || status === 'Alumni') {
                rollInput.val('');
                rollInput.prop('disabled', true);
                rollInput.trigger('blur');
                row.addClass('changed');
            } else {
                rollInput.prop('disabled', false);
            }
        });

        $('input[type="text"], input[type="number"], input[type="tel"]').on('focus', function () {
            this.select();
        });

        // Up/Down arrow navigation: moves focus to the same field in the row
        // above/below (vertical equivalent of Tab). <select> fields are
        // excluded so their native up/down option-cycling still works.
        $(document).on('keydown', '.editable-field', function(e) {
            if (this.tagName.toLowerCase() === 'select') {
                return;
            }

            if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') {
                return;
            }

            const currentCell = $(this).closest('td.field-column');
            if (currentCell.length === 0) {
                return;
            }

            const fieldName = currentCell.data('field');
            const currentRow = $(this).closest('tr.student-row');
            const direction = (e.key === 'ArrowDown') ? 'next' : 'prev';

            // Walk row by row in the chosen direction until we find a visible,
            // enabled field in the same column (skips hidden/disabled cells,
            // e.g. a toggled-off column or a disabled roll-no field).
            let targetRow = currentRow[direction]('tr.student-row');
            while (targetRow.length) {
                const targetField = targetRow
                    .find(`td.field-column[data-field="${fieldName}"]`)
                    .find('input.editable-field, textarea.editable-field')
                    .filter(':visible:not(:disabled)')
                    .first();

                if (targetField.length) {
                    e.preventDefault();
                    targetField.trigger('focus');
                    return;
                }

                targetRow = targetRow[direction]('tr.student-row');
            }
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>