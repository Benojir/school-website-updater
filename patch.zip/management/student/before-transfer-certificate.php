<?php
include_once("../../includes/auth-check.php");
require_once("../../includes/header-open.php");
echo "<title>Transfer Certificate Generation - " . $school_name . "</title>";
require_once("../../includes/header-close.php");
require_once("../../includes/dashboard-navbar.php");

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    include_once("../../includes/permission-denied.php");
}

$student_ids_string = $_REQUEST['student_ids'] ?? '';
$student_ids = explode(',', $student_ids_string);

if (empty($student_ids_string) || count($student_ids) == 0) {
    echo "<div class='container mt-4'><div class='alert alert-danger'>No student IDs provided.</div></div>";
    include_once("../../includes/body-close.php");
    exit();
}

$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
    .table-responsive {
        max-height: 500px;
        overflow-y: auto;
        scrollbar-width: thin;
        scrollbar-color: #888 #e0e0e0;
    }

    .table-responsive::-webkit-scrollbar {
        width: 8px;
    }

    /* td কে vertical + horizontal center করা */
    table tr {
        vertical-align: middle;
        /* vertically center */
        text-align: center;
        /* horizontally center */
    }
</style>

<div class="container mt-4">
    <h3 class="m-0 p-0"><i class="fas fa-graduation-cap me-2"></i>School Transfer Certificate</h3>
    <div class="row mt-4">
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h3 class="m-0 p-0"><i class="fas fa-graduation-cap me-2"></i>Transfer Certificate</h3>
                </div>
                <div class="card-body">
                    <div class="form-group mb-3">
                        <label for="promoted_class" class="form-label">Promoted Class:</label>
                        <input type="text" class="form-control" id="promoted_class" name="promoted_class" placeholder="eg: Five" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="date" class="form-label">Date:</label>
                        <input type="date" class="form-control" id="date" name="date" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="reason_for_leaving" class="form-label">Reason for Leaving:</label>
                        <input type="text" class="form-control" id="reason_for_leaving" name="reason_for_leaving" placeholder="Change of School" required>
                    </div>
                    <button type="submit" id="generate-btn" class="btn btn-primary">Generate Certificate</button>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h3 class="m-0 p-0"><i class="fas fa-list me-2"></i>Selected Students</h3>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead class="table-dark">
                                <tr>
                                    <th>Name</th>
                                    <th>Class</th>
                                    <th>Last Class</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                foreach ($student_ids as $student_id) {
                                    $student = getStudentInfo($pdo, $student_id);
                                ?>
                                    <tr id="trow-<?= $student_id ?>">
                                        <td>
                                            <?= $student['name'] ?>
                                            <br>
                                            <small class="text-muted" style="font-size: 0.8rem;"><?= $student['student_id'] ?></small>
                                        </td>
                                        <td><?= $student['class_name'] ?></td>
                                        <td>
                                            <select class="form-control form-control-sm" id="last-class-<?= $student_id ?>">
                                                <?php
                                                foreach ($classes as $class) {
                                                    $selected = $class['id'] == $student['class_id'] ? 'selected' : '';
                                                    echo "<option value='" . $class['id'] . "' " . $selected . ">" . $class['class_name'] . "</option>";
                                                }
                                                ?>
                                            </select>
                                        </td>
                                        <td>
                                            <button class='btn btn-sm btn-danger remove-btn' data-student-id='<?= $student_id ?>'><i class='fas fa-trash'></i></button>
                                        </td>
                                    </tr>
                                <?php
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

        let studentIds = <?= json_encode($student_ids) ?>;

        $('.remove-btn').click(function() {
            var studentId = $(this).data('student-id');
            $('#trow-' + studentId).remove();
            studentIds = studentIds.filter(id => id !== studentId);
        });

        $('#generate-btn').click(function() {
            var promotedClass = $('#promoted_class').val();
            var date = $('#date').val();
            var reasonForLeaving = $('#reason_for_leaving').val();

            if (studentIds.length == 0) {
                showErrorAlert('Please select at least one student.');
                return;
            }

            if (promotedClass == '' || date == '' || reasonForLeaving == '') {
                showErrorAlert('Please fill in all the required fields.');
                return;
            }

            let studentData = [];

            studentIds.forEach(function(studentId) {
                studentData.push({
                    student_id: studentId,
                    last_class: $('#last-class-' + studentId).val(),
                    promoted_class: promotedClass,
                    date: date,
                    reason_for_leaving: reasonForLeaving
                });
            });

            // Create a form
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '<?= BASE_URL ?>/api/download/student-transfer-certificate.php';
            form.target = '_blank';

            // Add the JSON data as a hidden field
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'student_data';
            input.value = JSON.stringify(studentData);
            form.appendChild(input);

            // Add the form to the page and submit
            document.body.appendChild(form);
            form.submit();
            document.body.removeChild(form);
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>