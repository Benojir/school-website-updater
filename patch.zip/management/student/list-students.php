<?php
/** @var PDO $pdo
 * @var string $assets_version
 */
global $pdo, $school_name, $websiteConfig;
include_once("../../includes/auth-check.php");
require_once("../../includes/header-open.php");
echo "<title>Manage Students - " . $school_name . "</title>";
echo '<link rel="stylesheet" href="../../assets/css/list-students.css" />';
require_once("../../includes/header-close.php");
require_once("../../includes/dashboard-navbar.php");

$stmt = $pdo->prepare("SELECT COUNT(*) FROM admission_enquiries");
$stmt->execute();
$count = $stmt->fetchColumn();
$totalAdmissionEnquiries = ($count > 99) ? '99+' : $count;

$stmt = $pdo->prepare("SELECT * FROM classes");
$stmt->execute();
$classes = $stmt->fetchAll();
?>

<div class="container mt-4">
    <!-- Action cards container -->
    <div class="container p-0">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="mb-0"><i class="fas fa-users me-2"></i>Student Management</h1>
            <a href="../academic/manage-admission-enquiries.php">
                <button type="button" class="btn btn-primary position-relative">
                    Admission Enquiry
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        <?= $totalAdmissionEnquiries; ?>
                    </span>
                </button>
            </a>
        </div>

        <!-- Filter Card -->
        <div class="card shadow-sm mb-4 p-0">
            <div class="card-header bg-primary text-white">
                <i class="fas fa-filter me-2"></i>Filter Students
            </div>
            <div class="card-body">
                <form id="filterForm" class="row g-3">
                    <!-- Search Field -->
                    <div class="col-md-4">
                        <label for="search" class="form-label">Search</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" name="search" id="search" class="form-control" placeholder="Search student... (CTRL+ /)">
                            <span id="clear-search-box" class="input-group-text bg-white" style="cursor: pointer; display: none;"><i class="fas fa-close"></i></span>
                        </div>
                    </div>

                    <!-- Class Filter -->
                    <div class="col-md-2">
                        <label for="classFilter" class="form-label">Class</label>
                        <select name="class" id="classFilter" class="form-select" onchange="updateSectionOptions()">
                            <option value="">All Classes</option>
                            <!-- Will be populated by JavaScript -->
                        </select>
                    </div>

                    <!-- Section Filter -->
                    <div class="col-md-2">
                        <label for="sectionFilter" class="form-label">Section</label>
                        <select name="section" id="sectionFilter" class="form-select">
                            <option value="">All Sections</option>
                            <!-- Will be populated by JavaScript -->
                        </select>
                    </div>

                    <!-- Gender Filter -->
                    <div class="col-md-2">
                        <label for="genderFilter" class="form-label">Gender</label>
                        <select name="gender" id="genderFilter" class="form-select">
                            <option value="">All Genders</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <!-- Status Filter -->
                    <div class="col-md-2">
                        <label for="statusFilter" class="form-label">Status</label>
                        <select name="status" id="statusFilter" class="form-select">
                            <option value="Active">Active</option>
                            <option value="">All Statuses</option>
                            <option value="Left">Left</option>
                            <option value="Alumni">Alumni</option>
                        </select>
                    </div>

                    <!-- Monthly Fee Status Filter -->
                    <div class="col-md-2">
                        <label for="monthlyFeeStatusFilter" class="form-label">Monthly Fees Status</label>
                        <select name="monthly_fee_status" id="monthlyFeeStatusFilter" class="form-select" onchange="setEmptyOptionToFeeStatusFilter('admissionFeeStatusFilter')">
                            <option value="">All Fee Statuses</option>
                            <option value="paid">Has Paid Fees</option>
                            <option value="unpaid">Has Unpaid Fees</option>
                            <option value="fully_paid">Fully Paid</option>
                        </select>
                    </div>

                    <!-- Admission Fee Status Filter -->
                    <div class="col-md-2">
                        <label for="admissionFeeStatusFilter" class="form-label">Admission Fees Status</label>
                        <select name="admission_fee_status" id="admissionFeeStatusFilter" class="form-select" onchange="setEmptyOptionToFeeStatusFilter('monthlyFeeStatusFilter')">
                            <option value="">All Fee Statuses</option>
                            <option value="paid">Has Paid Fees</option>
                            <option value="unpaid">Has Unpaid Fees</option>
                            <option value="fully_paid">Fully Paid</option>
                        </select>
                    </div>

                    <!-- Hosteler Filter -->
                    <div class="col-md-2">
                        <label for="hostelerFilter" class="form-label">Hosteler</label>
                        <select name="hosteler" id="hostelerFilter" class="form-select">
                            <option value="">All</option>
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label for="coachingFilter" class="form-label">Coaching</label>
                        <select name="coaching" id="coachingFilter" class="form-select">
                            <option value="">All</option>
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label for="tiffinFilter" class="form-label">Tiffin</label>
                        <select name="tiffin" id="tiffinFilter" class="form-select">
                            <option value="">All</option>
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <label for="customFeeFilter" class="form-label">Custom Fee</label>
                        <select name="customFee" id="customFeeFilter" class="form-select">
                            <option value="">All</option>
                            <option value="1">Has Custom Fee</option>
                            <option value="0">No Custom Fee</option>
                        </select>
                    </div>

                    <!-- Car Route Filter -->
                    <div class="col-md-2">
                        <label for="carRouteFilter" class="form-label">Uses School Car</label>
                        <select name="car_route" id="carRouteFilter" class="form-select">
                            <option value="">All</option>
                            <option value="has_route">Yes</option>
                            <option value="no_route">No</option>
                        </select>
                    </div>

                    <!-- Driver Wise Filter -->
                    <div class="col-md-2">
                        <label for="driverByFilter" class="form-label">Driver</label>
                        <select name="driver_id" id="driverByFilter" class="form-select">
                            <option value="">All Drivers</option>
                            <?php
                            // Fetch drivers from the database
                            $drivers = $pdo->query("SELECT id, name FROM drivers")->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($drivers as $driver) {
                                echo "<option value=\"{$driver['id']}\">{$driver['name']}</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <!-- Sort by -->
                    <div class="col-md-2">
                        <label for="sortByFilter" class="form-label">Sort By</label>
                        <select name="sort_by" id="sortByFilter" class="form-select">
                            <option value="roll_number_asc">Roll Number (Low to High)</option>
                            <option value="roll_number_desc">Roll Number (High to Low)</option>
                            <option value="student_name_asc">Student Name (A-Z)</option>
                            <option value="student_name_desc">Student Name (Z-A)</option>
                            <option value="registration_number_asc">Reg No (ASC)</option>
                            <option value="registration_number_desc">Reg No (DESC)</option>
                            <option value="pending_fee_desc">Pending Fee (High to Low)</option>
                            <option value="pending_fee_asc">Pending Fee (Low to High)</option>
                            <option value="">Recent Added</option>
                        </select>
                    </div>

                    <!-- Filter by academic year-->
                    <div class="col-md-2">
                        <label for="academicYearFilter" class="form-label">Academic Year</label>
                        <select name="academic_year" id="academicYearFilter" class="form-select">
                            <option value="">All Academic Years</option>
                            <?php
                            $academicYears = json_decode(generateAcademicYear(), true);
                            foreach ($academicYears as $academicYear) {
                                echo "<option value=\"{$academicYear}\">{$academicYear}</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <!-- Paid Month Filter -->
                    <div class="col-md-2">
                        <label for="paidMonthFilter" class="form-label">Paid Month</label>
                        <select name="paid_month" id="paidMonthFilter" class="form-select">
                            <option value="">Default</option>
                            <?php
                            $currentYear = date('Y'); // অথবা সরাসরি "2026" fix করেও দিতে পারেন
                            for ($m = 1; $m <= 12; $m++) {
                                $monthLabel = date('F', mktime(0, 0, 0, $m, 1)) . ' ' . $currentYear;
                                echo "<option value=\"" . htmlspecialchars($monthLabel) . "\">" . htmlspecialchars($monthLabel) . "</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <!-- Action Buttons -->
                    <div class="col-md-1 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary me-2" title="Apply Filters">
                            <i class="fas fa-filter"></i>
                        </button>
                        <button type="button" id="resetFilters" class="btn btn-outline-secondary" title="Reset Filters (CTRL+ L)">
                            <i class="fas fa-sync"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Bulk Actions Panel -->
        <div class="bulk-actions card shadow-sm mb-4" id="bulkActionsPanel">
            <div class="card-body">
                <div class="d-flex justify-content-between mb-2">
                    <span class="selected-count me-3" id="selectedCount">0 selected</span>
                    <button class="btn btn-outline-danger btn-sm" id="clearSelection" title="Clear selections (CTRL+ K)">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="d-flex flex-wrap align-content-center align-items-center">
                    <button class="btn btn-primary bulk-action-buttons" id="bulkEditStudents">
                        <i class="fa-solid fa-user-pen me-1"></i> Edit Students
                    </button>

                    <div class="btn-group bulk-action-buttons" role="group">
                        <button type="button" class="btn btn-info dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-graduation-cap me-1"></i> Academic Actions
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="javascript:void(0)" id="bulkPromoteStudents"><i class="fa-solid fa-user-graduate me-2 text-primary"></i> Promote Students</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="addBulkResults"><i class="fas fa-plus-circle me-2 text-primary"></i> Students Mark Entry</a></li>
                            <!-- <li><a class="dropdown-item" href="javascript:void(0)" id="manageAttendanceBtn" data-bs-toggle="modal" data-bs-target="#manageAttendanceModal"><i class="fa-solid fa-calendar-check me-2 text-primary"></i> Manage Attendance</a></li> -->
                        </ul>
                    </div>

                    <div class="btn-group bulk-action-buttons" role="group">
                        <button type="button" class="btn btn-success dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-dollar-sign me-1"></i> Financial Actions
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="javascript:void(0)" onclick="openFeesEntryPage(getSelectedStudentIds(), 'monthly')"><i class="fa-solid fa-money-bill-1-wave me-2 text-success"></i> Request Monthly Fees</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" onclick="openPaymentsEntryPage(getSelectedStudentIds(), 'monthly')"><i class="fa-solid fa-money-bill-1-wave me-2 text-success"></i> Monthly Payments Entry</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" onclick="fetchFullyUnpaidFees(getSelectedStudentIds(), 'monthly')"><i class="fa-solid fa-money-bill-1-wave me-2 text-success"></i> Unpaid Monthly Fees</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="javascript:void(0)" onclick="openFeesEntryPage(getSelectedStudentIds(), 'admission')"><i class="fa-solid fa-money-bills me-2 text-success"></i> Request Admission Fees</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" onclick="openPaymentsEntryPage(getSelectedStudentIds(), 'admission')"><i class="fa-solid fa-money-bills me-2 text-success"></i> Admission Payments Entry</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" onclick="fetchFullyUnpaidFees(getSelectedStudentIds(), 'admission')"><i class="fa-solid fa-money-bills me-2 text-success"></i> Unpaid Admission Fees</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="javascript:void(0)" onclick="openManageAdditionalFeesAndPaymentsModal(getSelectedStudentIds(), null, getSelectedClassIds())"><i class="fa-solid fa-money-bill-transfer me-2 text-success"></i> Manage Extra Additional Fees</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="manageWalletBtn" data-bs-toggle="modal" data-bs-target="#manageWalletModal"><i class="fa-solid fa-wallet me-2 text-success"></i> Manage Wallet</a></li>
                        </ul>
                    </div>

                    <div class="btn-group bulk-action-buttons" role="group">
                        <button type="button" class="btn btn-secondary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-download me-1"></i> Downloads & Reports
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="javascript:void(0)" id="downloadIdCards"><i class="fas fa-id-card me-2 text-secondary"></i> Student ID Cards</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="downloadTransportIdCards"><i class="fas fa-id-card me-2 text-secondary"></i> Transport ID Cards</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="downloadAdmitCards"><i class="fas fa-file-alt me-2 text-secondary"></i> Admit Cards</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" onclick="downloadAdmissionForm(null)"><i class="fas fa-file-download me-2 text-secondary"></i> Admission Form</a></li>
                            <li data-bs-toggle="modal" data-bs-target="#exportDataOptionsModal"><a class="dropdown-item" href="javascript:void(0)"><i class="fa-solid fa-file-arrow-down me-2 text-secondary"></i> Students' Data</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" onclick="downloadStudentsFullData()"><i class="fa-solid fa-file-arrow-down me-2 text-secondary"></i> Students' Register Record</a></li>
                            <li data-bs-toggle="modal" data-bs-target="#marksheetsDownloadModal"><a class="dropdown-item" href="javascript:void(0)"><i class="fas fa-file-pdf me-2 text-secondary"></i> Marksheets</a></li>
                            <li id="transferCertificateDownload"><a class="dropdown-item" href="javascript:void(0)"><i class="fas fa-file-pdf me-2 text-secondary"></i> Transfer Certificate</a></li>
                            <li id="pendingFeesReceiptDownload"><a class="dropdown-item" href="javascript:void(0)"><i class="fas fa-file-pdf me-2 text-secondary"></i> Unpaid Fees Receipt</a></li>
                        </ul>
                    </div>

                    <div class="btn-group bulk-action-buttons" role="group">
                        <button type="button" class="btn btn-warning dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-cogs me-1"></i> Admin Actions
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="javascript:void(0)" id="bulkEditPermissions"><i class="fas fa-key me-2 text-warning"></i> Edit Permissions</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="sendNotificationsBtn" data-bs-toggle="modal" data-bs-target="#sendNotificationsModal"><i class="fa-solid fa-bell me-2 text-warning"></i> Send Notifications</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="sendPaymentRemindersBtn" data-bs-toggle="modal" data-bs-target="#sendPaymentRemindersModal"><i class="fa-solid fa-bell me-2 text-warning"></i> Send Payment Reminders</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="activateStudentsBtn" onclick="confirmActive(getSelectedStudentIds(), null)"><i class="fa-solid fa-user-xmark me-2 text-warning"></i> Activate Students</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="deactivateStudentsBtn" onclick="confirmDeactive(getSelectedStudentIds(), null)"><i class="fa-solid fa-user-xmark me-2 text-warning"></i> Deactivate Students</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="deleteStudentsBtn" onclick="confirmDelete(getSelectedStudentIds(), null)"><i class="fas fa-trash-alt me-2 text-warning"></i> Delete Students</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mb-5">
    <!-- Student Table Container With Counter-->
    <div class="table-data-container shadow-lg rounded" style="border: 1px solid #e0e0e0;">
        <!-- Results Summary -->
        <div class="d-flex justify-content-between align-items-center p-3 results-summary">
            <!-- Will be updated via JavaScript -->
        </div>

        <!-- Student Table -->
        <div class="table-responsive">
            <table class="table table-striped table-hover table-bordered text-center align-middle table-sm">
                <thead class="table-dark">
                    <tr>
                        <th width="40">
                            <input type="checkbox" class="form-check-input select-all-checkbox" id="selectAll">
                        </th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Class</th>
                        <th>Father</th>
                        <th>Mother</th>
                        <th>Address</th>
                        <th title="Additional Information">A. Info</th>
                        <th>Status</th>
                        <th>Fee Info</th>
                        <th>Due</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="studentsTableBody">
                    <!-- Students will be loaded here via AJAX -->
                    <tr>
                        <td colspan="12" class="text-center py-4">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>


    <!-- Pagination -->
    <nav aria-label="Page navigation" class="mt-4">
        <ul class="pagination justify-content-center" id="paginationContainer">
            <!-- Will be updated via JavaScript -->
        </ul>
    </nav>
</div>


<?php
include_once __DIR__ . '/../../includes/modals/student/marksheet-download-chooser-modal.php';
include_once __DIR__ . '/../../includes/modals/student/fees-related-modals.php';
include_once __DIR__ . '/../../includes/modals/student/student-permission-management-modal.php';
include_once __DIR__ . '/../../includes/modals/student/mobile-notification-sending-form-modal.php';
include_once __DIR__ . '/../../includes/modals/student/student-wallet-editor-modal.php';
include_once __DIR__ . '/../../includes/modals/student/student-attendance-management-modal.php';
include_once __DIR__ . '/../../includes/modals/student/student-action-options-modal.php';
include_once __DIR__ . '/../../includes/modals/student/student-export-data-options-modal.php';
include_once __DIR__ . '/../../includes/modals/student/payment-reminder-modal.php';
?>


<script>
    // Global constant variables
    const currencySymbol = "<?= $websiteConfig['currency_symbol'] ?>";
    const now = new Date();

    // Initialize variables
    let globalSelectedStudents = [];
    let singleStudentId = null;
    let isFeeStatusSelectionResetting = false;
    let currentPage = 1;
    let totalPages = 1;
    let totalStudents = 0;
    let filterParams = {};

    // Initialize multiple dates picker
    const datePicker = flatpickr("#attendance_dates", {
        mode: "multiple",
        dateFormat: "Y-m-d"
    });

    $(document).ready(function() {
        // Load initial data
        loadInitialData();

        // Set default time to current time
        $('#attendance_time').val(now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0'))
    });
</script>


<!-- ---------------------------------Required Functions-------------------------------------------------- -->
<script defer src="../../assets/js/student/list-students/functions/student-related-basic-functions.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/functions/student-filter-related-functions.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/functions/student-selection-related-functions.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/functions/student-financial-related-functions.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/functions/student-download-permissions-related-functions.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/functions/student-academic-related-functions.js?v=<?= $assets_version ?>"></script>

<!-- ------------------------------------Required Events-------------------------------------------------- -->
<script defer src="../../assets/js/student/list-students/events/academic-related-events.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/events/filter-related-events.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/events/selection-related-events.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/events/financial-related-events.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/events/download-permissions-related-events.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/events/exam-related-events.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/events/notification-related-events.js?v=<?= $assets_version ?>"></script>

<?php include_once("../../includes/body-close.php"); ?>