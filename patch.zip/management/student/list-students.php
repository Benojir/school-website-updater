<?php

/** @var PDO $pdo
 * @var string $assets_version
 */
global $pdo, $school_name, $websiteConfig;
include_once("../../includes/auth-check.php");
require_once("../../includes/header-open.php");
echo "<title>Manage Students - " . $school_name . "</title>";
echo '<link rel="stylesheet" href="../../assets/css/list-students.css" />';
if (hasPermission(PERM_MANAGE_INVENTORY)) {
    echo '<link rel="stylesheet" href="../../assets/css/inventory.css?v=' . $assets_version . '" />';
}
require_once("../../includes/header-close.php");
require_once("../../includes/dashboard-navbar.php");

$canManageInventory = hasPermission(PERM_MANAGE_INVENTORY);
if ($canManageInventory) {
    $_SESSION['inventory_csrf'] ??= bin2hex(random_bytes(32));
}

$stmt = $pdo->prepare("SELECT COUNT(*) FROM admission_enquiries");
$stmt->execute();
$count = $stmt->fetchColumn();
$totalAdmissionEnquiries = ($count > 99) ? '99+' : $count;

$stmt = $pdo->prepare("SELECT * FROM classes");
$stmt->execute();
$classes = $stmt->fetchAll();
?>

<div class="container mt-4">
    <!-- Action cards container -->
    <div class="container p-0">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="mb-0"><i class="fas fa-users me-2"></i>Student Management</h1>
            <a href="../academic/manage-admission-enquiries.php">
                <button type="button" class="btn btn-primary position-relative">
                    Admission Enquiry
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        <?= $totalAdmissionEnquiries; ?>
                    </span>
                </button>
            </a>
        </div>

        <form id="filterForm">
            <!-- Filter Card -->
            <div class="card shadow-sm mb-2 p-0">
                <!-- হেডার অংশে টগল ফিচার যুক্ত করা হলো -->
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center"
                    data-bs-toggle="collapse"
                    data-bs-target="#filterCollapseBody"
                    aria-expanded="true"
                    style="cursor: pointer;"
                    title="Click to toggle filters">
                    <div>
                        <i class="fas fa-filter me-2"></i>Filter Students
                    </div>
                    <!-- টগল আইকন -->
                    <i class="fas fa-chevron-up" id="filterToggleIcon"></i>
                </div>

                <!-- collapse ক্লাস যুক্ত করে ডিভ র‍্যাপ করা হলো -->
                <div id="filterCollapseBody" class="collapse show">
                    <div class="card-body">
                        <div class="row g-3">
                            <!-- Search Field -->
                            <!-- <div class="col-md-4">
                                <label for="search" class="form-label">Search</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                    <input type="text" name="search" id="search" class="form-control" placeholder="Search student... (CTRL+ /)">
                                    <span id="clear-search-box" class="input-group-text bg-white" style="cursor: pointer; display: none;"><i class="fas fa-close"></i></span>
                                </div>
                            </div> -->

                            <!-- Class Filter -->
                            <div class="col-6 col-md-2">
                                <label for="classFilter" class="form-label">Class</label>
                                <select name="class" id="classFilter" class="form-select" onchange="updateSectionOptions()">
                                    <option value="">All Classes</option>
                                    <!-- Will be populated by JavaScript -->
                                </select>
                            </div>

                            <!-- Section Filter -->
                            <div class="col-6 col-md-2">
                                <label for="sectionFilter" class="form-label">Section</label>
                                <select name="section" id="sectionFilter" class="form-select">
                                    <option value="">All Sections</option>
                                    <!-- Will be populated by JavaScript -->
                                </select>
                            </div>

                            <!-- Gender Filter -->
                            <div class="col-6 col-md-2">
                                <label for="genderFilter" class="form-label">Gender</label>
                                <select name="gender" id="genderFilter" class="form-select">
                                    <option value="">All Genders</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>

                            <!-- Status Filter -->
                            <div class="col-6 col-md-2">
                                <label for="statusFilter" class="form-label">Status</label>
                                <select name="status" id="statusFilter" class="form-select">
                                    <option value="Active">Active</option>
                                    <option value="">All Statuses</option>
                                    <option value="Left">Left</option>
                                    <option value="Alumni">Alumni</option>
                                </select>
                            </div>

                            <!-- Monthly Fee Status Filter -->
                            <div class="col-6 col-md-2">
                                <label for="monthlyFeeStatusFilter" class="form-label">Monthly Fees Status</label>
                                <select name="monthly_fee_status" id="monthlyFeeStatusFilter" class="form-select" onchange="setEmptyOptionToFeeStatusFilter('admissionFeeStatusFilter')">
                                    <option value="">All Fee Statuses</option>
                                    <option value="paid">Has Paid Fees</option>
                                    <option value="unpaid">Has Unpaid Fees</option>
                                    <option value="fully_paid">Fully Paid</option>
                                </select>
                            </div>

                            <!-- Admission Fee Status Filter -->
                            <div class="col-6 col-md-2">
                                <label for="admissionFeeStatusFilter" class="form-label">Admission Fees Status</label>
                                <select name="admission_fee_status" id="admissionFeeStatusFilter" class="form-select" onchange="setEmptyOptionToFeeStatusFilter('monthlyFeeStatusFilter')">
                                    <option value="">All Fee Statuses</option>
                                    <option value="paid">Has Paid Fees</option>
                                    <option value="unpaid">Has Unpaid Fees</option>
                                    <option value="fully_paid">Fully Paid</option>
                                </select>
                            </div>

                            <!-- Hosteler Filter -->
                            <div class="col-6 col-md-2">
                                <label for="hostelerFilter" class="form-label">Hosteler</label>
                                <select name="hosteler" id="hostelerFilter" class="form-select">
                                    <option value="">All</option>
                                    <option value="1">Yes</option>
                                    <option value="0">No</option>
                                </select>
                            </div>

                            <div class="col-6 col-md-2">
                                <label for="coachingFilter" class="form-label">Coaching</label>
                                <select name="coaching" id="coachingFilter" class="form-select">
                                    <option value="">All</option>
                                    <option value="1">Yes</option>
                                    <option value="0">No</option>
                                </select>
                            </div>

                            <div class="col-6 col-md-2">
                                <label for="tiffinFilter" class="form-label">Tiffin</label>
                                <select name="tiffin" id="tiffinFilter" class="form-select">
                                    <option value="">All</option>
                                    <option value="1">Yes</option>
                                    <option value="0">No</option>
                                </select>
                            </div>

                            <div class="col-6 col-md-2">
                                <label for="customFeeFilter" class="form-label">Custom Fee</label>
                                <select name="customFee" id="customFeeFilter" class="form-select">
                                    <option value="">All</option>
                                    <option value="1">Has Custom Fee</option>
                                    <option value="0">No Custom Fee</option>
                                </select>
                            </div>

                            <!-- Car Route Filter -->
                            <div class="col-6 col-md-2">
                                <label for="carRouteFilter" class="form-label">Uses School Car</label>
                                <select name="car_route" id="carRouteFilter" class="form-select">
                                    <option value="">All</option>
                                    <option value="has_route">Yes</option>
                                    <option value="no_route">No</option>
                                </select>
                            </div>

                            <!-- Driver Wise Filter -->
                            <div class="col-6 col-md-2">
                                <label for="driverByFilter" class="form-label">Driver</label>
                                <select name="driver_id" id="driverByFilter" class="form-select select2">
                                    <option value="">All Drivers</option>
                                    <?php
                                    // Fetch drivers from the database
                                    $drivers = $pdo->query("SELECT id, name FROM drivers")->fetchAll(PDO::FETCH_ASSOC);
                                    foreach ($drivers as $driver) {
                                        echo "<option value=\"{$driver['id']}\">{$driver['name']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>

                            <!-- Sort by -->
                            <div class="col-6 col-md-2">
                                <label for="sortByFilter" class="form-label">Sort By</label>
                                <select name="sort_by" id="sortByFilter" class="form-select">
                                    <option value="roll_number_asc">Roll Number (Low to High)</option>
                                    <option value="roll_number_desc">Roll Number (High to Low)</option>
                                    <option value="student_name_asc">Student Name (A-Z)</option>
                                    <option value="student_name_desc">Student Name (Z-A)</option>
                                    <option value="registration_number_asc">Reg No (ASC)</option>
                                    <option value="registration_number_desc">Reg No (DESC)</option>
                                    <option value="pending_fee_desc">Pending Fee (High to Low)</option>
                                    <option value="pending_fee_asc">Pending Fee (Low to High)</option>
                                    <option value="">Recent Added</option>
                                </select>
                            </div>

                            <!-- Filter by academic year-->
                            <div class="col-6 col-md-2">
                                <label for="academicYearFilter" class="form-label">Academic Year</label>
                                <select name="academic_year" id="academicYearFilter" class="form-select">
                                    <option value="">All Years</option>
                                    <?php
                                    $academicYears = $pdo->query('SELECT DISTINCT academic_year FROM student_academic_records WHERE academic_year IS NOT NULL ORDER BY academic_year DESC')->fetchAll(PDO::FETCH_COLUMN);
                                    foreach ($academicYears as $academicYear) {
                                        echo '<option value="' . safe_htmlspecialchars($academicYear) . '"' . ($academicYear === academicCurrentYear($pdo) ? ' selected' : '') . '>' . safe_htmlspecialchars($academicYear) . '</option>';
                                    }
                                    ?>
                                </select>
                            </div>

                            <!-- Paid Month Filter -->
                            <div class="col-6 col-md-2">
                                <label for="paidMonthFilter" class="form-label">Paid Month</label>
                                <select name="paid_month" id="paidMonthFilter" class="form-select">
                                    <option value="">Default</option>
                                    <?php
                                    $currentYear = date('Y'); // অথবা সরাসরি "2026" fix করেও দিতে পারেন
                                    for ($m = 1; $m <= 12; $m++) {
                                        $monthLabel = date('F', mktime(0, 0, 0, $m, 1)) . ' ' . $currentYear;
                                        echo "<option value=\"" . htmlspecialchars($monthLabel) . "\">" . htmlspecialchars($monthLabel) . "</option>";
                                    }
                                    ?>
                                </select>
                            </div>

                            <!-- Unpaid Month Filter -->
                            <div class="col-6 col-md-2">
                                <label for="unpaidMonthFilter" class="form-label">Unpaid Month</label>
                                <select name="unpaid_month" id="unpaidMonthFilter" class="form-select">
                                    <option value="">Default</option>
                                    <?php
                                    $currentYear = date('Y');
                                    for ($m = 1; $m <= 12; $m++) {
                                        $monthLabel = date('F', mktime(0, 0, 0, $m, 1)) . ' ' . $currentYear;
                                        echo "<option value=\"" . htmlspecialchars($monthLabel) . "\">" . htmlspecialchars($monthLabel) . "</option>";
                                    }
                                    ?>
                                </select>
                            </div>

                            <!-- Additional Fee Status Filter -->
                            <div class="col-6 col-md-2">
                                <label for="additionalFeeStatusFilter" class="form-label">Additional Fees Status</label>
                                <select name="additional_fee_status" id="additionalFeeStatusFilter" class="form-select">
                                    <option value="">All Fee Statuses</option>
                                    <option value="paid">Has Paid Fees</option>
                                    <option value="unpaid">Has Unpaid Fees</option>
                                    <option value="fully_paid">Fully Paid</option>
                                </select>
                            </div>

                            <!-- Inventory Due Status Filter -->
                            <div class="col-6 col-md-2">
                                <label for="inventoryDueStatusFilter" class="form-label">Inventory Due Status</label>
                                <select name="inventory_due_status" id="inventoryDueStatusFilter" class="form-select">
                                    <option value="">All Due Statuses</option>
                                    <option value="unpaid">Has Unpaid Due</option>
                                    <option value="paid">Has Paid Purchases</option>
                                    <option value="fully_paid">Fully Paid</option>
                                </select>
                            </div>

                            <?php
                            // Additional fee setups, used by both dropdowns below. Fee types are
                            // defined per class, so the class name is shown to keep them apart.
                            $additionalFeeSetups = $pdo->query("
                                SELECT cwaf.id, cwaf.fee_type, cwaf.amount, c.class_name
                                FROM class_wise_additional_fees cwaf
                                LEFT JOIN classes c ON cwaf.class_id = c.id
                                ORDER BY c.id ASC, cwaf.fee_type ASC
                            ")->fetchAll(PDO::FETCH_ASSOC);

                            $additionalFeeOptions = '';
                            foreach ($additionalFeeSetups as $setup) {
                                $setup_amount = (float) $setup['amount'];
                                $amount_label = $setup_amount == (int) $setup_amount
                                    ? (string) (int) $setup_amount
                                    : number_format($setup_amount, 2);

                                $label = $setup['fee_type'] . ' - ' . ($setup['class_name'] ?? 'No Class') . ' (' . $currency_symbol . $amount_label . ')';
                                $additionalFeeOptions .= '<option value="' . (int) $setup['id'] . '">' . safe_htmlspecialchars($label) . '</option>';
                            }
                            ?>

                            <!-- Paid Additional Fee Filter -->
                            <div class="col-6 col-md-2">
                                <label for="paidAdditionalFeeFilter" class="form-label">Paid Additional Fee</label>
                                <select name="paid_additional_fee" id="paidAdditionalFeeFilter" class="form-select">
                                    <option value="">Default</option>
                                    <?= $additionalFeeOptions ?>
                                </select>
                            </div>

                            <!-- Unpaid Additional Fee Filter -->
                            <div class="col-6 col-md-2">
                                <label for="unpaidAdditionalFeeFilter" class="form-label">Unpaid Additional Fee</label>
                                <select name="unpaid_additional_fee" id="unpaidAdditionalFeeFilter" class="form-select">
                                    <option value="">Default</option>
                                    <?= $additionalFeeOptions ?>
                                </select>
                            </div>

                            <!-- Action Buttons -->
                            <div class="col-md-1 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary me-2" title="Apply Filters">
                                    <i class="fas fa-filter"></i>
                                </button>
                                <button type="button" id="resetFilters" class="btn btn-outline-secondary" title="Reset Filters (CTRL+ L)">
                                    <i class="fas fa-sync"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card shadow-sm mb-2 p-0">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <div>
                        <i class="fas fa-graduation-cap me-2"></i>Search students
                    </div>
                </div>
                <div class="card-body">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" name="search" id="search" class="form-control" placeholder="Search student... (CTRL+ /)">
                        <span id="clear-search-box" class="input-group-text bg-white" style="cursor: pointer; display: none;"><i class="fas fa-close"></i></span>
                    </div>
                </div>
            </div>
        </form>

        <!-- Bulk Actions Panel -->
        <div class="bulk-actions card shadow-sm mb-2" id="bulkActionsPanel">
            <div class="card-body">
                <div class="d-flex justify-content-between mb-2">
                    <span class="selected-count me-3" id="selectedCount">0 selected</span>
                    <button class="btn btn-outline-danger btn-sm" id="clearSelection" title="Clear selections (CTRL+ K)">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="d-flex flex-wrap align-content-center align-items-center">
                    <button class="btn btn-primary bulk-action-buttons" id="bulkEditStudents">
                        <i class="fa-solid fa-user-pen me-1"></i> Edit Students
                    </button>

                    <div class="btn-group bulk-action-buttons" role="group">
                        <button type="button" class="btn btn-info dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-graduation-cap me-1"></i> Academic Actions
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="javascript:void(0)" id="bulkPromoteStudents"><i class="fa-solid fa-user-graduate me-2 text-primary"></i> Promote Students</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="addBulkResults"><i class="fas fa-plus-circle me-2 text-primary"></i> Students Mark Entry</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="manageAttendanceBtn"><i class="fa-solid fa-calendar-check me-2 text-primary"></i> Manage Attendance</a></li>
                        </ul>
                    </div>

                    <div class="btn-group bulk-action-buttons" role="group">
                        <button type="button" class="btn btn-success dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-dollar-sign me-1"></i> Financial Actions
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="javascript:void(0)" onclick="openFeesEntryPage(getSelectedStudentIds(), 'monthly')"><i class="fa-solid fa-money-bill-1-wave me-2 text-success"></i> Request Fees (Monthly)</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" onclick="openPaymentsEntryPage(getSelectedStudentIds(), 'monthly')"><i class="fa-solid fa-money-bill-1-wave me-2 text-success"></i> Collect Fees (Monthly)</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" onclick="fetchFullyUnpaidFees(getSelectedStudentIds(), 'monthly')"><i class="fa-solid fa-money-bill-1-wave me-2 text-success"></i> Unpaid Fees (Monthly)</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="javascript:void(0)" onclick="openFeesEntryPage(getSelectedStudentIds(), 'admission')"><i class="fa-solid fa-money-bills me-2 text-success"></i> Request Fees (Admission)</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" onclick="openPaymentsEntryPage(getSelectedStudentIds(), 'admission')"><i class="fa-solid fa-money-bills me-2 text-success"></i> Collect Fees (Admission)</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" onclick="fetchFullyUnpaidFees(getSelectedStudentIds(), 'admission')"><i class="fa-solid fa-money-bills me-2 text-success"></i> Unpaid Fees (Admission)</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="manageWalletBtn" data-bs-toggle="modal" data-bs-target="#manageWalletModal"><i class="fa-solid fa-wallet me-2 text-success"></i> Manage Wallet</a></li>
                        </ul>
                    </div>

                    <div class="btn-group bulk-action-buttons" role="group">
                        <button type="button" class="btn btn-secondary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-download me-1"></i> Downloads & Reports
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="javascript:void(0)" id="downloadIdCards"><i class="fas fa-id-card me-2 text-secondary"></i> Student ID Cards</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="downloadTransportIdCards"><i class="fas fa-id-card me-2 text-secondary"></i> Transport ID Cards</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="downloadAdmitCards"><i class="fas fa-file-alt me-2 text-secondary"></i> Admit Cards</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" onclick="downloadAdmissionForm(null)"><i class="fas fa-file-download me-2 text-secondary"></i> Admission Form</a></li>
                            <li data-bs-toggle="modal" data-bs-target="#exportDataOptionsModal"><a class="dropdown-item" href="javascript:void(0)"><i class="fa-solid fa-file-arrow-down me-2 text-secondary"></i> Students' Data</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" onclick="downloadStudentsFullData()"><i class="fa-solid fa-file-arrow-down me-2 text-secondary"></i> Students' Register Record</a></li>
                            <li data-bs-toggle="modal" data-bs-target="#marksheetsDownloadModal"><a class="dropdown-item" href="javascript:void(0)"><i class="fas fa-file-pdf me-2 text-secondary"></i> Marksheets</a></li>
                            <li id="transferCertificateDownload"><a class="dropdown-item" href="javascript:void(0)"><i class="fas fa-file-pdf me-2 text-secondary"></i> Transfer Certificate</a></li>
                            <li id="pendingFeesReceiptDownload"><a class="dropdown-item" href="javascript:void(0)"><i class="fas fa-file-pdf me-2 text-secondary"></i> Unpaid Fees Receipt</a></li>
                            <li id="studentsWithDuesDownload"><a class="dropdown-item" href="javascript:void(0)"><i class="fas fa-file-invoice-dollar me-2 text-secondary"></i> Students Dues List</a></li>
                        </ul>
                    </div>

                    <div class="btn-group bulk-action-buttons" role="group">
                        <button type="button" class="btn btn-purple dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-download me-1"></i> Sheets Download
                        </button>
                        <ul class="dropdown-menu">
                            <li class="dropdown-item cursor-pointer" onclick="chooseExamAndDownloadMarkEntrySheet(examsData)"><i class="fas fa-file-pdf me-2 text-secondary"></i> Marks Entry Sheet</li>
                            <li><button type="button" class="dropdown-item" onclick="chooseExamAndDownloadAttendanceRecord(examsData)"><i class="fas fa-clipboard-check me-2 text-secondary"></i> Exam Attendance Record</button></li>
                            <li id="downloadPassportPhotos"><a class="dropdown-item" href="javascript:void(0)"><i class="fas fa-portrait me-2 text-secondary"></i> Passport Size Photos</a></li>
                        </ul>
                    </div>

                    <div class="btn-group bulk-action-buttons" role="group">
                        <button type="button" class="btn btn-warning dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-cogs me-1"></i> Admin Actions
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="javascript:void(0)" id="bulkEditPermissions"><i class="fas fa-key me-2 text-warning"></i> Edit Permissions</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="sendNotificationsBtn" data-bs-toggle="modal" data-bs-target="#sendNotificationsModal"><i class="fa-solid fa-bell me-2 text-warning"></i> Send Notifications</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="sendPaymentRemindersBtn" data-bs-toggle="modal" data-bs-target="#sendPaymentRemindersModal"><i class="fa-solid fa-bell me-2 text-warning"></i> Send Payment Reminders</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="activateStudentsBtn" onclick="confirmActive(getSelectedStudentIds(), null)"><i class="fa-solid fa-user-xmark me-2 text-warning"></i> Activate Students</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="deactivateStudentsBtn" onclick="confirmDeactive(getSelectedStudentIds(), null)"><i class="fa-solid fa-user-xmark me-2 text-warning"></i> Deactivate Students</a></li>
                            <li><a class="dropdown-item" href="javascript:void(0)" id="deleteStudentsBtn" onclick="confirmDelete(getSelectedStudentIds(), null)"><i class="fas fa-trash-alt me-2 text-warning"></i> Delete Students</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid mb-5">
    <!-- Student Table Container With Counter-->
    <div class="table-data-container shadow-lg rounded" style="border: 1px solid #e0e0e0;">
        <!-- Results Summary -->
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 p-3">
            <div class="results-summary">
                <!-- Will be updated via JavaScript -->
            </div>
            <div class="d-flex align-items-center gap-2">
                <label for="studentsPerPage" class="form-label mb-0 text-nowrap">Students per page</label>
                <select id="studentsPerPage" class="form-select form-select-sm exclude-from-load"
                    data-preference-key="<?= htmlspecialchars(BASE_URL . ':students-per-page:' . getAuthenticatedAdmin($pdo)['user_id'], ENT_QUOTES, 'UTF-8') ?>">
                    <?php foreach (range(25, 250, 25) as $pageSize): ?>
                        <option value="<?= $pageSize ?>" <?= $pageSize === 100 ? 'selected' : '' ?>><?= $pageSize ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <!-- Student Table -->
        <div class="table-responsive">
            <table id="studentsTable" class="table table-striped table-hover table-bordered text-center align-middle table-sm">
                <thead class="table-dark">
                    <tr>
                        <th width="40">
                            <input type="checkbox" class="form-check-input select-all-checkbox" id="selectAll">
                        </th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Class</th>
                        <th>Father</th>
                        <th>Mother</th>
                        <th>Address</th>
                        <th title="Additional Information">A. Info</th>
                        <th>Status</th>
                        <th>Fee Info</th>
                        <th>Due</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="studentsTableBody">
                    <!-- Students will be loaded here via AJAX -->
                    <tr>
                        <td colspan="12" class="text-center py-4">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>


    <!-- Pagination -->
    <nav aria-label="Page navigation" class="m-0 d-flex align-items-center justify-content-center">
        <ul class="pagination justify-content-center mb-0" id="paginationContainer">
            <!-- Will be updated via JavaScript -->
        </ul>
    </nav>
</div>


<?php
include_once __DIR__ . '/../../includes/modals/student/marksheet-download-chooser-modal.php';
include_once __DIR__ . '/../../includes/modals/student/fees-related-modals.php';
include_once __DIR__ . '/../../includes/modals/student/student-permission-management-modal.php';
include_once __DIR__ . '/../../includes/modals/student/mobile-notification-sending-form-modal.php';
include_once __DIR__ . '/../../includes/modals/student/student-wallet-editor-modal.php';
include_once __DIR__ . '/../../includes/modals/student/student-attendance-management-modal.php';
include_once __DIR__ . '/../../includes/modals/student/student-action-options-modal.php';
include_once __DIR__ . '/../../includes/modals/student/student-export-data-options-modal.php';
include_once __DIR__ . '/../../includes/modals/student/payment-reminder-modal.php';
if ($canManageInventory) {
    include_once __DIR__ . '/../../includes/modals/student/student-inventory-sale-modal.php';
    include_once __DIR__ . '/../../includes/modals/student/student-inventory-collect-modal.php';
}
?>


<script>
    // Global constant variables
    const currencySymbol = "<?= $websiteConfig['currency_symbol'] ?>";
    const now = new Date();

    <?php if ($canManageInventory): ?>
    window.studentInventoryConfig = <?= json_encode([
        'api' => BASE_URL . '/api/admin/inventory.php',
        'receipt' => BASE_URL . '/management/inventory/receipt.php',
        'csrf' => $_SESSION['inventory_csrf'],
        'currency' => $websiteConfig['currency_symbol'] ?? '₹'
    ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    <?php endif; ?>

    // Initialize variables
    let globalSelectedStudents = [];
    let globalStudentClasses = {};
    let singleStudentId = null;
    let isFeeStatusSelectionResetting = false;
    let currentPage = 1;
    let totalPages = 1;
    let totalStudents = 0;
    let filterParams = {};

    // Initialize multiple dates picker
    const datePicker = flatpickr("#attendance_dates", {
        mode: "multiple",
        dateFormat: "Y-m-d"
    });

    // Global data arrays
    let classesData = [];
    let examsData = [];

    $(document).ready(function() {
        restoreStudentsPageSize();
        // Load initial data
        loadInitialData();

        // Set default time to current time
        $('#attendance_time').val(now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0'))

        // Sticky Table Header using jQuery
        // The page keeps its normal scrolling; the header cells are pushed down by
        // however far the table has scrolled past the top of the window, so they
        // visually stay pinned to the top of the screen.
        const $stickyTable = $('#studentsTable');
        const $stickyContainer = $stickyTable.closest('.table-responsive');
        const $stickyThead = $stickyTable.find('thead th');

        function positionStickyHeader() {
            if ($stickyContainer.length === 0 || !$stickyContainer.is(':visible')) {
                return;
            }

            const containerTop = $stickyContainer.offset().top;
            const windowTop = $(window).scrollTop();

            if (windowTop > containerTop) {
                // Never let the header travel past the bottom of the table — the row
                // count changes with pagination, so a short list would otherwise leave
                // it floating over empty space below the table.
                const maxDistance = Math.max(0, $stickyTable.outerHeight() - $stickyThead.outerHeight());
                const scrollDistance = Math.min(windowTop - containerTop, maxDistance);

                $stickyThead.css({
                    'transform': 'translateY(' + scrollDistance + 'px)',
                    'background-color': '#212529', // keeps the header opaque over the rows
                    'z-index': '10',
                    'position': 'relative'
                });
            } else {
                // Back at the top — drop it into its normal place
                $stickyThead.css({
                    'transform': 'translateY(0)'
                });
            }
        }

        $(window).on('scroll resize', positionStickyHeader);

        // Collapsing the filter card moves the table, so re-run once it settles
        $('#filterCollapseBody').on('shown.bs.collapse hidden.bs.collapse', positionStickyHeader);
    });
</script>


<!-- ---------------------------------Required Functions-------------------------------------------------- -->
<script defer src="../../assets/js/student/list-students/functions/student-related-basic-functions.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/functions/student-filter-related-functions.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/functions/student-selection-related-functions.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/functions/student-financial-related-functions.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/functions/student-download-permissions-related-functions.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/functions/student-academic-related-functions.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/functions/sheets-download-functions.js?v=<?= $assets_version ?>"></script>
<?php if ($canManageInventory): ?>
<script defer src="../../assets/js/student/list-students/functions/student-inventory-functions.js?v=<?= $assets_version ?>"></script>
<?php endif; ?>

<!-- ------------------------------------Required Events-------------------------------------------------- -->
<script defer src="../../assets/js/student/list-students/events/academic-related-events.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/events/filter-related-events.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/events/selection-related-events.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/events/financial-related-events.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/events/download-permissions-related-events.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/events/exam-related-events.js?v=<?= $assets_version ?>"></script>
<script defer src="../../assets/js/student/list-students/events/notification-related-events.js?v=<?= $assets_version ?>"></script>

<?php include_once("../../includes/body-close.php"); ?>
