<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Bulk Edit Students - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    include_once("../../includes/permission-denied.php");
    exit();
}

// Get student IDs from query string
$student_ids = $_GET['student_ids'] ?? '';
if (!$student_ids) {
    die("Student IDs are required.");
}

// Convert comma-separated string to array
$student_ids_array = explode(',', $student_ids);
$student_ids_array = array_map('trim', $student_ids_array);
$student_ids_array = array_filter($student_ids_array);

if (empty($student_ids_array)) {
    die("No valid student IDs provided.");
}

// Fetch students data
$placeholders = implode(',', array_fill(0, count($student_ids_array), '?'));
$stmt = $pdo->prepare("SELECT * FROM students WHERE student_id IN ($placeholders)");
$stmt->execute($student_ids_array);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($students)) {
    die("No students found with the provided IDs.");
}

// Check if all students are from the same class
$class_ids = array_unique(array_column($students, 'class_id'));
if (count($class_ids) > 1) {
    die("All selected students must be from the same class.");
}
$current_class_id = $class_ids[0];

// Fetch sections for the current class
$sections = $pdo->query("SELECT id, section_name FROM sections WHERE class_id = $current_class_id ORDER BY section_name ASC")->fetchAll(PDO::FETCH_ASSOC);

// ---- START: NEW CODE ----
// Get all driving routes for the car route dropdown.
$routes = $pdo->query("SELECT id, route_name FROM driving_routes ORDER BY route_name ASC")->fetchAll(PDO::FETCH_ASSOC);
// ---- END: NEW CODE ----

// Data for dropdowns
$blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
$religions = ['islam', 'hindu', 'christian', 'buddhist', 'jain', 'sikh', 'parsi', 'judaism', 'bahai', 'atheist', 'agnostic', 'other'];
$statusValues = ['Active', 'Inactive', 'Left', 'Alumni'];
?>

<style>
    /* ... (Your existing styles remain unchanged) ... */
    .editable-field {
        border: 1px solid #ddd;
        padding: 5px;
        min-width: 100px;
    }

    .editable-field:focus {
        border-color: #80bdff;
        outline: 0;
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    }

    .student-row.changed {
        background-color: #fffde7;
    }

    .update-btn {
        display: none;
    }

    .student-row.changed .update-btn {
        display: inline-block;
    }

    .field-checkboxes {
        background-color: #f8f9fa;
        padding: 15px;
        border-radius: 5px;
        margin-bottom: 20px;
    }

    .field-checkboxes label {
        margin-right: 15px;
        font-weight: normal;
    }

    .photo-preview {
        width: 50px;
        height: 60px;
        object-fit: cover;
        cursor: pointer;
    }

    /* Cropper modal styles */
    .modal-xl {
        max-width: 80%;
    }

    .img-container {
        overflow: hidden;
        margin: 0 auto;
        height: 70vh;
    }

    .cropper-view-box {
        outline: 2px solid #007bff;
        outline-color: rgba(0, 123, 255, 0.75);
    }

    #imageToCrop {
        max-width: 100%;
    }

    /* Enhanced Cropper Modal Styles */
    .modal-xl {
        max-width: 90%;
    }

    .img-container {
        position: relative;
        overflow: hidden;
        margin: 0 auto;
        height: 70vh;
        min-height: 400px;
        max-height: 600px;
        background-color: #f8f9fa;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    #imageToCrop {
        max-width: 100%;
        max-height: 100%;
        width: auto;
        height: auto;
        display: block;
    }

    .cropper-container{direction:ltr;font-size:0;line-height:0;position:relative;touch-action:none;user-select:none;width:100% !important;height:100% !important;}.cropper-wrap-box,.cropper-canvas,.cropper-drag-box,.cropper-crop-box,.cropper-modal{position:absolute;top:0;right:0;bottom:0;left:0;}.cropper-wrap-box{overflow:hidden;}.cropper-drag-box{opacity:0;background-color:#fff;}.cropper-modal{opacity:.5;background-color:#000;}.cropper-view-box{display:block;overflow:hidden;width:100%;height:100%;outline:2px solid #007bff;outline-color:rgba(0,123,255,.75);}.cropper-dashed{position:absolute;display:block;opacity:.5;border:0 dashed #eee;}.cropper-dashed.dashed-h{top:33.33333%;left:0;width:100%;height:33.33333%;border-top-width:1px;border-bottom-width:1px;}.cropper-dashed.dashed-v{top:0;left:33.33333%;width:33.33333%;height:100%;border-right-width:1px;border-left-width:1px;}.cropper-center{position:absolute;top:50%;left:50%;display:block;width:0;height:0;opacity:.75;}.cropper-center:before,.cropper-center:after{position:absolute;display:block;content:' ';background-color:#eee;}.cropper-center:before{top:0;left:-3px;width:7px;height:1px;}.cropper-center:after{top:-3px;left:0;width:1px;height:7px;}.cropper-face,.cropper-line,.cropper-point{position:absolute;display:block;width:100%;height:100%;opacity:.1;}.cropper-face{top:0;left:0;background-color:#fff;}.cropper-line{background-color:#007bff;}.cropper-line.line-e{top:0;right:-3px;width:5px;cursor:e-resize;}.cropper-line.line-n{top:-3px;left:0;height:5px;cursor:n-resize;}.cropper-line.line-w{top:0;left:-3px;width:5px;cursor:w-resize;}.cropper-line.line-s{bottom:-3px;left:0;height:5px;cursor:s-resize;}.cropper-point{width:5px;height:5px;opacity:.75;background-color:#007bff;}.cropper-point.point-e{top:50%;right:-3px;margin-top:-3px;cursor:e-resize;}.cropper-point.point-n{top:-3px;left:50%;margin-left:-3px;cursor:n-resize;}.cropper-point.point-w{top:50%;left:-3px;margin-top:-3px;cursor:w-resize;}.cropper-point.point-s{bottom:-3px;left:50%;margin-left:-3px;cursor:s-resize;}.cropper-point.point-ne{top:-3px;right:-3px;cursor:ne-resize;}.cropper-point.point-nw{top:-3px;left:-3px;cursor:nw-resize;}.cropper-point.point-sw{bottom:-3px;left:-3px;cursor:sw-resize;}.cropper-point.point-se{right:-3px;bottom:-3px;width:5px;height:5px;cursor:se-resize;opacity:1;}.cropper-point.point-se:before{position:absolute;right:-50%;bottom:-50%;display:block;width:200%;height:200%;content:' ';opacity:0;background-color:#007bff;}
    
    table th, table td {
        text-align: center;
        vertical-align: middle; /* optional: vertically center too */
    }
    
    .th-min-width {
        min-width: 170px;
        white-space: nowrap;
    }
    .td-min-width input, .td-min-width textarea, .td-min-width select {
        min-width: 150px;
    }

    @media (max-width: 768px) {
        .modal-xl { max-width: 95%; }
        .img-container { height: 60vh; min-height: 300px; }
    }
</style>

<div class="container-fluid mt-4 mb-5">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0"><i class="fas fa-users-edit me-2"></i> Bulk Edit Students (Class: <?= safe_htmlspecialchars(getClassNameById($pdo, $students[0]['class_id'])) ?>)</h4>
        </div>

        <div class="card-body">
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i> You are editing <?= count($students) ?> students. Only changed fields will be updated.
            </div>

            <div class="row mb-3 align-items-center">
                <div class="col-md-4">
                    <div class="input-group">
                         <label class="input-group-text" for="sort-students-select"><i class="fas fa-sort-amount-down me-2"></i>Sort By</label>
                        <select class="form-select" id="sort-students-select">
                            <option value="roll_asc" selected>Roll Number (Low to High)</option>
                            <option value="roll_desc">Roll Number (High to Low)</option>
                            <option value="name_asc">Name (A-Z)</option>
                            <option value="name_desc">Name (Z-A)</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="field-checkboxes mb-4">
                 <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="check-name">
                    <label class="form-check-label" for="check-name"><b>Edit Name</b></label>
                </div>
                <hr>
                <h5><i class="fas fa-check-square me-2"></i> Fields to Display:</h5>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-image" value="student_image" checked>
                    <label class="form-check-label" for="toggle-image">Photo</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-father-name" value="father_name" checked>
                    <label class="form-check-label" for="toggle-father-name">Father's Name</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-mother" value="mother_name">
                    <label class="form-check-label" for="toggle-mother">Mother's Name</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-section" value="section_id" checked>
                    <label class="form-check-label" for="toggle-section">Section</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-roll" value="roll_no" checked>
                    <label class="form-check-label" for="toggle-roll">Roll No</label>
                </div>
                 <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-reg-no" value="registration_no">
                    <label class="form-check-label" for="toggle-reg-no">Reg. No</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-status" value="status">
                    <label class="form-check-label" for="toggle-status">Status</label>
                </div>
                 <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-gender" value="gender">
                    <label class="form-check-label" for="toggle-gender">Gender</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-phone" value="phone_number" checked>
                    <label class="form-check-label" for="toggle-phone">Phone</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-alt-phone" value="alternate_phone_number">
                    <label class="form-check-label" for="toggle-alt-phone">Alt. Phone</label>
                </div>
                 <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-email" value="email">
                    <label class="form-check-label" for="toggle-email">Email</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-religion" value="religion">
                    <label class="form-check-label" for="toggle-religion">Religion</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-blood" value="blood_group">
                    <label class="form-check-label" for="toggle-blood">Blood Group</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-father-occupation" value="father_occupation">
                    <label class="form-check-label" for="toggle-father-occupation">Father's Occupation</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-mother-occupation" value="mother_occupation">
                    <label class="form-check-label" for="toggle-mother-occupation">Mother's Occupation</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-student-adhaar" value="student_adhaar_no">
                    <label class="form-check-label" for="toggle-student-adhaar">Student Aadhaar</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-father-adhaar" value="father_adhaar_no">
                    <label class="form-check-label" for="toggle-father-adhaar">Father Aadhaar</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-mother-adhaar" value="mother_adhaar_no">
                    <label class="form-check-label" for="toggle-mother-adhaar">Mother Aadhaar</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-village" value="village">
                    <label class="form-check-label" for="toggle-village">Village</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-post-office" value="post_office">
                    <label class="form-check-label" for="toggle-post-office">Post Office</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-police-station" value="police_station">
                    <label class="form-check-label" for="toggle-police-station">Police Station</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-district" value="district">
                    <label class="form-check-label" for="toggle-district">District</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-pin-code" value="pin_code">
                    <label class="form-check-label" for="toggle-pin-code">Pin Code</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-car-route" value="driving_route,driver">
                    <label class="form-check-label" for="toggle-car-route">Driving Route & Driver</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-car-fee" value="car_fee">
                    <label class="form-check-label" for="toggle-car-fee">Car Fee</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-hostel-fee" value="hostel_fee">
                    <label class="form-check-label" for="toggle-hostel-fee">Hostel Fee</label>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-light table-hover" id="studentsTable">
                    <thead>
                        <tr>
                            <th class="bg-dark text-white">ID</th>
                            <th class="bg-dark text-white th-min-width">Name</th>
                            <th class="field-column bg-dark text-white" data-field="student_image">Photo</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="father_name">Father's Name</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="mother_name">Mother's Name</th>
                            <th class="field-column bg-dark text-white" data-field="section_id">Section</th>
                            <th class="field-column bg-dark text-white" data-field="roll_no">Roll No</th>
                            <th class="field-column bg-dark text-white" data-field="registration_no">Reg. No</th>
                            <th class="field-column bg-dark text-white" data-field="status">Status</th>
                            <th class="field-column bg-dark text-white" data-field="gender">Gender</th>
                            <th class="field-column bg-dark text-white" data-field="phone_number">Phone</th>
                            <th class="field-column bg-dark text-white" data-field="alternate_phone_number">Alt. Phone</th>
                            <th class="field-column bg-dark text-white" data-field="email">Email</th>
                            <th class="field-column bg-dark text-white" data-field="religion">Religion</th>
                            <th class="field-column bg-dark text-white" data-field="blood_group">Blood Group</th>
                            <th class="field-column bg-dark text-white" data-field="father_occupation">Father's Occupation</th>
                            <th class="field-column bg-dark text-white" data-field="mother_occupation">Mother's Occupation</th>
                            <th class="field-column bg-dark text-white" data-field="student_adhaar_no">Student Aadhaar</th>
                            <th class="field-column bg-dark text-white" data-field="father_adhaar_no">Father Aadhaar</th>
                            <th class="field-column bg-dark text-white" data-field="mother_adhaar_no">Mother Aadhaar</th>
                            <th class="field-column bg-dark text-white" data-field="village">Village</th>
                            <th class="field-column bg-dark text-white" data-field="post_office">Post Office</th>
                            <th class="field-column bg-dark text-white" data-field="police_station">Police Station</th>
                            <th class="field-column bg-dark text-white" data-field="district">District</th>
                            <th class="field-column bg-dark text-white" data-field="pin_code">Pin Code</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="driving_route">Driving Route</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="driver">Driver</th>
                            <th class="field-column bg-dark text-white" data-field="car_fee">Car Fee</th>
                            <th class="field-column bg-dark text-white" data-field="hostel_fee">Hostel Fee</th>
                            <th class="bg-dark text-white">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                            <tr class="student-row" data-student-id="<?= safe_htmlspecialchars($student['student_id']) ?>">
                                <td><?= safe_htmlspecialchars($student['student_id']) ?></td>
                                <td class="td-min-width">
                                    <input type="text" class="form-control form-control-sm editable-field name-input" value="<?= safe_htmlspecialchars($student['name']) ?>" disabled>
                                </td>

                                <td class="field-column" data-field="student_image">
                                    <?php if (!empty($student['student_image'])): ?>
                                        <img src="../../uploads/students/<?= safe_htmlspecialchars($student['student_image']) ?>" class="photo-preview">
                                    <?php else: ?>
                                        <img src="../../uploads/students/default_student_dp.jpg" class="photo-preview">
                                    <?php endif; ?>
                                    <input type="file" class="form-control mt-1 image-upload" style="display: none;" accept="image/*" capture="environment">
                                    <input type="hidden" class="current-image" value="<?= safe_htmlspecialchars($student['student_image']) ?>">
                                    <input type="hidden" class="cropped-image-data">
                                </td>
                                
                                <td class="field-column td-min-width" data-field="father_name">
                                    <input type="text" class="form-control form-control-sm editable-field father-name-input" value="<?= safe_htmlspecialchars($student['father_name']) ?>">
                                </td>

                                <td class="field-column td-min-width" data-field="mother_name">
                                    <input type="text" class="form-control form-control-sm editable-field mother-name-input" value="<?= safe_htmlspecialchars($student['mother_name']) ?>">
                                </td>

                                <td class="field-column" data-field="section_id">
                                    <select class="form-control form-control-sm editable-field section-select">
                                        <option value="">Select Section</option>
                                        <?php foreach ($sections as $section): ?>
                                            <option value="<?= $section['id'] ?>" <?= $student['section_id'] == $section['id'] ? 'selected' : '' ?>>
                                                <?= safe_htmlspecialchars($section['section_name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>

                                <td class="field-column" data-field="roll_no">
                                    <input type="number" class="form-control form-control-sm editable-field roll-no-input" value="<?= safe_htmlspecialchars($student['roll_no']) ?>">
                                </td>

                                <td class="field-column" data-field="registration_no">
                                    <input type="text" class="form-control form-control-sm editable-field registration-no-input" value="<?= safe_htmlspecialchars($student['registration_no']) ?>">
                                </td>
                                
                                <td class="field-column" data-field="status">
                                    <select class="form-control form-control-sm editable-field status-select">
                                        <?php foreach ($statusValues as $status): ?>
                                            <option value="<?= $status ?>" <?= $student['status'] === $status ? 'selected' : '' ?>>
                                                <?= $status ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                                
                                <td class="field-column" data-field="gender">
                                    <select class="form-control form-control-sm editable-field gender-select">
                                        <option value="Male" <?= $student['gender'] === 'Male' ? 'selected' : '' ?>>Male</option>
                                        <option value="Female" <?= $student['gender'] === 'Female' ? 'selected' : '' ?>>Female</option>
                                        <option value="Other" <?= $student['gender'] === 'Other' ? 'selected' : '' ?>>Other</option>
                                    </select>
                                </td>

                                <td class="field-column" data-field="phone_number">
                                    <input type="tel" class="form-control form-control-sm editable-field phone-input" value="<?= safe_htmlspecialchars($student['phone_number']) ?>">
                                </td>

                                <td class="field-column" data-field="alternate_phone_number">
                                    <input type="tel" class="form-control form-control-sm editable-field alt-phone-input" value="<?= safe_htmlspecialchars($student['alternate_phone_number']) ?>">
                                </td>
                                
                                <td class="field-column" data-field="email">
                                    <input type="email" class="form-control form-control-sm editable-field email-input" value="<?= safe_htmlspecialchars($student['email']) ?>">
                                </td>
                                
                                <td class="field-column" data-field="religion">
                                    <select class="form-control form-control-sm editable-field religion-select">
                                        <option value="">Select</option>
                                        <?php foreach ($religions as $religion): ?>
                                            <option value="<?= $religion ?>" <?= strtolower((string) $student['religion']) === $religion ? 'selected' : '' ?>>
                                                <?= ucfirst($religion) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>

                                <td class="field-column" data-field="blood_group">
                                    <select class="form-control form-control-sm editable-field blood-group-select">
                                        <option value="">Select</option>
                                        <?php foreach ($blood_groups as $group): ?>
                                            <option value="<?= $group ?>" <?= $student['blood_group'] === $group ? 'selected' : '' ?>>
                                                <?= $group ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                                
                                <td class="field-column" data-field="father_occupation">
                                    <input type="text" class="form-control form-control-sm editable-field father-occupation-input" value="<?= safe_htmlspecialchars($student['father_occupation']) ?>">
                                </td>

                                <td class="field-column" data-field="mother_occupation">
                                    <input type="text" class="form-control form-control-sm editable-field mother-occupation-input" value="<?= safe_htmlspecialchars($student['mother_occupation']) ?>">
                                </td>

                                <td class="field-column" data-field="student_adhaar_no">
                                    <input type="text" class="form-control form-control-sm editable-field student-adhaar-input" value="<?= safe_htmlspecialchars($student['student_adhaar_no']) ?>">
                                </td>
                                <td class="field-column" data-field="father_adhaar_no">
                                    <input type="text" class="form-control form-control-sm editable-field father-adhaar-input" value="<?= safe_htmlspecialchars($student['father_adhaar_no']) ?>">
                                </td>
                                <td class="field-column" data-field="mother_adhaar_no">
                                    <input type="text" class="form-control form-control-sm editable-field mother-adhaar-input" value="<?= safe_htmlspecialchars($student['mother_adhaar_no']) ?>">
                                </td>
                                <td class="field-column" data-field="village">
                                    <input type="text" class="form-control form-control-sm editable-field village-input" value="<?= safe_htmlspecialchars($student['village']) ?>">
                                </td>
                                <td class="field-column" data-field="post_office">
                                    <input type="text" class="form-control form-control-sm editable-field post-office-input" value="<?= safe_htmlspecialchars($student['post_office']) ?>">
                                </td>
                                <td class="field-column" data-field="police_station">
                                    <input type="text" class="form-control form-control-sm editable-field police-station-input" value="<?= safe_htmlspecialchars($student['police_station']) ?>">
                                </td>
                                <td class="field-column" data-field="district">
                                    <input type="text" class="form-control form-control-sm editable-field district-input" value="<?= safe_htmlspecialchars($student['district']) ?>">
                                </td>
                                <td class="field-column" data-field="pin_code">
                                    <input type="text" class="form-control form-control-sm editable-field pin-code-input" value="<?= safe_htmlspecialchars($student['pin_code']) ?>">
                                </td>

                                <td class="field-column td-min-width" data-field="driving_route">
                                    <select class="form-select form-select-sm editable-field car-route-select">
                                        <option value="">Select Driving Route</option>
                                        <?php foreach ($routes as $route): ?>
                                            <option value="<?= safe_htmlspecialchars($route['id']) ?>" <?= ($student['driving_route_id'] == $route['id']) ? 'selected' : '' ?>>
                                                <?= safe_htmlspecialchars($route['route_name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>

                                <td class="field-column td-min-width" data-field="driver">
                                    <select class="form-select form-select-sm editable-field driver-select">
                                        <option value="">Select Driver</option>
                                        <?php
                                        // Pre-load drivers only if a route is already selected
                                        if (!empty($student['driving_route_id'])) {
                                            $driverStmt = $pdo->prepare("SELECT id, name FROM drivers WHERE route_id = ?");
                                            $driverStmt->execute([$student['driving_route_id']]);
                                            $drivers = $driverStmt->fetchAll(PDO::FETCH_ASSOC);
                                            foreach ($drivers as $driver) {
                                                $selected = ($student['driver_id'] == $driver['id']) ? 'selected' : '';
                                                echo "<option value='" . safe_htmlspecialchars($driver['id']) . "' $selected>" . safe_htmlspecialchars($driver['name']) . "</option>";
                                            }
                                        }
                                        ?>
                                    </select>
                                </td>
                                <td class="field-column" data-field="car_fee">
                                    <input type="number" step="0.01" class="form-control form-control-sm editable-field car-fee-input" value="<?= safe_htmlspecialchars($student['car_fee']) ?>">
                                </td>

                                <td class="field-column" data-field="hostel_fee">
                                    <input type="number" step="0.01" class="form-control form-control-sm editable-field hostel-fee-input" value="<?= safe_htmlspecialchars($student['hostel_fee']) ?>">
                                </td>

                                <td>
                                    <button class="btn btn-sm btn-primary update-btn" data-student-id="<?= safe_htmlspecialchars($student['student_id']) ?>">
                                        <i class="fas fa-save"></i> Update
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="text-center mt-4">
                <button id="updateAllBtn" class="btn btn-primary px-4 py-2">
                    <i class="fas fa-save me-2"></i> Update All Changes
                </button>
                <a href="../view/list-students.php" class="btn btn-secondary px-4 py-2 ms-2">
                    <i class="fas fa-times me-2"></i> Cancel
                </a>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="cropModal" tabindex="-1" aria-labelledby="cropModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cropModalLabel">Crop Student Photo (5:6 ratio required)</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <div class="img-container">
                    <img id="imageToCrop" src="#" alt="Image to crop">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="cropImageBtn">Crop & Save</button>
            </div>
        </div>
    </div>
</div>


<script>
$(document).ready(function() {
    // ... (Your existing cropper and other logic above this point remains unchanged) ...
    let cropper;
    let currentImageRow;
    const cropModal = new bootstrap.Modal(document.getElementById('cropModal'));
    let rollNumbers = {};
    let registrationNumbers = {};
    $('#check-name').change(function() {
        const isChecked = $(this).is(':checked');
        $('.name-input').prop('disabled', !isChecked);
    });

    // --- MODIFIED CODE START ---
    // Initializes the data stores for roll numbers (with sections) and registration numbers.
    function initializeUniqueFields() {
        $('.student-row').each(function() {
            const $row = $(this);
            const studentId = $row.data('student-id');
            const rollNo = parseInt($row.find('.roll-no-input').val());
            const sectionId = $row.find('.section-select').val(); // Get section ID

            if (rollNo > 0) {
                // Store roll number and section ID together
                rollNumbers[studentId] = { roll: rollNo, section: sectionId };
            }

            const regNo = $row.find('.registration-no-input').val().trim();
            if (regNo) {
                registrationNumbers[studentId] = regNo;
            }
        });
    }

    // Validates that the roll number is unique within the same section.
    function validateRollNumber(studentId, newRollNo) {
        if (newRollNo <= 0) {
            return { valid: false, message: 'Roll number must be a positive number' };
        }
        
        const studentRow = $(`tr[data-student-id="${studentId}"]`);
        const currentSectionId = studentRow.find('.section-select').val();

        // If no section is selected, we can't validate for duplicates in the section.
        if (!currentSectionId) {
            return { valid: true, message: '' };
        }

        for (const [otherId, otherData] of Object.entries(rollNumbers)) {
            // Check for a duplicate roll number ONLY in the same section.
            if (otherId !== studentId && otherData.roll === newRollNo && otherData.section === currentSectionId) {
                return { valid: false, message: `Roll no ${newRollNo} is already used in this section.` };
            }
        }
        return { valid: true, message: '' };
    }
    // --- MODIFIED CODE END ---


    function validateRegistrationNumber(studentId, newRegNo) {
        if (!newRegNo) return { valid: true, message: '' }; // Allow empty
        for (let [otherId, otherReg] of Object.entries(registrationNumbers)) {
            if (otherId !== studentId && otherReg === newRegNo) {
                return { valid: false, message: `Reg. no ${newRegNo} is already assigned` };
            }
        }
        return { valid: true, message: '' };
    }

    initializeUniqueFields();

    // --- MODIFIED CODE START ---
    // Generic validator function that now handles the specific data structure for roll numbers.
    function createValidator(inputClass, validationFn, dataStore) {
         $(document).on('input blur', inputClass, function() {
            const $input = $(this);
            const $row = $input.closest('.student-row');
            const studentId = $row.data('student-id').toString();
            const newValue = (inputClass === '.roll-no-input') ? parseInt($input.val()) : $input.val().trim();
            
            $input.siblings('.validation-feedback').remove();
            $input.removeClass('is-invalid is-valid');

            if (($input.val() && !isNaN(newValue)) || (typeof newValue === 'string' && newValue)) {
                const validation = validationFn(studentId, newValue);
                if (!validation.valid) {
                    $input.addClass('is-invalid');
                    $input.after(`<div class="invalid-feedback d-block validation-feedback">${validation.message}</div>`);
                } else {
                    $input.addClass('is-valid');
                    // Update the dataStore with the correct structure
                    if (inputClass === '.roll-no-input') {
                        const sectionId = $row.find('.section-select').val();
                        dataStore[studentId] = { roll: newValue, section: sectionId };
                    } else {
                        dataStore[studentId] = newValue; // Original behavior for other fields
                    }
                }
            } else {
                delete dataStore[studentId];
            }
        });
    }
    // --- MODIFIED CODE END ---

    createValidator('.roll-no-input', validateRollNumber, rollNumbers);
    createValidator('.registration-no-input', validateRegistrationNumber, registrationNumbers);

    // --- NEW CODE START ---
    // Event handler for when a student's section is changed.
    $(document).on('change', '.section-select', function() {
        const $row = $(this).closest('.student-row');
        const studentId = $row.data('student-id').toString();
        const newSectionId = $(this).val();

        // Update the section ID in our internal roll number data store.
        if (rollNumbers[studentId]) {
            rollNumbers[studentId].section = newSectionId;
        }

        // Re-trigger the validation on the roll number input for this row.
        $row.find('.roll-no-input').trigger('blur');
    });
    // --- NEW CODE END ---

    $('.photo-preview').click(function() {
        currentImageRow = $(this).closest('td');
        currentImageRow.find('.image-upload').click();
    });

    $('.image-upload').change(function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                $('#imageToCrop').attr('src', e.target.result);
                cropModal.show();
            }
            reader.readAsDataURL(file);
        }
    });

    $('#cropModal').on('shown.bs.modal', function() {
        if (cropper) cropper.destroy();
        const image = document.getElementById('imageToCrop');
        cropper = new Cropper(image, {
            aspectRatio: 5 / 6, viewMode: 1, autoCropArea: 0.8, responsive: true,
            restore: false, guides: true, center: true, highlight: false,
            cropBoxMovable: true, cropBoxResizable: true, toggleDragModeOnDblclick: false,
        });
    });

    $('#cropImageBtn').click(function() {
        if (!cropper) return;
        const canvas = cropper.getCroppedCanvas({ width: 500, height: 600, fillColor: '#fff' });
        if (!canvas) return;

        canvas.toBlob(function(blob) {
            const previewUrl = URL.createObjectURL(blob);
            currentImageRow.find('.photo-preview').attr('src', previewUrl);
            const reader = new FileReader();
            reader.onload = () => {
                currentImageRow.find('.cropped-image-data').val(reader.result);
                currentImageRow.closest('.student-row').addClass('changed');
            };
            reader.readAsDataURL(blob);
            cropModal.hide();
        }, 'image/jpeg', 0.9);
    });

    $('#cropModal').on('hidden.bs.modal', function() {
        if (cropper) {
            cropper.destroy();
            cropper = null;
        }
        $('#imageToCrop').attr('src', '#');
        if (currentImageRow) currentImageRow.find('.image-upload').val('');
    });

    $('#sort-students-select').on('change', function() {
        const sortOption = $(this).val();
        let rows = $('#studentsTable tbody tr').get();

        rows.sort(function(a, b) {
            let valA, valB;

            switch (sortOption) {
                case 'name_asc':
                    valA = $(a).find('.name-input').val().trim().toLowerCase();
                    valB = $(b).find('.name-input').val().trim().toLowerCase();
                    return valA.localeCompare(valB);
                case 'name_desc':
                    valA = $(a).find('.name-input').val().trim().toLowerCase();
                    valB = $(b).find('.name-input').val().trim().toLowerCase();
                    return valB.localeCompare(valA);
                case 'roll_asc':
                    valA = parseInt($(a).find('.roll-no-input').val()) || 0;
                    valB = parseInt($(b).find('.roll-no-input').val()) || 0;
                    return valA - valB;
                case 'roll_desc':
                    valA = parseInt($(a).find('.roll-no-input').val()) || 0;
                    valB = parseInt($(b).find('.roll-no-input').val()) || 0;
                    return valB - valA;
                default:
                    return 0;
            }
        });

        $.each(rows, function(index, row) {
            $('#studentsTable tbody').append(row);
        });
    });

    $('.field-toggle').change(function() {
        const fields = $(this).val().split(',');
        const isChecked = $(this).is(':checked');
        fields.forEach(field => {
            $(`.field-column[data-field="${field}"]`).toggle(isChecked);
        });
    }).trigger('change');
    
    $('.editable-field, .image-upload').on('input change', function() {
        $(this).closest('.student-row').addClass('changed');
    });

    $(document).on('change', '.car-route-select', function() {
        const selectedRouteId = $(this).val();
        const row = $(this).closest('.student-row');
        const driverSelect = row.find('.driver-select');

        driverSelect.html('<option value="">Loading...</option>');

        if (!selectedRouteId) {
            driverSelect.html('<option value="">Select Driver</option>');
            return;
        }

        $.ajax({
            url: '../ajax/get-drivers-by-driving-route-id.php',
            type: 'GET',
            data: { route_id: selectedRouteId },
            dataType: 'json',
            success: function(drivers) {
                let options = '<option value="">Select Driver</option>';
                if (drivers.length > 0) {
                    drivers.forEach(driver => {
                        options += `<option value="${driver.id}">${driver.name}</option>`;
                    });
                } else {
                    options += '<option value="" disabled>No drivers available</option>';
                }
                driverSelect.html(options);
            },
            error: function() {
                driverSelect.html('<option value="">Error loading</option>');
            }
        });
    });
    
    $(document).on('click', '.update-btn', function() {
        const studentId = $(this).data('student-id');
        const row = $(`tr[data-student-id="${studentId}"]`);
        if (row.find('.is-invalid').length > 0) {
            toastr.error('Please fix validation errors before updating.');
            return;
        }
        updateStudent(studentId);
    });

    $('#updateAllBtn').click(function() {
        if ($('.is-invalid').length > 0) {
            toastr.error('Please fix all validation errors before updating.');
            return;
        }
        const changedRows = $('.student-row.changed');
        if (changedRows.length === 0) {
            toastr.info('No changes detected.');
            return;
        }
        let updateCount = 0, errorCount = 0;
        const progressToast = toastr.info(`Updating ${changedRows.length} students...`, 'Progress', { timeOut: 0 });
        changedRows.each((index, row) => {
            const studentId = $(row).data('student-id');
            setTimeout(() => {
                updateStudent(studentId, success => {
                    success ? updateCount++ : errorCount++;
                    if (updateCount + errorCount === changedRows.length) {
                        toastr.clear(progressToast);
                        if (errorCount === 0) {
                            toastr.success(`All ${updateCount} students updated successfully!`);
                        } else {
                            toastr.warning(`${updateCount} updated, ${errorCount} failed.`);
                        }
                    }
                });
            }, index * 200);
        });
    });

    function updateStudent(studentId, callback) {
        const row = $(`tr[data-student-id="${studentId}"]`);
        const formData = new FormData();
        formData.append('student_id', studentId);
        let hasChanges = false;
        
        const fields = [
            { selector: '.name-input', name: 'name' },
            { selector: '.section-select', name: 'section_id' },
            { selector: '.roll-no-input', name: 'roll_no' },
            { selector: '.phone-input', name: 'phone_number' },
            { selector: '.alt-phone-input', name: 'alternate_phone_number' },
            { selector: '.blood-group-select', name: 'blood_group' },
            { selector: '.mother-name-input', name: 'mother_name' },
            { selector: '.father-occupation-input', name: 'father_occupation' },
            { selector: '.mother-occupation-input', name: 'mother_occupation' },
            { selector: '.student-adhaar-input', name: 'student_adhaar_no' },
            { selector: '.father-adhaar-input', name: 'father_adhaar_no' },
            { selector: '.mother-adhaar-input', name: 'mother_adhaar_no' },
            { selector: '.village-input', name: 'village' },
            { selector: '.post-office-input', name: 'post_office' },
            { selector: '.police-station-input', name: 'police_station' },
            { selector: '.district-input', name: 'district' },
            { selector: '.pin-code-input', name: 'pin_code' },
            { selector: '.car-route-select', name: 'driving_route_id' },
            { selector: '.driver-select', name: 'driver_id' },
            { selector: '.car-fee-input', name: 'car_fee' },
            { selector: '.hostel-fee-input', name: 'hostel_fee' },
            { selector: '.father-name-input', name: 'father_name' },
            { selector: '.gender-select', name: 'gender' },
            { selector: '.religion-select', name: 'religion' },
            { selector: '.registration-no-input', name: 'registration_no' },
            { selector: '.email-input', name: 'email' },
            { selector: '.status-select', name: 'status' }
        ];

        fields.forEach(field => {
            const element = row.find(field.selector);
            if (element.data('original-value') !== undefined && element.val() != element.data('original-value')) {
                formData.append(field.name, element.val());
                hasChanges = true;
            }
        });
        
        const croppedImageData = row.find('.cropped-image-data').val();
        if (croppedImageData) {
            formData.append('cropped_image_data', croppedImageData);
            hasChanges = true;
        }
        formData.append('current_image', row.find('.current-image').val());

        if (!hasChanges) {
            toastr.info(`No changes for student ID ${studentId}.`);
            row.removeClass('changed');
            if (callback) callback(true);
            return;
        }
        
         const btn = row.find('.update-btn');
            const originalBtnText = btn.html();
            btn.html('<i class="fas fa-spinner fa-spin"></i>').prop('disabled', true);

            $.ajax({
                url: '../action/process-bulk-edit-student.php',
                type: 'POST', data: formData, processData: false, contentType: false,
                success: function(response) {
                    try {
                        response = typeof response === 'string' ? JSON.parse(response) : response;
                        if (response.success) {
                            toastr.success(`Student ${studentId} updated.`);
                            row.removeClass('changed');
                            fields.forEach(field => {
                                const element = row.find(field.selector);
                                element.data('original-value', element.val());
                                element.removeClass('is-invalid is-valid');
                            });
                            row.find('.validation-feedback').remove();
                            if (response.new_image) {
                                row.find('.current-image').val(response.new_image);
                                row.find('.cropped-image-data').val('');
                            }
                            if (callback) callback(true);
                        } else {
                            toastr.error(response.message || 'Update failed.');
                            if (callback) callback(false);
                        }
                    } catch (e) {
                        toastr.error('Invalid server response.');
                        if (callback) callback(false);
                    }
                },
                error: function(xhr) {
                    toastr.error('An error occurred. Check console.');
                    console.error(xhr.responseText);
                    if (callback) callback(false);
                },
                complete: function() {
                    btn.html(originalBtnText).prop('disabled', false);
                }
            });
    }

    $('.student-row').each(function() {
        const row = $(this);
        row.find('.editable-field').each(function() {
            $(this).data('original-value', $(this).val());
        });
    });
});
</script>

<?php include_once("../../includes/body-close.php"); ?>
