<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Assign Sections - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    include_once("../../includes/permission-denied.php");
    exit;
}

// Fetch all classes for the dropdown
$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY class_name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Initialize variables
$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : null;
$students = [];
$sections = [];
$class = null;

// If class is selected, fetch its sections and students without sections
if ($class_id) {
    // Get class name
    $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
    $stmt->execute([$class_id]);
    $class = $stmt->fetch(PDO::FETCH_ASSOC);

    // Get all sections for this class
    $stmt = $pdo->prepare("SELECT id, section_name FROM sections WHERE class_id = ? ORDER BY section_name ASC");
    $stmt->execute([$class_id]);
    $sections = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch students without sections
    $stmt = $pdo->prepare("
        SELECT s.id, s.student_id, s.name 
        FROM students s
        WHERE s.class_id = ? 
        AND (s.section_id IS NULL OR s.section_id = 0)
        AND s.status = 'Active'
        ORDER BY s.name ASC
    ");
    $stmt->execute([$class_id]);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<div class="container mt-4">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h3><i class="fas fa-users me-2"></i>Assign Sections</h3>
        </div>
        <div class="card-body">
            <!-- Class Selection Form -->
            <form method="get" id="filterForm" class="mb-4">
                <div class="row">
                    <div class="col-md-12">
                        <label class="form-label">Class</label>
                        <select class="form-select" name="class_id" id="classSelect" required>
                            <option value="">-- Select Class --</option>
                            <?php foreach ($classes as $c): ?>
                                <option value="<?= $c['id'] ?>" <?= $class_id == $c['id'] ? 'selected' : '' ?>>
                                    <?= safe_htmlspecialchars($c['class_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="text-center mt-3">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter me-2"></i>Filter Students
                    </button>
                    <?php if ($class_id): ?>
                        <a href="assign-sections.php" class="btn btn-secondary">
                            <i class="fas fa-times me-2"></i>Clear Filters
                        </a>
                    <?php endif; ?>
                </div>
            </form>

            <?php if ($class_id): ?>
                <!-- Display class info -->
                <div class="alert alert-info mb-4">
                    <h5>Class: <?= safe_htmlspecialchars($class['class_name']) ?></h5>
                    <p class="mb-0"><?= count($students) ?> students need section assignment</p>
                </div>

                <?php if (empty($students)): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle me-2"></i>
                        All students in this class already have sections assigned.
                    </div>
                <?php elseif (empty($sections)): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        No sections available for this class. Please create sections first.
                    </div>
                <?php else: ?>
                    <!-- Enhanced Section Assignment Form -->
                    <form id="sectionAssignmentForm">
                        <input type="hidden" name="class_id" value="<?= $class_id ?>">

                        <div class="row mb-3">
                            <div class="col-md-4">
                                <label class="form-label">Select Section</label>
                                <select class="form-control" id="bulkSectionSelect">
                                    <option value="">-- Select Section --</option>
                                    <?php foreach ($sections as $sec): ?>
                                        <option value="<?= $sec['id'] ?>">
                                            <?= safe_htmlspecialchars($sec['section_name']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4 d-flex align-items-end">
                                <button type="button" id="assignBulkBtn" class="btn btn-primary">
                                    <i class="fas fa-users me-2"></i>Assign Selected Students
                                </button>
                            </div>
                            <div class="col-md-4">
                                <label for="search_input" class="form-label">Search:</label>
                                <input type="text" class="form-control" id="search_input" placeholder="Search by name or student id" />
                            </div>
                        </div>

                        <div class="table-responsive">
                            <!-- Selected Students Summary -->
                            <div class="alert alert-info mb-2" id="selectedSummary" style="display: none;">
                                <strong><span id="selectedCount">0</span> student(s) selected</strong>
                            </div>

                            <table class="table table-bordered" id="studentsTable">
                                <thead class="table-dark">
                                    <tr>
                                        <th width="5%">
                                            <input type="checkbox" id="selectAll">
                                        </th>
                                        <th width="15%">Student ID</th>
                                        <th width="50%">Name</th>
                                        <th width="30%">Assigned Section</th>
                                    </tr>
                                </thead>
                                <tbody id="studentsTableBody">
                                    <!-- Selected students will be moved here dynamically -->
                                    <tr id="noSelectedStudents" class="table-warning">
                                        <td colspan="4" class="text-center">No students selected yet</td>
                                    </tr>

                                    <!-- All students will be listed here initially -->
                                    <?php foreach ($students as $student): ?>
                                        <tr data-student-id="<?= $student['id'] ?>">
                                            <td>
                                                <input type="checkbox" class="student-check"
                                                    name="students[]" value="<?= $student['id'] ?>">
                                            </td>
                                            <td><?= safe_htmlspecialchars($student['student_id']) ?></td>
                                            <td><?= safe_htmlspecialchars($student['name']) ?></td>
                                            <td class="section-display" data-student="<?= $student['id'] ?>">
                                                <span class="text-muted">Not assigned</span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="text-center mt-4">
                            <button type="submit" class="btn btn-success" id="saveButton">
                                <i class="fas fa-save me-2"></i>Save All Assignments
                            </button>
                        </div>
                    </form>
                <?php endif; ?>

            <?php elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['class_id'])): ?>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Please select a class to view students needing section assignment.
                </div>
            <?php else: ?>
                <div class="alert alert-secondary">
                    <i class="fas fa-info-circle me-2"></i>
                    Select a class to begin assigning sections.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    // Function to update selected students display
    function updateSelectedStudents() {
        const selectedStudents = $('.student-check:checked');
        const selectedCount = selectedStudents.length;

        // Update summary
        $('#selectedCount').text(selectedCount);
        if (selectedCount > 0) {
            $('#selectedSummary').show();
            $('#noSelectedStudents').hide();
        } else {
            $('#selectedSummary').hide();
            $('#noSelectedStudents').show();
        }

        // Reorder rows - selected first
        const tbody = $('#studentsTableBody');
        const allRows = tbody.find('tr:not(#noSelectedStudents)');

        // Move selected rows to top
        selectedStudents.each(function() {
            const row = $(this).closest('tr');
            tbody.prepend(row);
        });
    }

    $(document).ready(function() {
        // Store original student rows for filtering
        const originalRows = $('#studentsTableBody tr:not(#noSelectedStudents)').clone();

        // Toggle select all checkbox
        $('#selectAll').change(function() {
            $('.student-check').prop('checked', $(this).prop('checked'));
            updateSelectedStudents();
        });

        // Update selected students when checkboxes change
        $('body').on('change', '.student-check', function() {
            updateSelectedStudents();
            $('#selectAll').prop('checked',
                $('.student-check:visible').length === $('.student-check:visible:checked').length && $('.student-check:visible').length > 0
            );
        });

        // Real-time search filtering
        $('#search_input').on('input', function() {
            const searchText = $(this).val().toLowerCase();

            // Reset to original rows when search is empty
            // if (searchText === '') {
                //$('#studentsTableBody').html(originalRows.clone());
                // $('#noSelectedStudents').show();
                // return;
            // }

            // Filter rows
            const filteredRows = originalRows.filter(function() {
                const studentId = $(this).find('td:eq(1)').text().toLowerCase();
                const studentName = $(this).find('td:eq(2)').text().toLowerCase();
                return studentId.includes(searchText) || studentName.includes(searchText);
            });

            // Update table with filtered rows
            $('#studentsTableBody').html(filteredRows);
            $('#noSelectedStudents').toggle(filteredRows.length === 0);

            // Update checkbox states after filtering
            updateSelectedStudents();
        });

        // Bulk assign selected students to section
        $('#assignBulkBtn').click(function() {
            const sectionId = $('#bulkSectionSelect').val();
            const sectionName = $('#bulkSectionSelect option:selected').text();

            if (!sectionId) {
                toastr.error('Please select a section first');
                return;
            }

            const selectedStudents = [];
            $('.student-check:checked').each(function() {
                const studentId = $(this).val();
                selectedStudents.push(studentId);

                // Update display immediately
                $(`td.section-display[data-student="${studentId}"]`).html(
                    `<span class="badge bg-success">${sectionName}</span>
                 <input type="hidden" name="sections[${studentId}]" value="${sectionId}">`
                );
            });

            if (selectedStudents.length === 0) {
                toastr.error('Please select at least one student');
                return;
            }

            toastr.success(`Assigned ${selectedStudents.length} students to ${sectionName}`);

            // Uncheck all after assignment
            $('.student-check').prop('checked', false);
            $('#selectAll').prop('checked', false);
            updateSelectedStudents();
        });

        // Handle final form submission
        $('#sectionAssignmentForm').submit(function(e) {
            e.preventDefault();

            const formData = $(this).serialize();

            if (!$('input[name^="sections["]').length) {
                toastr.error('No section assignments made');
                return;
            }

            $('#saveButton').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Saving...');

            $.ajax({
                url: '../action/save-sections.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        setTimeout(() => {
                            window.location.reload();
                        }, 1500);
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr) {
                    toastr.error('An error occurred while saving sections');
                    console.error('Error:', xhr.responseText);
                },
                complete: function() {
                    $('#saveButton').prop('disabled', false).html('<i class="fas fa-save me-2"></i>Save All Assignments');
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>