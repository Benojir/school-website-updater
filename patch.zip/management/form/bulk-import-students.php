<?php
ini_set('memory_limit', '512M');
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Bulk Import Students - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    include_once("../../includes/permission-denied.php");
    exit();
}

// Include PHPExcel library (you may need to install this)
require_once '../../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

// Initialize response variable
$response = null;

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['student_file'])) {
    $response = processBulkImport($_FILES['student_file'], $pdo);
}

// Fetch all classes for validation
$classes = $pdo->query("SELECT id, class_name FROM classes")->fetchAll(PDO::FETCH_KEY_PAIR);
?>

<div class="container mt-4 mb-5">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0"><i class="fas fa-users me-2"></i> Bulk Import Students</h4>
        </div>

        <div class="card-body">
            <?php if ($response !== null): ?>
                <div class="alert alert-<?= $response['success'] ? 'success' : 'danger' ?>">
                    <?= safe_htmlspecialchars($response['message']) ?>
                    <?php if (!empty($response['errors'])): ?>
                        <ul class="mt-2 mb-0">
                            <?php foreach ($response['errors'] as $error): ?>
                                <li><?= safe_htmlspecialchars($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                    <?php if ($response['success'] && ($response['imported'] > 0 || $response['skipped'] > 0)): ?>
                        <div class="mt-2">
                            <strong>Summary:</strong>
                            <?= $response['imported'] ?> imported,
                            <?= $response['skipped'] ?> skipped
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-8">
                    <form id="bulkImportForm" method="post" enctype="multipart/form-data">
                        <div class="mb-4">
                            <label for="student_file" class="form-label">Select Excel File <span class="text-danger">*</span></label>
                            <div class="file-upload-wrapper">
                                <input type="file" class="form-control" id="student_file" name="student_file" accept=".xlsx,.xls" required>
                                <small class="text-muted">Only .xlsx or .xls files are allowed</small>
                            </div>
                        </div>

                        <div class="mb-4">
                            <h5 class="text-primary">File Requirements:</h5>
                            <ul>
                                <li>File must be in Excel format (.xlsx or .xls)</li>
                                <li><strong>Required columns:</strong> Name, Father Name, Date Of Birth, Gender, Class, Admission Date</li>
                                <li><strong>Optional columns:</strong> Phone Number, Address, Car Route, Car Fee, Hostel Fee</li>
                                <li>Gender must be one of: Male, Female, Other</li>
                                <li>Class names must match existing classes in the system</li>
                                <li>Dates should be in DD/MM/YYYY or YYYY-MM-DD format</li>
                                <li>Car Fee and Hostel Fee must be numeric values (integers or decimals)</li>
                                <li>If a Phone Number is provided, it must be 10 digits</li>
                                <li>If Hostel Fee is greater than 0, student will be marked as hosteler automatically</li>
                                <li><strong>Note:</strong> Multiple students can share the same phone number if they have the same father</li>
                                <li><strong>Duplicate Check:</strong> Students with the same name and father name will be skipped</li>
                            </ul>
                        </div>

                        <div class="text-center">
                            <button type="submit" class="btn btn-primary px-4 py-2" id="submitBtn">
                                <i class="fas fa-upload me-2"></i> Upload & Import
                            </button>
                            <a href="../../assets/sample-files/Demo-Bulk-Students-Data.xlsx" class="btn btn-outline-secondary ms-2">
                                <i class="fas fa-download me-2"></i> Download Sample File
                            </a>
                        </div>
                    </form>
                </div>

                <div class="col-md-4">
                    <div class="card border-info">
                        <div class="card-header bg-info text-white">
                            <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i> Instructions</h5>
                        </div>
                        <div class="card-body">
                            <ol>
                                <li>Download the sample file to see the required format</li>
                                <li>Fill in student data keeping the column headers</li>
                                <li>Upload the completed file</li>
                                <li>Review any errors and correct your file if needed</li>
                                <li>Students will be added to their respective classes</li>
                            </ol>
                            <div class="alert alert-warning mt-3">
                                <strong>Important Notes:</strong>
                                <ul class="mb-0 mt-2">
                                    <li>Students with the same father can share phone numbers</li>
                                    <li>Duplicate students (same name + father name) will be automatically skipped</li>
                                    <li>Phone numbers, if provided, are only flagged if they belong to different fathers</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#bulkImportForm').submit(function(e) {
            var fileInput = $('#student_file')[0];

            // Validate file selection
            if (!fileInput.files.length) {
                toastr.error('Please select a file to upload.');
                e.preventDefault();
                return false;
            }

            // Validate file type
            var fileName = fileInput.files[0].name;
            var fileExt = fileName.split('.').pop().toLowerCase();

            if (!['xlsx', 'xls'].includes(fileExt)) {
                toastr.error('Please select a valid Excel file (.xlsx or .xls)');
                e.preventDefault();
                return false;
            }

            // Show loading state
            $('#submitBtn').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i> Processing...');

            // Let the form submit normally (no AJAX to avoid complications)
            return true;
        });
    });
</script>

<?php
include_once("../../includes/body-close.php");

/**
 * Process the bulk import of students from Excel file
 */
function processBulkImport($file, $pdo)
{
    $response = [
        'success' => false,
        'message' => '',
        'errors' => [],
        'imported' => 0,
        'skipped' => 0
    ];

    try {
        // Validate file upload
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $upload_errors = [
                UPLOAD_ERR_INI_SIZE => 'File is too large (exceeds upload_max_filesize)',
                UPLOAD_ERR_FORM_SIZE => 'File is too large (exceeds MAX_FILE_SIZE)',
                UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
                UPLOAD_ERR_NO_FILE => 'No file was uploaded',
                UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
                UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
                UPLOAD_ERR_EXTENSION => 'File upload stopped by extension'
            ];

            $error_msg = isset($upload_errors[$file['error']]) ? $upload_errors[$file['error']] : 'Unknown upload error';
            throw new Exception("File upload error: " . $error_msg);
        }

        // Validate file type
        $allowed_extensions = ['xlsx', 'xls'];
        $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if (!in_array($file_ext, $allowed_extensions)) {
            throw new Exception("Invalid file type. Only Excel files (.xlsx, .xls) are allowed.");
        }

        // Validate file size (max 5MB)
        if ($file['size'] > 5 * 1024 * 1024) {
            throw new Exception("File is too large. Maximum file size is 5MB.");
        }

        // Load the Excel file
        try {
            $spreadsheet = IOFactory::load($file['tmp_name']);
        } catch (Exception $e) {
            throw new Exception("Failed to read Excel file. Please ensure it's a valid Excel file.");
        }

        $worksheet = $spreadsheet->getActiveSheet();
        $rows = $worksheet->toArray(null, true, true, true);

        // Check if file has data
        if (count($rows) < 2) {
            throw new Exception("The Excel file appears to be empty or has no data rows.");
        }

        // Get header row (first row)
        $header_row = array_shift($rows);
        $header = array_map(function ($cell) {
            return trim(strtolower($cell ?? ''));
        }, $header_row);

        // Validate headers - only required ones
        $required_headers = ['name', 'father name', 'date of birth', 'gender', 'class', 'admission date'];
        $missing_headers = [];

        foreach ($required_headers as $req_header) {
            if (!in_array($req_header, $header)) {
                $missing_headers[] = ucwords($req_header);
            }
        }

        if (!empty($missing_headers)) {
            throw new Exception("Missing required columns: " . implode(', ', $missing_headers));
        }

        // Get column indexes for required fields
        $name_index = array_search('name', $header);
        $father_index = array_search('father name', $header);
        $dob_index = array_search('date of birth', $header);
        $gender_index = array_search('gender', $header);
        $class_index = array_search('class', $header);
        $admission_index = array_search('admission date', $header);

        // Get column indexes for optional fields
        $phone_index = array_search('phone number', $header);
        $address_index = array_search('address', $header);
        $car_route_index = array_search('car route', $header);
        $car_fee_index = array_search('car fee', $header);
        $hostel_fee_index = array_search('hostel fee', $header);
        $registration_no_index = array_search('registration no', $header);
        $religion_index = array_search('religion', $header);

        // Get all classes for validation
        $classes = $pdo->query("SELECT id, class_name FROM classes")->fetchAll(PDO::FETCH_KEY_PAIR);

        // Begin transaction
        $pdo->beginTransaction();

        $row_number = 1; // Start from 1 (after header)

        foreach ($rows as $row) {
            $row_number++;

            // Skip completely empty rows
            $row_values = array_values($row);
            if (empty(array_filter($row_values, function ($val) {
                return !empty(trim($val ?? ''));
            }))) {
                continue;
            }

            // Extract and clean required data
            $name = trim($row[$name_index] ?? '');
            $father_name = trim($row[$father_index] ?? '');
            $dob = trim($row[$dob_index] ?? '');
            $gender = trim($row[$gender_index] ?? '');
            $class_name = trim($row[$class_index] ?? '');
            $admission_date = trim($row[$admission_index] ?? '');

            // Extract and clean optional data
            $phone = ($phone_index !== false) ? trim($row[$phone_index] ?? '') : '';
            $address = ($address_index !== false) ? trim($row[$address_index] ?? '') : '';
            $car_route = ($car_route_index !== false) ? trim($row[$car_route_index] ?? '') : '';
            $car_fee = ($car_fee_index !== false) ? trim($row[$car_fee_index] ?? '') : '';
            $hostel_fee = ($hostel_fee_index !== false) ? trim($row[$hostel_fee_index] ?? '') : '';
            $registration_no = ($registration_no_index !== false) ? trim($row[$registration_no_index] ?? '') : '';
            $religion = ($religion_index !== false) ? trim($row[$religion_index] ?? '') : '';

            $row_errors = [];

            // Validate required fields
            if (empty($name)) {
                $row_errors[] = "Row $row_number: Name is required";
            }

            if (empty($father_name)) {
                $row_errors[] = "Row $row_number: Father name is required";
            }

            // Validate and format date of birth
            $dob_formatted = validateAndFormatDate($dob, "Row $row_number: Date of Birth");
            if ($dob_formatted === false) {
                $row_errors[] = "Row $row_number: Invalid Date of Birth format (use DD/MM/YYYY or YYYY-MM-DD)";
            }

            // Check if student already exists (same name and father name)
            if (!empty($name) && !empty($father_name)) {
                $stmt = $pdo->prepare("
                    SELECT COUNT(*) FROM students 
                    WHERE LOWER(TRIM(name)) = LOWER(TRIM(?)) 
                    AND LOWER(TRIM(father_name)) = LOWER(TRIM(?))
                ");
                $stmt->execute([$name, $father_name]);
                if ($stmt->fetchColumn() > 0) {
                    $row_errors[] = "Row $row_number: Student '$name' with father '$father_name' already exists in the database";
                }
            }

            // Validate phone number (if provided)
            if (!empty($phone)) {
                // Clean phone number (remove spaces, dashes, etc.)
                $phone = preg_replace('/[^\d]/', '', $phone);

                if (!preg_match('/^\d{10}$/', $phone)) {
                    $row_errors[] = "Row $row_number: Phone number, if provided, must be exactly 10 digits";
                } else {
                    // Check for duplicate phone number with different father
                    // Allow same phone number for same father (siblings)
                    $stmt = $pdo->prepare("
                        SELECT COUNT(*) FROM students 
                        WHERE phone_number = ? AND LOWER(father_name) != LOWER(?)
                    ");
                    $stmt->execute([$phone, $father_name]);
                    if ($stmt->fetchColumn() > 0) {
                        $row_errors[] = "Row $row_number: Phone number already exists for a different father";
                    }
                }
            } else {
                $phone = null; // Set to null if empty for database insertion
            }

            // Validate gender
            $valid_genders = ['male', 'female', 'other'];
            if (empty($gender)) {
                $row_errors[] = "Row $row_number: Gender is required";
            } elseif (!in_array(strtolower($gender), $valid_genders)) {
                $row_errors[] = "Row $row_number: Gender must be one of: Male, Female, Other";
            } else {
                $gender = ucfirst(strtolower($gender));
            }

            // Validate class
            $class_id = null;
            if (empty($class_name)) {
                $row_errors[] = "Row $row_number: Class is required";
            } else {
                $class_found = false;
                foreach ($classes as $id => $db_class_name) {
                    if (strcasecmp($db_class_name, $class_name) === 0) {
                        $class_id = $id;
                        $class_found = true;
                        break;
                    }
                }

                if (!$class_found) {
                    $available_classes = implode(', ', $classes);
                    $row_errors[] = "Row $row_number: Class '$class_name' not found. Available classes: $available_classes";
                }
            }

            // Validate and format admission date
            $admission_formatted = validateAndFormatDate($admission_date, "Row $row_number: Admission Date");
            if ($admission_formatted === false) {
                $row_errors[] = "Row $row_number: Invalid Admission Date format (use DD/MM/YYYY or YYYY-MM-DD)";
            }

            // Validate optional fields
            $car_fee_value = 0;
            $hostel_fee_value = 0;
            $is_hosteler = 0;

            // Validate Car Fee
            if (!empty($car_fee)) {
                if (!is_numeric($car_fee) || $car_fee < 0) {
                    $row_errors[] = "Row $row_number: Car Fee must be a valid positive number";
                } else {
                    $car_fee_value = (float)$car_fee;
                }
            }

            // Validate Hostel Fee
            if (!empty($hostel_fee)) {
                if (!is_numeric($hostel_fee) || $hostel_fee < 0) {
                    $row_errors[] = "Row $row_number: Hostel Fee must be a valid positive number";
                } else {
                    $hostel_fee_value = (float)$hostel_fee;
                    // Set is_hosteler based on hostel fee
                    $is_hosteler = ($hostel_fee_value > 0) ? 1 : 0;
                }
            }

            // Car Route and Address don't need validation - they're just text

            // If any validation errors, skip this row
            if (!empty($row_errors)) {
                $response['errors'] = array_merge($response['errors'], $row_errors);
                $response['skipped']++;
                continue;
            }

            // Generate unique student ID
            $student_id = generateUniqueStudentId($pdo);

            // Insert student with all fields
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO students (
                        student_id, name, father_name, date_of_birth, phone_number, 
                        gender, class_id, admission_date, address, car_route, registration_no, religion, car_fee, 
                        hostel_fee, is_hosteler, status, updated_at
                    ) VALUES (
                        :student_id, :name, :father_name, :date_of_birth, :phone_number, 
                        :gender, :class_id, :admission_date, :address, :car_route, :registration_no, :religion, :car_fee,
                        :hostel_fee, :is_hosteler, 'Active', NOW()
                    )
                ");

                $stmt->execute([
                    ':student_id' => $student_id,
                    ':name' => $name,
                    ':father_name' => $father_name,
                    ':date_of_birth' => $dob_formatted,
                    ':phone_number' => $phone,
                    ':gender' => $gender,
                    ':class_id' => $class_id,
                    ':admission_date' => $admission_formatted,
                    ':address' => !empty($address) ? $address : null,
                    ':car_route' => !empty($car_route) ? $car_route : null,
                    ':registration_no' => !empty($registration_no) ? $registration_no : null,
                    ':religion' => !empty($religion) ? strtolower($religion) : null,
                    ':car_fee' => $car_fee_value,
                    ':hostel_fee' => $hostel_fee_value,
                    ':is_hosteler' => $is_hosteler
                ]);

                $response['imported']++;
            } catch (PDOException $e) {
                $response['errors'][] = "Row $row_number: Database error - " . $e->getMessage();
                $response['skipped']++;
                continue;
            }
        }

        // Commit or rollback based on results
        if ($response['imported'] > 0) {
            $pdo->commit();
            $response['success'] = true;

            if ($response['skipped'] > 0) {
                $response['message'] = "Import completed with some issues. {$response['imported']} students imported successfully, {$response['skipped']} records skipped due to errors.";
            } else {
                $response['message'] = "All {$response['imported']} students imported successfully!";
            }
        } else {
            $pdo->rollBack();
            $response['success'] = false;
            $response['message'] = "No students were imported. Please check the errors below and correct your file.";
        }
    } catch (Exception $e) {
        if (isset($pdo) && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $response['success'] = false;
        $response['message'] = "Import failed: " . $e->getMessage();
    }

    return $response;
}

/**
 * Validate and format date from various formats
 */
function validateAndFormatDate($dateString, $context = '')
{
    if (empty($dateString)) {
        return false;
    }

    // Handle Excel date serial numbers
    if (is_numeric($dateString)) {
        try {
            $date = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($dateString);
            return $date->format('Y-m-d');
        } catch (Exception $e) {
            return false;
        }
    }

    // Clean the date string
    $dateString = trim($dateString);

    // Handle different date separators and formats
    $separators = ['/', '-', '.'];

    foreach ($separators as $sep) {
        if (strpos($dateString, $sep) !== false) {
            $parts = explode($sep, $dateString);

            if (count($parts) === 3) {
                // Clean parts - remove leading zeros for comparison but keep original values
                $part1 = trim($parts[0]);
                $part2 = trim($parts[1]);
                $part3 = trim($parts[2]);

                // Try DD/MM/YYYY or D/M/YYYY format first (most common in schools)
                if (strlen($part3) === 4 && $part3 >= 1900 && $part3 <= 2100) {
                    $day = intval($part1);
                    $month = intval($part2);
                    $year = intval($part3);

                    // Validate day and month ranges
                    if ($day >= 1 && $day <= 31 && $month >= 1 && $month <= 12) {
                        // Create date and validate it actually exists
                        if (checkdate($month, $day, $year)) {
                            return sprintf('%04d-%02d-%02d', $year, $month, $day);
                        }
                    }
                }

                // Try YYYY/MM/DD or YYYY/M/D format
                if (strlen($part1) === 4 && $part1 >= 1900 && $part1 <= 2100) {
                    $year = intval($part1);
                    $month = intval($part2);
                    $day = intval($part3);

                    // Validate day and month ranges
                    if ($day >= 1 && $day <= 31 && $month >= 1 && $month <= 12) {
                        // Create date and validate it actually exists
                        if (checkdate($month, $day, $year)) {
                            return sprintf('%04d-%02d-%02d', $year, $month, $day);
                        }
                    }
                }

                // Try MM/DD/YYYY or M/D/YYYY format (American format)
                if (strlen($part3) === 4 && $part3 >= 1900 && $part3 <= 2100) {
                    $month = intval($part1);
                    $day = intval($part2);
                    $year = intval($part3);

                    // Only try this if day > 12 (to avoid ambiguity with DD/MM/YYYY)
                    // or if DD/MM/YYYY didn't work above
                    if ($day > 12 || $month > 12) {
                        if ($day >= 1 && $day <= 31 && $month >= 1 && $month <= 12) {
                            if (checkdate($month, $day, $year)) {
                                return sprintf('%04d-%02d-%02d', $year, $month, $day);
                            }
                        }
                    }
                }
            }
        }
    }

    // Try standard DateTime parsing as last resort
    $formats = ['Y-m-d', 'Y/m/d', 'd-m-Y', 'd/m/Y', 'm-d-Y', 'm/d/Y'];

    foreach ($formats as $format) {
        $date = DateTime::createFromFormat($format, $dateString);
        if ($date && $date->format($format) === $dateString) {
            return $date->format('Y-m-d');
        }
    }

    return false;
}

?>
