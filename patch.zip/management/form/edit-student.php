<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Edit Student Info - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    include_once("../../includes/permission-denied.php");
}

// Get student ID from query string
$student_id = $_GET['student_id'] ?? '';
if (!$student_id) {
    die("Student ID is required.");
}

// Fetch student data
$stmt = $pdo->prepare("SELECT * FROM students WHERE student_id = :student_id");
$stmt->execute([':student_id' => $student_id]);
$student = $stmt->fetch();
if (!$student) {
    die("Student not found.");
}

// Fetch classes
$classes = $pdo->query("SELECT id, class_name FROM classes")->fetchAll(PDO::FETCH_ASSOC);

// Blood group options
$blood_groups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

// Religions
$religions = [
    'islam',
    'hindu',
    'christian',
    'buddhist',
    'jain',
    'sikh',
    'parsi',
    'judaism',
    'bahai',
    'atheist',
    'agnostic',
    'other'
];

// Get all driving routes for the car route dropdown.
$routes = $pdo->query("SELECT id, route_name FROM driving_routes ORDER BY route_name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Get drivers according to student routes
$stmt = $pdo->prepare("SELECT * FROM drivers WHERE route_id = :route_id");
$stmt->execute([':route_id' => $student['driving_route_id']]);
$drivers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
    /* Cropper modal styles */
    .modal-xl {
        max-width: 50%;
    }

    .img-container {
        overflow: hidden;
        margin: 0 auto;
    }

    .cropper-container {
        width: 100% !important;
        height: 100% !important;
    }

    .cropper-modal {
        background-color: rgba(255, 255, 255, 0.8);
    }

    .cropper-view-box {
        outline: 2px solid #007bff;
        outline-color: rgba(0, 123, 255, 0.75);
    }
</style>

<div class="container mt-4 mb-5">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0"><i class="fas fa-edit me-2"></i> Edit Student</h4>
        </div>

        <div class="card-body">
            <form id="editStudentForm" enctype="multipart/form-data">
                <input type="hidden" name="student_id" value="<?= safe_htmlspecialchars($student['student_id']) ?>">
                <input type="hidden" id="current_image" name="current_image" value="<?= safe_htmlspecialchars($student['student_image']) ?>">

                <div class="row g-3">
                    <!-- Personal Information Section -->
                    <div class="col-md-12">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-user-circle me-2"></i> Student Information
                        </h5>
                    </div>

                    <input type="hidden" class="form-control" value="<?= safe_htmlspecialchars($student['student_id']) ?>">

                    <div class="col-md-4">
                        <label class="form-label">Full Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="name" required value="<?= safe_htmlspecialchars($student['name']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Gender <span class="text-danger">*</span></label>
                        <select class="form-select" name="gender" required>
                            <option value="Male" <?= $student['gender'] === 'Male' ? 'selected' : '' ?>>Male</option>
                            <option value="Female" <?= $student['gender'] === 'Female' ? 'selected' : '' ?>>Female</option>
                            <option value="Other" <?= $student['gender'] === 'Other' ? 'selected' : '' ?>>Other</option>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Date of Birth <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" name="date_of_birth" required value="<?= safe_htmlspecialchars($student['date_of_birth']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Blood Group</label>
                        <select class="form-select" name="blood_group">
                            <option value="">Select Blood Group</option>
                            <?php foreach ($blood_groups as $group): ?>
                                <option value="<?= $group ?>" <?= $student['blood_group'] === $group ? 'selected' : '' ?>>
                                    <?= $group ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="religion" class="form-label">Religion</label>
                        <select class="form-select" id="religion" name="religion">
                            <option value="">Select Religion</option>
                            <?php foreach ($religions as $religion): ?>
                                <option value="<?= $religion ?>" <?= ($student['religion'] == $religion) ? "selected" : "" ?>>
                                    <?= ucwords($religion) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Address</label>
                        <textarea class="form-control" name="address" rows="2"><?= safe_htmlspecialchars($student['address']) ?></textarea>
                    </div>

                    <!-- Family Information Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-users me-2"></i> Family Information
                        </h5>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Father's Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="father_name" required value="<?= safe_htmlspecialchars($student['father_name']) ?>">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Mother's Name</label>
                        <input type="text" class="form-control" name="mother_name" value="<?= safe_htmlspecialchars($student['mother_name']) ?>">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Father's Occupation</label>
                        <input type="text" class="form-control" name="father_occupation" value="<?= safe_htmlspecialchars($student['father_occupation']) ?>">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Mother's Occupation</label>
                        <input type="text" class="form-control" name="mother_occupation" value="<?= safe_htmlspecialchars($student['mother_occupation']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Phone Number <span class="text-danger">*</span></label>
                        <input type="tel" class="form-control" name="phone_number" required value="<?= safe_htmlspecialchars($student['phone_number']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Alternate Phone Number</label>
                        <input type="tel" class="form-control" name="alternate_phone_number" value="<?= safe_htmlspecialchars($student['alternate_phone_number']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Email Id</label>
                        <input type="email" class="form-control" name="email" value="<?= safe_htmlspecialchars($student['email']) ?>">
                    </div>

                    <!-- Academic Information Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-graduation-cap me-2"></i> Academic Information
                        </h5>
                    </div>

                    <div class="col-md-4">
                        <label for="registration_no" class="form-label">Registration No</label>
                        <input type="text" class="form-control" id="registration_no" name="registration_no" value="<?= safe_htmlspecialchars($student['registration_no']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Class <span class="text-danger">*</span></label>
                        <select class="form-select" name="class_id" id="class_id" required>
                            <option value="">Select Class</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?= $class['id'] ?>" <?= $student['class_id'] == $class['id'] ? 'selected' : '' ?>>
                                    <?= safe_htmlspecialchars($class['class_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Section <span class="text-danger">*</span></label>
                        <select class="form-select" name="section_id" id="section_id" required>
                            <option value="">Select Section</option>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Roll No <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" name="roll_no" required value="<?= safe_htmlspecialchars($student['roll_no']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Admission Date <span class="text-danger">*</span></label>
                        <input type="date" class="form-control" name="admission_date" required value="<?= safe_htmlspecialchars($student['admission_date']) ?>">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Academic Year <span class="text-danger">*</span></label>
                        <select class="form-select" name="academic_year" required>
                            <?php
                            $current_year = date('Y');
                            for ($year = $current_year; $year <= $current_year + 2; $year++) {
                                $selected = ($year == $student['academic_year']) ? 'selected' : '';
                                echo "<option value='$year' $selected>$year</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Status <span class="text-danger">*</span></label>
                        <select class="form-select" name="status" required>
                            <option value="Active" <?= $student['status'] === 'Active' ? 'selected' : '' ?>>Active</option>
                            <option value="Left" <?= $student['status'] === 'Left' ? 'selected' : '' ?>>Left</option>
                            <option value="Alumni" <?= $student['status'] === 'Alumni' ? 'selected' : '' ?>>Alumni</option>
                        </select>
                    </div>

                    <!-- Additional Information Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-info-circle me-2"></i> Additional Information
                        </h5>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Hosteler</label>
                        <div class="d-flex align-items-center">
                            <div class="form-check me-3">
                                <input class="form-check-input" type="radio" name="is_hosteler" id="hosteler_yes" value="1" <?= $student['is_hosteler'] ? 'checked' : '' ?>>
                                <label class="form-check-label" for="hosteler_yes">Yes</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="is_hosteler" id="hosteler_no" value="0" <?= !$student['is_hosteler'] ? 'checked' : '' ?>>
                                <label class="form-check-label" for="hosteler_no">No</label>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <label for="hostel_fee" class="form-label">Hostel Fees</label>
                        <input type="number" class="form-control" id="hostel_fee" name="hostel_fee" value="<?= safe_htmlspecialchars($student['hostel_fee'] ?? 0) ?>" placeholder="Hostel fees amount">
                    </div>

                    <div class="col-md-4">
                        <label for="driving_route" class="form-label">Driving Route</label>
                        <select class="form-select" id="driving_route" name="driving_route">
                            <option value="">Select Driving Route</option>
                            <?php foreach ($routes as $route): ?>
                                <option value="<?= safe_htmlspecialchars($route['id']) ?>" <?= ($student['driving_route_id'] == $route['id']) ? 'selected' : '' ?>>
                                    <?= safe_htmlspecialchars($route['route_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4 car_hide_unhide">
                        <label for="car_fee" class="form-label">Car Fees</label>
                        <input type="number" class="form-control" id="car_fee" name="car_fee" value="<?= safe_htmlspecialchars($student['car_fee'] ?? 0) ?>" placeholder="Car fees amount">
                    </div>

                    <div class="col-md-4 car_hide_unhide">
                        <label for="driver_id" class="form-label">Driver</label>
                        <select class="form-select" id="driver_id" name="driver_id">
                            <option value="">Select Driver</option>
                            <?php foreach ($drivers as $driver): ?>
                                <option value="<?= safe_htmlspecialchars($driver['id']) ?>" <?= ($student['driver_id'] == $driver['id']) ? 'selected' : '' ?>>
                                    <?= safe_htmlspecialchars($driver['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="custom_class_fee" class="form-label">Custom School Fees</label>
                        <input type="number" class="form-control" id="custom_class_fee" name="custom_class_fee" value="<?= safe_htmlspecialchars($student['custom_class_fee'] ?? 0) ?>" placeholder="Custom school fees if applicable">
                    </div>

                    <!-- Photo Upload Section -->
                    <div class="col-md-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">
                            <i class="fas fa-camera me-2"></i> Student Photo
                        </h5>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Passport Photo (Ratio 5:6)</label>
                        <input type="file" class="form-control" id="student_image" name="student_image" accept="image/*">
                        <small class="text-muted">Leave blank to keep existing image. Max size: 2MB.</small>
                        <input type="hidden" id="cropped_image_data" name="cropped_image_data">
                    </div>

                    <div class="col-md-6">
                        <?php if (!empty($student['student_image'])): ?>
                            <img src="../../uploads/students/<?= safe_htmlspecialchars($student['student_image']) ?>" id="currentImage" width="150" class="img-thumbnail mb-2">
                        <?php endif; ?>
                        <img id="imagePreview" src="#" alt="Preview" style="display:none; max-width:150px; max-height:180px;">
                    </div>

                    <!-- Cropping Modal -->
                    <div class="modal fade" id="cropModal" tabindex="-1" aria-labelledby="cropModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-xl"> <!-- Changed to modal-xl for larger size -->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="cropModalLabel">Crop Student Photo</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body p-0"> <!-- Added p-0 to remove padding -->
                                    <div class="img-container" style="width: 100%; height: 70vh;"> <!-- Set fixed height -->
                                        <img id="imageToCrop" src="#" alt="Image to crop" style="max-width: 100%; max-height: 100%; display: block;">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    <button type="button" class="btn btn-primary" id="cropImageBtn">Crop & Save</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="mt-4 text-center">
                    <button type="submit" class="btn btn-primary px-4 py-2">
                        <i class="fas fa-save me-2"></i> Update Student
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Function to fetch drivers based on selected car route
    function fetchDriversByRoute(routeId) {
        if (!routeId) {
            $('#driver_id').html('<option value="" disabled selected>Select Driver</option>');
            return;
        }

        $.ajax({
            url: '../ajax/get-drivers-by-driving-route-id.php',
            type: 'GET',
            data: {
                route_id: routeId
            },
            dataType: 'json',
            success: function(drivers) {
                let options = '<option value="" disabled selected>Select Driver</option>';
                if (drivers.length > 0) {
                    drivers.forEach(driver => {
                        options += `<option value="${driver.id}">${driver.name}</option>`;
                    });
                } else {
                    options += '<option value="" disabled>No drivers available for this route</option>';
                }
                $('#driver_id').html(options);
            },
            error: function(xhr, status, error) {
                console.error("Failed to fetch drivers:", status, error);
                $('#driver_id').html('<option value="" disabled selected>Error loading drivers</option>');
            }
        });
    }

    $(document).ready(function() {

        // Show or hide inputbox accordingly
        var isHosteler = $('input[name="is_hosteler"]:checked').val();

        if (isHosteler === "1") {
            $('#hostel_fee').parent().show();
        } else {
            $('#hostel_fee').parent().hide();
        }

        if ($('#driving_route').val().trim() !== "") {
            // $('[name="car_fee"]').parent().show();
            $('.car_hide_unhide').show();
        } else {
            // $('[name="car_fee"]').parent().hide();
            $('.car_hide_unhide').hide();
        }

        $('input[name="is_hosteler"]').on('change', function() {
            var selectedValue = $(this).val();

            if (selectedValue === "1") {
                $('#hostel_fee').parent().show();
            } else {
                $('#hostel_fee').parent().hide();
            }
        });

        $('#driving_route').on('input', function() {
            if ($(this).val().trim() !== "") {
                $('.car_hide_unhide').show();
                fetchDriversByRoute($(this).val());
            } else {
                $('.car_hide_unhide').hide();
                $('[name="car_fee"]').val("");
                $('#driver_id').val('');
                $('#driver_id').html('<option value="" disabled selected>Select Driver</option>');
            }
        });

        // Initialize sections dropdown
        function loadSections(classId, selectedSectionId = null) {
            if (!classId) return;
            $.ajax({
                url: '../ajax/get-sections-by-class.php',
                type: 'GET',
                data: {
                    class_id: classId
                },
                success: function(data) {
                    const sections = JSON.parse(data);
                    $('#section_id').empty().append('<option value="">Select Section</option>');
                    sections.forEach(section => {
                        const selected = section.id == selectedSectionId ? 'selected' : '';
                        $('#section_id').append(`<option value="${section.id}" ${selected}>${section.section_name}</option>`);
                    });
                }
            });
        }

        // Initial load with existing values
        const currentClassId = $('#class_id').val();
        const currentSectionId = "<?= $student['section_id'] ?>";
        loadSections(currentClassId, currentSectionId);

        // On class change
        $('#class_id').on('change', function() {
            loadSections($(this).val());
        });

        // Image preview
        $('input[name="student_image"]').change(function(e) {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                reader.onload = function(event) {
                    $('#imagePreview').attr('src', event.target.result).show();
                    $('#currentImage').hide();
                }
                reader.readAsDataURL(this.files[0]);
            }
        });

        // AJAX form submission
        $('#editStudentForm').submit(function(e) {
            e.preventDefault();

            const studentId = $('#student_id').val();
            const regex = /^[A-Za-z0-9]+$/;

            if (!regex.test(studentId)) {
                toastr.error('Student ID can only contain letters and numbers');
                e.preventDefault();
                return false;
            }

            const formData = new FormData(this);

            $.ajax({
                url: '../action/process-edit-student.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                beforeSend: function() {
                    $('button[type="submit"]').prop('disabled', true)
                        .html('<i class="fas fa-spinner fa-spin me-2"></i> Updating...');
                },
                success: function(response) {
                    // First check if response is already parsed
                    if (typeof response === 'string') {
                        try {
                            response = JSON.parse(response);
                        } catch (e) {
                            console.error("Failed to parse response:", response);
                            toastr.error("Invalid server response");
                            return;
                        }
                    }

                    if (response.success) {
                        toastr.success(response.message || 'Student updated successfully!');
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message || 'Student updated successfully!',
                            confirmButtonText: 'OK',
                            allowOutsideClick: false,
                            allowEscapeKey: false
                        }).then(() => {
                            // Redirect after clicking OK
                            window.location.href = '../view/list-students.php';
                        });
                    } else {
                        toastr.error(response.message || 'Operation failed');
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: response.message || 'Operation failed',
                            confirmButtonText: 'OK'
                        });
                        $('button[type="submit"]').prop('disabled', false).html('<i class="fas fa-save me-2"></i> Update Student');
                    }
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error:", status, error, xhr.responseText);
                    $('button[type="submit"]').prop('disabled', false)
                        .html('<i class="fas fa-save me-2"></i> Update Student');
                    try {
                        const response = JSON.parse(xhr.responseText);
                        toastr.error(response.message || 'An error occurred');
                    } catch (e) {
                        toastr.error('An error occurred. Please check console for details.');
                    }
                }
            });
        });

        // Image cropping
        // Initialize cropper when modal is shown
        let cropper;
        const imageToCrop = document.getElementById('imageToCrop');
        const cropModal = new bootstrap.Modal(document.getElementById('cropModal'));

        // Initialize cropper with proper settings
        document.getElementById('student_image').addEventListener('change', function(e) {
            const files = e.target.files;
            if (files && files.length > 0) {
                const file = files[0];
                const reader = new FileReader();

                reader.onload = function(event) {
                    // Show the cropping modal
                    imageToCrop.src = event.target.result;
                    cropModal.show();

                    // Initialize cropper after image is loaded
                    imageToCrop.onload = function() {
                        if (cropper) {
                            cropper.destroy();
                        }

                        cropper = new Cropper(imageToCrop, {
                            aspectRatio: 5 / 6,
                            viewMode: 1, // Ensure the crop box doesn't exceed the image
                            autoCropArea: 0.8, // Automatically select 80% of the image
                            responsive: true,
                            restore: false,
                            guides: false,
                            center: false,
                            highlight: false,
                            cropBoxMovable: true,
                            cropBoxResizable: true,
                            toggleDragModeOnDblclick: false,
                            minContainerWidth: 800,
                            minContainerHeight: 600,
                            ready: function() {
                                // Fit the image to the container when ready
                                this.cropper.setCropBoxData({
                                    width: 500,
                                    height: 600
                                });
                            }
                        });
                    };
                };
                reader.readAsDataURL(file);
            }
        });

        // Handle crop button click
        document.getElementById('cropImageBtn').addEventListener('click', function() {
            if (cropper) {
                // Get cropped canvas
                const canvas = cropper.getCroppedCanvas({
                    width: 500,
                    height: 600,
                    minWidth: 500,
                    minHeight: 600,
                    maxWidth: 500,
                    maxHeight: 600,
                    fillColor: '#fff',
                    imageSmoothingEnabled: true,
                    imageSmoothingQuality: 'high',
                });

                if (canvas) {
                    // Convert canvas to blob
                    canvas.toBlob(function(blob) {
                        // Create a new File from the blob
                        const file = new File([blob], document.getElementById('student_image').files[0].name, {
                            type: 'image/jpeg',
                            lastModified: Date.now()
                        });

                        // Create a new DataTransfer to replace the file input
                        const dataTransfer = new DataTransfer();
                        dataTransfer.items.add(file);
                        document.getElementById('student_image').files = dataTransfer.files;

                        // Update preview
                        const img = document.getElementById('imagePreview');
                        img.src = URL.createObjectURL(blob);
                        img.style.display = 'block';
                        $('#currentImage').hide();

                        // Also store the base64 version for AJAX submission
                        const croppedImageData = canvas.toDataURL('image/jpeg');
                        document.getElementById('cropped_image_data').value = croppedImageData;

                        // Close the modal
                        cropModal.hide();

                        // Destroy cropper
                        cropper.destroy();
                        cropper = null;
                    }, 'image/jpeg', 0.9);
                }
            }
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>