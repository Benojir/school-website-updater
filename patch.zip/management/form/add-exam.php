<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Add Exams - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_EXAMS)) {
    include_once("../../includes/permission-denied.php");
}
?>

<div class="container py-4">
    <div class="card shadow-lg mx-4 mx-md-5">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-plus-circle me-2"></i> Add New Exam</h3>
                <a href="../view/list-exams.php" class="btn btn-light btn-sm">
                    <i class="fas fa-list me-1"></i> View Exams
                </a>
            </div>
        </div>

        <div class="card-body p-4 p-md-5">
            <form id="addExamForm" method="POST">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exam_name" class="form-label fw-bold">Exam Name</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-pen"></i></span>
                                <input type="text" name="exam_name" id="exam_name" class="form-control" required
                                    placeholder="e.g. Midterm Exam">
                            </div>
                            <div class="form-text">Enter the exam name (e.g. Final, Unit Test)</div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exam_date" class="form-label fw-bold">Exam Date</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-calendar-day"></i></span>
                                <input type="date" name="exam_date" id="exam_date" class="form-control" required
                                    min="<?= date('Y-m-d') ?>">
                            </div>
                            <div class="form-text">Select the exam date</div>
                        </div>
                    </div>
                </div>

                <div class="text-center mt-4">
                    <button type="submit" id="submitBtn" class="btn btn-primary px-4">
                        <i class="fas fa-save me-2"></i> Save Exam
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // AJAX form submission
    $('#addExamForm').submit(function(e) {
        e.preventDefault();
        const formData = $(this).serialize();
        const submitBtn = $('#submitBtn');
        
        // Change button state
        submitBtn.prop('disabled', true).html(
            '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Saving...'
        );

        $.ajax({
            url: '../action/save-exam.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                    // Reset form on success
                    $('#addExamForm')[0].reset();
                    // Optional: Redirect after delay
                    // setTimeout(() => { window.location.href = '../view/list-exams.php'; }, 1500);
                } else {
                    toastr.error(response.message);
                }
                submitBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i> Save Exam');
            },
            error: function(xhr, status, error) {
                toastr.error('An error occurred. Please try again.');
                console.error(error);
                submitBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i> Save Exam');
            }
        });
    });

    // Set minimum date to today
    $('#exam_date').attr('min', new Date().toISOString().split('T')[0]);
});
</script>

<?php include_once("../../includes/body-close.php"); ?>