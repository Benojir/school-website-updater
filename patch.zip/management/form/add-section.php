<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/db.php");

// Get all classes
$classes = $pdo->query("SELECT * FROM classes ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

// Initialize message variable
$message = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $class_id = $_POST['class_id'];
    $section_name = strtoupper(trim($_POST['section_name']));
    $response = ['success' => false, 'message' => ''];
    
    if (!empty($class_id) && !empty($section_name)) {
        $check = $pdo->prepare("SELECT * FROM sections WHERE class_id = :class_id AND section_name = :section_name");
        $check->execute([':class_id' => $class_id, ':section_name' => $section_name]);

        if ($check->rowCount() > 0) {
            $response['message'] = "Section already exists for this class.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO sections (class_id, section_name) VALUES (:class_id, :section_name)");
            if ($stmt->execute([':class_id' => $class_id, ':section_name' => $section_name])) {
                $response['success'] = true;
                $response['message'] = "Section added successfully!";
            } else {
                $response['message'] = "Failed to add section. Please try again.";
            }
        }
    } else {
        $response['message'] = "Please fill in all fields.";
    }

    // If AJAX request, return JSON response
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    } else {
        // Fallback for non-JS users
        $message = $response['success'] 
            ? "<div class='alert alert-success mt-3'>{$response['message']}</div>"
            : "<div class='alert alert-danger mt-3'>{$response['message']}</div>";
    }
}

// Now output the HTML
include_once("../../includes/header-open.php");
echo "<title>Add Sections In Classes - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if ($_SESSION['user']['role'] !== 'superadmin') {
   include_once("../../includes/permission-denied.php");
}
?>

<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="mb-0"><i class="fas fa-layer-group me-2"></i>Add New Section</h4>
                <a href="../form/add-class.php" class="btn btn-light btn-sm">
                    <i class="fas fa-plus me-1"></i> Add New Class
                </a>
            </div>
        </div>
        <div class="card-body">
            <div id="message-container"><?= $message ?></div>
            
            <form id="addSectionForm" method="POST" action="add-section.php">
                <div class="mb-3">
                    <label for="class_id" class="form-label">Select Class</label>
                    <select name="class_id" id="class_id" class="form-select" required>
                        <option value="">-- Select Class --</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?= $class['id'] ?>"><?= safe_htmlspecialchars($class['class_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="section_name" class="form-label">Section Name</label>
                    <input type="text" name="section_name" id="section_name" class="form-control" 
                           placeholder="e.g., A, B, C" required maxlength="2" pattern="[A-Za-z]{1,2}">
                    <div class="form-text">Enter a single letter or two-letter section name</div>
                </div>

                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button type="submit" class="btn btn-primary px-4">
                        <i class="fas fa-save me-2"></i>Save Section
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Handle form submission via AJAX
    $('#addSectionForm').on('submit', function(e) {
        e.preventDefault();
        
        var form = $(this);
        var formData = form.serialize();
        var submitBtn = form.find('button[type="submit"]');
        
        // Disable button during processing
        submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Processing...');
        
        $.ajax({
            url: form.attr('action'),
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                    // form[0].reset();
                } else {
                    toastr.error(response.message);
                }
            },
            error: function(xhr, status, error) {
                toastr.error('An error occurred. Please try again.');
                console.error(xhr.responseText);
            },
            complete: function() {
                submitBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i>Save Section');
            }
        });
    });
});
</script>

<?php include_once("../../includes/body-close.php"); ?>