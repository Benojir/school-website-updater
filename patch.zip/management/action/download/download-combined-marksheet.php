<?php
include_once("../../../includes/auth-check.php");
include_once("../../../includes/permission-check.php");

if (!hasPermission(PERM_MANAGE_RESULTS)) {
    die("You do not have permission to perform this action.");
}

if (!isset($_GET['exam_ids']) || !isset($_GET['student_ids'])) {
    die("Required fields are missing.");
}

$exam_ids = explode(',', $_GET['exam_ids']);
$student_ids = explode(',', $_GET['student_ids']);

// School information
$school_name = $schoolInfo['name'];
$school_address = $schoolInfo['address'];
$school_contacts = 'Phone: ' . $schoolInfo['phone'] . ' | Email: ' . $schoolInfo['email'];

// Load HTML template and CSS
$css_style = file_get_contents('../../../marksheet-templates/combined-marksheets/design1/design.css');
$css = "<style>" . $css_style . "</style>";
$template = file_get_contents('../../../marksheet-templates/combined-marksheets/design1/design.html');
$template = str_replace('<link rel="stylesheet" href="design.css">', $css, $template);

$all_html_content = '';

foreach ($student_ids as $student_id) {
    $exam_tables = '';
    $overall_data = [];
    
    foreach ($exam_ids as $exam_id) {
        // Fetch result details
        $stmt = $pdo->prepare("
            SELECT r.*, s.*, e.exam_name, e.exam_date, c.class_name, sec.section_name
            FROM results r
            JOIN students s ON r.student_id = s.student_id
            JOIN exams e ON r.exam_id = e.id
            JOIN classes c ON r.class_id = c.id
            JOIN sections sec ON s.section_id = sec.id
            WHERE r.student_id = ? AND r.exam_id = ? AND (s.status = 'Active' OR s.status = 'Alumni')
        ");
        $stmt->execute([$student_id, $exam_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$result) continue;

        // Fetch subject marks
        $stmt = $pdo->prepare("
            SELECT sm.*, sub.subject_name, sub.subject_type 
            FROM subject_marks sm
            JOIN subjects sub ON sm.subject_id = sub.id
            WHERE sm.result_id = ? ORDER BY sub.subject_type
        ");
        $stmt->execute([$result['id']]);
        $subject_marks = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Build subject rows
        $subject_rows = "";
        foreach ($subject_marks as $subject) {
            $subject_rows .= "<tr>
                <td>".htmlspecialchars($subject['subject_name'])."</td>
                <td>".round($subject['theory_marks'])."</td>
                <td>".round($subject['practical_marks'])."</td>
                <td>".round($subject['total_marks'])."</td>
                <td>".round($subject['obtained_marks'])."</td>
                <td><strong>".htmlspecialchars($subject['grade'])."</strong></td>
            </tr>";
            
            // Accumulate overall data
            if (!isset($overall_data[$subject['subject_name']])) {
                $overall_data[$subject['subject_name']] = [
                    'theory' => 0,
                    'practical' => 0,
                    'total' => 0,
                    'obtained' => 0,
                    'count' => 0
                ];
            }
            $overall_data[$subject['subject_name']]['theory'] += $subject['theory_marks'];
            $overall_data[$subject['subject_name']]['practical'] += $subject['practical_marks'];
            $overall_data[$subject['subject_name']]['total'] += $subject['total_marks'];
            $overall_data[$subject['subject_name']]['obtained'] += $subject['obtained_marks'];
            $overall_data[$subject['subject_name']]['count']++;
        }

        // Add exam table
        $exam_tables .= '<div class="marks-table">
            <div class="marks-table-exam-name">'.htmlspecialchars($result['exam_name']).'</div>
            <table>
                <thead>
                    <tr>
                        <th>Subject</th>
                        <th>Written</th>
                        <th>Oral</th>
                        <th>Total</th>
                        <th>Obtained</th>
                        <th>Grade</th>
                    </tr>
                </thead>
                <tbody>'.$subject_rows.'</tbody>
            </table>
        </div>';
    }

    // Build overall table
    $overall_rows = "";
    foreach ($overall_data as $subject => $data) {
        $count = max(1, $data['count']);
        $overall_rows .= "<tr>
            <td>".htmlspecialchars($subject)."</td>
            <td>".round($data['theory']/$count)."</td>
            <td>".round($data['practical']/$count)."</td>
            <td>".round($data['total']/$count)."</td>
            <td>".round($data['obtained']/$count)."</td>
            <td>".calculateGrade($data['obtained']/$data['total']*100)."</td>
        </tr>";
    }

    // Build grading system table
    $grading_rows = "";
    $stmt = $pdo->prepare("SELECT * FROM grading_system ORDER BY min_percentage DESC");
    $stmt->execute();
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $grade) {
        $grading_rows .= "<tr>
            <td>".floor($grade['min_percentage'])."% - ".floor($grade['max_percentage'])."%</td>
            <td><strong>".htmlspecialchars($grade['grade'])."</strong></td>
            <td>".htmlspecialchars($grade['remarks'])."</td>
        </tr>";
    }

    // Replace placeholders
    $page_html = str_replace([
        '{{school_name}}',
        '{{school_address}}',
        '{{school_contacts}}',
        '{{student_id}}',
        '{{roll_no}}',
        '{{student_name}}',
        '{{father_name}}',
        '{{class_name}}',
        '{{section_name}}',
        '{{exam_tables}}',
        '{{overall_rows}}',
        '{{grading_rows}}'
    ], [
        htmlspecialchars($school_name),
        htmlspecialchars($school_address),
        htmlspecialchars($school_contacts),
        htmlspecialchars($result['student_id']),
        htmlspecialchars($result['roll_no']),
        htmlspecialchars($result['name']),
        htmlspecialchars($result['father_name']),
        htmlspecialchars($result['class_name']),
        htmlspecialchars($result['section_name']),
        $exam_tables,
        $overall_rows,
        $grading_rows
    ], $template);

    $all_html_content .= $page_html;
}

echo $all_html_content; // For testing purposes, output the HTML
exit;

function calculateGrade($percentage) {
    // Implement your grade calculation logic
    if ($percentage >= 80) return 'A+';
    if ($percentage >= 70) return 'A';
    if ($percentage >= 60) return 'B';
    if ($percentage >= 50) return 'C';
    if ($percentage >= 40) return 'D';
    return 'F';
}