<?php
include_once("../../../includes/auth-check.php");
include_once("../../../includes/permission-check.php");
include_once("../../../includes/browsershot.php");

$log_directory = __DIR__ . '/../../../assets/logs/';
if (!is_dir($log_directory)) {
    mkdir($log_directory, 0755, true);
}

use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;

// Check for permission
if (!hasPermission(PERM_MANAGE_RESULTS)) {
    die("You do not have permission to perform this action.");
}

if (!isset($_GET['result_ids'])) {
    die("Result IDs are required");
}

$result_ids = explode(',', $_GET['result_ids']);

// Load the HTML template
$template = file_get_contents('../../../marksheet-templates/single-marksheets/design1/design.html');

$all_html_content = file_get_contents('../../../marksheet-templates/html-open.html');
$all_html_content .= file_get_contents('../../../marksheet-templates/single-marksheets/design1/design-css.html');

// School information
$school_name = $schoolInfo['name'];
$school_address = $schoolInfo['address'];
$school_phone = $schoolInfo['phone'];
$school_email = $schoolInfo['email'];

$school_logo_path = '../../../uploads/school/logo-square.png';
$school_logo_base64 = imageToBase64($school_logo_path);

$principle_sign_path = '../../../uploads/school/principle_sign.png';
$principle_sign_base64 = imageToBase64($principle_sign_path);


// Process each result ID
foreach ($result_ids as $result_id) {
    // Fetch result details with student and exam information
    $stmt = $pdo->prepare("
        SELECT r.*, s.*, e.exam_name, e.exam_date, c.class_name, sec.section_name 
        FROM results r 
        JOIN students s ON r.student_id = s.student_id 
        JOIN exams e ON r.exam_id = e.id 
        JOIN classes c ON r.class_id = c.id 
        LEFT JOIN sections sec ON s.section_id = sec.id 
        WHERE r.id = ? 
        AND (s.status = 'Active' OR s.status = 'Alumni');

    ");
    $stmt->execute([$result_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$result) {
        continue; // Skip if result not found
    }

    // Fetch exam routine
    $routineStmtQuery = "SELECT * FROM exam_routines WHERE exam_id = ? AND class_id = ?";
    $routineStmt = $pdo->prepare($routineStmtQuery);
    $routineStmt->execute([$result['exam_id'], $result['class_id']]);
    $exam_routine = $routineStmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch subject marks
    $stmt = $pdo->prepare("
        SELECT sm.*, sub.subject_name, sub.subject_type 
        FROM subject_marks sm
        JOIN subjects sub ON sm.subject_id = sub.id
        WHERE sm.result_id = ? ORDER BY sub.subject_type
    ");
    $stmt->execute([$result_id]);
    $subject_marks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Build subject rows HTML
    $subject_rows = "";
    foreach ($subject_marks as $subject) {

        if ($subject['is_excluded'] == 1) {
            continue; // Skipping excluded subjects
        }

        $hasWrittenExam = true;
        $hasOralExam = true;

        foreach ($exam_routine as $routine) {
            if ($routine['subject_id'] == $subject['subject_id']) {
                if ($routine['theory_marks'] == 0) {
                    $hasWrittenExam = false;
                }
                if ($routine['practical_marks'] == 0) {
                    $hasOralExam = false;
                }
            }
        }

        $subject_rows .= "<tr>
            <td>" . safe_htmlspecialchars($subject['subject_name']) . "</td>
            <td>" . safe_htmlspecialchars($subject['subject_type']) . "</td>
            <td>" . ($hasWrittenExam ? ($subject['is_absent'] == 1 ? '<span style="color:red;">X</span>' : round($subject['theory_marks'])) : '-') . "</td>
            <td>" . ($hasOralExam ? ($subject['is_absent'] == 1 ? '<span style="color:red;">X</span>' : round($subject['practical_marks'])) : '-') . "</td>
            <td>" . round($subject['total_marks']) . "</td>
            <td>" . round($subject['obtained_marks']) . "</td>
            <td><strong>" . safe_htmlspecialchars($subject['grade']) . "</strong></td>
        </tr>";
    }

    // Fetch grading system
    $stmt = $pdo->prepare("SELECT * FROM grading_system ORDER BY min_percentage DESC");
    $stmt->execute();
    $grading_system = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $grading_rows = "";
    foreach ($grading_system as $grade) {
        $range = floor($grade['min_percentage']) . '% - ' . floor($grade['max_percentage']) . '%';
        $grading_rows .= "<tr>
            <td>" . $range . "</td>
            <td><strong>" . safe_htmlspecialchars($grade['grade']) . "</strong></td>
            <td>" . safe_htmlspecialchars($grade['remarks']) . "</td>
        </tr>";
    }
    
    // Generate QR Code
    $qrContent = "Student: {$result['name']}\nID: {$result['student_id']}\nPercentage: " . number_format($result['percentage'], 2) . "%";
    $qrCode = new QrCode($qrContent);
    $writer = new PngWriter();
    $qr_code_base64 = $writer->write($qrCode)->getDataUri();

    // Student Photo Base64
    $student_photo_path = '../../../uploads/students/' . $result['student_image'];
    $student_photo_base64 = imageToBase64($student_photo_path);

    // Promotion Status
    $promotion_status_row = $result['is_promoted'] ? '<tr><td><strong>Promotion Status:</strong></td><td colspan="3">Promoted</td></tr>' : '';


    // Replace placeholders in the template
    $page_html = $template;
    $placeholders = [
        '{{school_logo_base64}}'      => $school_logo_base64,
        '{{school_name}}'             => safe_htmlspecialchars($school_name),
        '{{school_address}}'          => safe_htmlspecialchars($school_address),
        '{{school_phone}}'            => safe_htmlspecialchars($school_phone),
        '{{school_email}}'            => safe_htmlspecialchars($school_email),
        '{{exam_name}}'               => strtoupper(safe_htmlspecialchars($result['exam_name'])),
        '{{student_id}}'              => safe_htmlspecialchars($result['student_id']),
        '{{roll_no}}'                 => safe_htmlspecialchars($result['roll_no']),
        '{{student_name}}'            => safe_htmlspecialchars($result['name']),
        '{{father_name}}'             => safe_htmlspecialchars($result['father_name']),
        '{{class_name}}'              => safe_htmlspecialchars($result['class_name']),
        '{{section_name}}'            => safe_htmlspecialchars($result['section_name']),
        '{{exam_date}}'               => safe_htmlspecialchars($result['exam_date']),
        '{{student_photo_base64}}'    => $student_photo_base64,
        '{{subject_rows}}'            => $subject_rows,
        '{{total_marks}}'             => round($result['total_marks']),
        '{{obtained_marks}}'          => round($result['obtained_marks']),
        '{{percentage}}'              => number_format($result['percentage'], 2),
        '{{overall_grade}}'           => safe_htmlspecialchars($result['grade']),
        '{{position_in_class}}'       => getOrdinal(getStudentPositionInClass($pdo, $result['exam_id'], $result['class_id'], $result['student_id'])),
        '{{result_status}}'           => getPassFailStatus($result['grade']),
        '{{remarks}}'                 => safe_htmlspecialchars($result['remarks']),
        '{{promotion_status_row}}'    => $promotion_status_row,
        '{{grading_rows}}'            => $grading_rows,
        '{{qr_code_base64}}'          => $qr_code_base64,
        '{{principle_sign_base64}}'   => $principle_sign_base64
    ];

    foreach ($placeholders as $key => $value) {
        $page_html = str_replace($key, $value, $page_html);
    }
    
    $all_html_content .= $page_html;
}

// Close the HTML body
$all_html_content .= '</body></html>';

// For debugging: Save the combined HTML to a file
file_put_contents($log_directory . 'marksheets_output.html', $all_html_content);

// Generate PDF from the combined HTML
$output_file_name = "marksheets_" . date('Ymd_His');
generatePDF($all_html_content, $output_file_name);
