<?php
ob_start();
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/db.php");
require_once("../../includes/functions.php");

header('Content-Type: application/json');

if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    function clean($data) {
        return ucwords(safe_htmlspecialchars(trim($data)));
    }

    function saveBase64Image($base64_string, $upload_dir, $prefix = 'stu_') {
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
        if (preg_match('/^data:image\/(\w+);base64,/', $base64_string, $type)) {
            $data = substr($base64_string, strpos($base64_string, ',') + 1);
            $type = strtolower($type[1]);
            if (!in_array($type, ['jpg', 'jpeg', 'png', 'gif'])) return false;
            $data = base64_decode($data);
            if ($data === false || strlen($data) > 2 * 1024 * 1024) return false;
        } else {
            return false;
        }
        $file_name = uniqid($prefix) . '.' . $type;
        $file_path = $upload_dir . $file_name;
        if (file_put_contents($file_path, $data)) {
            if (!getimagesize($file_path)) {
                unlink($file_path);
                return false;
            }
            return $file_name;
        }
        return false;
    }

    function isRollNumberUnique($pdo, $roll_no, $class_id, $student_id) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE roll_no = :roll_no AND class_id = :class_id AND student_id != :student_id");
        $stmt->execute([':roll_no' => $roll_no, ':class_id' => $class_id, ':student_id' => $student_id]);
        return $stmt->fetchColumn() == 0;
    }

    function getStudentClassId($pdo, $student_id) {
        $stmt = $pdo->prepare("SELECT class_id FROM students WHERE student_id = :student_id");
        $stmt->execute([':student_id' => $student_id]);
        return $stmt->fetchColumn();
    }

    if (empty($_POST['student_id'])) {
        throw new Exception("Student ID is required");
    }

    $student_id = trim($_POST['student_id']);
    
    // Get student's current class_id for validation
    $student_class_id = getStudentClassId($pdo, $student_id);
    if (!$student_class_id) {
        throw new Exception("Student not found");
    }
    
    // --- Build the SQL update query dynamically ---
    $updateFields = [];
    $params = [':student_id' => $student_id];

    // Field processing mapping
    $field_map = [
        'section_id' => 'int', 'roll_no' => 'int', 'phone_number' => 'string',
        'alternate_phone_number' => 'string', 'blood_group' => 'string', 'mother_name' => 'string',
        'address' => 'string', 'father_occupation' => 'string', 'mother_occupation' => 'string',
        'car_route' => 'string', 'car_fee' => 'decimal', 'hostel_fee' => 'decimal'
    ];

    foreach ($field_map as $field_name => $type) {
        if (isset($_POST[$field_name])) {
            $value = trim($_POST[$field_name]);
            
            // Validation and special handling
            if ($field_name === 'roll_no') {
                if ($value !== '' && (!is_numeric($value) || $value <= 0)) throw new Exception("Roll number must be a positive number");
                if ($value !== '' && !isRollNumberUnique($pdo, $value, $student_class_id, $student_id)) {
                    throw new Exception("Roll number {$value} is already assigned in this class");
                }
            }
            if (($field_name === 'phone_number' || $field_name === 'alternate_phone_number') && $value !== '' && !isValidPhoneNumber($value)) {
                 throw new Exception("Invalid phone number format. It should be 10 digits.");
            }

            $updateFields[] = "{$field_name} = :{$field_name}";
            $params[":{$field_name}"] = ($value === '') ? null : $value;

            // ** Special logic for is_hosteler based on hostel_fee **
            if ($field_name === 'hostel_fee') {
                 $is_hosteler = (!is_null($params[':hostel_fee']) && $params[':hostel_fee'] > 0) ? 1 : 0;
                 $updateFields[] = "is_hosteler = :is_hosteler";
                 $params[':is_hosteler'] = $is_hosteler;
            }
        }
    }

    // Handle image upload
    if (!empty($_POST['cropped_image_data'])) {
        $upload_dir = '../../uploads/students/';
        $cropped_image = saveBase64Image($_POST['cropped_image_data'], $upload_dir);

        if ($cropped_image) {
            $current_image = isset($_POST['current_image']) ? trim($_POST['current_image']) : null;
            if ($current_image && $current_image !== 'default_student_dp.jpg' && file_exists($upload_dir . $current_image)) {
                unlink($upload_dir . $current_image);
            }
            $updateFields[] = "student_image = :student_image";
            $params[':student_image'] = $cropped_image;
            $response['new_image'] = $cropped_image;
        } else {
            throw new Exception("Failed to save cropped image.");
        }
    }

    if (!empty($updateFields)) {
        $updateFields[] = "updated_at = NOW()";
        $sql = "UPDATE students SET " . implode(', ', $updateFields) . " WHERE student_id = :student_id";
        $stmt = $pdo->prepare($sql);
        
        if ($stmt->execute($params)) {
            $response['success'] = true;
            $response['message'] = "Student updated successfully";
        } else {
            throw new Exception("Failed to update student record. SQL Error: " . implode(", ", $stmt->errorInfo()));
        }
    } else {
        $response['success'] = true;
        $response['message'] = "No changes were detected";
    }

} catch (PDOException $e) {
    $response['message'] = "Database error: " . $e->getMessage();
    error_log("PDOException in bulk edit: " . $e->getMessage());
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    error_log("Exception in bulk edit: " . $e->getMessage());
}

ob_end_clean();
echo json_encode($response);
exit();
?>