<?php
//Check admin permission
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/db.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_RESULTS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'errors' => ['You do not have permission to perform this action.']
    ]);
    die();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$exam_id = $_POST['exam_id'] ?? '';
$class_id = $_POST['class_id'] ?? '';
$students = $_POST['students'] ?? [];
$subjects = $_POST['subjects'] ?? [];

if (empty($exam_id) || empty($class_id) || empty($students) || empty($subjects)) {
    echo json_encode(['success' => false, 'message' => 'Required fields are missing']);
    exit;
}

try {
    $pdo->beginTransaction();

    $success_count = 0;
    $error_messages = [];

    // Replace the entire student processing loop with this:

    foreach ($students as $student_id => $student_data) {
        // Check if result already exists for this student and exam
        $stmt = $pdo->prepare("SELECT id FROM results WHERE student_id = ? AND exam_id = ?");
        $stmt->execute([$student_id, $exam_id]);
        $existing_result = $stmt->fetch();

        // Calculate totals
        $total_marks = 0;
        $obtained_marks = 0;
        $subjects_data = [];

        foreach ($student_data['subjects'] as $subject_id => $marks) {
            $total = (float)$marks['total_marks'];
            $obtained = (float)$marks['obtained_marks'];

            if ($obtained > $total) {
                $error_messages[] = "Obtained marks exceed total marks for {$subjects[$subject_id]['subject_name']} (Student: {$student_data['name']})";
                continue 2; // Skip this student
            }

            $total_marks += $total;
            $obtained_marks += $obtained;

            // Calculate subject grade
            $percentage = ($obtained / $total) * 100;
            $stmt = $pdo->prepare("
            SELECT grade, remarks FROM grading_system 
            WHERE ? BETWEEN min_percentage AND max_percentage
            LIMIT 1
        ");
            $stmt->execute([$percentage]);
            $grade_info = $stmt->fetch(PDO::FETCH_ASSOC);

            $subjects_data[] = [
                'subject_id' => $subject_id,
                'theory_marks' => $marks['theory_marks'] ?? null,
                'practical_marks' => $marks['practical_marks'] ?? null,
                'total_marks' => $total,
                'obtained_marks' => $obtained,
                'grade' => $grade_info['grade'],
                'remarks' => $grade_info['remarks']
            ];
        }

        // Calculate overall percentage and grade
        $percentage = ($obtained_marks / $total_marks) * 100;
        $stmt = $pdo->prepare("
        SELECT grade, remarks FROM grading_system 
        WHERE ? BETWEEN min_percentage AND max_percentage
        LIMIT 1
    ");
        $stmt->execute([$percentage]);
        $grade_info = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existing_result) {
            // UPDATE existing result
            $result_id = $existing_result['id'];

            $stmt = $pdo->prepare("
            UPDATE results SET
                total_marks = ?,
                obtained_marks = ?,
                percentage = ?,
                grade = ?,
                remarks = ?,
                updated_at = NOW()
            WHERE id = ?
        ");
            $stmt->execute([
                $total_marks,
                $obtained_marks,
                $percentage,
                $grade_info['grade'],
                $grade_info['remarks'],
                $result_id
            ]);

            // Delete existing subject marks
            $stmt = $pdo->prepare("DELETE FROM subject_marks WHERE result_id = ?");
            $stmt->execute([$result_id]);
        } else {
            // INSERT new result
            $stmt = $pdo->prepare("
            INSERT INTO results (
                student_id, exam_id, class_id, 
                total_marks, obtained_marks, 
                percentage, grade, remarks
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
            $stmt->execute([
                $student_id,
                $exam_id,
                $class_id,
                $total_marks,
                $obtained_marks,
                $percentage,
                $grade_info['grade'],
                $grade_info['remarks']
            ]);

            $result_id = $pdo->lastInsertId();
        }

        // Insert subject marks (same for both new and updated results)
        foreach ($subjects_data as $subject) {
            $stmt = $pdo->prepare("
            INSERT INTO subject_marks (
                result_id, subject_id, 
                theory_marks, practical_marks,
                total_marks, obtained_marks, grade, remarks
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
            $stmt->execute([
                $result_id,
                $subject['subject_id'],
                $subject['theory_marks'],
                $subject['practical_marks'],
                $subject['total_marks'],
                $subject['obtained_marks'],
                $subject['grade'],
                $subject['remarks']
            ]);
        }

        $success_count++;
    }

    $pdo->commit();

    $message = "Successfully added results for $success_count students";
    if (!empty($error_messages)) {
        $message .= ". Errors: " . implode(", ", array_slice($error_messages, 0, 3));
        if (count($error_messages) > 3) {
            $message .= " and " . (count($error_messages) - 3) . " more";
        }
    }

    echo json_encode([
        'success' => true,
        'message' => $message,
        'success_count' => $success_count,
        'error_count' => count($error_messages),
        'errors' => $error_messages
    ]);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
