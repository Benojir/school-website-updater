<?php
require_once("../../includes/db.php");
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/functions.php");

header('Content-Type: application/json');

// Check admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    die(json_encode(['success' => false, 'message' => 'Permission denied']));
}

// Validate inputs
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['class_id']) || !isset($_POST['section_id']) || !isset($_POST['roll_numbers'])) {
    die(json_encode(['success' => false, 'message' => 'Invalid request']));
}

$class_id = (int)$_POST['class_id'];
$section_id = !empty($_POST['section_id']) ? (int)$_POST['section_id'] : null;
$roll_numbers = $_POST['roll_numbers'];

// Verify class
$stmt = $pdo->prepare("SELECT id FROM classes WHERE id = ?");
$stmt->execute([$class_id]);
if (!$stmt->fetch()) {
    die(json_encode(['success' => false, 'message' => 'Invalid class ID']));
}

// Verify section
if ($section_id !== null) {
    $stmt = $pdo->prepare("SELECT id FROM sections WHERE id = ? AND class_id = ?");
    $stmt->execute([$section_id, $class_id]);
    if (!$stmt->fetch()) {
        die(json_encode(['success' => false, 'message' => 'Invalid section ID or section does not belong to class']));
    }
}

try {
    $pdo->beginTransaction();

    // Validate all roll numbers are unique in this class-section
    $submitted_rolls = array_values($roll_numbers);
    if (count($submitted_rolls) !== count(array_unique($submitted_rolls))) {
        die(json_encode(['success' => false, 'message' => 'Duplicate roll numbers detected']));
    }

    // Add this after validating unique roll numbers
    foreach ($roll_numbers as $roll_no) {
        if (!is_numeric($roll_no) || $roll_no <= 0) {
            die(json_encode(['success' => false, 'message' => 'Roll numbers must be positive integers']));
        }
    }

    // Check against existing roll numbers in the class-section
    $whereClause = "class_id = ? AND roll_no IS NOT NULL";
    $params = [$class_id];

    if ($section_id !== null) {
        $whereClause .= " AND section_id = ?";
        $params[] = $section_id;
    } else {
        $whereClause .= " AND (section_id IS NULL OR section_id = 0)";
    }

    $stmt = $pdo->prepare("
        SELECT roll_no 
        FROM students 
        WHERE $whereClause
    ");
    $stmt->execute($params);
    $existing_rolls = $stmt->fetchAll(PDO::FETCH_COLUMN);

    $conflicts = array_intersect($submitted_rolls, $existing_rolls);
    if (!empty($conflicts)) {
        die(json_encode([
            'success' => false,
            'message' => 'Roll number conflict with existing students: ' . implode(', ', $conflicts)
        ]));
    }

    // Update roll numbers
    foreach ($roll_numbers as $student_id => $roll_no) {
        $whereClause = "id = ? AND class_id = ?";
        $params = [$roll_no, $student_id, $class_id];

        if ($section_id !== null) {
            $whereClause .= " AND section_id = ?";
            $params[] = $section_id;
        } else {
            $whereClause .= " AND (section_id IS NULL OR section_id = 0)";
        }

        $stmt = $pdo->prepare("
            UPDATE students 
            SET roll_no = ?, updated_at = NOW()
            WHERE $whereClause
        ");
        $stmt->execute($params);
    }

    // Update class_roll_numbers table
    if ($section_id !== null) {
        $max_roll = max(array_merge($existing_rolls, $submitted_rolls));
        $stmt = $pdo->prepare("
            INSERT INTO class_roll_numbers (class_id, section_id, last_roll_number)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE last_roll_number = GREATEST(last_roll_number, ?)
        ");
        $stmt->execute([$class_id, $section_id, $max_roll, $max_roll]);
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Roll numbers assigned successfully!'
    ]);
} catch (PDOException $e) {
    $pdo->rollBack();
    error_log("Roll number assignment error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
