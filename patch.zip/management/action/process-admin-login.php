<?php
require_once("../../includes/config.php");

header('Content-Type: application/json');

// Initialize response
$response = ['status' => 'error', 'message' => 'Invalid request'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $remember = isset($_POST['remember']) && $_POST['remember'] === 'on';
    $hcaptcha_response = $_POST['h-captcha-response'] ?? '';
    
    // Validate inputs
    if (empty($username)) {
        $response['message'] = 'Username is required';
    } elseif (empty($password)) {
        $response['message'] = 'Password is required';
    } elseif (empty($hcaptcha_response)) {
        $response['message'] = 'Please complete the captcha verification';
    } else {
        // Verify hCaptcha
        $hcaptcha_secret = $websiteConfig['captcha_secret_key']; // Replace with your actual secret key
        
        $verify_data = [
            'secret' => $hcaptcha_secret,
            'response' => $hcaptcha_response,
            'remoteip' => $_SERVER['REMOTE_ADDR']
        ];
        
        $verify_response = file_get_contents($captchaVerifyUrl . '?' . http_build_query($verify_data));
        $verify_result = json_decode($verify_response, true);
        
        if (!$verify_result['success']) {
            $response['message'] = 'Captcha verification failed. Please try again.';
        } else {
            try {
                // Check user in database
                $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? LIMIT 1");
                $stmt->execute([$username]);
                $user = $stmt->fetch();
                
                if ($user && password_verify($password, $user['password'])) {
                    // Check if user is active
                    if ($user['status'] !== 'active') {
                        $response['message'] = 'Your account is not active. Please contact administrator.';
                    } else {
                        // Set session variables
                        $_SESSION['user'] = [
                            'id' => $user['id'],
                            'username' => $user['username'],
                            'full_name' => $user['full_name'],
                            'role' => $user['user_role'],
                            'email' => $user['email'],
                            'logged_in' => true
                        ];
                        
                        // Remember me functionality
                        if ($remember) {
                            $token = bin2hex(random_bytes(32));
                            $expiry = time() + (86400 * 30); // 30 days
                            
                            // Store token in database
                            $stmt = $pdo->prepare("UPDATE users SET remember_token = ?, token_expiry = ? WHERE id = ?");
                            $stmt->execute([$token, date('Y-m-d H:i:s', $expiry), $user['id']]);
                            
                            // Set cookie
                            setcookie('remember_me', $token, $expiry, "/");
                        }
                        
                        // Determine redirect URL based on role
                        $redirect = 'dashboard';
                        
                        $response = [
                            'status' => 'success',
                            'message' => 'Login successful! Redirecting...',
                            'redirect' => $redirect
                        ];
                    }
                } else {
                    $response['message'] = 'Invalid username or password';
                }
            } catch (PDOException $e) {
                $response['message'] = 'Database error: ' . $e->getMessage();
            }
        }
    }
}

echo json_encode($response);
?>