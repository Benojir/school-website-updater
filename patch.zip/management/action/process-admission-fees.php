<?php
// Check if user is logged in
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'error' => true
    ]);
    die();
}

// Check if required data is provided
if (!isset($_POST['student_ids']) || empty($_POST['student_ids']) || 
    !isset($_POST['admission_fee']) || empty($_POST['admission_date']) || 
    !isset($_POST['admission_class']) || empty($_POST['payment_status'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Required fields are missing.',
        'error' => true
    ]);
    die();
}

if (!is_numeric($_POST['admission_fee']) || !is_numeric($_POST['admission_unpaid_amount']) || !is_numeric($_POST['admission_class'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid input data provided.',
        'error' => true
    ]);
    die();
}

try {
    // Get form data
    $studentIds = explode(',', $_POST['student_ids']);
    $admissionFee = (double)$_POST['admission_fee'];
    $admissionDate = $_POST['admission_date'];
    $classId = (int)$_POST['admission_class'];
    $paymentStatus = $_POST['payment_status'];
    $unpaidAmount = isset($_POST['admission_unpaid_amount']) ? (double)$_POST['admission_unpaid_amount'] : 0;
    $remark = isset($_POST['remark']) ? $_POST['remark'] : '-';

    // Validate amount must be posive
    if ($admissionFee < 0 || $unpaidAmount < 0) {
         echo json_encode([
            'success' => false,
            'message' => 'Amount must be positive value.',
            'error' => true
        ]);
        die();
    }

    if ($unpaidAmount > $admissionFee) {
         echo json_encode([
            'success' => false,
            'message' => 'Unpaid amount cannot be greater than admission fee.',
            'error' => true
        ]);
        die();
    }

    // Validate payment status
    if (!in_array($paymentStatus, ['paid', 'unpaid'])) {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid payment status.',
            'error' => true
        ]);
        die();
    }

    // Validate the status and unpaid amount
    if ($unpaidAmount > 0 && $paymentStatus == 'paid') {
        echo json_encode([
            'success' => false,
            'message' => 'Unpaid amount and payment status conflicted. Unpaid amount cannot be greater than 0 with \'PAID\' payment status.',
            'error' => true
        ]);
        die();
    } else if ($unpaidAmount == 0 && $paymentStatus == 'unpaid') {
        echo json_encode([
            'success' => false,
            'message' => 'Unpaid amount and payment status conflicted. Unpaid amount cannot be 0 if payment status is \'UNPAID\'.',
            'error' => true
        ]);
        die();
    }

    // Update unpaid amount according to payment status
    if ($paymentStatus == "paid") {
        $unpaidAmount = 0;
    }

    // Update remark according to unpaid amount
    if ($unpaidAmount == $admissionFee) {
        $remark = "Admission fee is not cleared yet. Please pay the admission fee.";
    } else if ($unpaidAmount < $admissionFee && $unpaidAmount !== 0) {
        $remark = "Still admission fee is not cleared. Just partial payment done. Partial paid amount ₹" . ($admissionFee - $unpaidAmount);
    } else if ($unpaidAmount == 0) {
        $remark = "Admission fee is cleared.";
    }

    // Prepare the base query for checking existing records
    $checkQuery = "SELECT id FROM student_admission_fees 
                   WHERE student_id = :student_id AND class_id = :class_id 
                   LIMIT 1";

    // Prepare the insert query
    $insertQuery = "INSERT INTO student_admission_fees 
                    (student_id, admission_fee, unpaid_amount, class_id, admission_date, payment_status, remark, updated_at) 
                    VALUES 
                    (:student_id, :admission_fee, :unpaid_amount, :class_id, :admission_date, :payment_status, :remark, NOW())";

    // Prepare the update query
    $updateQuery = "UPDATE student_admission_fees SET 
                    admission_fee = :admission_fee, 
                    unpaid_amount = :unpaid_amount, 
                    admission_date = :admission_date, 
                    payment_status = :payment_status, 
                    remark = :remark, 
                    updated_at = NOW() 
                    WHERE student_id = :student_id AND class_id = :class_id";

    // Initialize counters
    $insertedCount = 0;
    $updatedCount = 0;
    $errors = [];

    foreach ($studentIds as $studentId) {
        $studentId = trim($studentId);
        if (empty($studentId)) continue;

        try {
            // Check if record exists
            $stmt = $pdo->prepare($checkQuery);
            $stmt->execute([':student_id' => $studentId, ':class_id' => $classId]);
            $existingRecord = $stmt->fetch();

            if ($existingRecord) {
                // Update existing record
                $stmt = $pdo->prepare($updateQuery);
                $stmt->execute([
                    ':student_id' => $studentId,
                    ':class_id' => $classId,
                    ':admission_fee' => $admissionFee,
                    ':unpaid_amount' => $unpaidAmount,
                    ':admission_date' => $admissionDate,
                    ':payment_status' => $paymentStatus,
                    ':remark' => $remark
                ]);
                $updatedCount++;
            } else {
                // Insert new record
                $stmt = $pdo->prepare($insertQuery);
                $stmt->execute([
                    ':student_id' => $studentId,
                    ':admission_fee' => $admissionFee,
                    ':unpaid_amount' => $unpaidAmount,
                    ':class_id' => $classId,
                    ':admission_date' => $admissionDate,
                    ':payment_status' => $paymentStatus,
                    ':remark' => $remark
                ]);
                $insertedCount++;
            }
        } catch (PDOException $e) {
            $errors[] = "Error processing student ID $studentId: " . $e->getMessage();
        }
    }

    // Prepare the success message
    $successMessage = '';
    if ($updatedCount > 0) {
        $successMessage .= "$updatedCount student(s) admission fees updated. ";
    }
    if ($insertedCount > 0) {
        $successMessage .= "$insertedCount student(s) admission fees inserted. ";
    }

    if (($updatedCount > 0 || $insertedCount > 0) && empty($errors)) {
        echo json_encode([
            'success' => true,
            'message' => trim($successMessage),
            'updated_count' => $updatedCount,
            'inserted_count' => $insertedCount,
            'error' => false
        ]);
    } else if (!empty($errors)) {
        echo json_encode([
            'success' => false,
            'message' => trim($successMessage . " Errors: " . implode('; ', $errors)),
            'updated_count' => $updatedCount,
            'inserted_count' => $insertedCount,
            'error' => true
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'No students were processed.',
            'error' => true
        ]);
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred: ' . $e->getMessage(),
        'error' => true
    ]);
}