<?php
// Check if user is logged in
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/db.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['user']['role'] !== 'superadmin') {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['class_id']) && isset($_POST['new_status'])) {
    $class_id = $_POST['class_id'];
    $new_status = (int)$_POST['new_status'];
    
    try {
        // First unmark any other final class if we're marking this one as final
        if ($new_status === 1) {
            $pdo->prepare("UPDATE classes SET is_final_class = 0 WHERE is_final_class = 1")->execute();
        }
        
        // Update the selected class
        $stmt = $pdo->prepare("UPDATE classes SET is_final_class = :status WHERE id = :id");
        if ($stmt->execute([':status' => $new_status, ':id' => $class_id])) {
            $response['success'] = true;
            $response['message'] = $new_status ? 
                "Class marked as final successfully!" : 
                "Class unmarked as final successfully!";
        }
    } catch (PDOException $e) {
        $response['message'] = "Error: " . $e->getMessage();
    }
} else {
    $response['message'] = "Invalid request";
}

echo json_encode($response);
?>