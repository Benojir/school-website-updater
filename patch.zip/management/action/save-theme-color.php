<?php
// Check if user is logged in
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/db.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['user']['role'] !== 'superadmin') {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

// Validate input
if (!isset($_POST['themeColor']) || !preg_match('/^#[a-f0-9]{6}$/i', $_POST['themeColor'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid color format']);
    exit();
}

$themeColor = $_POST['themeColor'];

try {
    // Check if school info exists
    $stmt = $pdo->query("SELECT id FROM website_config LIMIT 1");
    $existingInfo = $stmt->fetch();

    if ($existingInfo) {
        // Update existing record
        $sql = "UPDATE website_config SET theme_color = ? WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $success = $stmt->execute([$themeColor, $existingInfo['id']]);
    } else {
        // Insert new record
        $sql = "INSERT INTO website_config (theme_color) VALUES (?)";
        $stmt = $pdo->prepare($sql);
        $success = $stmt->execute([$themeColor]);
    }

    if ($success) {
        // Calculate darker version for gradients
        $darkColor = adjustBrightness($themeColor, -20);
        
        echo json_encode([
            'success' => true,
            'message' => 'Theme color saved successfully',
            'darkColor' => $darkColor
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to save theme color']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}

// Helper function to adjust color brightness
function adjustBrightness($hex, $steps) {
    $steps = max(-255, min(255, $steps));
    $hex = str_replace('#', '', $hex);
    
    if (strlen($hex) == 3) {
        $hex = str_repeat(substr($hex,0,1), 2).str_repeat(substr($hex,1,1), 2).str_repeat(substr($hex,2,1), 2);
    }
    
    $r = hexdec(substr($hex,0,2));
    $g = hexdec(substr($hex,2,2));
    $b = hexdec(substr($hex,4,2));
    
    $r = max(0,min(255,$r + $steps));
    $g = max(0,min(255,$g + $steps));
    $b = max(0,min(255,$b + $steps));
    
    $r_hex = str_pad(dechex($r), 2, '0', STR_PAD_LEFT);
    $g_hex = str_pad(dechex($g), 2, '0', STR_PAD_LEFT);
    $b_hex = str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
    
    return '#'.$r_hex.$g_hex.$b_hex;
}
?>