<?php
// Check if user is logged in
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'error' => true
    ]);
    die();
}

// Check for required fields
$required = ['studentIDs', 'academic_year'];
foreach ($required as $field) {
    if (empty($_POST[$field])) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'All fields are required',
            'field' => $field
        ]);
        exit;
    }
}

try {
    $student_ids_string = sanitize_input($_POST['studentIDs']);
    $academic_year = sanitize_input($_POST['academic_year']);
    $admission_class_id = sanitize_input($_POST['admission_class']);
    $discount = sanitize_input($_POST['discount']);

    if (empty($discount)) {
        $discount = 0;
    }

    if (!is_numeric(($discount))) {
        throw new Exception('Invalid discount input.');
    }

    // Get Student IDs Array
    $studentIDs = explode(',', $student_ids_string);

    if (count($studentIDs) <= 0) {
        throw new Exception('Invalid student ids');
    }

    $results = [];
    $processedCount = 0;
    $skippedCount = 0;
    $last_proccessed_sid;
    $processedStudentIds = [];

    foreach ($studentIDs as $student_id) {
        // Start transaction for each student
        $pdo->beginTransaction();

        try {
            // Fetch student info
            $stmt = $pdo->prepare("SELECT * FROM students WHERE student_id = ?");
            $stmt->execute([$student_id]);
            $student_info = $stmt->fetch(PDO::FETCH_ASSOC);

            // Skip if not found or student has left
            if (!$student_info || strtolower($student_info['status']) === 'left' || strtolower($student_info['status']) === 'alumni') {
                $results[] = [
                    'student_id' => $student_id,
                    'success' => false,
                    'message' => 'Student not found or has left or alumni',
                    'action' => 'skipped'
                ];
                $skippedCount++;
                $pdo->commit();
                continue;
            }

            $class_id = $student_info['class_id'];

            if (!empty($admission_class_id) && is_numeric($admission_class_id)) {
                $class_id = $admission_class_id;
            }
            
            $remark = "Admission fee";

            if ($discount > 0) {
                $remark = $remark . ' with ' . $discount . '/- discount applied ';
            }

            // Fetch admission fee class wise
            $stmt = $pdo->prepare("SELECT amount FROM class_wise_admission_fees WHERE class_id = ?");
            $stmt->execute([$class_id]);
            $admission_fee_row = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$admission_fee_row) {
                throw new Exception('Admission fee not found for the selected class. Maybe the admission fee is not set for this class?');
            }

            $admission_fee = $admission_fee_row['amount'];

            // Calculate total fees
            $actual_fees = $admission_fee;
            $total_fees_with_discount = $actual_fees - $discount;

            if ($actual_fees <= $discount) {
                $results[] = [
                    'student_id' => $student_id,
                    'success' => false,
                    'message' => "Discount of $discount exceeds or equals the total fees of $actual_fees",
                    'action' => 'skipped'
                ];
                $skippedCount++;
                $pdo->commit();
                continue;
            }

            // Check if this academic year's fee already exists in full_paid_fees
            $stmt = $pdo->prepare("SELECT id FROM admission_full_paid_fees WHERE student_id = ? AND academic_year = ?");
            $stmt->execute([$student_id, $academic_year]);
            if ($stmt->fetch()) {
                $results[] = [
                    'student_id' => $student_id,
                    'success' => false,
                    'message' => "Admission fee for $academic_year already marked as fully paid",
                    'action' => 'skipped'
                ];
                $skippedCount++;
                $pdo->commit();
                continue;
            }

            // Check for existing unpaid fee for this year
            $stmt = $pdo->prepare("SELECT * FROM admission_unpaid_fees WHERE student_id = ? AND academic_year = ? LIMIT 1");
            $stmt->execute([$student_id, $academic_year]);
            $existing_fee = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($existing_fee) {
                // If existing unpaid fee found, check if it's the same amount
                if ($existing_fee['unpaid_amount'] == $total_fees_with_discount && $existing_fee['discount_amount'] == $discount) {
                    $results[] = [
                        'student_id' => $student_id,
                        'success' => false,
                        'message' => "Unpaid admission fee for $academic_year already exists with same amount",
                        'action' => 'skipped'
                    ];
                    $skippedCount++;
                    $pdo->commit();
                    continue;
                }

                // Fetch total partially paid amount
                $stmt = $pdo->prepare("SELECT SUM(partial_paid_amount) as total_partial_paid FROM admission_partial_fees_payments WHERE unpaid_admission_fees_id = ?");
                $stmt->execute([$existing_fee['id']]);
                $total_partial_paid = $stmt->fetchColumn();

                $unpaid_amount_after_discount = $total_fees_with_discount - $total_partial_paid;

                if ($unpaid_amount_after_discount < 0) {
                    $results[] = [
                        'student_id' => $student_id,
                        'success' => false,
                        'message' => "The new unpaid amount after discount is less than the total partially paid amount. Please review the discount or fees. To fix this delete the payment history and re-add the unpaid fee.",
                        'action' => 'skipped'
                    ];
                    $skippedCount++;
                    $pdo->commit();
                    continue;
                }

                // Update existing record
                $updateStmt = $pdo->prepare("UPDATE admission_unpaid_fees SET class_id = ?, actual_amount = ?, unpaid_amount = ?, discount_amount = ?, remark = ? WHERE id = ?");
                $updateStmt->execute([
                    $class_id,
                    $actual_fees,
                    $unpaid_amount_after_discount,
                    $discount,
                    $remark,
                    $existing_fee['id']
                ]);

                $action = 'updated';
                $processedStudentIds[] = $student_id;
            } else {
                // Insert new record
                $insertStmt = $pdo->prepare("
                    INSERT INTO admission_unpaid_fees
                    (student_id, academic_year, class_id, actual_amount, unpaid_amount, discount_amount, remark, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
                ");
                $insertStmt->execute([
                    $student_id,
                    $academic_year,
                    $class_id,
                    $actual_fees,
                    $total_fees_with_discount,
                    $discount,
                    $remark
                ]);

                $action = 'created';
                $processedStudentIds[] = $student_id;
            }

            $results[] = [
                'student_id' => $student_id,
                'success' => true,
                'message' => "Admission fee record {$action} successfully",
                'action' => $action,
                'amount' => $total_fees_with_discount
            ];
            $processedCount++;
            $last_proccessed_sid = $student_id;

            $pdo->commit();

            if (count($processedStudentIds) > 0) {
                $fcmTokens = getFCMTokensFromDatabase($pdo, $processedStudentIds);
                if ($fcmTokens) {
                    $notificationTitle = 'Unpaid Admission Fee (' . $academic_year . ')';
                    $notificationBody = 'Your admission fee has been updated successfully. Please check your account for details.';
                    $data = [
                        'title' => $notificationTitle,
                        'message' => $notificationBody
                    ];
                    try {
                        sendFirebaseNotification($fcmTokens, $notificationTitle, $notificationBody, $data);
                    } catch (Exception $e) {
                        // Log the error if needed
                        // error_log("Failed to send notification: " . $e->getMessage());
                    }
                }
            }
        } catch (Exception $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    echo json_encode([
        'success' => true,
        'message' => "Processed {$processedCount} students, skipped {$skippedCount}",
        'total_students' => count($studentIDs),
        'processed' => $processedCount,
        'skipped' => $skippedCount,
        'results' => $results
    ]);
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'error' => true,
        'processed_up_to' => $last_proccessed_sid ?? null
    ]);
}
