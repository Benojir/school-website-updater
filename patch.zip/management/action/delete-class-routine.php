<?php
// Check if user is logged in
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/db.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_CLASS_ROUTINES)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['routine_id'])) {
    $routine_id = (int)$_POST['routine_id'];
    
    try {
        $stmt = $pdo->prepare("DELETE FROM class_routines WHERE id = ?");
        $stmt->execute([$routine_id]);
        
        if ($stmt->rowCount() > 0) {
            $response['success'] = true;
            $response['message'] = "Routine deleted successfully!";
        } else {
            $response['message'] = "Routine not found or already deleted";
        }
    } catch (PDOException $e) {
        $response['message'] = "Database error: " . $e->getMessage();
    }
} else {
    $response['message'] = "Invalid request";
}

echo json_encode($response);
?>