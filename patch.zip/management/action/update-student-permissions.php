<?php
// Check if user is logged in
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/db.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['user']['role'] !== 'superadmin') {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$student_ids = $_POST['student_ids'] ?? '';
$override_admit_check = isset($_POST['override_admit_check']) ? 1 : 0;
$allow_admit_card = isset($_POST['allow_admit_card']) ? 1 : 0;
$override_marksheet_check = isset($_POST['override_marksheet_check']) ? 1 : 0;
$allow_marksheet = isset($_POST['allow_marksheet']) ? 1 : 0;
$notes = $_POST['notes'] ?? '';

if (empty($student_ids)) {
    echo json_encode(['success' => false, 'message' => 'Student ID is required']);
    exit;
}

$student_ids = explode(",", $student_ids);

$results = [];
$processedCount = 0;
$skippedCount = 0;
$last_proccessed_sid;

foreach ($student_ids as $student_id) {
    try {
        // Check if permissions exist
        $stmt = $pdo->prepare("SELECT 1 FROM student_permissions WHERE student_id = ?");
        $stmt->execute([$student_id]);
        $exists = $stmt->fetch();

        if ($exists) {
            // Update existing permissions
            $stmt = $pdo->prepare("
                UPDATE student_permissions 
                SET 
                    override_admit_check = ?, 
                    allow_admit_card = ?,
                    override_marksheet_check = ?,
                    allow_marksheet = ?,
                    notes = ?, 
                    updated_at = NOW() 
                WHERE student_id = ?
            ");
            $stmt->execute([
                $override_admit_check,
                $allow_admit_card,
                $override_marksheet_check,
                $allow_marksheet,
                $notes,
                $student_id
            ]);
        } else {
            // Insert new permissions
            $stmt = $pdo->prepare("
                INSERT INTO student_permissions 
                (
                    student_id, 
                    override_admit_check, 
                    allow_admit_card,
                    override_marksheet_check,
                    allow_marksheet,
                    notes, 
                    created_at, 
                    updated_at
                ) 
                VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())
            ");
            $stmt->execute([
                $student_id,
                $override_admit_check,
                $allow_admit_card,
                $override_marksheet_check,
                $allow_marksheet,
                $notes
            ]);
        }

        $student_name = ($stmt = $pdo->prepare("SELECT name FROM students WHERE student_id = ?")) && $stmt->execute([$student_id]) ? $stmt->fetchColumn() : false;

        $results[] = [
            'student_id' => $student_id,
            'success' => true,
            'message' => ucwords($student_name) . "'s download permissions updated successfully.",
            'action' => 'updated'
        ];
        $processedCount++;
        $last_proccessed_sid = $student_id;
    } catch (PDOException $e) {
        $results[] = [
            'student_id' => $student_id,
            'success' => false,
            'message' => "Student not found or has left or alumni.",
            'action' => 'skipped'
        ];
        $skippedCount++;
    }
}

echo json_encode([
    'success' => true,
    'message' => "Processed {$processedCount} students, skipped {$skippedCount}",
    'total_students' => count($student_ids),
    'processed' => $processedCount,
    'skipped' => $skippedCount,
    'results' => $results
]);
