<?php
// Check if user is logged in
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/db.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['user']['role'] !== 'superadmin') {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        
        if ($id > 0) {
            // Check if class wise fee exists
            $stmt = $pdo->prepare("SELECT id FROM class_wise_fee WHERE id = ?");
            $stmt->execute([$id]);
            
            if ($stmt->rowCount() > 0) {
                // Delete class wise fee
                $delete_stmt = $pdo->prepare("DELETE FROM class_wise_fee WHERE id = ?");
                if ($delete_stmt->execute([$id])) {
                    $response['success'] = true;
                    $response['message'] = 'Class fee deleted successfully!';
                } else {
                    throw new Exception('Failed to delete subject');
                }
            } else {
                throw new Exception('Class fee not found');
            }
        } else {
            throw new Exception('Invalid amount ID');
        }
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);