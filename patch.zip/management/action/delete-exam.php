<?php
// Check if user is logged in
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/db.php");

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_EXAMS)) {
    die("You do not have permission to perform this action.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['exam_id'])) {
    $exam_id = $_POST['exam_id'];

    $stmt = $pdo->prepare("DELETE FROM exams WHERE id = :id AND status = 'archived'");
    
    if ($stmt->execute([':id' => $exam_id])) {
        header("Location: ../view/archived-exams.php?deleted=1");
    } else {
        header("Location: ../view/archived-exams.php?deleted=0");
    }
    exit;
}
?>