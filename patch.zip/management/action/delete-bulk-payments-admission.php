<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/db.php");

header('Content-Type: application/json');

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

if (!isset($_REQUEST['payment_ids']) || empty($_REQUEST['payment_ids'])) {
    echo json_encode(['success' => false, 'message' => 'No payments selected']);
    exit;
}

$payment_ids = $_REQUEST['payment_ids'];
if (!is_array($payment_ids)) {
    $payment_ids = [$payment_ids];
}

// Additional validation: ensure we have valid payment IDs
$payment_ids = array_filter($payment_ids, function ($id) {
    return !empty($id) && is_numeric($id);
});

if (empty($payment_ids)) {
    echo json_encode(['success' => false, 'message' => 'No valid payment IDs provided']);
    exit;
}

$pdo->beginTransaction();

try {
    // Get all payment details before deleting
    $placeholders = implode(',', array_fill(0, count($payment_ids), '?'));
    $stmt = $pdo->prepare("SELECT * FROM admission_fees_payment_history WHERE id IN ($placeholders) ORDER BY payment_date DESC");
    $stmt->execute($payment_ids);
    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$payments) {
        echo json_encode(['success' => false, 'message' => 'No payments found.']);
        exit;
    }

    foreach ($payments as $payment) {

        $student_id = $payment['student_id'];
        $stmt = $pdo->prepare("SELECT * FROM admission_fees_payment_history WHERE student_id = ? ORDER BY id DESC LIMIT 1");
        $stmt->execute([$student_id]);
        $student_last_payment = $stmt->fetch(PDO::FETCH_ASSOC);
        $student_last_payment_id = $student_last_payment ? $student_last_payment['id'] : null;

        if ($student_last_payment_id > $payment['id']) {
            echo json_encode([
                'success' => false,
                'message' => 'This payment cannot be deleted because there are newer payments recorded for this student. Please delete the most recent payments first, starting from the latest.'
            ]);
            exit;
        }

        // Restore unpaid fees if they exist
        if (!empty($payment['unpaid_admission_fees_rows_backup'])) {

            $unpaid_fees = json_decode($payment['unpaid_admission_fees_rows_backup'], true);

            foreach ($unpaid_fees as $fee) {

                // First delete old rows which updated
                $stmt = $pdo->prepare("DELETE FROM admission_unpaid_fees WHERE academic_year = ? AND student_id = ?");
                $stmt->execute([
                    $fee['academic_year'],
                    $fee['student_id']
                ]);

                // Re-insert the unpaid fee record
                $stmt = $pdo->prepare("
                    INSERT INTO admission_unpaid_fees 
                    (student_id, academic_year, class_id, actual_amount, unpaid_amount, discount_amount, remark, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
                ");

                $stmt->execute([
                    $fee['student_id'],
                    $fee['academic_year'],
                    $fee['class_id'],
                    $fee['actual_amount'],
                    $fee['unpaid_amount'],
                    $fee['discount_amount'],
                    $fee['remark']
                ]);

                // Update new unpaid fee id
                $new_unpaid_fee_id = $pdo->lastInsertId();

                $stmt = $pdo->prepare("UPDATE admission_partial_fees_payments SET unpaid_admission_fees_id = ? WHERE unpaid_admission_fees_id = ?");
                $stmt->execute([$new_unpaid_fee_id, $fee['id']]);
            }
        }

        // Delete partial payments
        if (!empty($payment['partial_payment_ids_backup'])) {
            foreach (json_decode($payment['partial_payment_ids_backup'], true) as $id) {
                $stmt = $pdo->prepare("DELETE FROM admission_partial_fees_payments WHERE id = ?");
                $stmt->execute([$id]);
            }
        }

        // Delete full paid fees
        if (!empty($payment['full_paid_admission_payment_ids'])) {
            $full_ids = json_decode($payment['full_paid_admission_payment_ids'], true);
            foreach ($full_ids as $id) {
                $stmt = $pdo->prepare("DELETE FROM admission_full_paid_fees WHERE id = ?");
                $stmt->execute([$id]);
            }
        }

        // Proccess the wallet
        $stmt = $pdo->prepare("SELECT * FROM student_wallet WHERE student_id = ? LIMIT 1");
        $stmt->execute([$payment['student_id']]);
        $wallet = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!empty($wallet)) {

            $updated_balance = $wallet['balance'];

            if ($payment['method'] == 'wallet') {
                $updated_balance = $wallet['balance'] + $payment['wallet_affected_balance']; // Refund wallet balance if payment method was wallet
            } else {
                $updated_balance = $wallet['balance'] - $payment['wallet_affected_balance']; // Deduct from wallet balance
            }

            $stmt = $pdo->prepare("UPDATE student_wallet SET balance = ? WHERE id = ?");
            $stmt->execute([$updated_balance, $wallet['id']]);
        }

        // Delete wallet transaction history
        if (!empty($payment['wallet_transaction_id'])) {
            $stmt = $pdo->prepare("DELETE FROM wallet_transactions WHERE transaction_id = ?");
            $stmt->execute([$payment['wallet_transaction_id']]);
        }
    }

    // Finally delete the payment history records
    $placeholders = implode(',', array_fill(0, count($payment_ids), '?'));
    $stmt = $pdo->prepare("DELETE FROM admission_fees_payment_history WHERE id IN ($placeholders)");
    $stmt->execute($payment_ids);

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => count($payment_ids) . ' payment records deleted successfully and related records restored.'
    ]);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode([
        'success' => false,
        'message' => 'Error deleting payments: ' . $e->getMessage()
    ]);
}
