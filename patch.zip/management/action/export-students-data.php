<?php
// export-students-data.php
require_once("../../includes/db.php");
require_once '../../vendor/autoload.php'; // Make sure to include PHPSpreadsheet autoload

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Check if user is logged in
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");

// Check if sub admin has permission to export students data
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to export students data.'
    ]);
    die();
}

// Check if student IDs are provided
if (!isset($_GET['student_ids']) || empty($_GET['student_ids'])) {
    die("Student IDs are required (comma-separated)");
}

$student_ids = explode(',', $_GET['student_ids']);
$placeholders = rtrim(str_repeat('?,', count($student_ids)), ',');
$student_ids = array_map('trim', $student_ids);

try {
    // Prepare the query to fetch student data with class and section names
    $query = "
        SELECT 
            s.student_id,
            s.name,
            c.class_name,
            sec.section_name,
            CONCAT(c.class_name, ' - ', sec.section_name) AS class_section,
            s.roll_no,
            s.father_name,
            s.mother_name,
            s.phone_number,
            s.alternate_phone_number,
            s.gender,
            s.address,
            s.date_of_birth,
            s.blood_group
        FROM 
            students s
        LEFT JOIN 
            classes c ON s.class_id = c.id
        LEFT JOIN 
            sections sec ON s.section_id = sec.id
        WHERE 
            s.student_id IN ($placeholders)
        ORDER BY 
            c.id, sec.id, s.roll_no
    ";

    $stmt = $pdo->prepare($query);
    $stmt->execute($student_ids);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($students)) {
        die("No students found with the provided IDs");
    }

    // Create new Spreadsheet object
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Set document properties
    $spreadsheet->getProperties()
        ->setCreator("School Management System")
        ->setTitle("Students Data Export")
        ->setSubject("Students Information");

    // Set headers
    $headers = [
        'Name',
        'Class & Section',
        'Roll No',
        'Father Name',
        'Mother Name',
        'Phone Number',
        'Alternate Phone',
        'Gender',
        'Address',
        'Date of Birth',
        'Blood Group'
    ];

    $sheet->fromArray($headers, NULL, 'A1');

    // Add data
    $row = 2;
    foreach ($students as $student) {
        // Format date of birth if not null
        $dob = !empty($student['date_of_birth']) ? date('d-m-Y', strtotime($student['date_of_birth'])) : '';
        $class_section = $student['class_name'] . ' - ' . $student['section_name'];

        $sheet->fromArray([
            $student['name'],
            $class_section,
            $student['roll_no'],
            $student['father_name'] ?? '',
            $student['mother_name'] ?? '',
            $student['phone_number'] ?? '',
            $student['alternate_phone_number'] ?? '',
            $student['gender'] ?? '',
            $student['address'] ?? '',
            $dob,
            $student['blood_group'] ?? ''
        ], NULL, 'A' . $row);
        
        $row++;
    }

    // Auto-size columns
    foreach (range('A', 'K') as $column) {
        $sheet->getColumnDimension($column)->setAutoSize(true);
    }

    // Set header style
    $headerStyle = [
        'font' => [
            'bold' => true,
            'color' => ['rgb' => 'FFFFFF'],
        ],
        'fill' => [
            'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
            'startColor' => ['rgb' => '4472C4']
        ]
    ];
    $sheet->getStyle('A1:K1')->applyFromArray($headerStyle);

    // Set filename
    $filename = 'students_export_' . date('Y-m-d') . '.xlsx';

    // Redirect output to a client's web browser (Xlsx)
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="' . $filename . '"');
    header('Cache-Control: max-age=0');

    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;

} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}