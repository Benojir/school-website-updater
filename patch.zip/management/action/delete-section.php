<?php
// Check if user is logged in
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/db.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['user']['role'] !== 'superadmin') {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['section_id'])) {
    $section_id = $_POST['section_id'];
    
    try {
        $stmt = $pdo->prepare("DELETE FROM sections WHERE id = :id");
        if ($stmt->execute([':id' => $section_id])) {
            $response['success'] = true;
            $response['message'] = "Section deleted successfully!";
        }
    } catch (PDOException $e) {
        $response['message'] = "Error: " . $e->getMessage();
    }
} else {
    $response['message'] = "Invalid request";
}

echo json_encode($response);
?>