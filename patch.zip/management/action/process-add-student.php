<?php
ob_start();
// Check if user is logged in
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/functions.php");
require_once("../../includes/financial/fun-admission-fees-entry.php");

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'errors' => ['You do not have permission to perform this action.']
    ]);
    die();
}

// Sanitize function
function clean($data)
{
    if ($data === NULL || $data === '') {
        return NULL;
    }
    return ucwords(safe_htmlspecialchars(trim($data)));
}

// Add this function for handling base64 images
function saveBase64Image($base64_string, $upload_dir, $prefix = 'stu_')
{
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    // Check if the base64 string is valid
    if (preg_match('/^data:image\/(\w+);base64,/', $base64_string, $type)) {
        $data = substr($base64_string, strpos($base64_string, ',') + 1);
        $type = strtolower($type[1]); // jpg, png, gif

        if (!in_array($type, ['jpg', 'jpeg', 'png', 'gif'])) {
            return false;
        }

        $data = base64_decode($data);
        if ($data === false) {
            return false;
        }
    } else {
        return false;
    }

    $file_name = uniqid($prefix) . '.' . $type;
    $file_path = $upload_dir . $file_name;

    if (file_put_contents($file_path, $data)) {
        // Verify the saved file is a valid image
        if (!getimagesize($file_path)) {
            unlink($file_path);
            return false;
        }
        return $file_name;
    }

    return false;
}

// Function to save base64 image
// Enhanced function to validate and save images
function saveUploadedImage($file, $upload_dir, $prefix = 'stu_')
{
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    // Get file info
    $file_name = basename($file['name']);
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];

    // Check for upload errors
    if ($file_error !== UPLOAD_ERR_OK) {
        throw new Exception("File upload error: " . $file_error);
    }

    // Get real file extension and MIME type
    $file_info = new finfo(FILEINFO_MIME_TYPE);
    $mime_type = $file_info->file($file_tmp);

    // Allowed MIME types and corresponding extensions
    $allowed_mimes = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png'
    ];

    // Verify MIME type is allowed
    if (!array_key_exists($mime_type, $allowed_mimes)) {
        throw new Exception("Invalid file type. Only JPG and PNG images are allowed.");
    }

    // Get correct extension based on MIME type
    $file_ext = $allowed_mimes[$mime_type];

    // Check for double extensions (e.g., malicious.php.jpg)
    $path_info = pathinfo($file_name);
    if (preg_match('/\.(php|phtml|html|htm|js|exe|dll|bat|sh)$/i', $path_info['filename'])) {
        throw new Exception("Invalid filename. Potentially dangerous file extension detected.");
    }

    // Verify image content
    if (!getimagesize($file_tmp)) {
        throw new Exception("Uploaded file is not a valid image.");
    }

    // Check file size (2MB max)
    $max_size = 2 * 1024 * 1024;
    if ($file_size > $max_size) {
        throw new Exception("Image size must be less than 2MB.");
    }

    // Generate unique filename with correct extension
    $new_file_name = uniqid($prefix) . '.' . $file_ext;
    $destination = $upload_dir . $new_file_name;

    // Sanitize destination path to prevent directory traversal
    // $destination = str_replace(['../', '..\\'], '', $destination);

    // Move the file using streams for additional security
    $src = fopen($file_tmp, 'rb');
    $dst = fopen($destination, 'wb');

    if (!$src || !$dst) {
        throw new Exception("Failed to process uploaded file.");
    }

    while (!feof($src)) {
        fwrite($dst, fread($src, 8192));
    }

    fclose($src);
    fclose($dst);

    // Verify the moved file is still a valid image
    if (!getimagesize($destination)) {
        unlink($destination);
        throw new Exception("Uploaded file became invalid after moving.");
    }

    return $new_file_name;
}

$response = [
    'success' => false,
    'message' => '',
    'errors' => []
];

try {
    // Sanitize POST input
    $student_id                  = generateUniqueStudentId($pdo); // Generate unique student ID
    $admission_type              = clean($_POST['admission_type'] ?? '');
    $name                        = clean($_POST['name'] ?? '');
    $father_name                 = clean($_POST['father_name'] ?? '');
    $mother_name                 = clean($_POST['mother_name'] ?? '');
    $father_occupation           = clean($_POST['father_occupation'] ?? '');
    $mother_occupation           = clean($_POST['mother_occupation'] ?? '');
    $address                     = clean($_POST['address'] ?? '');
    $email                       = sanitize_input($_POST['email'] ?? '');
    $religion                    = sanitize_input($_POST['religion'] ?? '');
    $registration_no             = sanitize_input($_POST['registration_no'] ?? '');
    $class                       = clean($_POST['class_id'] ?? '');
    $section                     = clean($_POST['section_id'] ?? ''); // Don't clean NULL values
    $roll_no                     = clean($_POST['roll_no'] ?? '');
    $phone_number                = clean($_POST['phone_number'] ?? '');
    $alternate_phone_number      = clean($_POST['alternate_phone_number'] ?? '');
    $admission_date              = clean($_POST['admission_date'] ?? '');
    $academic_year               = clean($_POST['academic_year'] ?? '');
    $gender                      = clean($_POST['gender'] ?? '');
    $date_of_birth               = clean($_POST['date_of_birth'] ?? '');
    $status                      = 'Active'; // Default status for new students
    $blood_group                 = clean($_POST['blood_group'] ?? '');
    $is_hosteler                 = isset($_POST['is_hosteler']) ? (int)$_POST['is_hosteler'] : 0;
    $hostel_fee                  = sanitize_input($_POST['hostel_fee'] ?? 0);
    $driving_route_id            = clean($_POST['driving_route'] ?? '');
    $car_fee                     = sanitize_input($_POST['car_fee'] ?? 0);
    $driver_id                   = clean($_POST['driver_id'] ?? '');
    $custom_class_fee            = sanitize_input($_POST['custom_class_fee'] ?? 0);
    $admission_fee_discount      = sanitize_input($_POST['admission_fee_discount'] ?? 0);

    // Validate required fields
    $required_fields = [
        'admission_type',
        'name',
        'father_name',
        'class_id',
        'phone_number',
        'admission_date',
        'academic_year',
        'gender',
        'date_of_birth',
    ];

    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            throw new Exception("All required fields must be filled.");
        }
    }

    // Declaring default $is_re_admission
    $is_re_admission = false;

    // Validate admission type
    if ($admission_type === "re-admission") {
        $is_re_admission = true;
    }

    // Validate driving route and driver id
    if (!empty($driving_route_id)) {
        if (is_numeric($driving_route_id)) {
            // Check if driving route exists
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM driving_routes WHERE id = ?");
            $stmt->execute([$driving_route_id]);
            if ($stmt->fetchColumn() == 0) {
                throw new Exception("Selected driving route does not exist.");
            }
        } else {
            throw new Exception("Invalid driving route selected.");
        }
    }

    if (!empty($driver_id)) {
        if (is_numeric($driver_id)) {
            // Check if driver exists and is associated with the selected route
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM drivers WHERE id = ? AND route_id = ?");
            $stmt->execute([$driver_id, $driving_route_id]);
            if ($stmt->fetchColumn() == 0) {
                throw new Exception("Selected driver does not exist or is not associated with the selected route.");
            }
        } else {
            throw new Exception("Invalid driver selected.");
        }
    }

    // Validate phone number
    if (!isValidPhoneNumber($phone_number)) {
        throw new Exception("Invalid phone number format. It should be 10 digits.");
    }

    // Validate alternate phone number
    if (!empty($alternate_phone_number)) {
        if (!isValidPhoneNumber($alternate_phone_number)) {
            throw new Exception("Invalid alternate phone number format. It should be 10 digits.");
        }
    }

    // Then modify the image handling section like this:
    $image_path = "default_student_dp.jpg"; // Default image

    // Handle image upload - prioritize cropped image if available
    if (!empty($_POST['cropped_image_data'])) {
        // Use the new base64 function for cropped images
        $upload_dir = '../../uploads/students/';
        $cropped_image = saveBase64Image($_POST['cropped_image_data'], $upload_dir);

        if ($cropped_image) {
            $image_path = $cropped_image;
        } else {
            throw new Exception("Failed to save cropped image.");
        }
    }
    // Fall back to regular file upload if no cropped image available
    elseif (isset($_FILES['student_image']) && $_FILES['student_image']['size'] > 0) {
        try {
            $upload_dir = '../../uploads/students/';
            $image_path = saveUploadedImage($_FILES['student_image'], $upload_dir);

            // Additional ratio check for non-cropped images
            $image_full_path = $upload_dir . $image_path;
            list($width, $height) = getimagesize($image_full_path);

            $ratio = getRatioArray($width, $height);
            if ($ratio === null) {
                unlink($image_full_path);
                throw new Exception("Invalid image dimensions.");
            }

            $width_ratio = $ratio[0];
            $height_ratio = $ratio[1];

            if ($width_ratio !== 5 || $height_ratio !== 6) {
                unlink($image_full_path);
                throw new Exception("Image must be in a 5:6 ratio. Current ratio: {$width_ratio}:{$height_ratio}");
            }
        } catch (Exception $e) {
            throw new Exception("Image upload failed: " . $e->getMessage());
        }
    }

    // Check for duplicate student entry
    $checkID = $pdo->prepare("SELECT COUNT(*) FROM students WHERE name = :name AND class_id = :class AND father_name = :father_name");
    $checkID->execute([':name' => $name, ':class' => $class, ':father_name' => $father_name]);
    if ($checkID->fetchColumn() > 0) {
        throw new Exception("Student already exists.");
    }

    // Check for duplicate roll number in same class/section
    $checkRoll = $pdo->prepare("SELECT COUNT(*) FROM students WHERE class_id = :class AND roll_no = :roll_no");
    $checkRoll->execute([
        ':class'   => $class,
        ':roll_no' => $roll_no
    ]);
    if ($checkRoll->fetchColumn() > 0) {
        throw new Exception("Roll number already assigned in this class and section.");
    }

    // Check primary number and alternate number if same
    if ($phone_number == $alternate_phone_number) {
        throw new Exception("Primary phone number and alternate phone number must be different. You can leave blank the alternate phone number field.");
    }

    // Insert new student with additional fields
    $stmt = $pdo->prepare("
        INSERT INTO students (
            student_id, name, father_name, mother_name, father_occupation, mother_occupation,
            address, student_image, class_id, section_id, roll_no, phone_number, alternate_phone_number, email, religion, registration_no,
            admission_date, academic_year, gender, date_of_birth, status, blood_group, is_hosteler, driving_route_id, driver_id, car_fee, hostel_fee, custom_class_fee
        ) VALUES (
            :student_id, :name, :father_name, :mother_name, :father_occupation, :mother_occupation,
            :address, :student_image, :class, :section, :roll_no, :phone_number, :alternate_phone_number, :email, :religion, :registration_no,
            :admission_date, :academic_year, :gender, :date_of_birth, :status, :blood_group, :is_hosteler, :driving_route_id, :driver_id, :car_fee, :hostel_fee, :custom_class_fee
        )
    ");

    $stmt->execute([
        ':student_id'                  => $student_id,
        ':name'                        => $name,
        ':father_name'                 => $father_name,
        ':mother_name'                 => $mother_name,
        ':father_occupation'           => $father_occupation,
        ':mother_occupation'           => $mother_occupation,
        ':address'                     => $address,
        ':student_image'               => $image_path,
        ':class'                       => $class,
        ':section'                     => $section,
        ':roll_no'                     => $roll_no,
        ':phone_number'                => $phone_number,
        ':alternate_phone_number'      => $alternate_phone_number,
        ':email'                       => $email,
        ':religion'                    => $religion,
        ':registration_no'             => $registration_no,
        ':admission_date'              => $admission_date,
        ':academic_year'               => $academic_year,
        ':gender'                      => $gender,
        ':date_of_birth'               => $date_of_birth,
        ':status'                      => $status,
        ':blood_group'                 => $blood_group,
        ':is_hosteler'                 => $is_hosteler,
        ':driving_route_id'            => $driving_route_id,
        ':driver_id'                   => $driver_id,
        ':car_fee'                     => $car_fee,
        ':hostel_fee'                  => $hostel_fee,
        ':custom_class_fee'            => $custom_class_fee
    ]);

    $response['success'] = true;
    $response['message'] = "Student added successfully!";

    // Insert admission fee record if applicable
    $admission_fee_entry = fun_admission_fees_entry(
        $pdo, 
        $student_id, 
        $academic_year, 
        $class, 
        $admission_fee_discount,
        $is_re_admission
    );

    if ($admission_fee_entry['success']) {
        $response['message'] .= " Also Admission fee entry created.";
    } else {
        $response['message'] .= " However, Admission fee entry failed: " . $admission_fee_entry['message'];
    }

} catch (PDOException $e) {
    http_response_code(500);
    $response['message'] = "Database error: " . $e->getMessage();
    // error_log("PDOException: " . $e->getMessage());
} catch (Exception $e) {
    http_response_code(400);
    $response['message'] = $e->getMessage();
}



// Clean any output buffers
while (ob_get_level()) {
    ob_end_clean();
}

// Ensure only JSON is output
header('Content-Type: application/json');
echo json_encode($response);
exit();
