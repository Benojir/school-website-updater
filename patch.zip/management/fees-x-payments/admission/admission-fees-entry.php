<?php
include_once("../../../includes/auth-check.php");
require_once("../../../includes/header-open.php");
/** @var string $school_name */
echo "<title>Admission Fees Entry - " . $school_name . "</title>";
require_once("../../../includes/header-close.php");
require_once("../../../includes/dashboard-navbar.php");

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    include_once("../../../includes/permission-denied.php");
}

$student_ids_string = $_REQUEST['student_ids'] ?? '';
$student_ids = array_values(array_unique(array_filter(array_map('trim', explode(',', $student_ids_string)))));

if (empty($student_ids_string) || count($student_ids) == 0) {
    echo "<div class='container mt-4'><div class='alert alert-danger'>No student IDs provided.</div></div>";
    include_once("../../../includes/body-close.php");
    exit();
}

try {
    $currentAcademicYear = academicRequireCurrentYear($pdo);
    $selectedAcademicYear = academicRequestedYear($_REQUEST) ?? $currentAcademicYear;

    // Offer only years recorded by this school, including its configured current year.
    $availableAcademicYears = [$currentAcademicYear => $currentAcademicYear];
    $yearStmt = $pdo->query('SELECT DISTINCT academic_year FROM student_academic_records WHERE academic_year IS NOT NULL ORDER BY academic_year');
    foreach ($yearStmt->fetchAll(PDO::FETCH_COLUMN) as $year) {
        $year = academicNormalizeYear($year);
        $availableAcademicYears[$year] = $year;
    }
    ksort($availableAcademicYears, SORT_NUMERIC);
    if (!isset($availableAcademicYears[$selectedAcademicYear])) {
        throw new InvalidArgumentException('No academic records exist for the selected year. Choose a year recorded by the school.');
    }

    // Eligibility comes from each student's own enrollment, not their cached current class.
    $placeholders = implode(',', array_fill(0, count($student_ids), '?'));
    $yearStmt = $pdo->prepare("SELECT s.student_id, ar.academic_year
        FROM students s JOIN student_academic_records ar ON ar.student_row_id = s.id
        WHERE s.student_id IN ($placeholders) AND ar.academic_year IS NOT NULL
          AND ar.status = 'Active' AND ar.class_id IS NOT NULL");
    $yearStmt->execute($student_ids);
    $eligibleStudentYears = [];
    foreach ($yearStmt->fetchAll(PDO::FETCH_ASSOC) as $record) {
        $eligibleStudentYears[$record['student_id']][(string)$record['academic_year']] = true;
    }

    $selectedYearStudents = [];
    $unavailableStudentIds = [];
    foreach ($student_ids as $student_id) {
        $student_info = getStudentInfo($pdo, $student_id, $selectedAcademicYear);
        if (!$student_info || !isset($eligibleStudentYears[$student_id][$selectedAcademicYear])) {
            $unavailableStudentIds[] = $student_id;
            continue;
        }
        $selectedYearStudents[$student_id] = $student_info;
    }
} catch (Exception $e) {
    echo "<div class='container mt-4'><div class='alert alert-danger'>" . safe_htmlspecialchars($e->getMessage()) . '</div></div>';
    include_once("../../../includes/body-close.php");
    exit();
}

// Fetch class-wise new admission fees
$stmt = $pdo->prepare("SELECT class_id, amount FROM class_wise_new_admission_fees");
$stmt->execute();
$new_admission_fees = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// Fetch class-wise re-admission fees
$stmt = $pdo->prepare("SELECT class_id, amount FROM class_wise_re_admission_fees");
$stmt->execute();
$re_admission_fees = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

$filtered_student_ids = [];

?>
<style>
    .table-responsive {
        max-height: 500px;
        overflow-y: auto;
        scrollbar-width: thin;
        scrollbar-color: #888 #e0e0e0;
    }

    .table>thead {
        position: sticky;
    }

    .table>thead>tr>th {
        vertical-align: middle !important;
        text-align: center;
    }

    .table thead th {
        position: relative;
    }

    .table tbody td {
        vertical-align: middle !important;
        text-align: center;
    }

    .table tbody td img {
        border-radius: 5px;
        width: 60px;
        object-fit: cover;
        cursor: pointer;
        border: 1px solid #ddd;
    }
</style>

<div class="container-fluid mt-4">
    <div class="card shadow-sm mb-4">
        <div class="card-header d-flex justify-content-between align-items-center bg-primary text-white">
            <div>
                <h4 class="mb-0"><i class="fas fa-money-bill me-2"></i>Request Admission Fees</h4>
            </div>
            <div>
                <button type="button" class="btn btn-sm btn-danger" onclick="window.close()">
                    <i class="fas fa-window-close me-2"></i>Close Tab
                </button>
            </div>
        </div>
        <div class="card-body" id="admissionFeesForm">
            <div class="mb-3">
                <label for="admissionFeesAcademicYear" class="form-label">Academic year</label>
                <select id="admissionFeesAcademicYear" class="form-select">
                    <?php foreach ($availableAcademicYears as $year): ?>
                        <option value="<?= safe_htmlspecialchars($year) ?>" <?= $year === $selectedAcademicYear ? 'selected' : '' ?>><?= safe_htmlspecialchars($year) ?></option>
                    <?php endforeach; ?>
                </select>
                <div class="form-text">Choose one year for this request. Each student's class comes from their enrollment in that year. Unsaved fee choices and discounts are kept separately for each year while this page stays open.</div>
            </div>
            <div class="alert alert-light border small">
                Amounts use the currently configured New Admission / Re-Admission rates for the displayed class.
                Historical fee rates are not stored separately by year. Check the amounts before submitting.
            </div>
            <div id="admissionFeesYearStatus" class="alert alert-info d-none" role="status" aria-live="polite"></div>
            <?php if ($unavailableStudentIds): ?>
                <div class="alert alert-info">
                    No eligible enrollment for <?= safe_htmlspecialchars($selectedAcademicYear) ?>:
                    <?= safe_htmlspecialchars(implode(', ', $unavailableStudentIds)) ?>.
                    Select another academic year or complete the enrollment first.
                </div>
            <?php endif; ?>
            <div class="mb-3">
                <h5 class="m-0 p-0">Total Students: <span id="total_students_fee_entry"></span></h5>
            </div>
            <div class="row mb-3">
                <div class="row col-md-6">
                    <div class="col-md-12 mb-2">
                        <input type="text" id="admissionFeesSearchBox" class="form-control" placeholder="Search students..." />
                    </div>
                    <div class="col-md-12 mb-2">
                        <select id="admissionFeesStudentListSort" class="form-select">
                            <option value="default" selected>Default Order</option>
                            <option value="name-asc">Sort by Name (A-Z)</option>
                            <option value="name-desc">Sort by Name (Z-A)</option>
                            <option value="roll-asc">Sort by Roll No (Low to High)</option>
                            <option value="roll-desc">Sort by Roll No (High to Low)</option>
                        </select>
                    </div>
                </div>
                <div class="row col-md-6">
                    <div class="col-md-12 mb-2 d-flex align-items-center">
                        <input type="checkbox" id="changeFeesTypeToReAdmission" class="form-check-input me-2" />
                        <label for="changeFeesTypeToReAdmission" class="form-check-label">Change fees type to re-admission</label>
                    </div>
                </div>
            </div>

            <div class="table-responsive rounded-2">
                <table class="table table-bordered table-striped" id="admissionFeesTable">
                    <thead class="table-dark">
                        <tr>
                            <th><i class="fas fa-user"></i></th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Class in <?= safe_htmlspecialchars($selectedAcademicYear) ?></th>
                            <th>Fees Type</th>
                            <th>Actual Amount</th>
                            <th>Offer Amount</th>
                            <th>Discount</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($student_ids as $index => $student_id):
                            $student_info = $selectedYearStudents[$student_id] ?? null;
                            if (!$student_info) {
                                continue;
                            }

                            if (in_array($student_id, $filtered_student_ids)) {
                                continue;
                            }

                            $filtered_student_ids[] = $student_id;

                            $class_id = $student_info['class_id'];
                            $actual_amount = $new_admission_fees[$class_id] ?? 0;

                            // PREPARE DATA FOR SORTING
                            $sort_name = strtolower($student_info['name']);
                        ?>
                            <tr id="trow-<?= $student_id ?>"
                                class="student-row"
                                data-student-id="<?= $student_id ?>"
                                data-academic-year="<?= safe_htmlspecialchars($selectedAcademicYear) ?>"
                                data-admission-class-id="<?= (int)$class_id ?>"
                                data-name="<?= safe_htmlspecialchars($sort_name) ?>"
                                data-roll-no="<?= $student_info['roll_no'] ?? 0 ?>"
                                data-actual-amount="<?= $actual_amount ?>"
                                data-original-index="<?= $index ?>">

                                <td>
                                    <button tabindex="-1" class="btn btn-sm btn-outline-primary more-details-btn" title="More Details" data-student-id="<?= $student_id ?>">
                                        <i class="fas fa-plus-circle"></i>
                                    </button>
                                </td>

                                <td
                                    title="View Image"
                                    data-fancybox="student-images"
                                    data-caption="<?= $student_info['name'] ?>"
                                    data-src="<?= BASE_URL . "/uploads/students/" . $student_info['student_image']; ?>">
                                    <img
                                        src="<?= BASE_URL . "/uploads/students/" . $student_info['student_image']; ?>"
                                        alt="Img"
                                        loading="lazy" />
                                </td>
                                <td>
                                    <a tabindex="-1"
                                        class="text-decoration-none"
                                        href="<?= BASE_URL ?>/parent/dashboard/student-details.php?student_id=<?= urlencode($student_info['student_id']) ?>&amp;selected_year=<?= urlencode($selectedAcademicYear) ?>"
                                        target="_blank">
                                        <?php echo safe_htmlspecialchars($student_info['name']); ?>
                                    </a>
                                    <br>
                                    <small class="text-muted" style="font-size: 0.8rem;"><?= $student_info['student_id'] ?></small>
                                    <br>
                                    <small class="text-muted" style="font-size: 0.8rem;"><?= $student_info['registration_no'] ?></small>
                                </td>
                                <td>
                                    <?= $student_info['class_name'] . ' (' . $student_info['section_name'] . ')' ?>
                                    <br>
                                    <small class="text-muted" style="font-size: 0.8rem;">Roll: <?= $student_info['roll_no']; ?></small>
                                </td>
                                <td>
                                    <select id="admission-type-select-<?= $student_id ?>"
                                        class="form-control form-control-sm admission-type-select"
                                        tabindex="-1">
                                        <option value="new-admission-fees" selected>New Admission Fees</option>
                                        <option value="re-admission-fees">Re-Admission Fees</option>
                                    </select>
                                </td>
                                <td>
                                    <span id="actual-amount-<?= $student_id ?>" class="text-success fw-bold">
                                        <?php echo $currency_symbol . $actual_amount; ?>
                                    </span>
                                    <div class="fee-validation-message text-danger small d-none" role="status"></div>
                                </td>
                                <td>
                                    <input
                                        id="offer-amount-input-<?= $student_id ?>"
                                        type="text"
                                        class="form-control form-control-sm offer-amount-input text-center"
                                        min="0"
                                        max="<?php echo $actual_amount; ?>"
                                        value="<?= $actual_amount ?>" />
                                </td>
                                <td>
                                    <input
                                        id="discount-amount-input-<?= $student_id ?>"
                                        type="text"
                                        class="form-control form-control-sm discount-amount-input text-center"
                                        min="0"
                                        max="<?php echo $actual_amount; ?>"
                                        value="0" />
                                </td>
                                <td>
                                    <button
                                        data-student-id="<?php echo $student_info['student_id']; ?>"
                                        tabindex="-1"
                                        title="Remove student from list"
                                        class="btn btn-sm btn-danger remove-student-btn">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="text-end mt-3">
                <button id="submitAdmissionFeesEntryBtn" class="btn btn-primary" tabindex="-1">
                    <i class="fas fa-check-circle me-2"></i>Submit Admission Fees Request
                </button>
            </div>
            <script type="application/json" id="admissionFeesPageData"><?= json_encode([
                'studentIds' => $student_ids,
                'filteredStudentIds' => $filtered_student_ids,
                'academicYear' => $selectedAcademicYear,
                'newAdmissionFees' => $new_admission_fees,
                'reAdmissionFees' => $re_admission_fees,
            ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>
        </div>
    </div>
</div>

<?php include_once('../../../includes/modals/fees-x-payments/financial-details-modal.php'); ?>

<script>
    const initialAdmissionFeesData = JSON.parse(document.getElementById('admissionFeesPageData').textContent);
    let filteredStudentIDs = initialAdmissionFeesData.filteredStudentIds;
    let requestedStudentIDs = initialAdmissionFeesData.studentIds;
    let selectedAcademicYear = initialAdmissionFeesData.academicYear;
    let changingAcademicYear = false;
    let submittingAdmissionFees = false;
    let newAdmissionFees = initialAdmissionFeesData.newAdmissionFees;
    let reAdmissionFees = initialAdmissionFeesData.reAdmissionFees;
    const admissionFeesDrafts = new Map();
    let financialDataLoaded = [];

    function bindAdmissionFeesForm() {
        $('#total_students_fee_entry').text(filteredStudentIDs.length);
        restoreAdmissionFeesDraft();
        refreshAdmissionFeesValidation();

        $('#admissionFeesAcademicYear').on('change', function() {
            changeAdmissionFeesYear(String($(this).val() || ''));
        });

        $('.admission-type-select').on('change', function() {
            const row = $(this).closest('tr');
            updateAmount(row.attr('data-student-id'), row.find('.discount-amount-input').val());
            refreshAdmissionFeesValidation();
        });

        // Change admission fees type
        $('#changeFeesTypeToReAdmission').change(function() {
            const isChecked = $(this).is(':checked');
            if (isChecked) {
                $('.admission-type-select').val('re-admission-fees').trigger('change');
            } else {
                $('.admission-type-select').val('new-admission-fees').trigger('change');
            }
        });

        $('.offer-amount-input, .discount-amount-input').on('focus', function() {
            $(this).select();
        });

        // Max input validation for offer and discount amounts
        $('.offer-amount-input, .discount-amount-input').on('input', function() {
            const studentRow = $(this).closest('tr');
            
            // Changed: Getting the actual amount from the data attribute instead of parsing text
            const actualAmount = parseFloat(studentRow.attr('data-actual-amount')) || 0;

            let inputValue = parseFloat($(this).val()) || 0;
            if (inputValue > actualAmount) {
                $(this).val(actualAmount);
            } else if (inputValue < 0) {
                $(this).val(0);
            }

            // Auto calculate the other field and discount field
            let offerAmount = parseFloat(studentRow.find('.offer-amount-input').val()) || 0;
            let discountAmount = parseFloat(studentRow.find('.discount-amount-input').val()) || 0;

            let offerAmountCalc = actualAmount - discountAmount;
            let discountAmountCalc = actualAmount - offerAmount;

            if ($(this).hasClass('offer-amount-input')) {
                // If offer amount is changed, update discount
                studentRow.find('.discount-amount-input').val(discountAmountCalc >= 0 ? discountAmountCalc : 0);
            } else if ($(this).hasClass('discount-amount-input')) {
                // If discount amount is changed, update offer
                studentRow.find('.offer-amount-input').val(offerAmountCalc >= 0 ? offerAmountCalc : 0);
            }
            refreshAdmissionFeesValidation();
        });

        // Remove student from the list
        $('.remove-student-btn').click(function() {
            const studentID = $(this).attr('data-student-id');
            $(this).closest('tr').remove();
            filteredStudentIDs = filteredStudentIDs.filter(id => id !== studentID);
            requestedStudentIDs = requestedStudentIDs.filter(id => id !== studentID);
            $('#total_students_fee_entry').text(filteredStudentIDs.length);
            for (const draft of admissionFeesDrafts.values()) draft.delete(studentID);
            refreshAdmissionFeesValidation();
        });

        // Search functionality
        $('#admissionFeesSearchBox').on('keyup', function() {
            var value = $(this).val().toLowerCase();
            $("#admissionFeesTable tbody tr").filter(function() {
                // Toggle visibility based on whether the row text contains the search term
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });

        // Sorting functionality
        sortStudentRows(); // Initial sort
        $('#admissionFeesStudentListSort').change(function() {
            sortStudentRows();
        });

        // Submit admission fees entry
        $('#submitAdmissionFeesEntryBtn').click(function() {
            if (changingAcademicYear || submittingAdmissionFees) return;
            if (filteredStudentIDs.length === 0) {
                showWarningAlert('No students to process.');
                return;
            }

            if (!refreshAdmissionFeesValidation()) return;
            let data;
            try {
                data = collectAdmissionFeesData();
            } catch (error) {
                showWarningAlert(error.message);
                return;
            }

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/put/fees-x-payments/admission/process-fees-entry-admission.php',
                type: 'PUT',
                data: {
                    students_data: JSON.stringify(data)
                },
                dataType: 'json',
                beforeSend: function() {
                    submittingAdmissionFees = true;
                    $('#admissionFeesForm :input').prop('disabled', true);
                    showLoadingAlert('Processing admission fees entry. Please wait...');
                },
                success: function(response) {
                    if (response.success) {
                        admissionFeesDrafts.delete(selectedAcademicYear);
                        let errorMessages = response.errors || [];
                        let proccessedStudents = response.successes || [];
                        let skippedStudents = response.skips || [];
                        let message = response.message || 'Admission fees entry processed successfully.';
                        let html = "";

                        if (errorMessages.length > 0) {
                            html += `<div class="alert alert-danger mb-3">
                            <strong>Errors: (${errorMessages.length})</strong>
                            <ul>`;
                            errorMessages.forEach(function(error) {
                                html += `<li>${error}</li>`;
                            });
                            html += `</ul></div>`;
                        }

                        if (skippedStudents.length > 0) {
                            html += `<div class="text-danger">
                            <strong>Skipped students: (${skippedStudents.length})</strong>
                            <table class="table table-sm table-bordered mt-2">
                                <thead class="table-danger">
                                    <tr>
                                        <th>Student Name</th>
                                        <th>Reason</th>
                                    </tr>
                                </thead>
                                <tbody>`;
                            skippedStudents.forEach(function(student) {
                                html += `<tr>
                                    <td>${student.student_name}</td>
                                    <td>${student.reason}</td>
                                </tr>`;
                            });
                            html += `</tbody></table></div>`;
                        }

                        if (proccessedStudents.length > 0) {
                            html += `<div class="text-success">
                            <strong>Processed students: (${proccessedStudents.length})</strong>
                            <table class="table table-sm table-bordered mt-2">
                                <thead class="table-success">
                                    <tr>
                                        <th>Student Name</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>`;
                            proccessedStudents.forEach(function(student) {
                                html += `<tr>
                                    <td>${student.student_name}</td>
                                    <td>${student.message}</td>
                                </tr>`;
                            });
                            html += `</tbody></table></div>`;
                        }

                        Swal.close(); // Close loading alert
                        Swal.fire({
                            title: 'Detailed Results',
                            html: html,
                            icon: 'info',
                            width: '600px',
                            confirmButtonText: 'OK',
                            allowOutsideClick: false,
                            customClass: {
                                popup: 'rounded-4 shadow-lg',
                                confirmButton: 'btn btn-info px-4 py-2'
                            }
                        }).then(() => {
                            // Reload the page after closing the alert
                            history.back();
                        });
                    } else {
                        showErrorAlert(response.message || 'An error occurred while processing admission fees entry.');
                    }
                },
                error: function(e) {
                    showErrorAlert('An unexpected error occurred while processing admission fees entry.');
                    console.error(e.responseText);
                    let errorMessage = "Page: " + window.location.href + "\n\n" + e.responseText;
                    sendErrorReport(errorMessage);
                },
                complete: function() {
                    submittingAdmissionFees = false;
                    $('#admissionFeesForm :input').prop('disabled', false);
                    refreshAdmissionFeesValidation();
                }
            });
        });

        // More details button click event
        $('.more-details-btn').on('click', function() {
            const studentId = $(this).data('student-id');
            const studentName = capitalize($(this).closest('tr').data('name'));

            $('#studentFinancialDetailsModalLabel').html(`Financial Details: <b>${studentName}</b>`);

            if (financialDataLoaded[studentId]) {
                $('#studentFinancialDetailsModalBody').html(financialDataLoaded[studentId]);
                $('#studentFinancialDetailsModal').modal('show');
                return;
            }

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/get/fees-x-payments/admission/get-student-financial-overview.php',
                type: 'POST',
                data: {
                    student_id: studentId
                },
                dataType: 'json',
                beforeSend: function() {
                    showLoadingAlert('Fetching student financial details...');
                },
                success: function(response) {
                    Swal.close();
                    if (response.success) {
                        const unpaidFeesTable = response.unpaid_fees_table;
                        const paidFeesTable = response.paid_fees_table;
                        const fullHtml = unpaidFeesTable + paidFeesTable;

                        $('#studentFinancialDetailsModalBody').html(fullHtml);
                        $('#studentFinancialDetailsModal').modal('show');

                        if (!financialDataLoaded[studentId]) {
                            financialDataLoaded[studentId] = fullHtml;
                        }
                    } else {
                        showErrorAlert(response.message);
                    }
                },
                error: function(xhr) {
                    console.error(xhr.responseText);
                    showErrorAlert('Error fetching student financial details');
                }
            });
        });
    }

    $(document).ready(bindAdmissionFeesForm);

    function captureAdmissionFeesDraft() {
        const draft = admissionFeesDrafts.get(selectedAcademicYear) || new Map();
        $('#admissionFeesTable tbody tr').each(function() {
            const row = $(this);
            draft.set(row.attr('data-student-id'), {
                feeType: row.find('.admission-type-select').val(),
                discount: row.find('.discount-amount-input').val(),
                classId: row.attr('data-admission-class-id'),
                actualAmount: row.attr('data-actual-amount')
            });
        });
        admissionFeesDrafts.set(selectedAcademicYear, draft);
    }

    function restoreAdmissionFeesDraft() {
        const draft = admissionFeesDrafts.get(selectedAcademicYear);
        let changedRate = false;
        $('#admissionFeesTable tbody tr').each(function() {
            const row = $(this);
            const studentID = row.attr('data-student-id');
            const saved = draft && draft.get(studentID);
            if (!saved) return;
            row.find('.admission-type-select').val(saved.feeType);
            updateAmount(studentID, saved.discount);
            if (saved.classId !== row.attr('data-admission-class-id') ||
                Number(saved.actualAmount) !== Number(row.attr('data-actual-amount'))) changedRate = true;
        });
        if (changedRate) {
            $('#admissionFeesYearStatus').removeClass('d-none').text('Your saved choices were restored. A class or fee rate has changed; please review the updated amounts and discounts.');
        }
    }

    function admissionFeeRowData(row) {
        const academicYear = row.attr('data-academic-year');
        const classID = row.attr('data-admission-class-id');
        if (academicYear !== selectedAcademicYear || !/^[1-9][0-9]*$/.test(classID || '')) {
            throw new Error('Reload this year to use the correct enrollment and class.');
        }
        const feeType = row.find('.admission-type-select').val();
        if (!['new-admission-fees', 're-admission-fees'].includes(feeType)) throw new Error('Choose a valid fee type.');
        const rates = feeType === 're-admission-fees' ? reAdmissionFees : newAdmissionFees;
        const amount = Number(rates[classID] || 0);
        if (!Number.isFinite(amount) || amount <= 0) {
            throw new Error('No positive fee is configured for this class and fee type. Set its fee, choose another type, or remove this student.');
        }
        const discount = Number(row.find('.discount-amount-input').val());
        const offer = Number(row.find('.offer-amount-input').val());
        if (!Number.isFinite(discount) || discount < 0 || discount >= amount) {
            throw new Error('Discount must be zero or more and less than the fee.');
        }
        if (!Number.isFinite(offer) || offer <= 0 || Math.abs(amount - discount - offer) > 0.011) {
            throw new Error('Check the offer amount and discount.');
        }
        return {
            student_id: row.attr('data-student-id'),
            student_name: capitalize(row.attr('data-name')),
            academic_year: academicYear,
            fees_type: feeType,
            admission_class_id: classID,
            discount: discount
        };
    }

    function collectAdmissionFeesData() {
        const data = [];
        $('#admissionFeesTable tbody tr').each(function() { data.push(admissionFeeRowData($(this))); });
        return data;
    }

    function refreshAdmissionFeesValidation() {
        let valid = filteredStudentIDs.length > 0;
        let reAdmissionCount = 0;
        $('#admissionFeesTable tbody tr').each(function() {
            const row = $(this);
            let message = '';
            try { admissionFeeRowData(row); } catch (error) { valid = false; message = error.message; }
            row.find('.fee-validation-message').text(message).toggleClass('d-none', !message);
            row.find('.discount-amount-input, .offer-amount-input').toggleClass('is-invalid', !!message);
            if (row.find('.admission-type-select').val() === 're-admission-fees') reAdmissionCount++;
        });
        $('#changeFeesTypeToReAdmission')
            .prop('checked', filteredStudentIDs.length > 0 && reAdmissionCount === filteredStudentIDs.length)
            .prop('indeterminate', reAdmissionCount > 0 && reAdmissionCount < filteredStudentIDs.length);
        $('#submitAdmissionFeesEntryBtn').prop('disabled', !valid || changingAcademicYear || submittingAdmissionFees);
        return valid;
    }

    function changeAdmissionFeesYear(year) {
        if (year === selectedAcademicYear || changingAcademicYear || submittingAdmissionFees) {
            $('#admissionFeesAcademicYear').val(selectedAcademicYear);
            return;
        }
        captureAdmissionFeesDraft();
        changingAcademicYear = true;
        $('#admissionFeesForm :input').prop('disabled', true);
        $('#admissionFeesYearStatus').removeClass('d-none alert-danger').addClass('alert-info').text('Loading academic year ' + year + '...');
        const url = new URL(window.location.href);
        url.searchParams.set('selected_year', year);
        url.searchParams.delete('academic_year');
        url.searchParams.set('student_ids', requestedStudentIDs.join(','));
        const showYearError = () => {
            $('#admissionFeesAcademicYear').val(selectedAcademicYear);
            $('#admissionFeesYearStatus').removeClass('d-none alert-info').addClass('alert-danger')
                .text('Could not load that academic year. Your current entries are still here. Please try again.');
        };
        $.ajax({
            url: url.toString(),
            type: 'GET',
            dataType: 'html',
            cache: false,
            timeout: 20000,
            success: function(html) {
                try {
                    const page = new DOMParser().parseFromString(html, 'text/html');
                    const form = page.getElementById('admissionFeesForm');
                    const contextNode = form && form.querySelector('#admissionFeesPageData');
                    if (!contextNode) throw new Error('Admission fee form missing');
                    const context = JSON.parse(contextNode.textContent);
                    if (context.academicYear !== year || !Array.isArray(context.studentIds) ||
                        !Array.isArray(context.filteredStudentIds) || !context.newAdmissionFees || !context.reAdmissionFees) {
                        throw new Error('Admission fee year data missing');
                    }
                    contextNode.remove();
                    // Insert only the form; never execute scripts from the fetched full page.
                    document.getElementById('admissionFeesForm').replaceWith(document.importNode(form, true));
                    selectedAcademicYear = context.academicYear;
                    requestedStudentIDs = context.studentIds;
                    filteredStudentIDs = context.filteredStudentIds;
                    newAdmissionFees = context.newAdmissionFees;
                    reAdmissionFees = context.reAdmissionFees;
                    financialDataLoaded = [];
                    bindAdmissionFeesForm();
                    window.history.replaceState(null, '', url.toString());
                } catch (error) { showYearError(); }
            },
            error: showYearError,
            complete: function() {
                changingAcademicYear = false;
                $('#admissionFeesForm :input').prop('disabled', false);
                refreshAdmissionFeesValidation();
            }
        });
    }

    // Function to sort student rows
    function sortStudentRows() {
        var sortBy = $('#admissionFeesStudentListSort').val();
        var rows = $('#admissionFeesTable tbody tr').get();

        rows.sort(function(a, b) {
            var nameA = $(a).data('name');
            var nameB = $(b).data('name');
            var rollA = parseInt($(a).attr('data-roll-no')) || 0;
            var rollB = parseInt($(b).attr('data-roll-no')) || 0;
            var indexA = parseInt($(a).attr('data-original-index')) || 0;
            var indexB = parseInt($(b).attr('data-original-index')) || 0;

            if (sortBy === 'name-asc') {
                return nameA.localeCompare(nameB);
            } else if (sortBy === 'name-desc') {
                return nameB.localeCompare(nameA);
            } else if (sortBy === 'roll-asc') {
                return rollA - rollB;
            } else if (sortBy === 'roll-desc') {
                return rollB - rollA;
            } else { // default
                return indexA - indexB;
            }
        });

        $.each(rows, function(index, row) {
            $('#admissionFeesTable tbody').append(row);
        });
    }

    // The enrollment fixes the class; only the fee type and discount are editable.
    function updateAmount(student_id, discount = 0) {
        const row = $(document.getElementById('trow-' + student_id));
        const feesType = row.find('.admission-type-select').val();
        const classID = row.attr('data-admission-class-id');
        const rates = feesType === 're-admission-fees' ? reAdmissionFees : newAdmissionFees;
        let actualAmount = Number(rates[classID] || 0);

        actualAmount =
            actualAmount % 1 === 0 ?
            actualAmount.toFixed(0) :
            actualAmount.toFixed(2);

        row.find('[id^="actual-amount-"]').text('<?= $currency_symbol ?>' + actualAmount);
        row.attr('data-actual-amount', actualAmount);
        const offer = Number(actualAmount) - Number(discount);
        row.find('.offer-amount-input').val(Number.isFinite(offer) ? Math.max(0, offer).toFixed(2) : '').attr('max', actualAmount);
        row.find('.discount-amount-input').val(discount).attr('max', actualAmount);
    }
</script>

<?php include_once("../../../includes/body-close.php"); ?>
