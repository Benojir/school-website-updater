<?php
include_once("../../../includes/auth-check.php");
require_once("../../../includes/header-open.php");
echo "<title>Admission Fees Entry - " . $school_name . "</title>";
require_once("../../../includes/header-close.php");
require_once("../../../includes/dashboard-navbar.php");

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    include_once("../../../includes/permission-denied.php");
}

$student_ids_string = $_REQUEST['student_ids'] ?? '';
$student_ids = explode(',', $student_ids_string);

if (empty($student_ids_string) || count($student_ids) == 0) {
    echo "<div class='container mt-4'><div class='alert alert-danger'>No student IDs provided.</div></div>";
    include_once("../../../includes/body-close.php");
    exit();
}

// Fetch class-wise new admission fees
$stmt = $pdo->prepare("SELECT class_id, amount FROM class_wise_new_admission_fees");
$stmt->execute();
$new_admission_fees = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// Fetch class-wise re-admission fees
$stmt = $pdo->prepare("SELECT class_id, amount FROM class_wise_re_admission_fees");
$stmt->execute();
$re_admission_fees = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// Fetch all classes for dropdowns
$stmt = $pdo->prepare("SELECT id, class_name FROM classes ORDER BY id ASC");
$stmt->execute();
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

$filtered_student_ids = [];

?>
<style>
    .table-responsive {
        max-height: 500px;
        overflow-y: auto;
        scrollbar-width: thin;
        scrollbar-color: #888 #e0e0e0;
    }

    .table>thead {
        position: sticky;
    }

    .table>thead>tr>th {
        vertical-align: middle !important;
        text-align: center;
    }

    .table thead th {
        position: relative;
    }

    .table tbody td {
        vertical-align: middle !important;
        text-align: center;
    }

    .table tbody td img {
        border-radius: 5px;
        width: 50px;
        object-fit: cover;
        cursor: pointer;
        border: 1px solid #ddd;
    }
</style>

<div class="container mt-4">
    <div class="card shadow-sm mb-4">
        <div class="card-header d-flex justify-content-between align-items-center bg-primary text-white">
            <div>
                <h4 class="mb-0"><i class="fas fa-money-bill me-2"></i>Admission Fees Entry</h4>
            </div>
            <div>
                <button type="button" class="btn btn-sm btn-light" onclick="history.back();">
                    <i class="fas fa-arrow-left me-2"></i>Go Back
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="mb-3">
                <h5 class="m-0 p-0">Total Students: <span id="total_students_fee_entry"></span></h5>
            </div>
            <div class="row mb-3">
                <div class="row col-md-6">
                    <div class="col-md-12 mb-2">
                        <input type="text" id="admissionFeesSearchBox" class="form-control" placeholder="Search students..." />
                    </div>
                    <div class="col-md-12 mb-2">
                        <select id="admissionFeesStudentListSort" class="form-select">
                            <option value="name-asc" selected>Sort by Name (A-Z)</option>
                            <option value="name-desc">Sort by Name (Z-A)</option>
                        </select>
                    </div>
                </div>
                <div class="row col-md-6">
                    <!-- Checkboxes -->
                    <div class="col-md-12 mb-2 d-flex align-items-center">
                        <input type="checkbox" id="allowSelectingAdmissionClass" class="form-check-input me-2" />
                        <label for="allowSelectingAdmissionClass" class="form-check-label">Allow selecting admission class</label>
                    </div>
                    <div class="col-md-12 mb-2 d-flex align-items-center">
                        <input type="checkbox" id="changeFeesTypeToReAdmission" class="form-check-input me-2" />
                        <label for="changeFeesTypeToReAdmission" class="form-check-label">Change fees type to re-admission</label>
                    </div>
                </div>
            </div>

            <div class="table-responsive rounded-2">
                <table class="table table-bordered table-striped" id="admissionFeesTable">
                    <thead class="table-dark">
                        <tr>
                            <th><i class="fas fa-user"></i></th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Class</th>
                            <th>Academic Year</th>
                            <th>Fees Type</th>
                            <th>Admission Class</th>
                            <th>Actual Amount</th>
                            <th>Offer Amount</th>
                            <th>Discount</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($student_ids as $student_id):
                            $student_info = getStudentInfo($pdo, $student_id);
                            if (!$student_info) {
                                continue;
                            }

                            if (in_array($student_id, $filtered_student_ids)) {
                                continue;
                            }

                            $filtered_student_ids[] = $student_id;

                            $class_id = $student_info['class_id'];
                            $actual_amount = $new_admission_fees[$class_id] ?? 0;

                            // PREPARE DATA FOR SORTING
                            $sort_name = strtolower($student_info['name']);
                        ?>
                            <tr id="trow-<?= $student_id ?>"
                                class="student-row"
                                data-student-id="<?= $student_id ?>"
                                data-name="<?= safe_htmlspecialchars($sort_name) ?>">

                                <td>
                                    <button tabindex="-1" class="btn btn-sm btn-outline-primary more-details-btn" title="More Details" data-student-id="<?= $student_id ?>">
                                        <i class="fas fa-plus-circle"></i>
                                    </button>
                                </td>

                                <td
                                    title="View Image"
                                    data-fancybox="student-images"
                                    data-caption="<?= $student_info['name'] ?>"
                                    data-src="<?= BASE_URL . "/uploads/students/" . $student_info['student_image']; ?>">
                                    <img
                                        src="<?= BASE_URL . "/uploads/students/" . $student_info['student_image']; ?>"
                                        alt="Img"
                                        loading="lazy" />
                                </td>
                                <td>
                                    <a tabindex="-1"
                                        class="text-decoration-none"
                                        href="<?= BASE_URL ?>/parent/dashboard/student-details.php?student_id=<?= $student_info['student_id'] ?>"
                                        target="_blank">
                                        <?php echo safe_htmlspecialchars($student_info['name']); ?>
                                    </a>
                                    <br>
                                    <small class="text-muted" style="font-size: 0.8rem;"><?= $student_info['student_id'] ?></small>
                                </td>
                                <td><?= $student_info['class_name'] . ' (' . $student_info['section_name'] . ')' ?></td>
                                <td>
                                    <select class="form-control form-control-sm academic-year-select" tabindex="-1">
                                        <?php
                                        $current_year = date('Y');
                                        for ($year = $current_year; $year <= $current_year + 2; $year++) {
                                            $selected = ($year == $current_year + 0) ? 'selected' : '';
                                            echo "<option value='$year' $selected>$year</option>";
                                        }
                                        ?>
                                    </select>
                                </td>
                                <td>
                                    <select id="admission-type-select-<?= $student_id ?>"
                                        class="form-control form-control-sm admission-type-select"
                                        tabindex="-1"
                                        onchange="updateActualAmount('<?= $student_id ?>')">
                                        <option value="new-admission-fees" selected>New Admission Fees</option>
                                        <option value="re-admission-fees">Re-Admission Fees</option>
                                    </select>
                                </td>
                                <td>
                                    <select id="class-select-<?= $student_id ?>"
                                        class="form-select form-select-sm admission-class-select"
                                        disabled tabindex="-1"
                                        onchange="updateActualAmount('<?= $student_id ?>')">
                                        <option value="<?= $student_info['class_id'] ?>">Current Class</option>
                                        <?php foreach ($classes as $class): ?>
                                            <option value="<?= $class['id']; ?>"><?= safe_htmlspecialchars($class['class_name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                                <td>
                                    <span id="actual-amount-<?= $student_id ?>" class="text-success fw-bold">
                                        <?php echo $currency_symbol . $actual_amount; ?>
                                    </span>
                                </td>
                                <td>
                                    <input
                                        id="offer-amount-input-<?= $student_id ?>"
                                        type="number"
                                        class="form-control form-control-sm offer-amount-input"
                                        min="0"
                                        max="<?php echo $actual_amount; ?>" />
                                </td>
                                <td>
                                    <input
                                        id="discount-amount-input-<?= $student_id ?>"
                                        type="number"
                                        class="form-control form-control-sm discount-amount-input"
                                        min="0"
                                        max="<?php echo $actual_amount; ?>" />
                                </td>
                                <td>
                                    <button
                                        data-student-id="<?php echo $student_info['student_id']; ?>"
                                        tabindex="-1"
                                        title="Remove student from list"
                                        class="btn btn-sm btn-danger remove-student-btn">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="text-end mt-3">
                <button id="submitAdmissionFeesEntryBtn" class="btn btn-primary" tabindex="-1">
                    <i class="fas fa-check-circle me-2"></i>Submit Admission Fees Entry
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Include the modal html -->
<?php include_once('../../../includes/modals/fees-x-payments/financial-details-modal.php'); ?>

<script>
    let filteredStudentIDs = <?= json_encode($filtered_student_ids); ?>;
    const newAdmissionFees = <?= json_encode($new_admission_fees); ?>;
    const reAdmissionFees = <?= json_encode($re_admission_fees); ?>;
    let financialDataLoaded = [];

    $(document).ready(function() {
        $('#total_students_fee_entry').text(filteredStudentIDs.length);

        // Enable/disable admission class selection
        $('#allowSelectingAdmissionClass').change(function() {
            const isChecked = $(this).is(':checked');
            $('.admission-class-select').prop('disabled', !isChecked);
        });

        // Change admission fees type
        $('#changeFeesTypeToReAdmission').change(function() {
            const isChecked = $(this).is(':checked');
            if (isChecked) {
                $('.admission-type-select').val('re-admission-fees').trigger('change');
            } else {
                $('.admission-type-select').val('new-admission-fees').trigger('change');
            }
        });

        // Max input validation for offer and discount amounts
        $('.offer-amount-input, .discount-amount-input').on('input', function() {
            const studentRow = $(this).closest('tr');
            const studentID = studentRow.data('student-id');
            const actualAmountText = $(`#actual-amount-${studentID}`).text().replace('<?= $currency_symbol ?>', '');
            const actualAmount = parseFloat(actualAmountText) || 0;

            let inputValue = parseFloat($(this).val()) || 0;
            if (inputValue > actualAmount) {
                $(this).val(actualAmount);
            } else if (inputValue < 0) {
                $(this).val(0);
            }

            // Auto calculate the other field and discount field
            let offerAmount = parseFloat($(`#offer-amount-input-${studentID}`).val()) || 0;
            let discountAmount = parseFloat($(`#discount-amount-input-${studentID}`).val()) || 0;

            let offerAmountCalc = actualAmount - discountAmount;
            let discountAmountCalc = actualAmount - offerAmount;

            if ($(this).hasClass('offer-amount-input')) {
                // If offer amount is changed, update discount
                $(`#discount-amount-input-${studentID}`).val(discountAmountCalc >= 0 ? discountAmountCalc : 0);
            } else if ($(this).hasClass('discount-amount-input')) {
                // If discount amount is changed, update offer
                $(`#offer-amount-input-${studentID}`).val(offerAmountCalc >= 0 ? offerAmountCalc : 0);
            }
        });

        // Remove student from the list
        $('.remove-student-btn').click(function() {
            const studentID = $(this).data('student-id');
            $(`#trow-${studentID}`).remove();
            filteredStudentIDs = filteredStudentIDs.filter(id => id !== studentID);
            $('#total_students_fee_entry').text(filteredStudentIDs.length);
        });

        // Search functionality
        $('#admissionFeesSearchBox').on('keyup', function() {
            var value = $(this).val().toLowerCase();
            $("#admissionFeesTable tbody tr").filter(function() {
                // Toggle visibility based on whether the row text contains the search term
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });

        // Sorting functionality
        sortStudentRows(); // Initial sort
        $('#admissionFeesStudentListSort').change(function() {
            sortStudentRows();
        });

        // Submit admission fees entry
        $('#submitAdmissionFeesEntryBtn').click(function() {
            if (filteredStudentIDs.length === 0) {
                showWarningAlert('No students to process.');
                return;
            }

            let data = [];

            $('#admissionFeesTable tbody tr').each(function() {
                const studentID = $(this).data('student-id');
                const studentName = capitalize($(this).data('name'));
                const academicYear = $(this).find('.academic-year-select').val();
                const feesType = $(this).find('.admission-type-select').val();
                const admissionClassID = $(this).find('.admission-class-select').val();
                const discount = $(this).find('.discount-amount-input').val() || 0;
                data.push({
                    student_id: studentID,
                    student_name: studentName,
                    academic_year: academicYear,
                    fees_type: feesType,
                    admission_class_id: admissionClassID,
                    discount: discount
                });
            });

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/put/fees-x-payments/process-fees-entry-admission.php',
                type: 'PUT',
                data: {
                    students_data: JSON.stringify(data)
                },
                dataType: 'json',
                beforeSend: function() {
                    showLoadingAlert('Processing admission fees entry. Please wait...');
                },
                success: function(response) {
                    if (response.success) {
                        let errorMessages = response.errors || [];
                        let proccessedStudents = response.successes || [];
                        let skippedStudents = response.skips || [];
                        let message = response.message || 'Admission fees entry processed successfully.';
                        let html = "";

                        if (errorMessages.length > 0) {
                            html += `<div class="alert alert-danger mb-3">
                            <strong>Errors: (${errorMessages.length})</strong>
                            <ul>`;
                            errorMessages.forEach(function(error) {
                                html += `<li>${error}</li>`;
                            });
                            html += `</ul></div>`;
                        }

                        if (skippedStudents.length > 0) {
                            html += `<div class="text-danger">
                            <strong>Skipped students: (${skippedStudents.length})</strong>
                            <table class="table table-sm table-bordered mt-2">
                                <thead class="table-danger">
                                    <tr>
                                        <th>Student Name</th>
                                        <th>Reason</th>
                                    </tr>
                                </thead>
                                <tbody>`;
                            skippedStudents.forEach(function(student) {
                                html += `<tr>
                                    <td>${student.student_name}</td>
                                    <td>${student.reason}</td>
                                </tr>`;
                            });
                            html += `</tbody></table></div>`;
                        }

                        if (proccessedStudents.length > 0) {
                            html += `<div class="text-success">
                            <strong>Processed students: (${proccessedStudents.length})</strong>
                            <table class="table table-sm table-bordered mt-2">
                                <thead class="table-success">
                                    <tr>
                                        <th>Student Name</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>`;
                            proccessedStudents.forEach(function(student) {
                                html += `<tr>
                                    <td>${student.student_name}</td>
                                    <td>${student.message}</td>
                                </tr>`;
                            });
                            html += `</tbody></table></div>`;
                        }

                        Swal.close(); // Close loading alert
                        Swal.fire({
                            title: 'Detailed Results',
                            html: html,
                            icon: 'info',
                            width: '600px',
                            confirmButtonText: 'OK',
                            allowOutsideClick: false,
                            customClass: {
                                popup: 'rounded-4 shadow-lg',
                                confirmButton: 'btn btn-info px-4 py-2'
                            }
                        }).then(() => {
                            // Reload the page after closing the alert
                            history.back();
                        });
                    } else {
                        showErrorAlert(response.message || 'An error occurred while processing admission fees entry.');
                    }
                },
                error: function(e) {
                    showErrorAlert('An unexpected error occurred while processing admission fees entry.');
                    console.error(e.responseText);
                }
            });
        });

        // More details button click event
        $('.more-details-btn').on('click', function() {
            const studentId = $(this).data('student-id');
            const studentName = capitalize($(this).closest('tr').data('name'));

            $('#studentFinancialDetailsModalLabel').html(`Financial Details: <b>${studentName}</b>`);

            if (financialDataLoaded[studentId]) {
                $('#studentFinancialDetailsModalBody').html(financialDataLoaded[studentId]);
                $('#studentFinancialDetailsModal').modal('show');
                return;
            }

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/get/fees-x-payments/admission/get-student-financial-overview.php',
                type: 'POST',
                data: {
                    student_id: studentId
                },
                dataType: 'json',
                beforeSend: function() {
                    showLoadingAlert('Fetching student financial details...');
                },
                success: function(response) {
                    Swal.close();
                    if (response.success) {
                        const unpaidFeesTable = response.unpaid_fees_table;
                        const paidFeesTable = response.paid_fees_table;
                        const fullHtml = unpaidFeesTable + paidFeesTable;

                        $('#studentFinancialDetailsModalBody').html(fullHtml);
                        $('#studentFinancialDetailsModal').modal('show');

                        if (!financialDataLoaded[studentId]) {
                            financialDataLoaded[studentId] = fullHtml;
                        }
                    } else {
                        showErrorAlert(response.message);
                    }
                },
                error: function(xhr) {
                    console.error(xhr.responseText);
                    showErrorAlert('Error fetching student financial details');
                }
            });
        });
    });

    // Function to sort student rows
    function sortStudentRows() {
        var sortBy = $('#admissionFeesStudentListSort').val();
        var rows = $('#admissionFeesTable tbody tr').get();

        rows.sort(function(a, b) {
            var nameA = $(a).data('name');
            var nameB = $(b).data('name');

            if (sortBy === 'name-asc') {
                return nameA.localeCompare(nameB);
            } else if (sortBy === 'name-desc') {
                return nameB.localeCompare(nameA);
            }
        });

        $.each(rows, function(index, row) {
            $('#admissionFeesTable tbody').append(row);
        });
    }

    // Update actual amount based on fees type and class selection
    function updateActualAmount(student_id) {
        const feesType = $(`#admission-type-select-${student_id}`).val();
        const classSelect = $(`#class-select-${student_id}`);
        const selectedClassId = classSelect.val() || null;

        let actualAmount = 0;
        if (feesType == 'new-admission-fees') {
            if (selectedClassId && newAdmissionFees[selectedClassId]) {
                actualAmount = newAdmissionFees[selectedClassId];
            } else {
                actualAmount = 0;
            }
        } else if (feesType == 're-admission-fees') {
            if (selectedClassId && reAdmissionFees[selectedClassId]) {
                actualAmount = reAdmissionFees[selectedClassId];
            } else {
                actualAmount = 0;
            }
        }

        $(`#actual-amount-${student_id}`).text('<?= $currency_symbol ?>' + actualAmount);
    }
</script>

<?php include_once("../../../includes/body-close.php"); ?>