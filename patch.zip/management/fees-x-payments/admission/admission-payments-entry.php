<?php
/** @var array $additional_website_configs
 * @var string $school_name
 */
include_once("../../../includes/auth-check.php");
require_once("../../../includes/header-open.php");
echo "<title>Admission Payments Entry - " . $school_name . "</title>";
require_once("../../../includes/header-close.php");
require_once("../../../includes/dashboard-navbar.php");

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    include_once("../../../includes/permission-denied.php");
}

$authSession = getAuthenticatedAdmin($pdo);
$security_pin = $authSession['security_pin'];


$student_ids_string = $_REQUEST['student_ids'] ?? '';
$student_ids = explode(',', $student_ids_string);

if (empty($student_ids_string) || count($student_ids) == 0) {
    echo "<div class='container mt-4'><div class='alert alert-danger'>No student IDs provided.</div></div>";
    include_once("../../../includes/body-close.php");
    exit();
}

$filtered_student_ids = [];
?>
<style>
    .table>thead>tr>th {
        vertical-align: middle !important;
        text-align: center;
    }

    .table thead th {
        position: relative;
    }

    .table tbody td {
        vertical-align: middle !important;
        text-align: center;
    }

    .table tbody td img {
        border-radius: 5px;
        width: 60px;
        object-fit: cover;
        cursor: pointer;
        border: 1px solid #ddd;
    }
</style>

<div class="container-fluid mt-3">
    <div class="card shadow-sm mb-4">
        <div class="card-header d-flex justify-content-between align-items-center bg-primary text-white">
            <div>
                <h4 class="mb-0"><i class="fas fa-money-bill me-2"></i>Admission Payments Entry</h4>
            </div>
            <div>
                <button type="button" class="btn btn-sm btn-danger" onclick="window.close()">
                    <i class="fas fa-window-close me-2"></i>Close Tab
                </button>
            </div>
        </div>
        <div class="card-body">
            <div>
                <h5>Total Students: <span id="total_students_payment_entry"></span></h5>
            </div>
            <div class="row mb-3 bg-light">
                <div class="row col-md-6 ">
                    <div class="col-md-6 my-2">
                        <input type="text" id="admissionPaymentsSearchBox" class="form-control" placeholder="Search students..." />
                    </div>
                    <div class="col-md-6 my-2">
                        <select id="studentListSort" class="form-select">
                            <option value="default" selected>Default Sort (Requested Order)</option>
                            <option value="name-asc">Sort by Name (A-Z)</option>
                            <option value="name-desc">Sort by Name (Z-A)</option>
                            <option value="roll-asc">Sort by Roll No (Low to High)</option>
                            <option value="roll-desc">Sort by Roll No (High to Low)</option>
                            <option value="pending-asc">Sort by Pending Amount (Low to High)</option>
                            <option value="pending-desc">Sort by Pending Amount (High to Low)</option>
                            <option value="last_payment_asc">Sort by Last Payment Date (Old to New)</option>
                            <option value="last_payment_desc">Sort by Last Payment Date (New to Old)</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="d-flex justify-content-end my-2">
                        <button id="processPaymentsBtn" class="btn btn-primary">Save Payments Entry</button>
                    </div>
                </div>
            </div>
            <div class="table-responsive rounded-2">
                <table class="table table-bordered table-striped" id="admissionPaymentsTable">
                    <thead class="table-dark">
                        <tr>
                            <th><i class="fas fa-user"></i></th>
                            <th>Image</th>
                            <th>Student Name</th>
                            <th>Admission Amount</th>
                            <th>Offer Amount</th>
                            <th>Pending Amount</th>
                            <th>Pay Amount</th>
                            <th>Pay Date</th>
                            <th>Last Payment</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($student_ids as $original_index => $student_id):

                            $student_info = getStudentInfo($pdo, $student_id);
                            if (!$student_info) {
                                continue;
                            }

                            $admission_amounts = [];
                            $offer_amounts = [];
                            $pending_amounts = [];
                            $total_pending_amount = 0;

                            $unpaid_fees = getUnpaidAdmissionFeesData($pdo, $student_id);
                            if (count($unpaid_fees) == 0) {
                                continue;
                            }

                            foreach ($unpaid_fees as $unpaid_fee) {
                                $academic_year = $unpaid_fee['academic_year'];
                                $unpaid_class_name = $unpaid_fee['class_name'];
                                $offer_amount = $unpaid_fee['actual_amount'] - $unpaid_fee['discount_amount'];
                                $actual_amount = $unpaid_fee['actual_amount'];
                                $pending_amount = $unpaid_fee['unpaid_amount'];

                                $admission_amounts[] = [
                                    'academic_year' => $academic_year,
                                    'class_name' => $unpaid_class_name,
                                    'actual_amount' => $actual_amount,
                                ];

                                $offer_amounts[] = [
                                    'academic_year' => $academic_year,
                                    'class_name' => $unpaid_class_name,
                                    'offer_amount' => $offer_amount,
                                ];

                                $pending_amounts[] = [
                                    'academic_year' => $academic_year,
                                    'class_name' => $unpaid_class_name,
                                    'pending_amount' => $pending_amount,
                                ];

                                $total_pending_amount += $pending_amount;
                            }

                            $last_payment = getLastAdmissionPayment($pdo, $student_id);

                            if (in_array($student_id, $filtered_student_ids)) {
                                continue;
                            }

                            $filtered_student_ids[] = $student_id;

                            // PREPARE DATA FOR SORTING
                            $sort_name = strtolower($student_info['name']);
                            $sort_pending = $total_pending_amount;
                            $sort_date = ($last_payment) ? strtotime($last_payment['payment_date']) : 0;
                        ?>
                            <tr id="trow-<?= $student_id ?>"
                                class="student-row"
                                data-original-index="<?= $original_index ?>" 
                                data-student-id="<?= $student_id ?>"
                                data-name="<?= safe_htmlspecialchars($sort_name) ?>"
                                data-pending="<?= $sort_pending ?>"
                                data-last-payment="<?= $sort_date ?>"
                                data-roll-no="<?= $student_info['roll_no'] ?? 0 ?>">

                                <td>
                                    <button tabindex="-1" class="btn btn-sm btn-outline-primary more-details-btn" title="More Details" data-student-id="<?= $student_id ?>">
                                        <i class="fas fa-plus-circle"></i>
                                    </button>
                                </td>
                                <td
                                    title="View Image"
                                    data-fancybox="student-images"
                                    data-caption="<?= $student_info['name'] ?>"
                                    data-src="<?= BASE_URL . "/uploads/students/" . $student_info['student_image']; ?>">
                                    <img
                                        src="<?= BASE_URL . "/uploads/students/" . $student_info['student_image']; ?>"
                                        alt="Img"
                                        loading="lazy" />
                                </td>
                                <td>
                                    <a tabindex="-1"
                                        class="text-decoration-none"
                                        href="<?= BASE_URL ?>/parent/dashboard/student-details.php?student_id=<?= $student_id ?>"
                                        target="_blank">
                                        <?= safe_htmlspecialchars($student_info['name']); ?>
                                    </a>
                                    <br>
                                    <small class="text-muted" style="font-size: 0.8rem;"><?= $student_id ?></small>
                                    <br>
                                    <small class="text-muted" style="font-size: 0.8rem;">
                                        <?= $student_info['class_name'] . ' (' . $student_info['section_name'] . ') · Roll:' . $student_info['roll_no']; ?>
                                    </small>
                                </td>
                                <td style="max-width: 200px; min-width: 200px;">
                                    <?php foreach ($admission_amounts as $admission_amount): ?>
                                        <div class="w-100 mb-1" style="display: inline-block;">
                                            <span class="text-dark">
                                                <?= $admission_amount['class_name'] ?? '-' ?> ·
                                                <?= $currency_symbol . $admission_amount['actual_amount'] ?? 0 ?>
                                            </span>
                                        </div>
                                    <?php endforeach; ?>
                                </td>
                                <td style="max-width: 240px; min-width: 240px;">
                                    <?php foreach ($offer_amounts as $offer_amount): ?>
                                        <div class="w-100 mb-1" style="display: inline-block;">
                                            <span class="text-dark">
                                                <i class="fa-solid fa-calendar-days"></i><?= $offer_amount['academic_year'] ?? '-'; ?>
                                                · <?= $offer_amount['class_name'] ?? '-' ?> ·
                                                <span class="badge rounded-pill bg-success fw-bold"><?= $currency_symbol . $offer_amount['offer_amount'] ?? 0 ?></span>
                                            </span>
                                        </div>
                                    <?php endforeach; ?>
                                </td>
                                <td style="max-width: 240px; min-width: 240px;">
                                    <?php foreach ($pending_amounts as $pending_amount): ?>
                                        <div class="w-100 mb-1" style="display: inline-block;">
                                            <span class="text-dark">
                                                <i class="fa-solid fa-calendar-days"></i><?= $pending_amount['academic_year'] ?? '-'; ?>
                                                · <?= $pending_amount['class_name'] ?? '-' ?> ·
                                                <span class="badge rounded-pill bg-danger fw-bold"><?= $currency_symbol . $pending_amount['pending_amount'] ?? 0 ?></span>
                                            </span>
                                        </div>
                                    <?php endforeach; ?>
                                    <div class="w-100 mb-1" style="display: inline-block;">
                                        <span class="text-dark">
                                            Total Amount ·
                                            <span class="text-danger fw-bold"><?= $currency_symbol . $total_pending_amount ?></span>
                                        </span>
                                    </div>
                                </td>
                                <td><input type="text" id="payment-amount-<?= $student_id ?>" value="<?= $total_pending_amount ?>" class="form-control form-control-sm payment-amount text-center" min="0"></td>
                                <td><input type="date" id="payment-date-<?= $student_id ?>" value="<?= date('Y-m-d') ?>" class="form-control form-control-sm payment-date" tabindex="-1"></td>
                                <td>
                                    <?php if ($last_payment): ?>
                                        <?php echo "<span class='fw-bold badge rounded-pill bg-success'>" . $currency_symbol . $last_payment['payment_amount'] . "</span><br><span class='fw-bold'>" . date("d M, Y", strtotime($last_payment['payment_date'])) . "</span>"; ?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button tabindex="-1"
                                        title="Remove student from list"
                                        class="btn btn-sm btn-danger remove-student-btn"
                                        data-student-id="<?= $student_id ?>">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Include the modal html -->
<?php include_once('../../../includes/modals/fees-x-payments/financial-details-modal.php'); ?>

<script>
    let filteredStudentIds = <?= json_encode($filtered_student_ids) ?>;
    let financialDataLoaded = [];

    $('#total_students_payment_entry').text(filteredStudentIds.length);

    $(document).ready(function() {
        // Remove Student from List
        $('.remove-student-btn').on('click', function() {
            const studentId = $(this).data('student-id');
            $(`#trow-${studentId}`).remove();
            filteredStudentIds = filteredStudentIds.filter(id => id !== studentId);
            $('#total_students_payment_entry').text(filteredStudentIds.length);
        });

        // Select payment amount on focus
        $('.payment-amount').on('focus', function() {
            $(this).select();
        });

        // Payment Amount Input
        $('.payment-amount').on('input', function() {
            let paymentAmount = $(this).val();

            if (!isNumeric(paymentAmount)) {
                $(this).addClass('is-invalid');
                $(this).removeClass('is-valid');
            } else {
                $(this).removeClass('is-invalid');
                $(this).addClass('is-valid');
            }
        });

        // Payment Date Input
        $('.payment-date').on('input', function() {
            let paymentDate = $(this).val();

            if (!isValidDate(paymentDate)) {
                $(this).addClass('is-invalid');
                $(this).removeClass('is-valid');
            } else {
                $(this).removeClass('is-invalid');
                $(this).addClass('is-valid');
            }
        });

        // --- 1. Client-Side Search Functionality ---
        $('#admissionPaymentsSearchBox').on('keyup', function() {
            var value = $(this).val().toLowerCase();
            $("#admissionPaymentsTable tbody tr").filter(function() {
                // Toggle visibility based on whether the row text contains the search term
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });

        // --- 2. Client-Side Sort Functionality ---
        sortStudentRows(); // Initial sort
        $('#studentListSort').on('change', function() {
            sortStudentRows();
        });

        // --- 3. Show Student Financial Details in Modal ---
        $('.more-details-btn').on('click', function() {
            const studentId = $(this).data('student-id');
            const studentName = capitalize($(this).closest('tr').data('name'));

            $('#studentFinancialDetailsModalLabel').html(`Financial Details: <b>${studentName}</b>`);

            if (financialDataLoaded[studentId]) {
                $('#studentFinancialDetailsModalBody').html(financialDataLoaded[studentId]);
                $('#studentFinancialDetailsModal').modal('show');
                return;
            }

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/get/fees-x-payments/admission/get-student-financial-overview.php',
                type: 'POST',
                data: {
                    student_id: studentId
                },
                dataType: 'json',
                beforeSend: function() {
                    showLoadingAlert('Fetching student financial details...');
                },
                success: function(response) {
                    Swal.close();
                    // মডাল দেখানোর আগে বডির প্যাডিং রিমুভ করে দিন
                    $('body').css('padding-right', '');
                    $('body').removeClass('modal-open');
                    
                    if (response.success) {
                        const unpaidFeesTable = response.unpaid_fees_table;
                        const paidFeesTable = response.paid_fees_table;
                        const fullHtml = unpaidFeesTable + paidFeesTable;

                        $('#studentFinancialDetailsModalBody').html(fullHtml);
                        $('#studentFinancialDetailsModal').modal('show');

                        if (!financialDataLoaded[studentId]) {
                            financialDataLoaded[studentId] = fullHtml;
                        }
                    } else {
                        showErrorAlert(response.message);
                    }
                },
                error: function(xhr) {
                    console.error(xhr.responseText);
                    showErrorAlert('Error fetching student financial details');
                }
            });
        });

        // --- 4. Process Payments ---
        $('#processPaymentsBtn').on('click', function() {
            beforeProcessPayments(filteredStudentIds);
        });
    });

    // Function sort student rows
    function sortStudentRows() {
        var sortOption = $('#studentListSort').val();
        var $tbody = $('#admissionPaymentsTable tbody');
        var $rows = $tbody.find('tr').get();

        $rows.sort(function(a, b) {
            var valA, valB;

            switch (sortOption) {
                case 'default': // GET রিকোয়েস্টের ক্রমানুসারে
                    valA = parseInt($(a).data('original-index'));
                    valB = parseInt($(b).data('original-index'));
                    return valA - valB;

                case 'roll-asc': // রোল নম্বর ছোট থেকে বড়
                    valA = parseInt($(a).data('roll-no')) || 0;
                    valB = parseInt($(b).data('roll-no')) || 0;
                    return valA - valB;

                case 'roll-desc': // রোল নম্বর বড় থেকে ছোট
                    valA = parseInt($(a).data('roll-no')) || 0;
                    valB = parseInt($(b).data('roll-no')) || 0;
                    return valB - valA;

                case 'name-asc':
                    valA = $(a).data('name');
                    valB = $(b).data('name');
                    return valA.localeCompare(valB);

                case 'name-desc':
                    valA = $(a).data('name');
                    valB = $(b).data('name');
                    return valB.localeCompare(valA);

                case 'pending-asc':
                    valA = parseFloat($(a).data('pending'));
                    valB = parseFloat($(b).data('pending'));
                    return valA - valB;

                case 'pending-desc':
                    valA = parseFloat($(a).data('pending'));
                    valB = parseFloat($(b).data('pending'));
                    return valB - valA;

                case 'last_payment_asc':
                    valA = parseInt($(a).data('last-payment'));
                    valB = parseInt($(b).data('last-payment'));
                    return valA - valB;

                case 'last_payment_desc':
                    valA = parseInt($(a).data('last-payment'));
                    valB = parseInt($(b).data('last-payment'));
                    return valB - valA;

                default:
                    return 0;
            }
        });

        // Re-append rows in the new order
        $.each($rows, function(index, row) {
            $tbody.append(row);
        });
    }

    // Before Process Payments function -- Call this when save payment clicked ---
    function beforeProcessPayments(filteredStudentIds) {

        let formData = [];
        let errorFormData = [];

        filteredStudentIds.forEach((studentId, index) => {
            const trow = $(`#trow-${studentId}`);
            const studentName = capitalize(trow.data('name'));
            const paymentAmount = $('#payment-amount-' + studentId).val();
            const paymentDate = $('#payment-date-' + studentId).val();

            if (!isNumeric(paymentAmount) || !isValidDate(paymentDate)) {
                errorFormData.push({
                    studentId: studentId,
                    studentName: studentName,
                    paymentAmount: paymentAmount,
                    paymentDate: paymentDate
                });
            } else {
                formData.push({
                    studentId: studentId,
                    studentName: studentName,
                    paymentAmount: paymentAmount,
                    paymentDate: paymentDate
                });
            }
        });

        // --- Build error table ---
        let errorTable = `
        <div class="table-responsive">
            <table class="table table-sm table-bordered table-hover">
                <thead class="table-danger">
                <tr>
                    <th>Student Name</th>
                    <th>Payment Amount</th>
                    <th>Payment Date</th>
                </tr>
                </thead>
                <tbody>`;

        errorFormData.forEach((data, index) => {
            const studentName = data.studentName;
            const paymentAmount = data.paymentAmount;
            const paymentDate = data.paymentDate;

            errorTable += `
                <tr>
                    <td>${studentName}</td>
                    <td>${paymentAmount}</td>
                    <td>${paymentDate}</td>
                </tr>
            `;
        });

        errorTable += `
                </tbody>
            </table>
        </div>
        `

        if (errorFormData.length > 0) {
            showErrorAlert(errorTable, 'Invalid Payment Data');
            return;
        }

        // ----- Build success table -----
        let beforeProcessTable = `
        <div class="table-responsive">
            <table class="table table-sm table-bordered table-hover">
                <thead class="table-success">
                <tr>
                    <th>Student Name</th>
                    <th>Payment Amount</th>
                    <th>Payment Date</th>
                </tr>
                </thead>
                <tbody>`;

        formData.forEach((data, index) => {
            const studentName = data.studentName;
            const paymentAmount = data.paymentAmount;
            const paymentDate = data.paymentDate;

            beforeProcessTable += `
                <tr>
                    <td>${studentName}</td>
                    <td>${paymentAmount}</td>
                    <td>${paymentDate}</td>
                </tr>
            `;
        });

        beforeProcessTable += `
                </tbody>
            </table>
        </div>
        `

        Swal.fire({
            icon: 'question',
            title: 'Verify Payment Data',
            html: beforeProcessTable,
            width: '600px',
            showConfirmButton: true,
            showCancelButton: true,
            confirmButtonText: 'Everything Looks Good',
            cancelButtonText: 'Cancel',
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-success px-4 py-2',
                cancelButton: 'btn btn-danger px-4 py-2'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                <?php
                if ($additional_website_configs['need_security_pin_for_payment_entry'] == 1) {
                    echo "verifySecurityPin(formData);";
                } else {
                    echo "processPayments(formData);";
                }
                ?>
            }
        });
    }

    // Form submission function -- Call this when save payment clicked ---
    function processPayments(formData) {
        $.ajax({
            url: '<?= BASE_URL ?>/api/admin/put/fees-x-payments/admission/process-payments-entry-admission.php',
            type: 'PUT',
            data: {
                students_data: JSON.stringify(formData)
            },
            dataType: 'json',
            beforeSend: function() {
                showLoadingAlert('Processing payments...');
            },
            success: function(response) {
                if (response.success) {
                    showAlertAfterSuccess(response);
                } else {
                    showErrorAlert(response.message);
                }
            },
            error: function(e) {
                showErrorAlert('Error processing payments: ' + e.responseText);
                console.error(e);
                let errorMessage = "Page: " + window.location.href + "\n\n" + e.responseText;
                sendErrorReport(errorMessage);
            }
        });
    }

    // Function show details success form
    function showAlertAfterSuccess(response) {
        let errorMessages = response.errors || [];
        let proccessedStudents = response.successes || [];
        let skippedStudents = response.skips || [];
        let message = response.message || 'Admission payments entry processed successfully.';
        let html = "";

        if (errorMessages.length > 0) {
            html += `<div class="alert alert-danger mb-3">
                            <strong>Errors: (${errorMessages.length})</strong>
                            <ul>`;
            errorMessages.forEach(function(error) {
                html += `<li>${error}</li>`;
            });
            html += `</ul></div>`;
        }

        if (skippedStudents.length > 0) {
            html += `<div class="text-danger">
                            <strong>Skipped students: (${skippedStudents.length})</strong>
                            <table class="table table-sm table-bordered mt-2">
                                <thead class="table-danger">
                                    <tr>
                                        <th>Student Name</th>
                                        <th>Reason</th>
                                    </tr>
                                </thead>
                                <tbody>`;
            skippedStudents.forEach(function(student) {
                html += `<tr>
                                    <td>${student.student_name}</td>
                                    <td>${student.reason}</td>
                                </tr>`;
            });
            html += `</tbody></table></div>`;
        }

        if (proccessedStudents.length > 0) {
            html += `<div class="text-success">
                            <strong>Processed students: (${proccessedStudents.length})</strong>
                            <table class="table table-sm table-bordered mt-2">
                                <thead class="table-success">
                                    <tr>
                                        <th>Student Name</th>
                                        <th>Status</th>
                                        <th>Pay Amount</th>
                                        <th>Wallet Credit</th>
                                    </tr>
                                </thead>
                                <tbody>`;
            proccessedStudents.forEach(function(student) {
                html += `<tr>
                            <td>${student.student_name}</td>
                            <td class="text-success">Success</td>
                            <td><?= $currency_symbol ?>${student.payment_amount}</td>
                            <td><?= $currency_symbol ?>${student.wallet_credit}</td>
                        </tr>`;
            });
            html += `</tbody></table></div>`;
        }

        Swal.close(); // Close loading alert
        Swal.fire({
            title: 'Detailed Results',
            html: html,
            icon: 'info',
            width: '600px',
            confirmButtonText: 'OK',
            allowOutsideClick: false,
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-info px-4 py-2'
            }
        }).then(() => {
            // Reload the page after closing the alert
            location.reload();
        });
    }

    // Function verify security pin
    function verifySecurityPin(formData) {
        Swal.fire({
            title: 'Enter Security Pin',
            input: 'text', // Keep password type for masking
            inputAttributes: {
                autocapitalize: 'off',
                autofocus: 'true',
                // This is the key to stopping the "Saved Password" popup:
                autocomplete: 'one-time-code',
                name: 'my-unique-pin-field',
                style: '-webkit-text-security: disc;'
            },
            showCancelButton: true,
            confirmButtonText: 'Verify & Continue',
            showLoaderOnConfirm: true,
            preConfirm: (inputPin) => {
                if (inputPin === '<?= $security_pin ?>') {
                    return true;
                } else {
                    toastr.error('Invalid security pin. Please try again.');
                    return false;
                }
            },
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-primary px-4 py-2',
                cancelButton: 'btn btn-danger px-4 py-2'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                processPayments(formData);
            }
        });
    }
</script>

<?php include_once("../../../includes/body-close.php"); ?>