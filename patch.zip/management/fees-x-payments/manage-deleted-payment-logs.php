<?php
/** @var string $school_name
 * @var array $schoolSettings
 */
include_once("../../includes/auth-check.php");
require_once("../../includes/header-open.php");
echo "<title>Deleted Payments Log - " . $school_name . "</title>";
require_once("../../includes/header-close.php");
require_once("../../includes/dashboard-navbar.php");

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    include_once("../../includes/permission-denied.php");
}

$adminAuthData = getAuthenticatedAdmin($pdo);
$adminId = $adminAuthData['user_id'];
$security_pin = $adminAuthData['security_pin'];

// Validate payment type (optional here - empty means show both)
$payment_type = "";
if (isset($_REQUEST['payment-type'])) {
    $payment_type = $_REQUEST['payment-type'];
    if ($payment_type !== 'admission' && $payment_type !== 'monthly') {
        $payment_type = "";
    }
}

// Get all role IDs with manage fees permission
$stmt = $pdo->prepare("SELECT role_id FROM admin_permissions WHERE permission = ?");
$stmt->execute([PERM_MANAGE_FEES]);
$role_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);

$users = [];

// Get all users associated with those roles
if (!empty($role_ids)) {
    $placeholders = implode(',', array_fill(0, count($role_ids), '?'));

    $stmt = $pdo->prepare("SELECT id, full_name FROM users WHERE role_id IN ($placeholders)");
    $stmt->execute($role_ids);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Generate admin select options
$admin_select_options = '<option value="" selected>All Admins</option>';
$admin_select_options .= '<option value="unknown">Unknown</option>';

// Get all super admins
$stmt = $pdo->prepare("SELECT id, full_name FROM users WHERE user_role = 'superadmin'");
$stmt->execute();
$super_admins = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Track IDs we've already added to prevent duplicates
$added_ids = [];

// Add Super Admins (Skipping ID 1)
foreach ($super_admins as $super_admin) {
    if ($super_admin['id'] == 1) continue;

    $admin_select_options .= '<option value="' . $super_admin['id'] . '">' . $super_admin['full_name'] . '</option>';
    $added_ids[] = $super_admin['id'];
}

// Add Users with Permission (Checking for duplicates)
foreach ($users as $user) {
    if (!in_array($user['id'], $added_ids)) {
        $admin_select_options .= '<option value="' . $user['id'] . '">' . $user['full_name'] . '</option>';
        $added_ids[] = $user['id'];
    }
}
?>

<style>
    /* Keeps long remarks from blowing up the row height on small screens */
    .remark-cell {
        max-width: 320px;
    }

    .remark-text {
        word-break: break-word;
    }

    .remark-text.collapsed {
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }

    .remark-toggle {
        cursor: pointer;
        font-size: 0.75rem;
        color: #0d6efd;
        text-decoration: none;
    }

    .remark-toggle:hover {
        text-decoration: underline;
    }
</style>

<div class="container-fluid mt-4">
    <div class="card shadow-sm">
        <div class="bg-danger text-white d-flex justify-content-between align-items-center px-3 py-2">
            <h4><i class="fas fa-trash-alt me-2"></i> Deleted Payments Log</h4>
            <div>
                <a href="manage-payment-history-admission-x-monthly.php?payment-type=monthly" class="btn btn-sm btn-light">
                    <i class="fas fa-history me-1"></i> Payment History
                </a>
            </div>
        </div>

        <div class="card-body border-bottom">
            <div class="row g-3 align-items-center">
                <div class="col-md-3">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" class="form-control" id="search-input" placeholder="Search students... (Ctrl + /)">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-calendar-alt"></i></span>
                        <input type="text" class="form-control" id="date-range-picker" placeholder="Filter by deleted date range">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-credit-card"></i></span>
                        <select class="form-select" id="payment-type-filter">
                            <option value="" <?= (empty($payment_type) ? 'selected' : '') ?>>All Types</option>
                            <option value="admission" <?= ($payment_type === 'admission' ? 'selected' : '') ?>>Admission</option>
                            <option value="monthly" <?= ($payment_type === 'monthly' ? 'selected' : '') ?>>Monthly</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-2">
                    <select class="form-select custom-multiselect" id="admin-filter">
                        <?= $admin_select_options ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-secondary w-100" id="reset-filters-btn"><i class="fas fa-sync-alt me-1"></i> Reset</button>
                </div>
            </div>
        </div>

        <div class="card-body bg-light">
            <div class="row text-center">
                <div class="col-md-4">
                    <div class="stat-card p-3">
                        <h6 class="text-muted mb-1">Total Deleted Amount (Filtered)</h6>
                        <h4 class="fw-bold mb-0" id="summary-total-amount">₹0.00</h4>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card p-3">
                        <h6 class="text-muted mb-1">Deleted Records (Filtered)</h6>
                        <h4 class="fw-bold mb-0" id="summary-total-records">0</h4>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card p-3">
                        <h6 class="text-muted mb-1">Affected Students (Filtered)</h6>
                        <h4 class="fw-bold mb-0" id="summary-total-students">0</h4>
                    </div>
                </div>
            </div>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Image</th>
                            <th>Deleted At</th>
                            <th>Type</th>
                            <th>Student</th>
                            <th>Class</th>
                            <th>Father</th>
                            <th>Amount</th>
                            <th>Payment Date</th>
                            <th>Received By</th>
                            <th>Deleted By</th>
                            <th>Remark</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody id="deleted-log-body">
                    </tbody>
                </table>
            </div>

            <div id="pagination-container" class="mt-4 d-flex justify-content-center">
            </div>
        </div>
    </div>
</div>

<!-- Deleted payment details modal -->
<div class="modal fade" id="log-details-modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content rounded-4">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title"><i class="fas fa-file-invoice-dollar me-2"></i> Deleted Payment Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="log-details-body">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
    // Global state to keep track of current page and filters
    let currentPage = 1;
    let searchTimeout = null;

    // Keeps the currently rendered rows so the details modal can read them
    let loadedLogs = {};

    $(document).ready(function() {
        // Initialize Flatpickr for date range selection
        const datePicker = flatpickr("#date-range-picker", {
            mode: "range",
            dateFormat: "Y-m-d",
            onClose: function(selectedDates, dateStr, instance) {
                if (selectedDates.length === 2) {
                    fetchLogs(1); // Reset to page 1 on date range change
                }
            }
        });

        // Initial data load
        fetchLogs(currentPage);

        // Verify security pin before accessing the page
        <?php
        if ($schoolSettings['need_security_pin_for_payment_entry'] == 1) {
            echo "verifySecurityPin();";
        }
        ?>

        // --- Event Listeners ---

        // Search input with debounce to avoid excessive AJAX calls
        $('#search-input').on('keyup', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                fetchLogs(1); // Reset to page 1 on new search
            }, 500); // 500ms delay
        });

        // Filter by admin who deleted the payment
        $('#admin-filter').on('change', function() {
            fetchLogs(1);
        });

        // Filter by payment type
        $('#payment-type-filter').on('change', function() {
            fetchLogs(1);
        });

        // Reset filters button
        $('#reset-filters-btn').on('click', function() {
            // 1. Clear standard inputs
            $('#search-input').val('');
            $('#payment-type-filter').val('');
            datePicker.clear();

            // 2. Reset the underlying select tag
            $('#admin-filter').val('');

            // 3. Safely reset the Multiselect UI
            $('.custom-multiselect').multiselect('deselectAll', false);
            $('.custom-multiselect').multiselect('updateButtonText');

            // 4. Clear the search bar inside the dropdown manually
            $('.multiselect-search').val('').trigger('keydown');

            // 5. Fetch fresh data
            fetchLogs(1);
        });

        // Pagination click handler (using event delegation)
        $('#pagination-container').on('click', 'a.page-link', function(e) {
            e.preventDefault();
            const page = $(this).data('page');
            if (page) {
                fetchLogs(page);
            }
        });

        // Focus on search input when pressed CTRL+ /
        $(document).on('keydown', function(e) {
            if (e.ctrlKey && e.key === '/') {
                $('#search-input').focus();
                $('#search-input').select();
            }
        });
    });

    function fetchLogs(page) {
        currentPage = page;
        const searchQuery = $('#search-input').val();
        const dateRange = $('#date-range-picker').val().split(' to ');
        const startDate = dateRange[0] || '';
        const endDate = dateRange[1] || '';
        const adminId = $('#admin-filter').val();
        const paymentType = $('#payment-type-filter').val();

        // Show a loading state in the table
        $('#deleted-log-body').html('<tr><td colspan="12" class="text-center py-5"><div class="spinner-border text-danger" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        $.ajax({
            url: "<?= BASE_URL ?>/api/admin/get/fees-x-payments/get-deleted-payment-logs.php",
            type: "GET",
            data: {
                page: currentPage,
                search: searchQuery,
                startDate: startDate,
                endDate: endDate,
                adminId: adminId,
                paymentType: paymentType
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    renderTable(response.logs);
                    renderPagination(response.pagination);
                    renderSummary(response.summary);
                } else {
                    showErrorAlert(response.message || 'Could not fetch data.');
                    $('#deleted-log-body').html('<tr><td colspan="12" class="text-center py-4">Error loading data. Please try again.</td></tr>');
                }
            },
            error: function(e) {
                showErrorAlert("An unknown error occured. Please try again.");
                $('#deleted-log-body').html('<tr><td colspan="12" class="text-center py-4 text-danger">Error loading data. Please try again.</td></tr>');
                console.error(e);
                sendErrorReport(e.responseText);
            }
        });
    }

    function renderTable(logs) {
        const tableBody = $('#deleted-log-body');
        tableBody.empty();
        loadedLogs = {};

        if (logs.length === 0) {
            tableBody.html(`
                <tr>
                    <td colspan="12" class="text-center py-4">
                        <i class="fas fa-info-circle fa-2x text-muted mb-3"></i>
                        <h5>No deleted payment records found</h5>
                        <p class="text-muted">Try adjusting your search or date filters.</p>
                    </td>
                </tr>
            `);
            return;
        }

        logs.forEach(log => {
            loadedLogs[log.id] = log;

            const deletedAt = formatDateTimeCell(log.deleted_at);
            const paymentDate = log.payment_date ? new Date(log.payment_date).toLocaleDateString('en-GB', {
                day: 'numeric',
                month: 'short',
                year: 'numeric'
            }) : '-';

            // Student details come from the students table join. They will be
            // empty if the student has since been removed from the system.
            const studentExists = log.student_name !== null && log.student_name !== undefined;
            const studentImage = log.student_image || 'default_student_dp.jpg';
            const studentName = studentExists ? log.student_name : 'Student Removed';
            const typeBadge = log.payment_type === 'admission' ?
                '<span class="badge bg-primary">Admission</span>' :
                '<span class="badge bg-info text-dark">Monthly</span>';

            const studentCell = studentExists ?
                `<a href="<?= BASE_URL ?>/parent/dashboard/student-details.php?student_id=${log.student_id}" class="text-decoration-none" target="_blank">${escapeHtml(studentName)}</a>` :
                `<span class="text-muted fst-italic">${escapeHtml(studentName)}</span>`;

            const row = `
                <tr id="log-row-${log.id}">
                    <td>
                        <img src="<?= BASE_URL ?>/uploads/students/${studentImage}" alt="${escapeHtml(studentName)}" class="img-fluid rounded-circle border" data-fancybox data-caption="${escapeHtml(studentName)}" style="width: 50px; height: 50px; object-fit: cover; cursor: pointer;">
                    </td>
                    <td>${deletedAt}</td>
                    <td>${typeBadge}</td>
                    <td>
                        ${studentCell}
                        <small class="text-muted d-block small-text">ID: ${log.student_id ?? ''}</small>
                        <small class="text-muted d-block small-text">Reg: ${log.registration_no ?? ''}</small>
                    </td>
                    <td>
                        ${escapeHtml(log.class_name ?? '')} ${log.section_name ? '- ' + escapeHtml(log.section_name) : ''}
                        <small class="text-muted d-block small-text">Roll: ${log.roll_no ?? ''}</small>
                    </td>
                    <td>
                        ${escapeHtml(log.father_name ?? '')}
                        ${log.phone_number ? `<a href="tel:${log.phone_number}" class="text-decoration-none d-block small-text">+91${log.phone_number}</a>` : ''}
                    </td>
                    <td><span class="badge bg-danger">₹${parseFloat(log.payment_amount ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span></td>
                    <td>${paymentDate}</td>
                    <td>${escapeHtml(log.payment_entry_by_name ?? 'Unknown')}</td>
                    <td>${escapeHtml(log.deleted_by_name ?? 'Unknown')}</td>
                    <td title="${escapeHtml(log.payment_remark ?? '')}" width="20%">${renderRemarkCell(log.payment_remark)}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-dark" onclick="showLogDetails(${log.id})">
                            <i class="fas fa-eye me-1"></i> View
                        </button>
                    </td>
                </tr>
            `;
            tableBody.append(row);
        });
    }

    // Number of characters after which a remark is clamped with a "Show more" toggle
    const REMARK_TRUNCATE_LENGTH = 70;

    // Builds the remark cell, clamped to 2 lines when the text is long
    function renderRemarkCell(remark) {
        const text = remark ?? '';
        if (!text) return '';

        const isLong = text.length > REMARK_TRUNCATE_LENGTH;

        return `
            <div class="remark-cell">
                <span class="remark-text ${isLong ? 'collapsed' : ''}">${escapeHtml(text)}</span>
                ${isLong ? `<a class="remark-toggle d-inline-block mt-1" onclick="toggleRemark(this)"><i class="fas fa-chevron-down me-1"></i>Show more</a>` : ''}
            </div>
        `;
    }

    // Expands / collapses a clamped remark
    function toggleRemark(toggle) {
        const text = $(toggle).closest('.remark-cell').find('.remark-text');
        const isCollapsed = text.hasClass('collapsed');

        text.toggleClass('collapsed', !isCollapsed);
        $(toggle).html(isCollapsed ?
            '<i class="fas fa-chevron-up me-1"></i>Show less' :
            '<i class="fas fa-chevron-down me-1"></i>Show more');
    }

    // Renders the full snapshot of a deleted payment inside the modal
    function showLogDetails(logId) {
        const log = loadedLogs[logId];
        if (!log) return;

        let snapshotHtml = '';
        if (log.payment_snapshot) {
            try {
                snapshotHtml = JSON.stringify(JSON.parse(log.payment_snapshot), null, 2);
            } catch (e) {
                snapshotHtml = log.payment_snapshot;
            }
        }

        const rows = [
            ['Payment Type', log.payment_type === 'admission' ? 'Admission Fees' : 'Monthly Fees'],
            ['Original Payment ID', log.original_payment_id ?? '-'],
            ['Student', (log.student_name ?? 'Student Removed') + ' (' + (log.student_id ?? '-') + ')'],
            ['Registration No', log.registration_no ?? '-'],
            ['Class / Section', (log.class_name ?? '-') + (log.section_name ? ' - ' + log.section_name : '')],
            ['Roll No', log.roll_no ?? '-'],
            ['Father', log.father_name ?? '-'],
            ['Phone', log.phone_number ?? '-'],
            ['Amount', '₹' + parseFloat(log.payment_amount ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })],
            ['Payment Date', log.payment_date ?? '-'],
            ['Method', log.method ?? '-'],
            ['Wallet Affected Balance', '₹' + parseFloat(log.wallet_affected_balance ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })],
            ['Wallet Transaction ID', log.wallet_transaction_id ?? '-'],
            ['Remark', log.payment_remark ?? '-'],
            ['Received By', log.payment_entry_by_name ?? 'Unknown'],
            ['Payment Recorded At', log.payment_recorded_at ? formatDateTime(log.payment_recorded_at) : '-'],
            ['Deleted By', log.deleted_by_name ?? 'Unknown'],
            ['Deleted At', formatDateTime(log.deleted_at)]
        ];

        let html = '<div class="table-responsive"><table class="table table-sm table-striped mb-0">';
        rows.forEach(([label, value]) => {
            html += `<tr><th style="width: 40%">${label}</th><td>${escapeHtml(String(value))}</td></tr>`;
        });
        html += '</table></div>';

        if (snapshotHtml) {
            html += `
                <div class="mt-3">
                    <h6 class="fw-bold"><i class="fas fa-database me-1"></i> Raw Deleted Record</h6>
                    <pre class="bg-light border rounded p-2 small" style="max-height: 300px; overflow: auto;">${escapeHtml(snapshotHtml)}</pre>
                </div>
            `;
        }

        $('#log-details-body').html(html);
        new bootstrap.Modal(document.getElementById('log-details-modal')).show();
    }

    // Formats a MySQL datetime string into a readable "22 Aug 2026, 14:30"
    function formatDateTime(value) {
        if (!value) return '-';
        const parsed = new Date(String(value).replace(' ', 'T'));
        if (isNaN(parsed.getTime())) return value;
        return parsed.toLocaleDateString('en-GB', {
            day: 'numeric',
            month: 'short',
            year: 'numeric'
        }) + ', ' + parsed.toLocaleTimeString('en-GB', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    // Same value as formatDateTime() but split into two lines for table cells
    function formatDateTimeCell(value) {
        if (!value) return '-';
        const parsed = new Date(String(value).replace(' ', 'T'));
        if (isNaN(parsed.getTime())) return escapeHtml(value);
        return escapeHtml(parsed.toLocaleDateString('en-GB', {
            day: 'numeric',
            month: 'short',
            year: 'numeric'
        })) + '<br><small class="text-muted small-text">' + escapeHtml(parsed.toLocaleTimeString('en-GB', {
            hour: '2-digit',
            minute: '2-digit'
        })) + '</small>';
    }

    function renderSummary(summary) {
        const totalAmount = parseFloat(summary.totalAmount ?? 0).toLocaleString('en-IN', {
            style: 'currency',
            currency: 'INR'
        });
        $('#summary-total-amount').text(totalAmount);
        $('#summary-total-records').text(summary.totalRecords ?? 0);
        $('#summary-total-students').text(summary.totalStudents ?? 0);
    }

    function renderPagination(pagination) {
        const {
            currentPage,
            totalPages
        } = pagination;
        const paginationContainer = $('#pagination-container');
        paginationContainer.empty();

        if (totalPages <= 1) return;

        let paginationHtml = '<nav aria-label="Page navigation"><ul class="pagination">';

        // First & Previous
        if (currentPage > 1) {
            paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="1" aria-label="First">&laquo;&laquo;</a></li>`;
            paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage - 1}" aria-label="Previous">&laquo;</a></li>`;
        } else {
            paginationHtml += `<li class="page-item disabled"><span class="page-link">&laquo;&laquo;</span></li>`;
            paginationHtml += `<li class="page-item disabled"><span class="page-link">&laquo;</span></li>`;
        }

        // Numeric Pages
        const startPage = Math.max(1, currentPage - 2);
        const endPage = Math.min(totalPages, currentPage + 2);
        for (let i = startPage; i <= endPage; i++) {
            paginationHtml += `<li class="page-item ${i === currentPage ? 'active' : ''}"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
        }

        // Next & Last
        if (currentPage < totalPages) {
            paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage + 1}" aria-label="Next">&raquo;</a></li>`;
            paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${totalPages}" aria-label="Last">&raquo;&raquo;</a></li>`;
        } else {
            paginationHtml += `<li class="page-item disabled"><span class="page-link">&raquo;</span></li>`;
            paginationHtml += `<li class="page-item disabled"><span class="page-link">&raquo;&raquo;</span></li>`;
        }

        paginationHtml += '</ul></nav>';
        paginationContainer.html(paginationHtml);
    }

    // Function verify security pin
    function verifySecurityPin() {
        Swal.fire({
            title: 'Enter Security Pin',
            input: 'text',
            inputAttributes: {
                autocapitalize: 'off',
                autofocus: 'true',
                autocomplete: 'one-time-code',
                name: 'my-unique-pin-field',
                style: '-webkit-text-security: disc;'
            },
            showCancelButton: false,
            confirmButtonText: 'Verify & Continue',
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: true,
            showLoaderOnConfirm: true,
            preConfirm: (inputPin) => {
                if (inputPin === '<?= $security_pin ?>') {
                    return true;
                } else {
                    toastr.error('Invalid security pin. Please try again.');
                    return false;
                }
            },
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-primary px-4 py-2',
                cancelButton: 'btn btn-danger px-4 py-2'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.close();
                toastr.success('Security pin verified.');
            }
        });
    }
</script>

<?php include_once("../../includes/body-close.php"); ?>
