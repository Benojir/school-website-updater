<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Admission Fees Management - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if (!isSuperAdmin()) {
    include_once("../../includes/permission-denied.php");
}

// Fetch all classes for filter dropdown
$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container py-4">

    <!-- Add Fees Card -->
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fa-solid fa-money-check-dollar"></i> Add Admission Fees</h3>
            </div>
        </div>

        <div class="card-body p-4 p-md-5">
            <form id="addAdmissionFeeForm" method="POST">
                <div class="row g-3">

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="admission_type" class="form-label fw-bold">Admission Type</label>
                            <select name="admission_type" id="admission_type" class="form-select" onchange="loadAdmissionFees()" required>
                                <option value="" selected disabled>Select Admission Type</option>
                                <option value="new-admission">New Admission</option>
                                <option value="re-admission">Re-Admission</option>
                            </select>
                            <div class="form-text">Select the admission type for admission fees type</div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="class_id" class="form-label fw-bold">Class</label>
                            <select name="class_id" id="class_id" class="form-select select2" required>
                                <option value="" selected disabled>Select Class</option>
                                <?php foreach ($classes as $class): ?>
                                    <option value="<?= safe_htmlspecialchars($class['id']) ?>">
                                        <?= safe_htmlspecialchars($class['class_name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text">Select the class for the fees</div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="feeInput" class="form-label fw-bold">Amount</label>
                            <input type="number" id="feeInput" name="amount" placeholder="Enter amount for fee" class="form-control" required />
                            <div class="form-text">Amount for the fees</div>
                        </div>
                    </div>
                </div>

                <div class="text-center mt-4">
                    <button type="submit" id="submitBtn" class="btn btn-primary px-4">
                        <i class="fas fa-save me-2"></i> Save Admission Fee
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Fees Card -->
    <div class="card shadow-lg mt-5">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fa-solid fa-money-bill-wave"></i> Manage Admission Fees</h3>
            </div>
        </div>

        <div class="card-body">
            <!-- Search and Filter Section -->
            <div class="row mb-4">
                <div class="col-md-12">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-search"></i></span>
                                <input type="text" id="searchInput" class="form-control"
                                    placeholder="Search by amount or class name">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <select id="classFilter" class="form-select">
                                <option value="">All Classes</option>
                                <?php foreach ($classes as $class): ?>
                                    <option value="<?= $class['id'] ?>"><?= safe_htmlspecialchars($class['class_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button id="resetFilters" class="btn btn-outline-secondary w-100">
                                <i class="fas fa-undo me-1"></i> Reset
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Class Fee Management Table -->
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th width="5%">#</th>
                            <th>Class Name</th>
                            <th>Amount</th>
                            <th width="15%" class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="feesTableBody">
                        <!-- AJAX will load content here -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    // Load class wise fees with AJAX
    function loadAdmissionFees(searchInput = '', classId = '', addmissionTypeFilter = '') {

        let admissionType = $('#admission_type').val();

        if(addmissionTypeFilter) {
            admissionType = addmissionTypeFilter;
        }

        $.ajax({
            url: '../../api/admin/get/fees-x-payments/get-admission-fees-class-wise.php',
            type: 'GET',
            data: {
                search: searchInput,
                class_id: classId,
                admission_type: admissionType
            },
            dataType: 'json',
            beforeSend: function() {
                $('#feesTableBody').html(`
                    <tr>
                        <td colspan="5" class="text-center py-4">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </td>
                    </tr>
                `);
            },
            success: function(response) {
                if (response.amounts.length > 0) {
                    let html = '';
                    response.amounts.forEach((amount, index) => {
                        html += `
                            <tr id="tableAdmissionFeeRow-${amount.id}">
                                <td>${index + 1}</td>
                                <td>${escapeHtml(amount.class_name)}</td>
                                <td>
                                    <span class="badge bg-success">
                                        <?= $websiteConfig['currency_symbol'] ?> ${escapeHtml(amount.amount)}
                                    </span>
                                </td>
                                <td class="text-end">
                                    <button class="btn btn-sm btn-outline-danger delete-btn" data-id="${amount.id}" data-name="${escapeHtml(amount.class_name)}">
                                        <i class="fas fa-trash-alt me-1"></i> Delete
                                    </button>
                                </td>
                            </tr>
                        `;
                    });
                    $('#feesTableBody').html(html);
                } else {
                    $('#feesTableBody').html(`
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">
                                <i class="fas fa-book-open fa-3x mb-3"></i>
                                <h4>No fees found</h4>
                                <p>Try adjusting your search filters</p>
                            </td>
                        </tr>
                    `);
                }
            },
            error: function() {
                toastr.error('Failed to load class fees. Please try again.');
            }
        });
    }

    $(document).ready(function() {
        // Initial load
        loadAdmissionFees();

        // Search input handler with debounce
        let searchTimer;
        $('#searchInput').on('input', function() {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => {
                let searchInputText = $(this).val();
                let classId = $('#classFilter').val();
                loadAdmissionFees(searchInputText, classId);
            }, 500);
        });

        // Filter change handlers
        $('#classFilter').change(function() {
            let searchInputText = $('#searchInput').val();
            let classId = $('#classFilter').val();
            loadAdmissionFees(searchInputText, classId);
        });

        // Reset filters
        $('#resetFilters').click(function() {
            $('#searchInput').val('');
            $('#classFilter').val('');
            loadAdmissionFees();
        });

        // Delete admission fee with SweetAlert confirmation
        $(document).on('click', '.delete-btn', function() {
            const amountID = $(this).data('id');
            const className = $(this).data('name');
            const tableAdmissionFeeRow = $('#tableAdmissionFeeRow-' + amountID);
            const admissionType = $('#admission_type').val();

            Swal.fire({
                title: 'Delete Admission Fee',
                html: `Are you sure you want to delete class <strong>${className}</strong> admission fee from ${admissionType} fees?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '../../api/admin/delete/fees-x-payments/delete-class-wise-admission-fee.php',
                        type: 'POST',
                        data: {
                            id: amountID,
                            admission_type: admissionType
                        },
                        dataType: 'json',
                        beforeSend: function() {
                            tableAdmissionFeeRow.find('.delete-btn').html('<span class="spinner-border spinner-border-sm me-1"></span> Deleting');
                        },
                        success: function(response) {
                            if (response.success) {
                                toastr.success(response.message);
                                // Reload current page after delete
                                loadAdmissionFees(
                                    $('#searchInput').val(),
                                    $('#classFilter').val(),
                                    $('#typeFilter').val()
                                );
                            } else {
                                toastr.error(response.message);
                                tableAdmissionFeeRow.find('.delete-btn').html('<i class="fas fa-trash-alt me-1"></i> Delete');
                            }
                        },
                        error: function() {
                            toastr.error('An error occurred. Please try again.');
                            tableAdmissionFeeRow.find('.delete-btn').html('<i class="fas fa-trash-alt me-1"></i> Delete');
                        }
                    });
                }
            });
        });

        // Add Admission Fee JS
        // AJAX form submission
        $('#addAdmissionFeeForm').submit(function(e) {
            e.preventDefault();
            const formData = $(this).serialize();
            const submitBtn = $('#submitBtn');

            // Change button state
            submitBtn.prop('disabled', true).html(
                '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Saving...'
            );

            $.ajax({
                url: '../../api/admin/put/fees-x-payments/save-class-wise-admission-fee.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        // Reset input fields except admission type on success
                        $('#class_id').val('');
                        $('#feeInput').val('');
                    } else {
                        toastr.error(response.message);
                    }
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i> Save Admission Fee');

                    loadAdmissionFees(
                        $('#searchInput').val(),
                        $('#classFilter').val(),
                        $('#typeFilter').val()
                    );
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred. Please try again.');
                    console.error(error);
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i> Save Admission Fee');
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>