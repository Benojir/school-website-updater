<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/header-open.php");
echo "<title>Additional School Fees - " . $school_name . "</title>";
require_once("../../includes/header-close.php");
require_once("../../includes/dashboard-navbar.php");

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    include_once("../../includes/permission-denied.php");
}

// Fetch all classes from database
$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container py-4">

    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fa-solid fa-money-check-dollar"></i> Add Additional Fees</h3>
            </div>
        </div>

        <div class="card-body p-4 p-md-5">
            <form id="addAdditionalFeeForm" method="POST" autocomplete="on">
                <div class="row g-3">

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="class_id" class="form-label fw-bold">Class</label>
                            <select name="class_id" id="class_id" class="form-select select2" required>
                                <option value="" selected disabled>Select Class</option>
                                <?php foreach ($classes as $class): ?>
                                    <option value="<?= safe_htmlspecialchars($class['id']) ?>">
                                        <?= safe_htmlspecialchars($class['class_name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text">Select the class for the fees</div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="fee_type" class="form-label fw-bold">Fees Type</label>
                            <input type="text" id="fee_type" name="fee_type" placeholder="eg: Admit Card Fee" class="form-control" required />
                            <div class="form-text">Enter the fee name (Eg: Marksheet Fee, Electric Fee)</div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="subject_type" class="form-label fw-bold">Amount</label>
                            <input type="number" id="feeInput" name="amount" placeholder="Enter amount for fee" class="form-control" required />
                            <div class="form-text">Amount for the fees</div>
                        </div>
                    </div>
                </div>

                <div class="text-center mt-4">
                    <button type="submit" id="submitBtn" class="btn btn-primary px-4">
                        <i class="fas fa-save me-2"></i> Save Fee
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- View Fees Card -->
    <div class="card shadow-lg mt-5">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fa-solid fa-money-bill-wave"></i> Manage Fees</h3>
            </div>
        </div>

        <div class="card-body">
            <!-- Search and Filter Section -->
            <div class="row mb-4">
                <div class="col-md-12">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-search"></i></span>
                                <input type="text" id="searchInput" class="form-control"
                                    placeholder="Search by amount or class name">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <select id="classFilter" class="form-select">
                                <option value="">All Classes</option>
                                <?php foreach ($classes as $class): ?>
                                    <option value="<?= $class['id'] ?>"><?= safe_htmlspecialchars($class['class_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button id="resetFilters" class="btn btn-outline-secondary w-100">
                                <i class="fas fa-undo me-1"></i> Reset
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Class Fee Management Table -->
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th width="5%">#</th>
                            <th>Class Name</th>
                            <th>Fee Type</th>
                            <th>Amount</th>
                            <th width="15%" class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="feesTableBody">
                        <!-- AJAX will load content here -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Edit fee setup modal -->
<div class="modal fade" tabindex="-1" id="edit_fee_setup_modal" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content shadow-lg">
            <div class="modal-header bg-warning">
                <h5 class="modal-title" id="editModalLabel">Edit Fee</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="editAdditionalFeeForm" autocomplete="on">
                <div class="modal-body">
                    <p>Update the details for this fee. All fields are required.</p>

                    <input type="hidden" id="edit_fee_id" name="id" value="">

                    <div class="form-group mb-3">
                        <label for="edit_class_id" class="form-label fw-bold">Class</label>
                        <select name="class_id" id="edit_class_id" class="form-select" required>
                            <option value="" disabled>Select Class</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?= safe_htmlspecialchars($class['id']) ?>">
                                    <?= safe_htmlspecialchars($class['class_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group mb-3">
                        <label for="edit_fee_type" class="form-label fw-bold">Fees Type</label>
                        <input type="text" id="edit_fee_type" name="fee_type" placeholder="eg: Admit Card Fee" class="form-control" required />
                    </div>

                    <div class="form-group">
                        <label for="edit_amount" class="form-label fw-bold">Amount</label>
                        <input type="number" id="edit_amount" name="amount" placeholder="Enter amount for fee" class="form-control" required />
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i> Close
                    </button>
                    <button type="submit" class="btn btn-primary" id="saveEditBtn">
                        <i class="fas fa-save me-1"></i> Save Changes
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Load class wise fees with AJAX
    function loadAdditionalFees(searchInput = '', classId = '') {

        $.ajax({
            url: '../../api/admin/get/fees-x-payments/get-additional-fees-setup.php',
            type: 'GET',
            data: {
                search: searchInput,
                class_id: classId
            },
            dataType: 'json',
            beforeSend: function() {
                $('#feesTableBody').html(`
                    <tr>
                        <td colspan="5" class="text-center py-4">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </td>
                    </tr>
                `);
            },
            success: function(response) {
                if (response.amounts.length > 0) {
                    let html = '';
                    response.amounts.forEach((amount, index) => {
                        html += `
                            <tr id="tableAdditionalFeeRow-${amount.id}">
                                <td>${index + 1}</td>
                                <td>${escapeHtml(amount.class_name)}</td>
                                <td>${escapeHtml(amount.fee_type)}</td>
                                <td>
                                    <span class="badge bg-success">
                                        <?= $websiteConfig['currency_symbol'] ?> ${escapeHtml(amount.amount)}
                                    </span>
                                </td>
                                <td class="text-end">
                                    <button class="btn btn-sm btn-outline-danger delete-btn" data-id="${amount.id}" data-class-name="${escapeHtml(amount.class_name)}" data-fee-type="${escapeHtml(amount.fee_type)}">
                                        <i class="fas fa-trash-alt me-1"></i> Delete
                                    </button>
                                    <button class="btn btn-sm btn-warning edit-btn" 
                                        data-id="${amount.id}" 
                                        data-class-id="${amount.class_id}" 
                                        data-class-name="${escapeHtml(amount.class_name)}" 
                                        data-fee-type="${escapeHtml(amount.fee_type)}"
                                        data-amount="${amount.amount}">
                                        <i class="fas fa-pencil-alt me-1"></i> Edit
                                    </button>
                                </td>
                            </tr>
                        `;
                    });
                    $('#feesTableBody').html(html);
                } else {
                    $('#feesTableBody').html(`
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">
                                <i class="fas fa-money-bill-wave fa-3x mb-3"></i>
                                <h4>No fees found</h4>
                                <p>Try adjusting your search filters</p>
                            </td>
                        </tr>
                    `);
                }
            },
            error: function() {
                toastr.error('Failed to load class fees. Please try again.');
            }
        });
    }

    // Helper function to escape HTML
    function escapeHtml(unsafe) {
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    $(document).ready(function() {
        // Initial load
        loadAdditionalFees();

        // Search input handler with debounce
        let searchTimer;
        $('#searchInput').on('input', function() {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => {
                let searchInputText = $(this).val();
                let classId = $('#classFilter').val();
                loadAdditionalFees(searchInputText, classId);
            }, 500);
        });

        // Filter change handlers
        $('#classFilter').change(function() {
            let searchInputText = $('#searchInput').val();
            let classId = $('#classFilter').val();
            loadAdditionalFees(searchInputText, classId);
        });

        // Reset filters
        $('#resetFilters').click(function() {
            $('#searchInput').val('');
            $('#classFilter').val('');
            loadAdditionalFees();
        });

        // Use event delegation for dynamically loaded buttons
        $(document).on('click', '.edit-btn', function() {
            // 1. Get data from the button
            const feeId = $(this).data('id');
            const classId = $(this).data('class-id');
            const feeType = $(this).data('fee-type');
            const amount = $(this).data('amount');
            const className = $(this).data('class-name'); // For modal title

            // 2. Populate the modal form fields
            $('#edit_fee_id').val(feeId);
            $('#edit_class_id').val(classId).trigger('change'); // .trigger('change') is for select2
            $('#edit_fee_type').val(feeType);
            $('#edit_amount').val(amount);

            // 3. Update modal title
            $('#editModalLabel').html(`Edit Fee: <b>${escapeHtml(feeType)}</b> for <b>${escapeHtml(className)}</b>`);

            // 4. Show the modal
            var editModal = new bootstrap.Modal(document.getElementById('edit_fee_setup_modal'));
            editModal.show();
        });

        $('#editAdditionalFeeForm').submit(function(e) {
            e.preventDefault();
            const formData = $(this).serialize();
            const saveBtn = $('#saveEditBtn');

            saveBtn.prop('disabled', true).html(
                '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Saving...'
            );

            $.ajax({
                // NOTE: You will need to create this backend update script!
                url: '../../api/admin/put/fees-x-payments/update-additional-fee-setup.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        // Hide the modal
                        bootstrap.Modal.getInstance($('#edit_fee_setup_modal')).hide();
                        // Reload the table
                        loadAdditionalFees(
                            $('#searchInput').val(),
                            $('#classFilter').val()
                        );
                    } else {
                        toastr.error(response.message);
                    }
                    saveBtn.prop('disabled', false).html('<i class="fas fa-save me-1"></i> Save Changes');
                },
                error: function() {
                    toastr.error('An error occurred. Please try again.');
                    saveBtn.prop('disabled', false).html('<i class="fas fa-save me-1"></i> Save Changes');
                }
            });
        });

        // Delete fee with SweetAlert confirmation
        $(document).on('click', '.delete-btn', function() {
            const amountID = $(this).data('id');
            const className = $(this).data('class-name');
            const feeType = $(this).data('fee-type');
            const tableAdditionalFeeRow = $('#tableAdditionalFeeRow-' + amountID);

            Swal.fire({
                title: 'Delete Fee',
                html: `
                Are you sure you want to delete this fee? It will delete all the data related to it and you cannot revert it back. 
                <br>Class: <b>${className}</b> Type: <b>${feeType}</b>
                `,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '../../api/admin/delete/fees-x-payments/delete-additional-fee-setup.php',
                        type: 'POST',
                        data: {
                            id: amountID
                        },
                        dataType: 'json',
                        beforeSend: function() {
                            tableAdditionalFeeRow.find('.delete-btn').html('<span class="spinner-border spinner-border-sm me-1"></span> Deleting');
                        },
                        success: function(response) {
                            if (response.success) {
                                toastr.success(response.message);
                                // Reload current page after delete
                                loadAdditionalFees(
                                    $('#searchInput').val(),
                                    $('#classFilter').val()
                                );
                            } else {
                                toastr.error(response.message);
                                tableAdditionalFeeRow.find('.delete-btn').html('<i class="fas fa-trash-alt me-1"></i> Delete');
                            }
                        },
                        error: function(e) {
                            toastr.error('An error occurred. Please try again.');
                            tableAdditionalFeeRow.find('.delete-btn').html('<i class="fas fa-trash-alt me-1"></i> Delete');
                            console.log(e);
                        }
                    });
                }
            });
        });

        // Add Fee JS
        // AJAX form submission
        $('#addAdditionalFeeForm').submit(function(e) {
            e.preventDefault();
            const formData = $(this).serialize();
            const submitBtn = $('#submitBtn');

            // Change button state
            submitBtn.prop('disabled', true).html(
                '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Saving...'
            );

            $.ajax({
                url: '../../api/admin/put/fees-x-payments/save-class-wise-additional-fee.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        // Reset input fields except admission type on success
                        $('#class_id').val('');
                        $('#fee_type').val('');
                        $('#feeInput').val('');
                    } else {
                        toastr.error(response.message);
                    }
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i> Save Fee');

                    loadAdditionalFees(
                        $('#searchInput').val(),
                        $('#classFilter').val()
                    );
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred. Please try again.');
                    console.error(error);
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i> Save Fee');
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>