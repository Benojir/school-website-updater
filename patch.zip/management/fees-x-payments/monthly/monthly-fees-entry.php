<?php
include_once("../../../includes/auth-check.php");
require_once("../../../includes/header-open.php");
echo "<title>Monthly Fees Entry - " . $school_name . "</title>";
require_once("../../../includes/header-close.php");
require_once("../../../includes/dashboard-navbar.php");

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    include_once("../../../includes/permission-denied.php");
}

$student_ids_string = $_REQUEST['student_ids'] ?? '';
$student_ids = explode(',', $student_ids_string);

if (empty($student_ids_string) || count($student_ids) == 0) {
    echo "<div class='container mt-4'><div class='alert alert-danger'>No student IDs provided.</div></div>";
    include_once("../../../includes/body-close.php");
    exit();
}

// Fetch class-wise new admission fees
$stmt = $pdo->prepare("SELECT class_id, amount FROM class_wise_monthly_fees");
$stmt->execute();
$monthly_fees_setup = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

$filtered_student_ids = [];

?>
<style>
    .table-responsive {
        max-height: 500px;
        overflow-y: auto;
        scrollbar-width: thin;
        scrollbar-color: #888 #e0e0e0;
    }

    .table>thead {
        position: sticky;
    }

    .table>thead>tr>th {
        vertical-align: middle !important;
        text-align: center;
    }

    .table thead th {
        position: relative;
    }

    .table tbody td {
        vertical-align: middle !important;
        text-align: center;
    }

    .table tbody td img {
        border-radius: 5px;
        width: 50px;
        object-fit: cover;
        cursor: pointer;
        border: 1px solid #ddd;
    }
</style>

<div class="container mt-4">
    <div class="card shadow-sm mb-4">
        <div class="card-header d-flex justify-content-between align-items-center bg-primary text-white">
            <div>
                <h4 class="mb-0"><i class="fas fa-money-bill me-2"></i>Monthly Fees Entry</h4>
            </div>
            <div>
                <button type="button" class="btn btn-sm btn-light" onclick="history.back();">
                    <i class="fas fa-arrow-left me-2"></i>Go Back
                </button>
            </div>
        </div>
        <div class="card-body">
            <form id="monthlyFeesEntryForm">
                <div class="row mb-3">
                    <input type="hidden" id="student_ids" value="" name="student_ids" />
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Month:</label>
                        <select name="month_year[]" multiple size="10" class="form-control exclude-from-load feeMonthSelect custom-multiselect" required></select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Discount:</label>
                        <input type="number" name="discount" class="form-control">
                    </div>
                    <div class="col-md-12 d-flex justify-content-end">
                        <button id="submitBtn" class="btn btn-primary" type="submit">
                            <i class="fas fa-save me-2"></i>Submit Fees Entry
                        </button>
                    </div>
                </div>
            </form>
            <div class="mb-3">
                <h5 class="m-0 p-0">Total Students: <span id="total_students_fee_entry"></span></h5>
            </div>
            <div class="row mb-3">
                <div class="col-md-6 mb-2">
                    <input type="text" id="studentSearchBox" class="form-control" placeholder="Search students..." />
                </div>
                <div class="col-md-6 mb-2">
                    <select id="studentListSort" class="form-select">
                        <option value="name-asc" selected>Sort by Name (A-Z)</option>
                        <option value="name-desc">Sort by Name (Z-A)</option>
                    </select>
                </div>
            </div>

            <div class="table-responsive rounded-2">
                <table class="table table-bordered table-striped" id="studentListTable">
                    <thead class="table-dark">
                        <tr>
                            <th><i class="fas fa-user"></i></th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Class</th>
                            <th>Roll No.</th>
                            <th>Actual Fees</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($student_ids as $student_id):
                            $student_info = getStudentInfo($pdo, $student_id);
                            if (!$student_info) {
                                continue;
                            }

                            if (in_array($student_id, $filtered_student_ids)) {
                                continue;
                            }

                            $filtered_student_ids[] = $student_id;

                            $class_id = $student_info['class_id'];
                            $actual_amount = $monthly_fees_setup[$class_id] ?? 0;

                            // PREPARE DATA FOR SORTING
                            $sort_name = strtolower($student_info['name']);
                        ?>
                            <tr id="trow-<?= $student_id ?>"
                                class="student-row"
                                data-student-id="<?= $student_id ?>"
                                data-name="<?= safe_htmlspecialchars($sort_name) ?>">
                                <td>
                                    <button class="btn btn-sm btn-outline-primary more-details-btn" title="View More Details" data-student-id="<?= $student_id ?>">
                                        <i class="fas fa-plus-circle"></i>
                                    </button>
                                </td>
                                <td
                                    title="View Image"
                                    data-fancybox="student-images"
                                    data-caption="<?= $student_info['name'] ?>"
                                    data-src="<?= BASE_URL . "/uploads/students/" . $student_info['student_image']; ?>">
                                    <img
                                        src="<?= BASE_URL . "/uploads/students/" . $student_info['student_image']; ?>"
                                        alt="Img"
                                        loading="lazy" />
                                </td>
                                <td>
                                    <a tabindex="-1"
                                        class="text-decoration-none"
                                        href="<?= BASE_URL ?>/parent/dashboard/student-details.php?student_id=<?= $student_info['student_id'] ?>"
                                        target="_blank">
                                        <?php echo safe_htmlspecialchars($student_info['name']); ?>
                                    </a>
                                    <br>
                                    <small class="text-muted" style="font-size: 0.8rem;"><?= $student_info['student_id'] ?></small>
                                </td>
                                <td><?= $student_info['class_name'] . ' (' . $student_info['section_name'] . ')' ?></td>
                                <td><?= $student_info['roll_no']; ?></td>
                                <td>
                                    <span id="actual-amount-<?= $student_id ?>" class="text-success fw-bold">
                                        <?php echo $currency_symbol . $actual_amount; ?>
                                    </span>
                                </td>
                                <td>
                                    <button
                                        data-student-id="<?php echo $student_info['student_id']; ?>"
                                        tabindex="-1"
                                        title="Remove student from list"
                                        class="btn btn-sm btn-danger remove-student-btn">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- <div class="text-end mt-3">
                <button id="submitBtn" class="btn btn-primary" tabindex="-1">
                    <i class="fas fa-check-circle me-2"></i>Submit Fees Entry
                </button>
            </div> -->
        </div>
    </div>
</div>

<!-- Include the modal html -->
<?php include_once('../../../includes/modals/fees-x-payments/financial-details-modal.php'); ?>

<script>
    let filteredStudentIDs = <?= json_encode($filtered_student_ids); ?>;
    const monthly_fees_setup = <?= json_encode($monthly_fees_setup); ?>;
    let financialDataLoaded = [];

    $(document).ready(function() {

        // Initial calls
        sortStudentRows();
        populateMonthSelection();

        // Fill total students count
        $('#total_students_fee_entry').text(filteredStudentIDs.length);

        // Remove student from the list
        $('.remove-student-btn').click(function() {
            const studentID = $(this).data('student-id');
            $(`#trow-${studentID}`).remove();
            filteredStudentIDs = filteredStudentIDs.filter(id => id !== studentID);
            $('#total_students_fee_entry').text(filteredStudentIDs.length);
        });

        // Search functionality
        $('#studentSearchBox').on('keyup', function() {
            var value = $(this).val().toLowerCase();
            $("#studentListTable tbody tr").filter(function() {
                // Toggle visibility based on whether the row text contains the search term
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });

        // Sorting functionality
        $('#studentListSort').change(function() {
            sortStudentRows();
        });

        // Form submission
        $('#monthlyFeesEntryForm').submit(function(e) {
            e.preventDefault();

            const selectedStudentIds = filteredStudentIDs;

            if (selectedStudentIds.length === 0) {
                showWarningAlert('No students selected for fees entry.');
                return;
            }

            $('#student_ids').val(selectedStudentIds.join(','));

            const $form = $(this);
            const $btn = $form.find('[type="submit"]');
            const btnText = $btn.html();

            // Show loading state
            $btn.prop('disabled', true).html(
                '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...'
            );

            // Build form data manually
            let formData = $form.serializeArray();

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/put/fees-x-payments/process-fees-entry-monthly.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Show summary success message
                        toastr.success(response.message);

                        // Show detailed results in a modal or console
                        if (response.results && response.results.length > 0) {
                            let successCount = 0;
                            let skippedCount = 0;
                            let html = '<div class="bulk-results-container">';

                            response.results.forEach(result => {
                                if (result.success) {
                                    successCount++;
                                    html += `
                                        <div class="alert alert-success mb-2">
                                            <strong>${result.student_id}</strong>: ${result.message} 
                                            (Amount: ${result.amount || 'N/A'})
                                        </div>
                                    `;
                                } else {
                                    skippedCount++;
                                    html += `
                                        <div class="alert alert-warning mb-2">
                                            <strong>${result.student_id}</strong>: ${result.message}
                                        </div>
                                    `;
                                }
                            });

                            html += '</div>';

                            let finalHtml = `<div class="text-left">
                                            <p><strong>Summary:</strong> ${response.message}</p>
                                            <p>Successfully processed: ${successCount}</p>
                                            <p>Skipped: ${skippedCount}</p>
                                            <div class="mt-3" style="max-height: 300px; overflow-y: auto;">
                                                ${html}
                                            </div>
                                        </div>`;

                            showInfoAlert(finalHtml, 'Detailed Results');
                        }
                    } else {
                        showErrorAlert(response.message);
                    }
                },
                error: function(e) {
                    console.error(e.responseText);
                    showErrorAlert('An error occurred while processing the request.');
                },
                complete: function() {
                    $btn.prop('disabled', false).html(btnText);
                }
            });
        });

        // --- 3. Show Student Financial Details in Modal ---
        $('.more-details-btn').on('click', function() {
            const studentId = $(this).data('student-id');
            const studentName = capitalize($(this).closest('tr').data('name'));

            $('#studentFinancialDetailsModalLabel').html(`Financial Details: <b>${studentName}</b>`);

            if (financialDataLoaded[studentId]) {
                $('#studentFinancialDetailsModalBody').html(financialDataLoaded[studentId]);
                $('#studentFinancialDetailsModal').modal('show');
                return;
            }

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/get/fees-x-payments/monthly/get-student-financial-overview.php',
                type: 'POST',
                data: {
                    student_id: studentId
                },
                dataType: 'json',
                beforeSend: function() {
                    showLoadingAlert('Fetching student financial details...');
                },
                success: function(response) {
                    Swal.close();
                    if (response.success) {
                        const unpaidFeesTable = response.unpaid_fees_table;
                        const paidFeesTable = response.paid_fees_table;
                        const fullHtml = unpaidFeesTable + paidFeesTable;

                        $('#studentFinancialDetailsModalBody').html(fullHtml);
                        $('#studentFinancialDetailsModal').modal('show');

                        if (!financialDataLoaded[studentId]) {
                            financialDataLoaded[studentId] = fullHtml;
                        }
                    } else {
                        showErrorAlert(response.message);
                    }
                },
                error: function(xhr) {
                    console.error(xhr.responseText);
                    showErrorAlert('Error fetching student financial details');
                }
            });
        });
    });

    // Function to sort student rows
    function sortStudentRows() {
        var sortBy = $('#studentListSort').val();
        var rows = $('#studentListTable tbody tr').get();

        rows.sort(function(a, b) {
            var nameA = $(a).data('name');
            var nameB = $(b).data('name');

            if (sortBy === 'name-asc') {
                return nameA.localeCompare(nameB);
            } else if (sortBy === 'name-desc') {
                return nameB.localeCompare(nameA);
            }
        });

        $.each(rows, function(index, row) {
            $('#studentListTable tbody').append(row);
        });
    }

    // Populate month-year selection
    function populateMonthSelection() {

        const now = new Date();
        const totalMonths = 12; // 12 months back and 12 months forward
        // Clear existing options first to prevent duplicates if called multiple times
        $('.feeMonthSelect').empty();

        for (let i = totalMonths; i >= -totalMonths; i--) {
            const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
            const month = date.toLocaleString('default', {
                month: 'long'
            });
            const year = date.getFullYear();
            const value = `${month} ${year}`;

            $('.feeMonthSelect').each(function() {
                const option = document.createElement('option');
                option.value = value;
                option.textContent = value;

                // Set selected if it's the current month and year
                if (date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear()) {
                    option.selected = true;
                }

                $(this).append(option);
            });
        }
    }
</script>

<?php include_once("../../../includes/body-close.php"); ?>