<?php
// -----------------------------------------------------------------------//
//              THIS PAGE IS FOR MONTHLY FEES PAYMENTS ENTRY              //
// -----------------------------------------------------------------------//

include_once("../../../includes/auth-check.php");
require_once("../../../includes/header-open.php");
echo "<title>Monthly Payments Entry - " . $school_name . "</title>";
require_once("../../../includes/header-close.php");
require_once("../../../includes/dashboard-navbar.php");

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    include_once("../../../includes/permission-denied.php");
}

$student_ids_string = $_REQUEST['student_ids'] ?? '';
$student_ids = explode(',', $student_ids_string);

if (empty($student_ids_string) || count($student_ids) == 0) {
    echo "<div class='container mt-4'><div class='alert alert-danger'>No student IDs provided.</div></div>";
    include_once("../../../includes/body-close.php");
    exit();
}

$filtered_student_ids = [];
?>
<style>
    .table>thead>tr>th {
        vertical-align: middle !important;
        text-align: center;
    }

    .table thead th {
        position: relative;
    }

    .table tbody td {
        vertical-align: middle !important;
        text-align: center;
    }

    .table tbody td img {
        border-radius: 5px;
        width: 50px;
        object-fit: cover;
        cursor: pointer;
        border: 1px solid #ddd;
    }
</style>

<div class="container mt-4">

    <div class="card shadow-sm mb-4">
        <div class="card-header d-flex justify-content-between align-items-center bg-primary text-white">
            <div>
                <h4 class="mb-0"><i class="fas fa-money-bill me-2"></i>Monthly Payments Entry</h4>
            </div>
            <div>
                <button type="button" class="btn btn-sm btn-light" onclick="history.back();">
                    <i class="fas fa-arrow-left me-2"></i>Go Back
                </button>
            </div>
        </div>
        <div class="card-body">
            <form id="paymentsEntryForm" autocomplete="off">
                <input type="hidden" name="student_ids" value="" id="student_ids_input">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="fee_amount" class="form-label">Amount:</label>
                        <input type="number" id="fee_amount" name="amount" class="form-control" placeholder="Enter the payment amount" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="payment_date" class="form-label">Payment Date:</label>
                        <input type="date" id="payment_date" name="payment_date" class="form-control" required>
                    </div>
                </div>

                <div class="mt-3 mb-2 d-flex justify-content-end">
                    <button type="submit" class="btn btn-primary">Save Payments Entry</button>
                </div>
            </form>

            <div class="my-3">
                <div class="mb-3">
                    <h5>Total Students: <span id="total_students_payment_entry"></span></h5>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6 mb-2">
                        <input type="text" id="studentSearchBox" class="form-control" placeholder="Search students..." />
                    </div>
                    <div class="col-md-6">
                        <select id="studentListSort" class="form-select">
                            <option value="name-asc" selected>Sort by Name (A-Z)</option>
                            <option value="name-desc">Sort by Name (Z-A)</option>
                            <option value="pending-asc">Sort by Pending Amount (Low to High)</option>
                            <option value="pending-desc">Sort by Pending Amount (High to Low)</option>
                            <option value="last_payment_asc">Sort by Last Payment Date (Old to New)</option>
                            <option value="last_payment_desc">Sort by Last Payment Date (New to Old)</option>
                        </select>
                    </div>
                </div>
                <div class="table-responsive rounded-2">
                    <table class="table table-bordered table-striped" id="studentListTable">
                        <thead class="table-dark">
                            <tr>
                                <th><i class="fas fa-user"></i></th>
                                <th>Image</th>
                                <th>Student Name</th>
                                <th>Class</th>
                                <th>Actual Amount</th>
                                <th>Offer Amount</th>
                                <th>Pending Amount</th>
                                <th>Last Payment</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($student_ids as $student_id):
                                $student_info = getStudentInfo($pdo, $student_id);
                                if (!$student_info) {
                                    continue;
                                }

                                $unpaid_fees = getUnpaidMonthlyFeesData($pdo, $student_id);
                                if ($unpaid_fees) {
                                    $unpaid_fees = $unpaid_fees[0];
                                }

                                $last_payment = getLastMonthlyPayment($pdo, $student_id);

                                if (in_array($student_id, $filtered_student_ids)) {
                                    continue;
                                }

                                $filtered_student_ids[] = $student_id;

                                // PREPARE DATA FOR SORTING
                                $sort_name = strtolower($student_info['name']);
                                $sort_pending = $unpaid_fees['unpaid_amount'] ?? 0;
                                // Convert date to timestamp for easy sorting (0 if no date)
                                $sort_date = ($last_payment) ? strtotime($last_payment['payment_date']) : 0;
                            ?>
                                <tr id="trow-<?= $student_id ?>"
                                    class="student-row"
                                    data-student-id="<?= $student_id ?>"
                                    data-name="<?= safe_htmlspecialchars($sort_name) ?>"
                                    data-pending="<?= $sort_pending ?>"
                                    data-last-payment="<?= $sort_date ?>">

                                    <td>
                                        <button class="btn btn-sm btn-outline-primary more-details-btn" title="View More Details" data-student-id="<?= $student_id ?>">
                                            <i class="fas fa-plus-circle"></i>
                                        </button>
                                    </td>
                                    <td
                                        title="View Image"
                                        data-fancybox="student-images"
                                        data-caption="<?= $student_info['name'] ?>"
                                        data-src="<?= BASE_URL . "/uploads/students/" . $student_info['student_image']; ?>">
                                        <img
                                            src="<?= BASE_URL . "/uploads/students/" . $student_info['student_image']; ?>"
                                            alt="Img"
                                            loading="lazy" />
                                    </td>
                                    <td>
                                        <a
                                            class="text-decoration-none"
                                            href="<?= BASE_URL ?>/parent/dashboard/student-details.php?student_id=<?= $student_id ?>"
                                            target="_blank">
                                            <?php echo safe_htmlspecialchars($student_info['name']); ?>
                                        </a>
                                        <br>
                                        <small class="text-muted" style="font-size: 0.8rem;"><?= $student_id ?></small>
                                    </td>
                                    <td><?= $student_info['class_name'] . ' (' . $student_info['section_name'] . ')' ?></td>
                                    <td>
                                        <span class="text-dark fw-bold">
                                            <?php
                                            if (empty($unpaid_fees['actual_amount'])) {
                                                echo '-';
                                            } else {
                                                echo $currency_symbol . $unpaid_fees['actual_amount'];
                                            }
                                            ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="text-success fw-bold">
                                            <?php
                                            $offer_amount = ($unpaid_fees['actual_amount'] ?? 0) - ($unpaid_fees['discount_amount'] ?? 0);
                                            if ($offer_amount <= 0) {
                                                echo "-";
                                            } else {
                                                echo $currency_symbol . $offer_amount;
                                            }
                                            ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="text-danger fw-bold">
                                            <?php
                                            if (empty($unpaid_fees['unpaid_amount']) || $unpaid_fees['unpaid_amount'] <= 0) {
                                                echo '-';
                                            } else {
                                                echo $currency_symbol . $unpaid_fees['unpaid_amount'];
                                            }
                                            ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($last_payment): ?>
                                            <?php echo "Amount: " . $last_payment['payment_amount'] . "<br>Date: " . $last_payment['payment_date']; ?>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button
                                            title="Remove student from list"
                                            class="btn btn-sm btn-danger remove-student-btn"
                                            data-student-id="<?= $student_id ?>">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Include the modal html -->
<?php include_once('../../../includes/modals/fees-x-payments/financial-details-modal.php'); ?>

<script>
    let filteredStudentIds = <?= json_encode($filtered_student_ids) ?>;
    let financialDataLoaded = [];

    $('#total_students_payment_entry').text(filteredStudentIds.length);
    $('#student_ids_input').val(filteredStudentIds.join(','));

    $(document).ready(function() {

        // Remove Student from List
        $('.remove-student-btn').on('click', function() {
            const studentId = $(this).data('student-id');
            $(`#trow-${studentId}`).remove();
            filteredStudentIds = filteredStudentIds.filter(id => id !== studentId);
            $('#total_students_payment_entry').text(filteredStudentIds.length);
            $('#student_ids_input').val(filteredStudentIds.join(','));
        });

        // Form Submission
        $('#paymentsEntryForm').submit(function(e) {
            e.preventDefault();

            const amountVal = $('#fee_amount').val();
            if (!amountVal || isNaN(amountVal)) {
                showErrorAlert('Please enter a valid amount before submitting.');
                return;
            }

            if (filteredStudentIds.length === 0) {
                showWarningAlert('Please select at least one student.');
                return;
            }

            Swal.fire({
                title: "Is the amount correct?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                html: `<h3><b><span style="color: #0057c9;">₹${parseFloat(amountVal).toFixed(2)}</span></b></h3>`,
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, correct amount!",
                customClass: {
                    popup: 'rounded-4 shadow-lg'
                }
            }).then((result) => {

                if (result.isConfirmed) {

                    const $form = $(this);
                    const $btn = $form.find('[type="submit"]');
                    const btnText = $btn.html();

                    // Show loading state
                    $btn.prop('disabled', true).html(
                        '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...'
                    );

                    $.ajax({
                        url: '<?= BASE_URL ?>/api/admin/put/fees-x-payments/process-payments-entry-monthly.php',
                        type: 'POST',
                        data: $form.serialize(),
                        dataType: 'json',
                        success: function(response) {
                            if (response.success) {

                                // 1. Prepare the HTML for the detailed report
                                let reportHtml = `<div class="text-start">`;

                                // Summary Header
                                reportHtml += `<p class="alert alert-success text-center mb-3"><b>${response.message}</b></p>`;

                                // 2. Check for Wallet Credits
                                if (response.details && response.details.wallet_credits.length > 0) {
                                    reportHtml += `<h6 class="text-primary fw-bold mt-3"><i class="fas fa-wallet"></i> Wallet Credited (Excess Payment)</h6>
                                                <div class="table-responsive" style="max-height: 200px; overflow-y: auto;">
                                                    <table class="table table-sm table-bordered table-hover mb-0">
                                                        <thead class="table-light"><tr><th>Student Name</th><th class="text-end">Amount</th></tr></thead>
                                                        <tbody>`;

                                    response.details.wallet_credits.forEach(function(item) {
                                        reportHtml += `<tr>
                                        <td>${item.name}</td>
                                        <td class="text-end text-success fw-bold">+${item.amount}</td>
                                    </tr>`;
                                    });
                                    reportHtml += `</tbody></table></div>`;
                                }

                                // 3. Check for Skipped Students
                                if (response.details && response.details.skipped_students.length > 0) {
                                    reportHtml += `<h6 class="text-danger fw-bold mt-3"><i class="fas fa-exclamation-triangle"></i> Skipped Students</h6>
                                                <div class="table-responsive" style="max-height: 200px; overflow-y: auto;">
                                                    <table class="table table-sm table-bordered table-hover mb-0">
                                                        <thead class="table-light"><tr><th>Student Name</th><th>Reason</th></tr></thead>
                                                        <tbody>`;

                                    response.details.skipped_students.forEach(function(item) {
                                        reportHtml += `<tr>
                                        <td>${item.name}</td>
                                        <td class="text-danger small">${item.reason}</td>
                                    </tr>`;
                                    });
                                    reportHtml += `</tbody></table></div>`;
                                }

                                reportHtml += `</div>`;

                                // 4. Display the Detailed Report using SweetAlert
                                Swal.fire({
                                    title: "Processing Complete",
                                    icon: "success",
                                    html: reportHtml,
                                    width: '600px', // Make it wider for tables
                                    confirmButtonText: "Close",
                                    customClass: {
                                        popup: 'rounded-4 shadow-lg'
                                    }
                                }).then(() => {
                                    // Optional: Reload page or refresh table after closing the report
                                    location.reload();
                                });

                            } else {
                                showErrorAlert(response.message);
                            }
                        },
                        error: function(xhr) {
                            try {
                                let errorMsg = 'Error: ' + (xhr.statusText || 'Operation failed');
                                showErrorAlert(errorMsg);
                            } catch (e) {
                                console.error(e);
                                showErrorAlert('Error: ' + xhr.status + " " + xhr.statusText);
                            }
                            console.error(xhr.responseText);
                        },
                        complete: function() {
                            $btn.prop('disabled', false).html(btnText);
                        }
                    });
                }
            });
        });

        // --- 1. Client-Side Search Functionality ---
        $('#studentSearchBox').on('keyup', function() {
            var value = $(this).val().toLowerCase();
            $("#studentListTable tbody tr").filter(function() {
                // Toggle visibility based on whether the row text contains the search term
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });

        // --- 2. Client-Side Sort Functionality ---
        sortStudentRows(); // Initial sort
        $('#studentListSort').on('change', function() {
            sortStudentRows();
        });

        // --- 3. Show Student Financial Details in Modal ---
        $('.more-details-btn').on('click', function() {
            const studentId = $(this).data('student-id');
            const studentName = capitalize($(this).closest('tr').data('name'));

            $('#studentFinancialDetailsModalLabel').html(`Financial Details: <b>${studentName}</b>`);

            if (financialDataLoaded[studentId]) {
                $('#studentFinancialDetailsModalBody').html(financialDataLoaded[studentId]);
                $('#studentFinancialDetailsModal').modal('show');
                return;
            }

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/get/fees-x-payments/monthly/get-student-financial-overview.php',
                type: 'POST',
                data: {
                    student_id: studentId
                },
                dataType: 'json',
                beforeSend: function() {
                    showLoadingAlert('Fetching student financial details...');
                },
                success: function(response) {
                    Swal.close();
                    if (response.success) {
                        const unpaidFeesTable = response.unpaid_fees_table;
                        const paidFeesTable = response.paid_fees_table;
                        const fullHtml = unpaidFeesTable + paidFeesTable;
                        
                        $('#studentFinancialDetailsModalBody').html(fullHtml);
                        $('#studentFinancialDetailsModal').modal('show');

                        if (!financialDataLoaded[studentId]) {
                            financialDataLoaded[studentId] = fullHtml;
                        }
                    } else {
                        showErrorAlert(response.message);
                    }
                },
                error: function(xhr) {
                    console.error(xhr.responseText);
                    showErrorAlert('Error fetching student financial details');
                }
            });
        });
    });

    // Function sort student rows
    function sortStudentRows() {
        var sortOption = $('#studentListSort').val();
        var $tbody = $('#studentListTable tbody');
        var $rows = $tbody.find('tr').get();

        $rows.sort(function(a, b) {
            var valA, valB;

            switch (sortOption) {
                case 'name-asc':
                    valA = $(a).data('name');
                    valB = $(b).data('name');
                    return valA.localeCompare(valB);

                case 'name-desc':
                    valA = $(a).data('name');
                    valB = $(b).data('name');
                    return valB.localeCompare(valA);

                case 'pending-asc':
                    valA = parseFloat($(a).data('pending'));
                    valB = parseFloat($(b).data('pending'));
                    return valA - valB;

                case 'pending-desc':
                    valA = parseFloat($(a).data('pending'));
                    valB = parseFloat($(b).data('pending'));
                    return valB - valA;

                case 'last_payment_asc': // Oldest date first
                    valA = parseInt($(a).data('last-payment'));
                    valB = parseInt($(b).data('last-payment'));
                    // Handle '0' (no payment) cases - push to bottom or top?
                    // Currently: 0 is treated as very old (1970). 
                    return valA - valB;

                case 'last_payment_desc': // Newest date first
                    valA = parseInt($(a).data('last-payment'));
                    valB = parseInt($(b).data('last-payment'));
                    return valB - valA;

                default:
                    return 0;
            }
        });

        // Re-append rows in the new order
        $.each($rows, function(index, row) {
            $tbody.append(row);
        });
    }
</script>

<?php include_once("../../../includes/body-close.php"); ?>