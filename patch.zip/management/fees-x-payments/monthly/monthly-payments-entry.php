<?php

/** @var PDO $pdo
 * @var string $school_name
 * @var array $additional_website_configs
 */

// -----------------------------------------------------------------------//
//              THIS PAGE IS FOR MONTHLY FEES PAYMENTS ENTRY              //
// -----------------------------------------------------------------------//

include_once("../../../includes/auth-check.php");
require_once("../../../includes/header-open.php");
echo "<title>Collect Fees (Monthly) - " . $school_name . "</title>";
require_once("../../../includes/header-close.php");
require_once("../../../includes/dashboard-navbar.php");

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    include_once("../../../includes/permission-denied.php");
}

$authSession = getAuthenticatedAdmin($pdo);
$security_pin = $authSession['security_pin'];


$student_ids_string = $_REQUEST['student_ids'] ?? '';
$student_ids = explode(',', $student_ids_string);

if (empty($student_ids_string) || count($student_ids) == 0) {
    echo "<div class='container mt-4'><div class='alert alert-danger'>No student IDs provided.</div></div>";
    include_once("../../../includes/body-close.php");
    exit;
}

$filtered_student_ids = [];
$students_without_dues = [];

// Fetch class wise fees
$stmt = $pdo->prepare("SELECT class_id, amount FROM class_wise_monthly_fees");
$stmt->execute();
$class_wise_fees = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// Block this page if there are no class-wise fees setup
if (empty($class_wise_fees)) {
    echo "<div class='container mt-4'><div class='alert alert-danger'>No class-wise fees setup.</div></div>";
    include_once("../../../includes/body-close.php");
    exit;
}

?>
<style>
    .table>thead>tr>th {
        vertical-align: middle !important;
        text-align: center;
    }

    .table thead th {
        position: relative;
    }

    .table tbody td {
        vertical-align: middle !important;
        text-align: center;
    }

    .table tbody td img {
        border-radius: 5px;
        width: 50px;
        object-fit: cover;
        cursor: pointer;
        border: 1px solid #ddd;
    }
</style>

<div class="container-fluid mt-4">

    <div class="card shadow-sm mb-4">
        <div class="card-header d-flex justify-content-between align-items-center bg-primary text-white">
            <div>
                <h4 class="mb-0"><i class="fas fa-money-bill me-2"></i>Collect Fees (Monthly)</h4>
            </div>
            <div>
                <button type="button" class="btn btn-sm btn-danger" onclick="window.close()">
                    <i class="fas fa-window-close me-2"></i>Close Tab
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="my-1">
                <div class="alert alert-primary d-flex mb-2 align-items-center gap-2 hide" role="alert" id="no-due-students-alert">
                    <p class="m-0 p-0">Total Students Without Any Dues: <span class="fw-bold ms-1" id="total_students_without_dues"></span></p>
                    <button class="btn btn-sm btn-info ms-2" id="showStudentsWithoutDues">See Details</button>
                </div>
                <div class="mb-3">
                    <h5>Total Students: <span id="total_students_payment_entry"></span></h5>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6 mb-2">
                        <input type="text" id="studentSearchBox" class="form-control" placeholder="Search students... (CTRL+ /)" />
                    </div>
                    <div class="col-md-6">
                        <select id="studentListSort" class="form-select">
                            <option value="default" selected>Default (Requested Order)</option>
                            <option value="roll_no-asc">Roll (Low to High)</option>
                            <option value="roll_no-desc">Roll (High to Low)</option>
                            <option value="name-asc">Sort by Name (A-Z)</option>
                            <option value="name-desc">Sort by Name (Z-A)</option>
                            <option value="pending-asc">Sort by Pending Amount (Low to High)</option>
                            <option value="pending-desc">Sort by Pending Amount (High to Low)</option>
                            <option value="last_payment_asc">Sort by Last Payment Date (Old to New)</option>
                            <option value="last_payment_desc">Sort by Last Payment Date (New to Old)</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3 d-flex justify-content-end">
                    <button id="processPaymentsBtn" class="btn btn-primary">Save Payments Entry</button>
                </div>
                <div class="table-responsive rounded-2">
                    <table class="table table-bordered table-striped" id="studentListTable">
                        <thead class="table-dark">
                            <tr>
                                <th><i class="fas fa-user"></i></th>
                                <th>Image</th>
                                <th>Student Name</th>
                                <th>Fees Details</th>
                                <th>Offer Amount</th>
                                <th>Pending Amount</th>
                                <th>Total Month</th>
                                <th>Pay Amount</th>
                                <th>Payment Date</th>
                                <th>Last Payment</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($student_ids as $index => $student_id):
                                $student_info = getStudentInfo($pdo, $student_id);
                                if (!$student_info) {
                                    continue;
                                }

                                // Fetch the monthly fees of this student
                                $class_id = $student_info['class_id'];
                                $class_fee = getClassFee($class_id);
                                $custom_fee = $student_info['custom_class_fee'] ?? 0;
                                $car_fee = $student_info['car_fee'] ?? 0;
                                $hostel_fee = $student_info['hostel_fee'] ?? 0;
                                $coaching_fee = $student_info['coaching_fee'] ?? 0;
                                $tiffin_fee = $student_info['tiffin_fee'] ?? 0;

                                $monthly_fee = ($custom_fee > 0 ? $custom_fee : $class_fee) + $car_fee + $hostel_fee + $coaching_fee + $tiffin_fee;
                                $total_amount = 0;
                                $total_discount_amount = 0;
                                $total_offer_amount = 0;
                                $total_unpaid_amount = 0;

                                $unpaid_fees = getUnpaidMonthlyFeesData($pdo, $student_id);
                                $unpaid_months_list = [];
                                $unpaid_months_name = [];

                                if ($unpaid_fees) {
                                    // $unpaid_fees = $unpaid_fees[0];
                                    foreach ($unpaid_fees as $fee) {
                                        $total_amount += $fee['actual_amount'] ?? 0;
                                        $total_discount_amount += $fee['discount_amount'] ?? 0;
                                        $total_unpaid_amount += $fee['unpaid_amount'] ?? 0;

                                        // মাসের নাম ও বকেয়া সেভ করে রাখুন
                                        $unpaid_months_list[] = [
                                            'month' => $fee['month_year'],
                                            'due' => $fee['unpaid_amount'] ?? 0
                                        ];

                                        $unpaid_months_name[] = $fee['month_year'];
                                    }
                                } else {
                                    $no_due_students = [
                                        'student_id' => $student_id,
                                        'name' => $student_info['name'],
                                        'class_name' => $student_info['class_name'],
                                        'section_name' => $student_info['section_name'],
                                        'roll_no' => $student_info['roll_no']
                                    ];

                                    $students_without_dues[] = $no_due_students;
                                }

                                $total_offer_amount = $total_amount - $total_discount_amount;
                                $average_monthly_fee = $total_offer_amount / max(count($unpaid_fees), 1);

                                $last_payment = getLastMonthlyPayment($pdo, $student_id);

                                if (in_array($student_id, $filtered_student_ids)) {
                                    continue;
                                }

                                $filtered_student_ids[] = $student_id;

                                // Sort the $unpaid_months_name array lower to higher
                                if (count($unpaid_months_name) > 0) {
                                    usort($unpaid_months_name, function ($a, $b) {
                                        return strtotime("1 " . $a) <=> strtotime("1 " . $b);
                                    });
                                }

                                // PREPARE DATA FOR SORTING
                                $sort_name = strtolower($student_info['name']);
                                $sort_pending = $total_unpaid_amount;
                                // Convert date to timestamp for easy sorting (0 if no date)
                                $sort_date = ($last_payment) ? strtotime($last_payment['payment_date']) : 0;
                            ?>
                                <tr id="trow-<?= $student_id ?>"
                                    class="student-row"
                                    data-original-index="<?= $index ?>"
                                    data-student-id="<?= $student_id ?>"
                                    data-name="<?= safe_htmlspecialchars($sort_name) ?>"
                                    data-pending="<?= $sort_pending ?>"
                                    data-last-payment="<?= $sort_date ?>"
                                    data-roll-no="<?= $student_info['roll_no'] ?? '0' ?>"
                                    data-class-name="<?= $student_info['class_name'] ?? '' ?>"
                                    data-monthly-fee="<?= $monthly_fee ?? '0' ?>"
                                    data-unpaid-months='<?= json_encode($unpaid_months_list, JSON_HEX_APOS | JSON_HEX_QUOT) ?>'>

                                    <td>
                                        <button tabindex="-1" class="btn btn-sm btn-outline-primary more-details-btn" title="View More Details" data-student-id="<?= $student_id ?>">
                                            <i class="fas fa-plus-circle"></i>
                                        </button>
                                    </td>
                                    <td
                                        title="View Image"
                                        data-fancybox="student-images"
                                        data-caption="<?= $student_info['name'] ?>"
                                        data-src="<?= BASE_URL . "/uploads/students/" . $student_info['student_image']; ?>">
                                        <img
                                            src="<?= BASE_URL . "/uploads/students/" . $student_info['student_image']; ?>"
                                            alt="Img"
                                            loading="lazy" />
                                    </td>
                                    <td>
                                        <a tabindex="-1"
                                            class="text-decoration-none"
                                            href="<?= BASE_URL ?>/parent/dashboard/student-details.php?student_id=<?= $student_id ?>"
                                            target="_blank">
                                            <?= safe_htmlspecialchars($student_info['name']); ?>
                                        </a>
                                        <br>
                                        <small class="text-muted" style="font-size: 0.8rem;"><?= $student_id ?></small>
                                        <br>
                                        <small class="text-muted small-text">
                                            <?= $student_info['class_name'] . ' (' . $student_info['section_name'] . ')' ?> · Roll: <?= $student_info['roll_no'] ?>
                                        </small>
                                    </td>
                                    <td class="small">
                                        <div class="w-100 text-start" title="This is the monthly fee of the student. Included car fees, hostel fees if applicable, and other fees.">
                                            Monthly:
                                            <span class="text-dark fw-bold row-monthly-fee">
                                                <?= $currency_symbol . $monthly_fee; ?>
                                            </span>
                                        </div>
                                        <div class="w-100 text-start" title="This is the average monthly fee of the student.">
                                            Average Monthly:
                                            <span class="text-dark fw-bold row-average-monthly">
                                                <?= $currency_symbol . number_format($average_monthly_fee, 2, '.', ''); ?>
                                            </span>
                                        </div>
                                        <div class="w-100 text-start" title="Actual fee means the original total amount before any discount is applied.">
                                            Total:
                                            <span class="text-dark fw-bold row-total-actual">
                                                <?= $currency_symbol . $total_amount; ?>
                                            </span>
                                        </div>
                                        <div class="w-100 text-start">
                                            Discount:
                                            <span class="text-danger fw-bold row-total-discount">
                                                <?= $currency_symbol . $total_discount_amount; ?>
                                            </span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="text-success fw-bold row-offer-amount" title="Offer amount is the total amount after the discount has been applied.">
                                            <?= $currency_symbol . $total_offer_amount ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="text-danger fw-bold w-100 row-pending-amount" title="Pending amount is the amount that is still due and needs to be paid.">
                                            <?= $currency_symbol . $total_unpaid_amount ?>
                                        </div>
                                        <span class="small text-dark mt-1 row-pending-months">
                                            <?php
                                            if (count($unpaid_months_name) > 0) {
                                                if (count($unpaid_months_name) == 1) {
                                                    echo $unpaid_months_name[0];
                                                } else {
                                                    echo $unpaid_months_name[0] . ' to ' . end($unpaid_months_name);
                                                }
                                            }
                                            ?>
                                        </span>
                                    </td>
                                    <td>
                                        <input type="text"
                                            class="form-control form-control-sm total-month-input text-center"
                                            placeholder="Total month"
                                            value="0">
                                    </td>
                                    <td>
                                        <input type="text"
                                            class="form-control form-control-sm payment-amount-input text-center"
                                            placeholder="Enter Amount"
                                            value="0">
                                        <div class="payment-projection text-start mt-2 border rounded p-1 bg-light shadow-sm" style="display: none; font-size: 0.75rem; line-height: 1.4;"></div>
                                    </td>
                                    <td>
                                        <input type="date"
                                            class="form-control form-control-sm payment-date-input"
                                            value="<?= date('Y-m-d') ?>">
                                    </td>
                                    <td>
                                        <?php if ($last_payment): ?>
                                            <div class="w-100 text-center">
                                                <?php echo "<span class='fw-bold badge rounded-pill bg-success'>" . $currency_symbol . $last_payment['payment_amount'] . "</span>"; ?>
                                            </div>
                                            <div class="w-100 text-center my-1">
                                                <?php echo "<span class='fw-bold'>" . formatDate($last_payment['payment_date']) . "</span>"; ?>
                                            </div>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button
                                            title="Remove student from list"
                                            class="btn btn-sm btn-danger remove-student-btn"
                                            data-student-id="<?= $student_id ?>">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Include the modal html -->
<?php include_once('../../../includes/modals/fees-x-payments/financial-details-modal.php'); ?>
<?php include_once('../../../includes/modals/fees-x-payments/no-due-students-modal.php'); ?>
<?php include_once('../../../includes/modals/fees-x-payments/edit-monthly-fee-entry-modal.php'); ?>
<?php include_once('../../../includes/modals/fees-x-payments/permanent-monthly-fee-edit-modal.php'); ?>

<script>
    let filteredStudentIds = <?= json_encode($filtered_student_ids) ?>;
    let editEntryStudentInfo = {};
    let studentFinancialOverview = null;

    $('#total_students_payment_entry').text(filteredStudentIds.length);
    $('#student_ids_input').val(filteredStudentIds.join(','));

    $(document).ready(function() {
        let hasUnsavedChanges = false;
        populateMonthSelection();
        // $('#updateMonthlyFeesModal').modal('show');

        // Bootstrap Multiselect
        $('.bts-multiselect').multiselect({
            templates: {
                button: '<button type="button" class="multiselect dropdown-toggle form-select form-select-lg shadow-sm" style="text-align: left !important;" data-bs-toggle="dropdown" data-bs-config=\'{"popperConfig": {"strategy": "fixed"}}\' aria-expanded="false"><span class="multiselect-selected-text"></span></button>',
                filter: '<li class="multiselect-item filter"><div class="input-group p-2"><span class="input-group-text"><i class="fas fa-search"></i></span><input type="text" class="form-control multiselect-search" placeholder="Search..."><span class="input-group-text" style="cursor:pointer;"><i class="fas fa-times multiselect-clear-filter"></i></span></div></li>',
            },
            buttonWidth: '100%',
            includeSelectAllOption: true,
            nonSelectedText: 'Select month(s)',
            enableCaret: false,
            enableFiltering: true,
            enableCaseInsensitiveFiltering: true,
            maxHeight: 300
        });

        // Fix dropdown width for fixed positioned menus inside table-responsive
        $(document).on('show.bs.dropdown', '.multiselect-native-select .btn-group', function() {
            // Get the exact pixel width of the button
            let buttonWidth = $(this).outerWidth();

            // Apply that strict pixel width to the dropdown menu
            $(this).find('.dropdown-menu').css({
                'width': buttonWidth + 'px',
                'min-width': buttonWidth + 'px',
                'max-width': buttonWidth + 'px'
            });
        });

        // যেকোনো ইনপুট বা টেক্সট এরিয়া পরিবর্তন হলে
        $('input, textarea, select').on('input change', function() {
            hasUnsavedChanges = true;
        });

        // ট্যাব বন্ধ করার সময়
        $(window).on('beforeunload', function() {
            if (hasUnsavedChanges) {
                // jQuery তে ব্রাউজারকে ডায়ালগ দেখাতে শুধু কিছু রিটার্ন করলেই হয়
                return 'Your changes have not been saved. Are you sure you want to leave?';
            }
        });

        // Sticky Table Header using jQuery
        $(window).on('scroll', function() {
            var tableContainer = $('.table-responsive');
            var thead = $('#studentListTable thead th');
            var containerTop = tableContainer.offset().top;
            var windowTop = $(window).scrollTop();

            if (windowTop > containerTop) {
                // স্ক্রল করার সময় হেডারটিকে নিচে নামিয়ে আনবে
                var scrollDistance = windowTop - containerTop;
                thead.css({
                    'transform': 'translateY(' + scrollDistance + 'px)',
                    'background-color': '#212529', // ব্যাকগ্রাউন্ড কালার ডার্ক রাখার জন্য
                    'z-index': '10',
                    'position': 'relative'
                });
            } else {
                // স্ক্রল করে উপরে ফিরে গেলে আগের অবস্থায় (ডিফল্ট) ফিরে যাবে
                thead.css({
                    'transform': 'translateY(0)'
                });
            }
        });

        // Verify security pin before accessing the page
        <?php
        if ($additional_website_configs['need_security_pin_for_payment_entry'] == 1) {
            echo "verifySecurityPin();";
        }
        ?>

        // Select Text on Input Focus
        $('input').on('focus', function() {
            this.select();
        });

        // Total Month Input Change
        $('.total-month-input').on('input', function() {
            let monthlyFee = $(this).closest('tr').data('monthly-fee');
            let totalMonths = parseFloat($(this).val()) || 0;

            if (!isNumeric($(this).val())) {
                $(this).addClass('is-invalid');
                $('#processPaymentsBtn').prop('disabled', true);
            } else {
                $(this).removeClass('is-invalid');
                $('#processPaymentsBtn').prop('disabled', false);
            }

            let totalAmount = monthlyFee * totalMonths;
            $(this).closest('tr').find('.payment-amount-input').val(totalAmount);

            setTimeout(() => {
                $(this).closest('tr').find('.payment-amount-input').trigger('input');
            }, 1500);
        });

        // Up/Down Arrow Key Navigation on Total Month Input
        $(document).on('keydown', '.total-month-input', function(e) {
            // Down Arrow (Key code: 40)
            if (e.which === 40 || e.key === 'ArrowDown') {
                e.preventDefault(); // ব্রাউজারের ডিফল্ট স্ক্রল বা কার্সার মুভমেন্ট বন্ধ করতে
                let nextRow = $(this).closest('tr').next('tr:visible');
                if (nextRow.length > 0) {
                    nextRow.find('.total-month-input').focus();
                }
            }
            // Up Arrow (Key code: 38)
            else if (e.which === 38 || e.key === 'ArrowUp') {
                e.preventDefault();
                let prevRow = $(this).closest('tr').prev('tr:visible');
                if (prevRow.length > 0) {
                    prevRow.find('.total-month-input').focus();
                }
            }
        });

        // Focus on payment amount input
        // $('.payment-amount-input').on('focus', function() {
        //     this.select();
        // });

        $('.payment-amount-input').on('input', function() {
            let $row = $(this).closest('tr');
            let monthlyFee = parseFloat($row.data('monthly-fee')) || 0;
            let inputAmount = parseFloat($(this).val()) || 0;

            if (!isNumeric($(this).val())) {
                $(this).addClass('is-invalid');
                $('#processPaymentsBtn').prop('disabled', true);
            } else {
                $(this).removeClass('is-invalid');
                $('#processPaymentsBtn').prop('disabled', false);
            }

            // আপনার আগের মাসের হিসাব লজিক
            let calculatedMonths = monthlyFee > 0 ? (inputAmount / monthlyFee) : 0;
            $row.find('.total-month-input').val(calculatedMonths.toFixed(2));
            $row.find('.total-month-input').removeClass('is-invalid');

            // --- নতুন লজিক: রিয়েল-টাইম পেমেন্ট হিসাব ---
            let unpaidMonths = $row.data('unpaid-months');
            let $projectionDiv = $row.find('.payment-projection');
            // currenySymbol ভেরিয়েবলটি আপনার আগের স্ক্রিপ্ট থেকে পাবে, না থাকলে '₹' ব্যবহার করুন
            let symbol = typeof currenySymbol !== 'undefined' ? currenySymbol : '₹';

            if (inputAmount > 0) {
                let remainingInput = inputAmount;
                let projectionHtml = '<strong class="text-dark d-block border-bottom mb-1 pb-1">Payment Calculation:</strong>';

                if (unpaidMonths && unpaidMonths.length > 0) {
                    for (let i = 0; i < unpaidMonths.length; i++) {
                        let monthName = unpaidMonths[i].month;
                        let dueAmount = parseFloat(unpaidMonths[i].due);

                        if (remainingInput <= 0) break; // টাকা শেষ হলে লুপ থামিয়ে দিন

                        if (remainingInput >= dueAmount) {
                            // মাস পুরোপুরি ক্লিয়ার হলে
                            projectionHtml += `<div class="text-success fw-bold"><i class="fas fa-check-circle me-1"></i> ${monthName} (Clear)</div>`;
                            remainingInput -= dueAmount;
                        } else {
                            // আংশিক ক্লিয়ার হলে
                            let leftAmount = dueAmount - remainingInput;
                            projectionHtml += `<div class="text-warning text-dark fw-bold"><i class="fas fa-adjust me-1"></i> ${monthName} <br><span class="ms-3 text-muted">(${symbol}${remainingInput} Paid, ${symbol}${leftAmount} Due)</span></div>`;
                            remainingInput = 0;
                        }
                    }
                }

                // যদি সব মাস ক্লিয়ার করার পরও টাকা বেঁচে যায়, তবে ওয়ালেটে জমার হিসাব দেখাবে
                if (remainingInput > 0) {
                    projectionHtml += `<div class="text-info fw-bold mt-1 pt-1 border-top"><i class="fas fa-wallet me-1"></i> Advanced Payment: ${symbol}${remainingInput}</div>`;
                }

                $projectionDiv.html(projectionHtml).slideDown('fast');
            } else {
                // ইনপুট ০ বা খালি থাকলে হিসাব লুকিয়ে ফেলবে
                $projectionDiv.slideUp('fast').empty();
            }
        });

        // Up/Down Arrow Key Navigation (নতুন যুক্ত করা কোড)
        $(document).on('keydown', '.payment-amount-input', function(e) {
            // Down Arrow (Key code: 40)
            if (e.which === 40 || e.key === 'ArrowDown') {
                e.preventDefault(); // ব্রাউজারের ডিফল্ট স্ক্রল বা কার্সার মুভমেন্ট বন্ধ করতে
                let nextRow = $(this).closest('tr').next('tr:visible');
                if (nextRow.length > 0) {
                    nextRow.find('.payment-amount-input').focus();
                }
            }
            // Up Arrow (Key code: 38)
            else if (e.which === 38 || e.key === 'ArrowUp') {
                e.preventDefault();
                let prevRow = $(this).closest('tr').prev('tr:visible');
                if (prevRow.length > 0) {
                    prevRow.find('.payment-amount-input').focus();
                }
            }
        });

        // Focus and select on #studentSearchBox when pressed CTRL + /
        $(document).on('keydown', function(e) {
            if (e.ctrlKey && e.key === '/') {
                e.preventDefault();
                $('#studentSearchBox').focus();
                $('#studentSearchBox').select();
            }
        })

        // Remove Student from List
        $('.remove-student-btn').on('click', function() {
            const studentId = $(this).data('student-id');
            $(`#trow-${studentId}`).remove();
            filteredStudentIds = filteredStudentIds.filter(id => id !== studentId);
            $('#total_students_payment_entry').text(filteredStudentIds.length);
            $('#student_ids_input').val(filteredStudentIds.join(','));
        });

        // --- 1. Client-Side Search Functionality ---
        $('#studentSearchBox').on('keyup', function() {
            var value = $(this).val().toLowerCase();
            $("#studentListTable tbody tr").filter(function() {
                // Toggle visibility based on whether the row text contains the search term
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });

        // --- 2. Client-Side Sort Functionality ---
        sortStudentRows(); // Initial sort
        $('#studentListSort').on('change', function() {
            sortStudentRows();
        });

        // --- 3. Show Student Financial Details in Modal ---
        $('.more-details-btn').on('click', function() {
            const studentId = $(this).data('student-id');
            const studentName = capitalize($(this).closest('tr').data('name'));
            const studentClass = $(this).closest('tr').data('class-name');
            const studentRoll = $(this).closest('tr').data('roll-no') || '';

            $('#studentFinancialDetailsModalLabel').html(`<b>${studentName}</b> (Roll: ${studentRoll}, Class: ${studentClass})`);

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/get/fees-x-payments/monthly/get-student-financial-overview.php',
                type: 'POST',
                data: {
                    student_id: studentId
                },
                dataType: 'json',
                beforeSend: function() {
                    showLoadingAlert('Fetching student financial details...');
                },
                success: function(response) {
                    Swal.close();
                    $('body').css('padding-right', '');
                    $('body').removeClass('modal-open');

                    if (response.success) {
                        studentFinancialOverview = response;
                        const unpaidFeesTable = response.unpaid_fees_table;
                        const paidFeesTable = response.paid_fees_table;
                        const fullHtml = unpaidFeesTable + paidFeesTable;

                        $('#studentFinancialDetailsModalBody').html(fullHtml);
                        $('#studentFinancialDetailsModal').modal('show');

                        // --- নতুন কোড: মেইন টেবিলের রো (Row) রিয়েল-টাইমে আপডেট করা ---
                        let $row = $('#trow-' + studentId);

                        // ডাটা এট্রিবিউট আপডেট (যাতে পেমেন্ট ক্যালকুলেশনে নতুন ডেটা ব্যবহার হয়)
                        $row.attr('data-unpaid-months', JSON.stringify(response.unpaid_months_list));
                        $row.data('unpaid-months', response.unpaid_months_list);

                        $row.attr('data-pending', response.total_unpaid_amount);
                        $row.data('pending', response.total_unpaid_amount);

                        $row.attr('data-monthly-fee', response.monthly_fee);
                        $row.data('monthly-fee', response.monthly_fee);

                        // টেক্সট আপডেট
                        $row.find('.row-pending-amount').text('<?= $currency_symbol ?>' + response.total_unpaid_amount);
                        $row.find('.row-pending-months').text(response.unpaid_months_text);

                        // যদি ইতোমধ্যে কোনো পেমেন্ট এমাউন্ট লেখা থাকে, তবে প্রজেকশন পুনরায় ক্যালকুলেট করার জন্য ট্রিগার করুন
                        let currentInput = $row.find('.payment-amount-input').val();
                        if (parseFloat(currentInput) > 0) {
                            $row.find('.payment-amount-input').trigger('input');
                        }
                        // ২. UI-তে Pending Amount এবং Months Text আপডেট করা
                        $row.find('.row-pending-amount').text('<?= $currency_symbol ?>' + response.total_unpaid_amount);
                        $row.find('.row-pending-months').text(response.unpaid_months_text);

                        // --- নতুন যোগ করা কোড: Fees Details এবং Offer Amount রিয়েল-টাইম আপডেট ---
                        $row.find('.row-monthly-fee').text('<?= $currency_symbol ?>' + response.monthly_fee);
                        $row.find('.row-average-monthly').text('<?= $currency_symbol ?>' + response.average_monthly_fee);
                        $row.find('.row-total-actual').text('<?= $currency_symbol ?>' + response.total_actual_amount);
                        $row.find('.row-total-discount').text('<?= $currency_symbol ?>' + response.total_discount_amount);
                        $row.find('.row-offer-amount').text('<?= $currency_symbol ?>' + response.total_offer_amount);
                        // --- নতুন যোগ করা কোড শেষ ---

                    } else {
                        showErrorAlert(response.message);
                        studentFinancialOverview = null;
                    }
                },
                error: function(xhr) {
                    console.error(xhr.responseText);
                    showErrorAlert('Error fetching student financial details');
                    studentFinancialOverview = null;
                }
            });
        });

        // --- 4. Show alert div for no due students ---
        let totalStudentsWithouDue = <?= count($students_without_dues) ?>;
        if (totalStudentsWithouDue > 0) {
            $('#no-due-students-alert').removeClass('d-none');
            $('#total_students_without_dues').html(totalStudentsWithouDue);

            <?php
            $tableBody = '';
            foreach ($students_without_dues as $student) {
                $studentName = $student['name'];
                $className = $student['class_name'];
                $sectionName = $student['section_name'];
                $rollNo = $student['roll_no'];

                $tableBody .= "<tr>
                    <td>{$studentName}</td>
                    <td>{$rollNo}</td>
                    <td>{$className}</td>
                    <td>{$sectionName}</td>
                </tr>";
            }
            ?>

            let tableBody = `<?php echo $tableBody; ?>`;
            $('#noDueStudentsModalTableBody').html(tableBody);
        } else {
            $('#no-due-students-alert').addClass('d-none');
        }

        $('#showStudentsWithoutDues').click(function() {
            $('#noDueStudentsModal').modal('show');
        });

        // --- 5. Submit form data ---
        $('#processPaymentsBtn').click(function() {
            submitData();
            hasUnsavedChanges = false;
        });

        // Check real time changes of edit entry modal
        $(document).on('input',
            '#editMonthlyFeeEntryModalTutionFee, #editMonthlyFeeEntryModalCarFee, #editMonthlyFeeEntryModalHostelFee, #editMonthlyFeeEntryModalCoachingFee, #editMonthlyFeeEntryModalTiffinFee, #editMonthlyFeeEntryModalDiscount',
            function() {

                let tutionFee = $('#editMonthlyFeeEntryModalTutionFee').val();
                let carFee = $('#editMonthlyFeeEntryModalCarFee').val();
                let hostelFee = $('#editMonthlyFeeEntryModalHostelFee').val();
                let coachingFee = $('#editMonthlyFeeEntryModalCoachingFee').val();
                let tiffinFee = $('#editMonthlyFeeEntryModalTiffinFee').val();
                let discount = $('#editMonthlyFeeEntryModalDiscount').val();

                let totalFee = (parseFloat(tutionFee) || 0) + (parseFloat(carFee) || 0) + (parseFloat(hostelFee) || 0) + (parseFloat(coachingFee) || 0) + (parseFloat(tiffinFee) || 0) - (parseFloat(discount) || 0);
                $('#editMonthlyFeeEntryModalTotalAmount').text('<?= $currency_symbol ?>' + totalFee.toFixed(2));

                if (!isNumeric(tutionFee) || tutionFee <= 0) {
                    $('#editMonthlyFeeEntryModalTutionFee').addClass('is-invalid');
                    toastr.error('Tution fee must be greater than 0.');
                } else {
                    $('#editMonthlyFeeEntryModalTutionFee').removeClass('is-invalid');
                }
                if (!isNumeric(carFee) || carFee < 0) {
                    $('#editMonthlyFeeEntryModalCarFee').addClass('is-invalid');
                    toastr.error('Car fee must be a number.');
                } else {
                    $('#editMonthlyFeeEntryModalCarFee').removeClass('is-invalid');
                }
                if (!isNumeric(hostelFee) || hostelFee < 0) {
                    $('#editMonthlyFeeEntryModalHostelFee').addClass('is-invalid');
                    toastr.error('Hostel fee must be a number.');
                } else {
                    $('#editMonthlyFeeEntryModalHostelFee').removeClass('is-invalid');
                }
                if (!isNumeric(coachingFee) || coachingFee < 0) {
                    $('#editMonthlyFeeEntryModalCoachingFee').addClass('is-invalid');
                    toastr.error('Coaching fee must be a number.');
                } else {
                    $('#editMonthlyFeeEntryModalCoachingFee').removeClass('is-invalid');
                }
                if (!isNumeric(tiffinFee) || tiffinFee < 0) {
                    $('#editMonthlyFeeEntryModalTiffinFee').addClass('is-invalid');
                    toastr.error('Tiffin fee must be a number.');
                } else {
                    $('#editMonthlyFeeEntryModalTiffinFee').removeClass('is-invalid');
                }
                if (!isNumeric(discount) || discount < 0) {
                    $('#editMonthlyFeeEntryModalDiscount').addClass('is-invalid');
                    toastr.error('Discount must be a number.');
                } else {
                    $('#editMonthlyFeeEntryModalDiscount').removeClass('is-invalid');
                }

                if (discount >= totalFee) {
                    $('#editMonthlyFeeEntryModalDiscount').val(0);

                    let tutionFee = $('#editMonthlyFeeEntryModalTutionFee').val();
                    let carFee = $('#editMonthlyFeeEntryModalCarFee').val();
                    let hostelFee = $('#editMonthlyFeeEntryModalHostelFee').val();
                    let coachingFee = $('#editMonthlyFeeEntryModalCoachingFee').val();
                    let tiffinFee = $('#editMonthlyFeeEntryModalTiffinFee').val();
                    let discount = $('#editMonthlyFeeEntryModalDiscount').val();
                    let totalFee = (parseFloat(tutionFee) || 0) + (parseFloat(carFee) || 0) + (parseFloat(hostelFee) || 0) + (parseFloat(coachingFee) || 0) + (parseFloat(tiffinFee) || 0) - (parseFloat(discount) || 0);
                    $('#editMonthlyFeeEntryModalTotalAmount').text('<?= $currency_symbol ?>' + totalFee.toFixed(2));
                    toastr.error('Discount amount cannot be greater than or equal to total amount.');
                }
            }
        );

        $(document).on('click', '#updateEditMonthlyFeeEntryBtn', function() {
            let tutionFee = $('#editMonthlyFeeEntryModalTutionFee').val();
            let carFee = $('#editMonthlyFeeEntryModalCarFee').val();
            let hostelFee = $('#editMonthlyFeeEntryModalHostelFee').val();
            let coachingFee = $('#editMonthlyFeeEntryModalCoachingFee').val();
            let tiffinFee = $('#editMonthlyFeeEntryModalTiffinFee').val();
            let discountAmount = $('#editMonthlyFeeEntryModalDiscount').val();
            let totalFee = (parseFloat(tutionFee) || 0) + (parseFloat(carFee) || 0) + (parseFloat(hostelFee) || 0) + (parseFloat(coachingFee) || 0) + (parseFloat(tiffinFee) || 0) - (parseFloat(discountAmount) || 0);

            if (!isNumeric(tutionFee) || tutionFee <= 0) {
                toastr.error('Tution fee must be greater than 0.');
                return;
            }

            if (!isNumeric(carFee) || carFee < 0) {
                toastr.error('Car fee must be a number.');
                return;
            }

            if (!isNumeric(hostelFee) || hostelFee < 0) {
                toastr.error('Hostel fee must be a number.');
                return;
            }

            if (!isNumeric(coachingFee) || coachingFee < 0) {
                toastr.error('Coaching fee must be a number.');
                return;
            }

            if (!isNumeric(tiffinFee) || tiffinFee < 0) {
                toastr.error('Tiffin fee must be a number.');
                return;
            }

            if (!isNumeric(discountAmount) || discountAmount < 0) {
                toastr.error('Discount must be a number.');
                return;
            }

            if (discountAmount >= totalFee) {
                toastr.error('Discount amount cannot be greater than or equal to total amount.');
                return;
            }

            if (!isNumeric(totalFee) || totalFee <= 0) {
                toastr.error('Total fee must be a number. It should be greater than 0.');
                return;
            }

            let studentId = editEntryStudentInfo.student_id;
            let studentName = editEntryStudentInfo.name;
            let classInfo = editEntryStudentInfo.class_name + ' (' + editEntryStudentInfo.section_name + ')';
            let rollNo = editEntryStudentInfo.roll_no;

            let actualFee = parseFloat(tutionFee) + parseFloat(carFee) + parseFloat(hostelFee) + parseFloat(coachingFee) + parseFloat(tiffinFee);

            let monthYear = [$('#editMonthlyFeeEntryModalMonth').text().trim()];

            let studentsData = [];

            studentsData.push({
                studentId: studentId,
                studentName: studentName,
                classInfo: classInfo,
                rollNo: rollNo,
                tutionFee: tutionFee,
                carFee: carFee,
                hostelFee: hostelFee,
                coachingFee: coachingFee,
                tiffinFee: tiffinFee,
                discountAmount: discountAmount,
                actualFee: actualFee,
                offerAmount: totalFee,
                monthYear: monthYear
            });

            submitEditedUnpaidFeeData(studentsData);
        });

        // Submit updateMonthlyFeesModal data
        $(document).on('click', '#updateMonthlyFeesModalUpdateBtn', function() {
            let studentId = studentFinancialOverview.student_id;
            let classFee = studentFinancialOverview.class_fee;
            let customClassFee = $('#updateMonthlyFeesModalCustomClassFee').val();
            let carFee = $('#updateMonthlyFeesModalCarFee').val();
            let hostelFee = $('#updateMonthlyFeesModalHostelFee').val();
            let coachingFee = $('#updateMonthlyFeesModalCoachingFee').val();
            let tiffinFee = $('#updateMonthlyFeesModalTiffinFee').val();
            let selectedMonths = $('#updateMonthlyFeesModalSelectedMonths').val();
            let permanentChange = $('#updateMonthlyFeesModalPermanentChangeCheckbox').is(':checked');

            if (!isNumeric(customClassFee) || customClassFee < 0) {
                $('#updateMonthlyFeesModalCustomClassFee').addClass('is-invalid');
                toastr.error('Custom class fee must be a number.');
                return;
            } else {
                $('#updateMonthlyFeesModalCustomClassFee').removeClass('is-invalid');
            }

            if (!isNumeric(carFee) || carFee < 0) {
                $('#updateMonthlyFeesModalCarFee').addClass('is-invalid');
                toastr.error('Car fee must be a number.');
                return;
            } else {
                $('#updateMonthlyFeesModalCarFee').removeClass('is-invalid');
            }

            if (!isNumeric(hostelFee) || hostelFee < 0) {
                $('#updateMonthlyFeesModalHostelFee').addClass('is-invalid');
                toastr.error('Hostel fee must be a number.');
                return;
            } else {
                $('#updateMonthlyFeesModalHostelFee').removeClass('is-invalid');
            }

            if (!isNumeric(coachingFee) || coachingFee < 0) {
                $('#updateMonthlyFeesModalCoachingFee').addClass('is-invalid');
                toastr.error('Coaching fee must be a number.');
                return;
            } else {
                $('#updateMonthlyFeesModalCoachingFee').removeClass('is-invalid');
            }

            if (!isNumeric(tiffinFee) || tiffinFee < 0) {
                $('#updateMonthlyFeesModalTiffinFee').addClass('is-invalid');
                toastr.error('Tiffin fee must be a number.');
                return;
            } else {
                $('#updateMonthlyFeesModalTiffinFee').removeClass('is-invalid');
            }

            let customizedData = {
                studentId: studentId,
                classFee: classFee,
                customClassFee: customClassFee,
                carFee: carFee,
                hostelFee: hostelFee,
                coachingFee: coachingFee,
                tiffinFee: tiffinFee,
                selectedMonths: selectedMonths,
                permanentChange: permanentChange
            };

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/put/fees-x-payments/monthly/update-monthly-fees-data.php',
                method: 'POST',
                data: {
                    financialData: JSON.stringify(customizedData)
                },
                beforeSend: function() {
                    showLoadingAlert('Updating fees data...');
                },
                success: function(response) {
                    if (response.success) {
                        // Update Modal টি বন্ধ করে দিন
                        $('#updateMonthlyFeesModal').modal('hide');

                        // বিস্তারিত রেসপন্স দেখানোর জন্য ফাংশনটি কল করুন
                        showUpdateFeeDetailedResult(response, studentId);

                    } else {
                        toastr.error(response.message);
                        showErrorAlert(response.message);
                        console.log(response.message);
                    }
                },
                error: function(e) {
                    toastr.error('Something went wrong.');
                    showErrorAlert('Something went wrong.');
                    sendErrorReport(e.responseText);
                    console.error(e.responseText);
                },
                complete: function() {
                    // সব সিলেক্ট করা ভ্যালু আনসিলেক্ট করে দেবে
                    $('#updateMonthlyFeesModalSelectedMonths').val([]);
                    // Bootstrap Multiselect-এর UI আপডেট করবে যাতে চেকমার্কগুলো উঠে যায়
                    $('#updateMonthlyFeesModalSelectedMonths').multiselect('refresh');
                }
            });
        });

        $(document).on('input',
            '#updateMonthlyFeesModalCustomClassFee, #updateMonthlyFeesModalCarFee, #updateMonthlyFeesModalHostelFee, #updateMonthlyFeesModalCoachingFee, #updateMonthlyFeesModalTiffinFee',
            function() {

                let customClassFee = $('#updateMonthlyFeesModalCustomClassFee').val();
                let tutionFee = (parseFloat(customClassFee) || 0) > 0 ? customClassFee : studentFinancialOverview.class_fee;
                let carFee = $('#updateMonthlyFeesModalCarFee').val();
                let hostelFee = $('#updateMonthlyFeesModalHostelFee').val();
                let coachingFee = $('#updateMonthlyFeesModalCoachingFee').val();
                let tiffinFee = $('#updateMonthlyFeesModalTiffinFee').val();

                let totalFee = (parseFloat(tutionFee) || 0) + (parseFloat(carFee) || 0) + (parseFloat(hostelFee) || 0) + (parseFloat(coachingFee) || 0) + (parseFloat(tiffinFee) || 0);
                $('#updateMonthlyFeesModalCalculatedClassFee').text('<?= $currency_symbol ?>' + totalFee.toFixed(2));

                if (!isNumeric(customClassFee) || customClassFee < 0) {
                    $('#updateMonthlyFeesModalCustomClassFee').addClass('is-invalid');
                } else {
                    $('#updateMonthlyFeesModalCustomClassFee').removeClass('is-invalid');
                }

                if (!isNumeric(carFee) || carFee < 0) {
                    $('#updateMonthlyFeesModalCarFee').addClass('is-invalid');
                } else {
                    $('#updateMonthlyFeesModalCarFee').removeClass('is-invalid');
                }

                if (!isNumeric(hostelFee) || hostelFee < 0) {
                    $('#updateMonthlyFeesModalHostelFee').addClass('is-invalid');
                } else {
                    $('#updateMonthlyFeesModalHostelFee').removeClass('is-invalid');
                }

                if (!isNumeric(coachingFee) || coachingFee < 0) {
                    $('#updateMonthlyFeesModalCoachingFee').addClass('is-invalid');
                } else {
                    $('#updateMonthlyFeesModalCoachingFee').removeClass('is-invalid');
                }

                if (!isNumeric(tiffinFee) || tiffinFee < 0) {
                    $('#updateMonthlyFeesModalTiffinFee').addClass('is-invalid');
                } else {
                    $('#updateMonthlyFeesModalTiffinFee').removeClass('is-invalid');
                }
            }
        );
    });

    // Function sort student rows
    function sortStudentRows() {
        var sortOption = $('#studentListSort').val();
        var $tbody = $('#studentListTable tbody');
        var $rows = $tbody.find('tr').get();

        $rows.sort(function(a, b) {
            var valA, valB;

            switch (sortOption) {
                case 'default':
                    // অরিজিনাল রিকোয়েস্ট অর্ডার অনুযায়ী সর্ট করবে
                    valA = parseInt($(a).data('original-index'));
                    valB = parseInt($(b).data('original-index'));
                    return valA - valB;

                case 'roll_no-asc':
                    valA = parseInt($(a).data('roll-no'));
                    valB = parseInt($(b).data('roll-no'));
                    return valA - valB;

                case 'roll_no-desc':
                    valA = parseInt($(a).data('roll-no'));
                    valB = parseInt($(b).data('roll-no'));
                    return valB - valA;

                case 'name-asc':
                    valA = $(a).data('name');
                    valB = $(b).data('name');
                    return valA.localeCompare(valB);

                case 'name-desc':
                    valA = $(a).data('name');
                    valB = $(b).data('name');
                    return valB.localeCompare(valA);

                case 'pending-asc':
                    valA = parseFloat($(a).data('pending'));
                    valB = parseFloat($(b).data('pending'));
                    return valA - valB;

                case 'pending-desc':
                    valA = parseFloat($(a).data('pending'));
                    valB = parseFloat($(b).data('pending'));
                    return valB - valA;

                case 'last_payment_asc': // Oldest date first
                    valA = parseInt($(a).data('last-payment'));
                    valB = parseInt($(b).data('last-payment'));
                    // Handle '0' (no payment) cases - push to bottom or top?
                    // Currently: 0 is treated as very old (1970). 
                    return valA - valB;

                case 'last_payment_desc': // Newest date first
                    valA = parseInt($(a).data('last-payment'));
                    valB = parseInt($(b).data('last-payment'));
                    return valB - valA;

                default:
                    return 0;
            }
        });

        // Re-append rows in the new order
        $.each($rows, function(index, row) {
            $tbody.append(row);
        });
    }

    // Function submit data
    function submitData() {
        let studentsPaymentData = [];

        $('#studentListTable tbody tr').each(function() {
            let studentId = $(this).data('student-id');
            let paymentAmount = $(this).find('.payment-amount-input').val();
            let paymentDate = $(this).find('.payment-date-input').val();

            studentsPaymentData.push({
                student_id: studentId,
                student_name: $(this).data('name'),
                payment_amount: paymentAmount,
                payment_date: paymentDate
            });
        });

        Swal.fire({
            icon: 'question',
            title: 'Verify Payment Data',
            html: `
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Payment Amount</th>
                                <th>Payment Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${buildPreSubmitTableBody(studentsPaymentData)}
                        </tbody>
                    </table>
                </div>
            `,
            showCancelButton: true,
            confirmButtonText: 'Submit',
            showLoaderOnConfirm: true,
            customClass: {
                confirmButton: 'btn btn-primary px-4 py-2',
                cancelButton: 'btn btn-secondary px-4 py-2',
                popup: 'rounded-4 shadow-lg'
            }
        }).then(function(result) {
            if (result.isConfirmed) {
                submitPaymentsData(studentsPaymentData);
            }
        });
    }

    // Function submit payments data
    function submitPaymentsData(studentsPaymentData) {
        $.ajax({
            url: '<?= BASE_URL ?>/api/admin/put/fees-x-payments/monthly/process-payments-entry-monthly.php',
            type: 'POST',
            data: {
                students_payment_data: JSON.stringify(studentsPaymentData)
            },
            dataType: 'json',
            beforeSend: function() {
                showLoadingAlert();
            },
            success: function(response) {
                Swal.close();
                if (response.success) {
                    // এখানে payment_history_ids পাস করা হলো
                    showSuccessAlertTable(response.success_processed, response.failed_processed, response.payment_history_ids);
                } else {
                    showErrorAlert(response.message);
                }
            },
            error: function(xhr) {
                console.error(xhr.responseText);
                showErrorAlert('Error processing payments. Report sent to technical support.');
                let errorMessage = "Page: " + window.location.href + "\n\n" + xhr.responseText;
                sendErrorReport(errorMessage);
            }
        });
    }

    // Function verify security pin
    function verifySecurityPin() {
        Swal.fire({
            title: 'Enter Security Pin',
            input: 'text', // Keep password type for masking
            inputAttributes: {
                autocapitalize: 'off',
                autofocus: 'true',
                // This is the key to stopping the "Saved Password" popup:
                autocomplete: 'one-time-code',
                name: 'my-unique-pin-field',
                style: '-webkit-text-security: disc;'
            },
            showCancelButton: false,
            confirmButtonText: 'Verify & Continue',
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: true,
            showLoaderOnConfirm: true,
            preConfirm: (inputPin) => {
                if (inputPin === '<?= $security_pin ?>') {
                    return true;
                } else {
                    toastr.error('Invalid security pin. Please try again.');
                    return false;
                }
            },
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-primary px-4 py-2',
                cancelButton: 'btn btn-danger px-4 py-2'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.close();
                toastr.success('Security pin verified.');
            }
        });
    }

    // Function build pre-submit table body
    function buildPreSubmitTableBody(studentsPaymentData) {
        let tableBody = '';
        studentsPaymentData.forEach(function(data) {
            tableBody += `
                <tr>
                    <td>${capitalize(data.student_name)}</td>
                    <td><?= $currency_symbol ?>${data.payment_amount}</td>
                    <td>${formatDate(data.payment_date)}</td>
                </tr>
            `;
        });
        return tableBody;
    }

    // Function show success alert
    function showSuccessAlertTable(success_processed, failed_processed, payment_history_ids = []) {
        let totalSuccess = success_processed.length;
        let totalFailed = failed_processed.length;

        let successTable = `
            <div class="table-responsive">
                <table class="table table-bordered table-sm">
                    <thead class="table-success">
                        <tr>
                            <th>Name</th>
                            <th>Message</th>
                            <th>Payment Amount</th>
                            <th>Wallet Credit</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${buildSuccessTableBody(success_processed)}
                    </tbody>
                </table>
            </div>
        `;

        let failedTable = `
            <div class="table-responsive">
                <table class="table table-bordered table-sm">
                    <thead class="table-danger">
                        <tr>
                            <th>Name</th>
                            <th>Message</th>
                            <th>Payment Amount</th>
                            <th>Wallet Credit</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${buildFailedTableBody(failed_processed)}
                    </tbody>
                </table>
            </div>
        `;

        Swal.fire({
            icon: 'success',
            title: 'Successfully Processed Payments',
            width: '600px',
            html: `
                <p><strong>Success:</strong> ${totalSuccess}</p>
                ${successTable}
                <p><strong>Failed:</strong> ${totalFailed}</p>
                ${failedTable}
            `,
            showCancelButton: false,
            // প্রিন্ট বাটন দেখানোর অপশন চালু করা হলো
            showDenyButton: payment_history_ids && payment_history_ids.length > 0,
            denyButtonText: '<i class="fas fa-print me-1"></i> Print',
            confirmButtonText: 'OK',
            allowOutsideClick: false,
            allowEscapeKey: false,
            buttonsStyling: false, // কাস্টম ক্লাসগুলো ঠিকমতো কাজ করার জন্য
            customClass: {
                confirmButton: 'btn btn-primary px-4 py-2 me-2',
                denyButton: 'btn btn-info px-4 py-2', // প্রিন্ট বাটনের ডিজাইন
                popup: 'rounded-4 shadow-lg'
            },
            // প্রিন্ট বাটনে ক্লিক করলে কী হবে তা নির্ধারণ করা
            preDeny: () => {
                let idsString = payment_history_ids.join(',');
                let printUrl = '<?= BASE_URL ?>/api/download/receipt/monthly-payment-receipt.php?ids=' + idsString;
                
                // নতুন ট্যাবে রসিদ প্রিন্ট করার পেজ ওপেন হবে
                window.open(printUrl, '_blank');
                
                // false রিটার্ন করার কারণে ডায়ালগ বক্সটি বন্ধ হবে না
                return false; 
            }
        }).then((result) => {
            // শুধুমাত্র OK বাটনে ক্লিক করলেই পেজ রিলোড হবে
            if (result.isConfirmed) {
                location.reload();
            }
        });
    }

    // Function build success table body
    function buildSuccessTableBody(success_processed) {
        let tableBody = '';
        success_processed.forEach(function(data) {
            tableBody += `
                <tr>
                    <td>${capitalize(data.student_name)}</td>
                    <td>${data.message}</td>
                    <td><?= $currency_symbol ?>${data.payment_amount}</td>
                    <td><?= $currency_symbol ?>${data.wallet_credit}</td>
                </tr>
            `;
        });
        return tableBody;
    }

    // Function build failed table body
    function buildFailedTableBody(failed_processed) {
        let tableBody = '';
        failed_processed.forEach(function(data) {
            tableBody += `
                <tr>
                    <td>${capitalize(data.student_name)}</td>
                    <td>${data.message}</td>
                    <td><?= $currency_symbol ?>${data.payment_amount}</td>
                    <td><?= $currency_symbol ?>${data.wallet_credit}</td>
                </tr>
            `;
        });
        return tableBody;
    }

    // Function to delete unpaid fee entry
    function deleteUnpaidFeeEntry(entryId, studentId) {

        let tr = $('#trow-' + studentId);
        let viewMoreBtn = tr.find('.more-details-btn');
        let studentName = tr.data('name');

        Swal.fire({
            title: 'Are you sure?',
            html: `This action cannot be undone! You are about to delete an unpaid monthly fee entry for <strong>${studentName.toUpperCase()}</strong>.`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-danger px-4 py-2',
                cancelButton: 'btn btn-primary px-4 py-2'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                // Proceed with deletion
                $.ajax({
                    url: '<?= BASE_URL ?>/api/admin/delete/fees-x-payments/delete-unpaid-fee-entry.php',
                    type: 'POST',
                    data: {
                        entry_id: entryId,
                        fees_type: 'monthly'
                    },
                    dataType: 'json',
                    beforeSend: function() {
                        showLoadingAlert('Deleting Fee Entry...', '<div class="spinner-border text-primary" role="status"></div>');
                    },
                    success: function(response) {
                        if (response.success) {
                            // Show success message
                            toastr.success(response.message);
                            Swal.close();

                            viewMoreBtn.click();
                        } else {
                            showErrorAlert(response.message);
                        }
                    },
                    error: function(xhr) {
                        showErrorAlert('An error occurred while deleting the fee entry.');
                        console.error(xhr.responseText);
                    }
                });
            } else {
                // Cancel deletion
                viewMoreBtn.click();
            }
        });
    }

    // Function to populate fee entry
    function populateFeeEntryModal(entryId, monthYear, studentId) {
        $.ajax({
            url: '<?= BASE_URL ?>/api/admin/get/student/get-student-info.php',
            type: 'POST',
            data: {
                student_id: studentId
            },
            dataType: 'json',
            beforeSend: function() {
                showLoadingAlert('Retrieving student details...');
            },
            success: function(response) {
                Swal.close();
                $('body').css('padding-right', '');
                $('body').removeClass('modal-open');

                if (response.success) {
                    let student_info = response.student_info;
                    editEntryStudentInfo = student_info;
                    $('#editMonthlyFeeEntryModalMonth').text(monthYear);
                    $('#editMonthlyFeeEntryModalTutionFee').val(student_info.tution_fee);
                    $('#editMonthlyFeeEntryModalCarFee').val(student_info.car_fee);
                    $('#editMonthlyFeeEntryModalHostelFee').val(student_info.hostel_fee);
                    $('#editMonthlyFeeEntryModalCoachingFee').val(student_info.coaching_fee);
                    $('#editMonthlyFeeEntryModalTiffinFee').val(student_info.tiffin_fee);
                    $('#editMonthlyFeeEntryModalDiscount').val('0');
                    let totalFee =
                        (parseFloat(student_info.tution_fee) || 0) +
                        (parseFloat(student_info.car_fee) || 0) +
                        (parseFloat(student_info.hostel_fee) || 0) +
                        (parseFloat(student_info.coaching_fee) || 0) +
                        (parseFloat(student_info.tiffin_fee) || 0);
                    $('#editMonthlyFeeEntryModalTotalAmount').text('<?= $currency_symbol ?>' + totalFee.toFixed(2));
                    $('#editMonthlyFeeEntryModalLabel').html('Edit Monthly Fee Entry for <b>' + capitalize(student_info.name) + '</b>');

                    $('#editMonthlyFeeEntryModal').modal('show');
                } else {
                    showErrorAlert(response.message);
                }
            },
            error: function(xhr) {
                showErrorAlert('An error occurred while retrieving the fee entry.');
                console.error(xhr.responseText);
                sendErrorReport(xhr.responseText);
            }
        });
    }

    function submitEditedUnpaidFeeData(studentsFeeData) {
        $.ajax({
            url: '<?= BASE_URL ?>/api/admin/put/fees-x-payments/monthly/submit-fees-request.php',
            method: 'POST',
            data: {
                studentsFeeData: JSON.stringify(studentsFeeData)
            },
            dataType: 'json',
            beforeSend: function() {
                showLoadingAlert('Submitting fee request...');
            },
            success: function(response) {
                Swal.close();
                if (response.success) {
                    toastr.success(response.message);
                    showDetailedResultModal(response);
                    console.log(response);
                } else {
                    showErrorAlert(response.message);
                }
            },
            error: function(xhr) {
                console.error(xhr.responseText);
                showErrorAlert('Error submitting fee request. Report sent to technical support.');
                let errorMessage = "Page: " + window.location.href + "\n\n" + xhr.responseText;
                sendErrorReport(errorMessage);
            }
        });
    }

    // Function to show the detailed result modal
    function showDetailedResultModal(response) {
        // 1. Build the top summary badges
        let html = `
        <div class="mb-3 text-center d-flex justify-content-center gap-3">
            <span class="badge bg-secondary fs-6 py-2 px-3 shadow-sm">Total: ${response.total_records}</span>
            <span class="badge bg-success fs-6 py-2 px-3 shadow-sm">Processed: ${response.processed}</span>
            <span class="badge bg-danger fs-6 py-2 px-3 shadow-sm">Skipped: ${response.skipped}</span>
        </div>
        
        <div class="table-responsive text-start border rounded-3 shadow-sm" style="max-height: 60vh; overflow-y: auto; scrollbar-width: thin;">
            <table class="table table-sm table-hover align-middle mb-0" style="font-size: 0.85rem;">
                <thead class="table-light sticky-top" style="z-index: 1;">
                    <tr>
                        <th class="py-2 px-3">Student</th>
                        <th class="py-2">Month</th>
                        <th class="py-2">Status</th>
                        <th class="py-2 px-3">Remarks / Details</th>
                    </tr>
                </thead>
                <tbody>`;

        // 3. Loop through the backend results array
        if (response.results && response.results.length > 0) {
            response.results.forEach(item => {
                let statusBadge = '';
                let rowClass = '';
                let textClass = 'text-muted';

                if (item.action === 'created') {
                    statusBadge = '<span class="badge bg-success"><i class="fas fa-check me-1"></i>Created</span>';
                } else if (item.action === 'updated') {
                    statusBadge = '<span class="badge bg-info text-dark"><i class="fas fa-sync-alt me-1"></i>Updated</span>';
                } else {
                    statusBadge = '<span class="badge bg-danger"><i class="fas fa-times me-1"></i>Skipped</span>';
                    rowClass = 'table-danger bg-opacity-10';
                    textClass = 'text-danger fw-bold';
                }

                html += `
                <tr class="${rowClass}">
                    <td class="px-3 fw-bold text-nowrap">${item.name} <br><small class="text-muted fw-normal">ID: ${item.student_id}</small></td>
                    <td class="text-nowrap">${item.month_year}</td>
                    <td>${statusBadge}</td>
                    <td class="px-3"><small class="${textClass}">${item.message}</small></td>
                </tr>`;
            });
        } else {
            html += `<tr><td colspan="4" class="text-center py-3 text-muted">No detailed results available.</td></tr>`;
        }

        html += `</tbody></table></div>`;

        // 4. Trigger the SweetAlert
        Swal.fire({
            title: '<i class="fas fa-clipboard-list text-primary me-2"></i> Submission Report',
            html: html,
            icon: response.skipped > 0 ? 'warning' : 'success', // Use warning icon if anything was skipped
            width: '900px', // Wide enough for the table
            confirmButtonText: '<i class="fas fa-check-circle me-1"></i> Acknowledge & Close',
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-primary px-4'
            },
            buttonsStyling: false
        }).then((result) => {
            // Optional: Clean up the UI after they close the modal
            if (result.isConfirmed || result.isDismissed) {
                // --- পেজ রিফ্রেশ না করে ওই স্টুডেন্টের ডেটা আবার ফেচ করার জন্য বাটন ক্লিক সিমুলেট করা ---
                let studentId = editEntryStudentInfo.student_id;
                $('#trow-' + studentId).find('.more-details-btn').click();
            }
        });
    }

    function populateMonthSelection() {

        const now = new Date();
        const currentYear = now.getFullYear();

        $('.feeMonthSelect').empty();

        for (let monthIndex = 0; monthIndex < 12; monthIndex++) {

            const date = new Date(currentYear, monthIndex, 1);

            const month = date.toLocaleString('default', {
                month: 'long'
            });

            const value = `${month} ${currentYear}`;

            $('.feeMonthSelect').each(function() {

                const option = document.createElement('option');
                option.value = value;
                option.textContent = value;

                // Select current month false
                if (monthIndex === now.getMonth()) {
                    option.selected = false;
                }

                $(this).append(option);
            });
        }
    }

    // Function to show updateMonthlyFeesModal
    function showUpdateMonthlyFeesModal() {
        if (!studentFinancialOverview) {
            toastr.error('Student\'s financial details not found.');
            return;
        }

        let studentName = studentFinancialOverview.student_name;
        let className = studentFinancialOverview.class_name;
        let sectionName = studentFinancialOverview.section_name || '';
        let rollNo = studentFinancialOverview.roll_no || '';

        let classFee = studentFinancialOverview.class_fee;
        let customClassFee = studentFinancialOverview.custom_class_fee;
        let carFee = studentFinancialOverview.car_fee;
        let hostelFee = studentFinancialOverview.hostel_fee;
        let coachingFee = studentFinancialOverview.coaching_fee;
        let tiffinFee = studentFinancialOverview.tiffin_fee;
        let monthlyFee = studentFinancialOverview.monthly_fee;

        $('#updateMonthlyFeesModalStudentName').text(`${studentName}`);
        $('#updateMonthlyFeesModalClassInfo').html(`${className} - ${sectionName} (Roll: ${rollNo})`);
        $('#updateMonthlyFeesModalRegularClassFee').text(`${className}: <?= $currency_symbol ?>${classFee}`);
        $('#updateMonthlyFeesModalCalculatedClassFee').text(`<?= $currency_symbol ?>${monthlyFee}`);
        $('#updateMonthlyFeesModalCustomClassFee').val(customClassFee);
        $('#updateMonthlyFeesModalCarFee').val(carFee);
        $('#updateMonthlyFeesModalHostelFee').val(hostelFee);
        $('#updateMonthlyFeesModalCoachingFee').val(coachingFee);
        $('#updateMonthlyFeesModalTiffinFee').val(tiffinFee);

        $('#updateMonthlyFeesModal').modal('show');
    }

    // Function to show detailed result for Update Monthly Fees
    function showUpdateFeeDetailedResult(response, studentId) {

        // ব্যাকএন্ড থেকে আসা ডেটাগুলো ভেরিয়েবলে নেওয়া হলো
        let updatedMonths = response.updated_months || [];
        let skippedMonths = response.skipped_months || [];

        let html = `
        <div class="mb-3 text-center d-flex justify-content-center gap-3">
            <span class="badge bg-success fs-6 py-2 px-3 shadow-sm">Updated: ${updatedMonths.length}</span>
            <span class="badge bg-danger fs-6 py-2 px-3 shadow-sm">Skipped: ${skippedMonths.length}</span>
        </div>`;

        // যদি permanent_change true হয়
        if (response.permanently_changed) {
            html += `<div class="alert alert-info py-2 text-start"><i class="fas fa-info-circle me-1"></i> Student base fees updated permanently.</div>`;
        }

        html += `
        <div class="table-responsive text-start border rounded-3 shadow-sm" style="max-height: 50vh; overflow-y: auto; scrollbar-width: thin;">
            <table class="table table-sm table-hover align-middle mb-0" style="font-size: 0.85rem;">
                <thead class="table-light sticky-top" style="z-index: 1;">
                    <tr>
                        <th class="py-2 px-3">Month</th>
                        <th class="py-2">Status</th>
                        <th class="py-2 px-3">Details / Reason</th>
                    </tr>
                </thead>
                <tbody>`;

        if (updatedMonths.length > 0 || skippedMonths.length > 0) {
            // Updated Months রেন্ডার করা
            updatedMonths.forEach(item => {
                html += `
                <tr>
                    <td class="px-3 fw-bold text-nowrap">${item.month_year}</td>
                    <td><span class="badge bg-success"><i class="fas fa-check me-1"></i>Updated</span></td>
                    <td class="px-3"><small class="text-muted">New Fee: <b><?= $currency_symbol ?>${item.actual_amount}</b><br>New Pending: <?= $currency_symbol ?>${item.unpaid_amount}</small></td>
                </tr>`;
            });

            // Skipped Months রেন্ডার করা
            skippedMonths.forEach(item => {
                html += `
                <tr class="table-danger bg-opacity-10">
                    <td class="px-3 fw-bold text-nowrap">${item.month_year}</td>
                    <td><span class="badge bg-danger"><i class="fas fa-times me-1"></i>Skipped</span></td>
                    <td class="px-3"><small class="text-danger fw-bold">${item.reason}</small></td>
                </tr>`;
            });
        } else {
            html += `<tr><td colspan="3" class="text-center py-3 text-muted">No specific month records were modified.</td></tr>`;
        }

        html += `</tbody></table></div>`;

        // SweetAlert কল করা
        Swal.fire({
            title: '<i class="fas fa-clipboard-check text-success me-2"></i> Update Report',
            html: html,
            icon: skippedMonths.length > 0 ? 'warning' : 'success',
            width: '800px',
            confirmButtonText: '<i class="fas fa-sync-alt me-1"></i> Close & Refresh',
            allowOutsideClick: false,
            allowEscapeKey: false,
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-primary px-4'
            },
            buttonsStyling: false
        }).then((result) => {
            // ইউজার যখন মোডালটি বন্ধ করবেন, তখন ব্যাকগ্রাউন্ড ডেটা রিফ্রেশ হবে
            if (result.isConfirmed || result.isDismissed) {
                let tr = $('#trow-' + studentId);
                let viewMoreBtn = tr.find('.more-details-btn');
                viewMoreBtn.trigger('click');
            }
        });
    }
</script>

<?php include_once("../../../includes/body-close.php"); ?>