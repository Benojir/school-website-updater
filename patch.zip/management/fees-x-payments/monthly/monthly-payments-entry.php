<?php

/** @var PDO $pdo
 * @var string $school_name
 * @var array $additional_website_configs
 */

// -----------------------------------------------------------------------//
//              THIS PAGE IS FOR MONTHLY FEES PAYMENTS ENTRY              //
// -----------------------------------------------------------------------//

include_once("../../../includes/auth-check.php");
require_once("../../../includes/header-open.php");
echo "<title>Collect Fees (Monthly) - " . $school_name . "</title>";
require_once("../../../includes/header-close.php");
require_once("../../../includes/dashboard-navbar.php");

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    include_once("../../../includes/permission-denied.php");
}

$authSession = getAuthenticatedAdmin($pdo);
$security_pin = $authSession['security_pin'];


$student_ids_string = trim($_REQUEST['student_ids'] ?? '');

// Opening this page with no student_ids is the "Quick Collect" entry point: the table starts empty
// and the admin pulls students in one at a time using the Quick Add search box. Arriving with
// student_ids (the "Collect Fees" action on the students list) keeps the original bulk behaviour.
$student_ids = $student_ids_string === '' ? [] : explode(',', $student_ids_string);
$student_ids = array_values(array_filter(array_map('trim', $student_ids), fn($id) => $id !== ''));

$filtered_student_ids = [];
$students_without_dues = [];

// Fetch class wise fees
$stmt = $pdo->prepare("SELECT class_id, amount FROM class_wise_monthly_fees");
$stmt->execute();
$class_wise_fees = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// Block this page if there are no class-wise fees setup
if (empty($class_wise_fees)) {
    echo "<div class='container mt-4'><div class='alert alert-danger'>No class-wise fees setup.</div></div>";
    include_once("../../../includes/body-close.php");
    exit;
}

?>
<style>
    .table>thead>tr>th {
        vertical-align: middle !important;
        text-align: center;
    }

    .table thead th {
        position: relative;
    }

    .table tbody td {
        vertical-align: middle !important;
        text-align: center;
    }

    .table tbody td img {
        border-radius: 5px;
        width: 50px;
        object-fit: cover;
        cursor: pointer;
        border: 1px solid #ddd;
    }
</style>

<div class="container-fluid mt-4">

    <div class="card shadow-sm mb-4">
        <div class="card-header d-flex justify-content-between align-items-center bg-primary text-white">
            <div>
                <h4 class="mb-0"><i class="fas fa-money-bill me-2"></i>Collect Fees (Monthly)</h4>
            </div>
            <div>
                <button type="button" class="btn btn-sm btn-danger" onclick="window.close()">
                    <i class="fas fa-window-close me-2"></i>Close Tab
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="my-1">
                <div class="alert alert-primary d-flex mb-2 align-items-center gap-2 hide" role="alert" id="no-due-students-alert">
                    <p class="m-0 p-0">Total Students Without Any Dues: <span class="fw-bold ms-1" id="total_students_without_dues"></span></p>
                    <button class="btn btn-sm btn-info ms-2" id="showStudentsWithoutDues">See Details</button>
                </div>
                <div class="mb-3">
                    <h5>Total Students: <span id="total_students_payment_entry"></span></h5>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6 mb-2">
                        <input type="text" id="studentSearchBox" class="form-control" placeholder="Search students... (CTRL+ /)" />
                    </div>
                    <div class="col-md-6">
                        <select id="studentListSort" class="form-select">
                            <option value="default" selected>Default (Requested Order)</option>
                            <option value="roll_no-asc">Roll (Low to High)</option>
                            <option value="roll_no-desc">Roll (High to Low)</option>
                            <option value="name-asc">Sort by Name (A-Z)</option>
                            <option value="name-desc">Sort by Name (Z-A)</option>
                            <option value="pending-asc">Sort by Pending Amount (Low to High)</option>
                            <option value="pending-desc">Sort by Pending Amount (High to Low)</option>
                            <option value="last_payment_asc">Sort by Last Payment Date (Old to New)</option>
                            <option value="last_payment_desc">Sort by Last Payment Date (New to Old)</option>
                        </select>
                    </div>
                </div>
                <div class="card border-primary mb-3">
                    <div class="card-body py-3">
                        <label for="quickAddStudent" class="form-label fw-bold mb-2">
                            <i class="fas fa-bolt text-warning me-1"></i> Quick Add Student
                            <small class="text-muted fw-normal ms-1">(name, ID, roll, phone or guardian)</small>
                        </label>
                        <select id="quickAddStudent" class="form-select"></select>
                        <div class="form-text">
                            Picking a student adds them below with the <b>Pay Amount already filled to their pending due</b>.
                            Use that row's <i class="fas fa-hand-holding-dollar text-success"></i> button to collect just that
                            student straight away, or fill several rows and use <b>Save Payments Entry</b>.
                        </div>
                    </div>
                </div>

                <div class="mb-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <div id="collectionSummary" class="fw-bold text-primary">
                        <i class="fas fa-calculator me-1"></i>
                        <span id="collectionSummaryText">Nothing entered yet</span>
                    </div>
                    <button id="processPaymentsBtn" class="btn btn-primary">Save Payments Entry</button>
                </div>
                <div id="emptyTableNotice" class="alert alert-secondary text-center d-none">
                    <i class="fas fa-arrow-up me-1"></i>
                    No students in the list yet &mdash; use <b>Quick Add Student</b> above to pull one in.
                </div>
                <div class="table-responsive rounded-2">
                    <table class="table table-bordered table-striped" id="studentListTable">
                        <thead class="table-dark">
                            <tr>
                                <th><i class="fas fa-user"></i></th>
                                <th>Image</th>
                                <th>Student Name</th>
                                <th>Fees Details</th>
                                <th>Offer Amount</th>
                                <th>Pending Amount</th>
                                <th>Total Month</th>
                                <th>Pay Amount</th>
                                <th>Discount</th>
                                <th>Payment Date</th>
                                <th>Last Payment</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($student_ids as $index => $student_id):
                                // Skip duplicates up front - the shared row template below runs
                                // several queries per student, so there is no point repeating them.
                                if (in_array($student_id, $filtered_student_ids)) {
                                    continue;
                                }

                                $row_index = $index;

                                // Shared with the Quick Add search endpoint so a row added by search
                                // is identical to a row rendered here. See the partial's header.
                                include(__DIR__ . "/../../../includes/financial/monthly-payment-entry-row.php");

                                if (!$row_rendered) {
                                    continue;
                                }

                                $filtered_student_ids[] = $student_id;

                                if ($row_is_no_due) {
                                    $students_without_dues[] = $row_no_due_info;
                                }
                            endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Include the modal html -->
<?php include_once('../../../includes/modals/fees-x-payments/financial-details-modal.php'); ?>
<?php include_once('../../../includes/modals/fees-x-payments/no-due-students-modal.php'); ?>
<?php include_once('../../../includes/modals/fees-x-payments/edit-monthly-fee-entry-modal.php'); ?>
<?php include_once('../../../includes/modals/fees-x-payments/permanent-monthly-fee-edit-modal.php'); ?>

<script>
    let filteredStudentIds = <?= json_encode($filtered_student_ids) ?>;
    let editEntryStudentInfo = {};
    let studentFinancialOverview = null;
    let hasUnsavedChanges = false;
    // data-original-index for rows added later, so the "Default (Requested Order)"
    // sort keeps freshly added students at the bottom of the list
    let nextRowIndex = filteredStudentIds.length;

    $('#total_students_payment_entry').text(filteredStudentIds.length);
    $('#student_ids_input').val(filteredStudentIds.join(','));

    $(document).ready(function() {
        populateMonthSelection();
        updateCollectionSummary();
        toggleEmptyTableNotice();
        initQuickAddStudentSearch();
        // $('#updateMonthlyFeesModal').modal('show');

        // Bootstrap Multiselect
        $('.bts-multiselect').multiselect({
            templates: {
                button: '<button type="button" class="multiselect dropdown-toggle form-select form-select-lg shadow-sm" style="text-align: left !important;" data-bs-toggle="dropdown" data-bs-config=\'{"popperConfig": {"strategy": "fixed"}}\' aria-expanded="false"><span class="multiselect-selected-text"></span></button>',
                filter: '<li class="multiselect-item filter"><div class="input-group p-2"><span class="input-group-text"><i class="fas fa-search"></i></span><input type="text" class="form-control multiselect-search" placeholder="Search..."><span class="input-group-text" style="cursor:pointer;"><i class="fas fa-times multiselect-clear-filter"></i></span></div></li>',
            },
            buttonWidth: '100%',
            includeSelectAllOption: true,
            nonSelectedText: 'Select month(s)',
            enableCaret: false,
            enableFiltering: true,
            enableCaseInsensitiveFiltering: true,
            maxHeight: 300
        });

        // Fix dropdown width for fixed positioned menus inside table-responsive
        $(document).on('show.bs.dropdown', '.multiselect-native-select .btn-group', function() {
            // Get the exact pixel width of the button
            let buttonWidth = $(this).outerWidth();

            // Apply that strict pixel width to the dropdown menu
            $(this).find('.dropdown-menu').css({
                'width': buttonWidth + 'px',
                'min-width': buttonWidth + 'px',
                'max-width': buttonWidth + 'px'
            });
        });

        // যেকোনো ইনপুট বা টেক্সট এরিয়া পরিবর্তন হলে
        $(document).on('input change', 'input, textarea, select', function() {
            hasUnsavedChanges = true;
        });

        // ট্যাব বন্ধ করার সময়
        $(window).on('beforeunload', function() {
            if (hasUnsavedChanges) {
                // jQuery তে ব্রাউজারকে ডায়ালগ দেখাতে শুধু কিছু রিটার্ন করলেই হয়
                return 'Your changes have not been saved. Are you sure you want to leave?';
            }
        });

        // Sticky Table Header using jQuery
        $(window).on('scroll', function() {
            var tableContainer = $('.table-responsive');
            var thead = $('#studentListTable thead th');
            var containerTop = tableContainer.offset().top;
            var windowTop = $(window).scrollTop();

            if (windowTop > containerTop) {
                // স্ক্রল করার সময় হেডারটিকে নিচে নামিয়ে আনবে
                var scrollDistance = windowTop - containerTop;
                thead.css({
                    'transform': 'translateY(' + scrollDistance + 'px)',
                    'background-color': '#212529', // ব্যাকগ্রাউন্ড কালার ডার্ক রাখার জন্য
                    'z-index': '10',
                    'position': 'relative'
                });
            } else {
                // স্ক্রল করে উপরে ফিরে গেলে আগের অবস্থায় (ডিফল্ট) ফিরে যাবে
                thead.css({
                    'transform': 'translateY(0)'
                });
            }
        });

        // Verify security pin before accessing the page
        <?php
        if ($additional_website_configs['need_security_pin_for_payment_entry'] == 1) {
            echo "verifySecurityPin();";
        }
        ?>

        // Select Text on Input Focus
        $(document).on('focus', 'input', function() {
            this.select();
        });

        // Total Month Input Change
        $(document).on('input', '.total-month-input', function() {
            let monthlyFee = $(this).closest('tr').data('monthly-fee');
            let totalMonths = parseFloat($(this).val()) || 0;

            if (!isNumeric($(this).val())) {
                $(this).addClass('is-invalid');
                $('#processPaymentsBtn').prop('disabled', true);
            } else {
                $(this).removeClass('is-invalid');
                $('#processPaymentsBtn').prop('disabled', false);
            }

            let totalAmount = monthlyFee * totalMonths;
            $(this).closest('tr').find('.payment-amount-input').val(totalAmount);

            setTimeout(() => {
                $(this).closest('tr').find('.payment-amount-input').trigger('input');
            }, 1500);
        });

        // Up/Down Arrow Key Navigation on Total Month Input
        $(document).on('keydown', '.total-month-input', function(e) {
            // Down Arrow (Key code: 40)
            if (e.which === 40 || e.key === 'ArrowDown') {
                e.preventDefault(); // ব্রাউজারের ডিফল্ট স্ক্রল বা কার্সার মুভমেন্ট বন্ধ করতে
                let nextRow = $(this).closest('tr').next('tr:visible');
                if (nextRow.length > 0) {
                    nextRow.find('.total-month-input').focus();
                }
            }
            // Up Arrow (Key code: 38)
            else if (e.which === 38 || e.key === 'ArrowUp') {
                e.preventDefault();
                let prevRow = $(this).closest('tr').prev('tr:visible');
                if (prevRow.length > 0) {
                    prevRow.find('.total-month-input').focus();
                }
            }
        });

        // Focus on payment amount input
        // $('.payment-amount-input').on('focus', function() {
        //     this.select();
        // });

        $(document).on('input', '.payment-amount-input', function() {
            let $row = $(this).closest('tr');
            let monthlyFee = parseFloat($row.data('monthly-fee')) || 0;
            let inputAmount = parseFloat($(this).val()) || 0;

            if (!isNumeric($(this).val())) {
                $(this).addClass('is-invalid');
                $('#processPaymentsBtn').prop('disabled', true);
            } else {
                $(this).removeClass('is-invalid');
                $('#processPaymentsBtn').prop('disabled', false);
            }

            // আপনার আগের মাসের হিসাব লজিক
            let calculatedMonths = monthlyFee > 0 ? (inputAmount / monthlyFee) : 0;
            $row.find('.total-month-input').val(calculatedMonths.toFixed(2));
            $row.find('.total-month-input').removeClass('is-invalid');

            // --- নতুন লজিক: রিয়েল-টাইম পেমেন্ট হিসাব ---
            renderPaymentProjection($row);
            updateCollectionSummary();
        });

        // Up/Down Arrow Key Navigation (নতুন যুক্ত করা কোড)
        $(document).on('keydown', '.payment-amount-input', function(e) {
            // Down Arrow (Key code: 40)
            if (e.which === 40 || e.key === 'ArrowDown') {
                e.preventDefault(); // ব্রাউজারের ডিফল্ট স্ক্রল বা কার্সার মুভমেন্ট বন্ধ করতে
                let nextRow = $(this).closest('tr').next('tr:visible');
                if (nextRow.length > 0) {
                    nextRow.find('.payment-amount-input').focus();
                }
            }
            // Up Arrow (Key code: 38)
            else if (e.which === 38 || e.key === 'ArrowUp') {
                e.preventDefault();
                let prevRow = $(this).closest('tr').prev('tr:visible');
                if (prevRow.length > 0) {
                    prevRow.find('.payment-amount-input').focus();
                }
            }
        });

        // Discount Input Change.
        // The discount is granted on the OLDEST pending month only and must stay strictly below
        // that month's due, so a discount can never settle a month on its own. Anything else is
        // refused and the field is reset, which keeps the entry unambiguous.
        $(document).on('input', '.discount-amount-input', function() {
            let $input = $(this);
            let $row = $input.closest('tr');

            if (!isNumeric($input.val()) || parseFloat($input.val()) < 0) {
                $input.addClass('is-invalid');
                $('#processPaymentsBtn').prop('disabled', true);
                return;
            }

            $input.removeClass('is-invalid');
            $('#processPaymentsBtn').prop('disabled', false);

            if (validateDiscountInput($row, true)) {
                renderPaymentProjection($row);
            }

            updateCollectionSummary();
        });

        // Up/Down Arrow Key Navigation on Discount Input
        $(document).on('keydown', '.discount-amount-input', function(e) {
            if (e.which === 40 || e.key === 'ArrowDown') {
                e.preventDefault();
                let nextRow = $(this).closest('tr').next('tr:visible');
                if (nextRow.length > 0) {
                    nextRow.find('.discount-amount-input').focus();
                }
            } else if (e.which === 38 || e.key === 'ArrowUp') {
                e.preventDefault();
                let prevRow = $(this).closest('tr').prev('tr:visible');
                if (prevRow.length > 0) {
                    prevRow.find('.discount-amount-input').focus();
                }
            }
        });

        // Focus and select on #studentSearchBox when pressed CTRL + /
        $(document).on('keydown', function(e) {
            if (e.ctrlKey && e.key === '/') {
                e.preventDefault();
                $('#studentSearchBox').focus();
                $('#studentSearchBox').select();
            }
        })

        // Remove Student from List
        $(document).on('click', '.remove-student-btn', function() {
            removeStudentRow($(this).data('student-id'));
        });

        // Collect just this one row straight away (walk-up counter flow).
        // Posts a single-student array to the same endpoint the batch Save button uses.
        $(document).on('click', '.collect-single-btn', function() {
            collectSingleRow($(this).closest('tr'));
        });

        // --- 1. Client-Side Search Functionality ---
        $('#studentSearchBox').on('keyup', function() {
            var value = $(this).val().toLowerCase();
            $("#studentListTable tbody tr").filter(function() {
                // Toggle visibility based on whether the row text contains the search term
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });

        // --- 2. Client-Side Sort Functionality ---
        sortStudentRows(); // Initial sort
        $('#studentListSort').on('change', function() {
            sortStudentRows();
        });

        // --- 3. Show Student Financial Details in Modal ---
        $(document).on('click', '.more-details-btn', function() {
            const studentId = $(this).data('student-id');
            const studentName = capitalize($(this).closest('tr').data('name'));
            const studentClass = $(this).closest('tr').data('class-name');
            const studentRoll = $(this).closest('tr').data('roll-no') || '';

            $('#studentFinancialDetailsModalLabel').html(`<b>${studentName}</b> (Roll: ${studentRoll}, Class: ${studentClass})`);

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/get/fees-x-payments/monthly/get-student-financial-overview.php',
                type: 'POST',
                data: {
                    student_id: studentId
                },
                dataType: 'json',
                beforeSend: function() {
                    showLoadingAlert('Fetching student financial details...');
                },
                success: function(response) {
                    Swal.close();
                    $('body').css('padding-right', '');
                    $('body').removeClass('modal-open');

                    if (response.success) {
                        studentFinancialOverview = response;
                        const unpaidFeesTable = response.unpaid_fees_table;
                        const paidFeesTable = response.paid_fees_table;
                        const fullHtml = unpaidFeesTable + paidFeesTable;

                        $('#studentFinancialDetailsModalBody').html(fullHtml);
                        $('#studentFinancialDetailsModal').modal('show');

                        // --- নতুন কোড: মেইন টেবিলের রো (Row) রিয়েল-টাইমে আপডেট করা ---
                        let $row = $('#trow-' + studentId);

                        // ডাটা এট্রিবিউট আপডেট (যাতে পেমেন্ট ক্যালকুলেশনে নতুন ডেটা ব্যবহার হয়)
                        $row.attr('data-unpaid-months', JSON.stringify(response.unpaid_months_list));
                        $row.data('unpaid-months', response.unpaid_months_list);

                        $row.attr('data-pending', response.total_unpaid_amount);
                        $row.data('pending', response.total_unpaid_amount);

                        $row.attr('data-monthly-fee', response.monthly_fee);
                        $row.data('monthly-fee', response.monthly_fee);

                        $row.attr('data-advance-start', response.advance_start_month);
                        $row.data('advance-start', response.advance_start_month);

                        // টেক্সট আপডেট
                        $row.find('.row-pending-amount').text('<?= $currency_symbol ?>' + response.total_unpaid_amount);
                        $row.find('.row-pending-months').text(response.unpaid_months_text);

                        // যদি ইতোমধ্যে কোনো পেমেন্ট এমাউন্ট লেখা থাকে, তবে প্রজেকশন পুনরায় ক্যালকুলেট করার জন্য ট্রিগার করুন
                        let currentInput = $row.find('.payment-amount-input').val();
                        if (parseFloat(currentInput) > 0) {
                            $row.find('.payment-amount-input').trigger('input');
                        }

                        // The pending months just changed, so a discount typed earlier may no longer
                        // sit below the oldest month's due. Revalidate quietly, then re-project.
                        if (validateDiscountInput($row, false)) {
                            renderPaymentProjection($row);
                        }
                        // ২. UI-তে Pending Amount এবং Months Text আপডেট করা
                        $row.find('.row-pending-amount').text('<?= $currency_symbol ?>' + response.total_unpaid_amount);
                        $row.find('.row-pending-months').text(response.unpaid_months_text);

                        // --- নতুন যোগ করা কোড: Fees Details এবং Offer Amount রিয়েল-টাইম আপডেট ---
                        $row.find('.row-monthly-fee').text('<?= $currency_symbol ?>' + response.monthly_fee);
                        $row.find('.row-average-monthly').text('<?= $currency_symbol ?>' + response.average_monthly_fee);
                        $row.find('.row-total-actual').text('<?= $currency_symbol ?>' + response.total_actual_amount);
                        $row.find('.row-total-discount').text('<?= $currency_symbol ?>' + response.total_discount_amount);
                        $row.find('.row-offer-amount').text('<?= $currency_symbol ?>' + response.total_offer_amount);
                        // --- নতুন যোগ করা কোড শেষ ---

                    } else {
                        showErrorAlert(response.message);
                        studentFinancialOverview = null;
                    }
                },
                error: function(xhr) {
                    console.error(xhr.responseText);
                    showErrorAlert('Error fetching student financial details');
                    studentFinancialOverview = null;
                }
            });
        });

        // --- 4. Show alert div for no due students ---
        let totalStudentsWithouDue = <?= count($students_without_dues) ?>;
        if (totalStudentsWithouDue > 0) {
            $('#no-due-students-alert').removeClass('d-none');
            $('#total_students_without_dues').html(totalStudentsWithouDue);

            <?php
            $tableBody = '';
            foreach ($students_without_dues as $student) {
                $studentName = $student['name'];
                $className = $student['class_name'];
                $sectionName = $student['section_name'];
                $rollNo = $student['roll_no'];

                $tableBody .= "<tr>
                    <td>{$studentName}</td>
                    <td>{$rollNo}</td>
                    <td>{$className}</td>
                    <td>{$sectionName}</td>
                </tr>";
            }
            ?>

            let tableBody = `<?php echo $tableBody; ?>`;
            $('#noDueStudentsModalTableBody').html(tableBody);
        } else {
            $('#no-due-students-alert').addClass('d-none');
        }

        $('#showStudentsWithoutDues').click(function() {
            $('#noDueStudentsModal').modal('show');
        });

        // --- 5. Submit form data ---
        $('#processPaymentsBtn').click(function() {
            submitData();
            hasUnsavedChanges = false;
        });

        // Check real time changes of edit entry modal
        $(document).on('input',
            '#editMonthlyFeeEntryModalTutionFee, #editMonthlyFeeEntryModalCarFee, #editMonthlyFeeEntryModalHostelFee, #editMonthlyFeeEntryModalCoachingFee, #editMonthlyFeeEntryModalTiffinFee, #editMonthlyFeeEntryModalDiscount',
            function() {

                let tutionFee = $('#editMonthlyFeeEntryModalTutionFee').val();
                let carFee = $('#editMonthlyFeeEntryModalCarFee').val();
                let hostelFee = $('#editMonthlyFeeEntryModalHostelFee').val();
                let coachingFee = $('#editMonthlyFeeEntryModalCoachingFee').val();
                let tiffinFee = $('#editMonthlyFeeEntryModalTiffinFee').val();
                let discount = $('#editMonthlyFeeEntryModalDiscount').val();

                let totalFee = (parseFloat(tutionFee) || 0) + (parseFloat(carFee) || 0) + (parseFloat(hostelFee) || 0) + (parseFloat(coachingFee) || 0) + (parseFloat(tiffinFee) || 0) - (parseFloat(discount) || 0);
                $('#editMonthlyFeeEntryModalTotalAmount').text('<?= $currency_symbol ?>' + totalFee.toFixed(2));

                if (!isNumeric(tutionFee) || tutionFee <= 0) {
                    $('#editMonthlyFeeEntryModalTutionFee').addClass('is-invalid');
                    toastr.error('Tution fee must be greater than 0.');
                } else {
                    $('#editMonthlyFeeEntryModalTutionFee').removeClass('is-invalid');
                }
                if (!isNumeric(carFee) || carFee < 0) {
                    $('#editMonthlyFeeEntryModalCarFee').addClass('is-invalid');
                    toastr.error('Car fee must be a number.');
                } else {
                    $('#editMonthlyFeeEntryModalCarFee').removeClass('is-invalid');
                }
                if (!isNumeric(hostelFee) || hostelFee < 0) {
                    $('#editMonthlyFeeEntryModalHostelFee').addClass('is-invalid');
                    toastr.error('Hostel fee must be a number.');
                } else {
                    $('#editMonthlyFeeEntryModalHostelFee').removeClass('is-invalid');
                }
                if (!isNumeric(coachingFee) || coachingFee < 0) {
                    $('#editMonthlyFeeEntryModalCoachingFee').addClass('is-invalid');
                    toastr.error('Coaching fee must be a number.');
                } else {
                    $('#editMonthlyFeeEntryModalCoachingFee').removeClass('is-invalid');
                }
                if (!isNumeric(tiffinFee) || tiffinFee < 0) {
                    $('#editMonthlyFeeEntryModalTiffinFee').addClass('is-invalid');
                    toastr.error('Tiffin fee must be a number.');
                } else {
                    $('#editMonthlyFeeEntryModalTiffinFee').removeClass('is-invalid');
                }
                if (!isNumeric(discount) || discount < 0) {
                    $('#editMonthlyFeeEntryModalDiscount').addClass('is-invalid');
                    toastr.error('Discount must be a number.');
                } else {
                    $('#editMonthlyFeeEntryModalDiscount').removeClass('is-invalid');
                }

                if (discount >= totalFee) {
                    $('#editMonthlyFeeEntryModalDiscount').val(0);

                    let tutionFee = $('#editMonthlyFeeEntryModalTutionFee').val();
                    let carFee = $('#editMonthlyFeeEntryModalCarFee').val();
                    let hostelFee = $('#editMonthlyFeeEntryModalHostelFee').val();
                    let coachingFee = $('#editMonthlyFeeEntryModalCoachingFee').val();
                    let tiffinFee = $('#editMonthlyFeeEntryModalTiffinFee').val();
                    let discount = $('#editMonthlyFeeEntryModalDiscount').val();
                    let totalFee = (parseFloat(tutionFee) || 0) + (parseFloat(carFee) || 0) + (parseFloat(hostelFee) || 0) + (parseFloat(coachingFee) || 0) + (parseFloat(tiffinFee) || 0) - (parseFloat(discount) || 0);
                    $('#editMonthlyFeeEntryModalTotalAmount').text('<?= $currency_symbol ?>' + totalFee.toFixed(2));
                    toastr.error('Discount amount cannot be greater than or equal to total amount.');
                }
            }
        );

        $(document).on('click', '#updateEditMonthlyFeeEntryBtn', function() {
            let tutionFee = $('#editMonthlyFeeEntryModalTutionFee').val();
            let carFee = $('#editMonthlyFeeEntryModalCarFee').val();
            let hostelFee = $('#editMonthlyFeeEntryModalHostelFee').val();
            let coachingFee = $('#editMonthlyFeeEntryModalCoachingFee').val();
            let tiffinFee = $('#editMonthlyFeeEntryModalTiffinFee').val();
            let discountAmount = $('#editMonthlyFeeEntryModalDiscount').val();
            let totalFee = (parseFloat(tutionFee) || 0) + (parseFloat(carFee) || 0) + (parseFloat(hostelFee) || 0) + (parseFloat(coachingFee) || 0) + (parseFloat(tiffinFee) || 0) - (parseFloat(discountAmount) || 0);

            if (!isNumeric(tutionFee) || tutionFee <= 0) {
                toastr.error('Tution fee must be greater than 0.');
                return;
            }

            if (!isNumeric(carFee) || carFee < 0) {
                toastr.error('Car fee must be a number.');
                return;
            }

            if (!isNumeric(hostelFee) || hostelFee < 0) {
                toastr.error('Hostel fee must be a number.');
                return;
            }

            if (!isNumeric(coachingFee) || coachingFee < 0) {
                toastr.error('Coaching fee must be a number.');
                return;
            }

            if (!isNumeric(tiffinFee) || tiffinFee < 0) {
                toastr.error('Tiffin fee must be a number.');
                return;
            }

            if (!isNumeric(discountAmount) || discountAmount < 0) {
                toastr.error('Discount must be a number.');
                return;
            }

            if (discountAmount >= totalFee) {
                toastr.error('Discount amount cannot be greater than or equal to total amount.');
                return;
            }

            if (!isNumeric(totalFee) || totalFee <= 0) {
                toastr.error('Total fee must be a number. It should be greater than 0.');
                return;
            }

            let studentId = editEntryStudentInfo.student_id;
            let studentName = editEntryStudentInfo.name;
            let classInfo = editEntryStudentInfo.class_name + ' (' + editEntryStudentInfo.section_name + ')';
            let rollNo = editEntryStudentInfo.roll_no;

            let actualFee = parseFloat(tutionFee) + parseFloat(carFee) + parseFloat(hostelFee) + parseFloat(coachingFee) + parseFloat(tiffinFee);

            let monthYear = [$('#editMonthlyFeeEntryModalMonth').text().trim()];

            let studentsData = [];

            studentsData.push({
                studentId: studentId,
                studentName: studentName,
                classInfo: classInfo,
                rollNo: rollNo,
                tutionFee: tutionFee,
                carFee: carFee,
                hostelFee: hostelFee,
                coachingFee: coachingFee,
                tiffinFee: tiffinFee,
                discountAmount: discountAmount,
                actualFee: actualFee,
                offerAmount: totalFee,
                monthYear: monthYear
            });

            submitEditedUnpaidFeeData(studentsData);
        });

        // Submit updateMonthlyFeesModal data
        $(document).on('click', '#updateMonthlyFeesModalUpdateBtn', function() {
            let studentId = studentFinancialOverview.student_id;
            let classFee = studentFinancialOverview.class_fee;
            let customClassFee = $('#updateMonthlyFeesModalCustomClassFee').val();
            let carFee = $('#updateMonthlyFeesModalCarFee').val();
            let hostelFee = $('#updateMonthlyFeesModalHostelFee').val();
            let coachingFee = $('#updateMonthlyFeesModalCoachingFee').val();
            let tiffinFee = $('#updateMonthlyFeesModalTiffinFee').val();
            let selectedMonths = $('#updateMonthlyFeesModalSelectedMonths').val();
            let permanentChange = $('#updateMonthlyFeesModalPermanentChangeCheckbox').is(':checked');

            if (!isNumeric(customClassFee) || customClassFee < 0) {
                $('#updateMonthlyFeesModalCustomClassFee').addClass('is-invalid');
                toastr.error('Custom class fee must be a number.');
                return;
            } else {
                $('#updateMonthlyFeesModalCustomClassFee').removeClass('is-invalid');
            }

            if (!isNumeric(carFee) || carFee < 0) {
                $('#updateMonthlyFeesModalCarFee').addClass('is-invalid');
                toastr.error('Car fee must be a number.');
                return;
            } else {
                $('#updateMonthlyFeesModalCarFee').removeClass('is-invalid');
            }

            if (!isNumeric(hostelFee) || hostelFee < 0) {
                $('#updateMonthlyFeesModalHostelFee').addClass('is-invalid');
                toastr.error('Hostel fee must be a number.');
                return;
            } else {
                $('#updateMonthlyFeesModalHostelFee').removeClass('is-invalid');
            }

            if (!isNumeric(coachingFee) || coachingFee < 0) {
                $('#updateMonthlyFeesModalCoachingFee').addClass('is-invalid');
                toastr.error('Coaching fee must be a number.');
                return;
            } else {
                $('#updateMonthlyFeesModalCoachingFee').removeClass('is-invalid');
            }

            if (!isNumeric(tiffinFee) || tiffinFee < 0) {
                $('#updateMonthlyFeesModalTiffinFee').addClass('is-invalid');
                toastr.error('Tiffin fee must be a number.');
                return;
            } else {
                $('#updateMonthlyFeesModalTiffinFee').removeClass('is-invalid');
            }

            let customizedData = {
                studentId: studentId,
                classFee: classFee,
                customClassFee: customClassFee,
                carFee: carFee,
                hostelFee: hostelFee,
                coachingFee: coachingFee,
                tiffinFee: tiffinFee,
                selectedMonths: selectedMonths,
                permanentChange: permanentChange
            };

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/put/fees-x-payments/monthly/update-monthly-fees-data.php',
                method: 'POST',
                data: {
                    financialData: JSON.stringify(customizedData)
                },
                beforeSend: function() {
                    showLoadingAlert('Updating fees data...');
                },
                success: function(response) {
                    if (response.success) {
                        // Update Modal টি বন্ধ করে দিন
                        $('#updateMonthlyFeesModal').modal('hide');

                        // বিস্তারিত রেসপন্স দেখানোর জন্য ফাংশনটি কল করুন
                        showUpdateFeeDetailedResult(response, studentId);

                    } else {
                        toastr.error(response.message);
                        showErrorAlert(response.message);
                        console.log(response.message);
                    }
                },
                error: function(e) {
                    toastr.error('Something went wrong.');
                    showErrorAlert('Something went wrong.');
                    sendErrorReport(e.responseText);
                    console.error(e.responseText);
                },
                complete: function() {
                    // সব সিলেক্ট করা ভ্যালু আনসিলেক্ট করে দেবে
                    $('#updateMonthlyFeesModalSelectedMonths').val([]);
                    // Bootstrap Multiselect-এর UI আপডেট করবে যাতে চেকমার্কগুলো উঠে যায়
                    $('#updateMonthlyFeesModalSelectedMonths').multiselect('refresh');
                }
            });
        });

        $(document).on('input',
            '#updateMonthlyFeesModalCustomClassFee, #updateMonthlyFeesModalCarFee, #updateMonthlyFeesModalHostelFee, #updateMonthlyFeesModalCoachingFee, #updateMonthlyFeesModalTiffinFee',
            function() {

                let customClassFee = $('#updateMonthlyFeesModalCustomClassFee').val();
                let tutionFee = (parseFloat(customClassFee) || 0) > 0 ? customClassFee : studentFinancialOverview.class_fee;
                let carFee = $('#updateMonthlyFeesModalCarFee').val();
                let hostelFee = $('#updateMonthlyFeesModalHostelFee').val();
                let coachingFee = $('#updateMonthlyFeesModalCoachingFee').val();
                let tiffinFee = $('#updateMonthlyFeesModalTiffinFee').val();

                let totalFee = (parseFloat(tutionFee) || 0) + (parseFloat(carFee) || 0) + (parseFloat(hostelFee) || 0) + (parseFloat(coachingFee) || 0) + (parseFloat(tiffinFee) || 0);
                $('#updateMonthlyFeesModalCalculatedClassFee').text('<?= $currency_symbol ?>' + totalFee.toFixed(2));

                if (!isNumeric(customClassFee) || customClassFee < 0) {
                    $('#updateMonthlyFeesModalCustomClassFee').addClass('is-invalid');
                } else {
                    $('#updateMonthlyFeesModalCustomClassFee').removeClass('is-invalid');
                }

                if (!isNumeric(carFee) || carFee < 0) {
                    $('#updateMonthlyFeesModalCarFee').addClass('is-invalid');
                } else {
                    $('#updateMonthlyFeesModalCarFee').removeClass('is-invalid');
                }

                if (!isNumeric(hostelFee) || hostelFee < 0) {
                    $('#updateMonthlyFeesModalHostelFee').addClass('is-invalid');
                } else {
                    $('#updateMonthlyFeesModalHostelFee').removeClass('is-invalid');
                }

                if (!isNumeric(coachingFee) || coachingFee < 0) {
                    $('#updateMonthlyFeesModalCoachingFee').addClass('is-invalid');
                } else {
                    $('#updateMonthlyFeesModalCoachingFee').removeClass('is-invalid');
                }

                if (!isNumeric(tiffinFee) || tiffinFee < 0) {
                    $('#updateMonthlyFeesModalTiffinFee').addClass('is-invalid');
                } else {
                    $('#updateMonthlyFeesModalTiffinFee').removeClass('is-invalid');
                }
            }
        );
    });

    // ---------------------------------------------------------------------
    // QUICK COLLECT
    // Lets an admin find a student from this page instead of going back to the
    // students list, and collect from a single row without saving the whole table.
    // ---------------------------------------------------------------------

    // Function to wire up the Quick Add student search box (Select2 remote source)
    function initQuickAddStudentSearch() {
        $('#quickAddStudent').select2({
            theme: 'bootstrap-5',
            width: '100%',
            placeholder: 'Start typing a name, student ID, roll no or phone number...',
            allowClear: true,
            minimumInputLength: 1,
            ajax: {
                url: '<?= BASE_URL ?>/api/admin/get/fees-x-payments/monthly/search-students-for-payment.php',
                dataType: 'json',
                delay: 250,
                data: function(params) {
                    return {
                        q: params.term
                    };
                },
                processResults: function(response) {
                    if (!response.success) {
                        toastr.error(response.message || 'Student search failed.');
                        return {
                            results: []
                        };
                    }

                    return {
                        results: (response.results || []).map(function(item) {
                            return {
                                id: item.student_id,
                                text: item.name + ' (' + item.student_id + ')',
                                student: item
                            };
                        })
                    };
                },
                cache: true
            },
            templateResult: buildQuickAddOption
        });

        // Picking a student adds the row, then the box clears itself so the next
        // student can be typed straight away without any extra clicks.
        $('#quickAddStudent').on('select2:select', function(e) {
            let studentId = e.params.data.id;
            $(this).val(null).trigger('change');
            addStudentRow(studentId);
        });

        // Land on the search box when the page opens with an empty table
        if (filteredStudentIds.length === 0) {
            setTimeout(function() {
                $('#quickAddStudent').select2('open');
            }, 400);
        }
    }

    // Function to render one Quick Add dropdown entry (photo, class/roll, pending due)
    function buildQuickAddOption(option) {
        if (!option.student) {
            return option.text;
        }

        let student = option.student;
        let symbol = typeof currenySymbol !== 'undefined' ? currenySymbol : '<?= $currency_symbol ?>';

        let dueBadge = student.total_unpaid_amount > 0 ?
            '<span class="badge bg-danger">Due ' + symbol + student.total_unpaid_amount + '</span>' :
            '<span class="badge bg-success">No due</span>';

        return $(
            '<div class="d-flex align-items-center gap-2 py-1">' +
            '<img src="' + student.image_url + '" alt="" style="width:34px;height:34px;object-fit:cover;border-radius:4px;border:1px solid #ddd;" />' +
            '<div class="flex-grow-1">' +
            '<div class="fw-bold">' + escapeHtml(student.name) + '</div>' +
            '<small class="text-muted">' + escapeHtml(student.class_info) +
            ' &middot; Roll: ' + escapeHtml(String(student.roll_no || '-')) +
            ' &middot; ' + escapeHtml(student.student_id) + '</small>' +
            '</div>' + dueBadge +
            '</div>'
        );
    }

    // Function to add a student row to the table and pre-fill their pending due.
    // The row markup comes from the server so it is identical to a row rendered on page load.
    function addStudentRow(studentId) {
        let $existing = $('#trow-' + studentId);

        // Already listed - take the admin to that row instead of adding a duplicate
        if ($existing.length > 0) {
            toastr.info('This student is already in the list below.');
            highlightRow($existing);
            $existing.find('.payment-amount-input').focus().select();
            return;
        }

        $.ajax({
            url: '<?= BASE_URL ?>/api/admin/get/fees-x-payments/monthly/search-students-for-payment.php',
            type: 'POST',
            data: {
                student_id: studentId,
                row_index: nextRowIndex
            },
            dataType: 'json',
            beforeSend: function() {
                showLoadingAlert('Loading student...');
            },
            success: function(response) {
                Swal.close();

                if (!response.success) {
                    showErrorAlert(response.message);
                    return;
                }

                nextRowIndex++;

                // .filter('tr') drops any stray text node so $row is only the row element
                let $row = $(response.html.trim()).filter('tr');

                if ($row.length === 0) {
                    showErrorAlert('The student row could not be rendered. Please reload the page.');
                    return;
                }

                $('#studentListTable tbody').append($row);

                filteredStudentIds.push(response.student_id);
                $('#total_students_payment_entry').text(filteredStudentIds.length);
                $('#student_ids_input').val(filteredStudentIds.join(','));

                // Pre-fill the pending due - the common case then needs no typing at all.
                // Triggering 'input' runs the same projection/summary logic as manual typing.
                let pendingAmount = parseFloat(response.total_unpaid_amount) || 0;
                $row.find('.payment-amount-input').val(pendingAmount).trigger('input');

                if (response.is_no_due) {
                    toastr.info(capitalize(response.student_name) + ' has no pending due. Enter an amount to pay in advance.');
                }

                highlightRow($row);
                toggleEmptyTableNotice();
                $row.find('.payment-amount-input').focus().select();
            },
            error: function(xhr) {
                console.error(xhr.responseText);
                showErrorAlert('Could not load that student. Report sent to technical support.');
                sendErrorReport("Page: " + window.location.href + "\n\n" + xhr.responseText);
            }
        });
    }

    // Function to remove a row and keep all the counters in step
    function removeStudentRow(studentId) {
        $('#trow-' + studentId).remove();
        filteredStudentIds = filteredStudentIds.filter(id => id !== studentId);
        $('#total_students_payment_entry').text(filteredStudentIds.length);
        $('#student_ids_input').val(filteredStudentIds.join(','));
        updateCollectionSummary();
        toggleEmptyTableNotice();

        // Nothing left to save means no reason to warn about leaving the page
        if (!hasPendingEntry()) {
            hasUnsavedChanges = false;
        }
    }

    // Function to collect a single row immediately, without saving the rest of the table.
    // Reuses the batch endpoint by posting an array holding just this student.
    function collectSingleRow($row) {
        let studentId = $row.data('student-id');
        let studentName = capitalize($row.data('name'));
        let paymentAmount = $row.find('.payment-amount-input').val();
        let discountAmount = $row.find('.discount-amount-input').val();
        let paymentDate = $row.find('.payment-date-input').val();

        if (!isNumeric(paymentAmount) || parseFloat(paymentAmount) < 0) {
            toastr.error('Enter a valid pay amount before collecting.');
            $row.find('.payment-amount-input').focus().select();
            return;
        }

        if ((parseFloat(paymentAmount) || 0) <= 0 && (parseFloat(discountAmount) || 0) <= 0) {
            toastr.error('Enter a pay amount (or a discount) before collecting.');
            $row.find('.payment-amount-input').focus().select();
            return;
        }

        // Refuse to send a discount the row-level rule would reject anyway
        if (!validateDiscountInput($row, true)) {
            return;
        }

        let singleRowData = [{
            student_id: studentId,
            student_name: $row.data('name'),
            payment_amount: paymentAmount,
            discount_amount: discountAmount,
            payment_date: paymentDate
        }];

        $.ajax({
            url: '<?= BASE_URL ?>/api/admin/put/fees-x-payments/monthly/process-payments-entry-monthly.php',
            type: 'POST',
            data: {
                students_payment_data: JSON.stringify(singleRowData)
            },
            dataType: 'json',
            beforeSend: function() {
                showLoadingAlert('Collecting from ' + studentName + '...');
            },
            success: function(response) {
                Swal.close();

                if (!response.success) {
                    showErrorAlert(response.message);
                    return;
                }

                // Exactly one student was sent, so exactly one of these arrays has an entry
                if (response.failed_processed && response.failed_processed.length > 0) {
                    showErrorAlert(response.failed_processed[0].message);
                    return;
                }

                if (!response.success_processed || response.success_processed.length === 0) {
                    showErrorAlert('The payment was not recorded. Please try again.');
                    return;
                }

                showSingleCollectResult(studentName, response.success_processed[0], response.payment_history_ids || []);

                // Clear the row so the table is ready for the next parent
                removeStudentRow(studentId);
            },
            error: function(xhr) {
                console.error(xhr.responseText);
                showErrorAlert('Error collecting the payment. Report sent to technical support.');
                sendErrorReport("Page: " + window.location.href + "\n\n" + xhr.responseText);
            }
        });
    }

    // Function to show the outcome of a single-row collect, with the receipt to hand
    function showSingleCollectResult(studentName, processed, paymentIds) {
        let symbol = typeof currenySymbol !== 'undefined' ? currenySymbol : '<?= $currency_symbol ?>';
        let discount = parseFloat(processed.discount_amount) || 0;
        let walletCredit = parseFloat(processed.wallet_credit) || 0;

        let html = '<div class="text-start">';
        html += '<p class="mb-2 fs-5"><b>' + studentName + '</b></p>';
        html += '<p class="mb-1">Collected: <b class="text-success">' + symbol + processed.payment_amount + '</b></p>';

        if (discount > 0) {
            html += '<p class="mb-1">Discount given: <b class="text-danger">' + symbol + discount + '</b></p>';
        }

        if (walletCredit > 0) {
            html += '<p class="mb-1">Credited to wallet: <b>' + symbol + walletCredit + '</b></p>';
        }

        html += '<p class="mb-0 mt-2 small text-muted">' + processed.message + '</p>';
        html += '</div>';

        Swal.fire({
            icon: 'success',
            title: 'Payment Collected',
            html: html,
            width: '520px',
            showDenyButton: paymentIds.length > 0,
            denyButtonText: '<i class="fas fa-print me-1"></i> Print Receipt',
            confirmButtonText: '<i class="fas fa-user-plus me-1"></i> Next Student',
            allowOutsideClick: false,
            allowEscapeKey: false,
            buttonsStyling: false,
            customClass: {
                confirmButton: 'btn btn-primary px-4 py-2 me-2',
                denyButton: 'btn btn-info px-4 py-2',
                popup: 'rounded-4 shadow-lg'
            },
            preDeny: () => {
                window.open('<?= BASE_URL ?>/api/download/receipt/monthly-payment-receipt.php?ids=' + paymentIds.join(','), '_blank');
                // Returning false keeps the dialog open so the receipt can be reprinted
                return false;
            }
        }).then((result) => {
            if (result.isConfirmed) {
                $('#quickAddStudent').select2('open');
            }
        });
    }

    // Function to refresh the running "x students - y to collect" line above the table
    function updateCollectionSummary() {
        let symbol = typeof currenySymbol !== 'undefined' ? currenySymbol : '<?= $currency_symbol ?>';
        let studentCount = 0;
        let totalAmount = 0;
        let totalDiscount = 0;

        $('#studentListTable tbody tr').each(function() {
            let amount = parseFloat($(this).find('.payment-amount-input').val()) || 0;
            let discount = parseFloat($(this).find('.discount-amount-input').val()) || 0;

            if (amount > 0 || discount > 0) {
                studentCount++;
                totalAmount += amount;
                totalDiscount += discount;
            }
        });

        if (studentCount === 0) {
            $('#collectionSummaryText').text('Nothing entered yet');
            return;
        }

        totalAmount = Math.round(totalAmount * 100) / 100;
        totalDiscount = Math.round(totalDiscount * 100) / 100;

        let text = studentCount + (studentCount === 1 ? ' student' : ' students') +
            ' \u00b7 ' + symbol + totalAmount + ' to collect';

        if (totalDiscount > 0) {
            text += ' \u00b7 ' + symbol + totalDiscount + ' discount';
        }

        $('#collectionSummaryText').text(text);
    }

    // Function to report whether any row still holds an amount or a discount
    function hasPendingEntry() {
        let pending = false;

        $('#studentListTable tbody tr').each(function() {
            let amount = parseFloat($(this).find('.payment-amount-input').val()) || 0;
            let discount = parseFloat($(this).find('.discount-amount-input').val()) || 0;

            if (amount > 0 || discount > 0) {
                pending = true;
                return false;
            }
        });

        return pending;
    }

    // Function to show/hide the "table is empty" hint
    function toggleEmptyTableNotice() {
        $('#emptyTableNotice').toggleClass('d-none', $('#studentListTable tbody tr').length > 0);
    }

    // Function to briefly flash a row so the admin can see which one changed
    function highlightRow($row) {
        if ($row.length === 0) {
            return;
        }

        if (typeof $row[0].scrollIntoView === 'function') {
            $row[0].scrollIntoView({
                behavior: 'smooth',
                block: 'center'
            });
        }

        $row.addClass('table-warning');

        setTimeout(function() {
            $row.removeClass('table-warning');
        }, 1500);
    }

    // Function sort student rows
    function sortStudentRows() {
        var sortOption = $('#studentListSort').val();
        var $tbody = $('#studentListTable tbody');
        var $rows = $tbody.find('tr').get();

        $rows.sort(function(a, b) {
            var valA, valB;

            switch (sortOption) {
                case 'default':
                    // অরিজিনাল রিকোয়েস্ট অর্ডার অনুযায়ী সর্ট করবে
                    valA = parseInt($(a).data('original-index'));
                    valB = parseInt($(b).data('original-index'));
                    return valA - valB;

                case 'roll_no-asc':
                    valA = parseInt($(a).data('roll-no'));
                    valB = parseInt($(b).data('roll-no'));
                    return valA - valB;

                case 'roll_no-desc':
                    valA = parseInt($(a).data('roll-no'));
                    valB = parseInt($(b).data('roll-no'));
                    return valB - valA;

                case 'name-asc':
                    valA = $(a).data('name');
                    valB = $(b).data('name');
                    return valA.localeCompare(valB);

                case 'name-desc':
                    valA = $(a).data('name');
                    valB = $(b).data('name');
                    return valB.localeCompare(valA);

                case 'pending-asc':
                    valA = parseFloat($(a).data('pending'));
                    valB = parseFloat($(b).data('pending'));
                    return valA - valB;

                case 'pending-desc':
                    valA = parseFloat($(a).data('pending'));
                    valB = parseFloat($(b).data('pending'));
                    return valB - valA;

                case 'last_payment_asc': // Oldest date first
                    valA = parseInt($(a).data('last-payment'));
                    valB = parseInt($(b).data('last-payment'));
                    // Handle '0' (no payment) cases - push to bottom or top?
                    // Currently: 0 is treated as very old (1970). 
                    return valA - valB;

                case 'last_payment_desc': // Newest date first
                    valA = parseInt($(a).data('last-payment'));
                    valB = parseInt($(b).data('last-payment'));
                    return valB - valA;

                default:
                    return 0;
            }
        });

        // Re-append rows in the new order
        $.each($rows, function(index, row) {
            $tbody.append(row);
        });
    }

    // Function to render the live payment/discount projection for a row.
    // Mirrors the server-side waterfall: the discount reduces the oldest pending month first, then
    // the payment clears months oldest-first, then whatever is left rolls into advance months.
    function renderPaymentProjection($row) {
        let monthlyFee = parseFloat($row.data('monthly-fee')) || 0;
        let inputAmount = parseFloat($row.find('.payment-amount-input').val()) || 0;
        let discountAmount = parseFloat($row.find('.discount-amount-input').val()) || 0;
        let $projectionDiv = $row.find('.payment-projection');
        let symbol = typeof currenySymbol !== 'undefined' ? currenySymbol : '<?= $currency_symbol ?>';

        if (inputAmount <= 0 && discountAmount <= 0) {
            $projectionDiv.slideUp('fast').empty();
            return;
        }

        let projectionHtml = '<strong class="text-dark d-block border-bottom mb-1 pb-1">Payment Calculation:</strong>';
        let dueMonths = getRowUnpaidMonths($row);

        // The discount only ever touches the oldest pending month, and it is always smaller than
        // that month's due - so the month still carries a balance for the payment to work against.
        if (discountAmount > 0 && dueMonths.length > 0) {
            let originalDue = dueMonths[0].due;
            let reducedDue = Math.round((originalDue - discountAmount) * 100) / 100;
            dueMonths[0].due = reducedDue;

            projectionHtml += `<div class="text-primary fw-bold"><i class="fas fa-tags me-1"></i> ${symbol}${discountAmount} discount on ${dueMonths[0].month} <br><span class="ms-3 text-muted">(Due ${symbol}${originalDue} &rarr; ${symbol}${reducedDue})</span></div>`;
        }

        let remainingInput = inputAmount;

        for (let i = 0; i < dueMonths.length; i++) {
            if (remainingInput <= 0) break;

            let monthName = dueMonths[i].month;
            let dueAmount = dueMonths[i].due;

            if (remainingInput >= dueAmount) {
                projectionHtml += `<div class="text-success fw-bold"><i class="fas fa-check-circle me-1"></i> ${monthName} (Clear)</div>`;
                remainingInput = Math.round((remainingInput - dueAmount) * 100) / 100;
            } else {
                let leftAmount = Math.round((dueAmount - remainingInput) * 100) / 100;
                projectionHtml += `<div class="text-warning text-dark fw-bold"><i class="fas fa-adjust me-1"></i> ${monthName} <br><span class="ms-3 text-muted">(${symbol}${remainingInput} Paid, ${symbol}${leftAmount} Due)</span></div>`;
                remainingInput = 0;
            }
        }

        // Advance months are always charged at the full monthly fee - a collection-time discount
        // never applies to a month that has not been billed yet.
        if (remainingInput > 0.001) {
            projectionHtml += buildAdvanceProjection($row, remainingInput, monthlyFee, symbol);
        }

        $projectionDiv.html(projectionHtml).slideDown('fast');
    }

    // Function to read a row's pending months as {month, due} objects, oldest month first
    function getRowUnpaidMonths($row) {
        let unpaidMonths = $row.data('unpaid-months');
        let months = [];

        if (unpaidMonths && unpaidMonths.length > 0) {
            for (let i = 0; i < unpaidMonths.length; i++) {
                months.push({
                    month: unpaidMonths[i].month,
                    due: parseFloat(unpaidMonths[i].due) || 0
                });
            }
        }

        return months;
    }

    // Function to validate a row's discount against the oldest pending month.
    // A discount equal to or greater than that month's due is refused and the field is reset to 0,
    // so a discount can never wipe out a month by itself. Returns true when the value is usable.
    function validateDiscountInput($row, showAlert) {
        let $input = $row.find('.discount-amount-input');
        let discountAmount = parseFloat($input.val()) || 0;

        if (discountAmount <= 0) {
            return true;
        }

        let months = getRowUnpaidMonths($row);
        let oldestMonth = months.length > 0 ? months[0] : null;
        let oldestDue = oldestMonth ? oldestMonth.due : 0;
        let symbol = typeof currenySymbol !== 'undefined' ? currenySymbol : '<?= $currency_symbol ?>';

        if (discountAmount < oldestDue) {
            return true;
        }

        // Reset silently when the row data was refreshed in the background rather than typed
        if (!showAlert) {
            $input.val(0);
            renderPaymentProjection($row);
            toastr.error('Discount reset to 0 because it is not less than the pending due.');
            return false;
        }

        // Only one warning at a time, otherwise fast typing stacks up dialogs
        if (Swal.isVisible()) {
            return false;
        }

        let message = oldestMonth ?
            `The discount cannot be equal to or greater than the total due.<br><br><b>${oldestMonth.month}</b> has a pending due of <b>${symbol}${oldestDue}</b>, so the discount must be less than <b>${symbol}${oldestDue}</b>.` :
            `This student has no pending due, so no discount can be applied.`;

        Swal.fire({
            icon: 'warning',
            title: 'Discount Not Allowed',
            html: message,
            confirmButtonText: 'OK',
            allowOutsideClick: false,
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-primary px-4 py-2'
            },
            buttonsStyling: false
        }).then(() => {
            // Clear the refused figure so the row can never be submitted with it
            $input.val(0);
            renderPaymentProjection($row);
            $input.focus();
        });

        return false;
    }

    // Function to build the advance (auto-generated) months breakdown.
    // This mirrors the server-side auto-entry logic of processSingleStudentPayment().
    function buildAdvanceProjection($row, remainingAmount, monthlyFee, symbol) {
        // Trim floating point dust so the amounts read cleanly
        remainingAmount = Math.round(remainingAmount * 100) / 100;

        let html = `<div class="text-info fw-bold mt-1 pt-1 border-top"><i class="fas fa-calendar-plus me-1"></i> Advanced Payment: ${symbol}${remainingAmount}</div>`;

        // Without a monthly fee no month can be generated, so the amount goes to the wallet
        if (monthlyFee <= 0) {
            html += `<div class="text-muted ms-3"><i class="fas fa-wallet me-1"></i> Will be credited to wallet</div>`;
            return html;
        }

        let cursor = getAdvanceStartDate($row);
        let shownMonths = 0;
        const maxShownMonths = 24; // Keeps the projection box readable for very large amounts

        while (remainingAmount > 0.001) {
            if (shownMonths >= maxShownMonths) {
                let remainingMonths = Math.ceil(remainingAmount / monthlyFee);
                html += `<div class="text-muted ms-3">+ ${remainingMonths} more month(s)...</div>`;
                break;
            }

            let monthLabel = cursor.toLocaleString('default', {
                month: 'long'
            }) + ' ' + cursor.getFullYear();

            if (remainingAmount >= monthlyFee) {
                html += `<div class="text-success fw-bold ms-3"><i class="fas fa-check-circle me-1"></i> ${monthLabel} (Clear)</div>`;
                remainingAmount = Math.round((remainingAmount - monthlyFee) * 100) / 100;
            } else {
                let leftAmount = Math.round((monthlyFee - remainingAmount) * 100) / 100;
                html += `<div class="text-warning text-dark fw-bold ms-3"><i class="fas fa-adjust me-1"></i> ${monthLabel} <br><span class="ms-3 text-muted">(${symbol}${remainingAmount} Paid, ${symbol}${leftAmount} Due)</span></div>`;
                remainingAmount = 0;
            }

            cursor.setMonth(cursor.getMonth() + 1);
            shownMonths++;
        }

        return html;
    }

    // Function to get the first month the advance entries will start from (data-advance-start = "YYYY-MM")
    function getAdvanceStartDate($row) {
        let parts = ($row.data('advance-start') || '').toString().split('-');

        if (parts.length === 2 && parts[0] && parts[1]) {
            return new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, 1);
        }

        let now = new Date();
        return new Date(now.getFullYear(), now.getMonth(), 1);
    }

    // Function submit data
    function submitData() {
        let studentsPaymentData = [];

        $('#studentListTable tbody tr').each(function() {
            let studentId = $(this).data('student-id');
            let paymentAmount = $(this).find('.payment-amount-input').val();
            let discountAmount = $(this).find('.discount-amount-input').val();
            let paymentDate = $(this).find('.payment-date-input').val();

            studentsPaymentData.push({
                student_id: studentId,
                student_name: $(this).data('name'),
                payment_amount: paymentAmount,
                discount_amount: discountAmount,
                payment_date: paymentDate
            });
        });

        Swal.fire({
            icon: 'question',
            title: 'Verify Payment Data',
            html: `
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Payment Amount</th>
                                <th>Discount</th>
                                <th>Payment Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${buildPreSubmitTableBody(studentsPaymentData)}
                        </tbody>
                    </table>
                </div>
            `,
            showCancelButton: true,
            confirmButtonText: 'Submit',
            showLoaderOnConfirm: true,
            customClass: {
                confirmButton: 'btn btn-primary px-4 py-2',
                cancelButton: 'btn btn-secondary px-4 py-2',
                popup: 'rounded-4 shadow-lg'
            }
        }).then(function(result) {
            if (result.isConfirmed) {
                submitPaymentsData(studentsPaymentData);
            }
        });
    }

    // Function submit payments data
    function submitPaymentsData(studentsPaymentData) {
        $.ajax({
            url: '<?= BASE_URL ?>/api/admin/put/fees-x-payments/monthly/process-payments-entry-monthly.php',
            type: 'POST',
            data: {
                students_payment_data: JSON.stringify(studentsPaymentData)
            },
            dataType: 'json',
            beforeSend: function() {
                showLoadingAlert();
            },
            success: function(response) {
                Swal.close();
                if (response.success) {
                    // এখানে payment_history_ids পাস করা হলো
                    showSuccessAlertTable(response.success_processed, response.failed_processed, response.payment_history_ids);
                } else {
                    showErrorAlert(response.message);
                }
            },
            error: function(xhr) {
                console.error(xhr.responseText);
                showErrorAlert('Error processing payments. Report sent to technical support.');
                let errorMessage = "Page: " + window.location.href + "\n\n" + xhr.responseText;
                sendErrorReport(errorMessage);
            }
        });
    }

    // Function verify security pin
    function verifySecurityPin() {
        Swal.fire({
            title: 'Enter Security Pin',
            input: 'text', // Keep password type for masking
            inputAttributes: {
                autocapitalize: 'off',
                autofocus: 'true',
                // This is the key to stopping the "Saved Password" popup:
                autocomplete: 'one-time-code',
                name: 'my-unique-pin-field',
                style: '-webkit-text-security: disc;'
            },
            showCancelButton: false,
            confirmButtonText: 'Verify & Continue',
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: true,
            showLoaderOnConfirm: true,
            preConfirm: (inputPin) => {
                if (inputPin === '<?= $security_pin ?>') {
                    return true;
                } else {
                    toastr.error('Invalid security pin. Please try again.');
                    return false;
                }
            },
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-primary px-4 py-2',
                cancelButton: 'btn btn-danger px-4 py-2'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.close();
                toastr.success('Security pin verified.');
            }
        });
    }

    // Function build pre-submit table body
    function buildPreSubmitTableBody(studentsPaymentData) {
        let tableBody = '';
        studentsPaymentData.forEach(function(data) {
            let discount = parseFloat(data.discount_amount) || 0;
            let discountCell = discount > 0 ?
                `<td class="text-danger fw-bold">- <?= $currency_symbol ?>${discount}</td>` :
                `<td class="text-muted">-</td>`;

            tableBody += `
                <tr>
                    <td>${capitalize(data.student_name)}</td>
                    <td><?= $currency_symbol ?>${data.payment_amount}</td>
                    ${discountCell}
                    <td>${formatDate(data.payment_date)}</td>
                </tr>
            `;
        });
        return tableBody;
    }

    // Function show success alert
    function showSuccessAlertTable(success_processed, failed_processed, payment_history_ids = []) {
        let totalSuccess = success_processed.length;
        let totalFailed = failed_processed.length;

        let successTable = `
            <div class="table-responsive">
                <table class="table table-bordered table-sm">
                    <thead class="table-success">
                        <tr>
                            <th>Name</th>
                            <th>Message</th>
                            <th>Payment Amount</th>
                            <th>Discount</th>
                            <th>Wallet Credit</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${buildSuccessTableBody(success_processed)}
                    </tbody>
                </table>
            </div>
        `;

        let failedTable = `
            <div class="table-responsive">
                <table class="table table-bordered table-sm">
                    <thead class="table-danger">
                        <tr>
                            <th>Name</th>
                            <th>Message</th>
                            <th>Payment Amount</th>
                            <th>Discount</th>
                            <th>Wallet Credit</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${buildFailedTableBody(failed_processed)}
                    </tbody>
                </table>
            </div>
        `;

        Swal.fire({
            icon: 'success',
            title: 'Successfully Processed Payments',
            width: '600px',
            html: `
                <p><strong>Success:</strong> ${totalSuccess}</p>
                ${successTable}
                <p><strong>Failed:</strong> ${totalFailed}</p>
                ${failedTable}
            `,
            showCancelButton: false,
            // প্রিন্ট বাটন দেখানোর অপশন চালু করা হলো
            showDenyButton: payment_history_ids && payment_history_ids.length > 0,
            denyButtonText: '<i class="fas fa-print me-1"></i> Print',
            confirmButtonText: 'OK',
            allowOutsideClick: false,
            allowEscapeKey: false,
            buttonsStyling: false, // কাস্টম ক্লাসগুলো ঠিকমতো কাজ করার জন্য
            customClass: {
                confirmButton: 'btn btn-primary px-4 py-2 me-2',
                denyButton: 'btn btn-info px-4 py-2', // প্রিন্ট বাটনের ডিজাইন
                popup: 'rounded-4 shadow-lg'
            },
            // প্রিন্ট বাটনে ক্লিক করলে কী হবে তা নির্ধারণ করা
            preDeny: () => {
                let idsString = payment_history_ids.join(',');
                let printUrl = '<?= BASE_URL ?>/api/download/receipt/monthly-payment-receipt.php?ids=' + idsString;
                
                // নতুন ট্যাবে রসিদ প্রিন্ট করার পেজ ওপেন হবে
                window.open(printUrl, '_blank');
                
                // false রিটার্ন করার কারণে ডায়ালগ বক্সটি বন্ধ হবে না
                return false; 
            }
        }).then((result) => {
            // শুধুমাত্র OK বাটনে ক্লিক করলেই পেজ রিলোড হবে
            if (result.isConfirmed) {
                location.reload();
            }
        });
    }

    // Function build success table body
    function buildSuccessTableBody(success_processed) {
        let tableBody = '';
        success_processed.forEach(function(data) {
            tableBody += `
                <tr>
                    <td>${capitalize(data.student_name)}</td>
                    <td>${data.message}</td>
                    <td><?= $currency_symbol ?>${data.payment_amount}</td>
                    <td><?= $currency_symbol ?>${parseFloat(data.discount_amount) || 0}</td>
                    <td><?= $currency_symbol ?>${data.wallet_credit}</td>
                </tr>
            `;
        });
        return tableBody;
    }

    // Function build failed table body
    function buildFailedTableBody(failed_processed) {
        let tableBody = '';
        failed_processed.forEach(function(data) {
            tableBody += `
                <tr>
                    <td>${capitalize(data.student_name)}</td>
                    <td>${data.message}</td>
                    <td><?= $currency_symbol ?>${data.payment_amount}</td>
                    <td><?= $currency_symbol ?>${parseFloat(data.discount_amount) || 0}</td>
                    <td><?= $currency_symbol ?>${data.wallet_credit}</td>
                </tr>
            `;
        });
        return tableBody;
    }

    // Function to delete unpaid fee entry
    function deleteUnpaidFeeEntry(entryId, studentId) {

        let tr = $('#trow-' + studentId);
        let viewMoreBtn = tr.find('.more-details-btn');
        let studentName = tr.data('name');

        Swal.fire({
            title: 'Are you sure?',
            html: `This action cannot be undone! You are about to delete an unpaid monthly fee entry for <strong>${studentName.toUpperCase()}</strong>.`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-danger px-4 py-2',
                cancelButton: 'btn btn-primary px-4 py-2'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                // Proceed with deletion
                $.ajax({
                    url: '<?= BASE_URL ?>/api/admin/delete/fees-x-payments/delete-unpaid-fee-entry.php',
                    type: 'POST',
                    data: {
                        entry_id: entryId,
                        fees_type: 'monthly'
                    },
                    dataType: 'json',
                    beforeSend: function() {
                        showLoadingAlert('Deleting Fee Entry...', '<div class="spinner-border text-primary" role="status"></div>');
                    },
                    success: function(response) {
                        if (response.success) {
                            // Show success message
                            toastr.success(response.message);
                            Swal.close();

                            viewMoreBtn.click();
                        } else {
                            showErrorAlert(response.message);
                        }
                    },
                    error: function(xhr) {
                        showErrorAlert('An error occurred while deleting the fee entry.');
                        console.error(xhr.responseText);
                    }
                });
            } else {
                // Cancel deletion
                viewMoreBtn.click();
            }
        });
    }

    // Function to populate fee entry
    function populateFeeEntryModal(entryId, monthYear, studentId) {
        $.ajax({
            url: '<?= BASE_URL ?>/api/admin/get/student/get-student-info.php',
            type: 'POST',
            data: {
                student_id: studentId
            },
            dataType: 'json',
            beforeSend: function() {
                showLoadingAlert('Retrieving student details...');
            },
            success: function(response) {
                Swal.close();
                $('body').css('padding-right', '');
                $('body').removeClass('modal-open');

                if (response.success) {
                    let student_info = response.student_info;
                    editEntryStudentInfo = student_info;
                    $('#editMonthlyFeeEntryModalMonth').text(monthYear);
                    $('#editMonthlyFeeEntryModalTutionFee').val(student_info.tution_fee);
                    $('#editMonthlyFeeEntryModalCarFee').val(student_info.car_fee);
                    $('#editMonthlyFeeEntryModalHostelFee').val(student_info.hostel_fee);
                    $('#editMonthlyFeeEntryModalCoachingFee').val(student_info.coaching_fee);
                    $('#editMonthlyFeeEntryModalTiffinFee').val(student_info.tiffin_fee);
                    $('#editMonthlyFeeEntryModalDiscount').val('0');
                    let totalFee =
                        (parseFloat(student_info.tution_fee) || 0) +
                        (parseFloat(student_info.car_fee) || 0) +
                        (parseFloat(student_info.hostel_fee) || 0) +
                        (parseFloat(student_info.coaching_fee) || 0) +
                        (parseFloat(student_info.tiffin_fee) || 0);
                    $('#editMonthlyFeeEntryModalTotalAmount').text('<?= $currency_symbol ?>' + totalFee.toFixed(2));
                    $('#editMonthlyFeeEntryModalLabel').html('Edit Monthly Fee Entry for <b>' + capitalize(student_info.name) + '</b>');

                    $('#editMonthlyFeeEntryModal').modal('show');
                } else {
                    showErrorAlert(response.message);
                }
            },
            error: function(xhr) {
                showErrorAlert('An error occurred while retrieving the fee entry.');
                console.error(xhr.responseText);
                sendErrorReport(xhr.responseText);
            }
        });
    }

    function submitEditedUnpaidFeeData(studentsFeeData) {
        $.ajax({
            url: '<?= BASE_URL ?>/api/admin/put/fees-x-payments/monthly/submit-fees-request.php',
            method: 'POST',
            data: {
                studentsFeeData: JSON.stringify(studentsFeeData)
            },
            dataType: 'json',
            beforeSend: function() {
                showLoadingAlert('Submitting fee request...');
            },
            success: function(response) {
                Swal.close();
                if (response.success) {
                    toastr.success(response.message);
                    showDetailedResultModal(response);
                    console.log(response);
                } else {
                    showErrorAlert(response.message);
                }
            },
            error: function(xhr) {
                console.error(xhr.responseText);
                showErrorAlert('Error submitting fee request. Report sent to technical support.');
                let errorMessage = "Page: " + window.location.href + "\n\n" + xhr.responseText;
                sendErrorReport(errorMessage);
            }
        });
    }

    // Function to show the detailed result modal
    function showDetailedResultModal(response) {
        // 1. Build the top summary badges
        let html = `
        <div class="mb-3 text-center d-flex justify-content-center gap-3">
            <span class="badge bg-secondary fs-6 py-2 px-3 shadow-sm">Total: ${response.total_records}</span>
            <span class="badge bg-success fs-6 py-2 px-3 shadow-sm">Processed: ${response.processed}</span>
            <span class="badge bg-danger fs-6 py-2 px-3 shadow-sm">Skipped: ${response.skipped}</span>
        </div>
        
        <div class="table-responsive text-start border rounded-3 shadow-sm" style="max-height: 60vh; overflow-y: auto; scrollbar-width: thin;">
            <table class="table table-sm table-hover align-middle mb-0" style="font-size: 0.85rem;">
                <thead class="table-light sticky-top" style="z-index: 1;">
                    <tr>
                        <th class="py-2 px-3">Student</th>
                        <th class="py-2">Month</th>
                        <th class="py-2">Status</th>
                        <th class="py-2 px-3">Remarks / Details</th>
                    </tr>
                </thead>
                <tbody>`;

        // 3. Loop through the backend results array
        if (response.results && response.results.length > 0) {
            response.results.forEach(item => {
                let statusBadge = '';
                let rowClass = '';
                let textClass = 'text-muted';

                if (item.action === 'created') {
                    statusBadge = '<span class="badge bg-success"><i class="fas fa-check me-1"></i>Created</span>';
                } else if (item.action === 'updated') {
                    statusBadge = '<span class="badge bg-info text-dark"><i class="fas fa-sync-alt me-1"></i>Updated</span>';
                } else {
                    statusBadge = '<span class="badge bg-danger"><i class="fas fa-times me-1"></i>Skipped</span>';
                    rowClass = 'table-danger bg-opacity-10';
                    textClass = 'text-danger fw-bold';
                }

                html += `
                <tr class="${rowClass}">
                    <td class="px-3 fw-bold text-nowrap">${item.name} <br><small class="text-muted fw-normal">ID: ${item.student_id}</small></td>
                    <td class="text-nowrap">${item.month_year}</td>
                    <td>${statusBadge}</td>
                    <td class="px-3"><small class="${textClass}">${item.message}</small></td>
                </tr>`;
            });
        } else {
            html += `<tr><td colspan="4" class="text-center py-3 text-muted">No detailed results available.</td></tr>`;
        }

        html += `</tbody></table></div>`;

        // 4. Trigger the SweetAlert
        Swal.fire({
            title: '<i class="fas fa-clipboard-list text-primary me-2"></i> Submission Report',
            html: html,
            icon: response.skipped > 0 ? 'warning' : 'success', // Use warning icon if anything was skipped
            width: '900px', // Wide enough for the table
            confirmButtonText: '<i class="fas fa-check-circle me-1"></i> Acknowledge & Close',
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-primary px-4'
            },
            buttonsStyling: false
        }).then((result) => {
            // Optional: Clean up the UI after they close the modal
            if (result.isConfirmed || result.isDismissed) {
                // --- পেজ রিফ্রেশ না করে ওই স্টুডেন্টের ডেটা আবার ফেচ করার জন্য বাটন ক্লিক সিমুলেট করা ---
                let studentId = editEntryStudentInfo.student_id;
                $('#trow-' + studentId).find('.more-details-btn').click();
            }
        });
    }

    function populateMonthSelection() {

        const now = new Date();
        const currentYear = now.getFullYear();

        $('.feeMonthSelect').empty();

        for (let monthIndex = 0; monthIndex < 12; monthIndex++) {

            const date = new Date(currentYear, monthIndex, 1);

            const month = date.toLocaleString('default', {
                month: 'long'
            });

            const value = `${month} ${currentYear}`;

            $('.feeMonthSelect').each(function() {

                const option = document.createElement('option');
                option.value = value;
                option.textContent = value;

                // Select current month false
                if (monthIndex === now.getMonth()) {
                    option.selected = false;
                }

                $(this).append(option);
            });
        }
    }

    // Function to show updateMonthlyFeesModal
    function showUpdateMonthlyFeesModal() {
        if (!studentFinancialOverview) {
            toastr.error('Student\'s financial details not found.');
            return;
        }

        let studentName = studentFinancialOverview.student_name;
        let className = studentFinancialOverview.class_name;
        let sectionName = studentFinancialOverview.section_name || '';
        let rollNo = studentFinancialOverview.roll_no || '';

        let classFee = studentFinancialOverview.class_fee;
        let customClassFee = studentFinancialOverview.custom_class_fee;
        let carFee = studentFinancialOverview.car_fee;
        let hostelFee = studentFinancialOverview.hostel_fee;
        let coachingFee = studentFinancialOverview.coaching_fee;
        let tiffinFee = studentFinancialOverview.tiffin_fee;
        let monthlyFee = studentFinancialOverview.monthly_fee;

        $('#updateMonthlyFeesModalStudentName').text(`${studentName}`);
        $('#updateMonthlyFeesModalClassInfo').html(`${className} - ${sectionName} (Roll: ${rollNo})`);
        $('#updateMonthlyFeesModalRegularClassFee').text(`${className}: <?= $currency_symbol ?>${classFee}`);
        $('#updateMonthlyFeesModalCalculatedClassFee').text(`<?= $currency_symbol ?>${monthlyFee}`);
        $('#updateMonthlyFeesModalCustomClassFee').val(customClassFee);
        $('#updateMonthlyFeesModalCarFee').val(carFee);
        $('#updateMonthlyFeesModalHostelFee').val(hostelFee);
        $('#updateMonthlyFeesModalCoachingFee').val(coachingFee);
        $('#updateMonthlyFeesModalTiffinFee').val(tiffinFee);

        $('#updateMonthlyFeesModal').modal('show');
    }

    // Function to show detailed result for Update Monthly Fees
    function showUpdateFeeDetailedResult(response, studentId) {

        // ব্যাকএন্ড থেকে আসা ডেটাগুলো ভেরিয়েবলে নেওয়া হলো
        let updatedMonths = response.updated_months || [];
        let skippedMonths = response.skipped_months || [];

        let html = `
        <div class="mb-3 text-center d-flex justify-content-center gap-3">
            <span class="badge bg-success fs-6 py-2 px-3 shadow-sm">Updated: ${updatedMonths.length}</span>
            <span class="badge bg-danger fs-6 py-2 px-3 shadow-sm">Skipped: ${skippedMonths.length}</span>
        </div>`;

        // যদি permanent_change true হয়
        if (response.permanently_changed) {
            html += `<div class="alert alert-info py-2 text-start"><i class="fas fa-info-circle me-1"></i> Student base fees updated permanently.</div>`;
        }

        html += `
        <div class="table-responsive text-start border rounded-3 shadow-sm" style="max-height: 50vh; overflow-y: auto; scrollbar-width: thin;">
            <table class="table table-sm table-hover align-middle mb-0" style="font-size: 0.85rem;">
                <thead class="table-light sticky-top" style="z-index: 1;">
                    <tr>
                        <th class="py-2 px-3">Month</th>
                        <th class="py-2">Status</th>
                        <th class="py-2 px-3">Details / Reason</th>
                    </tr>
                </thead>
                <tbody>`;

        if (updatedMonths.length > 0 || skippedMonths.length > 0) {
            // Updated Months রেন্ডার করা
            updatedMonths.forEach(item => {
                html += `
                <tr>
                    <td class="px-3 fw-bold text-nowrap">${item.month_year}</td>
                    <td><span class="badge bg-success"><i class="fas fa-check me-1"></i>Updated</span></td>
                    <td class="px-3"><small class="text-muted">New Fee: <b><?= $currency_symbol ?>${item.actual_amount}</b><br>New Pending: <?= $currency_symbol ?>${item.unpaid_amount}</small></td>
                </tr>`;
            });

            // Skipped Months রেন্ডার করা
            skippedMonths.forEach(item => {
                html += `
                <tr class="table-danger bg-opacity-10">
                    <td class="px-3 fw-bold text-nowrap">${item.month_year}</td>
                    <td><span class="badge bg-danger"><i class="fas fa-times me-1"></i>Skipped</span></td>
                    <td class="px-3"><small class="text-danger fw-bold">${item.reason}</small></td>
                </tr>`;
            });
        } else {
            html += `<tr><td colspan="3" class="text-center py-3 text-muted">No specific month records were modified.</td></tr>`;
        }

        html += `</tbody></table></div>`;

        // SweetAlert কল করা
        Swal.fire({
            title: '<i class="fas fa-clipboard-check text-success me-2"></i> Update Report',
            html: html,
            icon: skippedMonths.length > 0 ? 'warning' : 'success',
            width: '800px',
            confirmButtonText: '<i class="fas fa-sync-alt me-1"></i> Close & Refresh',
            allowOutsideClick: false,
            allowEscapeKey: false,
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-primary px-4'
            },
            buttonsStyling: false
        }).then((result) => {
            // ইউজার যখন মোডালটি বন্ধ করবেন, তখন ব্যাকগ্রাউন্ড ডেটা রিফ্রেশ হবে
            if (result.isConfirmed || result.isDismissed) {
                let tr = $('#trow-' + studentId);
                let viewMoreBtn = tr.find('.more-details-btn');
                viewMoreBtn.trigger('click');
            }
        });
    }
</script>

<?php include_once("../../../includes/body-close.php"); ?>