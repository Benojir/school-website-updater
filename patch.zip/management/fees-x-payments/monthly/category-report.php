<?php
require_once __DIR__ . '/../../../includes/auth-check.php';
if (!hasPermission(PERM_CAN_SEE_FINANCIAL_REPORT)) {
    require_once __DIR__ . '/../../../includes/permission-denied.php'; exit;
}
require_once __DIR__ . '/../../../includes/financial/monthly-fee-ledger.php';
$_SESSION['monthly_category_csrf'] ??= bin2hex(random_bytes(32));
require_once __DIR__ . '/../../../includes/header-open.php';
echo '<title>Monthly Fee Categories - ' . safe_htmlspecialchars($school_name) . '</title>';
echo '<link rel="stylesheet" href="' . safe_htmlspecialchars(BASE_URL) . '/assets/css/monthly-fee-category-report.css">';
require_once __DIR__ . '/../../../includes/header-close.php';
require_once __DIR__ . '/../../../includes/dashboard-navbar.php';
?>
<main class="container-fluid monthly-category-report" id="monthlyCategoryReport"
      data-base="<?= safe_htmlspecialchars(BASE_URL) ?>"
      data-currency="<?= safe_htmlspecialchars($currency_symbol) ?>"
      data-csrf="<?= safe_htmlspecialchars($_SESSION['monthly_category_csrf']) ?>"
      data-can-review="<?= hasPermission(PERM_MANAGE_FEES) ? '1' : '0' ?>">
    <header class="category-hero mb-4">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
            <div class="d-flex align-items-center gap-3">
                <span class="category-hero-icon"><i class="fa-solid fa-chart-pie" aria-hidden="true"></i></span>
                <div><div class="category-eyebrow mb-1">Finance / Monthly fees</div>
                    <h1 class="h3 fw-bold mb-1">Monthly Fee Categories</h1>
                    <p class="category-description mb-0">Track each fee's billing, collections and remaining balance. Amounts in <?= safe_htmlspecialchars($currency_symbol) ?>.</p></div>
            </div>
            <span class="category-scope"><i class="fa-solid fa-users" aria-hidden="true"></i><span id="categoryStudentScope">All students</span></span>
        </div>
    </header>
    <section class="card category-card category-filter-card mb-4"><div class="card-body">
        <div class="d-flex align-items-center gap-2 mb-3"><i class="fa-solid fa-sliders text-primary" aria-hidden="true"></i><h2 class="h6 fw-bold mb-0">Report filters</h2></div>
        <form id="categoryFilters" class="row g-3 align-items-end">
            <div class="col-sm-6 col-lg-2"><label class="form-label" for="categoryMonth"><i class="fa-regular fa-calendar me-1" aria-hidden="true"></i> Billing month</label>
                <input class="form-control" type="month" id="categoryMonth" value="<?= date('Y-m') ?>" required></div>
            <div class="col-sm-6 col-lg-2"><label class="form-label" for="categoryFrom">Collection from</label>
                <input class="form-control" type="date" id="categoryFrom" value="<?= date('Y-m-01') ?>" required></div>
            <div class="col-sm-6 col-lg-2"><label class="form-label" for="categoryTo">Collection to</label>
                <input class="form-control" type="date" id="categoryTo" value="<?= date('Y-m-d') ?>" required></div>
            <div class="col-sm-6 col-lg-4"><label class="form-label" for="categoryStudent"><i class="fa-solid fa-magnifying-glass me-1" aria-hidden="true"></i> Find a student</label>
                <select class="form-select" id="categoryStudent" aria-describedby="categoryStudentHelp"><option value=""></option></select></div>
            <div class="col-lg-2"><button class="btn btn-primary w-100" id="categoryReportSubmit" type="submit"><i class="fa-solid fa-filter me-2" aria-hidden="true"></i>Show report</button></div>
        </form>
        <p class="category-description mt-2 mb-3" id="categoryStudentHelp">Search by name, father or mother, phone, Student ID, roll, registration, email or address. Select a student to view their report; clear the selection to show everyone.</p>
        <div class="category-priority" aria-label="Payment priority">
            <span class="category-description me-1"><i class="fa-solid fa-arrow-down-short-wide me-1" aria-hidden="true"></i>Collection order</span>
            <span class="badge"><i class="fa-solid fa-graduation-cap me-1" aria-hidden="true"></i>1. Tuition</span>
            <span class="badge"><i class="fa-solid fa-bus me-1" aria-hidden="true"></i>2. Car</span>
            <span class="badge"><i class="fa-solid fa-bed me-1" aria-hidden="true"></i>3. Hostel</span>
            <span class="badge"><i class="fa-solid fa-book-open me-1" aria-hidden="true"></i>4. Coaching</span>
            <span class="badge"><i class="fa-solid fa-utensils me-1" aria-hidden="true"></i>5. Tiffin</span>
            <span class="badge"><i class="fa-solid fa-coins me-1" aria-hidden="true"></i>6. Other</span>
        </div>
    </div></section>
    <div id="categoryMessage" class="alert alert-info category-message d-flex align-items-center gap-2" role="status" aria-live="polite">
        <i class="fa-solid fa-circle-notch fa-spin" id="categoryMessageIcon" aria-hidden="true"></i><span id="categoryMessageText">Loading report…</span>
    </div>
    <div class="row g-3 mb-4" aria-label="Report summary">
        <div class="col-6 col-xl-3"><div class="card category-card h-100"><div class="card-body">
            <div class="d-flex align-items-center justify-content-between gap-2 mb-2"><span class="category-stat-label">Total billed</span><span class="category-card-icon"><i class="fa-solid fa-file-invoice" aria-hidden="true"></i></span></div>
            <div class="category-stat-value" id="categoryStatBilled">—</div><div class="category-stat-note">Selected billing month</div>
        </div></div></div>
        <div class="col-6 col-xl-3"><div class="card category-card h-100"><div class="card-body">
            <div class="d-flex align-items-center justify-content-between gap-2 mb-2"><span class="category-stat-label">Fees paid</span><span class="category-card-icon success"><i class="fa-solid fa-circle-check" aria-hidden="true"></i></span></div>
            <div class="category-stat-value" id="categoryStatPaid">—</div><div class="category-stat-note">Applied to the selected bill month</div>
        </div></div></div>
        <div class="col-6 col-xl-3"><div class="card category-card h-100"><div class="card-body">
            <div class="d-flex align-items-center justify-content-between gap-2 mb-2"><span class="category-stat-label">Remaining due</span><span class="category-card-icon warning"><i class="fa-solid fa-hourglass-half" aria-hidden="true"></i></span></div>
            <div class="category-stat-value" id="categoryStatDue">—</div><div class="category-stat-note">After payments and discounts</div>
        </div></div></div>
        <div class="col-6 col-xl-3"><div class="card category-card h-100"><div class="card-body">
            <div class="d-flex align-items-center justify-content-between gap-2 mb-2"><span class="category-stat-label">Cash + online</span><span class="category-card-icon purple"><i class="fa-solid fa-hand-holding-dollar" aria-hidden="true"></i></span></div>
            <div class="category-stat-value" id="categoryStatCollected">—</div><div class="category-stat-note">Selected collection dates</div>
        </div></div></div>
    </div>
    <div class="row g-4 mb-4">
    <section class="col-xxl-6"><div class="card category-card h-100"><div class="card-body">
        <div class="d-flex align-items-center gap-3 mb-3"><span class="category-card-icon"><i class="fa-solid fa-file-invoice-dollar" aria-hidden="true"></i></span>
            <div><h2 class="h5 mb-1">Monthly billing</h2><span class="category-description" id="categoryBillPeriod"></span></div></div>
        <p class="category-description">Current balances for this bill month, including all payments applied to it.</p>
        <div class="table-responsive"><table class="table table-hover align-middle category-table">
            <thead><tr><th>Fee</th><th>Billed</th><th>Discount</th><th>Paid</th><th>Remaining due</th></tr></thead>
            <tbody id="categoryBillSummary"></tbody><tfoot id="categoryBillTotals"></tfoot>
        </table></div>
    </div></div></section>
    <section class="col-xxl-6"><div class="card category-card h-100"><div class="card-body">
        <div class="d-flex align-items-center gap-3 mb-3"><span class="category-card-icon success"><i class="fa-solid fa-money-bill-transfer" aria-hidden="true"></i></span>
            <div><h2 class="h5 mb-1">Fee collections</h2><span class="category-description" id="categoryCollectionPeriod"></span></div></div>
        <p class="category-description">Includes arrears and advance. Reversals are removed from the original collection date.
            Wallet payments apply previously deposited money and are shown separately. Gateway charges and GST are excluded.</p>
        <div class="table-responsive"><table class="table table-hover align-middle category-table">
            <thead><tr><th>Fee</th><th>Cash</th><th>Online</th><th>Cash + online</th><th>Applied from wallet</th></tr></thead>
            <tbody id="categoryCollectionSummary"></tbody><tfoot id="categoryCollectionTotals"></tfoot>
        </table></div>
        <p class="category-wallet-note mt-3 mb-0"><i class="fa-solid fa-wallet me-2" aria-hidden="true"></i>Additional wallet deposits: <strong id="categoryWalletDeposits"></strong></p>
    </div></div></section>
    </div>
    <section class="card category-card mb-4"><div class="card-body">
        <div class="d-flex align-items-center justify-content-between gap-2 mb-2"><h2 class="h5 mb-0"><i class="fa-solid fa-list-check text-primary me-2" aria-hidden="true"></i>Student bill breakdowns</h2><span class="badge bg-primary-subtle text-primary" id="categoryBillCount">—</span></div>
        <p class="category-description">Shows up to 100 category bills. Find a student above to narrow the list.
            A reviewed legacy balance categorizes only its remaining due; earlier billed and paid amounts stay unclassified.</p>
        <div class="table-responsive"><table class="table table-hover align-middle category-table category-table-details">
            <thead><tr><th>Student</th><th>Bill / breakdown</th><th>Fee</th><th>Billed</th><th>Discount</th><th>Paid</th><th>Due</th></tr></thead>
            <tbody id="categoryBillDetails"></tbody>
        </table></div>
    </div></section>
    <section class="card category-card mb-4"><div class="card-body">
        <div class="d-flex align-items-center justify-content-between gap-2 mb-2"><h2 class="h5 mb-0"><i class="fa-solid fa-clock-rotate-left text-warning me-2" aria-hidden="true"></i>Legacy bills awaiting verification</h2><span class="badge bg-warning-subtle text-warning-emphasis" id="categoryLegacyCount">—</span></div>
        <p class="category-description">Old totals are preserved. Enter the remaining amounts only after checking the original bill.
            Their sum must equal the existing due. Shows up to 100 pending bills.</p>
        <div class="table-responsive"><table class="table table-hover align-middle category-table category-table-legacy">
            <thead><tr><th>Student</th><th>Month</th><th>Remaining due</th><th>Action</th></tr></thead>
            <tbody id="categoryLegacyBills"></tbody>
        </table></div>
    </div></section>
    <section id="legacyReviewPanel" class="card category-card category-review-panel mb-4" hidden><div class="card-body">
        <h2 class="h5"><i class="fa-solid fa-clipboard-check me-2 text-warning" aria-hidden="true"></i>Verify remaining legacy due</h2><p class="category-description" id="legacyReviewDescription"></p>
        <form id="legacyReviewForm"><div class="row g-3">
            <?php foreach (MonthlyFeeLedger::FEES as $code => $label): if ($code === 'unclassified') continue; ?>
                <div class="col-md-4"><label class="form-label" for="legacy-<?= $code ?>"><?= $label ?></label>
                    <input class="form-control legacy-component" id="legacy-<?= $code ?>" data-fee="<?= $code ?>"
                           type="number" min="0" step="0.01" value="0" required></div>
            <?php endforeach; ?>
        </div><p class="my-3" id="legacyReviewTotal"></p>
            <button class="btn btn-primary" id="legacyReviewSubmit" type="submit"><i class="fa-solid fa-check me-2" aria-hidden="true"></i>Save verified remaining amounts</button>
            <button class="btn btn-outline-secondary" id="legacyReviewCancel" type="button"><i class="fa-solid fa-xmark me-2" aria-hidden="true"></i>Cancel</button>
        </form>
    </div></section>
</main>
<script src="<?= BASE_URL ?>/assets/js/monthly-fee-category-report.js?v=<?= filemtime(__DIR__ . '/../../../assets/js/monthly-fee-category-report.js') ?>"></script>
<?php require_once __DIR__ . '/../../../includes/body-close.php'; ?>
