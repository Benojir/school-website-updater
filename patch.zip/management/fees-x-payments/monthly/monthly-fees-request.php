<?php
/** @var string $school_name */
include_once("../../../includes/auth-check.php");
require_once("../../../includes/header-open.php");
echo "<title>Request Monthly Fees - " . $school_name . "</title>";
require_once("../../../includes/header-close.php");
require_once("../../../includes/dashboard-navbar.php");

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    include_once("../../../includes/permission-denied.php");
}

$student_ids_string = $_REQUEST['student_ids'] ?? '';
$student_ids = explode(',', $student_ids_string);

if (empty($student_ids_string) || count($student_ids) == 0) {
    echo "<div class='container mt-4'><div class='alert alert-danger'>No student IDs provided.</div></div>";
    include_once("../../../includes/body-close.php");
    exit();
}

// Fetch class-wise new admission fees
$stmt = $pdo->prepare("SELECT class_id, amount FROM class_wise_monthly_fees");
$stmt->execute();
$monthly_fees_setup = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

$filtered_student_ids = [];

?>
<style>
    .studentListTableContainer {
        max-height: 500px;
        min-height: 300px;
        overflow-y: auto;
        scrollbar-width: thin;
        scrollbar-color: #888 #e0e0e0;
        position: relative;
    }

    #studentListTable thead {
        position: sticky;
    }

    .table>thead>tr>th {
        vertical-align: middle !important;
        text-align: center;
    }

    .table thead th {
        position: relative;
    }

    .table tbody td {
        vertical-align: middle !important;
        text-align: center;
    }

    .table tbody td img {
        border-radius: 5px;
        width: 50px;
        object-fit: cover;
        cursor: pointer;
        border: 1px solid #ddd;
    }
</style>

<div class="container-fluid mt-4">
    <div class="card shadow-sm mb-4">
        <div class="card-header d-flex justify-content-between align-items-center bg-primary text-white">
            <div>
                <h4 class="mb-0"><i class="fas fa-money-bill me-2"></i>Request Monthly Fees</h4>
            </div>
            <div>
                <button type="button" class="btn btn-sm btn-danger" onclick="window.close()">
                    <i class="fas fa-window-close me-2"></i>Close Tab
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="mb-3">
                <h5 class="m-0 p-0">Total Students: <span id="total_students_fee_entry"></span></h5>
            </div>
            <div class="row mb-3">
                <div class="col-md-4 mb-2">
                    <input type="text" id="studentSearchBox" class="form-control" placeholder="Search students..." />
                </div>
                <div class="col-md-4 mb-2">
                    <select id="studentListSort" class="form-select">
                        <option value="default" selected>Default Sort (Requested Order)</option>
                        <option value="name-asc">Sort by Name (A-Z)</option>
                        <option value="name-desc">Sort by Name (Z-A)</option>
                        <option value="roll-asc">Sort by Roll No (Low to High)</option>
                        <option value="roll-desc">Sort by Roll No (High to Low)</option>
                    </select>
                </div>
                <div class="col-md-4 mb-2">
                    <select multiple size="10" id="feeMonthSelectForAll" class="form-control form-control-sm feeMonthSelect custom-multiselect">
                    </select>
                </div>
            </div>

            <div class="d-flex justify-content-end mb-3">
                <button class="btn btn-primary" id="requestFeesBtn"><i class="fas fa-floppy-disk me-2"></i>Request Fees</button>
            </div>

            <div class="studentListTableContainer table-responsive rounded-2">
                <table class="table table-bordered table-striped" id="studentListTable">
                    <thead class="table-dark">
                        <tr>
                            <th><i class="fas fa-user"></i></th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Class</th>
                            <th style="min-width: 200px;">Months</th>
                            <th>Total Fees</th>
                            <th style="min-width: 120px;">Tution Fees</th>
                            <th style="min-width: 120px;">Car Fees</th>
                            <th style="min-width: 120px;">Coaching Fees</th>
                            <th style="min-width: 120px;">Tiffin Fees</th>
                            <th style="min-width: 120px;">Hostel Fees</th>
                            <th style="min-width: 120px;">Discount</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($student_ids as $original_index => $student_id):
                            $student_info = getStudentInfo($pdo, $student_id);
                            if (!$student_info) {
                                continue;
                            }

                            if (in_array($student_id, $filtered_student_ids)) {
                                continue;
                            }

                            $filtered_student_ids[] = $student_id;

                            $class_id = $student_info['class_id'];

                            $car_fee = $student_info['car_fee'] ?? 0;
                            $hostel_fee = $student_info['hostel_fee'] ?? 0;
                            $coaching_fee = $student_info['coaching_fee'] ?? 0;
                            $tiffin_fee = $student_info['tiffin_fee'] ?? 0;
                            $custom_class_fee = $student_info['custom_class_fee'] ?? 0;
                            $class_fee = $monthly_fees_setup[$class_id] ?? 0;

                            if ($custom_class_fee > 0) {
                                $class_fee = $custom_class_fee;
                            }

                           $total_fees = $class_fee + $car_fee + $hostel_fee + $coaching_fee + $tiffin_fee;

                            // PREPARE DATA FOR SORTING
                            $sort_name = strtolower($student_info['name']);
                        ?>
                            <tr id="trow-<?= $student_id ?>"
                                class="student-row"
                                data-original-index="<?= $original_index ?>" data-student-id="<?= $student_id ?>"
                                data-name="<?= $sort_name ?>"
                                data-class-info="<?= $student_info['class_name'] . ' (' . $student_info['section_name'] . ')' ?>"
                                data-roll-no="<?= $student_info['roll_no'] ?? 0 ?>">
                                <td>
                                    <button tabindex="-1" class="btn btn-sm btn-outline-primary more-details-btn" title="View More Details" data-student-id="<?= $student_id ?>">
                                        <i class="fas fa-plus-circle"></i>
                                    </button>
                                </td>
                                <td
                                    title="View Image"
                                    data-fancybox="student-images"
                                    data-caption="<?= $student_info['name'] ?>"
                                    data-src="<?= BASE_URL . "/uploads/students/" . $student_info['student_image']; ?>">
                                    <img
                                        src="<?= BASE_URL . "/uploads/students/" . $student_info['student_image']; ?>"
                                        alt="Img"
                                        loading="lazy" />
                                </td>
                                <td>
                                    <a tabindex="-1"
                                        class="text-decoration-none"
                                        href="<?= BASE_URL ?>/parent/dashboard/student-details.php?student_id=<?= $student_info['student_id'] ?>"
                                        target="_blank">
                                        <?php echo safe_htmlspecialchars($student_info['name']); ?>
                                    </a>
                                    <br>
                                    <small class="text-muted small-text"><?= $student_info['student_id'] ?></small>
                                </td>
                                <td>
                                    <?= $student_info['class_name'] . ' (' . $student_info['section_name'] . ')' ?>
                                    <br>
                                    <small class="text-muted small-text">Roll: <?= $student_info['roll_no']; ?></small>
                                </td>
                                <td>
                                    <select
                                        id="month-year-<?= $student_id ?>"
                                        multiple
                                        size="10"
                                        class="form-control form-control-sm feeMonthSelect custom-multiselect"
                                        tabindex="-1">
                                    </select>
                                </td>
                                <td>
                                    <span id="total-fee-<?= $student_id ?>" class="badge rounded-pill bg-success fw-bold">
                                        <?php echo $currency_symbol . $total_fees; ?>
                                    </span>
                                </td>
                                <td>
                                    <input type="text" id="tution-fee-<?= $student_id ?>" value="<?= $class_fee ?>" class="form-control form-control-sm tution-fee text-center" min="0">
                                </td>
                                <td>
                                    <input type="text" id="car-fee-<?= $student_id ?>" value="<?= $car_fee ?>" class="form-control form-control-sm car-fee text-center" min="0">
                                </td>
                                <td>
                                    <input type="text" id="coaching-fee-<?= $student_id ?>" value="<?= $coaching_fee ?>" class="form-control form-control-sm coaching-fee text-center" min="0">
                                </td>
                                <td>
                                    <input type="text" id="tiffin-fee-<?= $student_id ?>" value="<?= $tiffin_fee ?>" class="form-control form-control-sm tiffin-fee text-center" min="0">
                                </td>
                                <td>
                                    <input type="text" id="hostel-fee-<?= $student_id ?>" value="<?= $hostel_fee ?>" class="form-control form-control-sm hostel-fee text-center" min="0">
                                </td>
                                <td>
                                    <input type="text" id="discount-amount-<?= $student_id ?>" value="0" class="form-control form-control-sm discount-amount text-center" min="0">
                                </td>
                                <td>
                                    <button
                                        data-student-id="<?php echo $student_info['student_id']; ?>"
                                        tabindex="-1"
                                        title="Remove student from list"
                                        class="btn btn-sm btn-danger remove-student-btn">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- <div class="text-end mt-3">
                <button id="submitBtn" class="btn btn-primary" tabindex="-1">
                    <i class="fas fa-check-circle me-2"></i>Submit Fees Entry
                </button>
            </div> -->
        </div>
    </div>
</div>

<!-- Include the modal html -->
<?php include_once('../../../includes/modals/fees-x-payments/financial-details-modal.php'); ?>

<script>
    const currenySymbol = '<?= $currency_symbol ?>';
    let filteredStudentIDs = <?= json_encode($filtered_student_ids); ?>;
    const monthly_fees_setup = <?= json_encode($monthly_fees_setup); ?>;
    let financialDataLoaded = [];
    let hasDataEntryError = false;

    $(document).ready(function() {
        // Initial calls
        sortStudentRows();
        populateMonthSelection();

        // Fill total students count
        $('#total_students_fee_entry').text(filteredStudentIDs.length);

        // Remove student from the list
        $('.remove-student-btn').click(function() {
            const studentID = $(this).data('student-id');
            $(`#trow-${studentID}`).remove();
            filteredStudentIDs = filteredStudentIDs.filter(id => id !== studentID);
            $('#total_students_fee_entry').text(filteredStudentIDs.length);
        });

        // Search functionality
        $('#studentSearchBox').on('keyup', function() {
            var value = $(this).val().toLowerCase();
            $("#studentListTable tbody tr").filter(function() {
                // Toggle visibility based on whether the row text contains the search term
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });

        // Sorting functionality
        $('#studentListSort').change(function() {
            sortStudentRows();
        });

        // --- 3. Show Student Financial Details in Modal ---
        $('.more-details-btn').on('click', function() {
            const studentId = $(this).data('student-id');
            const studentName = capitalize($(this).closest('tr').data('name'));

            $('#studentFinancialDetailsModalLabel').html(`Financial Details: <b>${studentName}</b>`);

            if (financialDataLoaded[studentId]) {
                $('#studentFinancialDetailsModalBody').html(financialDataLoaded[studentId]);
                $('#studentFinancialDetailsModal').modal('show');
                return;
            }

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/get/fees-x-payments/monthly/get-student-financial-overview.php',
                type: 'POST',
                data: {
                    student_id: studentId
                },
                dataType: 'json',
                beforeSend: function() {
                    showLoadingAlert('Fetching student financial details...');
                },
                success: function(response) {
                    Swal.close();
                    if (response.success) {
                        const unpaidFeesTable = response.unpaid_fees_table;
                        const paidFeesTable = response.paid_fees_table;
                        const fullHtml = unpaidFeesTable + paidFeesTable;

                        $('#studentFinancialDetailsModalBody').html(fullHtml);
                        $('#studentFinancialDetailsModal').modal('show');

                        if (!financialDataLoaded[studentId]) {
                            financialDataLoaded[studentId] = fullHtml;
                        }
                    } else {
                        showErrorAlert(response.message);
                    }
                },
                error: function(xhr) {
                    console.error(xhr.responseText);
                    showErrorAlert('Error fetching student financial details');
                }
            });
        });

        // Update total fee amount on input change
        $('.tution-fee, .car-fee, .coaching-fee, .tiffin-fee, .hostel-fee, .discount-amount').on('input', function() {
            let studentId = $(this).closest('tr').data('student-id');

            let tutionFeeInput = $('#tution-fee-' + studentId);
            let carFeeInput = $('#car-fee-' + studentId);
            let coachingFeeInput = $('#coaching-fee-' + studentId);
            let tiffinFeeInput = $('#tiffin-fee-' + studentId);
            let hostelFeeInput = $('#hostel-fee-' + studentId);
            let discountAmountInput = $('#discount-amount-' + studentId);

            let tutionFee = tutionFeeInput.val();
            let carFee = carFeeInput.val();
            let coachingFee = coachingFeeInput.val();
            let tiffinFee = tiffinFeeInput.val();
            let hostelFee = hostelFeeInput.val();
            let discountAmount = discountAmountInput.val();

            if (tutionFee === '' || !isNumeric(tutionFee) || tutionFee <= 0) {
                tutionFeeInput.addClass('is-invalid');
                tutionFeeInput.removeClass('is-valid');
                hasDataEntryError = true;
                return;
            } else {
                tutionFeeInput.removeClass('is-invalid');
                tutionFeeInput.addClass('is-valid');
            }

            if (carFee === '' || !isNumeric(carFee) || carFee < 0) {
                carFeeInput.addClass('is-invalid');
                carFeeInput.removeClass('is-valid');
                hasDataEntryError = true;
                return;
            } else {
                carFeeInput.removeClass('is-invalid');
                carFeeInput.addClass('is-valid');
            }

            if (coachingFee === '' || !isNumeric(coachingFee) || coachingFee < 0) {
                coachingFeeInput.addClass('is-invalid');
                coachingFeeInput.removeClass('is-valid');
                hasDataEntryError = true;
                return;
            } else {
                coachingFeeInput.removeClass('is-invalid');
                coachingFeeInput.addClass('is-valid');
            }

            if (tiffinFee === '' || !isNumeric(tiffinFee) || tiffinFee < 0) {
                tiffinFeeInput.addClass('is-invalid');
                tiffinFeeInput.removeClass('is-valid');
                hasDataEntryError = true;
                return;
            } else {
                tiffinFeeInput.removeClass('is-invalid');
                tiffinFeeInput.addClass('is-valid');
            }

            if (hostelFee === '' || !isNumeric(hostelFee) || hostelFee < 0) {
                hostelFeeInput.addClass('is-invalid');
                hostelFeeInput.removeClass('is-valid');
                hasDataEntryError = true;
                return;
            } else {
                hostelFeeInput.removeClass('is-invalid');
                hostelFeeInput.addClass('is-valid');
            }

            if (discountAmount === '' || !isNumeric(discountAmount) || discountAmount < 0) {
                discountAmountInput.addClass('is-invalid');
                discountAmountInput.removeClass('is-valid');
                hasDataEntryError = true;
                return;
            } else {
                discountAmountInput.removeClass('is-invalid');
                discountAmountInput.addClass('is-valid');
            }

            // লাইভ টোটাল ক্যালকুলেশনে কোচিং এবং টিফিন ফি যোগ করা হলো
            let totalFee = parseFloat(tutionFee) + 
                           parseFloat(carFee) + 
                           parseFloat(coachingFee) + 
                           parseFloat(tiffinFee) + 
                           parseFloat(hostelFee) - 
                           parseFloat(discountAmount);

            let formattedTotalFee = (totalFee % 1 === 0) ? totalFee : totalFee.toFixed(2);
            $('#total-fee-' + studentId).text(currenySymbol + formattedTotalFee);

            hasDataEntryError = false;
        });

        $('input[type=text]').on('focus', function() {
            $(this).select();
        });

        $('#feeMonthSelectForAll').on('change', function() {
            let selectedMonths = $(this).val();
            let $studentMonthSelects = $('#studentListTable tbody .feeMonthSelect');
            $studentMonthSelects.val(selectedMonths);
            $studentMonthSelects.multiselect('refresh');
        });

        // Submit button click
        $('#requestFeesBtn').on('click', function() {
            if (hasDataEntryError) {
                toastr.error('Please enter valid data for all fields.');
                return;
            }

            let studentsData = buildStudentsData();

            if (studentsData.length === 0) {
                toastr.error('Please select at least one student.');
                return;
            }

            // Send request to server
            confirmBeforeSubmit(studentsData);
        })
    });

    // Function to sort student rows
    function sortStudentRows() {
        var sortBy = $('#studentListSort').val();
        var rows = $('#studentListTable tbody tr').get();

        rows.sort(function(a, b) {
            var nameA = $(a).data('name');
            var nameB = $(b).data('name');

            if (sortBy === 'default') {
                return parseInt($(a).data('original-index')) - parseInt($(b).data('original-index'));
            } else if (sortBy === 'roll-asc') {
                return parseInt($(a).data('roll-no')) - parseInt($(b).data('roll-no'));
            } else if (sortBy === 'roll-desc') {
                return parseInt($(b).data('roll-no')) - parseInt($(a).data('roll-no'));
            } else if (sortBy === 'name-asc') {
                return nameA.localeCompare(nameB);
            } else if (sortBy === 'name-desc') {
                return nameB.localeCompare(nameA);
            }
            return 0;
        });

        $.each(rows, function(index, row) {
            $('#studentListTable tbody').append(row);
        });
    }

    // Populate month-year selection
    function populateMonthSelection() {

        const now = new Date();
        const totalMonths = 12; // 12 months back and 12 months forward
        // Clear existing options first to prevent duplicates if called multiple times
        $('.feeMonthSelect').empty();

        for (let i = totalMonths; i >= -totalMonths; i--) {
            const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
            const month = date.toLocaleString('default', {
                month: 'long'
            });
            const year = date.getFullYear();
            const value = `${month} ${year}`;

            $('.feeMonthSelect').each(function() {
                const option = document.createElement('option');
                option.value = value;
                option.textContent = value;

                // Set selected if it's the current month and year
                if (date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear()) {
                    option.selected = true;
                }

                $(this).append(option);
            });
        }
    }

    // Build students data
    function buildStudentsData() {
        let studentsData = [];

        $('#studentListTable tbody tr').each(function() {
            let studentId = $(this).data('student-id');
            let studentName = capitalize($(this).data('name'));
            let classInfo = $(this).data('class-info');
            let rollNo = $(this).data('roll-no');
            let tutionFee = $('#tution-fee-' + studentId).val();
            let carFee = $('#car-fee-' + studentId).val();
            let coachingFee = $('#coaching-fee-' + studentId).val();
            let tiffinFee = $('#tiffin-fee-' + studentId).val();
            let hostelFee = $('#hostel-fee-' + studentId).val();
            let discountAmount = $('#discount-amount-' + studentId).val();

            let actualFee = parseFloat(tutionFee) + parseFloat(carFee) + parseFloat(hostelFee) + parseFloat(coachingFee) + parseFloat(tiffinFee);
            let offerAmount = parseFloat(tutionFee) + parseFloat(carFee) + parseFloat(hostelFee) + parseFloat(coachingFee) + parseFloat(tiffinFee) - parseFloat(discountAmount);

            let monthYear = $('#month-year-' + studentId).val();

            studentsData.push({
                studentId: studentId,
                studentName: studentName,
                classInfo: classInfo,
                rollNo: rollNo,
                tutionFee: tutionFee,
                carFee: carFee,
                coachingFee: coachingFee,
                tiffinFee: tiffinFee,
                hostelFee: hostelFee,
                discountAmount: discountAmount,
                actualFee: actualFee,
                offerAmount: offerAmount,
                monthYear: monthYear
            });
        });

        return studentsData;
    }

    // Confirm before submitting (Builds the HTML)
    function buildConfirmationTable(studentsFeeData) {
        let tableHtml = `
        <div class="table-responsive text-start border rounded-3 shadow-sm" style="max-height: 60vh; overflow-y: auto; scrollbar-width: thin;">
            <table class="table table-sm table-hover align-middle mb-0" style="font-size: 0.85rem; white-space: nowrap;">
                <thead class="table-dark sticky-top" style="z-index: 1;">
                    <tr>
                        <th class="py-2 px-3">Student</th>
                        <th class="py-2">Class (Roll)</th>
                        <th class="py-2 text-end">Tution</th>
                        <th class="py-2 text-end">Car</th>
                        <th class="py-2 text-end">Hostel</th>
                        <th class="py-2 text-end text-warning">Discount</th>
                        <th class="py-2 text-end text-info">Net Total</th>
                        <th class="py-2 px-3">Month(s)</th>
                    </tr>
                </thead>
                <tbody>`;

        studentsFeeData.forEach(function(data) {
            // Handle month array safely and format for display
            let months = Array.isArray(data.monthYear) ? data.monthYear.join(', ') : (data.monthYear || '<span class="text-danger">None selected</span>');

            tableHtml += `
                <tr>
                    <td class="px-3 fw-bold text-primary">${data.studentName}</td>
                    <td>${data.classInfo} <br><small class="text-muted">Roll: ${data.rollNo}</small></td>
                    <td class="text-end">${currenySymbol}${parseFloat(data.tutionFee).toFixed(2)}</td>
                    <td class="text-end">${currenySymbol}${parseFloat(data.carFee).toFixed(2)}</td>
                    <td class="text-end">${currenySymbol}${parseFloat(data.hostelFee).toFixed(2)}</td>
                    <td class="text-end text-danger fw-bold">- ${currenySymbol}${parseFloat(data.discountAmount).toFixed(2)}</td>
                    <td class="text-end text-success fw-bold" style="font-size: 0.95rem;">${currenySymbol}${parseFloat(data.offerAmount).toFixed(2)}</td>
                    <td class="px-3"><span class="d-inline-block text-wrap" style="max-width: 160px; font-size: 0.8rem; line-height: 1.2;">${months}</span></td>
                </tr>`;
        });

        tableHtml += `</tbody></table></div>`;

        return tableHtml;
    }

    // Confirm before submitting (Triggers the SweetAlert)
    function confirmBeforeSubmit(studentsFeeData) {
        Swal.fire({
            title: '<i class="fas fa-file-invoice-dollar text-primary me-2"></i> Confirm Fee Request',
            html: buildConfirmationTable(studentsFeeData),
            icon: 'info',
            width: '1000px', // Expands the modal to fit the table comfortably
            showCancelButton: true,
            confirmButtonColor: '#0d6efd',
            cancelButtonColor: '#dc3545',
            confirmButtonText: '<i class="fas fa-check-circle me-1"></i> Submit Request',
            cancelButtonText: '<i class="fas fa-times-circle me-1"></i> Cancel',
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-primary px-4 py-2 me-2',
                cancelButton: 'btn btn-danger px-4 py-2'
            },
            buttonsStyling: false // Allows custom bootstrap button classes to apply cleanly
        }).then((result) => {
            if (result.isConfirmed) {
                submitData(studentsFeeData);
            }
        });
    }

    // Function to submit the form
    function submitData(studentsFeeData) {
        $.ajax({
            url: '<?= BASE_URL ?>/api/admin/put/fees-x-payments/monthly/submit-fees-request.php',
            method: 'POST',
            data: {
                studentsFeeData: JSON.stringify(studentsFeeData)
            },
            dataType: 'json',
            beforeSend: function() {
                showLoadingAlert('Submitting fee request...');
            },
            success: function(response) {
                Swal.close();
                if (response.success) {
                    toastr.success(response.message);
                    showDetailedResultModal(response);
                    financialDataLoaded = [];
                } else {
                    showErrorAlert(response.message);
                }
            },
            error: function(xhr) {
                console.error(xhr.responseText);
                showErrorAlert('Error submitting fee request. Report sent to technical support.');
                let errorMessage = "Page: " + window.location.href + "\n\n" + xhr.responseText;
                sendErrorReport(errorMessage);
            }
        });
    }

    // Function to show the detailed result modal
    function showDetailedResultModal(response) {
        // 1. Build the top summary badges
        let html = `
        <div class="mb-3 text-center d-flex justify-content-center gap-3">
            <span class="badge bg-secondary fs-6 py-2 px-3 shadow-sm">Total: ${response.total_records}</span>
            <span class="badge bg-success fs-6 py-2 px-3 shadow-sm">Processed: ${response.processed}</span>
            <span class="badge bg-danger fs-6 py-2 px-3 shadow-sm">Skipped: ${response.skipped}</span>
        </div>
        
        <div class="table-responsive text-start border rounded-3 shadow-sm" style="max-height: 60vh; overflow-y: auto; scrollbar-width: thin;">
            <table class="table table-sm table-hover align-middle mb-0" style="font-size: 0.85rem;">
                <thead class="table-light sticky-top" style="z-index: 1;">
                    <tr>
                        <th class="py-2 px-3">Student</th>
                        <th class="py-2">Month</th>
                        <th class="py-2">Status</th>
                        <th class="py-2 px-3">Remarks / Details</th>
                    </tr>
                </thead>
                <tbody>`;

        // 3. Loop through the backend results array
        if (response.results && response.results.length > 0) {
            response.results.forEach(item => {
                let statusBadge = '';
                let rowClass = '';
                let textClass = 'text-muted';

                if (item.action === 'created') {
                    statusBadge = '<span class="badge bg-success"><i class="fas fa-check me-1"></i>Created</span>';
                } else if (item.action === 'updated') {
                    statusBadge = '<span class="badge bg-info text-dark"><i class="fas fa-sync-alt me-1"></i>Updated</span>';
                } else {
                    statusBadge = '<span class="badge bg-danger"><i class="fas fa-times me-1"></i>Skipped</span>';
                    rowClass = 'table-danger bg-opacity-10';
                    textClass = 'text-danger fw-bold';
                }

                html += `
                <tr class="${rowClass}">
                    <td class="px-3 fw-bold text-nowrap">${item.name} <br><small class="text-muted fw-normal">ID: ${item.student_id}</small></td>
                    <td class="text-nowrap">${item.month_year}</td>
                    <td>${statusBadge}</td>
                    <td class="px-3"><small class="${textClass}">${item.message}</small></td>
                </tr>`;
            });
        } else {
            html += `<tr><td colspan="4" class="text-center py-3 text-muted">No detailed results available.</td></tr>`;
        }

        html += `</tbody></table></div>`;

        // 4. Trigger the SweetAlert
        Swal.fire({
            title: '<i class="fas fa-clipboard-list text-primary me-2"></i> Submission Report',
            html: html,
            icon: response.skipped > 0 ? 'warning' : 'success', // Use warning icon if anything was skipped
            width: '900px', // Wide enough for the table
            confirmButtonText: '<i class="fas fa-check-circle me-1"></i> Acknowledge & Close',
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-primary px-4'
            },
            buttonsStyling: false
        }).then((result) => {
            // Optional: Clean up the UI after they close the modal
            if (result.isConfirmed || result.isDismissed) {
                // e.g., location.reload(); OR remove successfully processed rows from your HTML table
            }
        });
    }
</script>

<?php include_once("../../../includes/body-close.php"); ?>