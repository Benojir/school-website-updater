<?php
/** @var string $school_name
 * @var array $schoolSettings
 */
include_once("../../includes/auth-check.php");
require_once("../../includes/header-open.php");
echo "<title>Payment History - " . $school_name . "</title>";
require_once("../../includes/header-close.php");
require_once("../../includes/dashboard-navbar.php");

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    include_once("../../includes/permission-denied.php");
}

$adminAuthData = getAuthenticatedAdmin($pdo);
$adminId = $adminAuthData['user_id'];
$security_pin = $adminAuthData['security_pin'];
$isAdminSuperAdmin = isSuperAdmin() ? 1 : 0;

// Validate payment type
$payment_type = "";
if (isset($_REQUEST['payment-type'])) {
    $payment_type = $_REQUEST['payment-type'];
    if ($payment_type !== 'admission' && $payment_type !== 'monthly') {
        $payment_type = "";
    }
}

// Get all role IDs with manage fees permission
// Use FETCH_COLUMN to get a simple list like [2, 5, 8]
$stmt = $pdo->prepare("SELECT role_id FROM admin_permissions WHERE permission = ?");
$stmt->execute([PERM_MANAGE_FEES]);
$role_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Initialize $users as an empty array in case no roles are found
$users = [];

// Get all users associated with those roles
if (!empty($role_ids)) {
    // Create a string of placeholders (?, ?, ?) for the IN clause
    $placeholders = implode(',', array_fill(0, count($role_ids), '?'));

    $stmt = $pdo->prepare("SELECT id, full_name FROM users WHERE role_id IN ($placeholders)");
    $stmt->execute($role_ids);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Generate admin select options
$admin_select_options = '<option value="" selected>All Admins</option>';
$admin_select_options .= '<option value="unknown">Unknown</option>';

// Get all super admins
$stmt = $pdo->prepare("SELECT id, full_name FROM users WHERE user_role = 'superadmin'");
$stmt->execute();
$super_admins = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Track IDs we've already added to prevent duplicates (if a superadmin also has the role)
$added_ids = [];

// Add Super Admins (Skipping ID 1)
foreach ($super_admins as $super_admin) {
    if ($super_admin['id'] == 1) continue;

    $admin_select_options .= '<option value="' . $super_admin['id'] . '">' . $super_admin['full_name'] . '</option>';
    $added_ids[] = $super_admin['id'];
}

// Add Users with Permission (Checking for duplicates)
foreach ($users as $user) {
    if (!in_array($user['id'], $added_ids)) {
        $admin_select_options .= '<option value="' . $user['id'] . '">' . $user['full_name'] . '</option>';
        $added_ids[] = $user['id'];
    }
}
?>

<style>
    /* Keeps long remarks from blowing up the row height on small screens */
    .remark-cell {
        max-width: 320px;
    }

    .remark-text {
        word-break: break-word;
    }

    .remark-text.collapsed {
        display: -webkit-box;
        -webkit-line-clamp: 2;
        line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }

    .remark-toggle {
        cursor: pointer;
        font-size: 0.75rem;
        color: #0d6efd;
        text-decoration: none;
    }

    .remark-toggle:hover {
        text-decoration: underline;
    }

    /* Date column: payment date on top, entry (updated_at) timestamp beneath it */
    .date-cell {
        line-height: 1.35;
    }

    .date-cell .payment-date {
        font-weight: 600;
        white-space: nowrap;
    }

    .date-cell .entry-date {
        white-space: nowrap;
    }

    /* Entry made on a different day than the payment date - a back-dated entry,
       worth spotting at a glance without shouting about it */
    .date-cell .entry-date.entry-date-differs {
        color: #b26a00 !important;
    }
</style>

<div class="container-fluid mt-4">
    <div class="card shadow-sm">
        <div class="bg-primary text-white d-flex justify-content-between align-items-center px-3 py-2">
            <h4><i class="fas fa-history me-2"></i> <?= ucwords($payment_type) ?> Fees Payment History</h4>
            <div>
                <a href="manage-deleted-payment-logs.php<?= (!empty($payment_type) ? '?payment-type=' . urlencode($payment_type) : '') ?>" class="btn btn-sm btn-light">
                    <i class="fas fa-trash-can-arrow-up me-1"></i> Deleted Log
                </a>
            </div>
        </div>

        <div class="card-body border-bottom">

            <div class="input-group mb-3 <?= (empty($payment_type) ? '' : 'd-none') ?>">
                <span class="input-group-text"><i class="fas fa-credit-card"></i></span>
                <select class="form-control" onchange="refreshWithPaymentType(this.value)">
                    <option value="" selected disabled>-- Select Payment Type --</option>
                    <option value="admission">Admission Fees</option>
                    <option value="monthly">Monthly Fees</option>
                </select>
            </div>

            <div class="row g-3 align-items-center <?= (!empty($payment_type) ? '' : 'd-none') ?>">
                <div class="col-xl-3 col-md-6">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" class="form-control" id="search-input" placeholder="Search students... (Ctrl + /)">
                    </div>
                </div>
                <div class="col-xl-2 col-md-6">
                    <div class="input-group">
                        <span class="input-group-text" title="Filter by payment date"><i class="fas fa-calendar-alt"></i></span>
                        <input type="text" class="form-control" id="date-range-picker" placeholder="Payment date range">
                    </div>
                </div>
                <!-- Second date filter: same UX as the payment-date one above, but it matches the
                     record's updated_at column. The two are mutually exclusive — applying one
                     clears the other (see the flatpickr onClose handlers below). -->
                <div class="col-xl-2 col-md-6">
                    <div class="input-group">
                        <span class="input-group-text" title="Filter by last updated date"><i class="fas fa-clock-rotate-left"></i></span>
                        <input type="text" class="form-control" id="updated-date-range-picker" placeholder="Updated date range">
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <select class="form-select custom-multiselect" id="admin-filter">
                        <?= $admin_select_options ?>
                    </select>
                </div>
                <div class="col-xl-2 col-md-3">
                    <button class="btn btn-secondary w-100" id="reset-filters-btn"><i class="fas fa-sync-alt me-1"></i> Reset</button>
                </div>
            </div>
        </div>

        <div class="card-body bg-light <?= (!empty($payment_type) ? '' : 'd-none') ?>">
            <div class="row text-center">
                <div class="col-md-6">
                    <div class="stat-card p-3">
                        <h6 class="text-muted mb-1">Total Payments (Filtered)</h6>
                        <h4 class="fw-bold mb-0" id="summary-total-amount">₹0.00</h4>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="stat-card p-3">
                        <h6 class="text-muted mb-1">Unique Students Paid (Filtered)</h6>
                        <h4 class="fw-bold mb-0" id="summary-total-students">0</h4>
                    </div>
                </div>
            </div>
        </div>

        <div class="card-body <?= (!empty($payment_type) ? '' : 'd-none') ?>">
            <div id="bulk-actions-bar" class="alert alert-primary d-none d-flex justify-content-between align-items-center py-2 px-3 mb-3">
                <span><span id="selected-count">0</span> payment(s) selected</span>
                <div>
                    <button class="btn btn-sm btn-info" id="bulk-print-btn">
                        <i class="fas fa-print me-1"></i> Print Selected
                    </button>
                    <button class="btn btn-sm btn-outline-secondary ms-2" id="clear-selection-btn">
                        <i class="fas fa-times me-1"></i> Clear Selection
                    </button>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th><input type="checkbox" id="select-all-checkbox" class="form-check-input"></th>
                            <th>Image</th>
                            <th>Payment Date</th>
                            <th>Student</th>
                            <th>Class</th>
                            <th>Father</th>
                            <th>Amount</th>
                            <th>Received By</th>
                            <th>Remark</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="payment-history-body">
                    </tbody>
                </table>
            </div>

            <div id="pagination-container" class="mt-4 d-flex justify-content-center">
            </div>
        </div>
    </div>
</div>

<script>
    // Global state to keep track of current page and filters
    let currentPage = 1;
    let searchTimeout = null;

    // Bulk selection state - persists across pagination/search
    let selectedPaymentIds = new Set();

    // Receipt file name is fixed per payment type for this page
    const receiptFile = '<?= $payment_type ?>' === 'admission' ? 'admission-payment-receipt.php' : 'monthly-payment-receipt.php';

    $(document).ready(function() {
        // Two date range filters live side by side: one matches the payment_date
        // column, the other the updated_at column. They are MUTUALLY EXCLUSIVE —
        // applying one clears the other, so they can never combine into a
        // conflicting (ANDed) query. clear(false) suppresses flatpickr's change
        // event, so clearing the sibling picker never triggers a second fetch.
        // Picking a SINGLE date (closing the picker after one click) is a valid
        // filter too — it means that one day only, see readDateRange().
        const paymentDatePicker = flatpickr("#date-range-picker", {
            mode: "range",
            dateFormat: "Y-m-d",
            onClose: function(selectedDates, dateStr, instance) {
                // When a date (or range) is selected, fetch data for the first page
                if (selectedDates.length > 0) {
                    updatedDatePicker.clear(false); // drop the conflicting updated_at filter
                    fetchPayments(1); // Reset to page 1 on date range change
                }
            }
        });

        // Same UX as above, but filters on the record's updated_at column
        const updatedDatePicker = flatpickr("#updated-date-range-picker", {
            mode: "range",
            dateFormat: "Y-m-d",
            onClose: function(selectedDates, dateStr, instance) {
                if (selectedDates.length > 0) {
                    paymentDatePicker.clear(false); // drop the conflicting payment_date filter
                    fetchPayments(1); // Reset to page 1 on date range change
                }
            }
        });

        // Initial data load
        fetchPayments(currentPage);

        // Verify security pin before accessing the page
        <?php
        if ($schoolSettings['need_security_pin_for_payment_entry'] == 1) {
            echo "verifySecurityPin();";
        }
        ?>

        // --- Event Listeners ---

        // Search input with debounce to avoid excessive AJAX calls
        $('#search-input').on('keyup', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                fetchPayments(1); // Reset to page 1 on new search
            }, 500); // 500ms delay
        });

        // Filter by admin
        $('#admin-filter').on('change', function() {
            fetchPayments(1); // Reset to page 1 on admin filter change
        })

        // Reset filters button
        $('#reset-filters-btn').on('click', function() {
            // 1. Clear standard inputs
            $('#search-input').val('');
            paymentDatePicker.clear();
            updatedDatePicker.clear();

            // 2. Reset the underlying select tag
            $('#admin-filter').val('');

            // 3. Safely reset the Multiselect UI
            $('.custom-multiselect').multiselect('deselectAll', false); // Unchecks everything
            $('.custom-multiselect').multiselect('updateButtonText'); // Restores "Select option(s)" text

            // 4. Clear the search bar inside the dropdown manually
            $('.multiselect-search').val('').trigger('keydown');

            // 5. Fetch fresh data
            fetchPayments(1);
        });

        // Pagination click handler (using event delegation)
        $('#pagination-container').on('click', 'a.page-link', function(e) {
            e.preventDefault();
            const page = $(this).data('page');
            if (page) {
                fetchPayments(page);
            }
        });

        // Focus on search input when pressed CTRL+ /
        $(document).on('keydown', function(e) {
            if (e.ctrlKey && e.key === '/') {
                $('#search-input').focus();
                $('#search-input').select();
            }
        });

        // Individual row checkbox toggle (event delegation, since rows are re-rendered)
        $('#payment-history-body').on('change', '.payment-checkbox', function() {
            const paymentId = String($(this).val());
            if ($(this).is(':checked')) {
                selectedPaymentIds.add(paymentId);
            } else {
                selectedPaymentIds.delete(paymentId);
            }
            updateSelectAllCheckboxState();
            updateBulkActionsBar();
        });

        // Select-all checkbox toggles all checkboxes on the current page
        $('#select-all-checkbox').on('change', function() {
            const isChecked = $(this).is(':checked');
            $('.payment-checkbox').each(function() {
                const paymentId = String($(this).val());
                $(this).prop('checked', isChecked);
                if (isChecked) {
                    selectedPaymentIds.add(paymentId);
                } else {
                    selectedPaymentIds.delete(paymentId);
                }
            });
            updateBulkActionsBar();
        });

        // Clear selection button
        $('#clear-selection-btn').on('click', function() {
            selectedPaymentIds.clear();
            $('.payment-checkbox').prop('checked', false);
            $('#select-all-checkbox').prop('checked', false).prop('indeterminate', false);
            updateBulkActionsBar();
        });

        // Bulk print button - opens a new tab with all selected payment IDs, comma separated
        $('#bulk-print-btn').on('click', function() {
            if (selectedPaymentIds.size === 0) return;
            const idsParam = Array.from(selectedPaymentIds).join(',');
            const url = "<?= BASE_URL ?>/api/download/receipt/" + receiptFile + "?ids=" + idsParam;
            window.open(url, '_blank');
        });
    });

    // Show/hide the bulk actions bar and update the selected count
    function updateBulkActionsBar() {
        const count = selectedPaymentIds.size;
        $('#selected-count').text(count);
        if (count > 0) {
            $('#bulk-actions-bar').removeClass('d-none');
        } else {
            $('#bulk-actions-bar').addClass('d-none');
        }
    }

    // Sync the header "select all" checkbox state (checked/indeterminate/unchecked)
    // based on how many of the currently visible row checkboxes are selected
    function updateSelectAllCheckboxState() {
        const totalOnPage = $('.payment-checkbox').length;
        const checkedOnPage = $('.payment-checkbox:checked').length;
        const selectAllCheckbox = $('#select-all-checkbox');

        if (checkedOnPage === 0) {
            selectAllCheckbox.prop('checked', false).prop('indeterminate', false);
        } else if (checkedOnPage === totalOnPage) {
            selectAllCheckbox.prop('checked', true).prop('indeterminate', false);
        } else {
            selectAllCheckbox.prop('checked', false).prop('indeterminate', true);
        }
    }

    function refreshWithPaymentType(value) {
        if (value) {
            window.location.href = '?payment-type=' + encodeURIComponent(value);
        }
    }

    /**
     * Reads a Flatpickr range input into { start, end }.
     *
     * A range picker holds "Y-m-d to Y-m-d" once two dates are picked, but just
     * "Y-m-d" when only ONE date was picked (the picker was closed after a single
     * click). In that case the day is mirrored into `end`, so a single date means
     * "that one day only". Without the mirror the API receives an open-ended
     * `payment_date >= start` with no upper bound, which is why picking only
     * 5 August used to return everything from 5 August up to today.
     */
    function readDateRange(selector) {
        const parts = ($(selector).val() || '').split(' to ');
        const start = (parts[0] || '').trim();
        const end = (parts[1] || '').trim() || start;
        return {
            start: start,
            end: end
        };
    }

    function fetchPayments(page) {

        const payment_type = '<?= $payment_type ?>';
        if (!payment_type) {
            return;
        }

        currentPage = page;
        const searchQuery = $('#search-input').val();
        const paymentDateRange = readDateRange('#date-range-picker');
        // updated_at range — always empty whenever the payment-date range above is
        // set, since selecting either range clears the other picker
        const updatedDateRange = readDateRange('#updated-date-range-picker');
        const adminId = $('#admin-filter').val();

        // Show a loading state in the table
        $('#payment-history-body').html('<tr><td colspan="10" class="text-center py-5"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        $.ajax({
            url: "<?= BASE_URL ?>/api/admin/get/fees-x-payments/get-payment-histories-admission-x-monthly.php",
            type: "GET",
            data: {
                page: currentPage,
                search: searchQuery,
                startDate: paymentDateRange.start,
                endDate: paymentDateRange.end,
                updatedStartDate: updatedDateRange.start,
                updatedEndDate: updatedDateRange.end,
                adminId: adminId,
                paymentType: payment_type
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    renderTable(response.payments);
                    renderPagination(response.pagination);
                    renderSummary(response.summary);
                    updateSelectAllCheckboxState();
                } else {
                    showErrorAlert(response.message || 'Could not fetch data.');
                    $('#payment-history-body').html('<tr><td colspan="10" class="text-center py-4">Error loading data. Please try again.</td></tr>');
                }
            },
            error: function(e) {
                showErrorAlert("An unknown error occured. Please try again.");
                $('#payment-history-body').html('<tr><td colspan="10" class="text-center py-4 text-danger">Error loading data. Please try again.</td></tr>');
                console.error(e);
                sendErrorReport(e.responseText);
            }
        });
    }

    function renderTable(payments) {
        const tableBody = $('#payment-history-body');
        tableBody.empty();

        if (payments.length === 0) {
            tableBody.html(`
                <tr>
                    <td colspan="10" class="text-center py-4">
                        <i class="fas fa-info-circle fa-2x text-muted mb-3"></i>
                        <h5>No payment records found</h5>
                        <p class="text-muted">Try adjusting your search or date filters.</p>
                    </td>
                </tr>
            `);
            return;
        }

        payments.forEach(payment => {
            const isChecked = selectedPaymentIds.has(String(payment.id));
            const row = `
                <tr id="payment-row-${payment.id}">
                    <td>
                        <input type="checkbox" class="form-check-input payment-checkbox" value="${payment.id}" ${isChecked ? 'checked' : ''}>
                    </td>
                    <td>
                        <img src="<?= BASE_URL ?>/uploads/students/${payment.student_image}" alt="${payment.student_name}" class="img-fluid rounded-circle border" data-fancybox data-caption="${payment.student_name}" style="width: 50px; height: 50px; object-fit: cover; cursor: pointer;">
                    </td>
                    <td>${renderDateCell(payment)}</td>
                    <td>
                        <a href="<?= BASE_URL ?>/parent/dashboard/student-details.php?student_id=${payment.student_id}" class="text-decoration-none" target="_blank">${escapeHtml(payment.student_name)}</a>
                        <small class="text-muted d-block small-text">ID: ${payment.student_id}</small>
                        <small class="text-muted d-block small-text">Reg: ${payment.registration_no}</small>
                    </td>
                    <td>
                        ${escapeHtml(payment.class_name)} - ${escapeHtml(payment.section_name)}
                        <small class="text-muted d-block small-text">Roll: ${payment.roll_no ?? ''}</small>
                    </td>
                    <td>
                        ${escapeHtml(payment.father_name)}
                        <a href="tel:${payment.phone_number}" class="text-decoration-none d-block small-text">+91${payment.phone_number}</a>
                    </td>
                    <td><span class="badge bg-success">₹${parseFloat(payment.payment_amount).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span></td>
                    <td>${escapeHtml(payment.admin_name)}</td>
                    <td title="${escapeHtml(payment.remark)}" width="30%">${renderRemarkCell(payment.remark)}</td>
                    <td>
                        <div class="btn-group" role="group" aria-label="Payment actions">
                            <a href="<?= BASE_URL ?>/api/download/receipt/${receiptFile}?ids=${payment.id}" class="btn btn-sm btn-info" target="_blank">
                                <i class="fas fa-print me-1"></i> Print
                            </a>
                            <button class="btn btn-sm btn-danger" onclick="deletePayment(${payment.id}, ${payment.admin_id})">
                                <i class="fas fa-trash-alt me-1"></i> Delete
                            </button>
                        </div>
                    </td>
                </tr>
            `;
            tableBody.append(row);
        });
    }

    /**
     * Parses a MySQL DATE ("Y-m-d") or DATETIME ("Y-m-d H:i:s") string into a
     * local Date object, or null when the value is empty/unparsable.
     *
     * Both normalisations matter: the space form isn't valid ISO 8601 (older
     * browsers reject it outright), and a bare "Y-m-d" is parsed as UTC midnight,
     * which renders as the PREVIOUS day for anyone in a negative UTC offset.
     * Adding an explicit midnight time makes it parse as local instead.
     */
    function parseMysqlDate(value) {
        if (!value) return null;
        const normalised = String(value).trim().replace(' ', 'T');
        const parsed = new Date(normalised.length <= 10 ? normalised + 'T00:00:00' : normalised);
        return isNaN(parsed.getTime()) ? null : parsed;
    }

    /**
     * Builds the Date column: the payment date on top, and below it the entry
     * timestamp (updated_at — when the record was actually keyed in).
     *
     * When both fall on the same day the sub-line shows only the time, since
     * repeating the date would just be noise. When they differ the entry line
     * spells out its own date and is tinted, so a back-dated entry is obvious.
     */
    function renderDateCell(payment) {
        const paymentDate = parseMysqlDate(payment.payment_date);
        const entryDate = parseMysqlDate(payment.updated_at);

        const paymentLabel = paymentDate ?
            paymentDate.toLocaleDateString('en-GB', {
                day: 'numeric',
                month: 'short',
                year: 'numeric'
            }) :
            '—';

        let html = `
            <div class="date-cell">
                <span class="payment-date" title="Payment date">
                    <i class="fas fa-calendar-alt text-primary me-1"></i>${paymentLabel}
                </span>`;

        if (entryDate) {
            const sameDay = paymentDate && entryDate.toDateString() === paymentDate.toDateString();
            const timeLabel = entryDate.toLocaleTimeString('en-GB', {
                hour: 'numeric',
                minute: '2-digit',
                hour12: true
            });
            const entryLabel = sameDay ?
                timeLabel :
                entryDate.toLocaleDateString('en-GB', {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric'
                }) + ', ' + timeLabel;
            const fullEntry = entryDate.toLocaleString('en-GB', {
                dateStyle: 'full',
                timeStyle: 'short'
            });

            html += `
                <small class="entry-date text-muted d-block small-text ${sameDay ? '' : 'entry-date-differs'}" title="Entry made on ${fullEntry}">
                    <i class="fas fa-clock-rotate-left me-1"></i>Entry: ${entryLabel}
                </small>`;
        }

        return html + `
            </div>`;
    }

    // Number of characters after which a remark is clamped with a "Show more" toggle
    const REMARK_TRUNCATE_LENGTH = 70;

    // Builds the remark cell, clamped to 2 lines when the text is long
    function renderRemarkCell(remark) {
        const text = remark ?? '';
        if (!text) return '';

        const isLong = text.length > REMARK_TRUNCATE_LENGTH;

        return `
            <div class="remark-cell">
                <span class="remark-text ${isLong ? 'collapsed' : ''}">${escapeHtml(text)}</span>
                ${isLong ? `<a class="remark-toggle d-inline-block mt-1" onclick="toggleRemark(this)"><i class="fas fa-chevron-down me-1"></i>Show more</a>` : ''}
            </div>
        `;
    }

    // Expands / collapses a clamped remark
    function toggleRemark(toggle) {
        const text = $(toggle).closest('.remark-cell').find('.remark-text');
        const isCollapsed = text.hasClass('collapsed');

        text.toggleClass('collapsed', !isCollapsed);
        $(toggle).html(isCollapsed ?
            '<i class="fas fa-chevron-up me-1"></i>Show less' :
            '<i class="fas fa-chevron-down me-1"></i>Show more');
    }

    function renderSummary(summary) {
        const totalAmount = parseFloat(summary.totalAmount).toLocaleString('en-IN', {
            style: 'currency',
            currency: 'INR'
        });
        $('#summary-total-amount').text(totalAmount);
        $('#summary-total-students').text(summary.totalStudents);
    }

    function renderPagination(pagination) {
        const {
            currentPage,
            totalPages
        } = pagination;
        const paginationContainer = $('#pagination-container');
        paginationContainer.empty();

        if (totalPages <= 1) return;

        let paginationHtml = '<nav aria-label="Page navigation"><ul class="pagination">';

        // First & Previous
        if (currentPage > 1) {
            paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="1" aria-label="First">&laquo;&laquo;</a></li>`;
            paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage - 1}" aria-label="Previous">&laquo;</a></li>`;
        } else {
            paginationHtml += `<li class="page-item disabled"><span class="page-link">&laquo;&laquo;</span></li>`;
            paginationHtml += `<li class="page-item disabled"><span class="page-link">&laquo;</span></li>`;
        }

        // Numeric Pages
        const startPage = Math.max(1, currentPage - 2);
        const endPage = Math.min(totalPages, currentPage + 2);
        for (let i = startPage; i <= endPage; i++) {
            paginationHtml += `<li class="page-item ${i === currentPage ? 'active' : ''}"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
        }

        // Next & Last
        if (currentPage < totalPages) {
            paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage + 1}" aria-label="Next">&raquo;</a></li>`;
            paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${totalPages}" aria-label="Last">&raquo;&raquo;</a></li>`;
        } else {
            paginationHtml += `<li class="page-item disabled"><span class="page-link">&raquo;</span></li>`;
            paginationHtml += `<li class="page-item disabled"><span class="page-link">&raquo;&raquo;</span></li>`;
        }

        paginationHtml += '</ul></nav>';
        paginationContainer.html(paginationHtml);
    }

    // Your existing delete function, slightly modified to reload data
    function deletePayment(payment_id, admin_id) {

        if (admin_id !== <?= $adminId ?> && <?= $isAdminSuperAdmin ?> == 0) {
            showWarningAlert('You are not authorized to delete this payment record. Only the admin who made the payment can delete it.');
            return;
        }

        let requestData = {
            payment_ids: payment_id,
            payment_type: '<?= $payment_type ?>'
        };

        Swal.fire({
            title: "Are you sure?",
            text: "This will restore related fee records and wallet balances. You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#d33",
            cancelButtonColor: "#3085d6",
            confirmButtonText: "Yes, delete it!",
            customClass: {
                confirmButton: "btn btn-danger px-4 py-2",
                cancelButton: "btn btn-secondary px-4 py-2",
                popup: "rounded-4 shadow-lg"
            }
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: "../../api/admin/delete/fees-x-payments/delete-payment-history-admission-x-monthly.php",
                    type: "POST",
                    data: requestData,
                    dataType: 'json',
                    beforeSend: function() {
                        showLoadingAlert();
                    },
                    success: function(response) {
                        if (response.success) {
                            showSuccessAlert(response.message, "Deleted!");
                            // Remove the deleted payment from the selection set, if present
                            selectedPaymentIds.delete(String(payment_id));
                            updateBulkActionsBar();
                            // Reload the data on the current page after deletion
                            fetchPayments(currentPage);
                        } else {
                            showErrorAlert(response.message || "Something went wrong.", "Can't Delete Payment!");
                        }
                    },
                    error: function(e) {
                        showErrorAlert("Something went wrong while deleting.");
                        console.error(e.responseText);
                    }
                });
            }
        });
    }

    // Function verify security pin
    function verifySecurityPin() {
        Swal.fire({
            title: 'Enter Security Pin',
            input: 'text', // Keep password type for masking
            inputAttributes: {
                autocapitalize: 'off',
                autofocus: 'true',
                // This is the key to stopping the "Saved Password" popup:
                autocomplete: 'one-time-code',
                name: 'my-unique-pin-field',
                style: '-webkit-text-security: disc;'
            },
            showCancelButton: false,
            confirmButtonText: 'Verify & Continue',
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: true,
            showLoaderOnConfirm: true,
            preConfirm: (inputPin) => {
                if (inputPin === '<?= $security_pin ?>') {
                    return true;
                } else {
                    toastr.error('Invalid security pin. Please try again.');
                    return false;
                }
            },
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-primary px-4 py-2',
                cancelButton: 'btn btn-danger px-4 py-2'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.close();
                toastr.success('Security pin verified.');
            }
        });
    }
</script>

<?php include_once("../../includes/body-close.php"); ?>