<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/header-open.php");
echo "<title>Payment History - " . $school_name . "</title>";
require_once("../../includes/header-close.php");
require_once("../../includes/dashboard-navbar.php");

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    include_once("../../includes/permission-denied.php");
}

// Validate payment type
$payment_type = "";
if (isset($_REQUEST['payment-type'])) {
    $payment_type = $_REQUEST['payment-type'];
    if ($payment_type !== 'admission' && $payment_type !== 'monthly') {
        $payment_type = "";
    }
}
?>

<div class="container mt-4">
    <div class="card shadow-sm">
        <div class="bg-primary text-white d-flex justify-content-between align-items-center px-3 py-2">
            <h4><i class="fas fa-history me-2"></i> <?= ucwords($payment_type) ?> Fees Payment History</h4>
            <div>
                <a href="../student/list-students.php" class="btn btn-sm btn-light">
                    <i class="fas fa-arrow-left me-1"></i> Back to Students
                </a>
            </div>
        </div>

        <div class="card-body border-bottom">
            <div class="input-group mb-3 <?= (empty($payment_type) ? '' : 'd-none') ?>">
                <span class="input-group-text"><i class="fas fa-credit-card"></i></span>
                <select class="form-control" onchange="refreshWithPaymentType(this.value)">
                    <option value="" selected disabled>-- Select Payment Type --</option>
                    <option value="admission">Admission Fees</option>
                    <option value="monthly">Monthly Fees</option>
                </select>
            </div>
            <div class="row g-3 align-items-center <?= (!empty($payment_type) ? '' : 'd-none') ?>">
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" class="form-control" id="search-input" placeholder="Search by student name...">
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-calendar-alt"></i></span>
                        <input type="text" class="form-control" id="date-range-picker" placeholder="Filter by payment date range">
                    </div>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-secondary w-100" id="reset-filters-btn"><i class="fas fa-sync-alt me-1"></i> Reset</button>
                </div>
            </div>
        </div>

        <div class="card-body bg-light <?= (!empty($payment_type) ? '' : 'd-none') ?>">
            <div class="row text-center">
                <div class="col-md-6">
                    <div class="stat-card p-3">
                        <h6 class="text-muted mb-1">Total Payments (Filtered)</h6>
                        <h4 class="fw-bold mb-0" id="summary-total-amount">₹0.00</h4>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="stat-card p-3">
                        <h6 class="text-muted mb-1">Unique Students Paid (Filtered)</h6>
                        <h4 class="fw-bold mb-0" id="summary-total-students">0</h4>
                    </div>
                </div>
            </div>
        </div>

        <div class="card-body <?= (!empty($payment_type) ? '' : 'd-none') ?>">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Date</th>
                            <th>Student</th>
                            <th>Father</th>
                            <th>Class & Section</th>
                            <th>Amount</th>
                            <th>Remark</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="payment-history-body">
                    </tbody>
                </table>
            </div>

            <div id="pagination-container" class="mt-4 d-flex justify-content-center">
            </div>
        </div>
    </div>
</div>

<script>
    // Global state to keep track of current page and filters
    let currentPage = 1;
    let searchTimeout = null;

    $(document).ready(function() {
        // Initialize Flatpickr for date range selection
        const datePicker = flatpickr("#date-range-picker", {
            mode: "range",
            dateFormat: "Y-m-d",
            onClose: function(selectedDates, dateStr, instance) {
                // When a date range is selected, fetch data for the first page
                if (selectedDates.length === 2) {
                    fetchPayments(1);
                }
            }
        });

        // Initial data load
        fetchPayments(currentPage);

        // --- Event Listeners ---

        // Search input with debounce to avoid excessive AJAX calls
        $('#search-input').on('keyup', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                fetchPayments(1); // Reset to page 1 on new search
            }, 500); // 500ms delay
        });

        // Reset filters button
        $('#reset-filters-btn').on('click', function() {
            $('#search-input').val('');
            datePicker.clear();
            fetchPayments(1);
        });

        // Pagination click handler (using event delegation)
        $('#pagination-container').on('click', 'a.page-link', function(e) {
            e.preventDefault();
            const page = $(this).data('page');
            if (page) {
                fetchPayments(page);
            }
        });
    });

    function refreshWithPaymentType(value) {
        if (value) {
            window.location.href = '?payment-type=' + encodeURIComponent(value);
        }
    }

    function fetchPayments(page) {

        const payment_type = '<?=$payment_type?>';
        if (!payment_type) {
            return;
        }

        currentPage = page;
        const searchQuery = $('#search-input').val();
        const dateRange = $('#date-range-picker').val().split(' to ');
        const startDate = dateRange[0] || '';
        const endDate = dateRange[1] || '';

        // Show a loading state in the table
        $('#payment-history-body').html('<tr><td colspan="8" class="text-center py-5"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');

        $.ajax({
            url: "../../api/admin/get/fees-x-payments/get-payment-histories-admission-x-monthly.php",
            type: "GET",
            data: {
                page: currentPage,
                search: searchQuery,
                startDate: startDate,
                endDate: endDate,
                paymentType: payment_type
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    renderTable(response.payments);
                    renderPagination(response.pagination);
                    renderSummary(response.summary);
                } else {
                    Swal.fire('Error', response.message || 'Could not fetch data.', 'error');
                    $('#payment-history-body').html('<tr><td colspan="8" class="text-center py-4">Error loading data. Please try again.</td></tr>');
                }
            },
            error: function(e) {
                Swal.fire('Error', 'An unknown error occurred.', 'error');
                $('#payment-history-body').html('<tr><td colspan="8" class="text-center py-4 text-danger">Error loading data. Please try again.</td></tr>');
                console.error(e);
            }
        });
    }

    function renderTable(payments) {
        const tableBody = $('#payment-history-body');
        tableBody.empty();

        if (payments.length === 0) {
            tableBody.html(`
                <tr>
                    <td colspan="8" class="text-center py-4">
                        <i class="fas fa-info-circle fa-2x text-muted mb-3"></i>
                        <h5>No payment records found</h5>
                        <p class="text-muted">Try adjusting your search or date filters.</p>
                    </td>
                </tr>
            `);
            return;
        }

        payments.forEach(payment => {
            const paymentDate = new Date(payment.payment_date).toLocaleDateString('en-GB', {
                day: 'numeric',
                month: 'short',
                year: 'numeric'
            });
            const row = `
                <tr id="payment-row-${payment.id}">
                    <td>${payment.id}</td>
                    <td>${paymentDate}</td>
                    <td>
                        ${escapeHtml(payment.student_name)}
                        <small class="text-muted d-block">ID: ${payment.student_id}</small>
                    </td>
                    <td>${escapeHtml(payment.father_name)}</td>
                    <td>${escapeHtml(payment.class_name)} - ${escapeHtml(payment.section_name)}</td>
                    <td><span class="badge bg-success">₹${parseFloat(payment.payment_amount).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span></td>
                    <td title="${escapeHtml(payment.remark)}" width="30%">${escapeHtml(payment.remark)}</td>
                    <td>
                        <button aria-label="Delete Payment Record" class="btn btn-sm btn-danger" onclick="deletePayment(${payment.id})">
                            <i class="fas fa-trash-alt me-1"></i> Delete
                        </button>
                    </td>
                </tr>
            `;
            tableBody.append(row);
        });
    }

    function renderSummary(summary) {
        const totalAmount = parseFloat(summary.totalAmount).toLocaleString('en-IN', {
            style: 'currency',
            currency: 'INR'
        });
        $('#summary-total-amount').text(totalAmount);
        $('#summary-total-students').text(summary.totalStudents);
    }

    function renderPagination(pagination) {
        const {
            currentPage,
            totalPages
        } = pagination;
        const paginationContainer = $('#pagination-container');
        paginationContainer.empty();

        if (totalPages <= 1) return;

        let paginationHtml = '<nav aria-label="Page navigation"><ul class="pagination">';

        // First & Previous
        if (currentPage > 1) {
            paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="1" aria-label="First">&laquo;&laquo;</a></li>`;
            paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage - 1}" aria-label="Previous">&laquo;</a></li>`;
        } else {
            paginationHtml += `<li class="page-item disabled"><span class="page-link">&laquo;&laquo;</span></li>`;
            paginationHtml += `<li class="page-item disabled"><span class="page-link">&laquo;</span></li>`;
        }

        // Numeric Pages
        const startPage = Math.max(1, currentPage - 2);
        const endPage = Math.min(totalPages, currentPage + 2);
        for (let i = startPage; i <= endPage; i++) {
            paginationHtml += `<li class="page-item ${i === currentPage ? 'active' : ''}"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
        }

        // Next & Last
        if (currentPage < totalPages) {
            paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage + 1}" aria-label="Next">&raquo;</a></li>`;
            paginationHtml += `<li class="page-item"><a class="page-link" href="#" data-page="${totalPages}" aria-label="Last">&raquo;&raquo;</a></li>`;
        } else {
            paginationHtml += `<li class="page-item disabled"><span class="page-link">&raquo;</span></li>`;
            paginationHtml += `<li class="page-item disabled"><span class="page-link">&raquo;&raquo;</span></li>`;
        }

        paginationHtml += '</ul></nav>';
        paginationContainer.html(paginationHtml);
    }

    // Helper to prevent XSS
    function escapeHtml(str) {
        // Check if str is not a string (e.g., null, undefined) and return an empty string if so.
        if (typeof str !== 'string') {
            return '';
        }

        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        // Now that we know str is a string, we can safely call .replace()
        return str.replace(/[&<>"']/g, function(m) {
            return map[m];
        });
    }

    // Your existing delete function, slightly modified to reload data
    function deletePayment(payment_id) {

        let requestData = {
            payment_ids: payment_id,
            payment_type: '<?=$payment_type?>'
        };

        Swal.fire({
            title: "Are you sure?",
            text: "This will restore related fee records and wallet balances. You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#d33",
            cancelButtonColor: "#3085d6",
            confirmButtonText: "Yes, delete it!"
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: "../../api/admin/delete/fees-x-payments/delete-payment-history-admission-x-monthly.php",
                    type: "POST",
                    data: requestData,
                    dataType: 'json',
                    beforeSend: function() {
                        Swal.fire({
                            title: "Processing...",
                            allowOutsideClick: false,
                            didOpen: () => {
                                Swal.showLoading();
                            }
                        });
                    },
                    success: function(response) {
                        if (response.success) {
                            Swal.fire("Deleted!", response.message, "success");
                            // Reload the data on the current page after deletion
                            fetchPayments(currentPage);
                        } else {
                            Swal.fire("Can't Delete Payment!", response.message || "Something went wrong.", "error");
                        }
                    },
                    error: function() {
                        Swal.fire("Failed!", "Something went wrong while deleting.", "error");
                    }
                });
            }
        });
    }
</script>

<?php include_once("../../includes/body-close.php"); ?>