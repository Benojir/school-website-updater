<?php
include_once("../../../includes/auth-check.php");
require_once("../../../includes/header-open.php");
echo "<title>Manage Wallets - " . $school_name . "</title>";
require_once("../../../includes/header-close.php");
require_once("../../../includes/dashboard-navbar.php");

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    include_once("../../../includes/permission-denied.php");
}

// Fetch student wallets
$stmt = $pdo->prepare("SELECT sw.student_id, sw.balance, sw.updated_at, s.name, s.roll_no, s.class_id, s.student_image, s.section_id, c.class_name, sec.section_name 
                        FROM student_wallet AS sw 
                        JOIN students AS s ON sw.student_id = s.student_id
                        JOIN classes AS c ON s.class_id = c.id
                        LEFT JOIN sections AS sec ON s.section_id = sec.id
                        WHERE sw.balance > 0
                        ORDER BY sw.updated_at DESC");
$stmt->execute();
$student_wallets = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
    .table-responsive {
        max-height: 500px;
        overflow-y: auto;
        scrollbar-width: thin;
        scrollbar-color: #888 #e0e0e0;
    }

    .table>thead {
        position: sticky;
    }

    .table>thead>tr>th {
        vertical-align: middle !important;
        text-align: center;
    }

    .table thead th {
        position: relative;
    }

    .table tbody td {
        vertical-align: middle !important;
        text-align: center;
    }

    .table tbody td img {
        border-radius: 5px;
        width: 50px;
        object-fit: cover;
        cursor: pointer;
        border: 1px solid #ddd;
    }
</style>

<div class="container mt-4">
    <div class="card shadow-sm mb-3">
        <div class="card-header d-flex justify-content-between align-items-center bg-primary text-white">
            <div>
                <h4 class="mb-0"><i class="fas fa-wallet me-2"></i>Student Wallets</h4>
            </div>
            <div>
                <button type="button" class="btn btn-sm btn-light" onclick="history.back();">
                    <i class="fas fa-arrow-left me-2"></i>Go Back
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Search:</label>
                    <input type="text" id="studentSearchBox" class="form-control" placeholder="Search by name or student ID..." />
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Sort by:</label>
                    <select id="studentListSort" class="form-select">
                        <option value="name-asc" selected>Name (A-Z)</option>
                        <option value="name-desc">Name (Z-A)</option>
                        <option value="roll-asc">Roll (Low to High)</option>
                        <option value="roll-desc">Roll (High to Low)</option>
                        <option value="balance-asc">Balance (Low to High)</option>
                        <option value="balance-desc">Balance (High to Low)</option>
                        <option value="last_transaction-asc">Last Transaction (Oldest)</option>
                        <option value="last_transaction-desc">Last Transaction (Recent)</option>
                    </select>
                </div>
            </div>
            <div class="mb-3">
                <p class="mb-0 text-primary"><i class="fas fa-user-graduate me-2"></i>Students: <span id="visibleStudentCount"><?= count($student_wallets) ?></span></p>
                <p class="mb-0 text-success mt-2"><i class="fas fa-money-bill me-2"></i>Wallet Balance: <span class="badge bg-success" id="totalWalletBalance">
                        <?php
                        $totalBalance = 0;
                        foreach ($student_wallets as $wallet) {
                            $totalBalance += $wallet['balance'];
                        }
                        echo $currency_symbol . $totalBalance;
                        ?>
                    </span></p>
            </div>
            <div class="table-responsive rounded-3">
                <table class="table table-hover table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th scope="col"><i class="fas fa-user"></i></th>
                            <th scope="col">Image</th>
                            <th scope="col">Name</th>
                            <th scope="col">Class</th>
                            <th scope="col">Balance</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody id="studentList">
                        <?php foreach ($student_wallets as $wallet) : ?>
                            <tr data-student-id="<?= $wallet['student_id'] ?>"
                                data-student-name="<?= strtolower($wallet['name']) ?>"
                                data-student-roll="<?= $wallet['roll_no'] ?>"
                                data-wallet-balance="<?= $wallet['balance'] ?>"
                                data-last-updated="<?= $wallet['updated_at'] ?>">
                                <td>
                                    <button tabindex="-1" class="btn btn-sm btn-outline-primary more-details-btn" title="View More Details" data-student-id="<?= $wallet['student_id'] ?>">
                                        <i class="fas fa-plus-circle"></i>
                                    </button>
                                </td>
                                <td title="View Image"
                                    data-fancybox="student-images"
                                    data-caption="<?= $wallet['name'] ?>"
                                    data-src="<?= BASE_URL . "/uploads/students/" . $wallet['student_image']; ?>">
                                    <img
                                        src="<?= BASE_URL . "/uploads/students/" . $wallet['student_image']; ?>"
                                        alt="Img"
                                        loading="lazy" />
                                </td>
                                <td>
                                    <a tabindex="-1"
                                        class="text-decoration-none"
                                        href="<?= BASE_URL ?>/parent/dashboard/student-details.php?student_id=<?= $wallet['student_id'] ?>"
                                        target="_blank">
                                        <?= $wallet['name'] ?>
                                    </a>
                                    <br>
                                    <small class="text-muted" style="font-size: 0.8rem;"><?= $wallet['student_id'] ?></small>
                                </td>
                                <td>
                                    <span class="badge bg-primary"><?= $wallet['class_name'] . " - " . $wallet['section_name'] ?></span>
                                    <br>
                                    <small class="text-muted" style="font-size: 0.8rem;">Roll: <?= $wallet['roll_no'] ?></small>
                                </td>
                                <td>
                                    <span class="text-success fw-bold" id="wallet-balance-<?= $wallet['student_id'] ?>">
                                        <?php echo $currency_symbol . $wallet['balance']; ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-primary edit-wallet-btn" data-student-id="<?= $wallet['student_id'] ?>" title="Edit student wallet">
                                        <i class="fas fa-edit me-2"></i>Edit
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Include the modal html -->
<?php include_once('../../../includes/modals/fees-x-payments/financial-details-modal.php'); ?>
<?php include_once('../../../includes/modals/student/student-wallet-editor-modal.php'); ?>

<script>
    $(document).ready(function() {

        let editWalletStudentData = {
            'student_id': null,
            'student_name': null
        };

        // --- Client Side Search Functionality ---
        $('#studentSearchBox').on('keyup', function() {
            var value = $(this).val().toLowerCase();
            var visibleCount = 0;

            $("#studentList tr").filter(function() {
                var name = $(this).data('student-name') + "";
                var id = $(this).data('student-id') + "";
                // Check if name or id matches the search value
                var isMatch = name.toLowerCase().indexOf(value) > -1 || id.toLowerCase().indexOf(value) > -1;
                
                $(this).toggle(isMatch);
                
                if(isMatch) visibleCount++;
            });

            $('#visibleStudentCount').text(visibleCount);
        });

        // --- Client Side Sort Functionality ---
        $('#studentListSort').on('change', function() {
            var sortVal = $(this).val();
            var rows = $('#studentList tr').get();

            rows.sort(function(a, b) {
                var A, B;

                if (sortVal == 'name-asc') {
                    A = $(a).data('student-name').toLowerCase();
                    B = $(b).data('student-name').toLowerCase();
                    return A.localeCompare(B);
                } else if (sortVal == 'name-desc') {
                    A = $(a).data('student-name').toLowerCase();
                    B = $(b).data('student-name').toLowerCase();
                    return B.localeCompare(A);
                } else if (sortVal == 'roll-asc') {
                    A = parseInt($(a).data('student-roll'));
                    B = parseInt($(b).data('student-roll'));
                    return A - B;
                } else if (sortVal == 'roll-desc') {
                    A = parseInt($(a).data('student-roll'));
                    B = parseInt($(b).data('student-roll'));
                    return B - A;
                } else if (sortVal == 'balance-asc') {
                    A = parseFloat($(a).data('wallet-balance'));
                    B = parseFloat($(b).data('wallet-balance'));
                    return A - B;
                } else if (sortVal == 'balance-desc') {
                    A = parseFloat($(a).data('wallet-balance'));
                    B = parseFloat($(b).data('wallet-balance'));
                    return B - A;
                } else if (sortVal == 'last_transaction-asc') {
                    A = new Date($(a).data('last-updated'));
                    B = new Date($(b).data('last-updated'));
                    return A - B;
                } else if (sortVal == 'last_transaction-desc') {
                    A = new Date($(a).data('last-updated'));
                    B = new Date($(b).data('last-updated'));
                    return B - A;
                }
            });

            $.each(rows, function(index, row) {
                $('#studentList').append(row);
            });
        });

        // Trigger default sort on load (optional, currently defaults to PHP order which is updated_at DESC)
        // If you want JS to take over immediately: $('#studentListSort').trigger('change');


        // Get wallet transaction history
        $('.more-details-btn').click(function() {
            const studentId = $(this).data('student-id');
            const studentName = capitalize($(this).closest('tr').data('student-name'));
            $('#studentFinancialDetailsModalLabel').html(`Wallet Transactions: <b>${studentName}</b>`);

            $.ajax({
                url: '<?= BASE_URL ?>/api/parent/get/fees-x-payments/get-wallet-transaction-history-data.php',
                method: 'POST',
                data: {
                    'student_id': studentId
                },
                dataType: 'json',
                beforeSend: function() {
                    showLoadingAlert();
                },
                success: function(response) {
                    if (response.success) {
                        Swal.close();
                        const transactionHistoryTable = buildTransactionHistoryTable(response.data.results);
                        $('#studentFinancialDetailsModalBody').html(transactionHistoryTable);
                        $('#studentFinancialDetailsModal').modal('show');
                    } else {
                        showErrorAlert(response.message);
                    }
                },
                error: function(e) {
                    console.error(e);
                    showErrorAlert('An error occurred while processing the request.');
                }
            });
        });

        // Edit wallet button click
        $('.edit-wallet-btn').click(function() {
            editWalletStudentData.student_id = $(this).data('student-id');
            editWalletStudentData.student_name = capitalize($(this).closest('tr').data('student-name'));

            $('#manageWalletModalLabel').html(`Manage Wallet: <b>${editWalletStudentData.student_name}</b>`);
            $('#manageWalletModal').modal('show');
        })

        // Process wallet
        $('#manageWalletForm').submit(function(e) {
            e.preventDefault();

            const $form = $(this);
            const wallet_action = $form.find('#wallet_action').val();
            const wallet_amount = $form.find('#wallet_amount').val();

            if (editWalletStudentData.student_id == null) {
                showWarningAlert('Please refresh the page. Something went wrong.');
                return;
            }
            
            let totalWalletAmount = $('#totalWalletBalance').text().replace('<?= $currency_symbol ?>', '');
            const wallet_balance_span = $('#wallet-balance-' + editWalletStudentData.student_id);
            let wallet_balance = wallet_balance_span.text().replace('<?= $currency_symbol ?>', '');
            let new_balance = parseFloat(wallet_balance);

            if (wallet_action == 'add_funds') {
                new_balance += parseFloat(wallet_amount);
                totalWalletAmount += parseFloat(wallet_amount);
            } else {
                new_balance -= parseFloat(wallet_amount);
                totalWalletAmount -= parseFloat(wallet_amount);
            }

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/put/fees-x-payments/process-wallet.php',
                method: 'POST',
                dataType: 'json',
                data: $form.serialize() + '&student_ids=' + editWalletStudentData.student_id,
                beforeSend: function() {
                    showLoadingAlert();
                },
                success: function(response) {
                    if (response.success) {
                        if (response.not_effected_students > 0) {
                            showErrorAlert(`${editWalletStudentData.student_name}'s wallet is not affected due to insufficient funds.`, 'Insufficient funds');
                        } else {
                            showSuccessAlert(response.message);
                            wallet_balance_span.html(`<?= $currency_symbol ?>${new_balance}`);
                            
                            // Update data attribute for sorting
                            const row = wallet_balance_span.closest('tr');
                            row.attr('data-wallet-balance', new_balance);
                            // Optionally update last transaction time (requires server timestamp or local approx)
                            // row.attr('data-last-updated', new Date().toISOString()); 

                            // Update total wallet balance
                            $('#totalWalletBalance').html(`<?= $currency_symbol ?>${totalWalletAmount}`);
                        }
                        $('#manageWalletModal').modal('hide');
                    } else {
                        showErrorAlert(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', xhr.responseText);
                    showErrorAlert('An error occurred while processing the request.');
                },
                complete: function() {
                    editWalletStudentData.student_id = null;
                    editWalletStudentData.student_name = null;
                    $form[0].reset();
                }
            });
        });
    });

    // Function to build transaction history table
    function buildTransactionHistoryTable(results) {
        let html = `
            <div class="table-responsive">
                <table class="table table-sm">
                    <thead class="table-light">
                        <tr>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th width="35%">Remarks</th>
                        </tr>
                    </thead>
                    <tbody>
        `;
        results.forEach(result => {

            let transaction_type_span = '';
            if (result.transaction_type == 'deposit') {
                transaction_type_span = `<span class="badge bg-success">${capitalize(result.transaction_type)}</span>`;
            } else {
                transaction_type_span = `<span class="badge bg-danger">${capitalize(result.transaction_type)}</span>`;
            }

            html += `
                <tr>
                    <td>${transaction_type_span}</td>
                    <td class="fw-bold"><?= $currency_symbol ?>${result.amount}</td>
                    <td>${formatDateTime(result.created_at)}</td>
                    <td>${result.description}</td>
                </tr>
            `;
        });
        html += `
                    </tbody>
                </table>
            </div>
        `;
        return html;
    }
</script>

<?php include_once("../../../includes/body-close.php"); ?>