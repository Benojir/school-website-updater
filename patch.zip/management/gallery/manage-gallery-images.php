<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage School Gallery Images - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_SCHOOL_GALLERY)) {
    include_once("../../includes/permission-denied.php");
}
?>

<div class="container mt-4">
    <h2 class="mb-4"><i class="fas fa-images me-2"></i>Gallery Management</h2>

    <!-- Upload Form -->
    <div class="card mb-4 border-0 shadow">
        <div class="card-header bg-primary text-white d-flex align-items-center">
            <i class="fas fa-camera me-2"></i>
            <h4 class="mb-0">Add New Photo</h4>
        </div>
        <div class="card-body">
            <form id="uploadForm" enctype="multipart/form-data" class="needs-validation" novalidate>
                <div class="mb-3">
                    <label for="photo" class="form-label"><i class="fas fa-image me-1"></i> Select Photo</label>
                    <div class="file-upload-wrapper">
                        <input class="form-control" type="file" id="photo" name="photo" accept="image/*" required>
                        <div class="invalid-feedback">Please select an image file.</div>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="caption" class="form-label"><i class="fas fa-comment me-1"></i> Caption/Description</label>
                    <textarea class="form-control" id="caption" name="caption" rows="2" placeholder="Enter caption (optional)"></textarea>
                </div>

                <div class="mb-3">
                    <label for="event_date" class="form-label"><i class="fas fa-calendar-day me-1"></i> Event Date</label>
                    <input type="date" class="form-control" id="event_date" name="event_date" required>
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-upload me-1"></i> Upload Photo
                </button>
            </form>
        </div>
    </div>

    <!-- Gallery Items -->
    <div class="card border-0 shadow">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <i class="fas fa-photo-video me-2"></i>
                <h4 class="mb-0">Gallery Photos</h4>
            </div>
            <div class="input-group" style="width: 300px;">
                <span class="input-group-text bg-white"><i class="fas fa-search"></i></span>
                <input type="text" class="form-control" id="searchInput" placeholder="Search by caption or date...">
            </div>
        </div>
        <div class="card-body">
            <div id="galleryContainer" class="row g-3">
                <!-- Gallery items will be loaded here via AJAX -->
                <div class="col-12 text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>

            <!-- Pagination -->
            <div class="d-flex justify-content-center mt-4">
                <nav aria-label="Gallery pagination">
                    <ul class="pagination" id="pagination">
                        <!-- Pagination will be loaded here via AJAX -->
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>

<style>
    .file-upload-wrapper {
        position: relative;
        margin-bottom: 1rem;
    }

    .gallery-img {
        height: 200px;
        object-fit: cover;
        transition: transform 0.3s ease;
    }

    .gallery-img:hover {
        transform: scale(1.03);
    }

    .card-img-top-container {
        overflow: hidden;
        border-radius: 0.25rem 0.25rem 0 0;
    }

    .gallery-card {
        transition: all 0.3s ease;
        border: 1px solid rgba(0, 0, 0, 0.125);
    }

    .gallery-card:hover {
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
    }

    .pagination .page-item.active .page-link {
        background-color: #0d6efd;
        border-color: #0d6efd;
    }
</style>

<script>
    $(document).ready(function() {
        // Set default date to today
        $('#event_date').val(new Date().toISOString().split('T')[0]);

        // Enable Bootstrap validation
        (function() {
            'use strict'
            var forms = document.querySelectorAll('.needs-validation')
            Array.prototype.slice.call(forms)
                .forEach(function(form) {
                    form.addEventListener('submit', function(event) {
                        if (!form.checkValidity()) {
                            event.preventDefault()
                            event.stopPropagation()
                        }

                        form.classList.add('was-validated')
                    }, false)
                })
        })();

        // Current page for pagination
        let currentPage = 1;
        const itemsPerPage = 12; // Adjust as needed

        // Load gallery items on page load
        loadGalleryItems();

        // Form submission handler
        $('#uploadForm').on('submit', function(e) {
            e.preventDefault();

            var formData = new FormData(this);

            $.ajax({
                url: '../../api/admin/put/gallery/upload-gallery-image.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                beforeSend: function() {
                    $('button[type="submit"]').prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span> Uploading...');
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success('Photo uploaded successfully!');
                        $('#uploadForm')[0].reset();
                        $('#uploadForm').removeClass('was-validated');
                        currentPage = 1; // Reset to first page
                        loadGalleryItems();
                    } else {
                        toastr.error(response.message || 'Error uploading photo');
                    }
                },
                error: function(xhr) {
                    toastr.error('Error: ' + xhr.responseText);
                },
                complete: function() {
                    $('button[type="submit"]').prop('disabled', false).html('<i class="fas fa-upload me-1"></i> Upload Photo');
                }
            });
        });

        // Search functionality
        $('#searchInput').on('keyup', function() {
            currentPage = 1; // Reset to first page when searching
            loadGalleryItems($(this).val());
        });

        // Function to load gallery items with pagination
        function loadGalleryItems(searchTerm = '', page = currentPage) {
            $.ajax({
                url: '../../api/admin/get/gallery/get-gallery-images.php',
                type: 'GET',
                data: {
                    search: searchTerm,
                    page: page,
                    per_page: itemsPerPage
                },
                beforeSend: function() {
                    $('#galleryContainer').html('<div class="col-12 text-center py-5"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></div>');
                },
                // In the success callback:
                success: function(response) {
                    $('#galleryContainer').html(response.html || '');

                    // Update pagination
                    if (response.pagination) {
                        $('#pagination').html(response.pagination);
                    }

                    // Initialize Fancybox with the gallery items
                    if (Fancybox.getInstance()) {
                        Fancybox.getInstance().destroy();
                    }

                    // Get all gallery links
                    const galleryLinks = document.querySelectorAll('[data-fancybox="gallery"]');

                    // Convert NodeList to array for Fancybox
                    const galleryItems = Array.from(galleryLinks).map(link => ({
                        src: link.getAttribute('href'),
                        caption: link.getAttribute('data-caption') || ''
                    }));

                    // Initialize Fancybox if we have items
                    if (galleryItems.length > 0) {
                        Fancybox.show(galleryItems, {
                            Thumbs: false,
                            Toolbar: {
                                display: {
                                    left: [],
                                    middle: [],
                                    right: ["close"],
                                },
                            },
                        });
                    }
                },
                error: function(xhr) {
                    $('#galleryContainer').html('<div class="col-12 text-center py-5 text-danger">Error loading gallery items</div>');
                }
            });
        }

        // Pagination click handler
        $(document).on('click', '.page-link:not(.disabled)', function(e) {
            e.preventDefault();
            const page = $(this).data('page');
            if (page) {
                currentPage = page;
                loadGalleryItems($('#searchInput').val(), page);
            }
        });

        // Delete photo handler (using event delegation)
        $(document).on('click', '.delete-photo', function(e) {
            e.preventDefault();
            var id = $(this).data('id');
            var delete_url = $(this).data('delete-url');

            Swal.fire({
                title: 'Delete Photo?',
                text: "This will permanently remove the photo from both the gallery and storage!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: '<i class="fas fa-trash me-1"></i> Delete',
                cancelButtonText: '<i class="fas fa-times me-1"></i> Cancel',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '../../api/admin/delete/gallery/delete-gallery-image.php',
                        type: 'POST',
                        data: {
                            id: id,
                            delete_url: delete_url
                        },
                        beforeSend: function() {
                            $('.delete-photo[data-id="' + id + '"]').html('<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span>');
                        },
                        success: function(response) {
                            if (response.success) {
                                toastr.success('Photo deleted successfully!');
                                loadGalleryItems($('#searchInput').val(), currentPage);
                            } else {
                                toastr.error(response.message || 'Error deleting photo');
                            }
                        },
                        error: function(xhr) {
                            toastr.error('Error: ' + xhr.responseText);
                        },
                        complete: function() {
                            $('.delete-photo[data-id="' + id + '"]').html('<i class="fas fa-trash me-1"></i> Delete');
                        }
                    });
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>