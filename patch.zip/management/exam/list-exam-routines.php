<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage Exam Routines - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_EXAMS)) {
    include_once("../../includes/permission-denied.php");
}


// Pagination setup
$limit = 50;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Search and filter
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$exam_id = isset($_GET['exam_id']) ? (int)$_GET['exam_id'] : '';
$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : '';

// Base query - Modified to only include active exams
$sql = "SELECT er.*, e.exam_name, c.class_name, s.subject_name
        FROM exam_routines er
        JOIN exams e ON er.exam_id = e.id AND e.status = 'active'
        JOIN classes c ON er.class_id = c.id
        JOIN subjects s ON er.subject_id = s.id";

$where = [];
$params = [];

if (!empty($search)) {
    // Removed room_number search as column is deleted
    $where[] = "s.subject_name LIKE ?";
    $params[] = "%$search%";
}

if (!empty($exam_id)) {
    $where[] = "er.exam_id = ?";
    $params[] = $exam_id;
}

if (!empty($class_id)) {
    $where[] = "er.class_id = ?";
    $params[] = $class_id;
}

if (count($where) > 0) {
    $sql .= " WHERE " . implode(" AND ", $where);
}

// Count total records
$count_sql = "SELECT COUNT(*) FROM ($sql) as total";
$count_stmt = $pdo->prepare($count_sql);
$count_stmt->execute($params);
$total_records = $count_stmt->fetchColumn();
$total_pages = ceil($total_records / $limit);

// Add sorting and pagination
// Updated ORDER BY to use theory_exam_date
$sql .= " ORDER BY er.theory_exam_date, er.theory_start_time LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;

// Fetch routines
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$routines = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch exams and classes for filters
$exams = $pdo->query("SELECT * FROM exams WHERE status = 'active'")->fetchAll();
$classes = $pdo->query("SELECT * FROM classes")->fetchAll();
?>

<div class="container py-4"> <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-calendar-alt me-2"></i> Exam Routines</h3>
                <a href="../exam/add-exam-routine.php" class="btn btn-light btn-sm">
                    <i class="fas fa-plus me-1"></i> Add New
                </a>
            </div>
        </div>

        <div class="card-body">
            <form method="GET" class="mb-4">
                <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label small text-muted">Search</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" name="search" class="form-control" placeholder="Search Subject..." value="<?= safe_htmlspecialchars($search) ?>">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small text-muted">Exam</label>
                        <select name="exam_id" class="form-select">
                            <option value="">All Exams</option>
                            <?php foreach ($exams as $exam): ?>
                                <option value="<?= $exam['id'] ?>" <?= $exam_id == $exam['id'] ? 'selected' : '' ?>>
                                    <?= safe_htmlspecialchars($exam['exam_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small text-muted">Class</label>
                        <select name="class_id" class="form-select">
                            <option value="">All Classes</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?= $class['id'] ?>" <?= $class_id == $class['id'] ? 'selected' : '' ?>>
                                    <?= safe_htmlspecialchars($class['class_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-filter me-1"></i> Filter
                        </button>
                    </div>
                </div>
            </form>

            <div class="table-responsive">
                <table class="table table-hover align-middle table-bordered">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 15%">Exam</th>
                            <th style="width: 10%">Class</th>
                            <th style="width: 15%">Subject</th>
                            <th style="width: 10%">Marks</th> <th style="width: 20%">Written (Theory)</th>
                            <th style="width: 20%">Oral (Practical)</th>
                            <th class="text-end" style="width: 10%">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($routines)): ?>
                            <tr>
                                <td colspan="7" class="text-center py-4 text-muted">
                                    <i class="fas fa-calendar-times fa-2x mb-2"></i><br>
                                    No exam routines found
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($routines as $routine): ?>
                                <tr id="routine-<?= $routine['id'] ?>">
                                    <td><?= safe_htmlspecialchars($routine['exam_name']) ?></td>
                                    <td><?= safe_htmlspecialchars($routine['class_name']) ?></td>
                                    <td><?= safe_htmlspecialchars($routine['subject_name']) ?></td>
                                    
                                    <td>
                                        <div class="small">Written: <span class="fw-bold"><?= $routine['theory_marks'] ?></span></div>
                                        <?php if($routine['practical_marks'] > 0): ?>
                                            <div class="small">Oral: <span class="fw-bold"><?= $routine['practical_marks'] ?></span></div>
                                        <?php else: ?>
                                            <div class="small text-muted">Oral: -</div>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <div class="small text-muted"><i class="fas fa-calendar-day me-1"></i> Date</div>
                                        <div class="fw-bold mb-1"><?= date('d M Y', strtotime($routine['theory_exam_date'])) ?></div>
                                        <span class="badge bg-primary">
                                            <i class="far fa-clock me-1"></i>
                                            <?= date('h:i A', strtotime($routine['theory_start_time'])) ?> - <?= date('h:i A', strtotime($routine['theory_end_time'])) ?>
                                        </span>
                                    </td>

                                    <td>
                                        <?php if (!empty($routine['practical_exam_date'])): ?>
                                            <div class="small text-muted"><i class="fas fa-calendar-day me-1"></i> Date</div>
                                            <div class="fw-bold mb-1"><?= date('d M Y', strtotime($routine['practical_exam_date'])) ?></div>
                                            <span class="badge bg-success">
                                                <i class="far fa-clock me-1"></i>
                                                <?= date('h:i A', strtotime($routine['practical_start_time'])) ?> - <?= date('h:i A', strtotime($routine['practical_end_time'])) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted small">Not Scheduled</span>
                                        <?php endif; ?>
                                    </td>

                                    <td class="text-end">
                                        <div class="btn-group">
                                            <a href="../exam/edit-exam-routine.php?id=<?= $routine['id'] ?>" class="btn btn-sm btn-outline-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <button class="btn btn-sm btn-outline-danger delete-btn" data-id="<?= $routine['id'] ?>">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($total_pages > 1): ?>
                <nav aria-label="Page navigation" class="mt-4">
                    <ul class="pagination justify-content-center">
                        <?php if ($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=1&search=<?= urlencode($search) ?>&exam_id=<?= $exam_id ?>&class_id=<?= $class_id ?>">
                                    <i class="fas fa-angle-double-left"></i>
                                </a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?= $page - 1 ?>&search=<?= urlencode($search) ?>&exam_id=<?= $exam_id ?>&class_id=<?= $class_id ?>">
                                    <i class="fas fa-angle-left"></i>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php
                        // Show limited page numbers
                        $start = max(1, $page - 2);
                        $end = min($total_pages, $page + 2);

                        if ($start > 1) {
                            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                        }

                        for ($i = $start; $i <= $end; $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&exam_id=<?= $exam_id ?>&class_id=<?= $class_id ?>">
                                    <?= $i ?>
                                </a>
                            </li>
                        <?php endfor;

                        if ($end < $total_pages) {
                            echo '<li class="page-item disabled"><span class="page-link">...</span></li>';
                        }
                        ?>

                        <?php if ($page < $total_pages): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?= $page + 1 ?>&search=<?= urlencode($search) ?>&exam_id=<?= $exam_id ?>&class_id=<?= $class_id ?>">
                                    <i class="fas fa-angle-right"></i>
                                </a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?= $total_pages ?>&search=<?= urlencode($search) ?>&exam_id=<?= $exam_id ?>&class_id=<?= $class_id ?>">
                                    <i class="fas fa-angle-double-right"></i>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Delete routine with SweetAlert confirmation
        $('.delete-btn').click(function() {
            const routineId = $(this).data('id');
            const routineRow = $('#routine-' + routineId);

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!',
                customClass: {
                    popup: 'rounded-4 shadow-lg'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '../../api/admin/delete/exam/delete-exam-routine.php',
                        type: 'POST',
                        data: {
                            id: routineId
                        },
                        dataType: 'json',
                        success: function(response) {
                            if (response.success) {
                                routineRow.fadeOut(300, function() {
                                    $(this).remove();
                                    toastr.success(response.message);
                                });
                            } else {
                                toastr.error(response.message);
                            }
                        },
                        error: function() {
                            toastr.error('An error occurred. Please try again.');
                        }
                    });
                }
            });
        });

        // Show any toastr message from session
        <?php if (isset($_SESSION['message'])): ?>
            toastr.success("<?= addslashes($_SESSION['message']) ?>");
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>

        // Submit the form when select changes
        $('select').on('change', function() {
            $('form')[0].submit();
        });

        // Auto submit form when user typing and delay 1500ms

        let typingTimer;
        const typingDelay = 1500; // 1500 milliseconds

        $('[name="search"]').on('input', function() {
            clearTimeout(typingTimer);
            typingTimer = setTimeout(() => {
                $('form')[0].submit();
            }, typingDelay);
        });

        // If user presses a key again, reset the timer
        $('[name="search"]').on('keydown', function() {
            clearTimeout(typingTimer);
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>