<?php
/** @var string $school_name */
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage Exam Routines - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

if (!hasPermission(PERM_MANAGE_EXAMS)) {
    include_once("../../includes/permission-denied.php");
}

$exams   = $pdo->query("SELECT * FROM exams WHERE status = 'active'")->fetchAll();
$classes = $pdo->query("SELECT * FROM classes")->fetchAll();
?>

<div class="container py-4">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-calendar-alt me-2"></i> Exam Routines</h3>
                <a href="../exam/add-exam-routine.php" class="btn btn-light btn-sm">
                    <i class="fas fa-plus me-1"></i> Add New
                </a>
            </div>
        </div>

        <div class="card-body">
            <form id="filter-form" class="mb-4">
                <div class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label small text-muted">Search</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" name="search" id="search" class="form-control" placeholder="Search Subject...">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small text-muted">Exam</label>
                        <select name="exam_id" id="exam_id" class="form-select">
                            <option value="">All Exams</option>
                            <?php foreach ($exams as $exam): ?>
                                <option value="<?= $exam['id'] ?>">
                                    <?= safe_htmlspecialchars($exam['exam_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small text-muted">Class</label>
                        <select name="class_id" id="class_id" class="form-select">
                            <option value="">All Classes</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?= $class['id'] ?>">
                                    <?= safe_htmlspecialchars($class['class_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="button" id="btn-filter" class="btn btn-primary w-100">
                            <i class="fas fa-filter me-1"></i> Filter
                        </button>
                    </div>
                </div>
            </form>

            <div class="table-responsive" style="position: relative;">
                <div id="table-loader" style="display:none; position:absolute; top:0; left:0; width:100%; height:100%; background:rgba(255,255,255,0.7); z-index:10; justify-content:center; align-items:center;">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>

                <table class="table table-hover align-middle table-bordered">
                    <thead class="table-light">
                        <tr>
                            <th style="width:15%">Exam</th>
                            <th style="width:10%">Class</th>
                            <th style="width:15%">Subject</th>
                            <th style="width:10%">Marks</th>
                            <th style="width:20%">Written (Theory)</th>
                            <th style="width:20%">Oral (Practical)</th>
                            <th class="text-end" style="width:10%">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="routine-table-body"></tbody>
                </table>
            </div>

            <div id="pagination-container"></div>
        </div>
    </div>
</div>

<script>
$(document).ready(function () {
    let currentPage = 1;

    // ------------------------------------------------------------------ //
    // Helpers
    // ------------------------------------------------------------------ //

    /** Format ISO date string → "12 Jun 2025" */
    function fmtDate(iso) {
        if (!iso) return '';
        const d = new Date(iso + 'T00:00:00');
        return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
    }

    /** Format ISO time string → "09:00 AM" */
    function fmtTime(iso) {
        if (!iso) return '';
        // iso can be "HH:MM:SS" or a full datetime; take last time portion
        const parts = iso.split('T');
        const timePart = parts.length > 1 ? parts[1] : iso;
        const [h, m] = timePart.split(':').map(Number);
        const ampm  = h >= 12 ? 'PM' : 'AM';
        const hour  = ((h % 12) || 12).toString().padStart(2, '0');
        return `${hour}:${m.toString().padStart(2, '0')} ${ampm}`;
    }

    function escHtml(str) {
        return $('<span>').text(str ?? '').html();
    }

    // ------------------------------------------------------------------ //
    // Render helpers
    // ------------------------------------------------------------------ //

    function buildRow(r) {
        const practicalCell = r.practical
            ? `<div class="small text-muted"><i class="fas fa-calendar-day me-1"></i> Date</div>
               <div class="fw-bold mb-1">${fmtDate(r.practical.date)}</div>
               <span class="badge bg-success">
                   <i class="far fa-clock me-1"></i>
                   ${fmtTime(r.practical.start_time)} - ${fmtTime(r.practical.end_time)}
               </span>`
            : `<span class="text-muted small">Not Scheduled</span>`;

        const oralMarks = r.marks.practical > 0
            ? `<div class="small">Oral: <span class="fw-bold">${r.marks.practical}</span></div>`
            : `<div class="small text-muted">Oral: -</div>`;

        return `
        <tr id="routine-${r.id}">
            <td>${escHtml(r.exam_name)}</td>
            <td>${escHtml(r.class_name)}</td>
            <td>${escHtml(r.subject_name)}</td>
            <td>
                <div class="small">Written: <span class="fw-bold">${r.marks.theory}</span></div>
                ${oralMarks}
            </td>
            <td>
                <div class="small text-muted"><i class="fas fa-calendar-day me-1"></i> Date</div>
                <div class="fw-bold mb-1">${fmtDate(r.theory.date)}</div>
                <span class="badge bg-primary">
                    <i class="far fa-clock me-1"></i>
                    ${fmtTime(r.theory.start_time)} - ${fmtTime(r.theory.end_time)}
                </span>
            </td>
            <td>${practicalCell}</td>
            <td class="text-end">
                <div class="btn-group">
                    <a href="../exam/edit-exam-routine.php?id=${r.id}" class="btn btn-sm btn-outline-primary">
                        <i class="fas fa-edit"></i>
                    </a>
                    <button class="btn btn-sm btn-outline-danger delete-btn" data-id="${r.id}">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </div>
            </td>
        </tr>`;
    }

    function buildEmptyRow() {
        return `<tr>
                    <td colspan="7" class="text-center py-4 text-muted">
                        <i class="fas fa-calendar-times fa-2x mb-2"></i><br>
                        No exam routines found
                    </td>
                </tr>`;
    }

    function buildPagination(p) {
        if (p.total_pages <= 1) return '';

        let html = '<nav aria-label="Page navigation" class="mt-4"><ul class="pagination justify-content-center">';
        const cur   = p.current_page;
        const total = p.total_pages;

        if (cur > 1) {
            html += `<li class="page-item"><a class="page-link pagination-link" href="#" data-page="1"><i class="fas fa-angle-double-left"></i></a></li>`;
            html += `<li class="page-item"><a class="page-link pagination-link" href="#" data-page="${cur - 1}"><i class="fas fa-angle-left"></i></a></li>`;
        }

        const start = Math.max(1, cur - 2);
        const end   = Math.min(total, cur + 2);

        if (start > 1) html += `<li class="page-item disabled"><span class="page-link">…</span></li>`;

        for (let i = start; i <= end; i++) {
            html += `<li class="page-item ${i === cur ? 'active' : ''}">
                        <a class="page-link pagination-link" href="#" data-page="${i}">${i}</a>
                     </li>`;
        }

        if (end < total) html += `<li class="page-item disabled"><span class="page-link">…</span></li>`;

        if (cur < total) {
            html += `<li class="page-item"><a class="page-link pagination-link" href="#" data-page="${cur + 1}"><i class="fas fa-angle-right"></i></a></li>`;
            html += `<li class="page-item"><a class="page-link pagination-link" href="#" data-page="${total}"><i class="fas fa-angle-double-right"></i></a></li>`;
        }

        html += '</ul></nav>';
        return html;
    }

    // ------------------------------------------------------------------ //
    // Fetch & render
    // ------------------------------------------------------------------ //

    function fetchRoutines(page = 1) {
        currentPage = page;
        $('#table-loader').css('display', 'flex');

        $.ajax({
            url: '<?= BASE_URL ?>/api/admin/get/exam/fetch-exams-routine.php',
            type: 'POST',
            data: {
                page:     page,
                search:   $('#search').val(),
                exam_id:  $('#exam_id').val(),
                class_id: $('#class_id').val(),
            },
            dataType: 'json',
            success: function (response) {
                $('#table-loader').hide();

                if (!response.success) {
                    toastr.error('Failed to load data.');
                    return;
                }

                // Render rows
                const rows = response.data.length
                    ? response.data.map(buildRow).join('')
                    : buildEmptyRow();

                $('#routine-table-body').html(rows);
                $('#pagination-container').html(buildPagination(response.pagination));
            },
            error: function () {
                $('#table-loader').hide();
                toastr.error('An error occurred while fetching data.');
            }
        });
    }

    // ------------------------------------------------------------------ //
    // Event listeners
    // ------------------------------------------------------------------ //

    fetchRoutines();

    $('#btn-filter').on('click', function (e) {
        e.preventDefault();
        fetchRoutines(1);
    });

    $('#exam_id, #class_id').on('change', function () {
        fetchRoutines(1);
    });

    let typingTimer;
    $('#search').on('input', function () {
        clearTimeout(typingTimer);
        typingTimer = setTimeout(() => fetchRoutines(1), 1000);
    }).on('keydown', function () {
        clearTimeout(typingTimer);
    });

    $(document).on('click', '.pagination-link', function (e) {
        e.preventDefault();
        fetchRoutines($(this).data('page'));
    });

    $(document).on('click', '.delete-btn', function () {
        const routineId  = $(this).data('id');
        const routineRow = $('#routine-' + routineId);

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete it!',
            customClass: { popup: 'rounded-4 shadow-lg' }
        }).then((result) => {
            if (!result.isConfirmed) return;

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/delete/exam/delete-exam-routine.php',
                type: 'POST',
                data: { id: routineId },
                dataType: 'json',
                success: function (response) {
                    if (response.success) {
                        routineRow.fadeOut(300, function () {
                            $(this).remove();
                            toastr.success(response.message);
                            if ($('#routine-table-body tr').length === 0) {
                                fetchRoutines(currentPage);
                            }
                        });
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function () {
                    toastr.error('An error occurred. Please try again.');
                }
            });
        });
    });

    <?php if (isset($_SESSION['message'])): ?>
        toastr.success("<?= addslashes($_SESSION['message']) ?>");
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>
});
</script>

<?php include_once("../../includes/body-close.php"); ?>