<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage Examinations - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_EXAMS)) {
    include_once("../../includes/permission-denied.php");
}

// Show only active exams
$exams = $pdo->query("SELECT * FROM exams WHERE status = 'active' ORDER BY exam_date DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container py-4">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-list me-2"></i> Active Exams</h3>
                <div>
                    <a href="../exam/add-exam.php" class="btn btn-light btn-sm me-2">
                        <i class="fas fa-plus me-1"></i> Add Exam
                    </a>
                    <a href="archived-exams.php" class="btn btn-light btn-sm">
                        <i class="fas fa-archive me-1"></i> Archived Exams
                    </a>
                </div>
            </div>
        </div>

        <div class="card-body">
            <?php if (empty($exams)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                    <h4 class="text-muted">No Active Exams Found</h4>
                    <p class="text-muted">Add a new exam to get started</p>
                    <a href="../exam/add-exam.php" class="btn btn-primary mt-3">
                        <i class="fas fa-plus me-1"></i> Add Exam
                    </a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th width="5%">#</th>
                                <th>Exam Name</th>
                                <th>Exam Date</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th width="15%" class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($exams as $index => $exam): ?>
                                <tr id="exam-<?= $exam['id'] ?>">
                                    <td><?= $index + 1 ?></td>
                                    <td><?= safe_htmlspecialchars($exam['exam_name']) ?></td>
                                    <td><?= date('d M Y', strtotime($exam['exam_date'])) ?></td>
                                    <td>
                                        <span class="badge bg-success">Active</span>
                                    </td>
                                    <td><?= date('d M Y', strtotime($exam['created_at'])) ?></td>
                                    <td class="text-end">
                                        <button class="btn btn-sm btn-warning archive-btn" 
                                                data-id="<?= $exam['id'] ?>" 
                                                data-name="<?= safe_htmlspecialchars($exam['exam_name']) ?>">
                                            <i class="fas fa-archive me-1"></i> Archive
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Archive exam with SweetAlert confirmation
    $('.archive-btn').click(function() {
        const examId = $(this).data('id');
        const examName = $(this).data('name');
        const examRow = $('#exam-' + examId);
        
        Swal.fire({
            title: 'Archive Exam',
            html: `Are you sure you want to archive <strong>${examName}</strong>?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#ffc107',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Yes, archive it!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '../../api/admin/put/exam/archive-exam.php',
                    type: 'POST',
                    data: { exam_id: examId },
                    dataType: 'json',
                    beforeSend: function() {
                        examRow.find('.archive-btn').html('<span class="spinner-border spinner-border-sm me-1"></span> Archiving');
                    },
                    success: function(response) {
                        if (response.success) {
                            toastr.success(response.message);
                            examRow.fadeOut(300, function() {
                                $(this).remove();
                            });
                        } else {
                            toastr.error(response.message);
                            examRow.find('.archive-btn').html('<i class="fas fa-archive me-1"></i> Archive');
                        }
                    },
                    error: function() {
                        toastr.error('An error occurred. Please try again.');
                        examRow.find('.archive-btn').html('<i class="fas fa-archive me-1"></i> Archive');
                    }
                });
            }
        });
    });

    // Show any toastr message from URL parameter
    <?php if (isset($_GET['archived']) && $_GET['archived'] == 1): ?>
        toastr.success('Exam archived successfully.');
    <?php endif; ?>
});
</script>

<?php include_once("../../includes/body-close.php"); ?>