<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage Examinations - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_EXAMS)) {
    include_once("../../includes/permission-denied.php");
}
?>

<div class="container py-4">
    <div class="card shadow-lg mb-5">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-plus-circle me-2"></i> Add New Exam</h3>
            </div>
        </div>

        <div class="card-body p-4 p-md-5">
            <form id="addExamForm" method="POST">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exam_name" class="form-label fw-bold">Exam Name</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-pen"></i></span>
                                <input type="text" name="exam_name" id="exam_name" class="form-control" required
                                    placeholder="e.g. Midterm Exam">
                            </div>
                            <div class="form-text">Enter the exam name (e.g. Final, Unit Test)</div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exam_date" class="form-label fw-bold">Exam Date</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-calendar-day"></i></span>
                                <input type="date" name="exam_date" id="exam_date" class="form-control" required
                                    min="<?= date('Y-m-d') ?>">
                            </div>
                            <div class="form-text">Select the exam date</div>
                        </div>
                    </div>
                </div>

                <div class="text-center mt-4">
                    <button type="submit" id="submitBtn" class="btn btn-primary px-4">
                        <i class="fas fa-save me-2"></i> Save Exam
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Active Exams Cards -->
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-list me-2"></i> Active Exams</h3>
                <div>
                    <a href="archived-exams.php" class="btn btn-light btn-sm">
                        <i class="fas fa-archive me-1"></i> Archived Exams
                    </a>
                </div>
            </div>
        </div>

        <div class="card-body" id="exam_list_table_card">
            <div class="table-responsive">
                <table class="table table-hover align-middle" id="exam_management_table">
                    <thead class="table-light">
                        <tr>
                            <th width="5%">#</th>
                            <th>Exam Name</th>
                            <th>Exam Date</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th width="15%" class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- AJAX will load content here -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    function loadAllActiveExams() {
        $.ajax({
            url: '../../api/admin/get/exam/get-all-exams.php?exam_type=active',
            type: 'GET',
            dataType: 'json',
            beforeSend: function() {
                $('#exam_management_table tbody').empty();
                $('#exam_management_table tbody').append('<tr><td colspan="6"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>');
            },
            success: function(response) {
                $('#exam_management_table tbody').empty();

                if (response.success) {
                    if (response.data.length > 0) {
                        response.data.forEach((exam, index) => {
                            $('#exam_management_table tbody').append(`
                                <tr id="exam-${exam.id}">
                                    <td>${index + 1}</td>
                                    <td>${exam.exam_name}</td>
                                    <td>${exam.exam_date}</td>
                                    <td><span class="badge bg-success">Active</span></td>
                                    <td>${formatDate(exam.created_at)}</td>
                                    <td class="text-end">
                                        <button class="btn btn-sm btn-warning" onclick="archiveExam(${exam.id}, '${escapeHtml(exam.exam_name)}')" title="Archive">
                                            <i class="fas fa-archive me-1"></i>
                                        </button>
                                        <button class="btn btn-sm btn-primary" onclick="renameExam(${exam.id}, '${escapeHtml(exam.exam_name)}')" title="Rename">
                                            <i class="fas fa-pen me-1"></i> 
                                        </button>
                                    </td>
                                </tr>
                            `);
                        })
                    } else {
                        $('#exam_list_table_card').html(`
                            <div class="text-center py-5">
                                <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                                <h4 class="text-muted">No Active Exams Found</h4>
                                <p class="text-muted">Add a new exam to get started</p>
                            </div>
                        `);
                    }
                } else {
                    console.error(response.message);
                    $('#exam_management_table tbody').append(`<tr><td colspan="6" class="text-danger text-center">${response.message}</td></tr>`);
                }
            },
            error: function(xhr, status, error) {
                console.error(error);
                $('#exam_management_table tbody').empty();
                $('#exam_management_table tbody').append('<tr><td colspan="6" class="text-danger text-center">An error occurred while loading exams.</td></tr>');
            }
        });
    }

    // Archive Exam
    function archiveExam(examId, examName) {
        const examRow = $('#exam-' + examId);

        Swal.fire({
            title: 'Archive Exam',
            html: `Are you sure you want to archive <strong>${examName}</strong>?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#ffc107',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Yes, archive it!',
            cancelButtonText: 'Cancel',
            customClass: {
                popup: 'rounded-4 shadow-lg'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '../../api/admin/put/exam/archive-exam.php',
                    type: 'POST',
                    data: {
                        exam_id: examId
                    },
                    dataType: 'json',
                    beforeSend: function() {
                        examRow.find('.archive-btn').html('<span class="spinner-border spinner-border-sm me-1"></span> Archiving');
                    },
                    success: function(response) {
                        if (response.success) {
                            showSuccessAlert(response.message);
                            examRow.fadeOut(300, function() {
                                $(this).remove();
                            });

                            setTimeout(() => {
                                if ($('#exam_management_table tbody').children().length === 0) {
                                    loadAllActiveExams();
                                }
                            }, 500); // Adjust the delay as needed

                        } else {
                            showErrorAlert(response.error);
                            examRow.find('.archive-btn').html('<i class="fas fa-archive me-1"></i> Archive');
                        }
                    },
                    error: function() {
                        showErrorAlert('An error occurred. Please try again.');
                        examRow.find('.archive-btn').html('<i class="fas fa-archive me-1"></i> Archive');
                    }
                });
            }
        });
    }

    // Rename Exam Function
    function renameExam(examId, currentName) {
        Swal.fire({
            title: 'Rename Exam',
            input: 'text',
            inputValue: currentName, // Pre-fill with current name
            inputLabel: 'Enter the new name',
            showCancelButton: true,
            confirmButtonText: 'Update',
            showLoaderOnConfirm: true,
            confirmButtonColor: '#0d6efd',
            cancelButtonColor: '#6c757d',
            customClass: {
                popup: 'rounded-4 shadow-lg'
            },
            inputValidator: (value) => {
                if (!value) {
                    return 'You need to write something!'
                }
            },
            preConfirm: (newName) => {
                // This calls your new PDO PHP file
                return $.ajax({
                    url: '../../api/admin/put/exam/rename-exam.php',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        exam_id: examId,
                        new_exam_name: newName
                    }
                }).then(response => {
                    if (!response.success) {
                        throw new Error(response.message || 'Failed to update');
                    }
                    return response;
                }).catch(error => {
                    Swal.showValidationMessage(
                        `Error: ${error.message || 'Request failed'}`
                    );
                });
            },
            allowOutsideClick: () => !Swal.isLoading()
        }).then((result) => {
            if (result.isConfirmed) {
                // Show success message
                showSuccessAlert(result.value.message);

                // Reload the table to see the change immediately
                loadAllActiveExams();
            }
        });
    }

    $(document).ready(function() {

        // Load all active exams
        loadAllActiveExams();

        // AJAX form submission
        $('#addExamForm').submit(function(e) {
            e.preventDefault();
            const formData = $(this).serialize();
            const submitBtn = $('#submitBtn');

            // Change button state
            submitBtn.prop('disabled', true).html(
                '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Saving...'
            );

            $.ajax({
                url: '../../api/admin/put/exam/save-exam.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        loadAllActiveExams();
                        showSuccessAlert(response.message);
                    } else {
                        showErrorAlert(response.message);
                    }
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i> Save Exam');
                },
                error: function(xhr, status, error) {
                    showErrorAlert('An error occurred while saving the exam.');
                    console.error(error);
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i> Save Exam');
                }
            });
        });

        // Set minimum date to today
        $('#exam_date').attr('min', new Date().toISOString().split('T')[0]);

        // Show any toastr message from URL parameter
        <?php if (isset($_GET['archived']) && $_GET['archived'] == 1): ?>
            toastr.success('Exam archived successfully.');
        <?php endif; ?>
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>