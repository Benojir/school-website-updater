<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Add Exam Routines - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

if (!hasPermission(PERM_MANAGE_EXAMS)) {
    include_once("../../includes/permission-denied.php");
}

$exams = $pdo->query("SELECT * FROM exams WHERE status='active'")->fetchAll();
$classes = $pdo->query("SELECT * FROM classes")->fetchAll();
?>

<div class="container mt-4">
    <div class="card shadow-lg border-0">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-calendar-alt me-2"></i> Add Exam Routines</h3>
                <a href="../exam/list-exam-routines.php" class="btn btn-light btn-sm">
                    <i class="fas fa-list me-1"></i> View Routines
                </a>
            </div>
        </div>

        <div class="card-body">
            <form id="examRoutineForm" method="POST">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">Exam</label>
                        <select name="exam_id" class="form-select" required>
                            <option value="" selected disabled>Select Exam</option>
                            <?php foreach ($exams as $exam): ?>
                                <option value="<?= $exam['id'] ?>"><?= $exam['exam_name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-bold">Class</label>
                        <select name="class_id" id="classSelect" class="form-select" required>
                            <option value="" selected disabled>Select Class</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?= $class['id'] ?>"><?= $class['class_name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-12">
                        <div class="card mb-3">
                            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">Subject Schedule</h5>
                                <button type="button" class="btn btn-sm btn-primary" id="addSubjectBtn" disabled>
                                    <i class="fas fa-plus me-1"></i> Add Subject
                                </button>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-hover mb-0" id="subjectScheduleTable">
                                        <thead class="table-light">
                                            <tr>
                                                <th style="width: 20%">Subject</th>
                                                <th style="width: 10%">Marks (W/O)</th>
                                                <th style="width: 30%">Written (Theory) Schedule</th>
                                                <th style="width: 30%">Oral (Practical) Schedule</th>
                                                <th style="width: 10%">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr id="noSubjectsRow">
                                                <td colspan="5" class="text-center text-muted py-5">
                                                    No subjects added yet. Select a class to add subjects.
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="mt-4 text-end">
                    <button type="button" class="btn btn-secondary me-2" onclick="window.location.href='../exam/list-exam-routines.php'">
                        <i class="fas fa-times me-1"></i> Cancel
                    </button>
                    <button type="submit" id="submitBtn" class="btn btn-primary" disabled>
                        <i class="fas fa-save me-1"></i> Save Routine
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="subjectModal" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">Add Subject to Schedule</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="editRowIndex" value="-1">

                <div class="row g-3 mb-4">
                    <div class="col-md-12">
                        <label class="form-label fw-bold">Subject</label>
                        <select class="form-select" id="modalSubjectSelect">
                            <option value="" selected disabled>Select Subject</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Written Marks (Theory)</label>
                        <input type="number" class="form-control" id="modalTheoryMarks" min="0" value="80">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Oral Marks (Practical)</label>
                        <input type="number" class="form-control" id="modalPracticalMarks" min="0" value="20">
                    </div>
                </div>

                <hr>

                <div class="row g-3">
                    <div class="col-md-6 border-end">
                        <h6 class="text-primary mb-3">Written Exam (Theory)</h6>
                        <div class="mb-3">
                            <label class="form-label">Date</label>
                            <input type="date" class="form-control" id="modalTheoryDate">
                        </div>
                        <div class="row g-2">
                            <div class="col-6">
                                <label class="form-label">Start Time</label>
                                <input type="time" class="form-control" id="modalTheoryStart">
                            </div>
                            <div class="col-6">
                                <label class="form-label">End Time</label>
                                <input type="time" class="form-control" id="modalTheoryEnd">
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <h6 class="text-success mb-3">Oral Exam (Practical)</h6>
                        <div class="mb-3">
                            <label class="form-label">Date</label>
                            <input type="date" class="form-control" id="modalPracDate">
                            <small class="text-muted">Optional if marks are 0</small>
                        </div>
                        <div class="row g-2">
                            <div class="col-6">
                                <label class="form-label">Start Time</label>
                                <input type="time" class="form-control" id="modalPracStart">
                            </div>
                            <div class="col-6">
                                <label class="form-label">End Time</label>
                                <input type="time" class="form-control" id="modalPracEnd">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="confirmAddSubject">Add Subject</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        const subjectModal = new bootstrap.Modal('#subjectModal');
        let classSubjects = [];
        let addedSubjects = [];

        // 1. Smart Time Setting: Auto-set End Time
        $('#modalTheoryStart').change(function() {
            setEndTime($(this).val(), '#modalTheoryEnd');
        });
        $('#modalPracStart').change(function() {
            setEndTime($(this).val(), '#modalPracEnd');
        });

        function setEndTime(startTime, targetSelector) {
            if (!startTime) return;
            // Create a date object, set hours, add 3 hours
            let [hours, minutes] = startTime.split(':');
            let date = new Date();
            date.setHours(parseInt(hours) + 3); // Default 3 hour exam
            date.setMinutes(parseInt(minutes));
            
            // Format back to HH:MM
            let newHours = String(date.getHours()).padStart(2, '0');
            let newMinutes = String(date.getMinutes()).padStart(2, '0');
            $(targetSelector).val(`${newHours}:${newMinutes}`);
        }

        // 2. Load subjects when class changes
        $('#classSelect').change(function() {
            const classId = $(this).val();
            const subjectSelect = $('#modalSubjectSelect');

            // Reset table if class changes
            addedSubjects = [];
            updateSubjectTable();

            if (classId) {
                $('#addSubjectBtn').prop('disabled', false);
                $.get(`../../api/admin/get/subject/get-subjects.php?class_id=${classId}`, function(data) {
                    classSubjects = data;
                    renderSubjectOptions();
                }).fail(function() {
                    toastr.error('Failed to load subjects.');
                });
            } else {
                $('#addSubjectBtn').prop('disabled', true);
            }
        });

        function renderSubjectOptions() {
            const subjectSelect = $('#modalSubjectSelect');
            subjectSelect.html('<option value="" selected disabled>Select Subject</option>');

            // Filter out already added subjects
            const availableSubjects = classSubjects.filter(subject =>
                !addedSubjects.some(added => added.subject_id == subject.id)
            );

            if (availableSubjects.length === 0) {
                subjectSelect.html('<option value="" selected disabled>No subjects available</option>');
            } else {
                $.each(availableSubjects, function(index, subject) {
                    subjectSelect.append(`<option value="${subject.id}">${subject.subject_name}</option>`);
                });
            }
        }

        // 3. Open Modal for NEW Entry
        $('#addSubjectBtn').click(function() {
            $('#editRowIndex').val("-1"); // Reset index
            $('#modalTitle').text("Add Subject to Schedule");
            $('#confirmAddSubject').text("Add Subject");
            $('#modalSubjectSelect').prop('disabled', false).val(""); // Enable select
            
            // Reset fields
            // $('#modalTheoryStart').val('10:00');
            // $('#modalTheoryEnd').val('13:00');
            // $('#modalPracDate').val('');
            // $('#modalPracStart').val('13:00');
            // $('#modalPracEnd').val('16:00');
            
            renderSubjectOptions(); // Re-render to hide used subjects
            subjectModal.show();
        });

        // 4. Open Modal for EDITING
        $(document).on('click', '.edit-subject', function() {
            const index = $(this).data('index');
            const subject = addedSubjects[index];

            $('#editRowIndex').val(index);
            $('#modalTitle').text("Edit Subject Details");
            $('#confirmAddSubject').text("Update Subject");

            // Populate Fields
            // We need to temporarily add the option back to select so we can select it
            $('#modalSubjectSelect').html(`<option value="${subject.subject_id}">${subject.subject_name}</option>`);
            $('#modalSubjectSelect').val(subject.subject_id).prop('disabled', true); // Lock subject

            $('#modalTheoryMarks').val(subject.theory_marks);
            $('#modalPracticalMarks').val(subject.practical_marks);
            $('#modalTheoryDate').val(subject.theory_exam_date);
            $('#modalTheoryStart').val(subject.theory_start_time);
            $('#modalTheoryEnd').val(subject.theory_end_time);

            $('#modalPracDate').val(subject.practical_exam_date);
            $('#modalPracStart').val(subject.practical_start_time);
            $('#modalPracEnd').val(subject.practical_end_time);

            subjectModal.show();
        });

        // 5. Save/Update Button Logic
        $('#confirmAddSubject').click(function() {
            const editIndex = parseInt($('#editRowIndex').val());
            const subjectId = $('#modalSubjectSelect').val();
            const subjectName = $('#modalSubjectSelect option:selected').text();

            // Gather Data
            const data = {
                subject_id: subjectId,
                subject_name: subjectName,
                theory_marks: $('#modalTheoryMarks').val(),
                practical_marks: $('#modalPracticalMarks').val(),
                theory_exam_date: $('#modalTheoryDate').val(),
                theory_start_time: $('#modalTheoryStart').val(),
                theory_end_time: $('#modalTheoryEnd').val(),
                practical_exam_date: $('#modalPracDate').val(),
                practical_start_time: $('#modalPracStart').val(),
                practical_end_time: $('#modalPracEnd').val()
            };

            // Validation
            if (!data.subject_id) return toastr.error('Please select a subject');
            if (!data.theory_exam_date || !data.theory_start_time || !data.theory_end_time) return toastr.error('Written exam details incomplete');
            if (data.theory_start_time >= data.theory_end_time) return toastr.error('Written End time must be after Start time');

            if (data.practical_marks > 0) {
                if(!data.practical_exam_date || !data.practical_start_time || !data.practical_end_time) {
                    return toastr.error('Oral exam details required because marks > 0');
                }
            }

            // Logic Split: Edit vs Add
            if (editIndex > -1) {
                // Update Existing
                addedSubjects[editIndex] = data;
                toastr.success('Subject updated');
            } else {
                // Add New
                if (addedSubjects.some(s => s.subject_id == subjectId)) {
                    return toastr.error('Subject already added');
                }
                addedSubjects.push(data);
                toastr.success('Subject added');
            }

            updateSubjectTable();
            // subjectModal.hide();
        });

        // 6. Remove subject
        $(document).on('click', '.remove-subject', function() {
            const index = $(this).data('index');
            addedSubjects.splice(index, 1);
            updateSubjectTable();
        });

        function updateSubjectTable() {
            const tableBody = $('#subjectScheduleTable tbody');
            
            if (addedSubjects.length === 0) {
                tableBody.html('<tr id="noSubjectsRow"><td colspan="5" class="text-center text-muted py-5">No subjects added yet</td></tr>');
                $('#submitBtn').prop('disabled', true);
                return;
            }

            tableBody.empty();
            $('#submitBtn').prop('disabled', false);

            addedSubjects.forEach((subject, index) => {
                let oralDisplay = '<span class="text-muted small">Not Scheduled</span>';
                if (subject.practical_exam_date) {
                    oralDisplay = `
                        <div class="small"><i class="far fa-calendar me-1"></i> ${subject.practical_exam_date}</div>
                        <div class="small"><i class="far fa-clock me-1"></i> ${subject.practical_start_time} - ${subject.practical_end_time}</div>
                    `;
                }

                const row = `
                <tr>
                    <td>
                        <strong>${subject.subject_name}</strong>
                        <input type="hidden" name="subjects[${index}][subject_id]" value="${subject.subject_id}">
                        <input type="hidden" name="subjects[${index}][subject_name]" value="${subject.subject_name}">
                    </td>
                    <td>
                        <div class="small">W: <input type="hidden" name="subjects[${index}][theory_marks]" value="${subject.theory_marks}">${subject.theory_marks}</div>
                        <div class="small">O: <input type="hidden" name="subjects[${index}][practical_marks]" value="${subject.practical_marks}">${subject.practical_marks}</div>
                    </td>
                    <td>
                        <div class="small"><i class="far fa-calendar me-1"></i> ${subject.theory_exam_date}</div>
                        <div class="small"><i class="far fa-clock me-1"></i> ${subject.theory_start_time} - ${subject.theory_end_time}</div>
                        <input type="hidden" name="subjects[${index}][theory_exam_date]" value="${subject.theory_exam_date}">
                        <input type="hidden" name="subjects[${index}][theory_start_time]" value="${subject.theory_start_time}">
                        <input type="hidden" name="subjects[${index}][theory_end_time]" value="${subject.theory_end_time}">
                    </td>
                    <td>
                        ${oralDisplay}
                        <input type="hidden" name="subjects[${index}][practical_exam_date]" value="${subject.practical_exam_date || ''}">
                        <input type="hidden" name="subjects[${index}][practical_start_time]" value="${subject.practical_start_time || ''}">
                        <input type="hidden" name="subjects[${index}][practical_end_time]" value="${subject.practical_end_time || ''}">
                    </td>
                    <td class="text-center align-middle">
                        <div class="btn-group">
                            <button type="button" class="btn btn-sm btn-outline-primary edit-subject" data-index="${index}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-danger remove-subject" data-index="${index}">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </div>
                    </td>
                </tr>`;
                tableBody.append(row);
            });
        }

        // 7. Final Submission
        $('#examRoutineForm').submit(function(e) {
            e.preventDefault();
            const formData = $(this).serialize();
            const submitBtn = $('#submitBtn');

            submitBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1"></span> Saving...');

            $.ajax({
                url: '../../api/admin/put/exam/save-exam-routine.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            title: 'Success!',
                            text: response.message,
                            icon: 'success',
                            confirmButtonText: 'OK',
                            customClass: {
                                popup: 'rounded-4 shadow-lg',
                                confirmButton: 'btn btn-success px-4 py-2'
                            }
                        }).then(() => {
                            location.reload();
                        });
                    } else {
                        showErrorAlert(response.message);
                    }
                },
                error: function() {
                    showErrorAlert('Server connection failure');
                },
                complete: function() {
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save me-1"></i> Save Routine');
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>