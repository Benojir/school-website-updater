<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Archived Exams - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

if (!hasPermission(PERM_MANAGE_EXAMS)) {
    include_once("../../includes/permission-denied.php");
}
?>

<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h2 class="h4 mb-0"><i class="fas fa-archive me-2"></i>Archived Exams</h2>
                <a href="list-exams.php" class="btn btn-sm btn-light">
                    <i class="fas fa-arrow-left me-1"></i> Back to Active Exams
                </a>
            </div>
        </div>

        <div class="card-body">

            <div id="loader" class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>

            <div id="content-area" class="d-none">
                <div class="table-responsive">
                    <table class="table table-hover table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th width="5%">#</th>
                                <th>Exam Name</th>
                                <th width="15%">Exam Date</th>
                                <th width="10%">Status</th>
                                <th width="15%">Created</th>
                                <th width="15%">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="exam-table-body"></tbody>
                    </table>
                </div>

                <div id="empty-message" class="alert alert-info d-none">
                    No archived exams found.
                </div>

                <nav aria-label="Page navigation" class="mt-3">
                    <ul class="pagination justify-content-center" id="pagination"></ul>
                </nav>
            </div>
        </div>
    </div>
</div>

<?php include_once("../../includes/body-close.php"); ?>

<script>
    // --- 1. Fetch Exams Function ---
    function fetchExams(page) {
        $('#loader').removeClass('d-none');
        $('#content-area').addClass('d-none');

        $.ajax({
            // Pointing to your existing API
            url: '../../api/admin/get/exam/get-all-exams.php',
            type: 'GET',
            data: {
                exam_type: 'archived',
                page: page,
                results_per_page: 10
            },
            dataType: 'json',
            success: function(response) {
                $('#loader').addClass('d-none');
                $('#content-area').removeClass('d-none');

                if (response.success) {
                    renderTable(response.data, page, 10);
                    renderPagination(response.pagination);
                } else {
                    showErrorAlert(response.message);
                }
            },
            error: function() {
                $('#loader').addClass('d-none');
                showErrorAlert("Failed to fetch data.");
            }
        });
    }

    // --- 2. Render Table ---
    function renderTable(data, currentPage, perPage) {
        let html = '';
        if (data.length === 0) {
            $('#empty-message').removeClass('d-none');
            $('.table-responsive').addClass('d-none');
            return;
        }

        $('#empty-message').addClass('d-none');
        $('.table-responsive').removeClass('d-none');

        let startIndex = (currentPage - 1) * perPage;

        data.forEach((exam, index) => {
            // Simple date formatting
            let createdDate = new Date(exam.created_at).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            });

            html += `
                <tr>
                    <td>${startIndex + index + 1}</td>
                    <td>${escapeHtml(exam.exam_name)}</td>
                    <td>${escapeHtml(exam.exam_date)}</td>
                    <td><span class="badge bg-secondary">Archived</span></td>
                    <td>${createdDate}</td>
                    <td>
                        <button class="btn btn-sm btn-success btn-restore" title="Restore" onclick="restoreExam(${exam.id}, '${escapeHtml(exam.exam_name)}')">
                            <i class="fas fa-redo me-1"></i>
                        </button>
                        <button class="btn btn-sm btn-danger btn-delete" onclick="deleteExam(${exam.id}, '${escapeHtml(exam.exam_name)}')" title="Delete">
                            <i class="fas fa-trash me-1"></i>
                        </button>
                    </td>
                </tr>
            `;
        });
        $('#exam-table-body').html(html);
    }

    // --- 3. Render Pagination ---
    function renderPagination(meta) {
        let html = '';
        let totalPages = meta.total_pages;
        let current = meta.page;

        if (totalPages <= 1) {
            $('#pagination').html('');
            return;
        }

        // Prev
        html += `<li class="page-item ${current == 1 ? 'disabled' : ''}">
                    <a class="page-link" href="#" onclick="fetchExams(${current - 1}); return false;">&laquo;</a>
                 </li>`;

        // Numbers
        for (let i = 1; i <= totalPages; i++) {
            let active = (i === current) ? 'active' : '';
            html += `<li class="page-item ${active}">
                        <a class="page-link" href="#" onclick="fetchExams(${i}); return false;">${i}</a>
                     </li>`;
        }

        // Next
        html += `<li class="page-item ${current == totalPages ? 'disabled' : ''}">
                    <a class="page-link" href="#" onclick="fetchExams(${current + 1}); return false;">&raquo;</a>
                 </li>`;

        $('#pagination').html(html);
        // Expose function to window so onclick works
        window.fetchExams = fetchExams;
    }

    // Function to delete exam function
    function deleteExam(id, examName) {
        Swal.fire({
            title: 'Delete Exam',
            html: `Are you sure you want to delete <strong>${examName}</strong>?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#e70000ff',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            customClass: {
                popup: 'rounded-4 shadow-lg'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                $.post('../../api/admin/delete/exam/delete-exam.php', {
                    exam_id: id
                }, function(res) {
                    if (res.success) {
                        showSuccessAlert(res.message);
                        fetchExams(1); // Reload
                    } else {
                        showErrorAlert(res.message);
                    }
                }, 'json');
            }
        });
    }

    // Function to restore an archived exam
    function restoreExam(id, examName) {
        Swal.fire({
            title: 'Restore Exam',
            html: `Are you sure you want to restore <strong>${examName}</strong>?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Restore',
            cancelButtonText: 'Cancel',
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-success px-4 py-2',
                cancelButton: 'btn btn-secondary px-4 py-2'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                $.post('../../api/admin/put/exam/restore-exam.php', {
                    exam_id: id
                }, function(res) {
                    if (res.success) {
                        showSuccessAlert(res.message);
                        fetchExams(1); // Reload
                    } else {
                        showErrorAlert(res.message);
                    }
                }, 'json');
            }
        });
    }

    $(document).ready(function() {
        // Initial Load
        fetchExams(1);
    });
</script>