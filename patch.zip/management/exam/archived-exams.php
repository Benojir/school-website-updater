<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Archived Exams - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// check admin permission
if (!hasPermission(PERM_MANAGE_EXAMS)) {
    include_once("../../includes/permission-denied.php");
}

// Pagination settings
$perPage = 10; // Number of items per page
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $perPage;

// Get total number of archived exams for pagination
$totalExams = $pdo->query("SELECT COUNT(*) FROM exams WHERE status = 'archived'")->fetchColumn();
$totalPages = ceil($totalExams / $perPage);

// Get paginated exams
$archived_exams = $pdo->prepare("SELECT * FROM exams WHERE status = 'archived' ORDER BY exam_date DESC LIMIT :limit OFFSET :offset");
$archived_exams->bindValue(':limit', $perPage, PDO::PARAM_INT);
$archived_exams->bindValue(':offset', $offset, PDO::PARAM_INT);
$archived_exams->execute();
$archived_exams = $archived_exams->fetchAll(PDO::FETCH_ASSOC);

?>

<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-header bg-dark text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h2 class="h4 mb-0"><i class="fas fa-archive me-2"></i>Archived Exams</h2>
                <a href="list-exams.php" class="btn btn-sm btn-outline-light">
                    <i class="fas fa-arrow-left me-1"></i> Back to Active Exams
                </a>
            </div>
        </div>

        <div class="card-body">
            <?php if (isset($_GET['restored']) && $_GET['restored'] == 1): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    Exam restored successfully.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['deleted']) && $_GET['deleted'] == 1): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    🗑️ Exam deleted successfully.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if (empty($archived_exams)): ?>
                <div class="alert alert-info">
                    No archived exams found.
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th width="5%">#</th>
                                <th>Exam Name</th>
                                <th width="15%">Exam Date</th>
                                <th width="10%">Status</th>
                                <th width="15%">Created</th>
                                <th width="15%">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($archived_exams as $index => $exam): ?>
                                <tr>
                                    <td><?= ($page - 1) * $perPage + $index + 1 ?></td>
                                    <td><?= safe_htmlspecialchars($exam['exam_name']) ?></td>
                                    <td><?= safe_htmlspecialchars($exam['exam_date']) ?></td>
                                    <td><span class="badge bg-secondary">Archived</span></td>
                                    <td><?= date('M j, Y', strtotime($exam['created_at'])) ?></td>
                                    <td>
                                        <form action="../../api/admin/put/exam/restore-exam.php" method="POST" onsubmit="return confirm('Are you sure you want to restore this exam?');" class="d-inline">
                                            <input type="hidden" name="exam_id" value="<?= $exam['id'] ?>">
                                            <button type="submit" class="btn btn-sm btn-success" title="Restore Exam">
                                                <i class="fas fa-redo me-1"></i>
                                            </button>
                                        </form>
                                        <form action="../../api/admin/delete/exam/delete-exam.php" method="POST" onsubmit="return confirm('🗑️ Are you sure you want to delete this exam?');" class="d-inline">
                                            <input type="hidden" name="exam_id" value="<?= $exam['id'] ?>">
                                            <button type="submit" class="btn btn-sm btn-danger" title="Delete Exam">
                                                <i class="fas fa-trash me-1"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center">
                        <?php if ($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?= $page - 1 ?>" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>

                        <?php if ($page < $totalPages): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?= $page + 1 ?>" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <div class="text-center text-muted small">
                    Showing <?= count($archived_exams) ?> of <?= $totalExams ?> archived exams
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include_once("../../includes/body-close.php"); ?>