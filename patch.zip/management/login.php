<?php
include_once("../includes/config.php");

// Check if user is logged in via session
if (!isLoggedIn()) {
    // Check for remember me cookie
    if (isset($_COOKIE['remember_me'])) {
        $token = $_COOKIE['remember_me'];

        try {
            // Check token in database
            $stmt = $pdo->prepare("SELECT * FROM users WHERE remember_token = ? AND token_expiry > NOW() LIMIT 1");
            $stmt->execute([$token]);
            $user = $stmt->fetch();

            if ($user) {
                // Recreate session
                $_SESSION['user'] = [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'full_name' => $user['full_name'],
                    'role' => $user['user_role'],
                    'logged_in' => true
                ];

                // Refresh token expiry
                $expiry = time() + (86400 * 30); // 30 days
                $pdo->prepare("UPDATE users SET token_expiry = ? WHERE id = ?")
                    ->execute([date('Y-m-d H:i:s', $expiry), $user['id']]);

                setcookie('remember_me', $token, $expiry, "/");
                header("Location: dashboard/");
                exit();
            }
            // Invalid token, stay in login

        } catch (PDOException $e) {
            // Log error so stay in login page
            error_log("Remember me token error: " . $e->getMessage());
        }
    }
    // No session or cookie, stay in login

} else {
    // Already logged In
    header("Location: dashboard/");
    exit();
}

include_once("../includes/header-open.php");
?>
<title>Login - <?= $school_name; ?></title>

<style>
    .login-page {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        min-height: 100vh;
    }

    .login-page .card {
        border-radius: 15px;
        border: none;
        overflow: hidden;
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }

    .login-page .card-body {
        padding: 2rem;
    }

    .login-page .form-control {
        padding: 0.75rem 1rem;
        border-radius: 8px;
        border: 1px solid #dee2e6;
        transition: all 0.3s;
    }

    .login-page .form-control:focus {
        border-color: <?= $theme_color; ?>;
        box-shadow: 0 0 0 0.25rem rgba(<?= hexdec(substr($theme_color, 1, 2)) ?>, <?= hexdec(substr($theme_color, 3, 2)) ?>, <?= hexdec(substr($theme_color, 5, 2)) ?>, 0.25);
    }

    .login-page .input-group-text {
        background-color: #f8f9fa;
        border-right: none;
    }

    .login-page .btn-primary {
        padding: 0.75rem;
        border-radius: 8px;
        font-weight: 500;
        transition: all 0.3s;
    }

    .login-page .btn-primary:hover {
        opacity: 0.9;
        transform: translateY(-2px);
    }

    .login-page .toggle-password {
        cursor: pointer;
        border-left: none;
    }

    .login-page .toggle-password:hover {
        background-color: #f8f9fa;
    }

    /* hCaptcha container styling */
    .hcaptcha-container {
        display: flex;
        justify-content: center;
        margin: 1rem 0;
    }

    /* Responsive adjustments */
    @media (max-width: 575.98px) {
        .login-page .card-body {
            padding: 1.5rem;
        }

        .hcaptcha-container {
            transform: scale(0.8);
            transform-origin: center;
        }
    }
</style>

<?php include_once("../includes/header-close.php"); ?>

<div class="login-page bg-light">
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-8 col-lg-6 col-xl-5">
                <div class="card shadow-sm">
                    <div class="card-body p-4 p-sm-5">
                        <div class="text-center mb-4">
                            <?php if (file_exists('../uploads/school/logo-square.png')): ?>
                                <img src="../uploads/school/logo-square.png" alt="School Logo" class="img-fluid mb-3" style="max-height: 80px;">
                            <?php endif; ?>
                            <h3 class="mb-1"><?= $school_name; ?></h3>
                            <p class="text-muted">School Management System</p>
                        </div>

                        <form id="loginForm" method="post" autocomplete="off">
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                                    <input type="text" class="form-control" id="username" name="username" placeholder="Enter username" required>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" required>
                                    <button class="btn btn-outline-secondary toggle-password" type="button">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="remember" name="remember">
                                <label class="form-check-label" for="remember">Remember me</label>
                            </div>

                            <!-- hCaptcha -->
                            <div class="hcaptcha-container">
                                <div class="h-captcha" data-sitekey="<?= $websiteConfig['captcha_site_key'] ?>"></div>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary btn-lg" id="loginBtn" style="background-color: <?= $theme_color; ?>; border-color: <?= $theme_color; ?>">
                                    <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                                    Login
                                </button>
                            </div>
                        </form>

                        <div class="text-center mt-3">
                            <a href="admin-forgot-password.php" class="text-decoration-none">Forgot password?</a>
                        </div>
                    </div>
                </div>

                <div class="text-center mt-3">
                    <p class="text-muted mb-0">© <?= date('Y'); ?> <?= $school_name; ?>. All rights reserved.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    let hcaptchaWidgetId;

    // Initialize hCaptcha when DOM is ready
    function initHcaptcha() {
        const container = document.querySelector('.h-captcha');

        if (typeof hcaptcha !== 'undefined' && container && !hcaptchaWidgetId) {
            try {
                hcaptchaWidgetId = hcaptcha.render(container, {
                    sitekey: '<?= $websiteConfig['captcha_site_key'] ?>',
                    theme: 'light',
                    size: 'normal'
                });
                console.log('hCaptcha initialized successfully');
            } catch (error) {
                console.error('hCaptcha initialization error:', error);
                // Retry after a short delay
                setTimeout(initHcaptcha, 500);
            }
        } else if (typeof hcaptcha === 'undefined') {
            // If hCaptcha hasn't loaded yet, wait and try again
            setTimeout(initHcaptcha, 200);
        }
    }

    // Helper function to reset hCaptcha
    function resetHcaptcha() {
        if (typeof hcaptcha !== 'undefined' && hcaptchaWidgetId !== undefined) {
            try {
                hcaptcha.reset(hcaptchaWidgetId);
            } catch (error) {
                console.error('Error resetting hCaptcha:', error);
            }
        }
    }

    $(document).ready(function() {
        // Start initialization
        initHcaptcha();

        // Toggle password visibility
        $('.toggle-password').click(function() {
            const passwordInput = $('#password');
            const icon = $(this).find('i');

            if (passwordInput.attr('type') === 'password') {
                passwordInput.attr('type', 'text');
                icon.removeClass('fa-eye').addClass('fa-eye-slash');
            } else {
                passwordInput.attr('type', 'password');
                icon.removeClass('fa-eye-slash').addClass('fa-eye');
            }
        });

        // Handle form submission
        $('#loginForm').submit(function(e) {
            e.preventDefault();

            // Check if hCaptcha is completed
            let hcaptchaResponse = '';
            if (typeof hcaptcha !== 'undefined' && hcaptchaWidgetId !== undefined) {
                try {
                    hcaptchaResponse = hcaptcha.getResponse(hcaptchaWidgetId);
                } catch (error) {
                    console.error('Error getting hCaptcha response:', error);
                }
            }

            if (!hcaptchaResponse) {
                toastr.error('Please complete the captcha verification');
                return;
            }

            const btn = $('#loginBtn');
            btn.prop('disabled', true);
            btn.find('.spinner-border').removeClass('d-none');

            $.ajax({
                url: 'action/process-admin-login.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        toastr.success(response.message);
                        setTimeout(function() {
                            window.location.href = response.redirect;
                        }, 1500);
                    } else {
                        toastr.error(response.message);
                        // Reset hCaptcha on error
                        resetHcaptcha();
                        btn.prop('disabled', false);
                        btn.find('.spinner-border').addClass('d-none');
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred. Please try again.');
                    // Reset hCaptcha on error
                    resetHcaptcha();
                    btn.prop('disabled', false);
                    btn.find('.spinner-border').addClass('d-none');
                    console.error(xhr.responseText);
                }
            });
        });
    });

    // Optional: Define the callback function in case the script was loaded with callback
    // This prevents the "Callback 'onHcaptchaLoad' is not defined" error
    window.onHcaptchaLoad = function() {
        console.log('hCaptcha loaded via callback');
        // The initialization is already handled in document ready, so this is just a fallback
    };
</script>

<?php include_once("../includes/body-close.php"); ?>