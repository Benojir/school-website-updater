<?php
require_once __DIR__ . '/../../includes/auth-check.php';
if(!isSuperAdmin() || !hasPermission(PERM_MANAGE_TEACHERS_ATTENDANCE)) { http_response_code(403); exit('Super administrator access is required.'); }
$_SESSION['staff_attendance_csrf'] ??= bin2hex(random_bytes(32));
include_once __DIR__ . '/../../includes/header-open.php';
echo '<title>Teacher Attendance Settings</title>';
include_once __DIR__ . '/../../includes/header-close.php';
include_once __DIR__ . '/../../includes/dashboard-navbar.php';
?>
<div class="container py-4" id="staffAttendance" data-view="teacher" data-endpoint="<?= safe_htmlspecialchars(BASE_URL) ?>/api/admin/teacher-attendance.php" data-csrf="<?= safe_htmlspecialchars($_SESSION['staff_attendance_csrf']) ?>">
    <h2>Teacher Settings</h2>
    <?php $attendanceView='teacher'; include __DIR__ . '/../../includes/teacher/staff-attendance-navigation.php'; ?>
    <p class="text-muted">Most teachers need only a salary entry. Add personal rules for someone with a different shift or deduction policy. This page manages existing Teacher App accounts.</p>
    <div id="staffMessage" role="status" class="alert d-none"></div>
    <div class="card mb-4"><div class="card-body"><div class="row g-3 align-items-end">
        <div class="col-md-5"><label class="form-label" for="staffTeacher">Teacher</label><select id="staffTeacher" class="form-select"></select></div>
        <div class="col-md-3"><label class="form-label" for="staffSettingsDate">View rules on date</label><input id="staffSettingsDate" type="date" class="form-control" required></div>
        <div class="col-md-4"><button id="staffReload" class="btn btn-primary">Load / Reload</button></div>
    </div><p id="staffPersonalSummary" class="mt-3 mb-0" role="status">Select a teacher and a date, then click Load / Reload to show the settings.</p><p id="staffSettingsHelp" class="mt-2 mb-0 d-none">Check the school's Effective from date in <a href="school-attendance-settings.php">School attendance settings</a>. Select a date covered by school rules, then click Load / Reload. If loading failed temporarily, try Load / Reload again.</p><div id="staffEffectiveRules" class="mt-2"></div></div></div>
    <div id="staffTeacherSettingsEditor" hidden>
    <fieldset id="staffTeacherSettingsFields" disabled>
    <legend class="visually-hidden">Settings for the loaded teacher and date</legend>
    <div class="card mb-4"><div class="card-header">Personal attendance rules</div><div class="card-body">
        <p>Tick only the groups that need different rules. Unticked groups continue to follow the school. To return to school defaults, untick all groups and save a new version.</p>
        <form id="staffTeacherRules">
            <p id="staffRuleCopyNote" class="text-primary d-none" role="status"></p>
            <div class="row g-3 mb-3">
                <div class="col-md-4"><label class="form-label">Effective from<input name="effective_date" type="date" class="form-control" required></label></div>
                <div class="col-md-4"><label class="form-label">Last date inclusive (optional)<input name="end_date" type="date" class="form-control"></label></div>
            </div>
            <p class="small text-muted">Leave the last date empty for an ongoing rule. After a temporary rule ends, school defaults return. A later version replaces earlier personal settings from its start date; an older personal shift does not resume automatically.</p>
            <div class="mb-4">
                <label class="form-check-label fw-semibold"><input type="checkbox" class="form-check-input me-2" data-override="schedule">Different working days and shift</label>
                <fieldset data-fields="schedule" class="row g-3 mt-1" disabled hidden>
                    <legend class="visually-hidden">Personal working days and shift</legend>
                    <div class="col-12"><label class="form-label">Working weekdays</label><div id="staffWeekdays"></div></div>
                    <?php foreach(['start_time'=>'Shift starts','end_time'=>'Shift ends','checkin_open'=>'Arrival opens','checkin_close'=>'Arrival closes','checkout_close'=>'Departure closes'] as $field=>$label): ?>
                    <div class="col-md-3"><label class="form-label"><?= $label ?><input name="<?= $field ?>" type="time" class="form-control" required></label></div>
                    <?php endforeach; ?>
                    <div class="col-md-3"><label class="form-label">Minimum shift work (minutes)<input name="minimum_work_min" type="number" min="0" max="1440" class="form-control" required></label></div>
                    <div class="col-12"><details><summary>Different weekday shifts (optional)</summary><p class="small text-muted mt-2">Customize shift times, arrival/departure windows and minimum work for each weekday. Blank fields follow this teacher's common schedule above. Late/early grace and deductions stay common.</p><div id="staffDaySchedules" class="row g-2 mt-2"></div></details></div>
                </fieldset>
            </div>
            <div class="mb-4">
                <label class="form-check-label fw-semibold"><input type="checkbox" class="form-check-input me-2" data-override="grace">Different late and early departure grace</label>
                <fieldset data-fields="grace" class="row g-3 mt-1" disabled hidden>
                    <legend class="visually-hidden">Personal grace periods</legend>
                    <?php foreach(['late_grace_min'=>'Late grace (minutes)','early_grace_min'=>'Early departure grace (minutes)'] as $field=>$label): ?>
                    <div class="col-md-4"><label class="form-label"><?= $label ?><input name="<?= $field ?>" type="number" min="0" max="180" class="form-control" required></label></div>
                    <?php endforeach; ?>
                </fieldset>
            </div>
            <div class="mb-4">
                <label class="form-check-label fw-semibold"><input type="checkbox" class="form-check-input me-2" data-override="deductions">Different attendance deductions</label>
                <fieldset data-fields="deductions" class="row g-3 mt-1" disabled hidden>
                    <legend class="visually-hidden">Personal deduction rules</legend>
                    <?php foreach(['absence_percent'=>'Absent day deduction (%)','short_day_percent'=>'Short day deduction (%)'] as $field=>$label): ?>
                    <div class="col-md-3"><label class="form-label"><?= $label ?><input name="<?= $field ?>" type="number" min="0" max="100" step="any" class="form-control" required></label></div>
                    <?php endforeach; ?>
                    <?php foreach(['late'=>'Late arrival','early'=>'Early departure'] as $field=>$label): ?>
                    <div class="col-md-3"><label class="form-label"><?= $label ?> mode<select name="<?= $field ?>_mode" class="form-select"><option value="flat">Flat per day</option><option value="per_minute">Per minute after grace</option></select></label></div>
                    <div class="col-md-3"><label class="form-label"><?= $label ?> amount<input name="<?= $field ?>_amount" type="number" min="0" max="1000000" step="0.01" class="form-control" required></label></div>
                    <?php endforeach; ?>
                    <div class="col-md-4"><label class="form-label">Daily deduction divisor<select name="salary_divisor" class="form-select"><option value="working_days">Scheduled working days</option><option value="calendar_days">Calendar days in month</option><option value="fixed">Fixed divisor</option></select></label></div>
                    <div class="col-md-3"><label class="form-label">Fixed divisor<input name="fixed_divisor" type="number" min="1" max="31" class="form-control" required></label></div>
                </fieldset>
            </div>
            <div class="row g-3"><div class="col-md-9"><label class="form-label w-100">Change reason<input name="reason" class="form-control" required minlength="5" maxlength="1000"></label></div><div class="col-md-3 align-self-end"><button class="btn btn-primary">Save personal rules</button></div></div>
        </form>
        <p class="small text-muted mt-3">School location, camera checks and holidays remain shared. Same-day shifts are supported. Historical changes require a fresh attendance review; reopen affected locked salaries first.</p>
        <details><summary>Personal rule history</summary><p class="small text-muted mt-2">Use this version again copies only that version's personal groups. Choose new dates and save a new version. Unticked groups follow school rules; later scheduled versions still take effect.</p><div id="staffTeacherRuleHistory" class="mt-2"></div></details>
    </div></div>
    <div class="card mb-4"><div class="card-header">Salary terms</div><div class="card-body">
        <form id="staffSalary" class="row g-3"><div class="col-md-3"><label class="form-label">Effective from<input name="effective_date" type="date" class="form-control" required></label></div><div class="col-md-3"><label class="form-label">Monthly salary<input name="salary" type="number" min="0" max="9999999" step="0.01" class="form-control" required></label></div><div class="col-md-3"><label class="form-label">Employment end (optional)<input name="employment_end" type="date" class="form-control"></label></div><div class="col-md-9"><label class="form-label w-100">Reason<input name="reason" class="form-control" required minlength="5" maxlength="1000"></label></div><div class="col-md-3 align-self-end"><button class="btn btn-primary">Add salary term</button></div></form>
                <div id="staffTerms" class="small my-3"></div>
        <p class="small text-muted mt-3">Enter salary here once, then add a dated term when it changes. Monthly bonuses, deductions and settlement are on Attendance &amp; payroll.</p>
    </div></div>
    <div class="card mb-4"><div class="card-header">Attendance phone</div><div class="card-body">
        <form id="staffDevice" class="row g-3"><div class="col-md-9"><label class="form-label w-100">Phone reset reason<input name="reason" class="form-control" required minlength="5" maxlength="1000" placeholder="Teacher replaced their phone"></label></div><div class="col-md-3 align-self-end"><button class="btn btn-outline-danger">Reset attendance phone</button></div></form>
    </div></div>
    </fieldset>
    </div>
</div>
<style>#staffAttendance [data-staff-form-message]{scroll-margin-bottom:190px;overflow-wrap:anywhere}@media print{#staffAttendance [data-staff-form-message]{display:none!important}}</style>
<script src="<?= safe_htmlspecialchars(BASE_URL) ?>/assets/js/teacher-attendance-admin.js?v=12"></script>
<?php include_once __DIR__ . '/../../includes/body-close.php'; ?>
