<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
/**@var string $school_name */
echo "<title>Add Teacher - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    include_once("../../includes/permission-denied.php");
}

// Initialize the options string with the default placeholder
$options = '';

// Prepare the query joining the sections and classes tables
$stmt = $pdo->prepare("
    SELECT s.id, c.class_name, s.section_name 
    FROM sections s 
    JOIN classes c ON s.class_id = c.id 
    ORDER BY c.id ASC, s.section_name ASC
");
$stmt->execute();

// Loop through the results and build the options list
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $options .= '<option value="' . $row['id'] . '">' . safe_htmlspecialchars($row['class_name']) . ' (' . safe_htmlspecialchars($row['section_name']) . ')</option>';
}

// Religions
$religions = [
    'islam',
    'hindu',
    'christian',
    'buddhist',
    'jain',
    'sikh',
    'parsi',
    'judaism',
    'bahai',
    'atheist',
    'agnostic',
    'other'
];
?>

<div class="container py-4">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="mb-0"><i class="fas fa-user-plus me-2"></i> Add New Teacher</h4>
                <a href="../teacher/list-teachers.php" class="btn btn-light btn-sm">
                    <i class="fas fa-list me-1"></i> View Teachers
                </a>
            </div>
        </div>

        <div class="card-body">
            <form id="addTeacherForm" enctype="multipart/form-data">
                <div class="row g-3">
                    <div class="col-12">
                        <h5 class="border-bottom pb-2 text-primary">Personal Information</h5>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Full Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Email <span class="text-danger">*</span></label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Phone <span class="text-danger">*</span></label>
                            <input type="text" name="phone" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Date of Birth <span class="text-danger">*</span></label>
                            <input type="date" name="date_of_birth" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label fw-bold">Gender <span class="text-danger">*</span></label>
                            <select name="gender" class="form-select" required>
                                <option value="" selected disabled>Select</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label fw-bold">Blood Group</label>
                            <select name="blood_group" class="form-select">
                                <option value="" selected>Select</option>
                                <option value="A+">A+</option>
                                <option value="A-">A-</option>
                                <option value="B+">B+</option>
                                <option value="B-">B-</option>
                                <option value="AB+">AB+</option>
                                <option value="AB-">AB-</option>
                                <option value="O+">O+</option>
                                <option value="O-">O-</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label fw-bold">Caste Category</label>
                            <select name="caste_category" class="form-select">
                                <option value="" selected>Select</option>
                                <option value="General">General</option>
                                <option value="OBC-A">OBC-A</option>
                                <option value="OBC-B">OBC-B</option>
                                <option value="SC">SC</option>
                                <option value="ST">ST</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Religion</label>
                            <select class="form-select" name="religion">
                                <option value="" selected>Select Religion</option>
                                <?php foreach ($religions as $religion): ?>
                                    <option value="<?= $religion ?>"><?= ucwords($religion) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Nationality</label>
                            <input type="text" name="nationality" class="form-control" value="Indian">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Aadhaar No.</label>
                            <input type="text" name="aadhaar_card" class="form-control">
                            <div class="form-text">Must be unique if provided.</div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Monthly Salary <span class="text-danger">*</span></label>
                            <input type="text" name="salary" class="form-control" placeholder="30000" oninput="autoCorrectNumberInput(this)" required>
                        </div>
                    </div>

                    <div class="col-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">Family Details</h5>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Father's Name</label>
                            <input type="text" name="father_name" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Father's Phone</label>
                            <input type="text" name="father_phone" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Mother's Name</label>
                            <input type="text" name="mother_name" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Mother's Phone</label>
                            <input type="text" name="mother_phone" class="form-control">
                        </div>
                    </div>

                    <div class="col-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">Professional Details</h5>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Joining Date <span class="text-danger">*</span></label>
                            <input type="date" name="joining_date" class="form-control" 
                                   value="<?= date('Y-m-d') ?>" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Status <span class="text-danger">*</span></label>
                            <select name="status" class="form-select" required>
                                <option value="active" selected>Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Qualification</label>
                            <input type="text" name="qualification" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Specialization</label>
                            <input type="text" name="subject_specialization" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Position in School</label>
                            <input type="text" name="position_in_school" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Assign Sections</label>
                            <select name="allow_sections[]" class="form-select custom-multiselect" multiple>
                                <?= $options ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">Website &amp; Access Settings</h5>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Display Priority (1 = first, 2 = second, etc.)</label>
                            <input type="number" name="display_priority" class="form-control" min="1" step="1" placeholder="Leave empty for no fixed position">
                            <div class="form-text">Controls where this teacher appears in the public teacher list. Lower numbers come first. Leave empty to place them after all manually ordered teachers, in random order.</div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="show_on_website" id="showOnWebsite" value="1" checked>
                            <label class="form-check-label fw-bold" for="showOnWebsite">Show this teacher on website's public pages</label>
                            <div class="form-text">Uncheck to keep this teacher out of the public faculty listings and department pages.</div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="share_phone_with_chatbot" id="sharePhoneWithChatbot" value="1" checked>
                            <label class="form-check-label fw-bold" for="sharePhoneWithChatbot">Share this teacher's phone number with the chatbot</label>
                            <div class="form-text">When checked, the website chatbot may give out this teacher's contact number if a parent or student asks for it.</div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="can_view_parent_contacts" id="canViewParentContacts" value="1" checked>
                            <label class="form-check-label fw-bold" for="canViewParentContacts">Allow this teacher to view parents' contact numbers</label>
                            <div class="form-text">When checked, this teacher can see parents' phone numbers and email addresses on student profiles.</div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="can_view_student_financial_report" id="canViewStudentFinancialReport" value="1">
                            <label class="form-check-label fw-bold" for="canViewStudentFinancialReport">Allow this teacher to see students' financial report</label>
                            <div class="form-text">When checked, this teacher's app can see the total due, month wise due breakdown and payment history of the students in their assigned sections. Leave unchecked to hide all financial figures.</div>
                        </div>
                    </div>

                    <div class="col-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">Bank Details</h5>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">PAN Card No.</label>
                            <input type="text" name="pan_number" class="form-control" placeholder="ABCDE1234F" maxlength="10" style="text-transform:uppercase;">
                            <div class="form-text">Must be unique if provided.</div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Voter EPIC No.</label>
                            <input type="text" name="voter_epic_number" class="form-control" placeholder="ABC1234567" style="text-transform:uppercase;">
                            <div class="form-text">Must be unique if provided.</div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Bank Name</label>
                            <input type="text" name="bank_name" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Branch Name</label>
                            <input type="text" name="bank_branch" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">IFSC Code</label>
                            <input type="text" name="ifsc_code" class="form-control" style="text-transform:uppercase;">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Account Number</label>
                            <input type="text" name="account_number" class="form-control">
                        </div>
                    </div>

                    <div class="col-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">Address Details</h5>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Village/Town</label>
                            <input type="text" name="village" class="form-control">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Post Office</label>
                            <input type="text" name="post_office" class="form-control">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Police Station</label>
                            <input type="text" name="police_station" class="form-control">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">District</label>
                            <input type="text" name="district" class="form-control">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Pincode</label>
                            <input type="text" name="pincode" class="form-control">
                        </div>
                    </div>

                    <!-- ===================== DOCUMENTS SECTION ===================== -->
                    <div class="col-12 mt-4">
                        <div class="d-flex justify-content-between align-items-center border-bottom pb-2">
                            <h5 class="text-primary mb-0">
                                Documents
                                <span id="documentsCounter" class="badge bg-secondary ms-2">0 / <?= MAX_TEACHER_DOCUMENTS ?></span>
                            </h5>
                            <button type="button" id="addDocumentBtn" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-plus me-1"></i> Add Document Field
                            </button>
                        </div>
                    </div>
                    <div class="col-12">
                        <div id="documentsContainer">
                            <!-- Dynamic document rows are injected here by JS -->
                        </div>
                        <div id="noDocumentsMsg" class="text-muted small">No document fields added yet. Click "Add Document Field" to attach PAN card, certificates, etc.</div>
                        <div id="documentsLimitMsg" class="text-danger small" style="display:none;">
                            <i class="fas fa-circle-exclamation me-1"></i> Maximum of <?= MAX_TEACHER_DOCUMENTS ?> documents reached. Remove a field to add another.
                        </div>
                    </div>

                    <div class="col-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">Profile Photo</h5>
                    </div>
                    <!-- Image Upload Section -->
                    <div class="col-12">
                        <div class="form-group">
                            <label class="form-label fw-bold">Teacher Photo</label>
                            <div class="image-upload-container">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="image-preview-container mb-3">
                                            <div class="image-preview-wrapper">
                                                <img id="imagePreview" src="../../assets/img/teacher-default-avatar.png" 
                                                     class="img-fluid" style="max-height: 200px; display: block;">
                                            </div>
                                        </div>
                                        <input type="file" id="teacherPhoto" name="teacher_photo" 
                                               class="form-control" accept="image/*">
                                        <div class="form-text">Please upload a photo with 5:6 aspect ratio (e.g., 500x600px)</div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="cropper-container" style="display: none;">
                                            <div class="cropper-wrapper">
                                                <img id="imageCropper" class="img-fluid" style="max-height: 300px;">
                                            </div>
                                            <div class="mt-3">
                                                <button type="button" id="cropImageBtn" class="btn btn-primary btn-sm">
                                                    <i class="fas fa-crop me-1"></i> Crop Image
                                                </button>
                                                <button type="button" id="cancelCropBtn" class="btn btn-secondary btn-sm ms-2">
                                                    <i class="fas fa-times me-1"></i> Cancel
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Upload / Save Progress Bar -->
                <div class="col-12 mt-4" id="uploadProgressWrapper" style="display:none;">
                    <label class="form-label fw-bold mb-1" id="uploadProgressLabel">Uploading...</label>
                    <div class="progress" style="height: 22px;">
                        <div id="uploadProgressBar" class="progress-bar progress-bar-striped progress-bar-animated bg-primary"
                             role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">0%</div>
                    </div>
                </div>

                <div class="text-end mt-4">
                    <button type="submit" id="submitBtn" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i> Save Teacher
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal for cropping -->
<div class="modal fade" id="cropModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-crop me-2"></i> Crop Image</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="img-container">
                    <img id="modalCropper" src="" class="img-fluid">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" id="confirmCrop" class="btn btn-primary">Crop & Save</button>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    let cropper;
    let originalImageURL;
    let croppedImageBlob;
    let documentRowIndex = 0;
    const MAX_DOCUMENTS = <?= MAX_TEACHER_DOCUMENTS ?>;

    // ===================== Dynamic Document Fields =====================
    function countDocumentRows() {
        return $('#documentsContainer .document-row').length;
    }

    function refreshDocumentsUI() {
        const total = countDocumentRows();
        const limitReached = total >= MAX_DOCUMENTS;

        $('#documentsCounter').text(total + ' / ' + MAX_DOCUMENTS)
            .toggleClass('bg-secondary', !limitReached)
            .toggleClass('bg-danger', limitReached);
        $('#noDocumentsMsg').toggle(total === 0);
        $('#documentsLimitMsg').toggle(limitReached);
        $('#addDocumentBtn').prop('disabled', limitReached);
    }

    function addDocumentRow() {
        if (countDocumentRows() >= MAX_DOCUMENTS) {
            toastr.error(`You can add a maximum of ${MAX_DOCUMENTS} documents.`);
            return;
        }

        documentRowIndex++;
        const rowId = 'docRow_' + documentRowIndex;
        const rowHtml = `
            <div class="document-row row g-2 align-items-center mb-2" id="${rowId}">
                <div class="col-md-4">
                    <input type="text" name="document_name[]" class="form-control" placeholder="Document Name (e.g. PAN Card)" required>
                </div>
                <div class="col-md-5">
                    <input type="file" name="document_file[]" class="form-control" accept="image/*" required>
                </div>
                <div class="col-md-2">
                    <div class="progress" style="height: 8px; display:none;" data-doc-progress>
                        <div class="progress-bar bg-success" role="progressbar" style="width: 0%;"></div>
                    </div>
                </div>
                <div class="col-md-1 text-end">
                    <button type="button" class="btn btn-outline-danger btn-sm remove-document-btn" title="Remove">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `;
        $('#documentsContainer').append(rowHtml);
        refreshDocumentsUI();
    }

    $('#addDocumentBtn').click(function() {
        addDocumentRow();
    });

    $('#documentsContainer').on('click', '.remove-document-btn', function() {
        $(this).closest('.document-row').remove();
        refreshDocumentsUI();
    });

    refreshDocumentsUI();

    // Auto-uppercase PAN / IFSC / Voter EPIC as the admin types
    $('input[name="pan_number"], input[name="ifsc_code"], input[name="voter_epic_number"]').on('input', function() {
        this.value = this.value.toUpperCase();
    });

    // Initialize cropper when image is selected
    $('#teacherPhoto').change(function(e) {
        if (this.files && this.files[0]) {
            const file = this.files[0];
            
            // Check if file is an image
            if (!file.type.match('image.*')) {
                toastr.error('Please select an image file');
                return;
            }
            
            const reader = new FileReader();
            
            reader.onload = function(event) {
                originalImageURL = event.target.result;
                
                // Show modal with cropper
                $('#modalCropper').attr('src', originalImageURL);
                $('#cropModal').modal('show');
                
                // Initialize cropper when modal is shown
                $('#cropModal').on('shown.bs.modal', function() {
                    if (cropper) {
                        cropper.destroy();
                    }
                    
                    const image = document.getElementById('modalCropper');
                    cropper = new Cropper(image, {
                        aspectRatio: 5/6,
                        viewMode: 1,
                        autoCropArea: 0.8,
                        responsive: true,
                        guides: true
                    });
                });
            };
            
            reader.readAsDataURL(file);
        }
    });
    
    // Handle crop confirmation
    $('#confirmCrop').click(function() {
        if (cropper) {
            // Get cropped canvas
            const canvas = cropper.getCroppedCanvas({
                width: 500,
                height: 600,
                minWidth: 250,
                minHeight: 300,
                maxWidth: 1000,
                maxHeight: 1200,
                fillColor: '#fff',
                imageSmoothingEnabled: true,
                imageSmoothingQuality: 'high'
            });
            
            if (canvas) {
                // Convert canvas to blob
                canvas.toBlob(function(blob) {
                    croppedImageBlob = blob;
                    
                    // Create a new preview URL
                    const previewURL = URL.createObjectURL(blob);
                    
                    // Update preview image
                    $('#imagePreview').attr('src', previewURL);
                    
                    // Close modal
                    $('#cropModal').modal('hide');
                    
                    // Clean up cropper
                    if (cropper) {
                        cropper.destroy();
                        cropper = null;
                    }
                }, 'image/jpeg', 0.9);
            }
        }
    });
    
    // Clean up when modal is closed
    $('#cropModal').on('hidden.bs.modal', function() {
        if (cropper) {
            cropper.destroy();
            cropper = null;
        }
    });

    // ===================== Progress Bar Helpers =====================
    function setProgress(percent, label) {
        $('#uploadProgressWrapper').show();
        $('#uploadProgressBar').css('width', percent + '%').attr('aria-valuenow', percent).text(percent + '%');
        if (label) {
            $('#uploadProgressLabel').text(label);
        }
    }

    function resetProgress() {
        $('#uploadProgressWrapper').hide();
        $('#uploadProgressBar').css('width', '0%').attr('aria-valuenow', 0).text('0%');
    }

    // Form submission
    $('#addTeacherForm').submit(function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        const submitBtn = $('#submitBtn');
        
        // Add cropped image to form data if available
        if (croppedImageBlob) {
            formData.append('cropped_image', croppedImageBlob, 'teacher_photo.jpg');
        } else if ($('#teacherPhoto')[0].files[0]) {
            // If no cropping was done but image was selected
            formData.append('original_image', $('#teacherPhoto')[0].files[0]);
        }
        
        submitBtn.prop('disabled', true).html(`
            <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
            Saving...
        `);

        setProgress(0, 'Uploading data & files...');

        $.ajax({
            url: '../../api/admin/put/teacher/save-teacher.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            xhr: function() {
                const xhr = $.ajaxSettings.xhr();
                if (xhr.upload) {
                    xhr.upload.addEventListener('progress', function(evt) {
                        if (evt.lengthComputable) {
                            // Upload itself counts for 0-70%; the remaining 70-100%
                            // is the server-side processing (ImgBB upload + DB insert).
                            const uploadPercent = Math.round((evt.loaded / evt.total) * 70);
                            setProgress(uploadPercent, uploadPercent < 70 ? 'Uploading data & files...' : 'Upload complete, processing...');
                        }
                    }, false);
                }
                return xhr;
            },
            beforeSend: function() {
                setProgress(5, 'Uploading data & files...');
            },
            success: function(response) {
                setProgress(100, 'Done!');
                if (response.success) {
                    toastr.success(response.message);
                    showSuccessAlert(response.message);
                    setInterval(() => {
                        window.location.reload();
                    }, 2000);
                } else {
                    toastr.error(response.message);
                    showErrorAlert(response.message);
                }
                submitBtn.prop('disabled', false).html(`
                    <i class="fas fa-save me-2"></i> Save Teacher
                `);
                setTimeout(resetProgress, 1500);
            },
            error: function(e) {
                toastr.error('An error occurred. Please try again.');
                showErrorAlert('An error occurred. Please try again.');
                console.error(e.responseText);
                submitBtn.prop('disabled', false).html(`
                    <i class="fas fa-save me-2"></i> Save Teacher
                `);
                resetProgress();
            }
        });
    });
});
</script>

<style>
    .image-preview-wrapper {
        border: 1px dashed #ccc;
        padding: 5px;
        margin-bottom: 10px;
        text-align: center;
        background-color: #f8f9fa;
    }
    
    .cropper-container {
        border: 1px dashed #ccc;
        padding: 5px;
        background-color: #f8f9fa;
    }
    
    .cropper-wrapper {
        height: 300px;
        overflow: hidden;
    }
    
    .img-container {
        height: 500px;
        overflow: hidden;
    }
    
    .cropper-view-box,
    .cropper-face {
        border-radius: 0%;
    }

    .document-row {
        background-color: #f8f9fa;
        border: 1px solid #e9ecef;
        border-radius: 6px;
        padding: 8px 6px;
    }
</style>

<?php include_once("../../includes/body-close.php"); ?>