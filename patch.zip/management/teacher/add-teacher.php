<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Add Teachers - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    include_once("../../includes/permission-denied.php");
}

// Initialize the options string with the default placeholder
$options = '';

// Prepare the query joining the sections and classes tables
$stmt = $pdo->prepare("
    SELECT s.id, c.class_name, s.section_name 
    FROM sections s 
    JOIN classes c ON s.class_id = c.id 
    ORDER BY c.id ASC, s.section_name ASC
");
$stmt->execute();

// Loop through the results and build the options list
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $options .= '<option value="' . $row['id'] . '">' . htmlspecialchars($row['class_name']) . ' (' . htmlspecialchars($row['section_name']) . ')</option>';
}
?>

<div class="container py-4">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="mb-0"><i class="fas fa-user-plus me-2"></i> Add New Teacher</h4>
                <a href="../teacher/list-teachers.php" class="btn btn-light btn-sm">
                    <i class="fas fa-list me-1"></i> View Teachers
                </a>
            </div>
        </div>

        <div class="card-body">
            <form id="addTeacherForm" enctype="multipart/form-data">
                <div class="row g-3">
                    <div class="col-12">
                        <h5 class="border-bottom pb-2 text-primary">Personal Information</h5>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Full Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Email <span class="text-danger">*</span></label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Phone <span class="text-danger">*</span></label>
                            <input type="text" name="phone" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Aadhaar No.</label>
                            <input type="text" name="aadhaar_card" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Monthly Salary <span class="text-danger">*</span></label>
                            <input type="text" name="salary" class="form-control" placeholder="30000" oninput="autoCorrectNumberInput(this)" required>
                        </div>
                    </div>
                    <div class="col-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">Professional Details</h5>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Joining Date <span class="text-danger">*</span></label>
                            <input type="date" name="joining_date" class="form-control" 
                                   value="<?= date('Y-m-d') ?>" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Status <span class="text-danger">*</span></label>
                            <select name="status" class="form-select" required>
                                <option value="active" selected>Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Qualification</label>
                            <input type="text" name="qualification" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Specialization</label>
                            <input type="text" name="subject_specialization" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Position in School</label>
                            <input type="text" name="position_in_school" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Assign Sections</label>
                            <select name="allow_sections[]" class="form-select custom-multiselect" multiple>
                                <?= $options ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">Address Details</h5>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Village/Town</label>
                            <input type="text" name="village" class="form-control">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Post Office</label>
                            <input type="text" name="post_office" class="form-control">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Police Station</label>
                            <input type="text" name="police_station" class="form-control">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">District</label>
                            <input type="text" name="district" class="form-control">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Pincode</label>
                            <input type="text" name="pincode" class="form-control">
                        </div>
                    </div>
                    <div class="col-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">Profile Photo</h5>
                    </div>
                    <!-- Image Upload Section -->
                    <div class="col-12">
                        <div class="form-group">
                            <label class="form-label fw-bold">Teacher Photo</label>
                            <div class="image-upload-container">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="image-preview-container mb-3">
                                            <div class="image-preview-wrapper">
                                                <img id="imagePreview" src="../../assets/img/teacher-default-avatar.png" 
                                                     class="img-fluid" style="max-height: 200px; display: block;">
                                            </div>
                                        </div>
                                        <input type="file" id="teacherPhoto" name="teacher_photo" 
                                               class="form-control" accept="image/*">
                                        <div class="form-text">Please upload a photo with 5:6 aspect ratio (e.g., 500x600px)</div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="cropper-container" style="display: none;">
                                            <div class="cropper-wrapper">
                                                <img id="imageCropper" class="img-fluid" style="max-height: 300px;">
                                            </div>
                                            <div class="mt-3">
                                                <button type="button" id="cropImageBtn" class="btn btn-primary btn-sm">
                                                    <i class="fas fa-crop me-1"></i> Crop Image
                                                </button>
                                                <button type="button" id="cancelCropBtn" class="btn btn-secondary btn-sm ms-2">
                                                    <i class="fas fa-times me-1"></i> Cancel
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-end mt-4">
                    <button type="submit" id="submitBtn" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i> Save Teacher
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal for cropping -->
<div class="modal fade" id="cropModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-crop me-2"></i> Crop Image</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="img-container">
                    <img id="modalCropper" src="" class="img-fluid">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" id="confirmCrop" class="btn btn-primary">Crop & Save</button>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    let cropper;
    let originalImageURL;
    let croppedImageBlob;
    
    // Initialize cropper when image is selected
    $('#teacherPhoto').change(function(e) {
        if (this.files && this.files[0]) {
            const file = this.files[0];
            
            // Check if file is an image
            if (!file.type.match('image.*')) {
                toastr.error('Please select an image file');
                return;
            }
            
            const reader = new FileReader();
            
            reader.onload = function(event) {
                originalImageURL = event.target.result;
                
                // Show modal with cropper
                $('#modalCropper').attr('src', originalImageURL);
                $('#cropModal').modal('show');
                
                // Initialize cropper when modal is shown
                $('#cropModal').on('shown.bs.modal', function() {
                    if (cropper) {
                        cropper.destroy();
                    }
                    
                    const image = document.getElementById('modalCropper');
                    cropper = new Cropper(image, {
                        aspectRatio: 5/6,
                        viewMode: 1,
                        autoCropArea: 0.8,
                        responsive: true,
                        guides: true
                    });
                });
            };
            
            reader.readAsDataURL(file);
        }
    });
    
    // Handle crop confirmation
    $('#confirmCrop').click(function() {
        if (cropper) {
            // Get cropped canvas
            const canvas = cropper.getCroppedCanvas({
                width: 500,
                height: 600,
                minWidth: 250,
                minHeight: 300,
                maxWidth: 1000,
                maxHeight: 1200,
                fillColor: '#fff',
                imageSmoothingEnabled: true,
                imageSmoothingQuality: 'high'
            });
            
            if (canvas) {
                // Convert canvas to blob
                canvas.toBlob(function(blob) {
                    croppedImageBlob = blob;
                    
                    // Create a new preview URL
                    const previewURL = URL.createObjectURL(blob);
                    
                    // Update preview image
                    $('#imagePreview').attr('src', previewURL);
                    
                    // Close modal
                    $('#cropModal').modal('hide');
                    
                    // Clean up cropper
                    if (cropper) {
                        cropper.destroy();
                        cropper = null;
                    }
                }, 'image/jpeg', 0.9);
            }
        }
    });
    
    // Clean up when modal is closed
    $('#cropModal').on('hidden.bs.modal', function() {
        if (cropper) {
            cropper.destroy();
            cropper = null;
        }
    });
    
    // Form submission
    $('#addTeacherForm').submit(function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        const submitBtn = $('#submitBtn');
        
        // Add cropped image to form data if available
        if (croppedImageBlob) {
            formData.append('cropped_image', croppedImageBlob, 'teacher_photo.jpg');
        } else if ($('#teacherPhoto')[0].files[0]) {
            // If no cropping was done but image was selected
            formData.append('original_image', $('#teacherPhoto')[0].files[0]);
        }
        
        submitBtn.prop('disabled', true).html(`
            <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
            Saving...
        `);
        
        $.ajax({
            url: '../../api/admin/put/teacher/save-teacher.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                    showSuccessAlert(response.message);
                    setInterval(() => {
                        window.location.reload();
                    }, 2000);
                } else {
                    toastr.error(response.message);
                    showErrorAlert(response.message);
                }
                submitBtn.prop('disabled', false).html(`
                    <i class="fas fa-save me-2"></i> Save Teacher
                `);
            },
            error: function() {
                toastr.error('An error occurred. Please try again.');
                showErrorAlert('An error occurred. Please try again.');
                submitBtn.prop('disabled', false).html(`
                    <i class="fas fa-save me-2"></i> Save Teacher
                `);
            }
        });
    });
});
</script>

<style>
    .image-preview-wrapper {
        border: 1px dashed #ccc;
        padding: 5px;
        margin-bottom: 10px;
        text-align: center;
        background-color: #f8f9fa;
    }
    
    .cropper-container {
        border: 1px dashed #ccc;
        padding: 5px;
        background-color: #f8f9fa;
    }
    
    .cropper-wrapper {
        height: 300px;
        overflow: hidden;
    }
    
    .img-container {
        height: 500px;
        overflow: hidden;
    }
    
    .cropper-view-box,
    .cropper-face {
        border-radius: 0%;
    }
</style>

<?php include_once("../../includes/body-close.php"); ?>