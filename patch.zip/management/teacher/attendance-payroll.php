<?php
require_once __DIR__ . '/../../includes/auth-check.php';
if(!hasPermission(PERM_MANAGE_TEACHERS_ATTENDANCE)) { http_response_code(403); exit('Teacher attendance permission is required.'); }
$_SESSION['staff_attendance_csrf'] ??= bin2hex(random_bytes(32));
$canPayroll=isSuperAdmin();
include_once __DIR__ . '/../../includes/header-open.php';
echo '<title>Teacher Attendance &amp; Payroll</title>';
include_once __DIR__ . '/../../includes/header-close.php';
include_once __DIR__ . '/../../includes/dashboard-navbar.php';
?>
<link rel="stylesheet" href="<?= safe_htmlspecialchars(BASE_URL) ?>/assets/css/teacher-attendance-payroll.css?v=3">
<div class="container py-4 staff-payroll-page" id="staffAttendance" data-endpoint="<?= safe_htmlspecialchars(BASE_URL) ?>/api/admin/teacher-attendance.php" data-csrf="<?= safe_htmlspecialchars($_SESSION['staff_attendance_csrf']) ?>">
    <header class="staff-payroll-heading">
        <span class="staff-payroll-heading-icon" aria-hidden="true"><svg width="30" height="30" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" focusable="false"><rect x="4" y="9" width="24" height="18" rx="3"/><path d="M11 9V6a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v3M4 17a30 30 0 0 0 24 0M14 17v4h4v-4"/></svg></span>
        <div><div class="staff-payroll-eyebrow">Teacher management</div><h2>Teacher Attendance &amp; Payroll</h2></div>
    </header>
    <div class="staff-payroll-navigation"><?php $attendanceView="review"; include __DIR__ . "/../../includes/teacher/staff-attendance-navigation.php"; ?></div>
    <p class="text-muted staff-payroll-intro">Choose manual salary for offline attendance, or attendance-based salary for automatic attendance deductions. Set each teacher's dated salary in Teacher settings, or enter their first base salary here when prompted. Add monthly bonuses/deductions, then finalize and record payment. Amounts use <?= safe_htmlspecialchars($currency_symbol) ?>.</p>
    <div id="staffMessage" role="status" class="alert d-none"></div>
    <div class="card mb-4 staff-filter-card"><div class="card-header">Teacher &amp; payroll period</div><div class="card-body">
        <div class="row g-3 align-items-end">
            <div class="col-12 col-lg-4"><label for="staffTeacher" class="form-label">Teacher</label><select id="staffTeacher" class="form-select select2"></select></div>
            <div class="col-6 col-md-3 col-lg-2"><label for="staffMonthYear" class="form-label">Year</label><select id="staffMonthYear" class="form-select" required><option value="" disabled selected>Select year</option><?php foreach(range(2100,2000) as $year): ?><option value="<?= $year ?>"><?= $year ?></option><?php endforeach; ?></select></div>
            <div class="col-6 col-md-3 col-lg-2"><label for="staffMonthName" class="form-label">Month</label><select id="staffMonthName" class="form-select" required><option value="" disabled selected>Select month</option><?php foreach(['January','February','March','April','May','June','July','August','September','October','November','December'] as $index=>$name): ?><option value="<?= sprintf('%02d',$index+1) ?>"><?= $name ?></option><?php endforeach; ?></select><input id="staffMonth" type="hidden"></div>
            <div class="col-12 col-md-6 col-lg-4 staff-filter-actions"><button id="staffReload" class="btn btn-primary">Load / Reload</button> <?php if($canPayroll): ?><a id="staffSettingsLink" class="btn btn-outline-secondary" href="teacher-attendance-settings.php">Teacher settings</a><?php endif; ?> <button id="staffPrint" class="btn btn-outline-secondary">Print report</button></div>
        </div>
    </div></div>
    <?php if($canPayroll): ?>
    <div class="card mb-4" id="staffPayrollModeCard"><div class="card-header">School salary calculation mode</div><div class="card-body">
        <p id="staffPayrollModeSummary" role="status"></p>
        <form id="staffPayrollMode" class="row g-3">
            <div class="col-md-4"><label class="form-label w-100">Salary calculation<select name="mode" class="form-select" required><option value="attendance">Attendance-based salary</option><option value="manual">Manual salary</option></select></label></div>
            <div class="col-md-5"><label class="form-label w-100">Change reason (optional)<input name="reason" class="form-control" maxlength="1000" placeholder="Leave blank to use a default reason"></label></div>
            <div class="col-md-3 align-self-end"><button class="btn btn-outline-primary">Save school salary mode</button></div>
        </form>
        <p class="small text-muted mt-2">Applies to ALL teachers from the selected year/month onwards, until the next saved mode version. Reopen affected finalized/paid salaries first. This choice does not enable or disable digital attendance; use School attendance settings for that.</p>
        <details><summary>Salary mode history</summary><ul id="staffPayrollModeHistory" class="mt-2"></ul></details>
    </div></div>
    <div id="staffManualSalaryInfo" class="alert alert-info" hidden>Manual salary does not require digital attendance or photo reviews. Enter every approved deduction/advance recovery and bonus/allowance below. <label class="d-block mt-2"><input id="staffShowAttendance" type="checkbox" class="form-check-input"> Show separate attendance records (these do not affect manual salary)</label></div>
    <?php endif; ?>
    <div id="staffSummary" class="row g-3 mb-3"></div>
    <p id="staffFormula" class="small text-muted"></p>
    <?php if($canPayroll): ?>
    <div id="staffInitialSalaryCard" class="card border-warning mb-4" hidden>
        <div class="card-header">Set base salary for the first time</div>
        <div class="card-body">
            <p><strong id="staffInitialSalaryTeacher"></strong> has no salary terms yet. Enter the monthly base salary to calculate this teacher's pay.</p>
            <form id="staffInitialSalary">
                <fieldset id="staffInitialSalaryFields" class="row g-3" disabled>
                    <div class="col-md-3"><label class="form-label w-100">Effective from<input name="effective_date" type="date" class="form-control" required></label></div>
                    <div class="col-md-3"><label class="form-label w-100">Monthly base salary (<?= safe_htmlspecialchars($currency_symbol) ?>)<input name="salary" type="number" min="0" max="9999999" step="0.01" class="form-control" required></label></div>
                    <div class="col-md-6"><label class="form-label w-100">Reason (optional)<input name="reason" class="form-control" maxlength="1000" placeholder="Leave blank to use a default reason"></label></div>
                    <div class="col-12"><button class="btn btn-primary">Save base salary &amp; recalculate</button></div>
                </fieldset>
            </form>
            <p class="small text-muted mt-3 mb-0">Effective from defaults to the first day of the selected month. Choose the date this salary should start. After saving, review the recalculated total before finalizing and marking payment. Future salary revisions can be added in Teacher settings.</p>
        </div>
    </div>
    <?php endif; ?>
    <div class="card mb-4" id="staffReviewWorkspace"><div class="card-header d-flex flex-wrap gap-2 justify-content-between align-items-center"><div><strong>Monthly photo review</strong><span id="staffGalleryTeacher" class="d-block small"></span></div><button type="button" id="staffNextTeacher" class="btn btn-sm btn-outline-primary">Next teacher with pending reviews →</button></div><div class="card-body">
        <p class="mb-2">Check the teacher and school background in each arrival/departure pair. Tick the days you have checked, then approve them together. Open Live frames when needed. Corrections and missing punches need individual review.</p>
        <div id="staffQueueSummary" class="small fw-semibold mb-2" role="status"></div>
        <details class="mb-3"><summary>All staff — remaining reviews</summary><div id="staffReviewQueue" class="row g-2 mt-1"></div></details>
        <div class="d-flex flex-wrap gap-2 align-items-end mb-3">
            <label for="staffReviewFilter" class="form-label mb-0">Show<select id="staffReviewFilter" class="form-select"><option value="pending">Pending days</option><option value="attention">Needs individual attention</option><option value="all">All saved days</option></select></label>
            <button type="button" id="staffSelectVisible" class="btn btn-outline-secondary">Select this page after checking</button>
            <button type="button" id="staffClearSelection" class="btn btn-outline-secondary">Clear selection</button>
        </div>
        <p id="staffGalleryStatus" class="small text-muted"></p>
        <nav class="staff-gallery-pagination d-flex flex-wrap gap-2 align-items-center mb-3" aria-label="Photo review pages"><button type="button" class="btn btn-outline-primary" data-gallery-page="-1" disabled>← Previous 10 days</button><span data-gallery-page-info class="small" role="status"></span><button type="button" class="btn btn-outline-primary" data-gallery-page="1" disabled>Next 10 days →</button></nav>
        <div id="staffReviewGallery" class="row g-3"></div>
        <nav class="staff-gallery-pagination d-flex flex-wrap gap-2 align-items-center mt-3" aria-label="Photo review pages below gallery"><button type="button" class="btn btn-outline-primary" data-gallery-page="-1" disabled>← Previous 10 days</button><span data-gallery-page-info class="small" role="status"></span><button type="button" class="btn btn-outline-primary" data-gallery-page="1" disabled>Next 10 days →</button></nav>
        <form id="staffBatchReview" class="border-top mt-3 pt-3">
            <label for="staffBatchReason" class="form-label">Reason for these approvals (optional)</label><input id="staffBatchReason" name="reason" class="form-control" maxlength="1000" placeholder="Leave blank to use a default reason">
        </form>
        <p class="small text-muted mt-2 mb-0">Up to 10 days per page. Selections stay when you change pages; changing the filter, teacher, month or reloading clears them. Nothing is selected automatically. A photo that has not loaded cannot be included. Every approved date keeps its own review history. Finalize salary separately after the month ends.</p>
    </div></div>
    <div class="card mb-4" id="staffAttendanceCard"><div class="card-header">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2"><div><strong>Monthly attendance — select a date to review its photos</strong><div id="staffAttendancePeriod" class="small text-muted"></div></div>
            <nav class="d-flex align-items-center gap-2 staff-attendance-pagination" aria-label="Monthly attendance pages"><button type="button" id="staffAttendancePrevious" class="btn btn-sm btn-outline-primary" disabled aria-label="Previous 10 attendance days">← Previous</button><label class="visually-hidden" for="staffAttendancePage">Attendance date range</label><select id="staffAttendancePage" class="form-select form-select-sm" aria-label="Attendance date range" disabled></select><button type="button" id="staffAttendanceNext" class="btn btn-sm btn-outline-primary" disabled aria-label="Next 10 attendance days">Next →</button></nav>
        </div>
    </div><div class="table-responsive">
        <table class="table table-sm table-striped align-middle mb-0 staff-attendance-table"><thead><tr><th scope="col">Date</th><th scope="col">Arrival / Departure</th><th scope="col">Status / Review</th><th scope="col">Shift / Rules</th><th scope="col">Late / Early</th><?php if($canPayroll): ?><th scope="col">Deduction</th><?php endif; ?></tr></thead><tbody id="staffDays"></tbody></table>
    </div><div id="staffAttendancePageInfo" class="card-footer small text-muted" role="status"></div></div>
    <div class="card mb-4" id="staffReviewCard"><div class="card-header">Selfie review <span id="staffSelectedDate"></span></div><div class="card-body">
        <p class="small text-muted">Check the face and school background. On-device blink/head-turn checks require human review. ImgBB photos are accessible to anyone who obtains their link.</p>
        <div id="staffPhotos" class="row g-3 mb-3"></div>
        <form id="staffReview" class="row g-3">
            <div class="col-md-3"><label class="form-label">Date<input name="date" type="date" class="form-control" required></label></div>
            <div class="col-md-6"><label class="form-label w-100">Review reason (optional)<input name="reason" class="form-control" maxlength="1000" placeholder="Leave blank to use a default reason"></label></div>
            <div class="col-md-3 align-self-end"><button name="decision" value="approved" class="btn btn-success">Approve day</button> <button name="decision" value="rejected" class="btn btn-danger">Reject day</button></div>
        </form>
        <div id="staffReviewMessage" class="alert d-none mt-3 mb-2" role="status" aria-atomic="true" tabindex="-1"></div>
        <p class="small text-muted mt-2 mb-0">Approval confirms you checked both pictures and the attendance point. Rejected attendance is treated as absent. A later departure or correction requires a fresh review.</p>
    </div></div>
    <div class="accordion mb-4" id="staffTools">
        <div class="accordion-item" id="staffCorrectionItem"><h3 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#staffCorrectionPanel">Attendance correction / leave</button></h3>
            <div id="staffCorrectionPanel" class="accordion-collapse collapse"><div class="accordion-body">
                <form id="staffCorrection" class="row g-3">
                    <div class="col-md-3"><label class="form-label">Date<input name="date" type="date" class="form-control" required></label></div>
                    <div class="col-md-3"><label class="form-label">Status<select name="status" class="form-select"><option value="present">Present (manual times)</option><option value="absent">Absent</option><option value="paid_leave">Paid leave</option><option value="unpaid_leave">Unpaid leave</option><option value="restore">Restore original app punches</option></select></label></div>
                    <div class="col-md-3"><label class="form-label">Arrival<input name="check_in" type="time" class="form-control"></label></div>
                    <div class="col-md-3"><label class="form-label">Departure<input name="check_out" type="time" class="form-control"></label></div>
                    <div class="col-md-9"><label class="form-label w-100">Correction reason (optional)<input name="reason" class="form-control" maxlength="1000" placeholder="Leave blank to use a default reason"></label></div>
                    <div class="col-md-3 align-self-end"><button class="btn btn-primary">Save correction</button></div>
                </form>
                <p class="small text-muted mt-2">Manual corrections preserve original selfies and punches in the audit history. Review the corrected day before finalizing salary.</p>
                <?php if(!$canPayroll): ?>
                <form id="staffDevice" class="row g-3 mt-2"><div class="col-md-9"><label class="form-label w-100">Phone reset reason (optional)<input name="reason" class="form-control" maxlength="1000" placeholder="Leave blank to use a default reason"></label></div><div class="col-md-3 align-self-end"><button class="btn btn-outline-danger">Reset attendance phone</button></div></form>
                <?php endif; ?>
            </div></div>
        </div>
<?php if($canPayroll): ?>
        <div class="accordion-item"><h3 class="accordion-header"><button id="staffSalaryToggle" class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#staffSalaryPanel">Monthly allowances / deductions / settlement</button></h3>
            <div id="staffSalaryPanel" class="accordion-collapse collapse"><div class="accordion-body">
                
                <form id="staffAdjustment" class="row g-3"><div class="col-md-3"><label class="form-label">Type<select name="kind" class="form-select"><option value="addition">Allowance / bonus</option><option value="deduction">Deduction / advance recovery</option></select></label></div><div class="col-md-3"><label class="form-label">Amount<input name="amount" type="number" min="0.01" max="9999999" step="0.01" class="form-control" required></label></div><div class="col-md-4"><label class="form-label w-100">Reason (optional)<input name="reason" class="form-control" maxlength="1000" placeholder="Leave blank to use a default reason"></label></div><div class="col-md-2 align-self-end"><button class="btn btn-primary">Add</button></div></form>
                <ul id="staffAdjustments" class="my-3"></ul><hr>
                <form id="staffSettlement" class="row g-3"><div class="col-md-3"><label class="form-label">Action<select name="action" class="form-select"><option value="finalize">Finalize &amp; lock salary</option><option value="paid">Mark paid</option><option value="reopen">Reopen for correction</option></select></label></div><div class="col-md-4"><label class="form-label w-100">Reason (optional)<input name="reason" class="form-control" maxlength="1000" placeholder="Leave blank to use a default reason"></label></div><div class="col-md-3"><label class="form-label w-100">Payment reference (optional)<input name="reference" class="form-control" maxlength="200" placeholder="Receipt / transaction ID, if available"></label></div><div class="col-md-2 align-self-end"><button class="btn btn-primary">Apply</button></div></form>
                <p class="small text-muted mt-2 mb-0">Leave the payment reference blank to generate a system tracking reference. Enter your receipt or transaction ID if you have one.</p>
                <p class="small text-muted mt-2">Finalize after the month ends. Attendance-based salary requires all saved days to be reviewed; manual salary requires checking salary terms and your adjustments. The final salary is frozen. Mark paid records your payment reference; it does not transfer money. Reopening a paid month retains its old snapshot in the audit history—reconcile any difference before recording payment again.</p>
            </div></div>
        </div>
<?php endif; ?>
    </div>
    <details class="mb-4"><summary>Audit history</summary><div id="staffAudit" class="mt-3"></div></details>
    <div id="staffReviewActions" aria-label="Photo review approval controls"><div class="container py-2">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2"><div class="staff-review-action-summary"><span id="staffBatchTeacher" class="d-block small text-muted"></span><strong id="staffSelectionCount" role="status">0 day(s) selected</strong> <a href="#staffBatchReason" class="small ms-2">Edit reason</a></div><button id="staffBatchApprove" form="staffBatchReview" class="btn btn-success" disabled>Approve selected days</button></div>
        <label class="small d-block mt-1"><input id="staffBatchConfirmed" form="staffBatchReview" type="checkbox" class="form-check-input" required> I checked all selected photos and required live frames.</label>
    </div></div>
</div>
<script src="<?= safe_htmlspecialchars(BASE_URL) ?>/assets/js/teacher-attendance-admin.js?v=22"></script>
<?php include_once __DIR__ . '/../../includes/body-close.php'; ?>
