<?php
require_once __DIR__ . '/../../includes/auth-check.php';
if(!hasPermission(PERM_MANAGE_TEACHERS_ATTENDANCE)) { http_response_code(403); exit('Teacher attendance permission is required.'); }
$_SESSION['staff_attendance_csrf'] ??= bin2hex(random_bytes(32));
$canPayroll=isSuperAdmin();
include_once __DIR__ . '/../../includes/header-open.php';
echo '<title>Teacher Attendance &amp; Payroll</title>';
include_once __DIR__ . '/../../includes/header-close.php';
include_once __DIR__ . '/../../includes/dashboard-navbar.php';
?>
<div class="container py-4" id="staffAttendance" data-endpoint="<?= safe_htmlspecialchars(BASE_URL) ?>/api/admin/teacher-attendance.php" data-csrf="<?= safe_htmlspecialchars($_SESSION['staff_attendance_csrf']) ?>">
    <h2>Teacher Attendance &amp; Payroll</h2>
    <?php $attendanceView="review"; include __DIR__ . "/../../includes/teacher/staff-attendance-navigation.php"; ?>
    <p class="text-muted">Review arrival and departure selfies, resolve missing attendance, then finalize salary. Amounts use <?= safe_htmlspecialchars($currency_symbol) ?>. On-device blink/head-turn checks require human review. Photos are stored on ImgBB and are accessible to anyone who obtains their image link.</p>
    <div id="staffMessage" role="status" class="alert d-none"></div>
    <div class="card mb-4"><div class="card-body">
        <div class="row g-3 align-items-end">
            <div class="col-md-4"><label for="staffTeacher" class="form-label">Teacher</label><select id="staffTeacher" class="form-select"></select></div>
            <div class="col-6 col-md-2"><label for="staffMonthYear" class="form-label">Year</label><select id="staffMonthYear" class="form-select" required><option value="" disabled selected>Select year</option><?php foreach(range(2100,2000) as $year): ?><option value="<?= $year ?>"><?= $year ?></option><?php endforeach; ?></select></div>
            <div class="col-6 col-md-2"><label for="staffMonthName" class="form-label">Month</label><select id="staffMonthName" class="form-select" required><option value="" disabled selected>Select month</option><?php foreach(['January','February','March','April','May','June','July','August','September','October','November','December'] as $index=>$name): ?><option value="<?= sprintf('%02d',$index+1) ?>"><?= $name ?></option><?php endforeach; ?></select><input id="staffMonth" type="hidden"></div>
            <div class="col-md-4"><button id="staffReload" class="btn btn-primary">Load / Reload</button> <?php if($canPayroll): ?><a id="staffSettingsLink" class="btn btn-outline-secondary" href="teacher-attendance-settings.php">Teacher settings</a><?php endif; ?> <button id="staffPrint" class="btn btn-outline-secondary">Print report</button></div>
        </div>
    </div></div>
    <div id="staffSummary" class="row g-3 mb-3"></div>
    <p id="staffFormula" class="small text-muted"></p>
    <div class="card mb-4" id="staffReviewWorkspace"><div class="card-header d-flex flex-wrap gap-2 justify-content-between align-items-center"><div><strong>Monthly photo review</strong><span id="staffGalleryTeacher" class="d-block small"></span></div><button type="button" id="staffNextTeacher" class="btn btn-sm btn-outline-primary">Next teacher with pending reviews →</button></div><div class="card-body">
        <p class="mb-2">Check the teacher and school background in each arrival/departure pair. Tick the days you have checked, then approve them together. Open Live frames when needed. Corrections and missing punches need individual review.</p>
        <div id="staffQueueSummary" class="small fw-semibold mb-2" role="status"></div>
        <details class="mb-3"><summary>All staff — remaining reviews</summary><div id="staffReviewQueue" class="row g-2 mt-1"></div></details>
        <div class="d-flex flex-wrap gap-2 align-items-end mb-3">
            <label for="staffReviewFilter" class="form-label mb-0">Show<select id="staffReviewFilter" class="form-select"><option value="pending">Pending days</option><option value="attention">Needs individual attention</option><option value="all">All saved days</option></select></label>
            <button type="button" id="staffSelectVisible" class="btn btn-outline-secondary">Select this page after checking</button>
            <button type="button" id="staffClearSelection" class="btn btn-outline-secondary">Clear selection</button>
        </div>
        <p id="staffGalleryStatus" class="small text-muted"></p>
        <nav class="staff-gallery-pagination d-flex flex-wrap gap-2 align-items-center mb-3" aria-label="Photo review pages"><button type="button" class="btn btn-outline-primary" data-gallery-page="-1" disabled>← Previous 10 days</button><span data-gallery-page-info class="small" role="status"></span><button type="button" class="btn btn-outline-primary" data-gallery-page="1" disabled>Next 10 days →</button></nav>
        <div id="staffReviewGallery" class="row g-3"></div>
        <nav class="staff-gallery-pagination d-flex flex-wrap gap-2 align-items-center mt-3" aria-label="Photo review pages below gallery"><button type="button" class="btn btn-outline-primary" data-gallery-page="-1" disabled>← Previous 10 days</button><span data-gallery-page-info class="small" role="status"></span><button type="button" class="btn btn-outline-primary" data-gallery-page="1" disabled>Next 10 days →</button></nav>
        <form id="staffBatchReview" class="border-top mt-3 pt-3">
            <label for="staffBatchReason" class="form-label">Reason for these approvals</label><input id="staffBatchReason" name="reason" class="form-control" minlength="5" maxlength="1000" required value="Checked teacher identity and school attendance background in the selected arrival and departure photos.">
        </form>
        <p class="small text-muted mt-2 mb-0">Up to 10 days per page. Selections stay when you change pages; changing the filter, teacher, month or reloading clears them. Nothing is selected automatically. A photo that has not loaded cannot be included. Every approved date keeps its own review history. Finalize salary separately after the month ends.</p>
    </div></div>
    <div class="card mb-4" id="staffAttendanceCard"><div class="card-header">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2"><div><strong>Monthly attendance — select a date to review its photos</strong><div id="staffAttendancePeriod" class="small text-muted"></div></div>
            <nav class="d-flex align-items-center gap-2 staff-attendance-pagination" aria-label="Monthly attendance pages"><button type="button" id="staffAttendancePrevious" class="btn btn-sm btn-outline-primary" disabled aria-label="Previous 10 attendance days">← Previous</button><label class="visually-hidden" for="staffAttendancePage">Attendance date range</label><select id="staffAttendancePage" class="form-select form-select-sm" aria-label="Attendance date range" disabled></select><button type="button" id="staffAttendanceNext" class="btn btn-sm btn-outline-primary" disabled aria-label="Next 10 attendance days">Next →</button></nav>
        </div>
    </div><div class="table-responsive">
        <table class="table table-sm table-striped align-middle mb-0 staff-attendance-table"><thead><tr><th scope="col">Date</th><th scope="col">Arrival / Departure</th><th scope="col">Status / Review</th><th scope="col">Shift / Rules</th><th scope="col">Late / Early</th><?php if($canPayroll): ?><th scope="col">Deduction</th><?php endif; ?></tr></thead><tbody id="staffDays"></tbody></table>
    </div><div id="staffAttendancePageInfo" class="card-footer small text-muted" role="status"></div></div>
    <div class="card mb-4"><div class="card-header">Selfie review <span id="staffSelectedDate"></span></div><div class="card-body">
        <div id="staffPhotos" class="row g-3 mb-3"></div>
        <form id="staffReview" class="row g-3">
            <div class="col-md-3"><label class="form-label">Date<input name="date" type="date" class="form-control" required></label></div>
            <div class="col-md-6"><label class="form-label w-100">Review reason<input name="reason" class="form-control" minlength="5" maxlength="1000" required placeholder="Confirm teacher, location background and both selfies"></label></div>
            <div class="col-md-3 align-self-end"><button name="decision" value="approved" class="btn btn-success">Approve day</button> <button name="decision" value="rejected" class="btn btn-danger">Reject day</button></div>
        </form>
        <div id="staffReviewMessage" class="alert d-none mt-3 mb-2" role="status" aria-atomic="true" tabindex="-1"></div>
        <p class="small text-muted mt-2 mb-0">Approval confirms you checked both pictures and the attendance point. Rejected attendance is treated as absent. A later departure or correction requires a fresh review.</p>
    </div></div>
    <div class="accordion mb-4" id="staffTools">
        <div class="accordion-item"><h3 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#staffCorrectionPanel">Attendance correction / leave</button></h3>
            <div id="staffCorrectionPanel" class="accordion-collapse collapse"><div class="accordion-body">
                <form id="staffCorrection" class="row g-3">
                    <div class="col-md-3"><label class="form-label">Date<input name="date" type="date" class="form-control" required></label></div>
                    <div class="col-md-3"><label class="form-label">Status<select name="status" class="form-select"><option value="present">Present (manual times)</option><option value="absent">Absent</option><option value="paid_leave">Paid leave</option><option value="unpaid_leave">Unpaid leave</option><option value="restore">Restore original app punches</option></select></label></div>
                    <div class="col-md-3"><label class="form-label">Arrival<input name="check_in" type="time" class="form-control"></label></div>
                    <div class="col-md-3"><label class="form-label">Departure<input name="check_out" type="time" class="form-control"></label></div>
                    <div class="col-md-9"><label class="form-label w-100">Correction reason<input name="reason" class="form-control" minlength="5" maxlength="1000" required placeholder="Forgot attendance / server issue / approved leave"></label></div>
                    <div class="col-md-3 align-self-end"><button class="btn btn-primary">Save correction</button></div>
                </form>
                <p class="small text-muted mt-2">Manual corrections preserve original selfies and punches in the audit history. Review the corrected day before finalizing salary.</p>
                <?php if(!$canPayroll): ?>
                <form id="staffDevice" class="row g-3 mt-2"><div class="col-md-9"><label class="form-label w-100">Phone reset reason<input name="reason" class="form-control" required minlength="5" maxlength="1000"></label></div><div class="col-md-3 align-self-end"><button class="btn btn-outline-danger">Reset attendance phone</button></div></form>
                <?php endif; ?>
            </div></div>
        </div>
<?php if($canPayroll): ?>
        <div class="accordion-item"><h3 class="accordion-header"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#staffSalaryPanel">Monthly allowances / deductions / settlement</button></h3>
            <div id="staffSalaryPanel" class="accordion-collapse collapse"><div class="accordion-body">
                
                <form id="staffAdjustment" class="row g-3"><div class="col-md-3"><label class="form-label">Type<select name="kind" class="form-select"><option value="addition">Allowance / bonus</option><option value="deduction">Deduction / advance recovery</option></select></label></div><div class="col-md-3"><label class="form-label">Amount<input name="amount" type="number" min="0.01" max="9999999" step="0.01" class="form-control" required></label></div><div class="col-md-4"><label class="form-label w-100">Reason<input name="reason" class="form-control" required minlength="5" maxlength="1000"></label></div><div class="col-md-2 align-self-end"><button class="btn btn-primary">Add</button></div></form>
                <ul id="staffAdjustments" class="my-3"></ul><hr>
                <form id="staffSettlement" class="row g-3"><div class="col-md-3"><label class="form-label">Action<select name="action" class="form-select"><option value="finalize">Finalize &amp; lock salary</option><option value="paid">Mark paid</option><option value="reopen">Reopen for correction</option></select></label></div><div class="col-md-4"><label class="form-label w-100">Reason<input name="reason" class="form-control" required minlength="5" maxlength="1000"></label></div><div class="col-md-3"><label class="form-label w-100">Payment reference (if paid)<input name="reference" class="form-control" maxlength="200"></label></div><div class="col-md-2 align-self-end"><button class="btn btn-primary">Apply</button></div></form>
                <p class="small text-muted mt-2">Finalize after the month ends and all saved days are reviewed. The final salary is frozen. Mark paid records your payment reference; it does not transfer money. Reopening a paid month retains its old snapshot in the audit history—reconcile any difference before recording payment again.</p>
            </div></div>
        </div>
<?php endif; ?>
    </div>
    <details class="mb-4"><summary>Audit history</summary><div id="staffAudit" class="mt-3"></div></details>
    <div id="staffReviewActions" aria-label="Photo review approval controls"><div class="container py-2">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2"><div class="staff-review-action-summary"><span id="staffBatchTeacher" class="d-block small text-muted"></span><strong id="staffSelectionCount" role="status">0 day(s) selected</strong> <a href="#staffBatchReason" class="small ms-2">Edit reason</a></div><button id="staffBatchApprove" form="staffBatchReview" class="btn btn-success" disabled>Approve selected days</button></div>
        <label class="small d-block mt-1"><input id="staffBatchConfirmed" form="staffBatchReview" type="checkbox" class="form-check-input" required> I checked all selected photos and required live frames.</label>
    </div></div>
</div>
<style>@media print{nav,.accordion,#staffReview,#staffReload,#staffPrint,#staffAudit,details,#staffReviewWorkspace,#staffReviewActions{display:none!important}#staffPhotos img{max-height:180px}#staffAttendance{font-size:11px;padding-bottom:0}}#staffPhotos img{max-height:280px;object-fit:contain;width:100%}.staff-review-photo{display:block;width:100%;height:170px;object-fit:contain;background:#f3f4f6}.staff-review-evidence{width:100%;max-height:240px;object-fit:contain}.staff-review-card.is-selected{border:2px solid #198754}.staff-review-card .staff-photo-error{font-size:.8rem;color:#b02a37}#staffReviewActions{position:fixed;bottom:0;left:0;right:0;z-index:1020;background:#fff;border-top:1px solid #d2d6da;box-shadow:0 -3px 12px #00000012;padding-bottom:env(safe-area-inset-bottom)}#staffAttendance{padding-bottom:190px!important;scroll-padding-bottom:190px}#staffReviewActions .staff-review-action-summary{min-width:0;max-width:100%;overflow-wrap:anywhere}#staffReviewGallery input,#staffBatchReason{scroll-margin-bottom:200px}#staffReviewWorkspace{scroll-margin-top:75px}.staff-gallery-pagination button{font-size:.875rem}@media(min-width:1400px){.staff-review-photo{height:200px}}@media print{#staffAttendance{padding-bottom:0!important}}</style>
<style>#staffAttendanceCard{scroll-margin-top:75px}.staff-attendance-pagination .form-select{width:auto;min-width:105px}.staff-attendance-table{min-width:760px;font-size:.875rem;line-height:1.3}.staff-attendance-table th,.staff-attendance-table td{padding:.25rem .65rem}.staff-attendance-table th{white-space:nowrap}.staff-attendance-table .staff-time-pair{white-space:nowrap}.staff-attendance-table .staff-time-pair span{display:inline-block;min-width:32px;color:#6c757d;font-size:.75rem}.staff-attendance-table .staff-day-selected>*{box-shadow:inset 0 0 0 9999px #eaf2ff}.staff-attendance-table [data-date]{font-size:inherit;font-weight:600;white-space:nowrap;scroll-margin-bottom:190px}.staff-attendance-table .staff-day-meta{font-size:.75rem;color:#6c757d}.staff-attendance-table .badge{font-size:.7rem;font-weight:500}@media print{.staff-attendance-pagination,#staffAttendancePageInfo{display:none!important}.staff-attendance-table{min-width:0;font-size:10px}}</style>
<style>#staffReviewMessage{scroll-margin-bottom:190px;overflow-wrap:anywhere}@media print{#staffReviewMessage{display:none!important}}</style>
<style>#staffAttendance [data-staff-form-message]{scroll-margin-bottom:190px;overflow-wrap:anywhere}@media print{#staffAttendance [data-staff-form-message]{display:none!important}}</style>
<script src="<?= safe_htmlspecialchars(BASE_URL) ?>/assets/js/teacher-attendance-admin.js?v=13"></script>
<?php include_once __DIR__ . '/../../includes/body-close.php'; ?>
