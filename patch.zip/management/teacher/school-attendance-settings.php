<?php
require_once __DIR__ . '/../../includes/auth-check.php';
if(!hasPermission(PERM_MANAGE_TEACHERS_ATTENDANCE)) { http_response_code(403); exit('Teacher attendance permission is required.'); }
$_SESSION['staff_attendance_csrf'] ??= bin2hex(random_bytes(32));
include_once __DIR__ . '/../../includes/header-open.php';
echo '<title>School Attendance Settings</title>';
include_once __DIR__ . '/../../includes/header-close.php';
include_once __DIR__ . '/../../includes/dashboard-navbar.php';
?>
<div class="container py-4" id="staffAttendance" data-view="school" data-endpoint="<?= safe_htmlspecialchars(BASE_URL) ?>/api/admin/teacher-attendance.php" data-csrf="<?= safe_htmlspecialchars($_SESSION['staff_attendance_csrf']) ?>">
    <h2>School Attendance Settings</h2>
    <?php $attendanceView='school'; include __DIR__ . '/../../includes/teacher/staff-attendance-navigation.php'; ?>
    <p class="text-muted">Set these rules once for the whole school. Teachers follow them automatically unless you assign personal settings. Location and live-camera checks always follow school rules.</p>
    <div id="staffMessage" role="status" class="alert d-none"></div>
    <?php if(isSuperAdmin()): ?>
    <div class="card mb-4"><div class="card-header">School attendance &amp; payroll rules</div><div class="card-body">
        <form id="staffRules" class="row g-3">
                    <p id="staffRuleCopyNote" class="col-12 text-primary d-none mb-0" role="status"></p>
                    <div class="col-md-3"><label class="form-label">Effective from<input name="effective_date" type="date" class="form-control" required></label></div>
                    <div class="col-md-3"><label class="form-label">Attendance<select name="enabled" class="form-select"><option value="0">Disabled</option><option value="1">Enabled</option></select></label></div>
                    <div class="col-md-3"><label class="form-label">Time zone<input name="timezone" class="form-control" readonly></label></div>
                    <div class="col-12"><p class="small text-muted mb-0">Enter the school centre and radius in metres (half the diameter). The reported GPS uncertainty must fit inside the boundary. Indoors, poor GPS may require an administrator correction. The first version can be backdated to cover this month's earlier attendance; enter those days manually before settlement. Later versions take effect tomorrow or later.</p></div>
                    <div class="col-md-3"><label class="form-label">Latitude<input name="latitude" type="number" min="-90" max="90" step="any" class="form-control" required></label></div>
                    <div class="col-md-3"><label class="form-label">Longitude<input name="longitude" type="number" min="-180" max="180" step="any" class="form-control" required></label></div>
                    <div class="col-md-3"><label class="form-label">School radius (m)<input name="radius_m" type="number" min="10" max="2000" class="form-control" required></label></div>
                    <div class="col-md-3"><label class="form-label">Maximum GPS error (m)<input name="max_accuracy_m" type="number" min="1" max="100" class="form-control" required></label></div>
                    <div class="col-12"><label class="form-label w-100">Selfie location instructions<textarea name="spot_instructions" class="form-control" maxlength="1000" required></textarea></label></div>
                    <div class="col-md-6"><label class="form-label w-100">Selfie attendance mode<select name="selfie_mode" class="form-select" required><option value="blink_turn">Blink + head turn</option><option value="blink_only">Blink only (no head turn)</option><option value="manual_selfie">Manual live-camera selfie (no gestures)</option></select></label></div>
                    <div class="col-12"><p class="small text-muted mb-0">This camera rule applies to every teacher, on arrival and departure. All modes require an uncovered face and keep the same location, phone and review restrictions. Manual selfie has no motion liveness challenge; review photos carefully. Free on-device mask detection can make mistakes. Update teacher apps before deploying these camera checks.</p></div>
                    <div class="col-12"><label class="form-label">Working weekdays</label><div id="staffWeekdays"></div></div>
                    <?php foreach(['start_time'=>'Shift starts','end_time'=>'Shift ends','checkin_open'=>'Arrival opens','checkin_close'=>'Arrival closes','checkout_close'=>'Departure closes'] as $field=>$label): ?>
                    <div class="col-md-3"><label class="form-label"><?= $label ?><input name="<?= $field ?>" type="time" class="form-control" required></label></div>
                    <?php endforeach; ?>
                    <div class="col-12"><details><summary>Different weekday shifts (optional)</summary><p class="small text-muted mt-2">Customize shift times, arrival/departure windows and minimum work for each weekday. Leave a field blank to follow the common settings. Late/early grace and deductions stay common.</p><div id="staffDaySchedules" class="row g-2 mt-2"></div></details></div>
                    <?php foreach(['late_grace_min'=>'Late grace (minutes)','early_grace_min'=>'Early departure grace (minutes)','minimum_work_min'=>'Minimum shift work (minutes)','absence_percent'=>'Absent day deduction (%)','short_day_percent'=>'Short day deduction (%)'] as $field=>$label): ?>
                    <div class="col-md-3"><label class="form-label"><?= $label ?><input name="<?= $field ?>" type="number" min="0" max="<?= str_ends_with($field,'percent')?100:($field==='minimum_work_min'?1440:180) ?>" class="form-control" required></label></div>
                    <?php endforeach; ?>
                    <?php foreach(['late'=>'Late arrival','early'=>'Early departure'] as $field=>$label): ?>
                    <div class="col-md-3"><label class="form-label"><?= $label ?> mode<select name="<?= $field ?>_mode" class="form-select"><option value="flat">Flat per day</option><option value="per_minute">Per minute after grace</option></select></label></div>
                    <div class="col-md-3"><label class="form-label"><?= $label ?> amount<input name="<?= $field ?>_amount" type="number" min="0" max="1000000" step="0.01" class="form-control" required></label></div>
                    <?php endforeach; ?>
                    <div class="col-md-3"><label class="form-label">Daily deduction divisor<select name="salary_divisor" class="form-select"><option value="working_days">Scheduled working days</option><option value="calendar_days">Calendar days in month</option><option value="fixed">Fixed divisor</option></select></label></div>
                    <div class="col-md-3"><label class="form-label">Fixed divisor<input name="fixed_divisor" type="number" min="1" max="31" class="form-control" required></label></div>
                    <div class="col-md-9"><label class="form-label w-100">Change reason<input name="reason" class="form-control" required minlength="5" maxlength="1000"></label></div><div class="col-md-3 align-self-end"><button class="btn btn-primary">Create rule version</button></div>
                    <p class="small text-muted">Same-day shifts are supported. Missing departure counts as absence after the day ends. Combined late, early and short-day deductions are capped at one day's salary. Set each teacher's monthly salary in Teacher Settings → Salary terms.</p>
                </form>
                <h3 class="h5 mt-4">School rule history</h3>
                <p class="small text-muted">Use this version again copies its settings into the form. Choose a new effective date and save to create a new version. Later scheduled versions still take effect on their dates.</p>
                <ul id="staffPolicyHistory" class="mt-3"></ul>
    </div></div>
    <?php endif; ?>
    <div class="card mb-4"><div class="card-header">School holidays / extra working days</div><div class="card-body">
        <p class="text-muted">School calendar exceptions apply to everyone, including teachers with personal shifts.</p>
        <form id="staffCalendar" class="row g-3"><div class="col-md-3"><label class="form-label">Date<input name="date" type="date" class="form-control" required></label></div><div class="col-md-3"><label class="form-label">Day type<select name="kind" class="form-select"><option value="holiday">Paid school holiday</option><option value="working">Extra working day</option><option value="default">Restore weekday rule</option></select></label></div><div class="col-md-4"><label class="form-label w-100">Reason<input name="reason" class="form-control" required minlength="5" maxlength="1000"></label></div><div class="col-md-2 align-self-end"><button class="btn btn-primary">Save</button></div></form>
                <ul id="staffCalendarList" class="mt-3"></ul>
    </div></div>
</div>
<style>#staffAttendance [data-staff-form-message]{scroll-margin-bottom:190px;overflow-wrap:anywhere}@media print{#staffAttendance [data-staff-form-message]{display:none!important}}</style>
<script src="<?= safe_htmlspecialchars(BASE_URL) ?>/assets/js/teacher-attendance-admin.js?v=13"></script>
<?php include_once __DIR__ . '/../../includes/body-close.php'; ?>
