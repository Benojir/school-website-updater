<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage Teachers - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    include_once("../../includes/permission-denied.php");
}

$stmt = $pdo->query("SELECT COUNT(*) FROM teacher_applications");
$totalEnquiries = $stmt->fetchColumn();
?>

<style>
    /* Table specific overrides */
    .table-responsive {
        position: relative;
        overflow: visible !important;
    }

    .table-responsive img {
        cursor: pointer;
    }

    .action-dropdown .dropdown-menu {
        position: absolute !important;
        z-index: 1000 !important;
    }

    .table-responsive {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }

    .selection-controls {
        display: none;
        /* Initially hidden */
    }
</style>

<div class="container py-4">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0">
                    <i class="fas fa-chalkboard-teacher me-2"></i> Teacher Management
                    <?php if ($totalEnquiries > 0): ?>
                        <a class="btn btn-sm btn-light ms-3 mb-1 position-relative" href="manage-teacher-enquiries.php">
                            Teachers Enquiries
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                <?= ($totalEnquiries > 99) ? '99+' : $totalEnquiries ?>
                            </span>
                        </a>
                    <?php endif; ?>
                </h3>
                <a href="../teacher/add-teacher.php" class="btn btn-light btn-sm">
                    <i class="fas fa-plus me-1"></i> Add Teacher
                </a>
            </div>
        </div>

        <div class="card-body">
            <div class="row mb-4 align-items-center">
                <div class="col-md-8">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" id="searchInput" class="form-control" placeholder="Search teachers...">
                        <select id="statusFilter" class="form-select" style="max-width: 150px;">
                            <option value="">All Status</option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                        <button id="refreshTeachers" class="btn btn-outline-secondary">
                            <i class="fas fa-sync-alt"></i>
                        </button>
                    </div>
                </div>
                <div class="col-md-4 text-end">
                    <div class="selection-controls">
                        <span id="selectionCount" class="me-3 fw-bold">0 selected</span>
                    </div>
                </div>
                <div class="col-md-12">
                    <!-- Action buttons -->
                    <div class="card my-3 bg-light selection-controls">
                        <div class="card-body position-relative">

                            <button id="clearSelection" class="btn-close position-absolute top-0 end-0 mt-3 me-3"></button>

                            <div class="d-flex flex-wrap gap-2 align-items-center">
                                <button class="btn btn-primary" id="id_cards_download_btn">
                                    <i class="fas fa-id-card me-2"></i>Download ID Cards
                                </button>
                                <button class="btn btn-primary">
                                    <i class="fas fa-file-export me-2"></i>Export Information
                                </button>
                                <button class="btn btn-primary">
                                    <i class="fas fa-hand-holding-usd me-2"></i>Pay Salary
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="table-responsive" style="overflow-x: auto !important;">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 5%;"><input class="form-check-input" type="checkbox" id="selectAllCheckbox"></th>
                            <th>ID</th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Specialization</th>
                            <th>Status</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="teachersTableBody">
                    </tbody>
                </table>
            </div>

            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center mt-3" id="paginationContainer">
                </ul>
            </nav>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // --- State Variables ---
        let currentPage = 1;
        const limit = 10;
        let selectedTeachers = new Set(); // Use a Set to store unique selected teacher IDs

        // --- Core Functions ---

        // Load teachers with AJAX
        function loadTeachers(page = 1, search = '', status = '') {
            currentPage = page;
            $.ajax({
                url: '../../api/admin/get/teacher/get-teachers.php',
                type: 'GET',
                data: {
                    page: page,
                    limit: limit,
                    search: search,
                    status: status
                },
                dataType: 'json',
                beforeSend: function() {
                    $('#teachersTableBody').html(`<tr><td colspan="9" class="text-center py-4"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>`);
                },
                success: function(response) {
                    if (response.teachers && response.teachers.length > 0) {
                        let html = '';
                        response.teachers.forEach((teacher) => {
                            const isChecked = selectedTeachers.has(teacher.id.toString());
                            // LINK CHANGED HERE: Direct link to edit-teacher.php
                            html += `
                            <tr id="teacher-${teacher.id}" class="${isChecked ? 'table-primary' : ''}">
                                <td><input class="form-check-input teacher-checkbox" type="checkbox" data-id="${teacher.id}" ${isChecked ? 'checked' : ''}></td>
                                <td>${escapeHtml(teacher.teacher_id)}</td>
                                <td><img src="../../uploads/teachers/${teacher.teacher_image}" alt="${teacher.name}" data-fancybox data-caption="${teacher.name}" class="rounded-circle border" width="60" height="60"></td>
                                <td>${escapeHtml(teacher.name)}</td>
                                <td><a href="mailto:${teacher.email}" class="text-decoration-none text-dark">${teacher.email}</a></td>
                                <td><a href="tel:${teacher.phone}" class="text-decoration-none text-dark">${teacher.phone}</a></td>
                                <td>${escapeHtml(teacher.subject_specialization || 'N/A')}</td>
                                <td>
                                    <span class="badge ${teacher.status === 'active' ? 'bg-success' : 'bg-secondary'}">
                                        ${capitalizeFirstLetter(teacher.status)}
                                    </span>
                                </td>
                                <td class="text-end">
                                    <div class="dropdown action-dropdown">
                                        <button class="btn btn-sm btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-cog"></i></button>
                                        <ul class="dropdown-menu dropdown-menu-end">
                                            <li><a class="dropdown-item" href="edit-teacher.php?teacher_id=${teacher.id}"><i class="fas fa-edit me-2"></i>Edit</a></li>
                                            <li><a class="dropdown-item status-btn" href="#" data-id="${teacher.id}" data-status="${teacher.status === 'active' ? 'inactive' : 'active'}"><i class="fas fa-power-off me-2"></i>${teacher.status === 'active' ? 'Deactivate' : 'Activate'}</a></li>
                                            <li><hr class="dropdown-divider"></li>
                                            <li><a class="dropdown-item delete-btn" href="#" data-id="${teacher.id}" data-name="${escapeHtml(teacher.name)}"><i class="fas fa-trash-alt me-2 text-danger"></i>Delete</a></li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>`;
                        });
                        $('#teachersTableBody').html(html);
                    } else {
                        $('#teachersTableBody').html(`<tr><td colspan="9" class="text-center py-5 text-muted"><i class="fas fa-chalkboard-teacher fa-3x mb-3"></i><h4>No teachers found</h4><p>${search ? 'Try a different search term' : 'Add your first teacher to get started'}</p></td></tr>`);
                    }
                    updatePagination(response.total, page);
                    updateSelectionState();
                },
                error: function() {
                    toastr.error('Failed to load teachers. Please try again.');
                    $('#teachersTableBody').html(`<tr><td colspan="9" class="text-center py-5 text-danger">Error loading data. Please refresh the page.</td></tr>`);
                }
            });
        }

        // --- Selection Logic ---
        function updateSelectionState() {
            const selectionCount = selectedTeachers.size;
            $('#selectionCount').text(`${selectionCount} selected`);

            if (selectionCount > 0) {
                $('.selection-controls').show();
            } else {
                $('.selection-controls').hide();
            }

            // Update "select all" checkbox state
            const allVisibleCheckboxes = $('.teacher-checkbox');
            const allVisibleSelected = allVisibleCheckboxes.length > 0 && allVisibleCheckboxes.filter(':checked').length === allVisibleCheckboxes.length;
            $('#selectAllCheckbox').prop('checked', allVisibleSelected);
        }

        // Toggle all checkboxes
        $('#selectAllCheckbox').on('click', function() {
            const isChecked = $(this).is(':checked');
            $('.teacher-checkbox').each(function() {
                const teacherId = $(this).data('id').toString();
                if (isChecked) {
                    selectedTeachers.add(teacherId);
                    $(this).closest('tr').addClass('table-primary');
                } else {
                    selectedTeachers.delete(teacherId);
                    $(this).closest('tr').removeClass('table-primary');
                }
                $(this).prop('checked', isChecked);
            });
            updateSelectionState();
        });


        // Individual checkbox click
        $(document).on('click', '.teacher-checkbox', function() {
            const teacherId = $(this).data('id').toString();
            if ($(this).is(':checked')) {
                selectedTeachers.add(teacherId);
                $(this).closest('tr').addClass('table-primary');
            } else {
                selectedTeachers.delete(teacherId);
                $(this).closest('tr').removeClass('table-primary');
            }
            updateSelectionState();
        });


        // Update pagination
        function updatePagination(totalRecords, currentPage) {
            const totalPages = Math.ceil(totalRecords / limit);
            let html = '';
            if (totalPages <= 1) {
                $('#paginationContainer').html('');
                return;
            }

            if (currentPage > 1) {
                html += `<li class="page-item"><a class="page-link" href="#" data-page="1" aria-label="First"><i class="fas fa-angle-double-left"></i></a></li>`;
                html += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage - 1}" aria-label="Previous"><i class="fas fa-angle-left"></i></a></li>`;
            }

            const start = Math.max(1, currentPage - 2);
            const end = Math.min(totalPages, currentPage + 2);

            if (start > 1) html += '<li class="page-item disabled"><span class="page-link">...</span></li>';

            for (let i = start; i <= end; i++) {
                html += `<li class="page-item ${i === currentPage ? 'active' : ''}"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
            }

            if (end < totalPages) html += '<li class="page-item disabled"><span class="page-link">...</span></li>';

            if (currentPage < totalPages) {
                html += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage + 1}" aria-label="Next"><i class="fas fa-angle-right"></i></a></li>`;
                html += `<li class="page-item"><a class="page-link" href="#" data-page="${totalPages}" aria-label="Last"><i class="fas fa-angle-double-right"></i></a></li>`;
            }

            $('#paginationContainer').html(html);
        }

        // --- Event Handlers ---

        // Initial load
        loadTeachers();

        // Search and filter handlers
        let searchTimer;
        $('#searchInput').on('input', function() {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => {
                $('#selectAllCheckbox').prop('checked', false);
                loadTeachers(1, $(this).val(), $('#statusFilter').val())
            }, 500);
        });
        $('#statusFilter').change(() => {
            $('#selectAllCheckbox').prop('checked', false);
            loadTeachers(1, $('#searchInput').val(), $('#statusFilter').val())
        });
        $('#refreshTeachers').click(() => loadTeachers(currentPage, $('#searchInput').val(), $('#statusFilter').val()));

        // Pagination click handler
        $(document).on('click', '.page-link', function(e) {
            e.preventDefault();
            const page = $(this).data('page');
            if (page) {
                loadTeachers(page, $('#searchInput').val(), $('#statusFilter').val());
                $('html, body').animate({
                    scrollTop: 0
                }, 'fast');
            }
        });

        // Clear the checkboxes
        $('#clearSelection').on('click', function() {
            // 1. Clear the Set containing the IDs
            selectedTeachers.clear();

            // 2. Uncheck all checkboxes (including the "Select All" box)
            $('.teacher-checkbox').prop('checked', false);
            $('#selectAllCheckbox').prop('checked', false);

            // 3. Remove the blue highlight from all table rows
            $('#teachersTableBody tr').removeClass('table-primary');

            // 4. Update the UI (hides the selection bar and resets the count)
            updateSelectionState();
        });

        // Download ID cards button click
        $('#id_cards_download_btn').on('click', function() {
            const ids = Array.from(selectedTeachers);
            if (ids.length === 0) {
                toastr.warning('Please select at least one teacher to download ID cards.');
                return;
            }
            toastr.info(`Downloading ID cards for ${ids.length} selected teachers.`);
            window.location.href = `../../api/download/download-bulk-teacher-id-card.php?ids=${ids.join(',')}`;
        });

        // --- Status and Delete Actions ---

        // Change teacher status
        $(document).on('click', '.status-btn', function(e) {
            e.preventDefault();
            const teacherId = $(this).data('id');
            const newStatus = $(this).data('status');
            const action = newStatus === 'active' ? 'activate' : 'deactivate';

            Swal.fire({
                title: `${capitalizeFirstLetter(action)} Teacher`,
                text: `Are you sure you want to ${action} this teacher?`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: `Yes, ${action} it!`,
                customClass: {
                    confirmButton: newStatus === 'active' ? 'btn btn-success px-4 py-2' : 'btn btn-warning px-4 py-2',
                    cancelButton: 'btn btn-secondary px-4 py-2',
                    popup: 'rounded-4 shadow-lg'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '../../api/admin/put/teacher/update-teacher-status.php',
                        type: 'POST',
                        data: {
                            id: teacherId,
                            status: newStatus
                        },
                        dataType: 'json',
                        success: (response) => {
                            if (response.success) {
                                toastr.success(response.message);
                                loadTeachers(currentPage, $('#searchInput').val(), $('#statusFilter').val());
                            } else {
                                toastr.error(response.message);
                            }
                        },
                        error: () => toastr.error('An error occurred. Please try again.')
                    });
                }
            });
        });

        // Delete teacher
        $(document).on('click', '.delete-btn', function(e) {
            e.preventDefault();
            const teacherId = $(this).data('id');
            const teacherName = $(this).data('name');

            Swal.fire({
                title: 'Delete Teacher',
                html: `Are you sure you want to delete <strong>${teacherName}</strong>? This action cannot be undone.`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, delete it!',
                customClass: {
                    confirmButton: 'btn btn-danger px-4 py-2',
                    cancelButton: 'btn btn-secondary px-4 py-2',
                    popup: 'rounded-4 shadow-lg'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '../../api/admin/delete/teacher/delete-teacher.php',
                        type: 'POST',
                        data: {
                            id: teacherId
                        },
                        dataType: 'json',
                        success: (response) => {
                            if (response.success) {
                                toastr.success(response.message);
                                // Remove from selection if deleted
                                selectedTeachers.delete(teacherId.toString());
                                loadTeachers(1, $('#searchInput').val(), $('#statusFilter').val()); // Go to first page after delete
                            } else {
                                toastr.error(response.message);
                            }
                        },
                        error: () => toastr.error('An error occurred. Please try again.')
                    });
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>