<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
/** @var PDO $pdo
 * @var string $school_name
 * @var string $currency_symbol
 */
echo "<title>Teacher Profile - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    include_once("../../includes/permission-denied.php");
}

$teacher_id = (int) ($_GET['id'] ?? 0);

if ($teacher_id <= 0) {
    echo "<div class='container py-5'><div class='alert alert-danger'><i class='fas fa-triangle-exclamation me-2'></i>No teacher ID provided.</div>
          <a href='list-teachers.php' class='btn btn-primary'><i class='fas fa-arrow-left me-1'></i> Back to Teachers</a></div>";
    include_once("../../includes/body-close.php");
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM teachers WHERE id = ?");
$stmt->execute([$teacher_id]);
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$teacher) {
    echo "<div class='container py-5'><div class='alert alert-danger'><i class='fas fa-triangle-exclamation me-2'></i>No teacher found with ID <b>" . $teacher_id . "</b>.</div>
          <a href='list-teachers.php' class='btn btn-primary'><i class='fas fa-arrow-left me-1'></i> Back to Teachers</a></div>";
    include_once("../../includes/body-close.php");
    exit();
}

// ---------------------------------------------------------
// Profile photo (falls back to the shared avatar when the file is missing)
// ---------------------------------------------------------
$image_file = !empty($teacher['teacher_image']) ? $teacher['teacher_image'] : 'default_teacher_dp.jpg';
$photo_url = file_exists(__DIR__ . '/../../uploads/teachers/' . $image_file)
    ? BASE_URL . '/uploads/teachers/' . $image_file
    : BASE_URL . '/assets/img/teacher-default-avatar.png';

// ---------------------------------------------------------
// Assigned sections: stored as a JSON list of section IDs
// ---------------------------------------------------------
$assigned_section_ids = json_decode($teacher['assigned_sections'] ?? '[]', true);
if (!is_array($assigned_section_ids)) {
    $assigned_section_ids = [];
}
$assigned_section_ids = array_values(array_filter(array_map('intval', $assigned_section_ids)));

$assigned_sections = [];
if (!empty($assigned_section_ids)) {
    $placeholders = implode(',', array_fill(0, count($assigned_section_ids), '?'));
    $stmt_sec = $pdo->prepare("
        SELECT s.id, c.class_name, s.section_name
        FROM sections s
        JOIN classes c ON s.class_id = c.id
        WHERE s.id IN ($placeholders)
        ORDER BY c.id ASC, s.section_name ASC
    ");
    $stmt_sec->execute($assigned_section_ids);
    $assigned_sections = $stmt_sec->fetchAll(PDO::FETCH_ASSOC);
}

// ---------------------------------------------------------
// Documents: JSON list of {document_name, document_url}
// ---------------------------------------------------------
$documents = json_decode($teacher['documents'] ?? '[]', true);
if (!is_array($documents)) {
    $documents = [];
}

// ---------------------------------------------------------
// Derived values for the summary tiles
// ---------------------------------------------------------
$age = null;
if (!empty($teacher['date_of_birth']) && $teacher['date_of_birth'] !== '0000-00-00') {
    try {
        $age = (new DateTime($teacher['date_of_birth']))->diff(new DateTime())->y;
    } catch (Exception $e) {
        $age = null;
    }
}

$tenure = '';
if (!empty($teacher['joining_date']) && $teacher['joining_date'] !== '0000-00-00') {
    try {
        $joined_diff = (new DateTime($teacher['joining_date']))->diff(new DateTime());
        $tenure_parts = [];
        if ($joined_diff->y > 0) $tenure_parts[] = $joined_diff->y . ' yr' . ($joined_diff->y > 1 ? 's' : '');
        if ($joined_diff->m > 0) $tenure_parts[] = $joined_diff->m . ' mo';
        if (empty($tenure_parts)) $tenure_parts[] = $joined_diff->d . ' day' . ($joined_diff->d === 1 ? '' : 's');
        $tenure = implode(' ', $tenure_parts);
    } catch (Exception $e) {
        $tenure = '';
    }
}

$status_key = strtolower($teacher['status'] ?? '');

// Applications share this table, so the badge covers their statuses too
$status_styles = [
    'active'   => ['bg-success',   'fa-circle-check',    'Active'],
    'inactive' => ['bg-danger',    'fa-circle-xmark',    'Inactive'],
    'pending'  => ['bg-warning text-dark', 'fa-hourglass-half', 'Pending Application'],
    'reject'   => ['bg-danger',    'fa-circle-xmark',    'Rejected Application'],
    'archive'  => ['bg-secondary', 'fa-box-archive',     'Archived Application'],
];
[$status_class, $status_icon, $status_label] = $status_styles[$status_key] ?? ['bg-secondary', 'fa-circle-question', ucfirst($status_key)];

// ---------------------------------------------------------
// Every detail group rendered below. Each row: label, value, icon and
// optionally an href (turns the value into a link) or mono (monospace value).
// ---------------------------------------------------------
$info_sections = [
    [
        'title' => 'Personal & Identity',
        'icon'  => 'fa-id-card',
        'width' => 'col-lg-6',
        'rows'  => [
            ['label' => 'Full Name', 'value' => $teacher['name'], 'icon' => 'fa-user'],
            ['label' => 'Email', 'value' => $teacher['email'], 'icon' => 'fa-envelope', 'href' => 'mailto:' . $teacher['email']],
            ['label' => 'Phone', 'value' => $teacher['phone'], 'icon' => 'fa-phone', 'href' => 'tel:' . $teacher['phone']],
            ['label' => 'Date of Birth', 'value' => !empty($teacher['date_of_birth']) ? formatDate($teacher['date_of_birth']) . ($age !== null ? " ({$age} yrs)" : '') : '', 'icon' => 'fa-cake-candles'],
            ['label' => 'Gender', 'value' => $teacher['gender'], 'icon' => 'fa-venus-mars'],
            ['label' => 'Blood Group', 'value' => $teacher['blood_group'], 'icon' => 'fa-droplet'],
            ['label' => 'Caste Category', 'value' => $teacher['caste_category'], 'icon' => 'fa-people-group'],
            ['label' => 'Religion', 'value' => !empty($teacher['religion']) ? ucwords($teacher['religion']) : '', 'icon' => 'fa-place-of-worship'],
            ['label' => 'Nationality', 'value' => $teacher['nationality'], 'icon' => 'fa-flag'],
            ['label' => 'Aadhaar No.', 'value' => $teacher['aadhaar_number'], 'icon' => 'fa-id-card', 'mono' => true],
        ],
    ],
    [
        'title' => 'Family Details',
        'icon'  => 'fa-people-roof',
        'width' => 'col-lg-6',
        'rows'  => [
            ['label' => "Father's Name", 'value' => $teacher['father_name'], 'icon' => 'fa-person'],
            ['label' => "Father's Phone", 'value' => $teacher['father_phone'], 'icon' => 'fa-phone', 'href' => 'tel:' . $teacher['father_phone']],
            ['label' => "Mother's Name", 'value' => $teacher['mother_name'], 'icon' => 'fa-person-dress'],
            ['label' => "Mother's Phone", 'value' => $teacher['mother_phone'], 'icon' => 'fa-phone', 'href' => 'tel:' . $teacher['mother_phone']],
        ],
    ],
    [
        'title' => 'Professional Details',
        'icon'  => 'fa-briefcase',
        'width' => 'col-lg-6',
        'rows'  => [
            ['label' => 'Position in School', 'value' => $teacher['position_in_school'], 'icon' => 'fa-briefcase'],
            ['label' => 'Qualification', 'value' => $teacher['qualification'], 'icon' => 'fa-graduation-cap'],
            ['label' => 'Specialization', 'value' => $teacher['subject_specialization'], 'icon' => 'fa-book'],
            ['label' => 'Monthly Salary', 'value' => $currency_symbol . number_format((float) $teacher['monthly_salary'], 2), 'icon' => 'fa-money-bill'],
            ['label' => 'Joining Date', 'value' => !empty($teacher['joining_date']) ? formatDate($teacher['joining_date']) : '', 'icon' => 'fa-calendar-check'],
            ['label' => 'Application Date', 'value' => !empty($teacher['application_date']) ? formatDate($teacher['application_date']) : '', 'icon' => 'fa-file-signature'],
        ],
    ],
    [
        'title' => 'Bank & Statutory Details',
        'icon'  => 'fa-building-columns',
        'width' => 'col-lg-6',
        'rows'  => [
            ['label' => 'Bank Name', 'value' => $teacher['bank_name'], 'icon' => 'fa-building-columns'],
            ['label' => 'Branch Name', 'value' => $teacher['bank_branch'], 'icon' => 'fa-location-dot'],
            ['label' => 'Account Number', 'value' => $teacher['account_number'], 'icon' => 'fa-hashtag', 'mono' => true],
            ['label' => 'IFSC Code', 'value' => $teacher['ifsc_code'], 'icon' => 'fa-code', 'mono' => true],
            ['label' => 'PAN No.', 'value' => $teacher['pan_number'], 'icon' => 'fa-id-badge', 'mono' => true],
            ['label' => 'Voter EPIC No.', 'value' => $teacher['voter_epic_number'], 'icon' => 'fa-id-badge', 'mono' => true],
        ],
    ],
    [
        'title' => 'Address Details',
        'icon'  => 'fa-map-location-dot',
        'width' => 'col-12',
        'rows'  => [
            ['label' => 'Village/Town', 'value' => $teacher['village'], 'icon' => 'fa-house'],
            ['label' => 'Post Office', 'value' => $teacher['post_office'], 'icon' => 'fa-envelope-open-text'],
            ['label' => 'Police Station', 'value' => $teacher['police_station'], 'icon' => 'fa-shield-halved'],
            ['label' => 'District', 'value' => $teacher['district'], 'icon' => 'fa-map'],
            ['label' => 'Pincode', 'value' => $teacher['pincode'], 'icon' => 'fa-map-pin'],
            ['label' => 'Full Address', 'value' => $teacher['address'], 'icon' => 'fa-location-dot'],
        ],
    ],
];
?>

<style>
    /* ---------- Hero ---------- */
    .profile-hero {
        border-radius: 14px;
        color: #fff;
        padding: 28px;
    }

    .profile-avatar {
        width: 145px;
        height: 174px;
        object-fit: cover;
        border: 4px solid #fff;
        border-radius: 12px;
        background: #fff;
        box-shadow: 0 8px 24px rgba(0, 0, 0, .25);
        cursor: zoom-in;
    }

    .profile-hero .hero-meta {
        font-size: .9rem;
        opacity: .9;
    }

    .hero-chip {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: rgba(255, 255, 255, .18);
        border: 1px solid rgba(255, 255, 255, .28);
        border-radius: 30px;
        padding: 4px 12px;
        font-size: .82rem;
        margin: 3px 4px 3px 0;
    }

    /* ---------- Summary tiles ---------- */
    .stat-tile {
        background: #fff;
        border: 1px solid #e9ecef;
        border-radius: 12px;
        padding: 14px 16px;
        height: 100%;
    }

    .stat-tile .stat-label {
        font-size: .72rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .04em;
        color: #6c757d;
    }

    .stat-tile .stat-value {
        font-size: 1.12rem;
        font-weight: 700;
        color: #212529;
        line-height: 1.3;
    }

    .stat-tile .stat-icon {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        background: #f1f3f5;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }

    /* ---------- Detail sections ---------- */
    .profile-section .card-header {
        background: #fff;
        border-bottom: 1px solid #eef1f4;
    }

    .info-item {
        border-bottom: 1px dashed #e9ecef;
        padding-bottom: 8px;
    }

    .info-label {
        font-size: .72rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .03em;
        color: #6c757d;
        margin-bottom: 2px;
    }

    .info-value {
        font-size: .95rem;
        font-weight: 600;
        color: #212529;
        word-break: break-word;
    }

    /* ---------- Documents ---------- */
    .doc-tile {
        border: 1px solid #e9ecef;
        border-radius: 12px;
        overflow: hidden;
        background: #fff;
        height: 100%;
        transition: transform .15s ease, box-shadow .15s ease;
    }

    .doc-tile:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 22px rgba(0, 0, 0, .1);
    }

    .doc-thumb {
        display: block;
        width: 100%;
        height: 165px;
        object-fit: cover;
        background: #f8f9fa;
        cursor: zoom-in;
    }

    .doc-caption {
        padding: 10px 12px;
        border-top: 1px solid #eef1f4;
    }

    .doc-name {
        font-size: .88rem;
        font-weight: 700;
        color: #212529;
        word-break: break-word;
    }

    /* ---------- Print ---------- */
    @media print {

        .no-print,
        nav,
        .navbar {
            display: none !important;
        }

        .profile-hero {
            background: #f1f3f5 !important;
            color: #212529 !important;
            border: 1px solid #dee2e6;
        }

        .hero-chip {
            background: #fff;
            border-color: #dee2e6;
            color: #212529;
        }

        .card,
        .doc-tile,
        .stat-tile {
            box-shadow: none !important;
            break-inside: avoid;
        }
    }
</style>

<div class="container-fluid py-4">

    <!-- ===================== HERO ===================== -->
    <div class="profile-hero gradient-heading-bg shadow mb-4">
        <div class="row g-4 align-items-center">
            <div class="col-auto text-center">
                <img src="<?= $photo_url ?>"
                    class="profile-avatar"
                    alt="<?= safe_htmlspecialchars($teacher['name']) ?>"
                    data-fancybox="teacher-photo"
                    data-caption="<?= safe_htmlspecialchars($teacher['name']) ?>">
            </div>

            <div class="col">
                <div class="d-flex align-items-center flex-wrap gap-2 mb-1">
                    <h2 class="mb-0 fw-bold"><?= safe_htmlspecialchars($teacher['name']) ?></h2>
                    <span class="badge <?= $status_class ?> ms-1">
                        <i class="fas <?= $status_icon ?> me-1"></i>
                        <?= safe_htmlspecialchars($status_label) ?>
                    </span>
                </div>

                <div class="hero-meta mb-2">
                    <i class="fas fa-briefcase me-1"></i>
                    <?= !empty($teacher['position_in_school']) ? safe_htmlspecialchars($teacher['position_in_school']) : 'Teacher' ?>
                    <?php if (!empty($teacher['subject_specialization'])): ?>
                        &nbsp;·&nbsp; <i class="fas fa-book me-1"></i><?= safe_htmlspecialchars($teacher['subject_specialization']) ?>
                    <?php endif; ?>
                </div>

                <div>
                    <span class="hero-chip"><i class="fas fa-hashtag"></i> ID: <?= (int) $teacher['id'] ?></span>
                    <?php if (!empty($teacher['email'])): ?>
                        <span class="hero-chip"><i class="fas fa-envelope"></i> <?= safe_htmlspecialchars($teacher['email']) ?></span>
                    <?php endif; ?>
                    <?php if (!empty($teacher['phone'])): ?>
                        <span class="hero-chip"><i class="fas fa-phone"></i> <?= safe_htmlspecialchars($teacher['phone']) ?></span>
                    <?php endif; ?>
                    <?php if (!empty($teacher['qualification'])): ?>
                        <span class="hero-chip"><i class="fas fa-graduation-cap"></i> <?= safe_htmlspecialchars($teacher['qualification']) ?></span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-12 col-xl-auto no-print">
                <div class="d-flex flex-wrap gap-2 justify-content-xl-end">
                    <a href="edit-bulk-teachers.php?teacher_ids=<?= (int) $teacher['id'] ?>" class="btn btn-light btn-sm">
                        <i class="fas fa-edit me-1"></i> Edit
                    </a>
                    <a href="<?= BASE_URL ?>/api/download/download-bulk-teacher-id-card.php?ids=<?= (int) $teacher['id'] ?>" class="btn btn-light btn-sm">
                        <i class="fas fa-id-card me-1"></i> ID Card
                    </a>
                    <button type="button" class="btn btn-light btn-sm" onclick="window.print()">
                        <i class="fas fa-print me-1"></i> Print
                    </button>
                    <a href="list-teachers.php" class="btn btn-dark btn-sm">
                        <i class="fas fa-list me-1"></i> All Teachers
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- ===================== SUMMARY TILES ===================== -->
    <div class="row g-3 mb-4">
        <?php
        $stat_tiles = [
            ['label' => 'Monthly Salary', 'value' => $currency_symbol . number_format((float) $teacher['monthly_salary'], 2), 'icon' => 'fa-money-bill-wave'],
            ['label' => 'Joined', 'value' => !empty($teacher['joining_date']) ? formatDate($teacher['joining_date']) : '—', 'icon' => 'fa-calendar-check'],
            ['label' => 'Experience Here', 'value' => $tenure !== '' ? $tenure : '—', 'icon' => 'fa-hourglass-half'],
            ['label' => 'Assigned Sections', 'value' => count($assigned_sections), 'icon' => 'fa-chalkboard'],
            ['label' => 'Documents', 'value' => count($documents), 'icon' => 'fa-folder-open'],
        ];
        foreach ($stat_tiles as $tile):
        ?>
            <div class="col-6 col-md-4 col-xl">
                <div class="stat-tile shadow-sm d-flex align-items-center gap-3">
                    <div class="stat-icon"><i class="fas <?= $tile['icon'] ?> text-primary"></i></div>
                    <div>
                        <div class="stat-label"><?= $tile['label'] ?></div>
                        <div class="stat-value"><?= safe_htmlspecialchars((string) $tile['value']) ?: '—' ?></div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- ===================== ASSIGNED SECTIONS ===================== -->
    <div class="card border-0 shadow-sm mb-4 profile-section">
        <div class="card-header py-3">
            <h6 class="mb-0 fw-bold text-primary"><i class="fas fa-chalkboard me-2"></i>Assigned Classes & Sections</h6>
        </div>
        <div class="card-body">
            <?php if (!empty($assigned_sections)): ?>
                <?php foreach ($assigned_sections as $section): ?>
                    <span class="badge bg-primary-subtle text-primary border border-primary-subtle rounded-pill px-3 py-2 me-2 mb-2">
                        <i class="fas fa-chalkboard-user me-1"></i>
                        <?= safe_htmlspecialchars($section['class_name']) ?> (<?= safe_htmlspecialchars($section['section_name']) ?>)
                    </span>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="text-muted small mb-0"><i class="fas fa-circle-info me-1"></i> No class or section is assigned to this teacher yet.</div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ===================== DETAIL SECTIONS ===================== -->
    <div class="row g-4">
        <?php foreach ($info_sections as $section): ?>
            <div class="<?= $section['width'] ?>">
                <div class="card border-0 shadow-sm h-100 profile-section">
                    <div class="card-header py-3">
                        <h6 class="mb-0 fw-bold text-primary"><i class="fas <?= $section['icon'] ?> me-2"></i><?= $section['title'] ?></h6>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <?php foreach ($section['rows'] as $row):
                                $value = trim((string) ($row['value'] ?? ''));
                                $is_empty = ($value === '');
                            ?>
                                <div class="col-md-6">
                                    <div class="info-item">
                                        <div class="info-label"><i class="fas <?= $row['icon'] ?> me-1"></i><?= $row['label'] ?></div>
                                        <div class="info-value <?= !empty($row['mono']) ? 'font-monospace' : '' ?>">
                                            <?php if ($is_empty): ?>
                                                <span class="text-muted fw-normal">&mdash;</span>
                                            <?php elseif (!empty($row['href'])): ?>
                                                <a href="<?= safe_htmlspecialchars($row['href']) ?>" class="text-decoration-none"><?= safe_htmlspecialchars($value) ?></a>
                                            <?php else: ?>
                                                <?= safe_htmlspecialchars($value) ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- ===================== DOCUMENTS ===================== -->
    <div class="card border-0 shadow-sm mt-4 profile-section">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="mb-0 fw-bold text-primary">
                <i class="fas fa-folder-open me-2"></i>Documents
                <span class="badge bg-secondary ms-1"><?= count($documents) ?></span>
            </h6>
            <a href="edit-bulk-teachers.php?teacher_ids=<?= (int) $teacher['id'] ?>" class="btn btn-sm btn-outline-primary no-print">
                <i class="fas fa-pen me-1"></i> Manage Documents
            </a>
        </div>
        <div class="card-body">
            <?php if (!empty($documents)): ?>
                <div class="row g-3">
                    <?php foreach ($documents as $document):
                        $doc_name = trim((string) ($document['document_name'] ?? 'Document'));
                        $doc_url = trim((string) ($document['document_url'] ?? ''));
                        if ($doc_url === '') {
                            continue;
                        }
                    ?>
                        <div class="col-6 col-md-4 col-lg-3">
                            <div class="doc-tile shadow-sm">
                                <img src="<?= safe_htmlspecialchars($doc_url) ?>"
                                    class="doc-thumb"
                                    alt="<?= safe_htmlspecialchars($doc_name) ?>"
                                    loading="lazy"
                                    data-fancybox="teacher-documents"
                                    data-caption="<?= safe_htmlspecialchars($doc_name) ?>">
                                <div class="doc-caption d-flex justify-content-between align-items-center gap-2">
                                    <span class="doc-name" title="<?= safe_htmlspecialchars($doc_name) ?>"><?= safe_htmlspecialchars($doc_name) ?></span>
                                    <a href="<?= safe_htmlspecialchars($doc_url) ?>" target="_blank" rel="noopener"
                                        class="btn btn-sm btn-outline-secondary no-print flex-shrink-0" title="Open original">
                                        <i class="fas fa-up-right-from-square"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-center text-muted py-4">
                    <i class="fas fa-folder-open fa-3x mb-3 opacity-50"></i>
                    <p class="mb-0">No documents uploaded for this teacher yet.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ===================== RECORD META ===================== -->
    <div class="text-muted small text-center mt-4">
        <i class="fas fa-clock me-1"></i>
        Record created on <?= !empty($teacher['created_at']) ? formatDate($teacher['created_at']) : '—' ?>
        &nbsp;·&nbsp; Last updated on <?= !empty($teacher['updated_at']) ? formatDate($teacher['updated_at']) : '—' ?>
    </div>
</div>

<?php include_once("../../includes/body-close.php"); ?>
