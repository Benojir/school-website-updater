<?php
require_once __DIR__ . '/../../includes/auth-check.php';
if(!hasPermission(PERM_MANAGE_TEACHERS_ATTENDANCE) || !isSuperAdmin()) {http_response_code(403);exit('Only the super administrator can view salary payments.');}
include_once __DIR__ . '/../../includes/header-open.php';
echo '<title>Monthly Salary Payments</title>';
include_once __DIR__ . '/../../includes/header-close.php';
include_once __DIR__ . '/../../includes/dashboard-navbar.php';
?>
<link rel="stylesheet" href="<?= safe_htmlspecialchars(BASE_URL) ?>/assets/css/staff-salary-payments.css?v=1">
<div class="container py-4" id="staffSalaryPayments" data-endpoint="<?= safe_htmlspecialchars(BASE_URL) ?>/api/admin/teacher-attendance.php" data-month="<?= date('Y-m') ?>" data-currency="<?= safe_htmlspecialchars($currency_symbol) ?>">
    <h2>Monthly Salary Payments</h2>
    <?php $attendanceView='payments';include __DIR__ . '/../../includes/teacher/staff-attendance-navigation.php'; ?>
    <p class="text-muted">See all teachers' recorded payments together. Only payments saved with <strong>Mark paid</strong> appear here. Finalized or estimated salaries are not payments.</p>
    <form id="staffPaymentsFilters" class="card mb-3"><div class="card-body row g-3 align-items-end">
        <div class="col-6 col-md-2"><label class="form-label w-100" for="staffPaymentsYear">Year<select id="staffPaymentsYear" class="form-select" required><?php foreach(range(2100,2000) as $year): ?><option value="<?= $year ?>" <?= $year===(int)date('Y')?'selected':'' ?>><?= $year ?></option><?php endforeach; ?></select></label></div>
        <div class="col-6 col-md-2"><label class="form-label w-100" for="staffPaymentsMonth">Month<select id="staffPaymentsMonth" class="form-select" required><?php foreach(['January','February','March','April','May','June','July','August','September','October','November','December'] as $index=>$name): ?><option value="<?= sprintf('%02d',$index+1) ?>" <?= $index+1===(int)date('n')?'selected':'' ?>><?= $name ?></option><?php endforeach; ?></select></label></div>
        <div class="col-md-3"><label class="form-label w-100" for="staffPaymentsBasis">Find by<select id="staffPaymentsBasis" class="form-select" aria-describedby="staffPaymentsHelp"><option value="salary_month">Salary month</option><option value="payment_month">Payment month</option></select></label></div>
        <div class="col-md-3"><label class="form-label w-100" for="staffPaymentsView">Show<select id="staffPaymentsView" class="form-select"><option value="teachers">Total by teacher</option><option value="entries">Payment entries / references</option></select></label></div>
        <div class="col-md-2"><button type="submit" class="btn btn-primary">Load report</button></div>
        <p id="staffPaymentsHelp" class="col-12 small text-muted mb-0">Salary month: September salary paid in October belongs to September. Payment month: that payment belongs to October.</p>
    </div></form>
    <div id="staffPaymentsMessage" class="alert d-none" role="status" aria-live="polite" tabindex="-1"></div>
    <div class="d-flex flex-wrap align-items-center gap-2 mb-3"><button id="staffPaymentsPrint" type="button" class="btn btn-outline-primary" disabled>Print A4 / Save PDF</button><span class="small text-muted">Choose a report view, then print. All rows print, including rows below the scroll area.</span></div>
    <section id="staffPaymentsPrintable" hidden aria-label="Salary payment report">
        <header class="staff-payments-heading"><h3><?= safe_htmlspecialchars($school_name) ?></h3><?php if(!empty($schoolInfo['campus_name'])): ?><p><?= safe_htmlspecialchars($schoolInfo['campus_name']) ?></p><?php endif; ?><h4 id="staffPaymentsTitle"></h4><p id="staffPaymentsGenerated" class="small text-muted"></p></header>
        <div id="staffPaymentsTotals" class="staff-payments-totals"></div>
        <p id="staffPaymentsWarning" class="alert alert-warning" hidden></p>
        <div class="staff-payments-scroll" tabindex="0" aria-label="All salary payment rows"><table class="table table-bordered table-striped align-middle staff-payments-table"><caption id="staffPaymentsCaption"></caption><thead id="staffPaymentsHead"></thead><tbody id="staffPaymentsRows"></tbody><tfoot id="staffPaymentsFoot"></tfoot></table></div>
        <p class="small mt-2">These are amounts recorded with Mark paid; this page does not transfer money or verify bank receipts. Payment history remains after salary corrections. Check repeated or reopened salary entries against receipts before treating them as separate payments.</p>
        <div class="staff-payments-signatures"><span>Prepared by: __________________</span><span>Checked / approved by: __________________</span></div>
    </section>
    <p id="staffPaymentsPrintGuard" class="staff-payments-print-guard">Load the selected month successfully before printing a salary payment report.</p>
</div>
<script src="<?= safe_htmlspecialchars(BASE_URL) ?>/assets/js/staff-salary-payments.js?v=1"></script>
<?php include_once __DIR__ . '/../../includes/body-close.php'; ?>
