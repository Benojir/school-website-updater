<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Edit Teacher - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check admin permission
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    include_once("../../includes/permission-denied.php");
}

// Get Teacher ID from URL
$teacher_id = isset($_GET['teacher_id']) ? intval($_GET['teacher_id']) : 0;

if ($teacher_id <= 0) {
    echo "<div class='container py-5'><div class='alert alert-danger'>Invalid Teacher ID provided. <a href='list-teachers.php' class='alert-link'>Go back</a></div></div>";
    include_once("../../includes/body-close.php");
    exit;
}

// Fetch Teacher Data
try {
    $stmt = $pdo->prepare("SELECT * FROM teachers WHERE id = ?");
    $stmt->execute([$teacher_id]);
    $teacher = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$teacher) {
        echo "<div class='container py-5'><div class='alert alert-danger'>Teacher not found. <a href='list-teachers.php' class='alert-link'>Go back</a></div></div>";
        include_once("../../includes/body-close.php");
        exit;
    }
} catch (PDOException $e) {
    echo "<div class='container py-5'><div class='alert alert-danger'>Database error: " . $e->getMessage() . "</div></div>";
    include_once("../../includes/body-close.php");
    exit;
}
?>

<style>
    /* Styles for image preview and cropper container */
    .image-preview-wrapper {
        border: 2px dashed #dee2e6;
        padding: 10px;
        margin-bottom: 15px;
        text-align: center;
        background-color: #f8f9fa;
        height: 250px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
    }

    #imagePreview {
        max-height: 100%;
        max-width: 100%;
        object-fit: contain;
        display: block;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    /* Styles for the crop modal */
    .img-container {
        height: 500px;
        overflow: hidden;
        background: #f7f7f7;
    }
</style>

<div class="container py-4">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0"><i class="fas fa-user-edit me-2"></i>Edit Teacher Details</h4>
            <a href="list-teachers.php" class="btn btn-light btn-sm"><i class="fas fa-arrow-left me-1"></i> Back to List</a>
        </div>

        <div class="card-body p-4">
            <form id="editTeacherForm">
                <input type="hidden" name="id" value="<?= $teacher['id'] ?>">

                <div class="row g-4">
                    <div class="col-12">
                        <h5 class="border-bottom pb-2 text-primary">Personal Information</h5>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-bold">Full Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control" value="<?= safe_htmlspecialchars($teacher['name']) ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-bold">Email <span class="text-danger">*</span></label>
                        <input type="email" name="email" class="form-control" value="<?= safe_htmlspecialchars($teacher['email']) ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-bold">Phone <span class="text-danger">*</span></label>
                        <input type="text" name="phone" class="form-control" value="<?= safe_htmlspecialchars($teacher['phone']) ?>" required>
                    </div>

                    <div class="col-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">Professional Details</h5>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-bold">Joining Date <span class="text-danger">*</span></label>
                        <input type="date" name="joining_date" class="form-control" value="<?= $teacher['joining_date'] ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-bold">Status <span class="text-danger">*</span></label>
                        <select name="status" class="form-select" required>
                            <option value="active" <?= $teacher['status'] === 'active' ? 'selected' : '' ?>>Active</option>
                            <option value="inactive" <?= $teacher['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-bold">Qualification</label>
                        <input type="text" name="qualification" class="form-control" value="<?= safe_htmlspecialchars($teacher['qualification'] ?? '') ?>">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-bold">Subject Specialization</label>
                        <input type="text" name="subject_specialization" class="form-control" value="<?= safe_htmlspecialchars($teacher['subject_specialization'] ?? '') ?>">
                    </div>

                    <div class="col-12">
                        <label class="form-label fw-bold">Address</label>
                        <textarea name="address" class="form-control" rows="3"><?= safe_htmlspecialchars($teacher['address'] ?? '') ?></textarea>
                    </div>

                    <div class="col-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">Profile Photo</h5>
                    </div>

                    <div class="col-md-4">
                        <div class="image-preview-wrapper">
                            <img id="imagePreview"
                                src="../../uploads/teachers/<?= !empty($teacher['teacher_image']) ? $teacher['teacher_image'] : '../../assets/img/teacher-default-avatar.png' ?>"
                                data-original-src="../../uploads/teachers/<?= !empty($teacher['teacher_image']) ? $teacher['teacher_image'] : '../../assets/img/teacher-default-avatar.png' ?>">
                        </div>
                    </div>
                    <div class="col-md-8">
                        <label class="form-label fw-bold">Upload New Photo</label>
                        <input type="file" id="teacherPhoto" name="teacher_photo" class="form-control mb-2" accept="image/*">
                        <div class="form-text text-muted mb-3">Recommended aspect ratio: 5:6. You will be asked to crop the image after selecting.</div>

                        <?php if (!empty($teacher['teacher_image'])): ?>
                            <div class="form-check p-3 border rounded bg-light overflow-hidden">
                                <input class="form-check-input ms-0 me-2" type="checkbox" name="remove_photo" id="removePhoto">
                                <label class="form-check-label text-danger fw-bold" for="removePhoto">
                                    Remove current photo
                                </label>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="d-flex justify-content-end mt-5 gap-2">
                    <button type="submit" class="btn btn-primary px-4 fw-bold"><i class="fas fa-save me-2"></i> Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="cropModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-crop me-2"></i> Crop Image</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <div class="img-container">
                    <img id="modalCropper" src="" class="img-fluid">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" id="confirmCrop" class="btn btn-primary">Crop & Save</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        let cropper;
        let croppedImageBlob = null;
        let cropConfirmed = false;

        // --- Image Handling & Cropping ---

        // File input change
        $('#teacherPhoto').on('change', function(e) {
            if (this.files && this.files[0]) {
                const file = this.files[0];
                if (!file.type.match('image.*')) {
                    toastr.error('Please select a valid image file (JPG, PNG).');
                    return;
                }

                // Uncheck remove photo if user selects a new one
                $('#removePhoto').prop('checked', false);

                cropConfirmed = false;
                const reader = new FileReader();
                reader.onload = function(event) {
                    $('#modalCropper').attr('src', event.target.result);
                    $('#cropModal').modal('show');
                };
                reader.readAsDataURL(file);
            }
        });

        // Initialize Cropper when modal opens
        $('#cropModal').on('shown.bs.modal', function() {
            if (cropper) cropper.destroy();
            cropper = new Cropper(document.getElementById('modalCropper'), {
                aspectRatio: 5 / 6,
                viewMode: 1,
                autoCropArea: 0.9,
                responsive: true
            });
        });

        // Confirm Crop
        $('#confirmCrop').click(function() {
            if (!cropper) return;
            const canvas = cropper.getCroppedCanvas({
                width: 500,
                height: 600,
                fillColor: '#fff',
                imageSmoothingEnabled: true,
                imageSmoothingQuality: 'high'
            });

            if (canvas) {
                canvas.toBlob((blob) => {
                    croppedImageBlob = blob;
                    $('#imagePreview').attr('src', URL.createObjectURL(blob));
                    cropConfirmed = true;
                    $('#cropModal').modal('hide');
                }, 'image/jpeg', 0.9);
            }
        });

        // Reset if crop cancelled
        $('#cropModal').on('hidden.bs.modal', function() {
            if (!cropConfirmed) {
                $('#teacherPhoto').val(null);
            }
            if (cropper) {
                cropper.destroy();
                cropper = null;
            }
        });

        // Handle "Remove Photo" checkbox
        $('#removePhoto').on('change', function() {
            if ($(this).is(':checked')) {
                croppedImageBlob = null;
                $('#teacherPhoto').val(null).prop('disabled', true);
                // Reset preview to default or original
                const originalSrc = $('#imagePreview').data('original-src');
                // Ideally, visual feedback that it will be deleted, e.g., opacity
                $('#imagePreview').css('opacity', '0.5');
            } else {
                $('#teacherPhoto').prop('disabled', false);
                $('#imagePreview').css('opacity', '1');
            }
        });

        // --- Form Submission ---

        $('#editTeacherForm').on('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);

            // Handle Image Logic
            if (croppedImageBlob) {
                formData.append('cropped_image', croppedImageBlob, 'teacher_photo.jpg');
            }
            // Remove the original large file from upload to save bandwidth
            formData.delete('teacher_photo');

            $.ajax({
                url: '../../api/admin/put/teacher/update-teacher.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                processData: false,
                contentType: false,
                beforeSend: function() {
                    $('button[type="submit"]').prop('disabled', true).html(`<span class="spinner-border spinner-border-sm me-2"></span>Saving...`);
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message,
                            showConfirmButton: true,
                            confirmButtonText: 'OK',
                            customClass: {
                                confirmButton: 'btn btn-success px-4 py-2',
                                popup: 'rounded-4 shadow-lg'
                            },
                            willClose: () => {
                                window.location.href = 'list-teachers.php';
                            }
                        });
                    } else {
                        showErrorAlert(response.message);
                    }
                },
                error: function() {
                    showErrorAlert('An error occurred. Please try again.');
                },
                complete: function() {
                    $('button[type="submit"]').prop('disabled', false).html(`<i class="fas fa-save me-2"></i> Save Changes`);
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>