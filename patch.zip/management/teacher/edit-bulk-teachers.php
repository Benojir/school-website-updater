<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Bulk Edit Teachers - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check admin permission
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    include_once("../../includes/permission-denied.php");
    exit();
}

// Get teacher IDs from query string
$teacher_ids = $_GET['teacher_ids'] ?? '';
if (!$teacher_ids) {
    die("<div class='container py-5'><div class='alert alert-danger'>Teacher IDs are required.</div></div>");
}

// Convert comma-separated string to array
$teacher_ids_array = explode(',', $teacher_ids);
$teacher_ids_array = array_map('trim', $teacher_ids_array);
$teacher_ids_array = array_filter($teacher_ids_array);

if (empty($teacher_ids_array)) {
    die("<div class='container py-5'><div class='alert alert-danger'>No valid teacher IDs provided.</div></div>");
}

// Fetch teachers data
$placeholders = implode(',', array_fill(0, count($teacher_ids_array), '?'));
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE id IN ($placeholders)");
$stmt->execute($teacher_ids_array);
$teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($teachers)) {
    die("<div class='container py-5'><div class='alert alert-danger'>No teachers found with the provided IDs.</div></div>");
}

// Fetch Sections for dropdown
$stmt_sec = $pdo->prepare("
    SELECT s.id, c.class_name, s.section_name 
    FROM sections s 
    JOIN classes c ON s.class_id = c.id 
    ORDER BY c.id ASC, s.section_name ASC
");
$stmt_sec->execute();
$all_sections = $stmt_sec->fetchAll(PDO::FETCH_ASSOC);

// Data for dropdowns
$statusValues = ['active', 'inactive'];
?>

<style>
    /* Table specific styles */
    .editable-field { border: 1px solid #ddd; padding: 5px; min-width: 100px; }
    .editable-field:focus { border-color: #80bdff; outline: 0; box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25); }
    .teacher-row.changed { background-color: #fffde7; }
    .update-btn { display: none; }
    .teacher-row.changed .update-btn { display: inline-block; }
    .field-checkboxes { background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
    .field-checkboxes label { margin-right: 15px; font-weight: normal; }
    .photo-preview { width: 50px; height: 60px; object-fit: cover; cursor: pointer; border: 1px solid #ccc; }
    table th, table td { text-align: center; vertical-align: middle; }
    .th-min-width { min-width: 170px; white-space: nowrap; }
    .td-min-width input, .td-min-width select { min-width: 150px; }

    /* Cropper modal styles */
    .modal-xl { max-width: 90%; }
    .img-container { position: relative; overflow: hidden; margin: 0 auto; height: 70vh; min-height: 400px; background-color: #f8f9fa; display: flex; align-items: center; justify-content: center; }
    #imageToCrop { max-width: 100%; max-height: 100%; }
</style>

<div class="container-fluid mt-4 mb-5">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0"><i class="fas fa-users-cog me-2"></i> Bulk Edit Teachers</h4>
        </div>

        <div class="card-body">
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i> You are editing <?= count($teachers) ?> teachers. Only changed fields will be updated.
            </div>

            <div class="field-checkboxes mb-4">
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="check-name">
                    <label class="form-check-label" for="check-name"><b>Edit Name</b></label>
                </div>
                <hr>
                <h5><i class="fas fa-check-square me-2"></i> Fields to Display:</h5>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-image" value="teacher_image" checked>
                    <label class="form-check-label" for="toggle-image">Photo</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-email" value="email" checked>
                    <label class="form-check-label" for="toggle-email">Email</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-phone" value="phone" checked>
                    <label class="form-check-label" for="toggle-phone">Phone</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-aadhaar" value="aadhaar_number">
                    <label class="form-check-label" for="toggle-aadhaar">Aadhaar No.</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-salary" value="monthly_salary" checked>
                    <label class="form-check-label" for="toggle-salary">Salary</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-sections" value="assigned_sections" checked>
                    <label class="form-check-label" for="toggle-sections">Sections</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-position" value="position_in_school">
                    <label class="form-check-label" for="toggle-position">Position</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-specialization" value="subject_specialization">
                    <label class="form-check-label" for="toggle-specialization">Specialization</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-qualification" value="qualification">
                    <label class="form-check-label" for="toggle-qualification">Qualification</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-joining" value="joining_date">
                    <label class="form-check-label" for="toggle-joining">Joining Date</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-status" value="status">
                    <label class="form-check-label" for="toggle-status">Status</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-village" value="village">
                    <label class="form-check-label" for="toggle-village">Village</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-post-office" value="post_office">
                    <label class="form-check-label" for="toggle-post-office">Post Office</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-police-station" value="police_station">
                    <label class="form-check-label" for="toggle-police-station">Police Station</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-district" value="district">
                    <label class="form-check-label" for="toggle-district">District</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input field-toggle" type="checkbox" id="toggle-pincode" value="pincode">
                    <label class="form-check-label" for="toggle-pincode">Pincode</label>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-light table-hover" id="teachersTable">
                    <thead>
                        <tr>
                            <th class="bg-dark text-white th-min-width">Name</th>
                            <th class="field-column bg-dark text-white" data-field="teacher_image">Photo</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="email">Email <span class="text-danger">*</span></th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="phone">Phone <span class="text-danger">*</span></th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="aadhaar_number">Aadhaar No.</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="monthly_salary">Salary</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="assigned_sections">Assigned Sections</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="position_in_school">Position</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="subject_specialization">Specialization</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="qualification">Qualification</th>
                            <th class="field-column bg-dark text-white th-min-width" data-field="joining_date">Joining Date <span class="text-danger">*</span></th>
                            <th class="field-column bg-dark text-white" data-field="status">Status</th>
                            <th class="field-column bg-dark text-white" data-field="village">Village</th>
                            <th class="field-column bg-dark text-white" data-field="post_office">Post Office</th>
                            <th class="field-column bg-dark text-white" data-field="police_station">Police Station</th>
                            <th class="field-column bg-dark text-white" data-field="district">District</th>
                            <th class="field-column bg-dark text-white" data-field="pincode">Pincode</th>
                            <th class="bg-dark text-white">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($teachers as $teacher): ?>
                            <tr class="teacher-row" data-teacher-id="<?= safe_htmlspecialchars($teacher['id']) ?>">
                                <td class="td-min-width">
                                    <input type="text" class="form-control form-control-sm editable-field name-input text-center" value="<?= safe_htmlspecialchars($teacher['name']) ?>" disabled>
                                    <small class="text-muted d-block mt-1">ID: <?= safe_htmlspecialchars($teacher['id']) ?></small>
                                </td>

                                <td class="field-column" data-field="teacher_image">
                                    <?php 
                                        $img_src = !empty($teacher['teacher_image']) ? $teacher['teacher_image'] : 'default_teacher_dp.jpg';
                                        // Handle absolute path to default avatar if it's not in the uploads folder
                                        if ($img_src === 'default_teacher_dp.jpg' && !file_exists("../../uploads/teachers/".$img_src)) {
                                            $img_url = "../../assets/img/teacher-default-avatar.png";
                                        } else {
                                            $img_url = "../../uploads/teachers/" . safe_htmlspecialchars($img_src);
                                        }
                                    ?>
                                    <img src="<?= $img_url ?>" class="photo-preview rounded">
                                    <input type="file" class="form-control mt-1 image-upload" style="display: none;" accept="image/*">
                                    <input type="hidden" class="current-image" value="<?= safe_htmlspecialchars($teacher['teacher_image'] ?? '') ?>">
                                    <input type="hidden" class="cropped-image-data">
                                </td>

                                <td class="field-column td-min-width" data-field="email">
                                    <input type="email" class="form-control form-control-sm editable-field email-input" value="<?= safe_htmlspecialchars($teacher['email']) ?>" required>
                                </td>

                                <td class="field-column td-min-width" data-field="phone">
                                    <input type="tel" class="form-control form-control-sm editable-field phone-input" value="<?= safe_htmlspecialchars($teacher['phone']) ?>" required>
                                </td>
                                
                                <td class="field-column td-min-width" data-field="aadhaar_number">
                                    <input type="text" class="form-control form-control-sm editable-field aadhaar-input" value="<?= safe_htmlspecialchars($teacher['aadhaar_number'] ?? '') ?>">
                                </td>

                                <td class="field-column td-min-width" data-field="monthly_salary">
                                    <input type="text" class="form-control form-control-sm editable-field salary-input" value="<?= safe_htmlspecialchars($teacher['monthly_salary'] ?? '') ?>" oninput="autoCorrectNumberInput(this)">
                                </td>

                                <td class="field-column td-min-width" data-field="assigned_sections">
                                    <?php 
                                        $assigned = json_decode($teacher['assigned_sections'] ?? '[]', true);
                                        if (!is_array($assigned)) $assigned = [];
                                    ?>
                                    <select class="form-select form-select-sm editable-field sections-select custom-multiselect" multiple>
                                        <?php foreach ($all_sections as $sec): ?>
                                            <option value="<?= $sec['id'] ?>" <?= in_array($sec['id'], $assigned) ? 'selected' : '' ?>>
                                                <?= safe_htmlspecialchars($sec['class_name']) ?> (<?= safe_htmlspecialchars($sec['section_name']) ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>

                                <td class="field-column td-min-width" data-field="position_in_school">
                                    <input type="text" class="form-control form-control-sm editable-field position-input" value="<?= safe_htmlspecialchars($teacher['position_in_school']) ?>">
                                </td>

                                <td class="field-column td-min-width" data-field="subject_specialization">
                                    <input type="text" class="form-control form-control-sm editable-field specialization-input" value="<?= safe_htmlspecialchars($teacher['subject_specialization']) ?>">
                                </td>

                                <td class="field-column td-min-width" data-field="qualification">
                                    <input type="text" class="form-control form-control-sm editable-field qualification-input" value="<?= safe_htmlspecialchars($teacher['qualification']) ?>">
                                </td>

                                <td class="field-column td-min-width" data-field="joining_date">
                                    <input type="date" class="form-control form-control-sm editable-field joining-input" value="<?= safe_htmlspecialchars($teacher['joining_date']) ?>" required>
                                </td>

                                <td class="field-column" data-field="status">
                                    <select class="form-control form-control-sm editable-field status-select">
                                        <?php foreach ($statusValues as $status): ?>
                                            <option value="<?= $status ?>" <?= $teacher['status'] === $status ? 'selected' : '' ?>>
                                                <?= ucfirst($status) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>

                                <td class="field-column td-min-width" data-field="village">
                                    <input type="text" class="form-control form-control-sm editable-field village-input" value="<?= safe_htmlspecialchars($teacher['village']) ?>">
                                </td>
                                <td class="field-column td-min-width" data-field="post_office">
                                    <input type="text" class="form-control form-control-sm editable-field post-office-input" value="<?= safe_htmlspecialchars($teacher['post_office']) ?>">
                                </td>
                                <td class="field-column td-min-width" data-field="police_station">
                                    <input type="text" class="form-control form-control-sm editable-field police-station-input" value="<?= safe_htmlspecialchars($teacher['police_station']) ?>">
                                </td>
                                <td class="field-column td-min-width" data-field="district">
                                    <input type="text" class="form-control form-control-sm editable-field district-input" value="<?= safe_htmlspecialchars($teacher['district']) ?>">
                                </td>
                                <td class="field-column td-min-width" data-field="pincode">
                                    <input type="text" class="form-control form-control-sm editable-field pincode-input" value="<?= safe_htmlspecialchars($teacher['pincode']) ?>">
                                </td>

                                <td>
                                    <button class="btn btn-sm btn-primary update-btn" data-teacher-id="<?= safe_htmlspecialchars($teacher['id']) ?>">
                                        <i class="fas fa-save"></i> Update
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="text-center mt-4">
                <button id="updateAllBtn" class="btn btn-primary px-4 py-2">
                    <i class="fas fa-save me-2"></i> Update All Changes
                </button>
                <a href="list-teachers.php" class="btn btn-secondary px-4 py-2 ms-2">
                    <i class="fas fa-times me-2"></i> Cancel
                </a>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="cropModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-crop me-2"></i> Crop Teacher Photo (5:6 Ratio)</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <div class="img-container">
                    <img id="imageToCrop" src="" class="img-fluid">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" id="cropImageBtn" class="btn btn-primary">Crop & Save</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        let cropper;
        let currentImageRow;
        const cropModal = new bootstrap.Modal(document.getElementById('cropModal'));
        let emailAddresses = {};

        // Toggle name editing
        $('#check-name').change(function() {
            $('.name-input').prop('disabled', !$(this).is(':checked'));
        });

        // Toggle columns
        $('.field-toggle').change(function() {
            const fields = $(this).val().split(',');
            const isChecked = $(this).is(':checked');
            fields.forEach(field => {
                $(`.field-column[data-field="${field}"]`).toggle(isChecked);
            });
        }).trigger('change');

        // Track original values and highlight changes
        $('.teacher-row').each(function() {
            const row = $(this);
            row.find('.editable-field').each(function() {
                // Special handling for multi-select to track initial state accurately
                if ($(this).is('select[multiple]')) {
                    $(this).data('original-value', JSON.stringify($(this).val() || []));
                } else {
                    $(this).data('original-value', $(this).val());
                }
            });
            // Pre-fill email array for live validation
            const id = row.data('teacher-id').toString();
            const email = row.find('.email-input').val().trim();
            if(email) emailAddresses[id] = email;
        });

        $('.editable-field, .image-upload').on('input change', function() {
            $(this).closest('.teacher-row').addClass('changed');
        });

        // Email validation frontend
        $(document).on('input blur', '.email-input', function() {
            const $input = $(this);
            const $row = $input.closest('.teacher-row');
            const teacherId = $row.data('teacher-id').toString();
            const newEmail = $input.val().trim();

            $input.siblings('.invalid-feedback').remove();
            $input.removeClass('is-invalid is-valid');

            if (!newEmail) {
                $input.addClass('is-invalid');
                $input.after(`<div class="invalid-feedback d-block">Email is required</div>`);
                return;
            }

            let isDuplicate = false;
            for (let [id, email] of Object.entries(emailAddresses)) {
                if (id !== teacherId && email.toLowerCase() === newEmail.toLowerCase()) {
                    isDuplicate = true; break;
                }
            }

            if (isDuplicate) {
                $input.addClass('is-invalid');
                $input.after(`<div class="invalid-feedback d-block">Email is already used in this list</div>`);
            } else {
                $input.addClass('is-valid');
                emailAddresses[teacherId] = newEmail;
            }
        });

        // --- Image Cropper Logic ---
        $('.photo-preview').click(function() {
            currentImageRow = $(this).closest('td');
            currentImageRow.find('.image-upload').click();
        });

        $('.image-upload').change(function() {
            const file = this.files[0];
            if (file) {
                if (!file.type.match('image.*')) {
                    toastr.error('Please select a valid image file.');
                    return;
                }
                const reader = new FileReader();
                reader.onload = function(e) {
                    $('#imageToCrop').attr('src', e.target.result);
                    cropModal.show();
                }
                reader.readAsDataURL(file);
            }
        });

        $('#cropModal').on('shown.bs.modal', function() {
            if (cropper) cropper.destroy();
            cropper = new Cropper(document.getElementById('imageToCrop'), {
                aspectRatio: 5 / 6,
                viewMode: 1,
                autoCropArea: 0.9,
                responsive: true
            });
        });

        $('#cropImageBtn').click(function() {
            if (!cropper) return;
            const canvas = cropper.getCroppedCanvas({ width: 500, height: 600, fillColor: '#fff' });
            if (!canvas) return;

            canvas.toBlob(function(blob) {
                const previewUrl = URL.createObjectURL(blob);
                currentImageRow.find('.photo-preview').attr('src', previewUrl);
                const reader = new FileReader();
                reader.onload = () => {
                    currentImageRow.find('.cropped-image-data').val(reader.result);
                    currentImageRow.closest('.teacher-row').addClass('changed');
                };
                reader.readAsDataURL(blob);
                cropModal.hide();
            }, 'image/jpeg', 0.9);
        });

        $('#cropModal').on('hidden.bs.modal', function() {
            if (cropper) { cropper.destroy(); cropper = null; }
            $('#imageToCrop').attr('src', '');
            if (currentImageRow) currentImageRow.find('.image-upload').val('');
        });

        // --- Update Actions ---
        $(document).on('click', '.update-btn', function() {
            const teacherId = $(this).data('teacher-id');
            const row = $(`tr[data-teacher-id="${teacherId}"]`);
            if (row.find('.is-invalid').length > 0) {
                toastr.error('Please fix validation errors before updating.');
                return;
            }
            updateTeacher(teacherId);
        });

        $('#updateAllBtn').click(function() {
            if ($('.is-invalid').length > 0) {
                toastr.error('Please fix all validation errors before updating.');
                return;
            }
            const changedRows = $('.teacher-row.changed');
            if (changedRows.length === 0) {
                toastr.info('No changes detected.');
                return;
            }
            
            let updateCount = 0, errorCount = 0;
            const progressToast = toastr.info(`Updating ${changedRows.length} teachers...`, 'Progress', { timeOut: 0 });
            
            changedRows.each((index, row) => {
                const teacherId = $(row).data('teacher-id');
                setTimeout(() => {
                    updateTeacher(teacherId, success => {
                        success ? updateCount++ : errorCount++;
                        if (updateCount + errorCount === changedRows.length) {
                            toastr.clear(progressToast);
                            if (errorCount === 0) {
                                toastr.success(`All ${updateCount} teachers updated successfully!`);
                            } else {
                                toastr.warning(`${updateCount} updated, ${errorCount} failed.`);
                            }
                        }
                    });
                }, index * 200); // Stagger requests to avoid overwhelming the server
            });
        });

        function updateTeacher(teacherId, callback) {
            const row = $(`tr[data-teacher-id="${teacherId}"]`);
            const formData = new FormData();
            formData.append('id', teacherId);
            let hasChanges = false;

            const fields = [
                { selector: '.name-input', name: 'name' },
                { selector: '.email-input', name: 'email' },
                { selector: '.phone-input', name: 'phone' },
                { selector: '.aadhaar-input', name: 'aadhaar_number' },
                { selector: '.salary-input', name: 'monthly_salary' },
                { selector: '.sections-select', name: 'assigned_sections' },
                { selector: '.position-input', name: 'position_in_school' },
                { selector: '.specialization-input', name: 'subject_specialization' },
                { selector: '.qualification-input', name: 'qualification' },
                { selector: '.joining-input', name: 'joining_date' },
                { selector: '.status-select', name: 'status' },
                { selector: '.village-input', name: 'village' },
                { selector: '.post-office-input', name: 'post_office' },
                { selector: '.police-station-input', name: 'police_station' },
                { selector: '.district-input', name: 'district' },
                { selector: '.pincode-input', name: 'pincode' }
            ];

            fields.forEach(field => {
                const element = row.find(field.selector);
                let currentValue = element.val();
                let originalValue = element.data('original-value');

                // Stringify multiple select arrays for comparison and sending
                if (element.is('select[multiple]')) {
                    currentValue = JSON.stringify(currentValue || []);
                }

                if (originalValue !== undefined && currentValue != originalValue) {
                    formData.append(field.name, currentValue);
                    hasChanges = true;
                }
            });

            const croppedImageData = row.find('.cropped-image-data').val();
            if (croppedImageData) {
                formData.append('cropped_image_data', croppedImageData);
                hasChanges = true;
            }
            formData.append('current_image', row.find('.current-image').val());

            if (!hasChanges) {
                row.removeClass('changed');
                if (callback) callback(true);
                return;
            }

            const btn = row.find('.update-btn');
            const originalBtnText = btn.html();
            btn.html('<i class="fas fa-spinner fa-spin"></i>').prop('disabled', true);

            $.ajax({
                url: '../../api/admin/put/teacher/process-bulk-edit-teacher.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        toastr.success(`Teacher ID ${teacherId} updated.`);
                        row.removeClass('changed');
                        
                        // Update original values
                        fields.forEach(field => {
                            const element = row.find(field.selector);
                            if (element.is('select[multiple]')) {
                                element.data('original-value', JSON.stringify(element.val() || []));
                            } else {
                                element.data('original-value', element.val());
                            }
                            element.removeClass('is-invalid is-valid');
                        });
                        
                        // Update image state
                        if (response.new_image) {
                            row.find('.current-image').val(response.new_image);
                            row.find('.cropped-image-data').val('');
                        }
                        if (callback) callback(true);
                    } else {
                        toastr.error(response.message || 'Update failed.');
                        if (callback) callback(false);
                    }
                },
                error: function(xhr) {
                    toastr.error('An error occurred. Check console.');
                    console.error(xhr.responseText);
                    if (callback) callback(false);
                },
                complete: function() {
                    btn.html(originalBtnText).prop('disabled', false);
                }
            });
        }
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>