<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
/**@var string $school_name */
echo "<title>Bulk Edit Teachers - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check admin permission
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    include_once("../../includes/permission-denied.php");
    exit();
}

// Get teacher IDs from query string
$teacher_ids = $_GET['teacher_ids'] ?? '';
if (!$teacher_ids) {
    die("<div class='container py-5'><div class='alert alert-danger'>Teacher IDs are required.</div></div>");
}

// Convert comma-separated string to array
$teacher_ids_array = explode(',', $teacher_ids);
$teacher_ids_array = array_map('trim', $teacher_ids_array);
$teacher_ids_array = array_filter($teacher_ids_array);

if (empty($teacher_ids_array)) {
    die("<div class='container py-5'><div class='alert alert-danger'>No valid teacher IDs provided.</div></div>");
}

// Fetch teachers data
$placeholders = implode(',', array_fill(0, count($teacher_ids_array), '?'));
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE id IN ($placeholders)");
$stmt->execute($teacher_ids_array);
$teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($teachers)) {
    die("<div class='container py-5'><div class='alert alert-danger'>No teachers found with the provided IDs.</div></div>");
}

// Fetch Sections for dropdown
$stmt_sec = $pdo->prepare("
    SELECT s.id, c.class_name, s.section_name 
    FROM sections s 
    JOIN classes c ON s.class_id = c.id 
    ORDER BY c.id ASC, s.section_name ASC
");
$stmt_sec->execute();
$all_sections = $stmt_sec->fetchAll(PDO::FETCH_ASSOC);

// Data for dropdowns
$statusValues = ['active', 'inactive'];
$genderValues = ['Male', 'Female', 'Other'];
$bloodGroupValues = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
$casteCategoryValues = ['General', 'OBC-A', 'OBC-B', 'SC', 'ST', 'Other'];
$religionValues = ['islam', 'hindu', 'christian', 'buddhist', 'jain', 'sikh', 'parsi', 'judaism', 'bahai', 'atheist', 'agnostic', 'other'];

// Field groups drive both the toggle panel and are used for reference by the table.
// key => [label, icon]
$fieldGroups = [
    'Personal & Identity' => [
        'teacher_image' => ['Photo', 'fa-image'],
        'email' => ['Email', 'fa-envelope'],
        'phone' => ['Phone', 'fa-phone'],
        'date_of_birth' => ['Date of Birth', 'fa-cake-candles'],
        'gender' => ['Gender', 'fa-venus-mars'],
        'blood_group' => ['Blood Group', 'fa-droplet'],
        'caste_category' => ['Caste Category', 'fa-people-group'],
        'religion' => ['Religion', 'fa-place-of-worship'],
        'nationality' => ['Nationality', 'fa-flag'],
        'aadhaar_number' => ['Aadhaar No.', 'fa-id-card'],
        'documents' => ['Documents', 'fa-folder-open'],
    ],
    'Family Details' => [
        'father_name' => ["Father's Name", 'fa-person'],
        'father_phone' => ["Father's Phone", 'fa-phone'],
        'mother_name' => ["Mother's Name", 'fa-person-dress'],
        'mother_phone' => ["Mother's Phone", 'fa-phone'],
    ],
    'Professional Details' => [
        'monthly_salary' => ['Salary', 'fa-money-bill'],
        'assigned_sections' => ['Sections', 'fa-chalkboard'],
        'position_in_school' => ['Position', 'fa-briefcase'],
        'subject_specialization' => ['Specialization', 'fa-book'],
        'qualification' => ['Qualification', 'fa-graduation-cap'],
        'joining_date' => ['Joining Date', 'fa-calendar-check'],
        'status' => ['Status', 'fa-toggle-on'],
    ],
    'Website & Access' => [
        'show_on_website' => ['Show on Website', 'fa-globe'],
        'display_priority' => ['Display Priority', 'fa-sort-numeric-down'],
        'share_phone_with_chatbot' => ['Share Phone with Chatbot', 'fa-robot'],
        'can_view_parent_contacts' => ['Can View Parent Contacts', 'fa-address-book'],
        'can_view_student_financial_report' => ["Can See Students' Financial Report", 'fa-file-invoice-dollar'],
    ],
    'Bank Details' => [
        'pan_number' => ['PAN No.', 'fa-id-badge'],
        'voter_epic_number' => ['Voter EPIC No.', 'fa-id-badge'],
        'bank_name' => ['Bank Name', 'fa-building-columns'],
        'bank_branch' => ['Branch Name', 'fa-building-columns'],
        'ifsc_code' => ['IFSC Code', 'fa-code'],
        'account_number' => ['Account No.', 'fa-hashtag'],
    ],
    'Address Details' => [
        'village' => ['Village/Town', 'fa-house'],
        'post_office' => ['Post Office', 'fa-envelope-open-text'],
        'police_station' => ['Police Station', 'fa-shield-halved'],
        'district' => ['District', 'fa-map'],
        'pincode' => ['Pincode', 'fa-map-pin'],
    ],
];

// Fields visible by default (kept minimal so the table isn't overwhelming on first load)
$defaultVisibleFields = ['teacher_image', 'email', 'phone', 'monthly_salary', 'assigned_sections', 'documents'];

// Fields that are always required when present (cannot be left blank / no blank option offered)
$requiredFields = ['email', 'phone', 'joining_date', 'date_of_birth', 'gender', 'status'];
?>

<style>
    /* Table specific styles */
    .editable-field { border: 1px solid #ddd; padding: 5px; min-width: 100px; }
    .editable-field:focus { border-color: #80bdff; outline: 0; box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25); }
    .teacher-row.changed { background-color: #fffde7; }
    .update-btn { display: none; }
    .teacher-row.changed .update-btn { display: inline-block; }
    .photo-preview { width: 50px; height: 60px; object-fit: cover; cursor: pointer; border: 1px solid #ccc; }
    table th, table td { text-align: center; vertical-align: middle; }
    .th-min-width { min-width: 170px; white-space: nowrap; }
    .td-min-width input.editable-field, .td-min-width select.editable-field { min-width: 150px; }
    table thead th { position: sticky; top: 0; z-index: 2; }

    /* --- Field visibility panel --- */
    .field-panel { background-color: #f8f9fa; border: 1px solid #e9ecef; border-radius: 10px; margin-bottom: 20px; overflow: hidden; }
    .field-panel-header { padding: 12px 16px; cursor: pointer; user-select: none; }
    .field-panel-header:hover { background-color: #eef1f4; }
    .field-panel-body { padding: 0 16px 16px 16px; }
    .field-group { background: #fff; border: 1px solid #e9ecef; border-radius: 8px; padding: 12px 14px; margin-bottom: 10px; }
    .field-group-title { font-size: 0.82rem; font-weight: 700; text-transform: uppercase; letter-spacing: .03em; color: #6c757d; margin-bottom: 8px; display: flex; align-items: center; justify-content: space-between; }
    .field-pill { display: inline-flex; align-items: center; gap: 6px; padding: 5px 12px; border-radius: 30px; border: 1px solid #dee2e6; background: #fff; cursor: pointer; font-size: 0.85rem; margin: 3px 4px 3px 0; transition: all .15s ease; }
    .field-pill input { display: none; }
    .field-pill i { font-size: 0.75rem; opacity: 0.7; }
    .field-pill:hover { border-color: #86b7fe; }
    .field-pill.active { background-color: #0d6efd; border-color: #0d6efd; color: #fff; }
    .field-pill.active i { opacity: 1; }
    .field-pill.locked { opacity: 0.65; cursor: not-allowed; }
    .group-select-all { font-size: 0.75rem; text-decoration: none; cursor: pointer; }

    /* --- Name column stays pinned so context is never lost while scrolling --- */
    .sticky-col { position: sticky; left: 0; z-index: 1; background: #fff; }
    thead .sticky-col { z-index: 3; }

    /* Highlight required column headers */
    .required-col::after { content: " *"; color: #dc3545; }

    /* Cropper modal styles */
    .modal-xl { max-width: 90%; }
    .img-container { position: relative; overflow: hidden; margin: 0 auto; height: 70vh; min-height: 400px; background-color: #f8f9fa; display: flex; align-items: center; justify-content: center; }
    #imageToCrop { max-width: 100%; max-height: 100%; }
</style>

<div class="container-fluid mt-4 mb-5">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0"><i class="fas fa-users-cog me-2"></i> Bulk Edit Teachers</h4>
        </div>

        <div class="card-body">
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i> You are editing <?= count($teachers) ?> teachers. Only changed fields will be updated.
            </div>

            <div class="d-flex flex-wrap align-items-center justify-content-between mb-3 gap-2">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="check-name">
                    <label class="form-check-label" for="check-name"><b>Enable Name Editing</b></label>
                </div>
                <div>
                    <button type="button" id="showAllFieldsBtn" class="btn btn-sm btn-outline-primary">
                        <i class="fas fa-eye me-1"></i> Show All
                    </button>
                    <button type="button" id="hideAllFieldsBtn" class="btn btn-sm btn-outline-secondary">
                        <i class="fas fa-eye-slash me-1"></i> Hide All
                    </button>
                </div>
            </div>

            <div class="field-panel">
                <div class="field-panel-header d-flex align-items-center justify-content-between" data-bs-toggle="collapse" data-bs-target="#fieldPanelBody">
                    <span><i class="fas fa-sliders me-2 text-primary"></i><b>Fields to Display &amp; Edit</b>
                        <span class="text-muted small ms-1">(choose what shows up as columns)</span>
                    </span>
                    <i class="fas fa-chevron-down text-muted"></i>
                </div>
                <div class="collapse show field-panel-body" id="fieldPanelBody">
                    <?php foreach ($fieldGroups as $groupName => $groupFields): ?>
                        <div class="field-group" data-group="<?= safe_htmlspecialchars($groupName) ?>">
                            <div class="field-group-title">
                                <span><?= safe_htmlspecialchars($groupName) ?></span>
                                <a class="group-select-all" data-action="select">Select all</a>
                            </div>
                            <div>
                                <?php foreach ($groupFields as $fieldKey => $fieldMeta):
                                    [$label, $icon] = $fieldMeta;
                                    $isDefault = in_array($fieldKey, $defaultVisibleFields);
                                    $isLocked = $fieldKey === 'teacher_image'; // photo column can't be hidden (upload trigger lives there)
                                    $isRequired = in_array($fieldKey, $requiredFields);
                                ?>
                                <label class="field-pill <?= $isDefault ? 'active' : '' ?> <?= $isLocked ? 'locked' : '' ?>" data-field="<?= $fieldKey ?>">
                                    <input type="checkbox" class="field-toggle" value="<?= $fieldKey ?>" <?= $isDefault ? 'checked' : '' ?> <?= $isLocked ? 'disabled' : '' ?>>
                                    <i class="fas <?= $icon ?>"></i>
                                    <?= safe_htmlspecialchars($label) ?><?= $isRequired ? ' <span class="text-danger">*</span>' : '' ?>
                                </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <div class="text-muted small"><span class="text-danger">*</span> Required field — cannot be saved blank once shown.</div>
                </div>
            </div>

            <?php
            // --- Config driving the generic cell renderer below ---
            $selectFieldOptions = [
                'gender' => $genderValues,
                'blood_group' => $bloodGroupValues,
                'caste_category' => $casteCategoryValues,
                'religion' => $religionValues,
                'status' => $statusValues,
            ];
            $dateFields = ['date_of_birth', 'joining_date'];
            $telFields = ['phone', 'father_phone', 'mother_phone'];
            $uppercaseTextFields = ['pan_number', 'voter_epic_number', 'ifsc_code'];
            // Yes/No columns are rendered as selects, not checkboxes: the generic JS collector
            // reads element.val(), which doesn't reflect a checkbox's checked state.
            $booleanFields = ['show_on_website', 'share_phone_with_chatbot', 'can_view_parent_contacts', 'can_view_student_financial_report'];
            // Yes/No columns whose schema default is 0, not 1. Used only for the "column missing
            // from the row" fallback below, so a permission is never shown as granted by accident.
            $booleanFieldsDefaultNo = ['can_view_student_financial_report'];
            $numberFields = ['display_priority'];
            $narrowColumns = ['teacher_image', 'gender', 'blood_group', 'caste_category', 'status', 'documents', 'show_on_website', 'share_phone_with_chatbot', 'can_view_parent_contacts', 'can_view_student_financial_report', 'display_priority'];
            ?>
            <div class="table-responsive">
                <table class="table table-bordered table-light table-hover" id="teachersTable">
                    <thead>
                        <tr>
                            <th class="bg-dark text-white th-min-width sticky-col">Name</th>
                            <?php foreach ($fieldGroups as $groupFields): foreach ($groupFields as $fieldKey => $fieldMeta):
                                [$label, ] = $fieldMeta;
                                $isRequired = in_array($fieldKey, $requiredFields);
                                $thClass = in_array($fieldKey, $narrowColumns) ? '' : 'th-min-width';
                            ?>
                            <th class="field-column bg-dark text-white <?= $thClass ?> <?= $isRequired ? 'required-col' : '' ?>" data-field="<?= $fieldKey ?>"><?= safe_htmlspecialchars($label) ?></th>
                            <?php endforeach; endforeach; ?>
                            <th class="bg-dark text-white">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($teachers as $teacher): ?>
                            <tr class="teacher-row" data-teacher-id="<?= safe_htmlspecialchars($teacher['id']) ?>">
                                <td class="td-min-width sticky-col">
                                    <input type="text" class="form-control form-control-sm editable-field name-input text-center" data-field="name" value="<?= safe_htmlspecialchars($teacher['name']) ?>" disabled>
                                    <small class="text-muted d-block mt-1">ID: <?= safe_htmlspecialchars($teacher['id']) ?></small>
                                </td>

                                <?php foreach ($fieldGroups as $groupFields): foreach ($groupFields as $fieldKey => $fieldMeta):
                                    $isRequired = in_array($fieldKey, $requiredFields);
                                    $tdClass = in_array($fieldKey, $narrowColumns) ? '' : 'td-min-width';
                                ?>
                                <td class="field-column <?= $tdClass ?>" data-field="<?= $fieldKey ?>">
                                    <?php if ($fieldKey === 'teacher_image'):
                                        $img_src = !empty($teacher['teacher_image']) ? $teacher['teacher_image'] : 'default_teacher_dp.jpg';
                                        if ($img_src === 'default_teacher_dp.jpg' && !file_exists("../../uploads/teachers/" . $img_src)) {
                                            $img_url = "../../assets/img/teacher-default-avatar.png";
                                        } else {
                                            $img_url = "../../uploads/teachers/" . safe_htmlspecialchars($img_src);
                                        }
                                    ?>
                                        <img src="<?= $img_url ?>" class="photo-preview rounded" title="Click to change photo">
                                        <input type="file" class="form-control mt-1 image-upload" style="display: none;" accept="image/*">
                                        <input type="hidden" class="current-image" value="<?= safe_htmlspecialchars($teacher['teacher_image'] ?? '') ?>">
                                        <input type="hidden" class="cropped-image-data">

                                    <?php elseif ($fieldKey === 'assigned_sections'):
                                        $assigned = json_decode($teacher['assigned_sections'] ?? '[]', true);
                                        if (!is_array($assigned)) $assigned = [];
                                    ?>
                                        <select class="form-select form-select-sm editable-field sections-select custom-multiselect" data-field="assigned_sections" multiple>
                                            <?php foreach ($all_sections as $sec): ?>
                                                <option value="<?= $sec['id'] ?>" <?= in_array($sec['id'], $assigned) ? 'selected' : '' ?>>
                                                    <?= safe_htmlspecialchars($sec['class_name']) ?> (<?= safe_htmlspecialchars($sec['section_name']) ?>)
                                                </option>
                                            <?php endforeach; ?>
                                        </select>

                                    <?php elseif ($fieldKey === 'documents'):
                                        $teacher_documents = json_decode($teacher['documents'] ?? '[]', true);
                                        if (!is_array($teacher_documents)) $teacher_documents = [];
                                        // Plain htmlspecialchars (not safe_htmlspecialchars) so that an '&' inside a
                                        // document URL is not un-escaped on its way into this JSON attribute.
                                        $documents_json = htmlspecialchars(json_encode($teacher_documents), ENT_QUOTES, 'UTF-8');
                                    ?>
                                        <button type="button" class="btn btn-sm btn-outline-primary manage-documents-btn text-nowrap" title="View, rename, remove or add documents">
                                            <i class="fas fa-folder-open me-1"></i> Manage
                                            <span class="badge bg-secondary ms-1 documents-count"><?= count($teacher_documents) ?></span>
                                        </button>
                                        <input type="hidden" class="documents-data" value="<?= $documents_json ?>">

                                    <?php elseif (isset($selectFieldOptions[$fieldKey])): ?>
                                        <select class="form-select form-select-sm editable-field" data-field="<?= $fieldKey ?>" <?= $isRequired ? 'required' : '' ?>>
                                            <?php if (!$isRequired): ?><option value="">Select</option><?php endif; ?>
                                            <?php foreach ($selectFieldOptions[$fieldKey] as $optionValue):
                                                $optionLabel = ($fieldKey === 'religion') ? ucwords($optionValue) : $optionValue;
                                                $selected = ((string)$teacher[$fieldKey] === (string)$optionValue) ? 'selected' : '';
                                            ?>
                                                <option value="<?= safe_htmlspecialchars($optionValue) ?>" <?= $selected ?>><?= ucwords(safe_htmlspecialchars($optionLabel)) ?></option>
                                            <?php endforeach; ?>
                                        </select>

                                    <?php elseif (in_array($fieldKey, $booleanFields)):
                                        // Columns are NOT NULL, so a missing value (teacher saved
                                        // before the column existed) falls back to the schema
                                        // default for that column - 1 for most, 0 for the
                                        // permissions listed in $booleanFieldsDefaultNo.
                                        $defaultIsYes = !in_array($fieldKey, $booleanFieldsDefaultNo);
                                        $isYes = isset($teacher[$fieldKey]) ? (string)$teacher[$fieldKey] === '1' : $defaultIsYes;
                                    ?>
                                        <select class="form-select form-select-sm editable-field" data-field="<?= $fieldKey ?>">
                                            <option value="1" <?= $isYes ? 'selected' : '' ?>>Yes</option>
                                            <option value="0" <?= $isYes ? '' : 'selected' ?>>No</option>
                                        </select>

                                    <?php elseif (in_array($fieldKey, $numberFields)): ?>
                                        <input type="number" min="1" step="1" class="form-control form-control-sm editable-field" data-field="<?= $fieldKey ?>" value="<?= safe_htmlspecialchars($teacher[$fieldKey] ?? '') ?>">

                                    <?php elseif (in_array($fieldKey, $dateFields)): ?>
                                        <input type="date" class="form-control form-control-sm editable-field" data-field="<?= $fieldKey ?>" value="<?= safe_htmlspecialchars($teacher[$fieldKey] ?? '') ?>" <?= $isRequired ? 'required' : '' ?>>

                                    <?php elseif (in_array($fieldKey, $telFields)): ?>
                                        <input type="tel" class="form-control form-control-sm editable-field" data-field="<?= $fieldKey ?>" value="<?= safe_htmlspecialchars($teacher[$fieldKey] ?? '') ?>" <?= $isRequired ? 'required' : '' ?>>

                                    <?php elseif ($fieldKey === 'email'): ?>
                                        <input type="email" class="form-control form-control-sm editable-field email-input" data-field="email" value="<?= safe_htmlspecialchars($teacher['email']) ?>" required>

                                    <?php elseif ($fieldKey === 'monthly_salary'): ?>
                                        <input type="text" class="form-control form-control-sm editable-field" data-field="monthly_salary" value="<?= safe_htmlspecialchars($teacher['monthly_salary'] ?? '') ?>" oninput="autoCorrectNumberInput(this)">

                                    <?php elseif (in_array($fieldKey, $uppercaseTextFields)): ?>
                                        <input type="text" class="form-control form-control-sm editable-field uppercase-input" data-field="<?= $fieldKey ?>" value="<?= safe_htmlspecialchars($teacher[$fieldKey] ?? '') ?>" style="text-transform:uppercase;">

                                    <?php else: ?>
                                        <input type="text" class="form-control form-control-sm editable-field" data-field="<?= $fieldKey ?>" value="<?= safe_htmlspecialchars($teacher[$fieldKey] ?? '') ?>">
                                    <?php endif; ?>
                                </td>
                                <?php endforeach; endforeach; ?>

                                <td>
                                    <button class="btn btn-sm btn-primary update-btn" data-teacher-id="<?= safe_htmlspecialchars($teacher['id']) ?>">
                                        <i class="fas fa-save"></i> Update
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="text-center mt-4">
                <button id="updateAllBtn" class="btn btn-primary px-4 py-2">
                    <i class="fas fa-save me-2"></i> Update All Changes
                </button>
                <a href="list-teachers.php" class="btn btn-secondary px-4 py-2 ms-2">
                    <i class="fas fa-times me-2"></i> Cancel
                </a>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="cropModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-crop me-2"></i> Crop Teacher Photo (5:6 Ratio)</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <div class="img-container">
                    <img id="imageToCrop" src="" class="img-fluid">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" id="cropImageBtn" class="btn btn-primary">Crop & Save</button>
            </div>
        </div>
    </div>
</div>

<!-- Documents manager: renames / removals / new uploads are saved straight away for one teacher -->
<div class="modal fade" id="documentsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-folder-open me-2"></i> Documents &mdash; <span id="documentsModalTeacherName"></span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="badge bg-secondary" id="documentsModalCounter">0 / <?= MAX_TEACHER_DOCUMENTS ?></span>
                    <button type="button" class="btn btn-sm btn-outline-primary" id="documentsModalAddBtn">
                        <i class="fas fa-plus me-1"></i> Add Document
                    </button>
                </div>

                <div id="documentsModalRows"></div>

                <div class="text-muted small" id="documentsModalEmptyMsg">No documents attached yet. Click "Add Document" to upload one.</div>
                <div class="text-danger small mt-2" id="documentsModalLimitMsg" style="display:none;">
                    <i class="fas fa-circle-exclamation me-1"></i> Maximum of <?= MAX_TEACHER_DOCUMENTS ?> documents reached. Remove one to add another.
                </div>
                <div class="alert alert-info py-2 small mt-3 mb-0">
                    <i class="fas fa-info-circle me-1"></i> Documents are saved on their own &mdash; "Save Documents" applies them immediately, separately from the row's other edits. Only JPG/PNG up to 2MB each.
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" id="documentsModalSaveBtn" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> Save Documents
                </button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        let cropper;
        let currentImageRow;
        const cropModal = new bootstrap.Modal(document.getElementById('cropModal'));
        let emailAddresses = {};

        // Toggle name editing
        $('#check-name').change(function() {
            $('.name-input').prop('disabled', !$(this).is(':checked'));
        });

        // --- Column visibility (pill toggles) ---
        // The pill is a <label> wrapping its checkbox, so the browser already forwards
        // clicks on the label to the checkbox natively — no manual click handler needed
        // (adding one caused a double-toggle where a single click canceled itself out).
        function applyColumnVisibility($toggle) {
            const field = $toggle.val();
            const isChecked = $toggle.is(':checked');
            $(`.field-column[data-field="${field}"]`).toggle(isChecked);
            $toggle.closest('.field-pill').toggleClass('active', isChecked);
        }

        $('.field-toggle').on('change', function() {
            applyColumnVisibility($(this));
        }).each(function() {
            applyColumnVisibility($(this));
        });

        $('#showAllFieldsBtn').click(function() {
            $('.field-toggle:not(:disabled)').prop('checked', true).trigger('change');
        });
        $('#hideAllFieldsBtn').click(function() {
            $('.field-toggle:not(:disabled)').prop('checked', false).trigger('change');
        });

        // Per-group "Select all" / "Deselect all" toggle link
        $('.group-select-all').click(function() {
            const $group = $(this).closest('.field-group');
            const $toggles = $group.find('.field-toggle:not(:disabled)');
            const shouldSelect = $(this).data('action') !== 'deselect';
            $toggles.prop('checked', shouldSelect).trigger('change');
            $(this).text(shouldSelect ? 'Deselect all' : 'Select all').data('action', shouldSelect ? 'deselect' : 'select');
        });

        // Track original values and highlight changes
        $('.teacher-row').each(function() {
            const row = $(this);
            row.find('.editable-field').each(function() {
                // Special handling for multi-select to track initial state accurately
                if ($(this).is('select[multiple]')) {
                    $(this).data('original-value', JSON.stringify($(this).val() || []));
                } else {
                    $(this).data('original-value', $(this).val());
                }
            });
            // Pre-fill email array for live validation
            const id = row.data('teacher-id').toString();
            const email = row.find('.email-input').val().trim();
            if(email) emailAddresses[id] = email;
        });

        $('.editable-field, .image-upload').on('input change', function() {
            $(this).closest('.teacher-row').addClass('changed');
        });

        // Auto-uppercase PAN / IFSC / Voter EPIC as the admin types
        $(document).on('input', '.uppercase-input', function() {
            this.value = this.value.toUpperCase();
        });

        // Email validation frontend
        $(document).on('input blur', '.email-input', function() {
            const $input = $(this);
            const $row = $input.closest('.teacher-row');
            const teacherId = $row.data('teacher-id').toString();
            const newEmail = $input.val().trim();

            $input.siblings('.invalid-feedback').remove();
            $input.removeClass('is-invalid is-valid');

            if (!newEmail) {
                $input.addClass('is-invalid');
                $input.after(`<div class="invalid-feedback d-block">Email is required</div>`);
                return;
            }

            let isDuplicate = false;
            for (let [id, email] of Object.entries(emailAddresses)) {
                if (id !== teacherId && email.toLowerCase() === newEmail.toLowerCase()) {
                    isDuplicate = true; break;
                }
            }

            if (isDuplicate) {
                $input.addClass('is-invalid');
                $input.after(`<div class="invalid-feedback d-block">Email is already used in this list</div>`);
            } else {
                $input.addClass('is-valid');
                emailAddresses[teacherId] = newEmail;
            }
        });

        // --- Image Cropper Logic ---
        $('.photo-preview').click(function() {
            currentImageRow = $(this).closest('td');
            currentImageRow.find('.image-upload').click();
        });

        $('.image-upload').change(function() {
            const file = this.files[0];
            if (file) {
                if (!file.type.match('image.*')) {
                    toastr.error('Please select a valid image file.');
                    return;
                }
                const reader = new FileReader();
                reader.onload = function(e) {
                    $('#imageToCrop').attr('src', e.target.result);
                    cropModal.show();
                }
                reader.readAsDataURL(file);
            }
        });

        $('#cropModal').on('shown.bs.modal', function() {
            if (cropper) cropper.destroy();
            cropper = new Cropper(document.getElementById('imageToCrop'), {
                aspectRatio: 5 / 6,
                viewMode: 1,
                autoCropArea: 0.9,
                responsive: true
            });
        });

        $('#cropImageBtn').click(function() {
            if (!cropper) return;
            const canvas = cropper.getCroppedCanvas({ width: 500, height: 600, fillColor: '#fff' });
            if (!canvas) return;

            canvas.toBlob(function(blob) {
                const previewUrl = URL.createObjectURL(blob);
                currentImageRow.find('.photo-preview').attr('src', previewUrl);
                const reader = new FileReader();
                reader.onload = () => {
                    currentImageRow.find('.cropped-image-data').val(reader.result);
                    currentImageRow.closest('.teacher-row').addClass('changed');
                };
                reader.readAsDataURL(blob);
                cropModal.hide();
            }, 'image/jpeg', 0.9);
        });

        $('#cropModal').on('hidden.bs.modal', function() {
            if (cropper) { cropper.destroy(); cropper = null; }
            $('#imageToCrop').attr('src', '');
            if (currentImageRow) currentImageRow.find('.image-upload').val('');
        });

        // --- Documents Manager ---
        // The teachers.documents column holds a JSON list of {document_name, document_url}.
        // The modal always renders the saved list, so renames/removals/new uploads are sent
        // as one complete list and saved on their own request (files are too heavy to stage).
        const MAX_DOCUMENTS = <?= MAX_TEACHER_DOCUMENTS ?>;
        const documentsModal = new bootstrap.Modal(document.getElementById('documentsModal'));
        let documentsRow = null;

        function getRowDocuments($row) {
            try {
                const parsed = JSON.parse($row.find('.documents-data').val() || '[]');
                return Array.isArray(parsed) ? parsed : [];
            } catch (e) {
                return [];
            }
        }

        function buildExistingDocRow(doc) {
            const $docRow = $(`
                <div class="document-row row g-2 align-items-center mb-2" data-doc-type="existing">
                    <div class="col-md-6">
                        <input type="text" class="form-control form-control-sm doc-name" placeholder="Document Name">
                    </div>
                    <div class="col-md-4">
                        <a class="btn btn-sm btn-outline-secondary w-100 doc-view-link" target="_blank" rel="noopener">
                            <i class="fas fa-eye me-1"></i> View
                        </a>
                    </div>
                    <div class="col-md-2 text-end">
                        <button type="button" class="btn btn-sm btn-outline-danger doc-remove-btn" title="Remove document">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `);

            // Set through the DOM rather than string interpolation so odd characters can't break markup
            $docRow.find('.doc-name').val(doc.document_name || '');
            $docRow.find('.doc-view-link').attr('href', doc.document_url || '#');
            $docRow.data('doc-url', doc.document_url || '');
            return $docRow;
        }

        function buildNewDocRow() {
            return $(`
                <div class="document-row row g-2 align-items-center mb-2" data-doc-type="new">
                    <div class="col-md-6">
                        <input type="text" class="form-control form-control-sm doc-name" placeholder="Document Name (e.g. PAN Card)">
                    </div>
                    <div class="col-md-4">
                        <input type="file" class="form-control form-control-sm doc-file" accept="image/jpeg,image/png">
                    </div>
                    <div class="col-md-2 text-end">
                        <button type="button" class="btn btn-sm btn-outline-danger doc-remove-btn" title="Remove document">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `);
        }

        function refreshDocumentsModalUI() {
            const total = $('#documentsModalRows .document-row').length;
            const limitReached = total >= MAX_DOCUMENTS;

            $('#documentsModalCounter').text(total + ' / ' + MAX_DOCUMENTS)
                .toggleClass('bg-secondary', !limitReached)
                .toggleClass('bg-danger', limitReached);
            $('#documentsModalEmptyMsg').toggle(total === 0);
            $('#documentsModalLimitMsg').toggle(limitReached);
            $('#documentsModalAddBtn').prop('disabled', limitReached);
        }

        function setRowDocuments($row, documents) {
            $row.find('.documents-data').val(JSON.stringify(documents));
            $row.find('.documents-count').text(documents.length);
        }

        $(document).on('click', '.manage-documents-btn', function() {
            documentsRow = $(this).closest('.teacher-row');

            $('#documentsModalTeacherName').text(documentsRow.find('.name-input').val() || '');

            const $rows = $('#documentsModalRows').empty();
            getRowDocuments(documentsRow).forEach(function(doc) {
                $rows.append(buildExistingDocRow(doc));
            });

            refreshDocumentsModalUI();
            documentsModal.show();
        });

        $('#documentsModalAddBtn').click(function() {
            if ($('#documentsModalRows .document-row').length >= MAX_DOCUMENTS) {
                toastr.error(`A teacher can have a maximum of ${MAX_DOCUMENTS} documents.`);
                return;
            }
            $('#documentsModalRows').append(buildNewDocRow());
            refreshDocumentsModalUI();
        });

        $(document).on('click', '#documentsModalRows .doc-remove-btn', function() {
            $(this).closest('.document-row').remove();
            refreshDocumentsModalUI();
        });

        $('#documentsModalSaveBtn').click(function() {
            if (!documentsRow) return;

            const teacherId = documentsRow.data('teacher-id');
            const keptDocuments = [];
            const newDocuments = [];
            let hasInvalidRow = false;

            $('#documentsModalRows .document-row').each(function() {
                const $docRow = $(this);
                const $nameInput = $docRow.find('.doc-name');
                const docName = ($nameInput.val() || '').trim();

                $nameInput.toggleClass('is-invalid', docName === '');
                if (docName === '') {
                    hasInvalidRow = true;
                }

                if ($docRow.data('doc-type') === 'existing') {
                    if (docName !== '') {
                        keptDocuments.push({
                            document_name: docName,
                            document_url: $docRow.data('doc-url')
                        });
                    }
                    return;
                }

                const $fileInput = $docRow.find('.doc-file');
                const pickedFile = $fileInput[0].files[0];

                $fileInput.toggleClass('is-invalid', !pickedFile);
                if (!pickedFile) {
                    hasInvalidRow = true;
                    return;
                }

                if (docName !== '') {
                    newDocuments.push({ name: docName, file: pickedFile });
                }
            });

            if (hasInvalidRow) {
                toastr.error('Every document needs a name, and every new document needs an image file.');
                return;
            }

            const formData = new FormData();
            formData.append('id', teacherId);
            formData.append('documents_existing', JSON.stringify(keptDocuments));
            newDocuments.forEach(function(doc) {
                formData.append('document_name[]', doc.name);
                formData.append('document_file[]', doc.file);
            });

            const $saveBtn = $(this);
            const originalBtnText = $saveBtn.html();
            const $targetRow = documentsRow;
            $saveBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-1"></i> Saving...');

            $.ajax({
                url: '../../api/admin/put/teacher/process-bulk-edit-teacher.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        setRowDocuments($targetRow, response.documents || []);
                        toastr.success(`Documents saved for Teacher ID ${teacherId}.`);
                        documentsModal.hide();
                    } else {
                        toastr.error(response.message || 'Failed to save documents.');
                    }
                },
                error: function(xhr) {
                    toastr.error('An error occurred while saving documents. Check console.');
                    console.error(xhr.responseText);
                },
                complete: function() {
                    $saveBtn.prop('disabled', false).html(originalBtnText);
                }
            });
        });

        // --- Update Actions ---
        $(document).on('click', '.update-btn', function() {
            const teacherId = $(this).data('teacher-id');
            const row = $(`tr[data-teacher-id="${teacherId}"]`);
            if (row.find('.is-invalid').length > 0) {
                toastr.error('Please fix validation errors before updating.');
                return;
            }
            updateTeacher(teacherId);
        });

        $('#updateAllBtn').click(function() {
            if ($('.is-invalid').length > 0) {
                toastr.error('Please fix all validation errors before updating.');
                return;
            }
            const changedRows = $('.teacher-row.changed');
            if (changedRows.length === 0) {
                toastr.info('No changes detected.');
                return;
            }
            
            let updateCount = 0, errorCount = 0;
            const progressToast = toastr.info(`Updating ${changedRows.length} teachers...`, 'Progress', { timeOut: 0 });
            
            changedRows.each((index, row) => {
                const teacherId = $(row).data('teacher-id');
                setTimeout(() => {
                    updateTeacher(teacherId, success => {
                        success ? updateCount++ : errorCount++;
                        if (updateCount + errorCount === changedRows.length) {
                            toastr.clear(progressToast);
                            if (errorCount === 0) {
                                toastr.success(`All ${updateCount} teachers updated successfully!`);
                            } else {
                                toastr.warning(`${updateCount} updated, ${errorCount} failed.`);
                            }
                        }
                    });
                }, index * 200); // Stagger requests to avoid overwhelming the server
            });
        });

        function updateTeacher(teacherId, callback) {
            const row = $(`tr[data-teacher-id="${teacherId}"]`);
            const formData = new FormData();
            formData.append('id', teacherId);
            let hasChanges = false;

            // Generic: any input/select carrying a data-field attribute is sent automatically
            // when its value differs from what it started with. Adding a new column to the
            // table (with a matching backend field_map entry) needs no JS changes here.
            row.find('.editable-field[data-field]').each(function() {
                const element = $(this);
                const fieldName = element.data('field');
                let currentValue = element.val();
                let originalValue = element.data('original-value');

                // Stringify multiple-select arrays for comparison and sending
                if (element.is('select[multiple]')) {
                    currentValue = JSON.stringify(currentValue || []);
                }

                if (originalValue !== undefined && currentValue != originalValue) {
                    formData.append(fieldName, currentValue);
                    hasChanges = true;
                }
            });

            const croppedImageData = row.find('.cropped-image-data').val();
            if (croppedImageData) {
                formData.append('cropped_image_data', croppedImageData);
                hasChanges = true;
            }
            formData.append('current_image', row.find('.current-image').val());

            if (!hasChanges) {
                row.removeClass('changed');
                if (callback) callback(true);
                return;
            }

            const btn = row.find('.update-btn');
            const originalBtnText = btn.html();
            btn.html('<i class="fas fa-spinner fa-spin"></i>').prop('disabled', true);

            $.ajax({
                url: '../../api/admin/put/teacher/process-bulk-edit-teacher.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        toastr.success(`Teacher ID ${teacherId} updated.`);
                        row.removeClass('changed');
                        
                        // Update original values so future edits compare against the saved state
                        row.find('.editable-field[data-field]').each(function() {
                            const element = $(this);
                            if (element.is('select[multiple]')) {
                                element.data('original-value', JSON.stringify(element.val() || []));
                            } else {
                                element.data('original-value', element.val());
                            }
                            element.removeClass('is-invalid is-valid');
                        });
                        
                        // Update image state
                        if (response.new_image) {
                            row.find('.current-image').val(response.new_image);
                            row.find('.cropped-image-data').val('');
                        }
                        if (callback) callback(true);
                    } else {
                        toastr.error(response.message || 'Update failed.');
                        if (callback) callback(false);
                    }
                },
                error: function(xhr) {
                    toastr.error('An error occurred. Check console.');
                    console.error(xhr.responseText);
                    if (callback) callback(false);
                },
                complete: function() {
                    btn.html(originalBtnText).prop('disabled', false);
                }
            });
        }
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>