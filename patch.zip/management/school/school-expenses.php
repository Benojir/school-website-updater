<?php
require_once __DIR__ . '/../../includes/auth-check.php';
require_once __DIR__ . '/../../includes/header-open.php';
echo '<title>School Expenses - ' . safe_htmlspecialchars($school_name) . '</title>';
$expenseStyleVersion = substr(hash_file('sha256', __DIR__ . '/../../assets/css/school-expenses.css'), 0, 16);
$expenseScriptVersion = substr(hash_file('sha256', __DIR__ . '/../../assets/js/school-expenses.js'), 0, 16);
echo '<link rel="stylesheet" href="' . BASE_URL . '/assets/css/school-expenses.css?v=' . $expenseStyleVersion . '">';
require_once __DIR__ . '/../../includes/header-close.php';
require_once __DIR__ . '/../../includes/dashboard-navbar.php';
if (!hasPermission(PERM_MANAGE_EXPENSES)) require __DIR__ . '/../../includes/permission-denied.php';
$_SESSION['school_expenses_csrf'] ??= bin2hex(random_bytes(32));
?>
<main class="container expenses-app py-3" id="schoolExpensesApp">
    <header class="expenses-heading">
        <div>
            <p class="expenses-eyebrow">School finance</p>
            <h1>School Expenses</h1>
            <p class="text-muted mb-0">Every expense, clearly recorded. See where your school spends.</p>
        </div>
        <div class="expenses-heading-actions">
            <button type="button" class="btn btn-outline-primary" id="manageExpenseCategories"><i class="fas fa-layer-group me-2" aria-hidden="true"></i>Categories</button>
            <button type="button" class="btn btn-primary" id="addExpense"><i class="fas fa-plus me-2" aria-hidden="true"></i>Add expense</button>
        </div>
    </header>
    <div id="expensesNotice" class="alert d-none" role="alert"></div>
    <section class="expenses-panel expenses-filter-panel" aria-labelledby="expensesFilterTitle">
        <div class="expenses-panel-heading"><h2 id="expensesFilterTitle">Choose a period</h2><span class="small text-muted">From and To dates are included</span></div>
        <div class="expenses-presets" role="group" aria-label="Quick date ranges">
            <button type="button" class="active" data-expense-period="month" aria-pressed="true">This month</button>
            <button type="button" data-expense-period="last-month" aria-pressed="false">Last month</button>
            <button type="button" data-expense-period="year" aria-pressed="false">This year</button>
            <button type="button" data-expense-period="all" aria-pressed="false">All time</button>
        </div>
        <form id="expenseFilters" class="expenses-filter-grid">
            <div><label for="expenseFrom" class="form-label">From date</label><input type="text" name="from" id="expenseFrom" class="form-control expense-date" placeholder="YYYY-MM-DD" autocomplete="off"></div>
            <div><label for="expenseTo" class="form-label">To date</label><input type="text" name="to" id="expenseTo" class="form-control expense-date" placeholder="YYYY-MM-DD" autocomplete="off"></div>
            <div><label for="expenseCategoryFilter" class="form-label">Category</label><select id="expenseCategoryFilter" name="category_id" class="form-select"><option value="0">All categories</option></select></div>
            <div class="expenses-search-field"><label for="expenseSearch" class="form-label">Search expenses</label><input type="search" id="expenseSearch" name="search" class="form-control" maxlength="150" placeholder="Category, paid to, note, date or amount"></div>
            <div class="expenses-filter-buttons"><button type="submit" class="btn btn-primary">Apply</button><button type="button" class="btn btn-outline-secondary" id="resetExpenseFilters">Reset</button></div>
        </form>
        <p class="expenses-period-label mb-0" id="expenseAppliedFilters" role="status">Loading this month's expenses…</p>
    </section>
    <section class="expenses-summary" aria-label="Expense totals for the applied filters" id="expenseSummary" aria-busy="true">
        <div class="expenses-stat expenses-stat-primary"><span><i class="fas fa-wallet me-2" aria-hidden="true"></i>Total spent</span><strong id="expenseTotal">—</strong><small>All matching entries, across every page</small></div>
        <div class="expenses-stat"><span><i class="fas fa-receipt me-2" aria-hidden="true"></i>Expense entries</span><strong id="expenseCount">—</strong><small id="expenseReceiptCount">—</small></div>
        <div class="expenses-stat"><span><i class="fas fa-arrow-trend-up me-2" aria-hidden="true"></i>Largest expense</span><strong id="expenseLargest">—</strong><small>Within the selected filters</small></div>
    </section>
    <section class="expenses-panel expenses-breakdown-panel" aria-labelledby="expenseBreakdownTitle">
        <div class="expenses-panel-heading"><div><h2 id="expenseBreakdownTitle">Spending by category</h2><p class="small text-muted mb-0">A clear picture of where the money went.</p></div><button type="button" class="btn btn-sm btn-outline-secondary d-none" id="toggleExpenseBreakdown">Show all</button></div>
        <div id="expenseBreakdown" class="expenses-breakdown" aria-live="polite"><p class="text-muted mb-0">Loading category totals…</p></div>
    </section>
    <section class="expenses-panel expenses-records" aria-labelledby="expenseRecordsTitle">
        <div class="expenses-panel-heading"><div><h2 id="expenseRecordsTitle">Expense history</h2><p id="expenseResultsSummary" class="small text-muted mb-0" role="status">Loading expenses…</p></div><button type="button" class="btn btn-outline-secondary" id="exportExpenses" disabled><i class="fas fa-download me-2" aria-hidden="true"></i>Download CSV</button></div>
        <div class="expenses-list-tools">
            <div><label for="expenseSort" class="small">Sort by</label><select id="expenseSort" class="form-select form-select-sm"><option value="date_desc">Newest expense date</option><option value="date_asc">Oldest expense date</option><option value="amount_desc">Highest amount</option><option value="amount_asc">Lowest amount</option></select></div>
            <div><label for="expensePageSize" class="small">Per page</label><select id="expensePageSize" class="form-select form-select-sm"><option value="10">10</option><option value="25" selected>25</option><option value="50">50</option><option value="100">100</option></select></div>
        </div>
        <div class="table-responsive expenses-table-wrap" id="expenseResults" aria-busy="true">
            <table class="table expenses-table mb-0">
                <caption class="visually-hidden">School expenses with dates, categories, amounts, payees, notes, bills and actions</caption>
                <thead><tr><th scope="col">Date</th><th scope="col">Category</th><th scope="col">Amount</th><th scope="col">Paid to / place</th><th scope="col">Note</th><th scope="col">Bill</th><th scope="col">Actions</th></tr></thead>
                <tbody id="expenseRows"><tr class="expenses-state-row"><td colspan="7" class="text-center py-5"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading expenses…</span></div></td></tr></tbody>
            </table>
        </div>
        <nav id="expensePagination" class="expenses-pagination" aria-label="Expense history pages"></nav>
    </section>
    <p class="small text-muted mt-3">Totals cover expenses recorded here. Optional bills and notes help you keep the full story of each expense.</p>
</main>

<div class="modal fade expenses-modal" id="expenseModal" tabindex="-1" aria-labelledby="expenseModalTitle" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable"><div class="modal-content">
        <div class="modal-header"><div><p class="expenses-eyebrow mb-1">Expense entry</p><h2 class="modal-title fs-5" id="expenseModalTitle">Add expense</h2></div><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
        <div class="modal-body">
            <form id="expenseForm">
                <div id="expenseFormError" class="alert alert-danger d-none" role="alert"></div>
                <input type="hidden" name="id" value="0"><input type="hidden" name="version" value="0">
                <div class="expenses-field-heading"><label for="expenseCategory" class="form-label">Category <span class="text-danger">*</span></label><button type="button" class="btn btn-link btn-sm p-0" id="showInlineExpenseCategory"><i class="fas fa-plus me-1" aria-hidden="true"></i>New category</button></div>
                <select name="category_id" id="expenseCategory" class="form-select mb-3" required><option value="">Choose a category</option></select>
                <div id="inlineExpenseCategory" class="expenses-inline-category mb-3 d-none">
                    <label for="inlineExpenseCategoryName" class="form-label">New category name</label>
                    <div class="input-group"><input type="text" id="inlineExpenseCategoryName" class="form-control" maxlength="120" placeholder="e.g. Electricity"><button type="button" class="btn btn-outline-primary" id="saveInlineExpenseCategory">Create</button></div>
                    <p id="inlineExpenseCategoryError" class="small text-danger mt-2 mb-0" role="alert"></p>
                </div>
                <div class="row g-3 mb-3">
                    <div class="col-sm-6"><label for="expenseAmount" class="form-label">Amount <span class="text-danger">*</span></label><div class="input-group"><span class="input-group-text"><?= safe_htmlspecialchars($currency_symbol) ?></span><input type="number" name="amount" id="expenseAmount" class="form-control" required min="0.01" max="999999999.99" step="0.01" placeholder="0.00" inputmode="decimal"></div></div>
                    <div class="col-sm-6"><label for="expenseDate" class="form-label">Expense date <span class="text-danger">*</span></label><input type="text" name="date" id="expenseDate" class="form-control expense-date" placeholder="YYYY-MM-DD" required autocomplete="off"></div>
                </div>
                <div class="mb-3"><label for="expensePayee" class="form-label">Paid to / place <span class="expenses-optional">Optional</span></label><input type="text" name="payee" id="expensePayee" class="form-control" maxlength="150" placeholder="Shop, vendor, person or place"></div>
                <div class="mb-3"><label for="expenseNote" class="form-label">Note <span class="expenses-optional">Optional</span></label><textarea name="note" id="expenseNote" class="form-control" rows="3" maxlength="2000" placeholder="What was bought or paid for? Why was it needed?"></textarea></div>
                <div class="expenses-upload">
                    <label for="expenseBillImage" class="form-label">Bill / receipt image <span class="expenses-optional">Optional</span></label>
                    <input type="file" id="expenseBillImage" name="bill_image" class="form-control" accept="image/jpeg,image/png,image/gif,image/webp">
                    <p class="form-text mb-0">JPG, PNG, GIF or WebP, up to 5 MB. Images are stored on ImgBB.</p>
                    <div id="expenseBillPreview" class="expenses-bill-preview d-none"></div>
                    <div class="form-check mt-3 d-none" id="expenseRemoveBillWrap"><input type="checkbox" class="form-check-input" name="remove_receipt" value="1" id="expenseRemoveBill"><label for="expenseRemoveBill" class="form-check-label">Remove the current bill from this expense</label></div>
                </div>
                <div class="expenses-form-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary" id="saveExpense"><i class="fas fa-check me-2" aria-hidden="true"></i>Save expense</button></div>
            </form>
        </div>
    </div></div>
</div>

<div class="modal fade expenses-modal" id="expenseCategoriesModal" tabindex="-1" aria-labelledby="expenseCategoriesTitle" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable"><div class="modal-content">
        <div class="modal-header"><div><h2 class="modal-title fs-5" id="expenseCategoriesTitle">Expense categories</h2><p class="small text-muted mb-0">Keep spending organised. Archived categories stay in past reports.</p></div><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
        <div class="modal-body">
            <div id="expenseCategoryError" class="alert alert-danger d-none" role="alert"></div>
            <form id="expenseCategoryForm" class="expenses-category-form"><input type="hidden" name="id" value="0"><input type="hidden" name="version" value="0"><div><label for="expenseCategoryName" class="form-label" id="expenseCategoryNameLabel">New category name</label><input type="text" name="name" id="expenseCategoryName" class="form-control" required maxlength="120" placeholder="e.g. Repairs & maintenance"></div><button type="submit" class="btn btn-primary" id="saveExpenseCategory">Create category</button><button type="button" class="btn btn-outline-secondary d-none" id="cancelExpenseCategoryEdit">Cancel edit</button></form>
            <label for="expenseCategorySearch" class="visually-hidden">Search categories</label><input type="search" id="expenseCategorySearch" class="form-control my-3" placeholder="Search categories…" maxlength="120">
            <div id="expenseCategoryList" class="expenses-category-list" aria-live="polite"></div>
        </div>
    </div></div>
</div>

<div class="modal fade expenses-modal" id="expenseDetailModal" tabindex="-1" aria-labelledby="expenseDetailTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable"><div class="modal-content">
        <div class="modal-header"><h2 class="modal-title fs-5" id="expenseDetailTitle">Expense details</h2><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
        <div class="modal-body" id="expenseDetailBody"></div>
    </div></div>
</div>
<script>
window.schoolExpensesConfig = <?= json_encode([
    'api' => BASE_URL . '/api/admin/school-expenses.php',
    'csrf' => $_SESSION['school_expenses_csrf'],
    'currency' => $currency_symbol,
    'today' => date('Y-m-d'),
    'monthStart' => date('Y-m-01')
], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?>;
</script>
<script defer src="<?= BASE_URL ?>/assets/js/school-expenses.js?v=<?= $expenseScriptVersion ?>"></script>
<?php require_once __DIR__ . '/../../includes/body-close.php'; ?>
