<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>School Expenses - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_EXPENSES)) {
    include_once("../../includes/permission-denied.php");
}
?>

<div class="container py-4">
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card shadow-lg">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="fas fa-cash-register me-2"></i> Add Expense</h4>
                </div>
                <div class="card-body">
                    <form id="expenseForm">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Expense Category: <span class="text-danger">*</span></label>
                            <select name="expense_category" class="form-control select2 category_selector" required>
                                <option value="" selected disabled>Select Category</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Amount: <span class="text-danger">*</span></label>
                            <input type="number" name="amount" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Date: <span class="text-danger">*</span></label>
                            <input type="date" name="date" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label for="billImage" class="form-label fw-bold">Bill/Receipt Image</label>
                            <input class="form-control" type="file" id="billImage" name="billImage"
                                accept="image/png,image/jpeg,image/gif,image/webp" required>
                            <div class="form-text">
                                Upload clear image of your bill or receipt. Max size: 5MB.
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Note:</label>
                            <textarea name="note" class="form-control" rows="3" placeholder="Where did you spend?, Why did you spend?"></textarea>
                        </div>

                        <div class="d-flex justify-content-center">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i> Save Expense
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card shadow-lg">
                <div class="card-header bg-primary text-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4 class="mb-0"><i class="fas fa-list me-2"></i> Expense Categories</h4>
                        <button id="addNewCategory" class="btn btn-light btn-sm">
                            <i class="fas fa-plus me-1"></i> Add New
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" class="form-control" placeholder="Search categories..." id="category_search_input">
                        </div>
                    </div>
                    <div class="table-responsive mb-3">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th class="text-start">Category Name</th>
                                    <th class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="expense_categories_table">
                                <!-- AJAX will load content here -->
                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-center">
                        <nav aria-label="Page navigation">
                            <ul class="pagination justify-content-center" id="paginationContainer">
                                <!-- AJAX will load pagination here -->
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0"><i class="fas fa-money-bill me-2"></i> Recent Spendings</h4>
        </div>
        <div class="card-body">
            <div class="mb-3">
                <form id="filter_form">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-search"></i></span>
                                <input type="text" class="form-control" placeholder="Search by category, amount, date..." name="recent_spends_search_input" id="recent_spends_search_input">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <select class="form-control select2 category_selector" name="category_filter">
                                <option value="" selected disabled>Select Category</option>
                                <!-- AJAX will load content here -->
                            </select>
                        </div>
                    </div>
                </form>
            </div>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th class="text-start">Category</th>
                            <th class="text-end">Amount</th>
                            <th class="text-end">Date</th>
                            <th class="text-end">Note</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="recent_spends_table">
                        <!-- AJAX will load content here -->
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-center">
                <nav aria-label="Page navigation">
                    <ul class="pagination justify-content-center" id="paginationContainer">
                        <!-- AJAX will load pagination here -->
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</div>

<?php include_once("../../includes/body-close.php"); ?>