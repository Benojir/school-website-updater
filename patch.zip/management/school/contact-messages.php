<?php
require_once __DIR__ . '/../../includes/auth-check.php';
if (!hasPermission(PERM_MANAGE_CONTACT_MESSAGES)) {
    http_response_code(403);
    exit('You do not have permission to manage contact messages.');
}
if (empty($_SESSION['admin_contact_csrf'])) {
    $_SESSION['admin_contact_csrf'] = bin2hex(random_bytes(32));
}
require_once __DIR__ . '/../../includes/header-open.php';
echo '<title>Contact Messages - ' . safe_htmlspecialchars($school_name) . '</title>';
require_once __DIR__ . '/../../includes/header-close.php';
require_once __DIR__ . '/../../includes/dashboard-navbar.php';
?>
<main class="container my-4" id="contactMessages" data-api="<?= BASE_URL ?>/api/admin/contact-messages.php" data-csrf="<?= safe_htmlspecialchars($_SESSION['admin_contact_csrf']) ?>">
    <h1 class="h3"><i class="fa-solid fa-envelope me-2"></i>Contact Messages</h1>
    <p class="text-muted">Messages from the website contact form. Times are shown in <?= safe_htmlspecialchars(date_default_timezone_get()) ?>.</p>
    <p id="contactCounts" aria-live="polite"></p>
    <div class="alert d-none" id="contactAdminFeedback" role="status" aria-live="polite"></div>
    <form id="contactFilters" class="row g-2 mb-3">
        <div class="col-md-7">
            <label class="visually-hidden" for="contactSearch">Search messages</label>
            <input class="form-control" id="contactSearch" name="search" maxlength="100" placeholder="Search name, phone, subject or message">
        </div>
        <div class="col-md-3">
            <label class="visually-hidden" for="contactStatus">Message status</label>
            <select class="form-select" id="contactStatus" name="status">
                <option value="">All messages</option>
                <option value="unread">Unread</option>
                <option value="read">Read</option>
            </select>
        </div>
        <div class="col-md-2"><button type="submit" class="btn btn-primary w-100">Search</button></div>
    </form>
    <div class="table-responsive">
        <table class="table table-bordered align-middle">
            <thead><tr><th>Visitor</th><th>Message</th><th>Received</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody id="contactMessageRows"><tr><td colspan="5">Loading messages...</td></tr></tbody>
        </table>
    </div>
    <nav class="d-flex gap-3 align-items-center" aria-label="Message pages">
        <button type="button" class="btn btn-outline-secondary" id="contactPrevious" disabled>Previous</button>
        <span id="contactPage" aria-live="polite"></span>
        <button type="button" class="btn btn-outline-secondary" id="contactNext" disabled>Next</button>
    </nav>
    <noscript><p>Please enable JavaScript to view and manage contact messages.</p></noscript>
</main>
<div class="modal fade" id="contactMessageModal" tabindex="-1" aria-labelledby="contactMessageTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content">
        <div class="modal-header">
            <h2 class="modal-title fs-5" id="contactMessageTitle">Contact Message</h2>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <dl class="row">
                <dt class="col-sm-3">Name</dt><dd class="col-sm-9 text-break" data-contact-detail="name"></dd>
                <dt class="col-sm-3">Phone</dt><dd class="col-sm-9 text-break" data-contact-detail="phone"></dd>
                <dt class="col-sm-3">Subject</dt><dd class="col-sm-9 text-break" data-contact-detail="subject"></dd>
                <dt class="col-sm-3">Received</dt><dd class="col-sm-9" data-contact-detail="created_at"></dd>
            </dl>
            <div class="border rounded p-3 text-break" style="white-space:pre-wrap" data-contact-detail="message"></div>
        </div>
        <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button></div>
    </div></div>
</div>
<script src="<?= BASE_URL ?>/assets/js/contact-messages-admin.js?v=<?= filemtime(__DIR__ . '/../../assets/js/contact-messages-admin.js') ?>" defer></script>
<?php require_once __DIR__ . '/../../includes/body-close.php'; ?>
