<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/header-open.php");
echo "<title>Manage Students - " . $school_name . "</title>";
require_once("../../includes/header-close.php");
require_once("../../includes/dashboard-navbar.php");

$stmt = $pdo->prepare("SELECT COUNT(*) FROM admission_enquiries");
$stmt->execute();
$count = $stmt->fetchColumn();
$totalAdmissionEnquiries = ($count > 99) ? '99+' : $count;

$stmt = $pdo->prepare("SELECT * FROM classes");
$stmt->execute();
$classes = $stmt->fetchAll();
?>

<style>
    .table-responsive {
        overflow-x: unset !important;
    }

    .filter-card {
        background-color: #f8f9fa;
        border-radius: 8px;
        padding: 15px;
        margin-bottom: 20px;
    }

    .badge-active {
        background-color: #198754;
    }

    .badge-left {
        background-color: #dc3545;
    }

    .badge-paid {
        background-color: #198754;
    }

    .badge-unpaid {
        background-color: #dc3545;
    }

    .badge-nofee {
        background-color: #6c757d;
    }

    .action-dropdown .dropdown-menu {
        min-width: 200px;
    }

    .pagination .page-item.active .page-link {
        background-color: #0d6efd;
        border-color: #0d6efd;
    }

    .status-badge {
        cursor: default;
    }

    .bulk-actions {
        background-color: #f8f9fa;
        padding: 15px;
        margin-bottom: 20px;
        border-radius: 8px;
        display: none;
    }

    .bulk-checkbox {
        width: 20px;
    }

    .select-all-checkbox {
        margin-right: 10px;
    }

    .bulk-action-buttons {
        margin-right: 10px;
        margin-bottom: 5px;
    }

    .selected-count {
        font-weight: bold;
        margin-right: 15px;
    }
</style>

<div class="container mt-4">
    <!-- Action cards container -->
    <div class="container p-0">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="mb-0"><i class="fas fa-users me-2"></i>Student Management</h1>
            <a href="manage-admission-enquiries.php">
                <button type="button" class="btn btn-primary position-relative">
                    Admission Enquiry
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        <?= $totalAdmissionEnquiries; ?>
                    </span>
                </button>
            </a>
        </div>

        <!-- Filter Card -->
        <div class="card shadow-sm mb-4 p-0">
            <div class="card-header bg-primary text-white">
                <i class="fas fa-filter me-2"></i>Filter Students
            </div>
            <div class="card-body">
                <form id="filterForm" class="row g-3">
                    <!-- Search Field -->
                    <div class="col-md-3">
                        <label for="search" class="form-label">Search</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" name="search" id="search" class="form-control" placeholder="ID or Name">
                        </div>
                    </div>

                    <!-- Class Filter -->
                    <div class="col-md-2">
                        <label for="class" class="form-label">Class</label>
                        <select name="class" id="classFilter" class="form-select">
                            <option value="">All Classes</option>
                            <!-- Will be populated by JavaScript -->
                        </select>
                    </div>

                    <!-- Section Filter -->
                    <div class="col-md-2">
                        <label for="section" class="form-label">Section</label>
                        <select name="section" id="sectionFilter" class="form-select">
                            <option value="">All Sections</option>
                            <!-- Will be populated by JavaScript -->
                        </select>
                    </div>

                    <!-- Gender Filter -->
                    <div class="col-md-2">
                        <label for="gender" class="form-label">Gender</label>
                        <select name="gender" id="genderFilter" class="form-select">
                            <option value="">All Genders</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <!-- Status Filter -->
                    <div class="col-md-2">
                        <label for="status" class="form-label">Status</label>
                        <select name="status" id="statusFilter" class="form-select">
                            <option value="Active">Active</option>
                            <option value="">All Statuses</option>
                            <option value="Left">Left</option>
                            <option value="Alumni">Alumni</option>
                        </select>
                    </div>

                    <!-- Fee Status Filter -->
                    <div class="col-md-2">
                        <label for="fee_status" class="form-label">Fee Status</label>
                        <select name="fee_status" id="feeStatusFilter" class="form-select">
                            <option value="">All Fee Statuses</option>
                            <option value="paid">Has Paid Fees</option>
                            <option value="unpaid">Has Unpaid Fees</option>
                            <option value="fully_paid">Fully Paid</option>
                        </select>
                    </div>

                    <!-- Hosteler Filter -->
                    <div class="col-md-2">
                        <label for="hosteler" class="form-label">Hosteler</label>
                        <select name="hosteler" id="hostelerFilter" class="form-select">
                            <option value="">All</option>
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                    </div>

                    <!-- Car Route Filter -->
                    <div class="col-md-2">
                        <label for="car_route" class="form-label">Uses School Car</label>
                        <select name="car_route" id="carRouteFilter" class="form-select">
                            <option value="">All</option>
                            <option value="has_route">Yes</option>
                            <option value="no_route">No</option>
                        </select>
                    </div>

                    <!-- Action Buttons -->
                    <div class="col-md-1 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary me-2" title="Apply Filters">
                            <i class="fas fa-filter"></i>
                        </button>
                        <button type="button" id="resetFilters" class="btn btn-outline-secondary" title="Reset Filters">
                            <i class="fas fa-sync"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Bulk Actions Panel -->
        <div class="bulk-actions card shadow-sm mb-4" id="bulkActionsPanel">
            <div class="card-body">
                <div class="d-flex flex-wrap align-items-center">
                    <span class="selected-count me-3" id="selectedCount">0 selected</span>

                    <!-- Bulk Students Permissions Button -->
                    <button class="btn btn-warning bulk-action-buttons" id="bulkEditPermissions">
                        <i class="fas fa-key me-1"></i> Edit Permissions
                    </button>

                    <!-- Download ID Cards Button -->
                    <button class="btn btn-primary bulk-action-buttons" id="downloadIdCards">
                        <i class="fas fa-id-card me-1"></i> Download ID Cards
                    </button>

                    <!-- Download Admit Cards Button -->
                    <button class="btn btn-info bulk-action-buttons" id="downloadAdmitCards">
                        <i class="fas fa-file-alt me-1"></i> Download Admit Cards
                    </button>

                    <!-- Add Bulk Fees Button -->
                    <button class="btn btn-primary bulk-action-buttons" id="manageFeesAndPaymentsBtn">
                        <i class="fa-solid fa-money-bill-1-wave"></i> Manage Fees
                    </button>

                    <!-- Add Bulk Results Button -->
                    <button class="btn btn-warning bulk-action-buttons" id="addBulkResults">
                        <i class="fas fa-plus-circle me-1"></i> Students Mark Entry
                    </button>

                    <!-- Download Marksheet Button with Exam Selector -->
                    <div class="dropdown d-inline-block me-2">
                        <button class="btn btn-success dropdown-toggle bulk-action-buttons" type="button" id="downloadMarksheetDropdown" data-bs-toggle="dropdown">
                            <i class="fas fa-file-pdf me-1"></i> Download Marksheet
                        </button>
                        <ul class="dropdown-menu" id="examDropdown">
                            <!-- Will be populated by JavaScript -->
                        </ul>
                    </div>

                    <!-- Promote bulk students Button -->
                    <button class="btn btn-warning bulk-action-buttons" id="bulkPromoteStudents">
                        <i class="fa-solid fa-user-graduate"></i> Promote Students
                    </button>

                    <!-- Additional/Bulk Edit Students -->
                    <button class="btn btn-info bulk-action-buttons" id="bulkEditStudents">
                        <i class="fa-solid fa-user-pen"></i> Edit Students
                    </button>

                    <!-- Bulk Students Admission Fee Manage -->
                    <button class="btn btn-warning bulk-action-buttons" id="bulkAdmissionFeeBtn" data-bs-toggle="modal" data-bs-target="#admissionFeeModal">
                        <i class="fa-solid fa-money-bills"></i> Admission Fees
                    </button>

                    <!-- Bulk Students Send Notifications -->
                    <button class="btn btn-info bulk-action-buttons" id="sendNotificationsBtn" data-bs-toggle="modal" data-bs-target="#sendNotificationsModal">
                        <i class="fa-solid fa-bell me-1"></i> Send Notifications
                    </button>

                    <!-- Bulk Students Manage Wallet -->
                    <button class="btn btn-success bulk-action-buttons" id="manageWalletBtn" data-bs-toggle="modal" data-bs-target="#manageWalletModal">
                        <i class="fa-solid fa-wallet me-1"></i> Manage Wallet
                    </button>

                    <!-- Bulk Students Export Data Button -->
                    <button class="btn btn-primary bulk-action-buttons" id="exportBulkStudentData">
                        <i class="fa-solid fa-file-arrow-down me-1"></i> Download Students' Data
                    </button>

                    <!-- Clear Selection Button -->
                    <button class="btn btn-outline-secondary" id="clearSelection">
                        <i class="fas fa-times me-1"></i> Clear Selection
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Student Table Container With Counter-->
    <div class="table-data-container shadow-lg rounded" style="overflow-x: unset !important; border: 1px solid #e0e0e0;">
        <!-- Results Summary -->
        <div class="d-flex justify-content-between align-items-center p-3 results-summary">
            <!-- Will be updated via JavaScript -->
        </div>

        <!-- Student Table -->
        <div class="table-responsive">
            <table class="table table-striped table-hover table-bordered text-center align-middle">
                <thead class="table-dark">
                    <tr>
                        <th width="40">
                            <input type="checkbox" class="form-check-input select-all-checkbox" id="selectAll">
                        </th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Father's Name</th>
                        <th>Address</th>
                        <th>Class</th>
                        <th>Section</th>
                        <th>Roll No</th>
                        <th>Hosteler</th>
                        <th>Car Route</th>
                        <th>Status</th>
                        <th>Fee Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="studentsTableBody">
                    <!-- Students will be loaded here via AJAX -->
                    <tr>
                        <td colspan="13" class="text-center py-4">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>


    <!-- Pagination -->
    <nav aria-label="Page navigation" class="mt-4">
        <ul class="pagination justify-content-center" id="paginationContainer">
            <!-- Will be updated via JavaScript -->
        </ul>
    </nav>
</div>

<!-- Bulk Student Payments and Fees Modal -->
<div class="modal fade" id="bulkFeeModal" data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="bulkFeeModalLabel" aria-hidden="true" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Students' Fees & Payments Management</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <ul class="nav nav-tabs nav-fill mb-3" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="tab1-tab" data-bs-toggle="tab" data-bs-target="#tab1" type="button" role="tab">Payments Entry</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="tab2-tab" data-bs-toggle="tab" data-bs-target="#tab2" type="button" role="tab">Fees Entry</button>
                    </li>
                </ul>

                <div class="tab-content mt-4">
                    <div class="tab-pane fade show active" id="tab1" role="tabpanel">
                        <div class="payment-entry-info-alert-container"></div>
                        <form id="paymentsEntryForm" autocomplete="off">
                            <div class="mb-3">
                                <label for="amount" class="form-label">Amount:</label>
                                <input type="number" id="amount" name="amount" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="payment_date" class="form-label">Payment Date:</label>
                                <input type="date" id="payment_date" name="payment_date" class="form-control" required>
                            </div>
                            <div class="mt-3 mb-2 justify-content-right">
                                <button type="submit" class="btn btn-primary">Save Payments Entry</button>
                            </div>
                        </form>
                    </div>
                    <div class="tab-pane fade" id="tab2" role="tabpanel">
                        <form id="feesEntryForm" autocomplete="off">
                            <div class="mb-3">
                                <label for="month_year" class="form-label">Month:</label>
                                <select name="month_year" id="month_year" class="form-control exclude-from-load feeMonthSelect" required></select>
                            </div>
                            <div class="mb-3">
                                <label for="discount" class="form-label">Discount:</label>
                                <input type="number" id="discount" name="discount" class="form-control">
                            </div>
                            <div class="mt-3 mb-2 justify-content-right">
                                <button type="submit" class="btn btn-primary">Save Fees Entry</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Permission Modal -->
<div class="modal fade" id="permissionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="permissionForm">
                <div class="modal-header">
                    <h5 class="modal-title">Manage Permissions for <span id="permStudentName"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="student_ids" id="permStudentIds">

                    <!-- Add this alert for bulk operations -->
                    <div class="alert alert-info mb-3" id="bulkPermissionAlert" style="display: none;">
                        <i class="fas fa-users me-2"></i> You are editing permissions for <strong><span id="selectedStudentsCount">0</span></strong> selected students.
                    </div>

                    <div class="alert alert-info mb-3">
                        <strong>Current Fee Status:</strong> <span id="currentFeeStatus">N/A for bulk operations</span>
                    </div>

                    <!-- Admit Card Section -->
                    <div class="card mb-3">
                        <div class="card-header bg-primary text-white">
                            Admit Card Permissions
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="overrideAdmitCheck" name="override_admit_check">
                                    <label class="form-check-label" for="overrideAdmitCheck">Override Fee Requirements for Admit Card</label>
                                </div>
                            </div>

                            <div class="mb-3" id="admitCardOverrideContainer" style="display:none;">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="allowAdmitCard" name="allow_admit_card">
                                    <label class="form-check-label" for="allowAdmitCard">Allow Admit Card Download</label>
                                </div>
                                <small class="text-muted">This will override the default fee-based permission</small>
                            </div>
                        </div>
                    </div>

                    <!-- Marksheet Section -->
                    <div class="card mb-3">
                        <div class="card-header bg-success text-white">
                            Marksheet Permissions
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="overrideMarksheetCheck" name="override_marksheet_check">
                                    <label class="form-check-label" for="overrideMarksheetCheck">Override Requirements for Marksheet</label>
                                </div>
                            </div>

                            <div class="mb-3" id="marksheetOverrideContainer" style="display:none;">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="allowMarksheet" name="allow_marksheet">
                                    <label class="form-check-label" for="allowMarksheet">Allow Marksheet Download</label>
                                </div>
                                <small class="text-muted">This will override any default restrictions</small>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="permissionNotes" class="form-label">Notes:</label>
                        <textarea class="form-control" id="permissionNotes" name="notes" rows="3" placeholder="Reason for override"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Permissions</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bulk admission fees manage modal -->
<div class="modal fade" id="admissionFeeModal" tabindex="-1" aria-labelledby="admissionFeeModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" id="admissionFeeForm">
                <div class="modal-header bg-primary text-white">
                    <h1 class="modal-title fs-5" id="admissionFeeModalLabel">Manage Admission Fees</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="admission_fee" class="form-label">Admission Fee: </label>
                        <input class="form-control" type="number" name="admission_fee" id="admission_fee" required>
                    </div>
                    <div class="mb-3">
                        <label for="admission_date" class="form-label">Admission Date: </label>
                        <input class="form-control" type="date" name="admission_date" id="admission_date" required>
                    </div>
                    <div class="mb-3">
                        <label for="admission_class" class="form-label">Admission Class: </label>
                        <select class="form-select exclude-from-load" name="admission_class" id="admission_class" required>
                            <option selected value="">-- Select Admission Class --</option>
                            <?php
                            foreach ($classes as $class) {
                                echo '<option value="' . $class['id'] . '">' . $class['class_name'] . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="admission_unpaid_amount" class="form-label">Unpaid Amount: </label>
                        <input class="form-control" type="number" name="admission_unpaid_amount" id="admission_unpaid_amount" required>
                    </div>
                    <div class="mb-3">
                        <label for="payment_status" class="form-label">Status: </label>
                        <select class="form-select exclude-from-load" name="payment_status" id="payment_status" required>
                            <option selected value="">-- Select Payment Status --</option>
                            <option value="unpaid">Unpaid</option>
                            <option value="paid">Paid</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bulk notification send modal -->
<div class="modal fade" id="sendNotificationsModal" tabindex="-1" aria-labelledby="notificationModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" id="sendNotificationForm">
                <div class="modal-header bg-primary text-white">
                    <h1 class="modal-title fs-5" id="notificationModalLabel">Send Notification</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="notification_title" class="form-label">Notification Title: </label>
                        <input class="form-control" type="text" name="notification_title" id="notification_title" required>
                    </div>
                    <div class="mb-3">
                        <label for="notification_message" class="form-label">Notification Message: </label>
                        <input class="form-control" type="text" name="notification_message" id="notification_message" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bulk student manage wallet -->
<div class="modal fade" id="manageWalletModal" tabindex="-1" aria-labelledby="manageWalletModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" id="manageWalletForm">
                <div class="modal-header bg-primary text-white">
                    <h1 class="modal-title fs-5" id="manageWalletModalLabel">Manage Wallet</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="wallet_action" class="form-label">Action: </label>
                        <select class="form-select exclude-from-load" name="wallet_action" id="wallet_action" required>
                            <option selected value="">-- Select Action --</option>
                            <option value="add_funds">Add Funds</option>
                            <option value="deduct_funds">Deduct Funds</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="wallet_amount" class="form-label">Amount: </label>
                        <input class="form-control" type="number" name="wallet_amount" id="wallet_amount" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Manage unpaid fees modal for single student -->
<div class="modal fade" id="manageUnpaidFeesModal" tabindex="-1" aria-labelledby="manageUnpaidFeesModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h1 class="modal-title fs-5" id="manageUnpaidFeesModalLabel">All Unpaid Fees</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="manageUnpaidFeesModalBody">
                <!-- Data will be loaded via ajax -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
    let globalSelectedStudents = [];

    // Helper function to get selected student IDs
    function getSelectedStudentIds() {
        // Return the global array instead of just visible checkboxes
        console.log(globalSelectedStudents);
        return globalSelectedStudents.map(id => id);
    }

    // IMPROVED: Helper function to get selected class IDs (you'll need to modify this)
    function getSelectedClassIds() {
        // Since we need class IDs, we should store them in globalSelectedStudents as objects
        // For now, let's get class IDs from currently visible selections
        const selectedIds = [];
        $('.student-checkbox:checked').each(function() {
            selectedIds.push($(this).data('class-id'));
        });
        return selectedIds;
    }

    // Function to manage unpaid fees
    function fetchAllUnpaidFees(student_name, student_id) {
        $.ajax({
            url: '../ajax/fetch-all-unpaid-fees.php',
            type: 'GET', // Use GET for fetching data
            data: {
                student_id: student_id
            },
            dataType: 'json',
            beforeSend: function() {
                // Show loading indicator
                Swal.fire({
                    title: 'Fetching Unpaid Fees...',
                    html: '<div class="spinner-border text-primary" role="status"></div>',
                    showConfirmButton: false,
                    allowOutsideClick: false
                });
            },
            success: function(response) {
                if (response.success) {
                    // Show success message
                    toastr.success(response.message);
                    // Populate the modal body with the unpaid fees data
                    let html = response.html;
                    $('#manageUnpaidFeesModalBody').html(html);
                    $('#manageUnpaidFeesModal').modal('show');
                    $('#manageUnpaidFeesModalLabel').html('Unpaid Fees for <b>' + student_name + '</b>');
                } else {
                    toastr.error(response.message);
                }
            },
            error: function(xhr) {
                toastr.error('Error fetching unpaid fees');
                console.error(xhr.responseText);
            },
            complete: function() {
                // Hide loading indicator
                Swal.close();
            }
        });
    }

    // Function to delete unpaid fee entry
    function deleteUnpaidFeeEntry(entryId, btn) {
        Swal.fire({
            title: 'Are you sure?',
            text: "This action cannot be undone!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!'
        }).then((result) => {
            if (result.isConfirmed) {
                // Proceed with deletion
                $.ajax({
                    url: '../action/delete-unpaid-fee-entry.php',
                    type: 'POST',
                    data: {
                        entry_id: entryId
                    },
                    dataType: 'json',
                    beforeSend: function() {
                        // Show loading indicator
                        Swal.fire({
                            title: 'Deleting Fee Entry...',
                            html: '<div class="spinner-border text-primary" role="status"></div>',
                            showConfirmButton: false,
                            allowOutsideClick: false
                        });
                    },
                    success: function(response) {
                        if (response.success) {
                            // Show success message
                            toastr.success(response.message);
                            // Refresh the unpaid fees modal content
                            $(btn).closest('.alert').remove();
                            if ($('#manageUnpaidFeesModalBody').children().length === 0) {
                                $('#manageUnpaidFeesModal').modal('hide');
                                toastr.info('No more unpaid fees for this student.');
                            }
                        } else {
                            toastr.error(response.message);
                        }
                    },
                    error: function(xhr) {
                        toastr.error('Error deleting fee entry');
                        console.error(xhr.responseText);
                    },
                    complete: function() {
                        // Hide loading indicator
                        Swal.close();
                    }
                });
            }
        });
    }

    // Function to manage bulk permissions
    function openBulkPermissionModal(studentIds) {
        // Set the student IDs in the form
        $('#permStudentIds').val(studentIds.join(','));

        // Update the modal title and show the bulk info alert
        $('#permStudentName').text("Multiple Students (" + studentIds.length + ")");
        $('#bulkPermissionAlert').show();
        $('#selectedStudentsCount').text(studentIds.length);

        // For bulk operations, we don't show individual fee status
        $('#currentFeeStatus').html('<em>Fee status varies across selected students</em>');

        // Reset all permission checkboxes to default state
        $('#overrideAdmitCheck, #allowAdmitCard, #overrideMarksheetCheck, #allowMarksheet').prop('checked', false);
        $('#permissionNotes').val('');

        // Hide the override containers initially
        $('#admitCardOverrideContainer, #marksheetOverrideContainer').hide();

        // Set up event listeners for the checkboxes
        $('#overrideAdmitCheck').off('change').on('change', function() {
            toggleOverrideOptions('admit', $(this).is(':checked'));
        });

        $('#overrideMarksheetCheck').off('change').on('change', function() {
            toggleOverrideOptions('marksheet', $(this).is(':checked'));
        });

        // Show the modal
        const permModal = new bootstrap.Modal(document.getElementById('permissionModal'));
        $('.modal-backdrop').remove();
        permModal.show();

        // Add special handling for bulk operations
        $('#permissionForm').off('submit').on('submit', function(e) {
            e.preventDefault();
            saveBulkPermissions(studentIds);
        });
    }

    function saveBulkPermissions(studentIds) {
        const $form = $('#permissionForm');
        const $btn = $form.find('[type="submit"]');
        const btnText = $btn.html();

        // Show loading state
        $btn.prop('disabled', true).html(
            '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...'
        );

        // Get form data
        const formData = $form.serialize();

        $.ajax({
            url: '../action/update-student-permissions.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Show summary success message
                    toastr.success(response.message);

                    // Show detailed results in a modal if available
                    if (response.results && response.results.length > 0) {
                        let successCount = 0;
                        let skippedCount = 0;
                        let html = '<div class="bulk-results-container">';

                        response.results.forEach(result => {
                            if (result.success) {
                                successCount++;
                                html += `
                                <div class="alert alert-success mb-2">
                                    <strong>${result.student_id}</strong>: ${result.message}
                                </div>
                            `;
                            } else {
                                skippedCount++;
                                html += `
                                <div class="alert alert-warning mb-2">
                                    <strong>${result.student_id}</strong>: ${result.message}
                                </div>
                            `;
                            }
                        });

                        html += '</div>';

                        // Show detailed results in a modal
                        Swal.fire({
                            title: 'Bulk Permissions Results',
                            html: `
                            <div class="text-left">
                                <p><strong>Summary:</strong> ${response.message}</p>
                                <p>Successfully processed: ${successCount}</p>
                                <p>Skipped: ${skippedCount}</p>
                                <div class="mt-3" style="max-height: 300px; overflow-y: auto;">
                                    ${html}
                                </div>
                            </div>
                        `,
                            icon: 'info',
                            confirmButtonText: 'OK',
                            width: '800px'
                        });
                    }

                    // Close the modal
                    $('#permissionModal').modal('hide');
                    $('.modal-backdrop').hide();
                } else {
                    toastr.error(response.message);
                }
            },
            error: function(xhr) {
                try {
                    const errorResponse = JSON.parse(xhr.responseText);
                    let errorMsg = 'Error: ' + (errorResponse.message || 'Operation failed');

                    if (errorResponse.processed_up_to) {
                        errorMsg += ` (Last processed student ID: ${errorResponse.processed_up_to})`;
                    }

                    toastr.error(errorMsg);
                } catch (e) {
                    toastr.error('Error: ' + xhr.status + " " + xhr.statusText);
                    console.error(e);
                }
            },
            complete: function() {
                $btn.prop('disabled', false).html(btnText);
            }
        });
    }

    $(document).ready(function() {

        // Initialize variables
        let currentPage = 1;
        let totalPages = 1;
        let totalStudents = 0;
        let filterParams = {};

        // Initialize month dropdown
        // let monthSelect = $('.feeMonthSelect');
        const now = new Date();
        const totalMonths = 24;

        for (let i = totalMonths; i >= -totalMonths; i--) {
            const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
            const month = date.toLocaleString('default', {
                month: 'long'
            });
            const year = date.getFullYear();
            const value = `${month} ${year}`;

            $('.feeMonthSelect').each(function() {
                const option = document.createElement('option');
                option.value = value;
                option.textContent = value;

                // Set selected if it's the current month and year
                if (date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear()) {
                    option.selected = true;
                }

                $(this).append(option);
            });
        }


        // Load initial data
        loadInitialData();

        // Function to load initial data (classes, sections, etc.)
        function loadInitialData() {
            $.ajax({
                url: '../ajax/students-list-api.php',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Populate class filter
                        const classFilter = $('#classFilter');
                        response.classes.forEach(cls => {
                            classFilter.append(`<option value="${cls.id}">${cls.class_name}</option>`);
                        });

                        // Populate section filter
                        const sectionFilter = $('#sectionFilter');
                        response.sections.forEach(sec => {
                            sectionFilter.append(`<option value="${sec.id}">${sec.section_name} (${sec.class_name})</option>`);
                        });

                        // Populate exam dropdown
                        const examDropdown = $('#examDropdown');
                        response.exams.forEach(exam => {
                            examDropdown.append(`<li><a class="dropdown-item exam-option" href="#" data-exam-id="${exam.id}">${exam.exam_name} (${formatDate(exam.exam_date)})</a></li>`);
                        });

                        // Populate admit cards dropdown (for bulk actions)
                        const admitCards = response.admit_cards;

                        // Now load the students
                        loadStudents();
                    } else {
                        toastr.error('Error loading initial data');
                    }
                },
                error: function(xhr) {
                    toastr.error('Error: ' + xhr.statusText);
                    console.error(xhr.responseText);
                }
            });
        }

        // Function to format date
        function formatDate(dateString) {
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', {
                day: 'numeric',
                month: 'short',
                year: 'numeric'
            });
        }

        // Add this new function to preserve selections before reload
        function preserveSelectionsBeforeReload() {
            // Don't just capture visible checkboxes, maintain the global array
            $('.student-checkbox:checked').each(function() {
                const studentId = $(this).data('student-id').toString();
                if (!globalSelectedStudents.includes(studentId)) {
                    globalSelectedStudents.push(studentId);
                }
            });

            // Remove unchecked students from global array
            $('.student-checkbox:not(:checked)').each(function() {
                const studentId = $(this).data('student-id').toString();
                const index = globalSelectedStudents.indexOf(studentId);
                if (index > -1) {
                    globalSelectedStudents.splice(index, 1);
                }
            });
        }

        // Function to load students
        function loadStudents(page = 1) {
            preserveSelectionsBeforeReload(); // Save selections before reload
            currentPage = page;

            // Show loading indicator
            $('#studentsTableBody').html(`
                <tr>
                    <td colspan="13" class="text-center py-4">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </td>
                </tr>
            `);

            // Get filter values
            filterParams = {
                search: $('#search').val(),
                class: $('#classFilter').val(),
                section: $('#sectionFilter').val(),
                gender: $('#genderFilter').val(),
                status: $('#statusFilter').val(),
                fee_status: $('#feeStatusFilter').val(),
                hosteler: $('#hostelerFilter').val(),
                car_route: $('#carRouteFilter').val(),
                page: currentPage
            };

            // Make AJAX request
            $.ajax({
                url: '../ajax/students-list-api.php',
                type: 'GET',
                data: filterParams,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        totalPages = response.total_pages;
                        totalStudents = response.total_students;

                        renderStudents(response.students);
                        updatePagination(response.total_pages, response.current_page);
                        updateResultsSummary(response.total_students, response.current_page);
                    } else {
                        toastr.error('Error loading students');
                        $('#studentsTableBody').html(`
                        <tr>
                            <td colspan="13" class="text-center py-4 text-danger">
                                Error loading student data
                            </td>
                        </tr>
                    `);
                    }
                },
                error: function(xhr) {
                    toastr.error('Error: ' + xhr.statusText);
                    console.error(xhr.responseText);
                    $('#studentsTableBody').html(`
                    <tr>
                        <td colspan="13" class="text-center py-4 text-danger">
                            Error loading student data
                        </td>
                    </tr>
                `);
                }
            });
        }

        // Function to render students in the table
        function renderStudents(students) {
            const $tbody = $('#studentsTableBody');
            $tbody.empty();

            if (students.length > 0) {
                students.forEach(function(student) {
                    const isSelected = globalSelectedStudents.includes(student.student_id.toString());
                    const row = `
                        <tr>
                            <td>
                                <input type="checkbox" class="form-check-input student-checkbox" 
                                    data-student-id="${escapeHtml(student.student_id)}" 
                                    data-class-id="${escapeHtml(student.class_id)}"
                                    ${isSelected ? 'checked' : ''}>
                            </td>
                            <td style="max-width: 70px;">
                                <a data-src="../../uploads/students/${escapeHtml(student.student_image)}" data-fancybox data-caption="${escapeHtml(student.name)}">
                                    <img src="../../uploads/students/${escapeHtml(student.student_image)}" alt="📷" width="100%" loading="lazy">
                                </a>
                            </td>
                            <td>
                                <a target="_blank" href="../../parent/dashboard/view-student-details.php?student_id=${escapeHtml(student.student_id)}" class="text-decoration-none">
                                    ${escapeHtml(student.name)}
                                </a>
                            </td>
                            <td>${escapeHtml(student.father_name)}</td>
                            <td class="text-truncate" style="max-width: 200px;" title="${escapeHtml(student.address)}">${escapeHtml(student.address)}</td>
                            <td>${escapeHtml(student.class_name)}</td>
                            <td>${escapeHtml(student.section_name)}</td>
                            <td>${escapeHtml(student.roll_no)}</td>
                            <td>
                                <span class="badge ${student.is_hosteler ? 'bg-info' : 'bg-secondary'}">
                                    ${student.is_hosteler ? 'Yes' : 'No'}
                                </span>
                            </td>
                            <td>
                                ${student.car_route ? 
                                    `<span class="badge bg-primary" title="${escapeHtml(student.car_route)}">Yes</span>` : 
                                    `<span class="badge bg-secondary">No</span>`}
                            </td>
                            <td>
                                <span class="badge status-badge ${student.status === 'Active' ? 'bg-success' : 'bg-danger'}">
                                    ${escapeHtml(student.status)}
                                </span>
                            </td>
                            <td>
                                ${renderFeeStatus(student)}
                            </td>
                            <td>
                                ${renderActionDropdown(student)}
                            </td>
                        </tr>
                    `;
                    $tbody.append(row);
                });
                // Update selection count after rendering
                setTimeout(updateSelectAllCheckbox, 100);
            } else {
                $tbody.html(`
                    <tr>
                        <td colspan="13" class="text-center py-4">
                            <i class="fas fa-user-slash fa-2x text-muted mb-3"></i>
                            <h5>No students found</h5>
                            ${hasFilters() ? '<p class="text-muted">Try adjusting your filters</p>' : ''}
                        </td>
                    </tr>
                `);
            }
        }

        // Helper function to check if any filters are applied
        function hasFilters() {
            return $('#search').val() ||
                $('#classFilter').val() ||
                $('#sectionFilter').val() ||
                $('#statusFilter').val() ||
                $('#feeStatusFilter').val() ||
                $('#hostelerFilter').val() ||
                $('#carRouteFilter').val();
        }

        // Show Selected Students Btn Action
        $(document).on('click', '#showSelectedStudentsInfoBtn', () => {
            showAllSelectedStudentsInfo();
        });

        // OPTIONAL: Function to show all selected students in a modal
        function showAllSelectedStudentsInfo() {
            console.log('Showing selected students details');

            if (globalSelectedStudents.length === 0) {
                toastr.info('No students selected');
                return;
            }

            // Fetch details of all selected students
            $.ajax({
                url: '../ajax/get-selected-students-details.php',
                type: 'POST',
                data: {
                    student_ids: globalSelectedStudents.join(',')
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        let html = '<div class="table-responsive"><table class="table table-sm">';
                        html += '<thead><tr><th>ID</th><th>Name</th><th>Class</th></tr></thead><tbody>';

                        response.students.forEach(student => {
                            html += `<tr>
                                <td>${student.student_id}</td>
                                <td>${student.name}</td>
                                <td>${student.class_name} - ${student.section_name}</td>
                            </tr>`;
                        });

                        html += '</tbody></table></div>';

                        Swal.fire({
                            title: `Selected Students (${globalSelectedStudents.length})`,
                            html: html,
                            width: '600px',
                            confirmButtonText: 'Close'
                        });
                    }
                },
                error: function() {
                    toastr.error('Error fetching student details');
                }
            });
        }

        // Helper function to escape HTML
        function escapeHtml(text) {
            if (text === null || text === undefined) {
                return '';
            }
            return text.toString()
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;");
        }

        // Function to render fee status
        // Replace the renderFeeStatus function with:
        function renderFeeStatus(student) {
            if (student.unpaid_amount !== undefined) {
                if (student.unpaid_amount > 0) {
                    return `<span class="badge bg-danger status-badge" title="Unpaid: ₹${parseFloat(student.unpaid_amount).toFixed(2)}">
                <i class="fas fa-times-circle"></i> Unpaid
            </span>`;
                } else if (student.paid_amount > 0) {
                    return `<span class="badge bg-success status-badge" title="Paid: ₹${parseFloat(student.paid_amount || 0).toFixed(2)}">
                <i class="fas fa-check-circle"></i> Paid
            </span>`;
                } else {
                    return `<span class="badge bg-secondary status-badge">No Fee Data</span>`;
                }
            } else {
                return `<span class="badge bg-secondary status-badge">No Fee Data</span>`;
            }
        }

        // Function to render action dropdown
        function renderActionDropdown(student) {
            return `
                <div class="dropdown action-dropdown">
                    <button class="btn btn-sm btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                        <i class="fas fa-cog"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li>
                            <a class="dropdown-item" href="../form/edit-student.php?student_id=${escapeHtml(student.student_id)}">
                                <i class="fas fa-edit text-primary me-2"></i> Edit Student
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item" href="#" onclick="fetchAllUnpaidFees('${escapeHtml(student.name)}','${escapeHtml(student.student_id)}')">
                                <i class="fas fa-money-bill-wave text-warning me-2"></i> Unpaid Fees
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item" target="_blank" href="../../parent/dashboard/view-student-details.php?student_id=${escapeHtml(student.student_id)}">
                                <i class="fas fa-eye text-info me-2"></i> View Details
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#permissionModal"
                                onclick="openPermissionModal('${escapeHtml(student.student_id)}', '${escapeHtml(student.name)}')">
                                <i class="fas fa-key text-warning me-2"></i> Permission
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item" href="../form/bulk-add-result.php?student_ids=${escapeHtml(student.student_id)}">
                                <i class="fas fa-plus-circle text-primary me-2"></i> Mark Entry
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="../view/view-results.php?student_id=${escapeHtml(student.student_id)}">
                                <i class="fas fa-eye text-info me-2"></i> View Results
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <button class="dropdown-item text-danger" onclick="confirmDelete('${escapeHtml(student.student_id)}', '${escapeHtml(student.name)}')">
                                <i class="fas fa-trash-alt me-2"></i> Delete
                            </button>
                        </li>
                    </ul>
                </div>
                `;
        }

        // Function to update pagination
        function updatePagination(totalPages, currentPage) {
            const $pagination = $('#paginationContainer');
            $pagination.empty();

            if (totalPages <= 1) return;

            // Build pagination HTML
            let html = '';

            // Previous buttons
            if (currentPage > 1) {
                html += `
            <li class="page-item">
                <a class="page-link" href="#" data-page="1" title="First Page">
                    <i class="fas fa-angle-double-left"></i>
                </a>
            </li>
            <li class="page-item">
                <a class="page-link" href="#" data-page="${currentPage - 1}" title="Previous Page">
                    <i class="fas fa-angle-left"></i>
                </a>
            </li>
            `;
            }

            // Page numbers
            const start = Math.max(1, currentPage - 2);
            const end = Math.min(totalPages, currentPage + 2);

            if (start > 1) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }

            for (let i = start; i <= end; i++) {
                html += `
            <li class="page-item ${i == currentPage ? 'active' : ''}">
                <a class="page-link" href="#" data-page="${i}">${i}</a>
            </li>
            `;
            }

            if (end < totalPages) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }

            // Next buttons
            if (currentPage < totalPages) {
                html += `
            <li class="page-item">
                <a class="page-link" href="#" data-page="${currentPage + 1}" title="Next Page">
                    <i class="fas fa-angle-right"></i>
                </a>
            </li>
            <li class="page-item">
                <a class="page-link" href="#" data-page="${totalPages}" title="Last Page">
                    <i class="fas fa-angle-double-right"></i>
                </a>
            </li>
            `;
            }

            $pagination.html(html);
        }

        // IMPROVED: Update results summary to include selection info
        function updateResultsSummary(totalStudents, currentPage) {
            const perPage = 1000;
            const start = (currentPage - 1) * perPage + 1;
            const end = Math.min(start + perPage - 1, totalStudents);

            $('.results-summary').html(`
                Showing ${start} to ${end} of ${totalStudents} students
                ${hasFilters() ? '<div class="text-muted"><small>Filtered results</small></div>' : ''}
            `);

            // Add selection summary if there are selections
            displaySelectionSummary();
        }

        // Form submission handler
        $('#filterForm').on('submit', function(e) {
            e.preventDefault();
            loadStudents();
        });

        // Reset filters
        // Update your reset and clear functions
        $('#resetFilters').click(function() {
            $('#filterForm')[0].reset();
            globalSelectedStudents = []; // Clear selections
            loadStudents();
            $('#selectAll').prop('checked', false).prop('indeterminate', false);
            updateSelectedCount();
        });

        // Pagination click handler
        $(document).on('click', '.page-link', function(e) {
            e.preventDefault();
            const page = $(this).data('page');
            if (page) {
                loadStudents(page);
            }
        });

        // Select/Deselect all functionality
        // IMPROVED: Select/Deselect all functionality
        $('#selectAll').change(function() {
            const isChecked = $(this).prop('checked');
            $('.student-checkbox').each(function() {
                $(this).prop('checked', isChecked);
                const studentId = $(this).data('student-id').toString();

                if (isChecked) {
                    if (!globalSelectedStudents.includes(studentId)) {
                        globalSelectedStudents.push(studentId);
                    }
                } else {
                    const index = globalSelectedStudents.indexOf(studentId);
                    if (index > -1) {
                        globalSelectedStudents.splice(index, 1);
                    }
                }
            });
            updateSelectedCount();
        });

        // Update select all checkbox when individual checkboxes change
        $(document).on('change', '.student-checkbox', function() {
            updateSelectedCount();
        });

        // Clear selection
        $('#clearSelection').click(function() {
            globalSelectedStudents = []; // Clear global selections
            $('.student-checkbox, #selectAll').prop('checked', false);
            $('.student-checkbox, #selectAll').prop('indeterminate', false);
            updateSelectedCount();
        });

        // Update selected count display
        // Update the updateSelectedCount function
        function updateSelectedCount() {
            // Update global array with current page selections
            $('.student-checkbox:checked').each(function() {
                const studentId = $(this).data('student-id').toString();
                if (!globalSelectedStudents.includes(studentId)) {
                    globalSelectedStudents.push(studentId);
                }
            });

            // Remove unchecked students from current page
            $('.student-checkbox:not(:checked)').each(function() {
                const studentId = $(this).data('student-id').toString();
                const index = globalSelectedStudents.indexOf(studentId);
                if (index > -1) {
                    globalSelectedStudents.splice(index, 1);
                }
            });

            // Update the UI count
            $('#selectedCount').text(globalSelectedStudents.length + ' selected');

            // Show/hide bulk actions panel
            if (globalSelectedStudents.length > 0) {
                $('#bulkActionsPanel').slideDown();
            } else {
                $('#bulkActionsPanel').slideUp();
            }

            // Update "Select All" checkbox state for current page
            updateSelectAllCheckbox();
        }

        // NEW: Function to update "Select All" checkbox state
        function updateSelectAllCheckbox() {
            const visibleCheckboxes = $('.student-checkbox');
            const checkedVisibleCheckboxes = $('.student-checkbox:checked');

            if (visibleCheckboxes.length === 0) {
                $('#selectAll').prop('checked', false).prop('indeterminate', false);
            } else if (checkedVisibleCheckboxes.length === visibleCheckboxes.length) {
                $('#selectAll').prop('checked', true).prop('indeterminate', false);
            } else if (checkedVisibleCheckboxes.length > 0) {
                $('#selectAll').prop('checked', false).prop('indeterminate', true);
            } else {
                $('#selectAll').prop('checked', false).prop('indeterminate', false);
            }
        }

        // Bulk promote students
        $('#bulkPromoteStudents').click(function() {

            const selectedStudentIds = getSelectedStudentIds();
            const selectedClassIds = getSelectedClassIds();

            if (selectedClassIds.length > 0) {
                // loop through selected IDs and check if they are in the same class
                let allSameClass = true;
                const classId = selectedClassIds[0];

                for (let i = 1; i < selectedClassIds.length; i++) {
                    if (selectedClassIds[i] !== classId) {
                        allSameClass = false;
                        break;
                    }
                }

                if (allSameClass) {
                    window.open('../form/promote-bulk-students.php?student_ids=' + selectedStudentIds.join(','), '_blank');
                } else {
                    toastr.error('Please select students from the same class');
                }
            } else {
                toastr.warning('Please select at least one student');
            }
        });

        // Bulk edit students
        $('#bulkEditStudents').click(function() {

            const selectedStudentIds = getSelectedStudentIds();
            const selectedClassIds = getSelectedClassIds();

            if (selectedClassIds.length > 0) {
                // loop through selected IDs and check if they are in the same class
                let allSameClass = true;
                const classId = selectedClassIds[0];

                for (let i = 1; i < selectedClassIds.length; i++) {
                    if (selectedClassIds[i] !== classId) {
                        allSameClass = false;
                        break;
                    }
                }

                if (allSameClass) {
                    window.open('../form/edit-bulk-students.php?student_ids=' + selectedStudentIds.join(','), '_blank');
                } else {
                    toastr.error('Please select students from the same class');
                }
            } else {
                toastr.warning('Please select at least one student');
            }
        });

        // Bulk export students data
        $('#exportBulkStudentData').click(function() {

            const selectedStudentIds = getSelectedStudentIds();

            if (selectedStudentIds.length > 0) {
                window.open('../action/export-students-data.php?student_ids=' + selectedStudentIds.join(','), '_blank');
            } else {
                toastr.warning('Please select at least one student');
            }
        });

        // Send admission fee form
        $('#admissionFeeForm').submit((e) => {
            e.preventDefault();

            const selectedStudentIds = getSelectedStudentIds();

            if (selectedStudentIds.length === 0) {
                toastr.warning('Please select at least one student.');
                return;
            }

            const formData = $('#admissionFeeForm').serializeArray();
            formData.push({
                name: 'student_ids',
                value: selectedStudentIds.join(',')
            });

            $.ajax({
                url: '../action/process-admission-fees.php',
                method: 'POST',
                dataType: 'json',
                data: $.param(formData),
                beforeSend: function() {
                    Swal.fire({
                        title: 'Processing...',
                        text: 'Please wait',
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        allowEnterKey: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });
                },
                success: function(response) {
                    console.log('Success:', response);
                    if (response.success) {
                        let successMessage = response.message;
                        if (response.updated_count > 0 || response.inserted_count > 0) {
                            successMessage = `
                                <div class="text-start">
                                    <p>✅ ${response.updated_count} student(s) admission fees updated</p>
                                    <p>✅ ${response.inserted_count} student(s) admission fees inserted</p>
                                </div>
                            `;
                        }

                        Swal.fire({
                            title: 'Success!',
                            html: successMessage,
                            icon: 'success',
                            confirmButtonText: 'OK'
                        });

                        $('#admissionFeeModal').modal('hide');
                        // Refresh the page or update UI as needed
                        // window.location.reload();
                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: response.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', xhr.responseText);
                    Swal.fire({
                        title: 'Error',
                        text: 'An error occurred while processing the request.',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                },
                complete: function() {
                    // Swal.close() is not needed as we're showing a new dialog
                }
            });
        });

        // Send notification form
        $('#sendNotificationForm').submit((e) => {
            e.preventDefault();

            const selectedStudentIds = getSelectedStudentIds();

            if (selectedStudentIds.length === 0) {
                toastr.warning('Please select at least one student.');
                return;
            }

            const formData = $('#sendNotificationForm').serializeArray();
            formData.push({
                name: 'student_ids',
                value: selectedStudentIds.join(',')
            });

            $.ajax({
                url: '../action/send-notification.php',
                method: 'POST',
                dataType: 'json',
                data: $.param(formData),
                beforeSend: function() {
                    Swal.fire({
                        title: 'Processing...',
                        text: 'Please wait',
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        allowEnterKey: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });
                },
                success: function(response) {
                    console.log('Success:', response);
                    if (response.success) {
                        let successMessage = response.message;

                        Swal.fire({
                            title: 'Success!',
                            html: successMessage,
                            icon: 'success',
                            confirmButtonText: 'OK'
                        });

                        $('#sendNotificationModal').modal('hide');
                        // Refresh the page or update UI as needed
                        // window.location.reload();
                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: response.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', xhr.responseText);
                    Swal.fire({
                        title: 'Error',
                        text: 'An error occurred while processing the request.',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                },
                complete: function() {
                    // Swal.close() is not needed as we're showing a new dialog
                }
            });
        });

        // Manage Wallet Form
        $('#manageWalletForm').submit(function(e) {
            e.preventDefault();

            const selectedStudentIds = getSelectedStudentIds();
            const $form = $(this);
            const $btn = $form.find('[type="submit"]');
            const btnText = $btn.html();

            if (selectedStudentIds.length === 0) {
                toastr.warning('Please select at least one student.');
                return;
            }

            $.ajax({
                url: '../action/process-wallet.php',
                method: 'POST',
                dataType: 'json',
                data: $form.serialize() + '&student_ids=' + selectedStudentIds.join(','),
                beforeSend: function() {
                    Swal.fire({
                        title: 'Processing...',
                        text: 'Please wait',
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        allowEnterKey: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });
                },
                success: function(response) {
                    console.log('Success:', response);
                    if (response.success) {
                        let successMessage = response.message;
                        if (response.not_effected_students > 0) {
                            successMessage += "<br> Total <b>" + response.not_effected_students + "</b> student(s) wallets are not affected due to insufficient funds.";
                        }

                        Swal.fire({
                            title: 'Success!',
                            html: successMessage,
                            icon: 'success',
                            confirmButtonText: 'OK'
                        });

                        $('#manageWalletModal').modal('hide');
                        // Refresh the page or update UI as needed
                        // window.location.reload();
                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: response.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', xhr.responseText);
                    Swal.fire({
                        title: 'Error',
                        text: 'An error occurred while processing the request.',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                },
                complete: function() {
                    // Swal.close() is not needed as we're showing a new dialog
                }
            });
        });

        // Manage Fees Button
        $('#manageFeesAndPaymentsBtn').click(function() {
            let bulkFeeModal = new bootstrap.Modal(document.getElementById('bulkFeeModal'));
            const selectedStudentIds = getSelectedStudentIds();

            if (selectedStudentIds.length === 1) {
                $.ajax({
                    url: '../ajax/get-fees-info-remark.php',
                    method: 'POST',
                    dataType: 'json', // make sure your PHP returns JSON
                    data: {
                        student_id: selectedStudentIds[0]
                    },
                    beforeSend: function() {
                        Swal.fire({
                            title: 'Processing...',
                            text: 'Please wait',
                            allowOutsideClick: false,
                            allowEscapeKey: false,
                            allowEnterKey: false,
                            didOpen: () => {
                                Swal.showLoading();
                            }
                        });
                    },
                    success: function(response) {
                        console.log('Success:', response);
                        if (response.success) {
                            $('.payment-entry-info-alert-container').html(`
                                <div class="alert alert-info" role="alert">
                                    ${response.message}
                                </div>
                            `);
                        } else {
                            $('.payment-entry-info-alert-container').html(`
                                <div class="alert alert-warning" role="alert">
                                    ${response.message || 'No info available'}
                                </div>
                            `);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error:', xhr.responseText);
                        Swal.fire('Error', 'Failed to load fee information.', 'error');
                    },
                    complete: function() {
                        Swal.close(); // ✅ Close the loader
                        bulkFeeModal.show(); // ✅ Show the modal
                    }
                });
            } else {
                $('.payment-entry-info-alert-container').html(`
                    <div class="alert alert-info" role="alert">
                        Payment entry for total <b>${selectedStudentIds.length}</b> students.
                    </div>
                `);

                bulkFeeModal.show();
            }
        });


        // Ask Fees
        $('#feesEntryForm').submit(function(e) {
            e.preventDefault();

            const selectedStudentIds = getSelectedStudentIds();
            const $form = $(this);
            const $btn = $form.find('[type="submit"]');
            const btnText = $btn.html();

            // Show loading state
            $btn.prop('disabled', true).html(
                '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...'
            );

            // Build form data manually
            let formData = $form.serializeArray();
            formData.push({
                name: 'studentIDs',
                value: selectedStudentIds.join(',')
            });

            $.ajax({
                url: '../action/process-fees-entry.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Show summary success message
                        toastr.success(response.message);

                        // Show detailed results in a modal or console
                        if (response.results && response.results.length > 0) {
                            let successCount = 0;
                            let skippedCount = 0;
                            let html = '<div class="bulk-results-container">';

                            response.results.forEach(result => {
                                if (result.success) {
                                    successCount++;
                                    html += `
                                <div class="alert alert-success mb-2">
                                    <strong>${result.student_id}</strong>: ${result.message} 
                                    (Amount: ${result.amount || 'N/A'})
                                </div>
                            `;
                                } else {
                                    skippedCount++;
                                    html += `
                                <div class="alert alert-warning mb-2">
                                    <strong>${result.student_id}</strong>: ${result.message}
                                </div>
                            `;
                                }
                            });

                            html += '</div>';

                            // Show detailed results in a modal
                            Swal.fire({
                                title: 'Detailed Results',
                                html: `
                            <div class="text-left">
                                <p><strong>Summary:</strong> ${response.message}</p>
                                <p>Successfully processed: ${successCount}</p>
                                <p>Skipped: ${skippedCount}</p>
                                <div class="mt-3" style="max-height: 300px; overflow-y: auto;">
                                    ${html}
                                </div>
                            </div>
                        `,
                                icon: 'info',
                                confirmButtonText: 'OK'
                            });
                        }

                        $('#bulkFeeModal').modal('hide');
                        $('.modal-backdrop').hide();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr) {
                    try {
                        const errorResponse = JSON.parse(xhr.responseText);
                        let errorMsg = 'Error: ' + (errorResponse.message || 'Operation failed');

                        if (errorResponse.processed_up_to) {
                            errorMsg += ` (Last processed student ID: ${errorResponse.processed_up_to})`;
                        }

                        toastr.error(errorMsg);
                    } catch (e) {
                        toastr.error('Error: ' + xhr.status + " " + xhr.statusText);
                        console.error(e);
                    }
                },
                complete: function() {
                    $btn.prop('disabled', false).html(btnText);
                }
            });
        });


        // Save payment form submit
        $('#paymentsEntryForm').submit(function(e) {
            e.preventDefault();

            const amountVal = $('#amount').val();
            if (!amountVal || isNaN(amountVal)) {
                toastr.error('Please enter a valid amount before submitting.');
                return;
            }

            const selectedStudentIds = getSelectedStudentIds();

            Swal.fire({

                title: "Is the amount correct?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                html: `<h3><b><span style="color: #0057c9;">₹${parseFloat(amountVal).toFixed(2)}</span></b></h3>`,
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, correct amount!"

            }).then((result) => {

                if (result.isConfirmed) {

                    const $form = $(this);
                    const $btn = $form.find('[type="submit"]');
                    const btnText = $btn.html();

                    // Show loading state
                    $btn.prop('disabled', true).html(
                        '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...'
                    );

                    // Build form data manually
                    let formData = $form.serializeArray();
                    formData.push({
                        name: 'studentIDs',
                        value: selectedStudentIds.join(',')
                    });

                    $.ajax({
                        url: '../action/process-payments-entry.php',
                        type: 'POST',
                        data: formData,
                        dataType: 'json',
                        success: function(response) {
                            if (response.success) {
                                // Show summary success message
                                toastr.success(response.message);
                                $('#bulkFeeModal').modal('hide');
                                $('.modal-backdrop').hide();
                            } else {
                                toastr.error(response.message);
                            }

                            console.log(response.message);
                        },
                        error: function(xhr) {
                            try {
                                let errorMsg = 'Error: ' + (xhr.statusText || 'Operation failed');
                                toastr.error(errorMsg);
                            } catch (e) {
                                toastr.error('Error: ' + xhr.status + " " + xhr.statusText);
                                console.error(e);
                            }
                            console.error(xhr.responseText);
                        },
                        complete: function() {
                            $btn.prop('disabled', false).html(btnText);
                        }
                    });
                }
            });
        });


        // Add Result button click handler
        $('#addBulkResults').click(function() {

            const selectedStudentIds = getSelectedStudentIds();
            const selectedClassIds = getSelectedClassIds();

            if (selectedClassIds.length > 0) {
                // loop through selected IDs and check if they are in the same class
                let allSameClass = true;
                const classId = selectedClassIds[0];

                for (let i = 1; i < selectedClassIds.length; i++) {
                    if (selectedClassIds[i] !== classId) {
                        allSameClass = false;
                        break;
                    }
                }

                if (allSameClass) {
                    window.open('../form/bulk-add-result.php?student_ids=' + selectedStudentIds.join(','), '_blank');
                } else {
                    toastr.error('Please select students from the same class');
                }
            } else {
                toastr.warning('Please select at least one student');
            }
        });

        // Download ID Cards
        $('#downloadIdCards').click(function() {
            const selectedIds = getSelectedStudentIds();
            if (selectedIds.length > 0) {
                window.open('../action/download-bulk-id-card.php?student_ids=' + selectedIds.join(','), '_blank');
            } else {
                toastr.warning('Please select at least one student');
            }
        });

        // Download Admit Cards
        $('#downloadAdmitCards').click(function() {
            const selectedIds = getSelectedStudentIds();
            if (selectedIds.length > 0) {
                // Show modal to select which admit card to download
                Swal.fire({
                    title: 'Select Admit Card',
                    text: 'Which admit card do you want to download?',
                    input: 'select',
                    inputOptions: getAdmitCardOptions(),
                    inputPlaceholder: 'Select an admit card',
                    showCancelButton: true,
                    confirmButtonText: 'Download',
                    preConfirm: (admitId) => {
                        if (!admitId) {
                            Swal.showValidationMessage('Please select an admit card');
                        }
                        return admitId;
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.open('../action/download-bulk-admit-card.php?admit_id=' + result.value + '&student_ids=' + selectedIds.join(','), '_blank');
                    }
                });
            } else {
                toastr.warning('Please select at least one student');
            }
        });

        // Helper function to get admit card options
        function getAdmitCardOptions() {
            const options = <?php
                            $admitCards = $pdo->query("
                SELECT ea.id, e.exam_name, c.class_name 
                FROM exam_admit_releases ea
                JOIN exams e ON ea.exam_id = e.id
                JOIN classes c ON ea.class_id = c.id
                WHERE ea.status = 'released'
                ORDER BY e.exam_date DESC
            ")->fetchAll(PDO::FETCH_ASSOC);

                            $options = [];
                            foreach ($admitCards as $card) {
                                $options[$card['id']] = $card['exam_name'] . ' (' . $card['class_name'] . ')';
                            }

                            echo json_encode($options, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                            ?>;

            return options;
        }

        // Download Marksheet - handled by exam dropdown items
        $(document).on('click', '.exam-option', function(e) {
            e.preventDefault();
            const examId = $(this).data('exam-id');
            const selectedIds = getSelectedStudentIds();

            if (selectedIds.length > 0) {
                // First we need to get result IDs for these students and this exam
                $.ajax({
                    url: '../ajax/get-student-result-ids.php',
                    type: 'GET',
                    data: {
                        student_ids: selectedIds.join(','),
                        exam_id: examId
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success && response.result_ids.length > 0) {
                            window.open('../action/download-bulk-marksheet.php?result_ids=' + response.result_ids.join(','), '_blank');
                        } else {
                            toastr.error('No marksheets found for selected students and exam');
                        }
                    },
                    error: function(xhr) {
                        toastr.error('Error fetching result data: ' + xhr.statusText);
                    }
                });
            } else {
                toastr.warning('Please select at least one student');
            }
        });

        // ADD: Function to display selection summary
        function displaySelectionSummary() {
            if (globalSelectedStudents.length > 0) {
                const visibleSelected = $('.student-checkbox:checked').length;
                const totalSelected = globalSelectedStudents.length;

                if (totalSelected > visibleSelected) {
                    $('.results-summary').append(`
                    <div class="alert alert-info alert-sm mt-2">
                        <i class="fas fa-info-circle"></i> 
                        ${totalSelected} students selected (${visibleSelected} visible on this page)
                        <button class="btn btn-sm btn-outline-primary ms-2" id="showSelectedStudentsInfoBtn">
                            View All Selected
                        </button>
                    </div>
                `);
                }
            }
        }

        // Debounce function to prevent too many AJAX calls
        function debounce(func, wait, immediate) {
            let timeout;
            return function() {
                const context = this,
                    args = arguments;
                const later = function() {
                    timeout = null;
                    if (!immediate) func.apply(context, args);
                };
                const callNow = immediate && !timeout;
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
                if (callNow) func.apply(context, args);
            };
        }

        // Set up event listeners for real-time filtering
        $('#search').on('input', debounce(function() {
            loadStudents();
        }, 500));

        $('select').change(function() {
            if (!$(this).hasClass('exclude-from-load')) {
                loadStudents();

                // remove check box selection
                $('#selectAll').prop('checked', false);
                $('.student-checkbox').prop('checked', false);
                updateSelectedCount();
            }
        });

    });

    // Add this to your document ready function
    $('#bulkEditPermissions').click(function() {
        const selectedStudentIds = getSelectedStudentIds();
        if (selectedStudentIds.length === 0) {
            toastr.warning('Please select at least one student');
            return;
        }

        openBulkPermissionModal(selectedStudentIds);
    });

    // Update the openPermissionModal function to handle single student case
    function openPermissionModal(studentId, studentName) {
        $('#permStudentIds').val(studentId);
        $('#permStudentName').text(studentName + " (ID: " + studentId + ")");
        $('#bulkPermissionAlert').hide();

        // Fetch current permissions and fee status for single student
        $.ajax({
            url: '../ajax/get-student-permissions.php',
            type: 'GET',
            data: {
                student_id: studentId
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Update fee status display
                    let feeStatusText = response.fee_paid ?
                        '<span class="text-success">All fees cleared</span>' :
                        '<span class="text-danger">Pending fees: ₹' + response.unpaid_amount + '</span>';
                    $('#currentFeeStatus').html(feeStatusText);

                    // Set override checkboxes
                    $('#overrideAdmitCheck').prop('checked', response.data.override_admit_check || false);
                    $('#overrideMarksheetCheck').prop('checked', response.data.override_marksheet_check || false);

                    // Show/hide override options based on checkboxes
                    toggleOverrideOptions('admit', response.data.override_admit_check || false);
                    toggleOverrideOptions('marksheet', response.data.override_marksheet_check || false);

                    // Set permission toggles
                    $('#allowAdmitCard').prop('checked', response.data.allow_admit_card || false);
                    $('#allowMarksheet').prop('checked', response.data.allow_marksheet || false);
                    $('#permissionNotes').val(response.data.notes || '');
                } else {
                    toastr.error(response.message);
                }
            },
            error: function(xhr) {
                toastr.error('Error loading permissions: ' + xhr.statusText);
            }
        });

        // Show the modal
        const permModal = new bootstrap.Modal(document.getElementById('permissionModal'));
        $('.modal-backdrop').remove();
        permModal.show();
    }

    function toggleOverrideOptions(type, show) {
        const container = type === 'admit' ? '#admitCardOverrideContainer' : '#marksheetOverrideContainer';
        if (show) {
            $(container).show();
        } else {
            $(container).hide();
            $(container).find('input[type="checkbox"]').prop('checked', false);
        }
    }

    function confirmDelete(studentId, studentName) {
        Swal.fire({
            title: 'Confirm Delete',
            text: 'Are you sure you want to delete student with ID: ' + studentId + ' (' + studentName + ')?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '../action/delete-student.php',
                    type: 'POST',
                    data: {
                        student_id: studentId
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            toastr.success(response.message);
                            setTimeout(function() {
                                window.location.reload();
                            }, 1500);
                        } else {
                            toastr.error(response.message);
                        }
                    },
                    error: function(xhr) {
                        toastr.error('Error: ' + xhr.statusText);
                    }
                });
            }
        });
    }

    // Handle permission form submission
    $('#permissionForm').submit(function(e) {
        e.preventDefault();

        var $form = $(this);
        var $btn = $form.find('[type="submit"]');
        var btnText = $btn.html();

        // Show loading state
        $btn.prop('disabled', true).html(
            '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...'
        );

        $.ajax({
            url: '../action/update-student-permissions.php',
            type: 'POST',
            data: $form.serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                    $('#permissionModal').modal('hide');
                } else {
                    toastr.error(response.message);
                }
            },
            error: function(xhr) {
                toastr.error('Error saving permissions: ' + xhr.statusText);
            },
            complete: function() {
                $btn.prop('disabled', false).html(btnText);
            }
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>