<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/header-open.php");
echo "<title>Payment History - " . $school_name . "</title>";
require_once("../../includes/header-close.php");
require_once("../../includes/dashboard-navbar.php");
require_once("../../includes/db.php");

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    die("You don't have permission to access this page.");
}

// Get all payment history with pagination
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, [
    'options' => ['default' => 1, 'min_range' => 1]
]);

$per_page = 20;
$offset = ($page - 1) * $per_page;

// Get total count
$stmt = $pdo->query("SELECT COUNT(*) FROM student_payment_history");
$total_payments = $stmt->fetchColumn();
$total_pages = ceil($total_payments / $per_page);

// Get payment history with student names
$stmt = $pdo->prepare("
    SELECT ph.*, s.name AS student_name, s.father_name, s.class_id, s.section_id, 
           c.class_name, sec.section_name 
    FROM student_payment_history ph
    LEFT JOIN students s ON ph.student_id = s.student_id
    LEFT JOIN classes c ON c.id = s.class_id
    LEFT JOIN sections sec ON sec.id = s.section_id
    ORDER BY ph.id DESC
    LIMIT :limit OFFSET :offset
");
$stmt->bindValue(':limit', $per_page, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
    .table-responsive {
        overflow-x: auto;
    }

    .badge-paid {
        background-color: #28a745;
    }

    .badge-partial {
        background-color: #ffc107;
        color: #212529;
    }

    .action-dropdown .dropdown-menu {
        min-width: 150px;
    }

    .pagination .page-item.active .page-link {
        background-color: #0d6efd;
        border-color: #0d6efd;
    }

    .table-striped tbody tr:nth-of-type(odd) {
        background-color: #f9f9f9;
    }
</style>

<div class="container mt-4">
    <div class="card shadow-sm">
        <div class="bg-primary text-white d-flex justify-content-between align-items-center px-3 py-2">
            <h4><i class="fas fa-history me-2"></i>Payment History</h4>
            <div>
                <a href="students-list.php" class="btn btn-sm btn-light">
                    <i class="fas fa-arrow-left me-1"></i> Back to Students
                </a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Date</th>
                            <th>Student</th>
                            <th>Father</th>
                            <th>Class & Section</th>
                            <th>Amount</th>
                            <th>Remark</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($payments)): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4">
                                    <i class="fas fa-info-circle fa-2x text-muted mb-3"></i>
                                    <h5>No payment records found</h5>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($payments as $payment): ?>
                                <tr>
                                    <td><?= $payment['id'] ?></td>
                                    <td><?= date('d M Y', strtotime($payment['payment_date'])) ?></td>
                                    <td>
                                        <?= safe_htmlspecialchars($payment['student_name']) ?>
                                        <small class="text-muted d-block">ID: <?= $payment['student_id'] ?></small>
                                    </td>
                                    <td>
                                        <?= safe_htmlspecialchars($payment['father_name']) ?>
                                    </td>
                                    <td><?= safe_htmlspecialchars($payment['class_name']) ?> - <?= safe_htmlspecialchars($payment['section_name']) ?></td>
                                    <td><span class="badge bg-success">₹<?= number_format($payment['payment_amount'], 2) ?></span></td>
                                    <td title="<?= $payment['remark'] ?>" width="30%"><?= $payment['remark'] ?></td>
                                    <td>
                                        <button aria-label="Delete Payment Record" class="btn btn-sm btn-danger" onclick="deletePayment(<?= $payment['id'] ?>)"><i class="fas fa-trash-alt me-2"></i> Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <nav aria-label="Page navigation" class="mt-4">
                    <ul class="pagination justify-content-center">
                        <?php if ($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=1" aria-label="First">
                                    <span aria-hidden="true">&laquo;&laquo;</span>
                                </a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?= $page - 1 ?>" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php
                        $start = max(1, $page - 2);
                        $end = min($total_pages, $page + 2);
                        for ($i = $start; $i <= $end; $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>

                        <?php if ($page < $total_pages): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?= $page + 1 ?>" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?= $total_pages ?>" aria-label="Last">
                                    <span aria-hidden="true">&raquo;&raquo;</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    function deletePayment(payment_id) {
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#d33",
            cancelButtonColor: "#3085d6",
            confirmButtonText: "Yes, delete it!"
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: "../action/delete-bulk-payments.php",
                    type: "POST",
                    data: {
                        payment_ids: payment_id
                    },
                    beforeSend: function() {
                        Swal.fire({
                            title: "Processing...",
                            text: "Please wait while the payment is being deleted.",
                            allowOutsideClick: false,
                            allowEscapeKey: false,
                            showConfirmButton: false,
                            didOpen: () => {
                                Swal.showLoading();
                            }
                        });
                    },
                    success: function(response) {
                        if (response.success) {
                            Swal.fire({
                                icon: "success",
                                title: "Deleted!",
                                text: response.message,
                                confirmButtonColor: "#0d6efd"
                            }).then(() => {
                                $("tr:has(button[onclick='deletePayment(" + payment_id + ")'])").fadeOut();
                            });
                        } else {
                            Swal.fire({
                                icon: "error",
                                title: "Can't Delete Payment!",
                                text: response.message || "Something went wrong while deleting.",
                                confirmButtonText: "I Understood",
                                confirmButtonColor: "#d33"
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        let errorMessage = "Something went wrong while deleting.";

                        try {
                            // Try to parse server's response for a better message
                            const res = JSON.parse(xhr.responseText);
                            if (res.message) {
                                errorMessage = res.message;
                            }
                        } catch (e) {
                            // Keep default error message if not JSON
                        }

                        Swal.fire({
                            icon: "error",
                            title: "Failed!",
                            text: errorMessage,
                            confirmButtonColor: "#d33"
                        });

                        console.error("Error details:", xhr.responseText);
                    },
                    complete: function() {
                        // Swal.close();
                    }
                });
            }
        });
    }
</script>

<?php include_once("../../includes/body-close.php"); ?>