<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/header-open.php");
echo "<title>Manage Students - " . $school_name . "</title>";
require_once("../../includes/header-close.php");
require_once("../../includes/dashboard-navbar.php");

$stmt = $pdo->prepare("SELECT COUNT(*) FROM admission_enquiries");
$stmt->execute();
$count = $stmt->fetchColumn();
$totalAdmissionEnquiries = ($count > 99) ? '99+' : $count;

$stmt = $pdo->prepare("SELECT * FROM classes");
$stmt->execute();
$classes = $stmt->fetchAll();
?>

<style>
    .filter-card {
        background-color: #f8f9fa;
        border-radius: 8px;
        padding: 15px;
        margin-bottom: 20px;
    }

    .table>thead>tr>th {
        vertical-align: middle !important;
    }

    .table thead th {
        position: relative;
    }

    .table thead th input[type="checkbox"] {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    #marksheetDownloadModalTableBody>tr>td {
        vertical-align: middle;
        text-align: center;
    }

    .badge-active {
        background-color: #198754;
    }

    .badge-left {
        background-color: #dc3545;
    }

    .badge-paid {
        background-color: #198754;
    }

    .badge-unpaid {
        background-color: #dc3545;
    }

    .badge-nofee {
        background-color: #6c757d;
    }

    .action-dropdown .dropdown-menu {
        min-width: 200px;
    }

    .pagination .page-item.active .page-link {
        background-color: #0d6efd;
        border-color: #0d6efd;
    }

    .status-badge {
        cursor: default;
    }

    .bulk-actions {
        background-color: #f8f9fa;
        padding: 15px;
        margin-bottom: 20px;
        border-radius: 8px;
        display: none;
    }

    .bulk-checkbox {
        width: 20px;
    }

    .select-all-checkbox {
        margin-right: 10px;
    }

    .bulk-action-buttons {
        margin-right: 10px;
        margin-bottom: 5px;
    }

    .selected-count {
        font-weight: bold;
        margin-right: 15px;
    }

    .bulk-action-buttons {
        margin-right: 10px;
        margin-bottom: 10px;
        /* Provides consistent spacing */
    }

    .dropdown-menu .dropdown-item {
        display: flex;
        align-items: center;
        gap: 8px;
        /* Adds space between icon and text */
    }

    .dropdown-menu .dropdown-item i.fa-solid,
    .dropdown-menu .dropdown-item i.fas {
        width: 20px;
        /* Aligns icons neatly */
        text-align: center;
    }

    /* Styles for nested dropdown (for Marksheets) */
    .dropdown-submenu {
        position: relative;
    }

    .dropdown-submenu>.dropdown-menu {
        top: 0;
        left: 100%;
        margin-top: -6px;
        margin-left: -1px;
        border-radius: 0 0.25rem 0.25rem 0.25rem;
    }

    .dropdown-submenu:hover>.dropdown-menu {
        display: block;
    }

    .dropdown-submenu>a:after {
        display: block;
        content: " ";
        float: right;
        width: 0;
        height: 0;
        border-color: transparent;
        border-style: solid;
        border-width: 5px 0 5px 5px;
        border-left-color: #ccc;
        margin-top: 5px;
        margin-right: -10px;
    }
</style>

<div class="container mt-4">
    <!-- Action cards container -->
    <div class="container p-0">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="mb-0"><i class="fas fa-users me-2"></i>Student Management</h1>
            <a href="manage-admission-enquiries.php">
                <button type="button" class="btn btn-primary position-relative">
                    Admission Enquiry
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        <?= $totalAdmissionEnquiries; ?>
                    </span>
                </button>
            </a>
        </div>

        <!-- Filter Card -->
        <div class="card shadow-sm mb-4 p-0">
            <div class="card-header bg-primary text-white">
                <i class="fas fa-filter me-2"></i>Filter Students
            </div>
            <div class="card-body">
                <form id="filterForm" class="row g-3">
                    <!-- Search Field -->
                    <div class="col-md-3">
                        <label for="search" class="form-label">Search</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" name="search" id="search" class="form-control" placeholder="ID or Name">
                        </div>
                    </div>

                    <!-- Class Filter -->
                    <div class="col-md-2">
                        <label for="classFilter" class="form-label">Class</label>
                        <select name="class" id="classFilter" class="form-select" onchange="updateSectionOptions()">
                            <option value="">All Classes</option>
                            <!-- Will be populated by JavaScript -->
                        </select>
                    </div>

                    <!-- Section Filter -->
                    <div class="col-md-2">
                        <label for="sectionFilter" class="form-label">Section</label>
                        <select name="section" id="sectionFilter" class="form-select">
                            <option value="">All Sections</option>
                            <!-- Will be populated by JavaScript -->
                        </select>
                    </div>

                    <!-- Gender Filter -->
                    <div class="col-md-2">
                        <label for="genderFilter" class="form-label">Gender</label>
                        <select name="gender" id="genderFilter" class="form-select">
                            <option value="">All Genders</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <!-- Status Filter -->
                    <div class="col-md-2">
                        <label for="statusFilter" class="form-label">Status</label>
                        <select name="status" id="statusFilter" class="form-select">
                            <option value="Active">Active</option>
                            <option value="">All Statuses</option>
                            <option value="Left">Left</option>
                            <option value="Alumni">Alumni</option>
                        </select>
                    </div>

                    <!-- Fee Status Filter -->
                    <div class="col-md-2">
                        <label for="feeStatusFilter" class="form-label">Fee Status</label>
                        <select name="fee_status" id="feeStatusFilter" class="form-select">
                            <option value="">All Fee Statuses</option>
                            <option value="paid">Has Paid Fees</option>
                            <option value="unpaid">Has Unpaid Fees</option>
                            <option value="fully_paid">Fully Paid</option>
                        </select>
                    </div>

                    <!-- Hosteler Filter -->
                    <div class="col-md-2">
                        <label for="hostelerFilter" class="form-label">Hosteler</label>
                        <select name="hosteler" id="hostelerFilter" class="form-select">
                            <option value="">All</option>
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                    </div>

                    <!-- Car Route Filter -->
                    <div class="col-md-2">
                        <label for="carRouteFilter" class="form-label">Uses School Car</label>
                        <select name="car_route" id="carRouteFilter" class="form-select">
                            <option value="">All</option>
                            <option value="has_route">Yes</option>
                            <option value="no_route">No</option>
                        </select>
                    </div>

                    <!-- Driver Wise Filter -->
                    <div class="col-md-2">
                        <label for="driverByFilter" class="form-label">Driver</label>
                        <select name="driver_id" id="driverByFilter" class="form-select">
                            <option value="">All Drivers</option>
                            <?php
                            // Fetch drivers from the database
                            $drivers = $pdo->query("SELECT id, name FROM drivers")->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($drivers as $driver) {
                                echo "<option value=\"{$driver['id']}\">{$driver['name']}</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <!-- Action Buttons -->
                    <div class="col-md-1 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary me-2" title="Apply Filters">
                            <i class="fas fa-filter"></i>
                        </button>
                        <button type="button" id="resetFilters" class="btn btn-outline-secondary" title="Reset Filters">
                            <i class="fas fa-sync"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Bulk Actions Panel -->
        <div class="bulk-actions card shadow-sm mb-4" id="bulkActionsPanel">
            <div class="card-body">
                <div class="d-flex flex-wrap align-content-center align-items-center">
                    <span class="selected-count me-3" id="selectedCount">0 selected</span>

                    <button class="btn btn-primary bulk-action-buttons" id="bulkEditStudents">
                        <i class="fa-solid fa-user-pen me-1"></i> Edit Students
                    </button>

                    <div class="btn-group bulk-action-buttons" role="group">
                        <button type="button" class="btn btn-info dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-graduation-cap me-1"></i> Academic Actions
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#" id="bulkPromoteStudents"><i class="fa-solid fa-user-graduate me-2 text-primary"></i> Promote Students</a></li>
                            <li><a class="dropdown-item" href="#" id="addBulkResults"><i class="fas fa-plus-circle me-2 text-primary"></i> Students Mark Entry</a></li>
                            <li><a class="dropdown-item" href="#" id="manageAttendanceBtn" data-bs-toggle="modal" data-bs-target="#manageAttendanceModal"><i class="fa-solid fa-calendar-check me-2 text-primary"></i> Manage Attendance</a></li>
                        </ul>
                    </div>

                    <div class="btn-group bulk-action-buttons" role="group">
                        <button type="button" class="btn btn-success dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-dollar-sign me-1"></i> Financial Actions
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#" id="manageFeesAndPaymentsBtn"><i class="fa-solid fa-money-bill-1-wave me-2 text-success"></i> Manage Monthly Fees</a></li>
                            <li><a class="dropdown-item" href="#" onclick="openManageAdmissionFeesAndPaymentsModal(getSelectedStudentIds())"><i class="fa-solid fa-money-bills me-2 text-success"></i> Manage Admission Fees</a></li>
                            <li><a class="dropdown-item" href="#" id="manageWalletBtn" data-bs-toggle="modal" data-bs-target="#manageWalletModal"><i class="fa-solid fa-wallet me-2 text-success"></i> Manage Wallet</a></li>
                        </ul>
                    </div>

                    <div class="btn-group bulk-action-buttons" role="group">
                        <button type="button" class="btn btn-secondary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-download me-1"></i> Downloads & Reports
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#" id="downloadIdCards"><i class="fas fa-id-card me-2 text-secondary"></i> Download ID Cards</a></li>
                            <li><a class="dropdown-item" href="#" id="downloadAdmitCards"><i class="fas fa-file-alt me-2 text-secondary"></i> Download Admit Cards</a></li>
                            <li><a class="dropdown-item" href="#" onclick="downloadAdmissionForm(null)"><i class="fas fa-file-download me-2 text-secondary"></i> Download Admission Form</a></li>
                            <li><a class="dropdown-item" href="#" id="exportBulkStudentData"><i class="fa-solid fa-file-arrow-down me-2 text-secondary"></i> Download Students' Data</a></li>
                            <li data-bs-toggle="modal" data-bs-target="#marksheetsDownloadModal"><a class="dropdown-item" href="#"><i class="fas fa-file-pdf me-2 text-secondary"></i> Download Marksheet</a></li>
                        </ul>
                    </div>

                    <div class="btn-group bulk-action-buttons" role="group">
                        <button type="button" class="btn btn-warning dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-cogs me-1"></i> Admin Actions
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#" id="bulkEditPermissions"><i class="fas fa-key me-2 text-warning"></i> Edit Permissions</a></li>
                            <li><a class="dropdown-item" href="#" id="sendNotificationsBtn" data-bs-toggle="modal" data-bs-target="#sendNotificationsModal"><i class="fa-solid fa-bell me-2 text-warning"></i> Send Notifications</a></li>
                        </ul>
                    </div>

                    <button class="btn btn-outline-danger" id="clearSelection" style="margin-left: auto;">
                        <i class="fas fa-times me-1"></i> Clear Selection
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Student Table Container With Counter-->
    <div class="table-data-container shadow-lg rounded" style="border: 1px solid #e0e0e0;">
        <!-- Results Summary -->
        <div class="d-flex justify-content-between align-items-center p-3 results-summary">
            <!-- Will be updated via JavaScript -->
        </div>

        <!-- Student Table -->
        <div class="table-responsive">
            <table class="table table-striped table-hover table-bordered text-center align-middle">
                <thead class="table-dark">
                    <tr>
                        <th width="40">
                            <input type="checkbox" class="form-check-input select-all-checkbox" id="selectAll">
                        </th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Father's Name</th>
                        <th>Address</th>
                        <th>Class</th>
                        <th>Section</th>
                        <th>Roll No</th>
                        <th>Hosteler</th>
                        <th>Car Route</th>
                        <th>Status</th>
                        <th>Fee Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="studentsTableBody">
                    <!-- Students will be loaded here via AJAX -->
                    <tr>
                        <td colspan="13" class="text-center py-4">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>


    <!-- Pagination -->
    <nav aria-label="Page navigation" class="mt-4">
        <ul class="pagination justify-content-center" id="paginationContainer">
            <!-- Will be updated via JavaScript -->
        </ul>
    </nav>
</div>

<!-- Marksheet download chooser modal -->
<div class="modal fade" id="marksheetsDownloadModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h1 class="modal-title fs-5">Download Marksheets</h1>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                    <tbody id="marksheetDownloadModalTableBody">
                        <!-- Dynamically populated -->
                    </tbody>
                </table>
            </div>
            <div class="modal-footer d-flex justify-content-center">
                <button type="button" class="btn btn-primary" onclick="downloadCombinedMarksheets()"><i class="fas fa-download"></i> Download Combined Marksheet</button>
            </div>
        </div>
    </div>
</div>

<!-- Bulk Admission Fees and Payments Modal -->
<div class="modal fade" id="bulkAdmissionFeeModal" data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="bulkAdmissionFeeModalLabel" aria-hidden="true" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Admission Fees & Payments <b><span class="studentNameInModal"></span></b></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <ul class="nav nav-tabs nav-fill mb-3" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="admissionTab1-tab" data-bs-toggle="tab" data-bs-target="#admissionTab1" type="button" role="tab">Admission Payments Entry</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="admissionTab2-tab" data-bs-toggle="tab" data-bs-target="#admissionTab2" type="button" role="tab">Admission Fees Entry</button>
                    </li>
                </ul>

                <div class="tab-content mt-4">
                    <div class="tab-pane fade show active" id="admissionTab1" role="tabpanel">
                        <div class="payment-entry-info-alert-container"></div>
                        <form id="admissionPaymentsEntryForm" autocomplete="off">
                            <div class="mb-3">
                                <label for="admission_fee_amount" class="form-label">Amount:</label>
                                <input type="number" id="admission_fee_amount" name="amount" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="admission_payment_date" class="form-label">Payment Date:</label>
                                <input type="date" id="admission_payment_date" name="payment_date" class="form-control" required>
                            </div>
                            <div class="mt-3 mb-2 justify-content-right">
                                <button type="submit" class="btn btn-primary">Save Payments Entry</button>
                            </div>
                        </form>
                    </div>
                    <div class="tab-pane fade" id="admissionTab2" role="tabpanel">
                        <form id="admissionFeesEntryForm" autocomplete="off">
                            <div class="mb-3">
                                <label for="academic_year" class="form-label">Academic Year:</label>
                                <select name="academic_year" id="academic_year" class="form-control exclude-from-load academicYearSelect" required></select>
                            </div>
                            <div class="mb-3">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <label for="admission_class" class="form-label mb-0">
                                        Admission Class (Optional):
                                    </label>
                                    <label class="text-small" for="enable_admission_class_selection">
                                        Enable selection:
                                        <input type="checkbox" id="enable_admission_class_selection" class="form-check-input ms-2">
                                    </label>
                                </div>
                                <select name="admission_class" id="admission_class_selector" class="form-control exclude-from-load" disabled>
                                    <option value="">Current Class</option>
                                    <?php foreach ($classes as $class): ?>
                                        <option value="<?php echo $class['id']; ?>"><?php echo $class['class_name']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="discount" class="form-label">Discount:</label>
                                <input type="number" id="discount" name="discount" class="form-control">
                            </div>
                            <div class="mt-3 mb-2 justify-content-right">
                                <button type="submit" class="btn btn-primary">Save Fees Entry</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bulk Student Payments and Fees Modal -->
<div class="modal fade" id="bulkFeeModal" data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="bulkFeeModalLabel" aria-hidden="true" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Monthly Fees & Payments <b><span class="studentNameInModal"></span></b></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <ul class="nav nav-tabs nav-fill mb-3" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="monthlyTab1-tab" data-bs-toggle="tab" data-bs-target="#monthlyFeesTab1" type="button" role="tab">Payments Entry</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="monthlyTab2-tab" data-bs-toggle="tab" data-bs-target="#monthlyFeesTab2" type="button" role="tab">Fees Entry</button>
                    </li>
                </ul>

                <div class="tab-content mt-4">
                    <div class="tab-pane fade show active" id="monthlyFeesTab1" role="tabpanel">
                        <div class="payment-entry-info-alert-container"></div>
                        <form id="paymentsEntryForm" autocomplete="off">
                            <div class="mb-3">
                                <label for="monthly_fee_amount" class="form-label">Amount:</label>
                                <input type="number" id="monthly_fee_amount" name="amount" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="monthly_fee_payment_date" class="form-label">Payment Date:</label>
                                <input type="date" id="monthly_fee_payment_date" name="payment_date" class="form-control" required>
                            </div>
                            <div class="mt-3 mb-2 justify-content-right">
                                <button type="submit" class="btn btn-primary">Save Payments Entry</button>
                            </div>
                        </form>
                    </div>
                    <div class="tab-pane fade" id="monthlyFeesTab2" role="tabpanel">
                        <form id="feesEntryForm" autocomplete="off">
                            <div class="mb-3">
                                <label for="month_year" class="form-label">Month:</label>
                                <select name="month_year" id="month_year" class="form-control exclude-from-load feeMonthSelect" required></select>
                            </div>
                            <div class="mb-3">
                                <label for="discount" class="form-label">Discount:</label>
                                <input type="number" id="discount" name="discount" class="form-control">
                            </div>
                            <div class="mt-3 mb-2 justify-content-right">
                                <button type="submit" class="btn btn-primary">Save Fees Entry</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Permission Modal -->
<div class="modal fade" id="permissionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="permissionForm">
                <div class="modal-header">
                    <h5 class="modal-title">Manage Permissions for <span id="permStudentName"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="student_ids" id="permStudentIds">

                    <!-- Add this alert for bulk operations -->
                    <div class="alert alert-info mb-3" id="bulkPermissionAlert" style="display: none;">
                        <i class="fas fa-users me-2"></i> You are editing permissions for <strong><span id="selectedStudentsCount">0</span></strong> selected students.
                    </div>

                    <div class="alert alert-info mb-3">
                        <strong>Current Fee Status:</strong> <span id="currentFeeStatus">N/A for bulk operations</span>
                    </div>

                    <!-- Admit Card Section -->
                    <div class="card mb-3">
                        <div class="card-header bg-primary text-white">
                            Admit Card Permissions
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="overrideAdmitCheck" name="override_admit_check">
                                    <label class="form-check-label" for="overrideAdmitCheck">Override Fee Requirements for Admit Card</label>
                                </div>
                            </div>

                            <div class="mb-3" id="admitCardOverrideContainer" style="display:none;">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="allowAdmitCard" name="allow_admit_card">
                                    <label class="form-check-label" for="allowAdmitCard">Allow Admit Card Download</label>
                                </div>
                                <small class="text-muted">This will override the default fee-based permission</small>
                            </div>
                        </div>
                    </div>

                    <!-- Marksheet Section -->
                    <div class="card mb-3">
                        <div class="card-header bg-success text-white">
                            Marksheet Permissions
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="overrideMarksheetCheck" name="override_marksheet_check">
                                    <label class="form-check-label" for="overrideMarksheetCheck">Override Requirements for Marksheet</label>
                                </div>
                            </div>

                            <div class="mb-3" id="marksheetOverrideContainer" style="display:none;">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="allowMarksheet" name="allow_marksheet">
                                    <label class="form-check-label" for="allowMarksheet">Allow Marksheet Download</label>
                                </div>
                                <small class="text-muted">This will override any default restrictions</small>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="permissionNotes" class="form-label">Notes:</label>
                        <textarea class="form-control" id="permissionNotes" name="notes" rows="3" placeholder="Reason for override"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Permissions</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bulk notification send modal -->
<div class="modal fade" id="sendNotificationsModal" tabindex="-1" aria-labelledby="notificationModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" id="sendNotificationForm">
                <div class="modal-header bg-primary text-white">
                    <h1 class="modal-title fs-5" id="notificationModalLabel">Send Notification</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="notification_title" class="form-label">Notification Title: </label>
                        <input class="form-control" type="text" name="notification_title" id="notification_title" required>
                    </div>
                    <div class="mb-3">
                        <label for="notification_message" class="form-label">Notification Message: </label>
                        <input class="form-control" type="text" name="notification_message" id="notification_message" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bulk student manage wallet -->
<div class="modal fade" id="manageWalletModal" tabindex="-1" aria-labelledby="manageWalletModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" id="manageWalletForm">
                <div class="modal-header bg-primary text-white">
                    <h1 class="modal-title fs-5" id="manageWalletModalLabel">Manage Wallet</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="wallet_action" class="form-label">Action: </label>
                        <select class="form-select exclude-from-load" name="wallet_action" id="wallet_action" required>
                            <option selected value="">-- Select Action --</option>
                            <option value="add_funds">Add Funds</option>
                            <option value="deduct_funds">Deduct Funds</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="wallet_amount" class="form-label">Amount: </label>
                        <input class="form-control" type="number" name="wallet_amount" id="wallet_amount" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Manage unpaid fees modal for single student -->
<div class="modal fade" id="manageUnpaidFeesModal" tabindex="-1" aria-labelledby="manageUnpaidFeesModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h1 class="modal-title fs-5" id="manageUnpaidFeesModalLabel">All Unpaid Fees</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="manageUnpaidFeesModalBody">
                <!-- Data will be loaded via ajax -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Manage Attendance Modal -->
<div class="modal fade" id="manageAttendanceModal" tabindex="-1" aria-labelledby="manageAttendanceModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="post" id="manageAttendanceForm">
                <div class="modal-header bg-primary text-white">
                    <h1 class="modal-title fs-5" id="manageAttendanceModalLabel">Manage Attendance</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="attendance_action" class="form-label">Action: </label>
                        <select class="form-select exclude-from-load" name="attendance_action" id="attendance_action" required>
                            <option selected value="">-- Select Action --</option>
                            <option value="present">Mark Present</option>
                            <option value="absent">Mark Absent</option>
                            <option value="late">Mark Late</option>
                            <option value="leave">Mark Leave</option>
                        </select>
                    </div>

                    <!-- Date Selection -->
                    <div class="mb-3">
                        <label for="attendance_dates" class="form-label">Select Dates: </label>
                        <input class="form-control" type="text" name="attendance_dates" id="attendance_dates" placeholder="Select multiple dates" required>
                    </div>

                    <!-- Time Selection -->
                    <div class="mb-3">
                        <label for="attendance_time" class="form-label">Time: </label>
                        <input class="form-control" type="time" name="attendance_time" id="attendance_time" required>
                    </div>

                    <!-- Hidden field for combined date-time values -->
                    <input type="hidden" name="attendance_datetimes" id="attendance_datetimes">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" id="resetAttendanceForm">Reset</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    let globalSelectedStudents = [];
    let singleStudentId = null;

    // Helper function to get selected student IDs
    function getSelectedStudentIds() {
        // Return the global array instead of just visible checkboxes
        console.log(globalSelectedStudents);
        return globalSelectedStudents.map(id => id);
    }

    // IMPROVED: Helper function to get selected class IDs (you'll need to modify this)
    function getSelectedClassIds() {
        // Since we need class IDs, we should store them in globalSelectedStudents as objects
        // For now, let's get class IDs from currently visible selections
        const selectedIds = [];
        $('.student-checkbox:checked').each(function() {
            selectedIds.push($(this).data('class-id'));
        });
        return selectedIds;
    }

    // Function to manage unpaid fees
    function fetchAllUnpaidFees(student_name, student_id, feesType = 'monthly') {

        let api_url = '../ajax/fetch-all-monthly-unpaid-fees.php';
        let fees_type_text = 'Monthly';

        if (feesType == 'admission') {
            fees_type_text = 'Admission';
        }

        if (feesType == 'admission') {
            api_url = '../ajax/fetch-all-admission-unpaid-fees.php';
        }

        $.ajax({
            url: api_url,
            type: 'GET', // Use GET for fetching data
            data: {
                student_id: student_id
            },
            dataType: 'json',
            beforeSend: function() {
                // Show loading indicator
                Swal.fire({
                    title: 'Fetching Unpaid Fees...',
                    html: '<div class="spinner-border text-primary" role="status"></div>',
                    showConfirmButton: false,
                    allowOutsideClick: false
                });
            },
            success: function(response) {
                if (response.success) {
                    // Show success message
                    toastr.success(response.message);
                    // Populate the modal body with the unpaid fees data
                    let html = response.html;
                    $('#manageUnpaidFeesModalBody').html(html);
                    $('#manageUnpaidFeesModal').modal('show');
                    $('#manageUnpaidFeesModalLabel').html('Unpaid ' + fees_type_text + ' Fees for <b>' + student_name + '</b>');
                } else {
                    toastr.error(response.message);
                }
            },
            error: function(xhr) {
                toastr.error('Error fetching unpaid fees');
                console.error(xhr.responseText);
            },
            complete: function() {
                // Hide loading indicator
                Swal.close();
            }
        });
    }

    // Function to delete unpaid fee entry
    function deleteUnpaidFeeEntry(entryId, btn, feesType = 'monthly') {

        let api_url = '../action/delete-unpaid-monthly-fee-entry.php';
        if (feesType == 'admission') {
            api_url = '../action/delete-unpaid-admission-fee-entry.php';
        }

        Swal.fire({
            title: 'Are you sure?',
            text: "This action cannot be undone!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!'
        }).then((result) => {
            if (result.isConfirmed) {
                // Proceed with deletion
                $.ajax({
                    url: api_url,
                    type: 'POST',
                    data: {
                        entry_id: entryId
                    },
                    dataType: 'json',
                    beforeSend: function() {
                        // Show loading indicator
                        Swal.fire({
                            title: 'Deleting Fee Entry...',
                            html: '<div class="spinner-border text-primary" role="status"></div>',
                            showConfirmButton: false,
                            allowOutsideClick: false
                        });
                    },
                    success: function(response) {
                        if (response.success) {
                            // Show success message
                            toastr.success(response.message);
                            // Refresh the unpaid fees modal content
                            $(btn).closest('.alert').remove();
                            if ($('#manageUnpaidFeesModalBody').children().length === 0) {
                                $('#manageUnpaidFeesModal').modal('hide');
                                toastr.info('No more unpaid fees for this student.');
                            }
                        } else {
                            toastr.error(response.message);
                        }
                    },
                    error: function(xhr) {
                        toastr.error('Error deleting fee entry');
                        console.error(xhr.responseText);
                    },
                    complete: function() {
                        // Hide loading indicator
                        Swal.close();
                    }
                });
            }
        });
    }

    // Function to open admission fees and payments modal
    function openManageAdmissionFeesAndPaymentsModal(selectedStudentIds, studentName = null) {

        let bulkFeeModal = new bootstrap.Modal(document.getElementById('bulkAdmissionFeeModal'));

        if (selectedStudentIds.length === 0) {
            toastr.warning('Please select at least one student.');
            return;
        }

        if (studentName && selectedStudentIds.length === 1) {
            $('.studentNameInModal').text('[' + studentName + ']');
        } else {
            $('.studentNameInModal').text('');
        }

        if (selectedStudentIds.length === 1) {
            singleStudentId = selectedStudentIds[0];
            // For single student, fetch fee info and show it
            $.ajax({
                url: '../ajax/get-admission-fees-info-remark.php',
                method: 'POST',
                dataType: 'json', // make sure your PHP returns JSON
                data: {
                    student_id: selectedStudentIds[0]
                },
                beforeSend: function() {
                    Swal.fire({
                        title: 'Processing...',
                        text: 'Please wait',
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        allowEnterKey: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });
                },
                success: function(response) {
                    console.log('Success:', response);
                    if (response.success) {
                        $('.payment-entry-info-alert-container').html(`
                                <div class="alert alert-info" role="alert">
                                    ${response.message}
                                </div>
                            `);
                    } else {
                        $('.payment-entry-info-alert-container').html(`
                                <div class="alert alert-warning" role="alert">
                                    ${response.message || 'No info available'}
                                </div>
                            `);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', error);
                    console.error('Error:', xhr.responseText);
                    Swal.fire('Error', 'Failed to load fee information.', 'error');
                },
                complete: function() {
                    Swal.close(); // ✅ Close the loader
                    bulkFeeModal.show(); // ✅ Show the modal
                }
            });
        } else {
            $('.payment-entry-info-alert-container').html(`
                    <div class="alert alert-info" role="alert">
                        Payment entry for total <b>${selectedStudentIds.length}</b> students.
                    </div>
                `);

            bulkFeeModal.show();
        }
    }

    // Function to open the bulk fees and payments modal
    function openManageMonthlyFeesAndPaymentsModal(selectedStudentIds, studentName = null) {

        let bulkFeeModal = new bootstrap.Modal(document.getElementById('bulkFeeModal'));

        if (selectedStudentIds.length === 0) {
            toastr.warning('Please select at least one student.');
            return;
        }

        if (studentName && selectedStudentIds.length === 1) {
            $('.studentNameInModal').text('[' + studentName + ']');
        } else {
            $('.studentNameInModal').text('');
        }

        if (selectedStudentIds.length === 1) {
            singleStudentId = selectedStudentIds[0];
            // For single student, fetch fee info and show it
            $.ajax({
                url: '../ajax/get-fees-info-remark.php',
                method: 'POST',
                dataType: 'json', // make sure your PHP returns JSON
                data: {
                    student_id: selectedStudentIds[0]
                },
                beforeSend: function() {
                    Swal.fire({
                        title: 'Processing...',
                        text: 'Please wait',
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        allowEnterKey: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });
                },
                success: function(response) {
                    console.log('Success:', response);
                    if (response.success) {
                        $('.payment-entry-info-alert-container').html(`
                                <div class="alert alert-info" role="alert">
                                    ${response.message}
                                </div>
                            `);
                    } else {
                        $('.payment-entry-info-alert-container').html(`
                                <div class="alert alert-warning" role="alert">
                                    ${response.message || 'No info available'}
                                </div>
                            `);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', xhr.responseText);
                    Swal.fire('Error', 'Failed to load fee information.', 'error');
                },
                complete: function() {
                    Swal.close(); // ✅ Close the loader
                    bulkFeeModal.show(); // ✅ Show the modal
                }
            });
        } else {
            $('.payment-entry-info-alert-container').html(`
                    <div class="alert alert-info" role="alert">
                        Payment entry for total <b>${selectedStudentIds.length}</b> students.
                    </div>
                `);

            bulkFeeModal.show();
        }
    }

    // Function to manage bulk permissions
    function openBulkPermissionModal(studentIds) {
        // Set the student IDs in the form
        $('#permStudentIds').val(studentIds.join(','));

        // Update the modal title and show the bulk info alert
        $('#permStudentName').text("Multiple Students (" + studentIds.length + ")");
        $('#bulkPermissionAlert').show();
        $('#selectedStudentsCount').text(studentIds.length);

        // For bulk operations, we don't show individual fee status
        $('#currentFeeStatus').html('<em>Fee status varies across selected students</em>');

        // Reset all permission checkboxes to default state
        $('#overrideAdmitCheck, #allowAdmitCard, #overrideMarksheetCheck, #allowMarksheet').prop('checked', false);
        $('#permissionNotes').val('');

        // Hide the override containers initially
        $('#admitCardOverrideContainer, #marksheetOverrideContainer').hide();

        // Set up event listeners for the checkboxes
        $('#overrideAdmitCheck').off('change').on('change', function() {
            toggleOverrideOptions('admit', $(this).is(':checked'));
        });

        $('#overrideMarksheetCheck').off('change').on('change', function() {
            toggleOverrideOptions('marksheet', $(this).is(':checked'));
        });

        // Show the modal
        const permModal = new bootstrap.Modal(document.getElementById('permissionModal'));
        $('.modal-backdrop').remove();
        permModal.show();

        // Add special handling for bulk operations
        $('#permissionForm').off('submit').on('submit', function(e) {
            e.preventDefault();
            saveBulkPermissions(studentIds);
        });
    }

    function saveBulkPermissions(studentIds) {
        const $form = $('#permissionForm');
        const $btn = $form.find('[type="submit"]');
        const btnText = $btn.html();

        // Show loading state
        $btn.prop('disabled', true).html(
            '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...'
        );

        // Get form data
        const formData = $form.serialize();

        $.ajax({
            url: '../action/update-student-permissions.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Show summary success message
                    toastr.success(response.message);

                    // Show detailed results in a modal if available
                    if (response.results && response.results.length > 0) {
                        let successCount = 0;
                        let skippedCount = 0;
                        let html = '<div class="bulk-results-container">';

                        response.results.forEach(result => {
                            if (result.success) {
                                successCount++;
                                html += `
                                <div class="alert alert-success mb-2">
                                    <strong>${result.student_id}</strong>: ${result.message}
                                </div>
                            `;
                            } else {
                                skippedCount++;
                                html += `
                                <div class="alert alert-warning mb-2">
                                    <strong>${result.student_id}</strong>: ${result.message}
                                </div>
                            `;
                            }
                        });

                        html += '</div>';

                        // Show detailed results in a modal
                        Swal.fire({
                            title: 'Bulk Permissions Results',
                            html: `
                            <div class="text-left">
                                <p><strong>Summary:</strong> ${response.message}</p>
                                <p>Successfully processed: ${successCount}</p>
                                <p>Skipped: ${skippedCount}</p>
                                <div class="mt-3" style="max-height: 300px; overflow-y: auto;">
                                    ${html}
                                </div>
                            </div>
                        `,
                            icon: 'info',
                            confirmButtonText: 'OK',
                            width: '800px'
                        });
                    }

                    // Close the modal
                    $('#permissionModal').modal('hide');
                    $('.modal-backdrop').hide();
                } else {
                    toastr.error(response.message);
                }
            },
            error: function(xhr) {
                try {
                    const errorResponse = JSON.parse(xhr.responseText);
                    let errorMsg = 'Error: ' + (errorResponse.message || 'Operation failed');

                    if (errorResponse.processed_up_to) {
                        errorMsg += ` (Last processed student ID: ${errorResponse.processed_up_to})`;
                    }

                    toastr.error(errorMsg);
                } catch (e) {
                    toastr.error('Error: ' + xhr.status + " " + xhr.statusText);
                    console.error(e);
                }
            },
            complete: function() {
                $btn.prop('disabled', false).html(btnText);
            }
        });
    }

    // Function to change section options based on selected class
    function updateSectionOptions() {
        const selectedClassId = $('#classFilter').val();
        const sectionFilter = $('#sectionFilter');

        // Clear current options
        sectionFilter.empty();
        sectionFilter.append('<option value="">All Sections</option>');

        if (selectedClassId) {
            // Fetch sections for the selected class via AJAX
            $.ajax({
                url: '../ajax/get-sections-by-class.php',
                type: 'GET',
                data: {
                    class_id: selectedClassId
                },
                dataType: 'json',
                success: function(response) {
                    if (response.length > 0) {
                        response.forEach(sec => {
                            sectionFilter.append(`<option value="${sec.id}">${sec.section_name}</option>`);
                        });
                    } else {
                        toastr.error('Error loading sections');
                        toastr.error('No sections available for the selected class');
                        sectionFilter.html('<option value="">No sections available</option>');
                    }
                },
                error: function(xhr) {
                    toastr.error('Error: ' + xhr.statusText);
                    console.error(xhr.responseText);
                }
            });
        } else {
            // If no class is selected, leave it empty
            sectionFilter.empty();
            sectionFilter.append('<option value="">All Sections</option>');
        }
    }


    // Function to load initial data (classes, sections, etc.)
    function loadInitialData() {
        $.ajax({
            url: '../ajax/students-list-api.php',
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Populate class filter
                    const classFilter = $('#classFilter');
                    response.classes.forEach(cls => {
                        classFilter.append(`<option value="${cls.id}">${cls.class_name}</option>`);
                    });

                    // Populate marksheets download modal body;
                    let marksheetsRows = '';

                    response.exams.forEach(exam => {
                        let marksheetsDownloadTableRow = `
                            <tr>
                                <td><input type="checkbox" class="exam-checkbox-for-marksheet" data-exam-id="${exam.id}"></td>
                                <td>${exam.exam_name} (${formatDate(exam.exam_date)})</td>
                                <td>
                                    <button class="btn btn-sm btn-success single-marksheet-download-button" data-exam-id="${exam.id}">
                                        <i class="fas fa-download"></i> Download
                                    </button>
                                </td>
                            </tr>
                        `;
                        marksheetsRows += marksheetsDownloadTableRow;
                    });

                    $('#marksheetDownloadModalTableBody').html(marksheetsRows);

                    // Populate admit cards dropdown (for bulk actions)
                    const admitCards = response.admit_cards;

                    // Now load the students
                    loadStudents();
                } else {
                    toastr.error('Error loading initial data');
                }
            },
            error: function(xhr) {
                toastr.error('Error: ' + xhr.statusText);
                console.error(xhr.responseText);
            }
        });
    }

    // Function to format date
    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            day: 'numeric',
            month: 'short',
            year: 'numeric'
        });
    }

    // Add this new function to preserve selections before reload
    function preserveSelectionsBeforeReload() {
        // Don't just capture visible checkboxes, maintain the global array
        $('.student-checkbox:checked').each(function() {
            const studentId = $(this).data('student-id').toString();
            if (!globalSelectedStudents.includes(studentId)) {
                globalSelectedStudents.push(studentId);
            }
        });

        // Remove unchecked students from global array
        $('.student-checkbox:not(:checked)').each(function() {
            const studentId = $(this).data('student-id').toString();
            const index = globalSelectedStudents.indexOf(studentId);
            if (index > -1) {
                globalSelectedStudents.splice(index, 1);
            }
        });
    }

    // Function to load students
    function loadStudents(page = 1) {
        preserveSelectionsBeforeReload(); // Save selections before reload
        currentPage = page;

        // Show loading indicator
        $('#studentsTableBody').html(`
                <tr>
                    <td colspan="13" class="text-center py-4">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </td>
                </tr>
            `);

        // Get filter values
        filterParams = {
            search: $('#search').val(),
            class: $('#classFilter').val(),
            section: $('#sectionFilter').val(),
            gender: $('#genderFilter').val(),
            status: $('#statusFilter').val(),
            fee_status: $('#feeStatusFilter').val(),
            hosteler: $('#hostelerFilter').val(),
            car_route: $('#carRouteFilter').val(),
            driver_id: $('#driverByFilter').val(),
            page: currentPage
        };

        // Make AJAX request
        $.ajax({
            url: '../ajax/students-list-api.php',
            type: 'GET',
            data: filterParams,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    totalPages = response.total_pages;
                    totalStudents = response.total_students;

                    renderStudents(response.students);
                    updatePagination(response.total_pages, response.current_page);
                    updateResultsSummary(response.total_students, response.current_page);
                } else {
                    toastr.error('Error loading students');
                    $('#studentsTableBody').html(`
                        <tr>
                            <td colspan="13" class="text-center py-4 text-danger">
                                Error loading student data
                            </td>
                        </tr>
                    `);
                }
            },
            error: function(xhr) {
                toastr.error('Error: ' + xhr.statusText);
                console.error(xhr.responseText);
                $('#studentsTableBody').html(`
                    <tr>
                        <td colspan="13" class="text-center py-4 text-danger">
                            Error loading student data
                        </td>
                    </tr>
                `);
            }
        });
    }

    // Function to render students in the table
    function renderStudents(students) {
        const $tbody = $('#studentsTableBody');
        $tbody.empty();

        if (students.length > 0) {
            students.forEach(function(student) {
                const isSelected = globalSelectedStudents.includes(student.student_id.toString());
                const row = `
                        <tr>
                            <td>
                                <input type="checkbox" class="form-check-input student-checkbox" 
                                    data-student-id="${escapeHtml(student.student_id)}" 
                                    data-class-id="${escapeHtml(student.class_id)}"
                                    ${isSelected ? 'checked' : ''}>
                            </td>
                            <td style="max-width: 70px;">
                                <a data-src="../../uploads/students/${escapeHtml(student.student_image)}" data-fancybox data-caption="${escapeHtml(student.name)}">
                                    <img src="../../uploads/students/${escapeHtml(student.student_image)}" alt="📷" width="100%" loading="lazy">
                                </a>
                            </td>
                            <td>
                                <a target="_blank" href="../../parent/dashboard/view-student-details.php?student_id=${escapeHtml(student.student_id)}" class="text-decoration-none">
                                    ${escapeHtml(student.name)}
                                </a>
                            </td>
                            <td>${escapeHtml(student.father_name)}</td>
                            <td class="text-truncate" style="max-width: 200px;" title="${escapeHtml(student.address)}">${escapeHtml(student.address)}</td>
                            <td>${escapeHtml(student.class_name)}</td>
                            <td>${escapeHtml(student.section_name)}</td>
                            <td>${escapeHtml(student.roll_no)}</td>
                            <td>
                                <span class="badge ${student.is_hosteler ? 'bg-info' : 'bg-secondary'}">
                                    ${student.is_hosteler ? 'Yes' : 'No'}
                                </span>
                            </td>
                            <td>
                                ${student.driving_route ? 
                                    `<span class="badge bg-primary" title="${escapeHtml(student.driving_route)}">Yes</span>` : 
                                    `<span class="badge bg-secondary">No</span>`}
                            </td>
                            <td>
                                <span class="badge status-badge ${student.status === 'Active' ? 'bg-success' : 'bg-danger'}">
                                    ${escapeHtml(student.status)}
                                </span>
                            </td>
                            <td>
                                ${renderFeeStatus(student)}
                            </td>
                            <td>
                                ${renderActionDropdown(student)}
                            </td>
                        </tr>
                    `;
                $tbody.append(row);
            });
            // Update selection count after rendering
            setTimeout(updateSelectAllCheckbox, 100);
        } else {
            $tbody.html(`
                    <tr>
                        <td colspan="13" class="text-center py-4">
                            <i class="fas fa-user-slash fa-2x text-muted mb-3"></i>
                            <h5>No students found</h5>
                            ${hasFilters() ? '<p class="text-muted">Try adjusting your filters</p>' : ''}
                        </td>
                    </tr>
                `);
        }
    }

    // Helper function to check if any filters are applied
    function hasFilters() {
        return $('#search').val() ||
            $('#classFilter').val() ||
            $('#sectionFilter').val() ||
            $('#statusFilter').val() ||
            $('#feeStatusFilter').val() ||
            $('#hostelerFilter').val() ||
            $('#carRouteFilter').val();
    }

    // OPTIONAL: Function to show all selected students in a modal
    function showAllSelectedStudentsInfo() {
        console.log('Showing selected students details');

        if (globalSelectedStudents.length === 0) {
            toastr.info('No students selected');
            return;
        }

        // Fetch details of all selected students
        $.ajax({
            url: '../ajax/get-selected-students-details.php',
            type: 'POST',
            data: {
                student_ids: globalSelectedStudents.join(',')
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    let html = '<div class="table-responsive"><table class="table table-sm">';
                    html += '<thead><tr><th>ID</th><th>Name</th><th>Class</th></tr></thead><tbody>';

                    response.students.forEach(student => {
                        html += `<tr>
                                <td>${student.student_id}</td>
                                <td>${student.name}</td>
                                <td>${student.class_name} - ${student.section_name}</td>
                            </tr>`;
                    });

                    html += '</tbody></table></div>';

                    Swal.fire({
                        title: `Selected Students (${globalSelectedStudents.length})`,
                        html: html,
                        width: '600px',
                        confirmButtonText: 'Close'
                    });
                }
            },
            error: function() {
                toastr.error('Error fetching student details');
            }
        });
    }

    // Helper function to escape HTML
    function escapeHtml(text) {
        if (text === null || text === undefined) {
            return '';
        }
        return text.toString()
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    // Function to render fee status
    // Replace the renderFeeStatus function with:
    function renderFeeStatus(student) {
        if (student.unpaid_amount !== undefined) {
            if (student.unpaid_amount > 0) {
                return `<span class="badge bg-danger status-badge" title="Unpaid: ₹${parseFloat(student.unpaid_amount).toFixed(2)}">
                <i class="fas fa-times-circle"></i> Unpaid
            </span>`;
            } else if (student.paid_amount > 0) {
                return `<span class="badge bg-success status-badge" title="Paid: ₹${parseFloat(student.paid_amount || 0).toFixed(2)}">
                <i class="fas fa-check-circle"></i> Paid
            </span>`;
            } else {
                return `<span class="badge bg-secondary status-badge">No Fee Data</span>`;
            }
        } else {
            return `<span class="badge bg-secondary status-badge">No Fee Data</span>`;
        }
    }

    // Function to render action dropdown
    function renderActionDropdown(student) {
        return `
                <div class="dropdown action-dropdown">
                    
                    <button class="btn btn-sm btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown" type="button" data-bs-config='{ "popperConfig": { "strategy": "fixed" }}'>
                        <i class="fas fa-cog"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li>
                            <a class="dropdown-item" href="../form/edit-student.php?student_id=${escapeHtml(student.student_id)}">
                                <i class="fas fa-edit text-primary me-2"></i> Edit Student
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item" href="#" onclick="fetchAllUnpaidFees('${escapeHtml(student.name)}','${escapeHtml(student.student_id)}', 'monthly')">
                                <i class="fas fa-money-bill-wave text-warning me-2"></i> Unpaid Monthly Fees
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="#" onclick="openManageMonthlyFeesAndPaymentsModal(['${escapeHtml(student.student_id)}'], '${escapeHtml(student.name)}')">
                                <i class="fas fa-money-check-alt text-success me-2"></i> Monthly Fees & Payments
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item" target="_blank" href="../../parent/dashboard/view-student-details.php?student_id=${escapeHtml(student.student_id)}">
                                <i class="fas fa-eye text-info me-2"></i> View Details
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#permissionModal"
                                onclick="openPermissionModal('${escapeHtml(student.student_id)}', '${escapeHtml(student.name)}')">
                                <i class="fas fa-key text-warning me-2"></i> Download Permissions
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item" href="../form/students-mark-entry.php?student_ids=${escapeHtml(student.student_id)}">
                                <i class="fas fa-plus-circle text-primary me-2"></i> Mark Entry
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="../view/view-results.php?student_id=${escapeHtml(student.student_id)}">
                                <i class="fas fa-eye text-info me-2"></i> View Results
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <a class="dropdown-item" href="#" onclick="downloadAdmissionForm('${escapeHtml(student.student_id)}')">
                                <i class="fas fa-download text-primary me-2"></i> Admission Form
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="#" onclick="fetchAllUnpaidFees('${escapeHtml(student.name)}','${escapeHtml(student.student_id)}', 'admission')">
                                <i class="fas fa-money-bill-wave text-warning me-2"></i> Unpaid Admission Fees
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="#" onclick="openManageAdmissionFeesAndPaymentsModal(['${escapeHtml(student.student_id)}'], '${escapeHtml(student.name)}')">
                                <i class="fas fa-money-check-alt text-success me-2"></i> Admission Fees & Payments
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <button class="dropdown-item text-danger" onclick="confirmDelete('${escapeHtml(student.student_id)}', '${escapeHtml(student.name)}')">
                                <i class="fas fa-trash-alt me-2"></i> Delete
                            </button>
                        </li>
                    </ul>
                </div>
                `;
    }

    // Function to update pagination
    function updatePagination(totalPages, currentPage) {
        const $pagination = $('#paginationContainer');
        $pagination.empty();

        if (totalPages <= 1) return;

        // Build pagination HTML
        let html = '';

        // Previous buttons
        if (currentPage > 1) {
            html += `
            <li class="page-item">
                <a class="page-link" href="#" data-page="1" title="First Page">
                    <i class="fas fa-angle-double-left"></i>
                </a>
            </li>
            <li class="page-item">
                <a class="page-link" href="#" data-page="${currentPage - 1}" title="Previous Page">
                    <i class="fas fa-angle-left"></i>
                </a>
            </li>
            `;
        }

        // Page numbers
        const start = Math.max(1, currentPage - 2);
        const end = Math.min(totalPages, currentPage + 2);

        if (start > 1) {
            html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }

        for (let i = start; i <= end; i++) {
            html += `
            <li class="page-item ${i == currentPage ? 'active' : ''}">
                <a class="page-link" href="#" data-page="${i}">${i}</a>
            </li>
            `;
        }

        if (end < totalPages) {
            html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
        }

        // Next buttons
        if (currentPage < totalPages) {
            html += `
            <li class="page-item">
                <a class="page-link" href="#" data-page="${currentPage + 1}" title="Next Page">
                    <i class="fas fa-angle-right"></i>
                </a>
            </li>
            <li class="page-item">
                <a class="page-link" href="#" data-page="${totalPages}" title="Last Page">
                    <i class="fas fa-angle-double-right"></i>
                </a>
            </li>
            `;
        }

        $pagination.html(html);
    }

    // IMPROVED: Update results summary to include selection info
    function updateResultsSummary(totalStudents, currentPage) {
        const perPage = 1000;
        const start = (currentPage - 1) * perPage + 1;
        const end = Math.min(start + perPage - 1, totalStudents);

        $('.results-summary').html(`
                Showing ${start} to ${end} of ${totalStudents} students
                ${hasFilters() ? '<div class="text-muted"><small>Filtered results</small></div>' : ''}
            `);

        // Add selection summary if there are selections
        displaySelectionSummary();
    }

    // Update selected count display
    // Update the updateSelectedCount function
    function updateSelectedCount() {
        // Update global array with current page selections
        $('.student-checkbox:checked').each(function() {
            const studentId = $(this).data('student-id').toString();
            if (!globalSelectedStudents.includes(studentId)) {
                globalSelectedStudents.push(studentId);
            }
        });

        // Remove unchecked students from current page
        $('.student-checkbox:not(:checked)').each(function() {
            const studentId = $(this).data('student-id').toString();
            const index = globalSelectedStudents.indexOf(studentId);
            if (index > -1) {
                globalSelectedStudents.splice(index, 1);
            }
        });

        // Update the UI count
        $('#selectedCount').text(globalSelectedStudents.length + ' selected');

        // Show/hide bulk actions panel
        if (globalSelectedStudents.length > 0) {
            $('#bulkActionsPanel').slideDown();
        } else {
            $('#bulkActionsPanel').slideUp();
        }

        // Update "Select All" checkbox state for current page
        updateSelectAllCheckbox();
    }

    // NEW: Function to update "Select All" checkbox state
    function updateSelectAllCheckbox() {
        const visibleCheckboxes = $('.student-checkbox');
        const checkedVisibleCheckboxes = $('.student-checkbox:checked');

        if (visibleCheckboxes.length === 0) {
            $('#selectAll').prop('checked', false).prop('indeterminate', false);
        } else if (checkedVisibleCheckboxes.length === visibleCheckboxes.length) {
            $('#selectAll').prop('checked', true).prop('indeterminate', false);
        } else if (checkedVisibleCheckboxes.length > 0) {
            $('#selectAll').prop('checked', false).prop('indeterminate', true);
        } else {
            $('#selectAll').prop('checked', false).prop('indeterminate', false);
        }
    }

    // Helper function to get admit card options
    function getAdmitCardOptions() {
        const options = <?php
                        $admitCards = $pdo->query("
                SELECT ea.id, e.exam_name, c.class_name 
                FROM exam_admit_releases ea
                JOIN exams e ON ea.exam_id = e.id
                JOIN classes c ON ea.class_id = c.id
                WHERE ea.status = 'released'
                ORDER BY e.exam_date DESC
            ")->fetchAll(PDO::FETCH_ASSOC);

                        $options = [];
                        foreach ($admitCards as $card) {
                            $options[$card['id']] = $card['exam_name'] . ' (' . $card['class_name'] . ')';
                        }

                        echo json_encode($options, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                        ?>;

        return options;
    }

    // Helper function to get session year options
    function getSessionYearOptions() {
        const options = <?php
                        $currentYear = date('Y');
                        $sessions = [];
                        // Create an object for more descriptive options, e.g., "2025-2026"
                        for ($i = 0; $i < 5; $i++) {
                            $startYear = $currentYear + $i;
                            $endYear = $startYear + 1;
                            // $sessions[$startYear] = $startYear . '-' . $endYear;
                            $sessions[$startYear] = $startYear;
                        }
                        echo json_encode($sessions);
                        ?>;
        return options;
    }

    // Function to populate academic year select in admission fees & payments modal
    function populateAcademicYearSelect() {
        const options = getSessionYearOptions();
        const $select = $('#academic_year');

        $select.empty(); // Clear existing options
        $select.append('<option value="">Select Academic Year</option>'); // Default option

        $.each(options, function(value, text) {
            $select.append('<option value="' + value + '">' + text + '</option>');
        });
    }

    // ADD: Function to display selection summary
    function displaySelectionSummary() {
        if (globalSelectedStudents.length > 0) {
            const visibleSelected = $('.student-checkbox:checked').length;
            const totalSelected = globalSelectedStudents.length;

            if (totalSelected > visibleSelected) {
                $('.results-summary').append(`
                    <div class="alert alert-info alert-sm mt-2">
                        <i class="fas fa-info-circle"></i> 
                        ${totalSelected} students selected (${visibleSelected} visible on this page)
                        <button class="btn btn-sm btn-outline-primary ms-2" id="showSelectedStudentsInfoBtn">
                            View All Selected
                        </button>
                    </div>
                `);
            }
        }
    }

    // Debounce function to prevent too many AJAX calls
    function debounce(func, wait, immediate) {
        let timeout;
        return function() {
            const context = this,
                args = arguments;
            const later = function() {
                timeout = null;
                if (!immediate) func.apply(context, args);
            };
            const callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    }

    // Update the openPermissionModal function to handle single student case
    function openPermissionModal(studentId, studentName) {
        $('#permStudentIds').val(studentId);
        $('#permStudentName').text(studentName + " (ID: " + studentId + ")");
        $('#bulkPermissionAlert').hide();

        // Fetch current permissions and fee status for single student
        $.ajax({
            url: '../ajax/get-student-permissions.php',
            type: 'GET',
            data: {
                student_id: studentId
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Update fee status display
                    let feeStatusText = response.fee_paid ?
                        '<span class="text-success">All fees cleared</span>' :
                        '<span class="text-danger">Pending fees: ₹' + response.unpaid_amount + '</span>';
                    $('#currentFeeStatus').html(feeStatusText);

                    // Set override checkboxes
                    $('#overrideAdmitCheck').prop('checked', response.data.override_admit_check || false);
                    $('#overrideMarksheetCheck').prop('checked', response.data.override_marksheet_check || false);

                    // Show/hide override options based on checkboxes
                    toggleOverrideOptions('admit', response.data.override_admit_check || false);
                    toggleOverrideOptions('marksheet', response.data.override_marksheet_check || false);

                    // Set permission toggles
                    $('#allowAdmitCard').prop('checked', response.data.allow_admit_card || false);
                    $('#allowMarksheet').prop('checked', response.data.allow_marksheet || false);
                    $('#permissionNotes').val(response.data.notes || '');
                } else {
                    toastr.error(response.message);
                }
            },
            error: function(xhr) {
                toastr.error('Error loading permissions: ' + xhr.statusText);
            }
        });

        // Show the modal
        const permModal = new bootstrap.Modal(document.getElementById('permissionModal'));
        $('.modal-backdrop').remove();
        permModal.show();
    }

    function toggleOverrideOptions(type, show) {
        const container = type === 'admit' ? '#admitCardOverrideContainer' : '#marksheetOverrideContainer';
        if (show) {
            $(container).show();
        } else {
            $(container).hide();
            $(container).find('input[type="checkbox"]').prop('checked', false);
        }
    }

    function confirmDelete(studentId, studentName) {
        Swal.fire({
            title: 'Confirm Delete',
            text: 'Are you sure you want to delete student with ID: ' + studentId + ' (' + studentName + ')?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '../action/delete-student.php',
                    type: 'POST',
                    data: {
                        student_id: studentId
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            toastr.success(response.message);
                            setTimeout(function() {
                                window.location.reload();
                            }, 1500);
                        } else {
                            toastr.error(response.message);
                        }
                    },
                    error: function(xhr) {
                        toastr.error('Error: ' + xhr.statusText);
                    }
                });
            }
        });
    }

    // Function to download admission Forms
    function downloadAdmissionForm(studentId) {

        let studentIdsWithComma = '';

        if (studentId) {
            studentIdsWithComma = studentId;
        } else {
            const selectedIds = getSelectedStudentIds();
            const selectedClassIds = getSelectedClassIds();
            studentIdsWithComma = selectedIds.join(',');

            let allSameClass = true;
            const classId = selectedClassIds[0];

            for (let i = 1; i < selectedClassIds.length; i++) {
                if (selectedClassIds[i] !== classId) {
                    allSameClass = false;
                    break;
                }
            }

            if (!allSameClass) {
                toastr.error('Please select students from the same class');
                return;
            }

            if (selectedIds.length === 0) {
                toastr.warning('Please select at least one student');
                return;
            }

            if (selectedIds.length > 30) {
                toastr.warning('Please select up to 30 students at a time to download admission forms');
                return;
            }
        }

        if (studentIdsWithComma) {
            // Show modal to select which admission form to download
            Swal.fire({
                title: 'Select Session Year',
                text: 'Which session year do you want to download?',
                input: 'select',
                inputOptions: getSessionYearOptions(),
                inputPlaceholder: 'Select a session year',
                showCancelButton: true,
                confirmButtonText: 'Download',
                preConfirm: (sessionYear) => {
                    // 1. Validation: Ensure a session year was selected
                    if (!sessionYear) {
                        Swal.showValidationMessage('Please select a session year');
                    }
                    // 2. Return the selected value so it can be used in .then()
                    return sessionYear;
                }
            }).then((result) => {
                // Check if the user clicked "Download" and a value was confirmed
                if (result.isConfirmed) {
                    // The selected sessionYear is in result.value
                    window.open('../action/download/download-bulk-admission-forms.php?student_ids=' + studentIdsWithComma + '&session_year=' + result.value, '_blank');
                }
            });
        } else {
            toastr.warning('Please select at least one student');
        }
    }

    // Function to download combined marksheets
    function downloadCombinedMarksheets() {

        const selectedIds = getSelectedStudentIds();
        const selectedClassIds = getSelectedClassIds();

        if (selectedClassIds.length > 0) {
            // loop through selected IDs and check if they are in the same class
            let allSameClass = true;
            const classId = selectedClassIds[0];

            for (let i = 1; i < selectedClassIds.length; i++) {
                if (selectedClassIds[i] !== classId) {
                    allSameClass = false;
                    break;
                }
            }

            if (!allSameClass) {
                toastr.error('Please select students from the same class');
                return;
            } 
        } else {
            toastr.warning('Please select at least one student');
        }

        if (selectedIds.length == 0) {
            toastr.warning('Please select at least one student');
            return;
        }

        if (selectedIds.length > 50) {
            toastr.warning('Please select up to 50 students at a time to download combined marksheets');
            return;
        }

        const studentIdsWithComma = selectedIds.join(',');
        const selectedExamIdsForMarksheet = [];

        $('.exam-checkbox-for-marksheet:checked').each(function() {
            const examId = $(this).data('exam-id');
            selectedExamIdsForMarksheet.push(examId);
        });

        if (selectedExamIdsForMarksheet.length < 2) {
            toastr.warning('Please select at least 2 exams for marksheet');
            return;
        }

        // Sort exam ids low to high
        selectedExamIdsForMarksheet.sort((a, b) => a - b);

        window.open('../action/download/download-combined-marksheet.php?student_ids=' + studentIdsWithComma + '&exam_ids=' + selectedExamIdsForMarksheet.join(','), '_blank');
    }


    $(document).ready(function() {

        // Initialize variables
        let currentPage = 1;
        let totalPages = 1;
        let totalStudents = 0;
        let filterParams = {};

        // Initialize month dropdown
        // let monthSelect = $('.feeMonthSelect');
        const now = new Date();
        const totalMonths = 24;

        for (let i = totalMonths; i >= -totalMonths; i--) {
            const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
            const month = date.toLocaleString('default', {
                month: 'long'
            });
            const year = date.getFullYear();
            const value = `${month} ${year}`;

            $('.feeMonthSelect').each(function() {
                const option = document.createElement('option');
                option.value = value;
                option.textContent = value;

                // Set selected if it's the current month and year
                if (date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear()) {
                    option.selected = true;
                }

                $(this).append(option);
            });
        }


        // Load initial data
        loadInitialData();

        // Populate academic year select in admission fees & payments modal
        populateAcademicYearSelect()


        // Show Selected Students Btn Action
        $(document).on('click', '#showSelectedStudentsInfoBtn', () => {
            showAllSelectedStudentsInfo();
        });


        // Form submission handler
        $('#filterForm').on('submit', function(e) {
            e.preventDefault();
            loadStudents();
        });

        // Reset filters
        // Update your reset and clear functions
        $('#resetFilters').click(function() {
            $('#filterForm')[0].reset();
            globalSelectedStudents = []; // Clear selections
            loadStudents();
            $('#selectAll').prop('checked', false).prop('indeterminate', false);
            updateSelectedCount();
        });

        // Pagination click handler
        $(document).on('click', '.page-link', function(e) {
            e.preventDefault();
            const page = $(this).data('page');
            if (page) {
                loadStudents(page);
            }
        });

        // Select/Deselect all functionality
        // IMPROVED: Select/Deselect all functionality
        $('#selectAll').change(function() {
            const isChecked = $(this).prop('checked');
            $('.student-checkbox').each(function() {
                $(this).prop('checked', isChecked);
                const studentId = $(this).data('student-id').toString();

                if (isChecked) {
                    if (!globalSelectedStudents.includes(studentId)) {
                        globalSelectedStudents.push(studentId);
                    }
                } else {
                    const index = globalSelectedStudents.indexOf(studentId);
                    if (index > -1) {
                        globalSelectedStudents.splice(index, 1);
                    }
                }
            });
            updateSelectedCount();
        });

        // Update select all checkbox when individual checkboxes change
        $(document).on('change', '.student-checkbox', function() {
            updateSelectedCount();
        });

        // Clear selection
        $('#clearSelection').click(function() {
            globalSelectedStudents = []; // Clear global selections
            $('.student-checkbox, #selectAll').prop('checked', false);
            $('.student-checkbox, #selectAll').prop('indeterminate', false);
            updateSelectedCount();
        });


        // Bulk promote students
        $('#bulkPromoteStudents').click(function() {

            const selectedStudentIds = getSelectedStudentIds();
            const selectedClassIds = getSelectedClassIds();

            if (selectedClassIds.length > 0) {
                // loop through selected IDs and check if they are in the same class
                let allSameClass = true;
                const classId = selectedClassIds[0];

                for (let i = 1; i < selectedClassIds.length; i++) {
                    if (selectedClassIds[i] !== classId) {
                        allSameClass = false;
                        break;
                    }
                }

                if (allSameClass) {
                    window.open('../form/promote-bulk-students.php?student_ids=' + selectedStudentIds.join(','), '_blank');
                } else {
                    toastr.error('Please select students from the same class');
                }
            } else {
                toastr.warning('Please select at least one student');
            }
        });

        // Bulk edit students
        $('#bulkEditStudents').click(function() {

            const selectedStudentIds = getSelectedStudentIds();
            const selectedClassIds = getSelectedClassIds();

            if (selectedClassIds.length > 0) {
                // loop through selected IDs and check if they are in the same class
                let allSameClass = true;
                const classId = selectedClassIds[0];

                for (let i = 1; i < selectedClassIds.length; i++) {
                    if (selectedClassIds[i] !== classId) {
                        allSameClass = false;
                        break;
                    }
                }

                if (allSameClass) {
                    window.location.href = '../form/edit-bulk-students.php?student_ids=' + selectedStudentIds.join(',');
                } else {
                    toastr.error('Please select students from the same class');
                }
            } else {
                toastr.warning('Please select at least one student');
            }
        });

        // Bulk export students data
        $('#exportBulkStudentData').click(function() {

            const selectedStudentIds = getSelectedStudentIds();

            if (selectedStudentIds.length > 0) {
                window.open('../action/export-students-data.php?student_ids=' + selectedStudentIds.join(','), '_blank');
            } else {
                toastr.warning('Please select at least one student');
            }
        });


        // Send notification form
        $('#sendNotificationForm').submit((e) => {
            e.preventDefault();

            const selectedStudentIds = getSelectedStudentIds();

            if (selectedStudentIds.length === 0) {
                toastr.warning('Please select at least one student.');
                return;
            }

            const formData = $('#sendNotificationForm').serializeArray();
            formData.push({
                name: 'student_ids',
                value: selectedStudentIds.join(',')
            });

            $.ajax({
                url: '../action/send-notification.php',
                method: 'POST',
                dataType: 'json',
                data: $.param(formData),
                beforeSend: function() {
                    Swal.fire({
                        title: 'Processing...',
                        text: 'Please wait',
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        allowEnterKey: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });
                },
                success: function(response) {
                    console.log('Success:', response);
                    if (response.success) {
                        let successMessage = response.message;

                        Swal.fire({
                            title: 'Success!',
                            html: successMessage,
                            icon: 'success',
                            confirmButtonText: 'OK'
                        });

                        $('#sendNotificationModal').modal('hide');
                        // Refresh the page or update UI as needed
                        // window.location.reload();
                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: response.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', xhr.responseText);
                    Swal.fire({
                        title: 'Error',
                        text: 'An error occurred while processing the request.',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                },
                complete: function() {
                    // Swal.close() is not needed as we're showing a new dialog
                }
            });
        });

        // Manage Wallet Form
        $('#manageWalletForm').submit(function(e) {
            e.preventDefault();

            const selectedStudentIds = getSelectedStudentIds();
            const $form = $(this);
            const $btn = $form.find('[type="submit"]');
            const btnText = $btn.html();

            if (selectedStudentIds.length === 0) {
                toastr.warning('Please select at least one student.');
                return;
            }

            $.ajax({
                url: '../action/process-wallet.php',
                method: 'POST',
                dataType: 'json',
                data: $form.serialize() + '&student_ids=' + selectedStudentIds.join(','),
                beforeSend: function() {
                    Swal.fire({
                        title: 'Processing...',
                        text: 'Please wait',
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        allowEnterKey: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });
                },
                success: function(response) {
                    console.log('Success:', response);
                    if (response.success) {
                        let successMessage = response.message;
                        if (response.not_effected_students > 0) {
                            successMessage += "<br> Total <b>" + response.not_effected_students + "</b> student(s) wallets are not affected due to insufficient funds.";
                        }

                        Swal.fire({
                            title: 'Success!',
                            html: successMessage,
                            icon: 'success',
                            confirmButtonText: 'OK'
                        });

                        $('#manageWalletModal').modal('hide');
                        // Refresh the page or update UI as needed
                        // window.location.reload();
                    } else {
                        Swal.fire({
                            title: 'Error',
                            text: response.message,
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', xhr.responseText);
                    Swal.fire({
                        title: 'Error',
                        text: 'An error occurred while processing the request.',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                },
                complete: function() {
                    // Swal.close() is not needed as we're showing a new dialog
                }
            });
        });

        // Manage Fees Button
        $('#manageFeesAndPaymentsBtn').click(function() {
            const selectedStudentIds = getSelectedStudentIds();
            openManageMonthlyFeesAndPaymentsModal(selectedStudentIds);
        });

        // Ask Admission Fees Form Submit
        $('#admissionFeesEntryForm').submit(function(e) {
            e.preventDefault();

            let selectedStudentIds = getSelectedStudentIds();
            if (selectedStudentIds.length === 0) {
                if (singleStudentId) {
                    selectedStudentIds = [singleStudentId];
                } else {
                    toastr.warning('Please select at least one student.');
                    return;
                }
            }
            const $form = $(this);
            const $btn = $form.find('[type="submit"]');
            const btnText = $btn.html();

            // Show loading state
            $btn.prop('disabled', true).html(
                '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...'
            );

            // Build form data manually
            let formData = $form.serializeArray();
            formData.push({
                name: 'studentIDs',
                value: selectedStudentIds.join(',')
            });

            $.ajax({
                url: '../action/process-fees-entry-admission.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Show summary success message
                        toastr.success(response.message);

                        // Show detailed results in a modal or console
                        if (response.results && response.results.length > 0) {
                            let successCount = 0;
                            let skippedCount = 0;
                            let html = '<div class="bulk-results-container">';

                            response.results.forEach(result => {
                                if (result.success) {
                                    successCount++;
                                    html += `
                                        <div class="alert alert-success mb-2">
                                            <strong>${result.student_id}</strong>: ${result.message} 
                                            (Amount: ${result.amount || 'N/A'})
                                        </div>
                                    `;
                                } else {
                                    skippedCount++;
                                    html += `
                                        <div class="alert alert-warning mb-2">
                                            <strong>${result.student_id}</strong>: ${result.message}
                                        </div>
                                    `;
                                }
                            });

                            html += '</div>';

                            // Show detailed results in a modal
                            Swal.fire({
                                title: 'Detailed Results',
                                html: `
                                    <div class="text-left">
                                        <p><strong>Summary:</strong> ${response.message}</p>
                                        <p>Successfully processed: ${successCount}</p>
                                        <p>Skipped: ${skippedCount}</p>
                                        <div class="mt-3" style="max-height: 300px; overflow-y: auto;">
                                            ${html}
                                        </div>
                                    </div>
                                `,
                                icon: 'info',
                                confirmButtonText: 'OK'
                            });
                        }

                        $('#bulkAdmissionFeeModal').modal('hide');
                        $('.modal-backdrop').hide();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr) {
                    try {
                        console.log(xhr.responseText);
                        const errorResponse = JSON.parse(xhr.responseText);
                        let errorMsg = 'Error: ' + (errorResponse.message || 'Operation failed');

                        if (errorResponse.processed_up_to) {
                            errorMsg += ` (Last processed student ID: ${errorResponse.processed_up_to})`;
                        }

                        toastr.error(errorMsg);
                    } catch (e) {
                        toastr.error('Error: ' + xhr.status + " " + xhr.statusText);
                        console.error(e);
                    }
                },
                complete: function() {
                    $btn.prop('disabled', false).html(btnText);
                    singleStudentId = null; // Reset single student ID after processing
                }
            });
        });


        // Save admission payment form submit
        $('#admissionPaymentsEntryForm').submit(function(e) {
            e.preventDefault();

            const amountVal = $('#admission_fee_amount').val();
            if (!amountVal || isNaN(amountVal)) {
                toastr.error('Please enter a valid amount before submitting.');
                return;
            }

            let selectedStudentIds = getSelectedStudentIds();

            if (selectedStudentIds.length === 0) {
                if (singleStudentId) {
                    selectedStudentIds = [singleStudentId];
                } else {
                    toastr.warning('Please select at least one student.');
                    return;
                }
            }

            Swal.fire({
                title: "Is the amount correct?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                html: `<h3><b><span style="color: #0057c9;">₹${parseFloat(amountVal).toFixed(2)}</span></b></h3>`,
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, correct amount!"

            }).then((result) => {

                if (result.isConfirmed) {

                    const $form = $(this);
                    const $btn = $form.find('[type="submit"]');
                    const btnText = $btn.html();

                    // Show loading state
                    $btn.prop('disabled', true).html(
                        '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...'
                    );

                    // Build form data manually
                    let formData = $form.serializeArray();
                    formData.push({
                        name: 'studentIDs',
                        value: selectedStudentIds.join(',')
                    });

                    $.ajax({
                        url: '../action/process-payments-entry-admission.php',
                        type: 'POST',
                        data: formData,
                        dataType: 'json',
                        success: function(response) {
                            if (response.success) {
                                // Show summary success message
                                toastr.success(response.message);
                                $('#bulkAdmissionFeeModal').modal('hide');
                                $('.modal-backdrop').hide();
                            } else {
                                toastr.error(response.message);
                            }

                            console.log(response.message);
                        },
                        error: function(xhr) {
                            try {
                                let errorMsg = 'Error: ' + (xhr.statusText || 'Operation failed');
                                toastr.error(errorMsg);
                            } catch (e) {
                                toastr.error('Error: ' + xhr.status + " " + xhr.statusText);
                                console.error(e);
                            }
                            console.error(xhr.responseText);
                        },
                        complete: function() {
                            $btn.prop('disabled', false).html(btnText);
                            singleStudentId = null; // Reset single student ID after processing
                        }
                    });
                }
            });
        });

        // Admission Fees Form Class Selector Enable/Disable
        $('#enable_admission_class_selection').change(function() {
            if ($(this).is(':checked')) {
                $('#admission_class_selector').prop('disabled', false);
            } else {
                $('#admission_class_selector').prop('disabled', true).val('');
            }
        });


        // Ask Fees form submit
        $('#feesEntryForm').submit(function(e) {
            e.preventDefault();

            let selectedStudentIds = getSelectedStudentIds();
            if (selectedStudentIds.length === 0) {
                if (singleStudentId) {
                    selectedStudentIds = [singleStudentId];
                } else {
                    toastr.warning('Please select at least one student.');
                    return;
                }
            }
            const $form = $(this);
            const $btn = $form.find('[type="submit"]');
            const btnText = $btn.html();

            // Show loading state
            $btn.prop('disabled', true).html(
                '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...'
            );

            // Build form data manually
            let formData = $form.serializeArray();
            formData.push({
                name: 'studentIDs',
                value: selectedStudentIds.join(',')
            });

            $.ajax({
                url: '../action/process-fees-entry-monthly.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Show summary success message
                        toastr.success(response.message);

                        // Show detailed results in a modal or console
                        if (response.results && response.results.length > 0) {
                            let successCount = 0;
                            let skippedCount = 0;
                            let html = '<div class="bulk-results-container">';

                            response.results.forEach(result => {
                                if (result.success) {
                                    successCount++;
                                    html += `
                                <div class="alert alert-success mb-2">
                                    <strong>${result.student_id}</strong>: ${result.message} 
                                    (Amount: ${result.amount || 'N/A'})
                                </div>
                            `;
                                } else {
                                    skippedCount++;
                                    html += `
                                <div class="alert alert-warning mb-2">
                                    <strong>${result.student_id}</strong>: ${result.message}
                                </div>
                            `;
                                }
                            });

                            html += '</div>';

                            // Show detailed results in a modal
                            Swal.fire({
                                title: 'Detailed Results',
                                html: `
                            <div class="text-left">
                                <p><strong>Summary:</strong> ${response.message}</p>
                                <p>Successfully processed: ${successCount}</p>
                                <p>Skipped: ${skippedCount}</p>
                                <div class="mt-3" style="max-height: 300px; overflow-y: auto;">
                                    ${html}
                                </div>
                            </div>
                        `,
                                icon: 'info',
                                confirmButtonText: 'OK'
                            });
                        }

                        $('#bulkFeeModal').modal('hide');
                        $('.modal-backdrop').hide();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr) {
                    try {
                        const errorResponse = JSON.parse(xhr.responseText);
                        let errorMsg = 'Error: ' + (errorResponse.message || 'Operation failed');

                        if (errorResponse.processed_up_to) {
                            errorMsg += ` (Last processed student ID: ${errorResponse.processed_up_to})`;
                        }

                        toastr.error(errorMsg);
                    } catch (e) {
                        toastr.error('Error: ' + xhr.status + " " + xhr.statusText);
                        console.error(e);
                    }
                },
                complete: function() {
                    $btn.prop('disabled', false).html(btnText);
                    singleStudentId = null; // Reset single student ID after processing
                }
            });
        });


        // Save payment form submit
        $('#paymentsEntryForm').submit(function(e) {
            e.preventDefault();

            const amountVal = $('#monthly_fee_amount').val();
            if (!amountVal || isNaN(amountVal)) {
                toastr.error('Please enter a valid amount before submitting.');
                return;
            }

            let selectedStudentIds = getSelectedStudentIds();

            if (selectedStudentIds.length === 0) {
                if (singleStudentId) {
                    selectedStudentIds = [singleStudentId];
                } else {
                    toastr.warning('Please select at least one student.');
                    return;
                }
            }

            Swal.fire({
                title: "Is the amount correct?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                html: `<h3><b><span style="color: #0057c9;">₹${parseFloat(amountVal).toFixed(2)}</span></b></h3>`,
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, correct amount!"

            }).then((result) => {

                if (result.isConfirmed) {

                    const $form = $(this);
                    const $btn = $form.find('[type="submit"]');
                    const btnText = $btn.html();

                    // Show loading state
                    $btn.prop('disabled', true).html(
                        '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...'
                    );

                    // Build form data manually
                    let formData = $form.serializeArray();
                    formData.push({
                        name: 'studentIDs',
                        value: selectedStudentIds.join(',')
                    });

                    $.ajax({
                        url: '../action/process-payments-entry.php',
                        type: 'POST',
                        data: formData,
                        dataType: 'json',
                        success: function(response) {
                            if (response.success) {
                                // Show summary success message
                                toastr.success(response.message);
                                $('#bulkFeeModal').modal('hide');
                                $('.modal-backdrop').hide();
                            } else {
                                toastr.error(response.message);
                            }

                            console.log(response.message);
                        },
                        error: function(xhr) {
                            try {
                                let errorMsg = 'Error: ' + (xhr.statusText || 'Operation failed');
                                toastr.error(errorMsg);
                            } catch (e) {
                                toastr.error('Error: ' + xhr.status + " " + xhr.statusText);
                                console.error(e);
                            }
                            console.error(xhr.responseText);
                        },
                        complete: function() {
                            $btn.prop('disabled', false).html(btnText);
                            singleStudentId = null; // Reset single student ID after processing
                        }
                    });
                }
            });
        });


        // Add Result button click handler
        $('#addBulkResults').click(function() {

            const selectedStudentIds = getSelectedStudentIds();
            const selectedClassIds = getSelectedClassIds();

            if (selectedClassIds.length > 0) {
                // loop through selected IDs and check if they are in the same class
                let allSameClass = true;
                const classId = selectedClassIds[0];

                for (let i = 1; i < selectedClassIds.length; i++) {
                    if (selectedClassIds[i] !== classId) {
                        allSameClass = false;
                        break;
                    }
                }

                if (allSameClass) {
                    window.open('../form/students-mark-entry.php?student_ids=' + selectedStudentIds.join(','), '_blank');
                } else {
                    toastr.error('Please select students from the same class');
                }
            } else {
                toastr.warning('Please select at least one student');
            }
        });

        // Download ID Cards
        $('#downloadIdCards').click(function() {
            const selectedIds = getSelectedStudentIds();
            if (selectedIds.length > 0) {
                window.open('../action/download/download-bulk-id-card.php?student_ids=' + selectedIds.join(','), '_blank');
            } else {
                toastr.warning('Please select at least one student');
            }
        });

        // Download Admit Cards
        $('#downloadAdmitCards').click(function() {
            const selectedIds = getSelectedStudentIds();
            if (selectedIds.length > 0) {
                // Show modal to select which admit card to download
                Swal.fire({
                    title: 'Select Admit Card',
                    text: 'Which admit card do you want to download?',
                    input: 'select',
                    inputOptions: getAdmitCardOptions(),
                    inputPlaceholder: 'Select an admit card',
                    showCancelButton: true,
                    confirmButtonText: 'Download',
                    preConfirm: (admitId) => {
                        if (!admitId) {
                            Swal.showValidationMessage('Please select an admit card');
                        }
                        return admitId;
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.open('../action/download/download-bulk-admit-card.php?admit_id=' + result.value + '&student_ids=' + selectedIds.join(','), '_blank');
                    }
                });
            } else {
                toastr.warning('Please select at least one student');
            }
        });


        // Download Marksheet - handled by exam dropdown items
        $(document).on('click', '.single-marksheet-download-button', function(e) {
            e.preventDefault();
            const examId = $(this).data('exam-id');
            const selectedIds = getSelectedStudentIds();
            const selectedClassIds = getSelectedClassIds();

            if (selectedClassIds.length > 0) {
                // loop through selected IDs and check if they are in the same class
                let allSameClass = true;
                const classId = selectedClassIds[0];

                for (let i = 1; i < selectedClassIds.length; i++) {
                    if (selectedClassIds[i] !== classId) {
                        allSameClass = false;
                        break;
                    }
                }

                if (!allSameClass) {
                    toastr.error('Please select students from the same class');
                    return;
                }
            }

            if (selectedIds.length > 0) {
                // First we need to get result IDs for these students and this exam
                $.ajax({
                    url: '../ajax/get-student-result-ids.php',
                    type: 'GET',
                    data: {
                        student_ids: selectedIds.join(','),
                        exam_id: examId
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success && response.result_ids.length > 0) {
                            window.open('../action/download/download-single-marksheet.php?result_ids=' + response.result_ids.join(','), '_blank');
                        } else {
                            toastr.error('No marksheets found for selected students and exam');
                        }
                    },
                    error: function(xhr) {
                        toastr.error('Error fetching result data: ' + xhr.statusText);
                    }
                });
            } else {
                toastr.warning('Please select at least one student');
            }
        });

        // Set up event listeners for real-time filtering
        $('#search').on('input', debounce(function() {
            loadStudents();
        }, 500));

        $('select').change(function() {
            if (!$(this).hasClass('exclude-from-load')) {
                loadStudents();

                // remove check box selection
                $('#selectAll').prop('checked', false);
                $('.student-checkbox').prop('checked', false);
                updateSelectedCount();
            }
        });

        // Add this to your document ready function
        $('#bulkEditPermissions').click(function() {
            const selectedStudentIds = getSelectedStudentIds();
            if (selectedStudentIds.length === 0) {
                toastr.warning('Please select at least one student');
                return;
            }

            openBulkPermissionModal(selectedStudentIds);
        });

        // Handle permission form submission
        $('#permissionForm').submit(function(e) {
            e.preventDefault();

            var $form = $(this);
            var $btn = $form.find('[type="submit"]');
            var btnText = $btn.html();

            // Show loading state
            $btn.prop('disabled', true).html(
                '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...'
            );

            $.ajax({
                url: '../action/update-student-permissions.php',
                type: 'POST',
                data: $form.serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        $('#permissionModal').modal('hide');
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr) {
                    toastr.error('Error saving permissions: ' + xhr.statusText);
                },
                complete: function() {
                    $btn.prop('disabled', false).html(btnText);
                }
            });
        });


        // Initialize multiple dates picker
        const datePicker = flatpickr("#attendance_dates", {
            mode: "multiple",
            dateFormat: "Y-m-d"
        });

        // Set default time to current time
        const now1 = new Date();
        document.getElementById('attendance_time').value =
            now1.getHours().toString().padStart(2, '0') + ':' +
            now1.getMinutes().toString().padStart(2, '0');

        // Prepare data before form submission
        // Prepare data before form submission
        $('#manageAttendanceForm').on('submit', function(e) {
            e.preventDefault();

            // Get form data
            const selectedStudentIds = getSelectedStudentIds();
            if (selectedStudentIds.length === 0) {
                Swal.fire({
                    icon: 'warning',
                    title: 'No Students Selected',
                    text: 'Please select at least one student to manage attendance.'
                });
                return;
            }

            const dates = datePicker.selectedDates;
            const time = $('#attendance_time').val();
            const action = $('#attendance_action').val();

            // Validation
            if (dates.length === 0) {
                Swal.fire({
                    icon: 'warning',
                    title: 'No Dates Selected',
                    text: 'Please select at least one date for attendance.'
                });
                return;
            }

            if (!action) {
                Swal.fire({
                    icon: 'warning',
                    title: 'No Action Selected',
                    text: 'Please select an action for attendance.'
                });
                return;
            }

            if (!time) {
                Swal.fire({
                    icon: 'warning',
                    title: 'No Time Selected',
                    text: 'Please select a time for attendance.'
                });
                return;
            }

            // Combine dates with time
            const dateTimeValues = dates.map(date => {
                const dateStr = date.toLocaleDateString('en-CA'); // YYYY-MM-DD format
                return `${dateStr} ${time}`;
            });

            // Prepare form data as JSON
            const formData = {
                action: action,
                datetimes: dateTimeValues,
                student_ids: selectedStudentIds.join(',')
            };

            // Show loading state
            const submitBtn = $(this).find('button[type="submit"]');
            submitBtn.prop('disabled', true);
            submitBtn.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...');

            // AJAX submission with JSON data
            $.ajax({
                url: '../action/process-attendance.php',
                type: 'POST',
                dataType: 'json',
                contentType: 'application/json', // Add this line
                data: JSON.stringify(formData), // Stringify the JSON
                success: function(response) {
                    if (response.success) {
                        $('#manageAttendanceModal').modal('hide');

                        let infoHtml = `
                            <div class="alert alert-success mb-3">
                                <p>${response.message}</p>
                                <hr>
                                <p class="mb-1">Total Dates Processed: <b>${response.totalDateProcessed}</b></p>
                                <p class="mb-1">Total Students Processed: <b>${response.totalStudentsProcessed}</b></p>
                                <p class="mb-1">Total Records Updated: <b>${response.totalUpdatedRecords}</b></p>
                                <p class="mb-1">Total Records Inserted: <b>${response.totalInsertedRecords}</b></p>
                                <p class="mb-1">Total Dates Skipped: <b>${response.totalSkipDateRecords}</b></p>
                                <p class="mb-1">Total Students Skipped: <b>${response.totalSkipStudents}</b></p>
                            </div>
                        `;

                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            html: infoHtml,
                            confirmButtonText: 'OK',
                            willClose: () => {
                                // Optional: Refresh your attendance data grid here
                            }
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: response.message || 'Failed to save attendance records.'
                        });
                    }
                },
                error: function(xhr) {
                    const errorMsg = xhr.responseJSON?.message ||
                        xhr.responseText ||
                        'An error occurred while saving attendance';

                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: errorMsg
                    });
                    console.error('Error:', errorMsg);
                },
                complete: function() {
                    submitBtn.prop('disabled', false);
                    submitBtn.html('<i class="fas fa-paper-plane"></i> Submit');
                }
            });
        });

        // Reset form when modal closes
        $('#manageAttendanceModal').on('hidden.bs.modal', function() {
            datePicker.clear();
            $('#attendance_action').val('');
        });

        // Reset form
        $('#resetAttendanceForm').click(function() {
            datePicker.clear();
            const now = new Date();
            document.getElementById('attendance_time').value =
                now.getHours().toString().padStart(2, '0') + ':' +
                now.getMinutes().toString().padStart(2, '0');
            $('#attendance_action').val('');
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>