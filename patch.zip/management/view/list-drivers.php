<?php
// Standard includes for authentication, permission checks, and page headers.
include_once("../../includes/auth-check.php");
// We'll use a specific permission for managing transport or drivers.
// You might need to define PERM_MANAGE_TRANSPORT in your permission system.
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage Drivers - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if the user has the required permission to access this page.
// If not, display a permission denied message.
if (!hasPermission('PERM_MANAGE_TRANSPORT')) {
    include_once("../../includes/permission-denied.php");
}
// Get all driving routes for the route filter dropdown.
$routes = $pdo->query("SELECT id, route_name FROM driving_routes ORDER BY route_name ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Custom styles for this page -->
<style>
    /* Ensures the action dropdown menu appears correctly within the responsive table */
    .table-responsive {
        overflow: visible !important;
    }

    /* Styles for the image preview box in the edit modal */
    .image-preview-wrapper {
        border: 1px dashed #ccc;
        padding: 5px;
        margin-bottom: 10px;
        text-align: center;
        background-color: #f8f9fa;
        height: 180px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    #imagePreview {
        max-height: 100%;
        max-width: 100%;
        display: block;
    }

    /* Styles for the image cropping modal */
    .img-container {
        height: 500px;
        overflow: hidden;
        background: #f7f7f7;
    }

    /* Controls for bulk actions, hidden by default */
    .selection-controls {
        display: none;
    }
</style>

<div class="container py-4">
    <div class="card shadow-lg">
        <!-- Card Header -->
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-shuttle-van me-2"></i> Driver Management</h3>
                <div class="d-flex gap-2">
                    <a href="../form/add-driving-route.php" class="btn btn-light btn-sm">
                        <i class="fas fa-plus me-1"></i> Add Driving Route
                    </a>
                    <a href="../form/add-driver.php" class="btn btn-light btn-sm">
                        <i class="fas fa-plus me-1"></i> Add Driver
                    </a>
                </div>
            </div>
        </div>

        <!-- Card Body -->
        <div class="card-body">
            <!-- Search and Filter Controls -->
            <div class="row mb-4 align-items-center">
                <div class="col-md-8">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" id="searchInput" class="form-control" placeholder="Search drivers by name, email, phone, or vehicle...">
                        <select id="statusFilter" class="form-select" style="max-width: 150px;">
                            <option value="">All Status</option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                        <button id="refreshDrivers" class="btn btn-outline-secondary" title="Refresh list">
                            <i class="fas fa-sync-alt"></i>
                        </button>
                    </div>
                </div>
                <!-- Bulk Action Controls -->
                <div class="col-md-4 text-end">
                    <div class="selection-controls">
                        <span id="selectionCount" class="me-3 fw-bold">0 selected</span>
                        <button id="id_cards_download_btn" class="btn btn-primary btn-sm">
                            <i class="fas fa-id-card me-2"></i>Download ID Cards
                        </button>
                    </div>
                </div>
            </div>

            <!-- Drivers Table -->
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 5%;"><input class="form-check-input" type="checkbox" id="selectAllCheckbox"></th>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Vehicle No.</th>
                            <th>Status</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="driversTableBody">
                        <!-- Driver data will be loaded here via AJAX -->
                    </tbody>
                </table>
            </div>

            <!-- Pagination Container -->
            <nav>
                <ul class="pagination justify-content-center mt-3" id="paginationContainer">
                    <!-- Pagination links will be loaded here -->
                </ul>
            </nav>
        </div>
    </div>
</div>

<!-- Edit Driver Modal -->
<div class="modal fade" id="editDriverModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-edit me-2"></i> Edit Driver Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="editDriverModalBody">
                <!-- Edit form will be loaded here via AJAX -->
            </div>
        </div>
    </div>
</div>

<!-- Image Cropping Modal -->
<div class="modal fade" id="cropModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-crop me-2"></i> Crop Image</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="img-container">
                    <img id="modalCropper" src="" class="img-fluid">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" id="confirmCrop" class="btn btn-primary">Crop & Save</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // --- STATE MANAGEMENT ---
        // These variables hold the current state of the page.
        let currentPage = 1;
        const limit = 10; // Number of drivers to show per page.
        let cropper; // Holds the Cropper.js instance.
        let croppedImageBlob = null; // Holds the cropped image data as a Blob.
        let cropConfirmed = false; // Flag to check if cropping was confirmed by the user.
        let selectedDrivers = new Set(); // A Set to store unique IDs of selected drivers for bulk actions.

        // --- CORE FUNCTIONS ---

        /**
         * Loads the list of drivers from the server using AJAX.
         * @param {number} page - The page number to load.
         * @param {string} search - The search query.
         * @param {string} status - The status to filter by ('active' or 'inactive').
         */
        function loadDrivers(page = 1, search = '', status = '') {
            currentPage = page;
            $.ajax({
                // This is the backend script that fetches driver data. You will need to create this file.
                url: '../ajax/get-drivers.php',
                type: 'GET',
                data: {
                    page: page,
                    limit: limit,
                    search: search,
                    status: status
                },
                dataType: 'json',
                beforeSend: function() {
                    // Show a loading spinner while data is being fetched.
                    $('#driversTableBody').html(`<tr><td colspan="8" class="text-center py-4"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>`);
                },
                success: function(response) {
                    const tableBody = $('#driversTableBody');
                    if (response.drivers && response.drivers.length > 0) {
                        let html = '';
                        response.drivers.forEach((driver) => {
                            const isChecked = selectedDrivers.has(driver.id.toString());
                            // Build the HTML for each driver row.
                            html += `
                            <tr id="driver-${driver.id}" class="${isChecked ? 'table-primary' : ''}">
                                <td><input class="form-check-input driver-checkbox" type="checkbox" data-id="${driver.id}" ${isChecked ? 'checked' : ''}></td>
                                <td>${escapeHtml(driver.driver_id)}</td>
                                <td>${escapeHtml(driver.name)}</td>
                                <td>${escapeHtml(driver.email)}</td>
                                <td>${escapeHtml(driver.phone)}</td>
                                <td>${escapeHtml(driver.vehicle_number)}</td>
                                <td>
                                    <span class="badge ${driver.status === 'active' ? 'bg-success' : 'bg-secondary'}">
                                        ${capitalizeFirstLetter(driver.status)}
                                    </span>
                                </td>
                                <td class="text-end">
                                    <div class="dropdown action-dropdown">
                                        <button class="btn btn-sm btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown"><i class="fas fa-cog"></i></button>
                                        <ul class="dropdown-menu dropdown-menu-end">
                                            <li><a class="dropdown-item edit-btn" href="#" data-id="${driver.id}"><i class="fas fa-edit me-2"></i>Edit</a></li>
                                            <li><a class="dropdown-item status-btn" href="#" data-id="${driver.id}" data-status="${driver.status === 'active' ? 'inactive' : 'active'}"><i class="fas fa-power-off me-2"></i>${driver.status === 'active' ? 'Deactivate' : 'Activate'}</a></li>
                                            <li><hr class="dropdown-divider"></li>
                                            <li><a class="dropdown-item delete-btn" href="#" data-id="${driver.id}" data-name="${escapeHtml(driver.name)}"><i class="fas fa-trash-alt me-2 text-danger"></i>Delete</a></li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>`;
                        });
                        tableBody.html(html);
                    } else {
                        // Show a message if no drivers are found.
                        tableBody.html(`<tr><td colspan="8" class="text-center py-5 text-muted"><i class="fas fa-shuttle-van fa-3x mb-3"></i><h4>No drivers found</h4><p>${search ? 'Try a different search term' : 'Add your first driver to get started'}</p></td></tr>`);
                    }
                    // Update the pagination links and selection controls.
                    updatePagination(response.total, page);
                    updateSelectionState();
                },
                error: function() {
                    toastr.error('Failed to load drivers. Please try again.');
                    $('#driversTableBody').html(`<tr><td colspan="8" class="text-center py-5 text-danger">Error loading data. Please refresh the page.</td></tr>`);
                }
            });
        }

        /**
         * Updates the state of bulk action controls based on how many drivers are selected.
         */
        function updateSelectionState() {
            const selectionCount = selectedDrivers.size;
            $('#selectionCount').text(`${selectionCount} selected`);
            $('.selection-controls').toggle(selectionCount > 0);

            // Check or uncheck the "select all" checkbox.
            const allVisibleCheckboxes = $('.driver-checkbox');
            const allVisibleSelected = allVisibleCheckboxes.length > 0 && allVisibleCheckboxes.filter(':checked').length === allVisibleCheckboxes.length;
            $('#selectAllCheckbox').prop('checked', allVisibleSelected);
        }

        /**
         * Generates and displays the pagination links.
         * @param {number} totalRecords - The total number of drivers.
         * @param {number} currentPage - The current active page.
         */
        function updatePagination(totalRecords, currentPage) {
            const totalPages = Math.ceil(totalRecords / limit);
            let html = '';
            if (totalPages <= 1) {
                $('#paginationContainer').html('');
                return;
            }
            // Logic to build pagination links (first, prev, numbers, next, last)
            if (currentPage > 1) {
                html += `<li class="page-item"><a class="page-link" href="#" data-page="1"><i class="fas fa-angle-double-left"></i></a></li>`;
                html += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage - 1}"><i class="fas fa-angle-left"></i></a></li>`;
            }
            const start = Math.max(1, currentPage - 2);
            const end = Math.min(totalPages, currentPage + 2);
            if (start > 1) html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            for (let i = start; i <= end; i++) {
                html += `<li class="page-item ${i === currentPage ? 'active' : ''}"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
            }
            if (end < totalPages) html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            if (currentPage < totalPages) {
                html += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage + 1}"><i class="fas fa-angle-right"></i></a></li>`;
                html += `<li class="page-item"><a class="page-link" href="#" data-page="${totalPages}"><i class="fas fa-angle-double-right"></i></a></li>`;
            }
            $('#paginationContainer').html(html);
        }

        // --- HELPER FUNCTIONS ---
        function escapeHtml(unsafe) {
            if (unsafe === null || typeof unsafe === 'undefined') return '';
            return unsafe.toString().replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
        }

        function capitalizeFirstLetter(string) {
            return string.charAt(0).toUpperCase() + string.slice(1);
        }

        // --- EVENT HANDLERS ---

        // Initial load of drivers when the page is ready.
        loadDrivers();

        // --- Search, Filter, and Refresh Handlers ---
        let searchTimer;
        $('#searchInput').on('input', function() {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => {
                loadDrivers(1, $(this).val(), $('#statusFilter').val())
            }, 500); // Debounce search to avoid excessive AJAX calls.
        });
        $('#statusFilter').change(() => loadDrivers(1, $('#searchInput').val(), $('#statusFilter').val()));
        $('#refreshDrivers').click(() => loadDrivers(currentPage, $('#searchInput').val(), $('#statusFilter').val()));

        // --- Selection Handlers ---
        $('#selectAllCheckbox').on('click', function() {
            const isChecked = $(this).is(':checked');
            $('.driver-checkbox').each(function() {
                const driverId = $(this).data('id').toString();
                if (isChecked) {
                    selectedDrivers.add(driverId);
                    $(this).closest('tr').addClass('table-primary');
                } else {
                    selectedDrivers.delete(driverId);
                    $(this).closest('tr').removeClass('table-primary');
                }
                $(this).prop('checked', isChecked);
            });
            updateSelectionState();
        });

        $(document).on('click', '.driver-checkbox', function() {
            const driverId = $(this).data('id').toString();
            if ($(this).is(':checked')) {
                selectedDrivers.add(driverId);
                $(this).closest('tr').addClass('table-primary');
            } else {
                selectedDrivers.delete(driverId);
                $(this).closest('tr').removeClass('table-primary');
            }
            updateSelectionState();
        });
        
        // --- Pagination Handler ---
        $(document).on('click', '.page-link', function(e) {
            e.preventDefault();
            const page = $(this).data('page');
            if (page) {
                loadDrivers(page, $('#searchInput').val(), $('#statusFilter').val());
            }
        });

        // --- Edit Action ---
        $(document).on('click', '.edit-btn', function(e) {
            e.preventDefault();
            const driverId = $(this).data('id');
            croppedImageBlob = null; // Reset cropped image state

            $.ajax({
                // This script fetches a single driver's data. You will need to create this.
                url: '../ajax/get-driver.php',
                type: 'GET',
                data: { id: driverId },
                dataType: 'json',
                beforeSend: function() {
                    $('#editDriverModalBody').html(`<div class="text-center py-4"><div class="spinner-border text-primary"></div></div>`);
                    $('#editDriverModal').modal('show');
                },
                success: function(response) {
                    if (response.success) {
                        const driver = response.driver;
                        // Populate the modal with the driver's data in a form.
                        $('#editDriverModalBody').html(`
                        <form id="editDriverForm">
                            <input type="hidden" name="id" value="${driver.id}">
                            <div class="row g-3">
                                <div class="col-md-6"><label class="form-label fw-bold">Driver ID</label><input type="text" name="driver_id" class="form-control" value="${escapeHtml(driver.driver_id)}" readonly></div>
                                <div class="col-md-6"><label class="form-label fw-bold">Full Name</label><input type="text" name="name" class="form-control" value="${escapeHtml(driver.name)}" required></div>
                                <div class="col-md-6"><label class="form-label fw-bold">Email</label><input type="email" name="email" class="form-control" value="${escapeHtml(driver.email)}" required></div>
                                <div class="col-md-6"><label class="form-label fw-bold">Phone</label><input type="text" name="phone" class="form-control" value="${escapeHtml(driver.phone)}" required></div>
                                <div class="col-md-6"><label class="form-label fw-bold">Vehicle No.</label><input type="text" name="vehicle_number" class="form-control" value="${escapeHtml(driver.vehicle_number)}" required></div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Route</label>
                                    <select name="route" class="form-select" required>
                                        <option value="">Select Route</option>
                                        <?php foreach ($routes as $route): ?>
                                            <option value="<?php echo $route['id']; ?>" ${driver.route_id == '<?php echo $route['id']; ?>' ? 'selected' : ''}><?php echo safe_htmlspecialchars($route['route_name']); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-bold">Driver Photo</label>
                                    <div class="image-preview-wrapper">
                                        <img id="imagePreview" src="../../uploads/drivers/${driver.driver_image || 'default_driver_dp.jpg'}">
                                    </div>
                                    <input type="file" id="driverPhoto" name="driver_photo" class="form-control" accept="image/*">
                                    <div class="form-text">Optional. Upload a new photo with a 5:6 aspect ratio.</div>
                                    ${driver.driver_image ? `<div class="form-check mt-2"><input class="form-check-input" type="checkbox" name="remove_photo" id="removePhoto"><label class="form-check-label" for="removePhoto">Remove current photo</label></div>` : ''}
                                </div>
                            </div>
                            <div class="text-end mt-4">
                                <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary"><i class="fas fa-save me-2"></i>Save Changes</button>
                            </div>
                        </form>
                    `);
                    } else {
                        toastr.error(response.message);
                        $('#editDriverModal').modal('hide');
                    }
                },
                error: () => toastr.error('Failed to load driver data.')
            });
        });
        
        // --- Edit Form Submission ---
        $(document).on('submit', '#editDriverForm', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            if (croppedImageBlob) {
                formData.append('cropped_image', croppedImageBlob, 'driver_photo.jpg');
            }
            formData.delete('driver_photo');

            $.ajax({
                // This script handles the update logic. You will need to create this.
                url: '../action/update-driver.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        $('#editDriverModal').modal('hide');
                        loadDrivers(currentPage, $('#searchInput').val(), $('#statusFilter').val());
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: () => toastr.error('An error occurred. Please try again.')
            });
        });

        // --- Image Cropping Logic ---
        $(document).on('change', '#driverPhoto', function(e) {
            if (this.files && this.files[0]) {
                cropConfirmed = false;
                const reader = new FileReader();
                reader.onload = (event) => {
                    $('#modalCropper').attr('src', event.target.result);
                    $('#cropModal').modal('show');
                };
                reader.readAsDataURL(this.files[0]);
            }
        });
        $('#cropModal').on('shown.bs.modal', function() {
            if (cropper) cropper.destroy();
            cropper = new Cropper(document.getElementById('modalCropper'), {
                aspectRatio: 5 / 6,
                viewMode: 1
            });
        });
        $('#confirmCrop').click(function() {
            if (!cropper) return;
            cropper.getCroppedCanvas({ width: 500, height: 600 }).toBlob((blob) => {
                croppedImageBlob = blob;
                $('#imagePreview').attr('src', URL.createObjectURL(blob));
                cropConfirmed = true;
                $('#cropModal').modal('hide');
            }, 'image/jpeg', 0.9);
        });
        $('#cropModal').on('hidden.bs.modal', function() {
            if (!cropConfirmed) $('#driverPhoto').val(null);
            if (cropper) {
                cropper.destroy();
                cropper = null;
            }
        });

        // --- Status Change Action ---
        $(document).on('click', '.status-btn', function(e) {
            e.preventDefault();
            const driverId = $(this).data('id');
            const newStatus = $(this).data('status');
            const action = newStatus === 'active' ? 'activate' : 'deactivate';

            Swal.fire({
                title: `Are you sure?`,
                text: `Do you want to ${action} this driver?`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: `Yes, ${action}!`
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        // This script updates the status. You will need to create this.
                        url: '../action/update-driver-status.php',
                        type: 'POST',
                        data: { id: driverId, status: newStatus },
                        dataType: 'json',
                        success: (response) => {
                            if (response.success) {
                                toastr.success(response.message);
                                loadDrivers(currentPage, $('#searchInput').val(), $('#statusFilter').val());
                            } else {
                                toastr.error(response.message);
                            }
                        },
                        error: () => toastr.error('An error occurred.')
                    });
                }
            });
        });

        // --- Delete Action ---
        $(document).on('click', '.delete-btn', function(e) {
            e.preventDefault();
            const driverId = $(this).data('id');
            const driverName = $(this).data('name');

            Swal.fire({
                title: 'Delete Driver',
                html: `Are you sure you want to delete <strong>${driverName}</strong>? This action cannot be undone.`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        // This script handles deletion. You will need to create this.
                        url: '../action/delete-driver.php',
                        type: 'POST',
                        data: { id: driverId },
                        dataType: 'json',
                        success: (response) => {
                            if (response.success) {
                                toastr.success(response.message);
                                selectedDrivers.delete(driverId.toString());
                                loadDrivers(1, $('#searchInput').val(), $('#statusFilter').val());
                            } else {
                                toastr.error(response.message);
                            }
                        },
                        error: () => toastr.error('An error occurred.')
                    });
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>
