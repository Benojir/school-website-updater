<?php

/** @var string $school_name */
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Dashboard - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

$stats = [];
// Super admins are automatically allowed by hasPermission.
$can_see_financial_data = hasPermission(PERM_CAN_SEE_FINANCIAL_REPORT);

// ==========================================
// 1. USER & CLASS STATISTICS
// ==========================================
// One master row per student: count every status once, regardless of enrollment history.
$dashboardAcademicYear = academicCurrentYear($pdo);
$stmt = $pdo->query("SELECT COUNT(*) FROM students");
$stats['total_students'] = (int)$stmt->fetchColumn();
$stats['total_active_students'] = null;
if ($dashboardAcademicYear !== null) {
    // The yearly record is authoritative; the compatibility profile may carry another status.
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM students s
                          WHERE EXISTS (
                              SELECT 1 FROM student_academic_records ar
                              WHERE ar.student_row_id = s.id
                                AND ar.academic_year = :academic_year
                                AND ar.status = 'Active'
                          )");
    $stmt->execute([':academic_year' => $dashboardAcademicYear]);
    $stats['total_active_students'] = (int)$stmt->fetchColumn();
}

$stmt = $pdo->query("SELECT COUNT(*) as total FROM teachers WHERE status = 'active'");
$stats['total_teachers'] = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM classes");
$stats['total_classes'] = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT c.class_name, COUNT(s.id) as student_count 
                    FROM classes c 
                    LEFT JOIN students s ON c.id = s.class_id AND s.status = 'Active'
                    GROUP BY c.id 
                    ORDER BY c.id");
$stats['students_by_class'] = $stmt->fetchAll();

$stmt = $pdo->query("SELECT COUNT(*) as total FROM parent_auth_sessions WHERE fcm_token IS NOT NULL AND fcm_token != ''");
$stats['total_parent_app_installs'] = $stmt->fetch()['total'];

$stmt = $pdo->query("SELECT COUNT(*) as total FROM driver_auth_sessions WHERE fcm_token IS NOT NULL AND fcm_token != ''");
$stats['total_driver_app_installs'] = $stmt->fetch()['total'];


// ==========================================
// 2. FINANCIAL STATISTICS (FEES & WALLET)
// ==========================================
// Wallet
if ($can_see_financial_data) {
    $stmt = $pdo->prepare("SELECT SUM(balance) as total FROM student_wallet");
    $stmt->execute();
    $stats['total_wallet_balance'] = $stmt->fetch()['total'] ?? 0;

    // This month's collections: use actual payment dates, including partial payments.
    $collectionMonthStart = new DateTimeImmutable('first day of this month midnight');
    $collectionNextMonth = $collectionMonthStart->modify('+1 month');
    $stmt = $pdo->prepare("SELECT
        (SELECT COALESCE(SUM(payment_amount), 0) FROM student_payment_history
         WHERE payment_date >= ? AND payment_date < ?) AS monthly,
        (SELECT COALESCE(SUM(payment_amount), 0) FROM admission_fees_payment_history
         WHERE payment_date >= ? AND payment_date < ?) AS admission");
    $stmt->execute([
        $collectionMonthStart->format('Y-m-d'), $collectionNextMonth->format('Y-m-d'),
        $collectionMonthStart->format('Y-m-d'), $collectionNextMonth->format('Y-m-d')
    ]);
    $monthCollections = $stmt->fetch(PDO::FETCH_ASSOC);
    $stats['this_month_monthly_fees'] = (float)$monthCollections['monthly'];
    $stats['this_month_admission_fees'] = (float)$monthCollections['admission'];
    $stats['this_month_total_fees'] = $stats['this_month_monthly_fees'] + $stats['this_month_admission_fees'];

    // Monthly Fees
    $stmt = $pdo->query("SELECT SUM(unpaid_amount) as total FROM student_unpaid_fees");
    $stats['lifetime_monthly_fees_pending'] = $stmt->fetch()['total'] ?? 0;

    $stmt = $pdo->query("SELECT SUM(payment_amount) as total FROM student_payment_history");
    $stats['lifetime_monthly_fees_collected'] = $stmt->fetch()['total'] ?? 0;

    $stmt = $pdo->query("SELECT COUNT(DISTINCT student_id) AS total FROM student_unpaid_fees WHERE unpaid_amount > 0");
    $stats['total_students_with_unpaid_monthly_fees'] = $stmt->fetch()['total'] ?? 0;

    // Admission Fees
    $stmt = $pdo->query("SELECT SUM(unpaid_amount) as unpaid_amount FROM admission_unpaid_fees");
    $stats['lifetime_total_unpaid_admission_fees'] = $stmt->fetch()['unpaid_amount'] ?? 0;

    $stmt = $pdo->query("SELECT SUM(payment_amount) as total FROM admission_fees_payment_history");
    $stats['lifetime_total_admission_fees_collected'] = $stmt->fetch()['total'] ?? 0;

    $stmt = $pdo->query("SELECT COUNT(DISTINCT student_id) AS total FROM admission_unpaid_fees WHERE unpaid_amount > 0");
    $stats['total_students_with_unpaid_admission_fees'] = $stmt->fetch()['total'] ?? 0;

    // Additional Fees
    $stmt = $pdo->query("SELECT SUM(class_wise_additional_fees.amount) AS unpaid_amount
                         FROM additional_fees_data
                         INNER JOIN class_wise_additional_fees ON additional_fees_data.additional_fee_setup_id = class_wise_additional_fees.id
                         WHERE additional_fees_data.additional_fee_status = 'unpaid'");
    $stats['lifetime_total_unpaid_additional_fees'] = $stmt->fetch()['unpaid_amount'] ?? 0;

    $stmt = $pdo->query("SELECT SUM(class_wise_additional_fees.amount) AS paid_amount
                         FROM additional_fees_data
                         INNER JOIN class_wise_additional_fees ON additional_fees_data.additional_fee_setup_id = class_wise_additional_fees.id
                         WHERE additional_fees_data.additional_fee_status = 'paid'");
    $stats['lifetime_total_paid_additional_fees'] = $stmt->fetch()['paid_amount'] ?? 0;

    $stmt = $pdo->query("SELECT COUNT(DISTINCT student_id) AS total FROM additional_fees_data WHERE additional_fee_status = 'unpaid'");
    $stats['total_students_with_unpaid_additional_fees'] = $stmt->fetch()['total'] ?? 0;

    // Total Pending
    $stats['lifetime_pending_fees'] = $stats['lifetime_monthly_fees_pending'] + $stats['lifetime_total_unpaid_admission_fees'] + $stats['lifetime_total_unpaid_additional_fees'];

}


// ==========================================
// 3. EXAMS & NOTICES STATISTICS
// ==========================================
$stmt = $pdo->query("SELECT * FROM exams 
                    WHERE status = 'active' 
                    AND exam_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY) 
                    ORDER BY exam_date LIMIT 3");
$stats['upcoming_exams'] = $stmt->fetchAll();

$stmt = $pdo->query("SELECT title, notice_date FROM notices ORDER BY notice_date DESC LIMIT 3");
$stats['latest_notices'] = $stmt->fetchAll();
?>

<style>
    .list-group-item:hover {
        background-color: rgb(235, 235, 235);
    }
    
    /* Responsive sizing for School Overview cards on mobile */
    @media (max-width: 767.98px) {
        .school-overview-cards .card-body {
            padding: 0.75rem;
        }
        .school-overview-cards .h4 {
            font-size: 1.1rem;
        }
        .school-overview-cards .h5 {
            font-size: 1rem;
        }
        .school-overview-cards .fa-2x {
            font-size: 1.5em;
        }
        .school-overview-cards .ms-3 {
            margin-left: 0.5rem !important;
        }
        .school-overview-cards .small {
            font-size: 0.7rem;
        }
    }
</style>

<div class="container py-3">

    <?php if (isSuperAdmin() && !empty($subscriptions)) : ?>
        <h3 class="mb-3 text-secondary"><i class="fas fa-coins me-2"></i> Subscription Overview</h3>

        <?php if (!empty($subscription_access['payment_warning'])) : ?>
            <div class="alert alert-warning shadow-sm border-warning rounded-4" role="alert">
                <div class="d-flex align-items-center mb-2">
                    <i class="fas fa-triangle-exclamation fs-4 me-2"></i>
                    <h5 class="alert-heading mb-0 fw-bold">Subscription Payment Reminder</h5>
                </div>
                <p class="mb-2">Outstanding balance:
                    <strong><?= safe_htmlspecialchars($currency_symbol) . number_format($subscription_access['subscription_due_amount'], 2) ?></strong>.
                    Please pay in full by <strong><?= formatDate($subscriptions['subscription_payment_due_at']) ?></strong>
                    <?php if ($subscription_access['payment_days_left'] === 0): ?>(today).<?php else: ?>(<?= $subscription_access['payment_days_left'] ?> days remaining).<?php endif; ?>
                </p>
                <p class="small mb-3">Website access will be suspended after this date if a subscription balance remains, even if your subscription is still valid.</p>
                <a href="<?= BASE_URL ?>/management/dashboard/subscription-account.php" target="_blank" rel="noopener" class="btn btn-warning fw-semibold">View Subscription Account</a>
            </div>
        <?php endif; ?>

        <?php if ($subscription_days_left <= 30) : ?>
            <div class="alert alert-danger shadow-sm border border-danger" style="border-left-width: 4px !important;" role="alert">
                <div class="d-flex align-items-center mb-2">
                    <i class="fas fa-triangle-exclamation fs-4 me-2"></i>
                    <h5 class="alert-heading mb-0 fw-bold">Subscription Expiring Soon!</h5>
                </div>
                <hr class="border-danger opacity-25">
                <p class="mb-2">
                    Your subscription will expire on <strong class="fs-5 text-danger"><?= formatDate($subscriptions['subscription_end_at']) ?></strong>. Please renew your subscription. Otherwise, you cannot access your website.
                </p>
                <p class="mb-3 small">
                    <i class="text-muted">You must clear your due fees to renew your subscription if not already done.</i>
                </p>
                <a href="tel:+919083156928" class="btn btn-danger fw-bold shadow-sm">
                    Contact Support
                </a>
            </div>
        <?php endif; ?>

        <div class="row g-4 mb-4">
            <div class="col-xl-6 col-md-6" style="cursor: pointer; user-select: none;" onclick="window.open('<?= BASE_URL ?>/management/dashboard/subscription-account.php')">
                <div class="card shadow-sm h-100 border-1 bg-opacity-10 <?= $subscriptions['current_subscription_total'] >= 0 ? 'bg-success border-success' : 'bg-danger border-danger' ?>">
                    <div class="card-body">
                        <div class="d-flex align-items-center h-100">
                            <div class="flex-grow-1">
                                <?php
                                $subscription_due = $subscriptions['current_subscription_total'];
                                if ($subscription_due > 0) {
                                    echo '<div class="small fw-bold text-success">Subscription Advanced</div>';
                                    echo '<div class="h4 mb-0 text-success fw-bold">' . $currency_symbol . number_format($subscription_due, 2) . '</div>';
                                } else if ($subscription_due == 0) {
                                    echo '<div class="small fw-bold text-success">Subscription Due</div>';
                                    echo '<div class="h4 mb-0 text-success fw-bold">' . $currency_symbol . '0.00</div>';
                                } else {
                                    echo '<div class="small fw-bold text-danger">Subscription Due</div>';
                                    echo '<div class="h4 mb-0 text-danger fw-bold">' . $currency_symbol . number_format(abs($subscription_due), 2) . '</div>';
                                }
                                ?>
                                <div class="text-muted small mt-1">Subscription: <b class="<?= $subscriptions['current_subscription_total'] >= 0 ? 'text-success' : 'text-danger' ?>"><?= formatDate($subscriptions['subscription_start_at']) ?></b> to <b class="<?= $subscriptions['current_subscription_total'] >= 0 ? 'text-success' : 'text-danger' ?>"><?= formatDate($subscriptions['subscription_end_at']) ?></b></div>
                                <?php if (!empty($subscriptions['subscription_payment_due_at'])): ?>
                                    <div class="small text-muted mt-2">Payment deadline: <strong><?= formatDate($subscriptions['subscription_payment_due_at']) ?></strong></div>
                                <?php endif; ?>
                            </div>
                            <div class="ms-3">
                                <i class="fas fa-crown fa-2x <?= $subscriptions['current_subscription_total'] >= 0 ? 'text-success' : 'text-danger' ?>"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-6 col-md-6" style="cursor: pointer; user-select: none;" onclick="window.open('<?= BASE_URL ?>/management/dashboard/subscription-account.php?target=sms')">
                <div class="card shadow-sm h-100 border-1 bg-opacity-10 bg-info border-info">
                    <div class="card-body">
                        <div class="d-flex align-items-center h-100">
                            <div class="flex-grow-1">
                                <div class="small fw-bold text-info">SMS Balance</div>
                                <div class="h4 mb-0 fw-bold"><?= $currency_symbol . $subscriptions['current_sms_balance'] ?></div>
                                <div class="text-muted small mt-1">Rate: <?= $currency_symbol . $subscriptions['sms_price'] ?>/SMS & <?= $currency_symbol . $subscriptions['wasms_price'] ?>/WA SMS</div>
                            </div>
                            <div class="ms-3">
                                <i class="fas fa-sms fa-2x text-info"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <h3 class="mb-3 text-secondary"><i class="fas fa-school me-2"></i> School Overview</h3>

    <div class="row g-4 mb-4 school-overview-cards align-items-start">
        <div class="col-6 col-md-6 col-xl-3" onclick="location.href='../student/list-students.php';" style="cursor: pointer; user-select: none;">
            <div class="card border-start-3 border-start-primary shadow-sm h-100"
                 title="<?= safe_htmlspecialchars($dashboardAcademicYear !== null
                     ? 'Active students in academic year ' . $dashboardAcademicYear . ' (School Settings) / Total unique students across all years and statuses, including Active, Left and Alumni.'
                     : 'Set the academic year in School Settings to see the active count. Total unique students includes all years and statuses.') ?>">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Total Students</div>
                            <div class="h4 mb-0"><?= $stats['total_active_students'] === null ? '—' : number_format($stats['total_active_students']) ?>/<?= number_format($stats['total_students']) ?></div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-users fa-2x text-primary opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-6 col-md-6 col-xl-3" onclick="location.href='../teacher/list-teachers.php';" style="cursor: pointer;">
            <div class="card border-start-3 border-start-success shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Total Teachers</div>
                            <div class="h4 mb-0"><?= $stats['total_teachers'] ?></div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-chalkboard-teacher fa-2x text-success opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-6 col-md-6 col-xl-3">
            <div class="card border-start-3 border-start-info shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Total Classes</div>
                            <div class="h4 mb-0"><?= $stats['total_classes'] ?></div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-school fa-2x text-info opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-6 col-md-6 col-xl-3 fees-info-card" onclick="location.href='../fees-x-payments/wallet/manage-student-wallets.php';" style="cursor: pointer; user-select: none;">
            <div class="card border-start-3 border-start-warning shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Total Wallet Balance</div>
                            <div class="h4 mb-0"><?= $can_see_financial_data ? '₹' . number_format($stats['total_wallet_balance'], 2) : '-' ?></div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-wallet fa-2x text-success opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-6 col-md-6 col-xl-3 fees-info-card" title="Lifetime Total Pending Unpaid Admission Fees">
            <div class="card border-start-3 border-start-danger shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Unpaid Admission Fees</div>
                            <div class="h4 mb-0"><?= $can_see_financial_data ? '₹' . number_format($stats['lifetime_total_unpaid_admission_fees'], 2) : '-' ?></div>
                            <div class="text-muted small"><?= $can_see_financial_data ? '(' . number_format($stats['total_students_with_unpaid_admission_fees'], 0) . ' students)' : '-' ?></div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-exclamation-triangle fa-2x text-danger opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-6 col-md-6 col-xl-3 fees-info-card" title="Lifetime Total Pending Unpaid Monthly Fees">
            <div class="card border-start-3 border-start-danger shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Unpaid Monthly Fees</div>
                            <div class="h4 mb-0"><?= $can_see_financial_data ? '₹' . number_format($stats['lifetime_monthly_fees_pending'], 2) : '-' ?></div>
                            <div class="text-muted small"><?= $can_see_financial_data ? '(' . number_format($stats['total_students_with_unpaid_monthly_fees'], 0) . ' students)' : '-' ?></div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-exclamation-triangle fa-2x text-danger opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-6 col-md-6 col-xl-3 fees-info-card" title="Lifetime Total Pending Unpaid Additional Fees">
            <div class="card border-start-3 border-start-danger shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Unpaid Additional Fees</div>
                            <div class="h4 mb-0"><?= $can_see_financial_data ? '₹' . number_format($stats['lifetime_total_unpaid_additional_fees'], 2) : '-' ?></div>
                            <div class="text-muted small"><?= $can_see_financial_data ? '(' . number_format($stats['total_students_with_unpaid_additional_fees'], 0) . ' students)' : '-' ?></div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-exclamation-triangle fa-2x text-danger opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-6 col-md-6 col-xl-3 fees-info-card" title="Lifetime Total Pending Unpaid Fees">
            <div class="card border-start-3 border-start-danger shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Total Unpaid Fees</div>
                            <div class="h4 mb-0"><?= $can_see_financial_data ? '₹' . number_format($stats['lifetime_pending_fees'], 2) : '-' ?></div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-exclamation-triangle fa-2x text-danger opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-6 col-md-6 col-xl-3 fees-info-card" title="Monthly and admission payments dated within <?= date('F Y') ?>" onclick="location.href='<?= BASE_URL ?>/management/fees-x-payments/manage-payment-history-admission-x-monthly.php';" style="cursor: pointer; user-select: none;">
            <div class="card border-start-3 border-start-warning shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center mb-2">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Fees Collected (<?= date('F') ?>)</div>
                            <div class="h4 mb-0"><?= $can_see_financial_data ? '₹' . number_format($stats['this_month_total_fees'], 2) : '-' ?></div>
                            <div class="text-muted small">Total (Monthly + Admission)</div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-money-bill-wave fa-2x text-warning opacity-100"></i>
                        </div>
                    </div>
                    <div class="small d-flex justify-content-between flex-wrap gap-1">
                        <span class="text-muted">Monthly</span>
                        <span class="fw-semibold"><?= $can_see_financial_data ? '₹' . number_format($stats['this_month_monthly_fees'], 2) : '-' ?></span>
                    </div>
                    <div class="small d-flex justify-content-between flex-wrap gap-1">
                        <span class="text-muted">Admission</span>
                        <span class="fw-semibold"><?= $can_see_financial_data ? '₹' . number_format($stats['this_month_admission_fees'], 2) : '-' ?></span>
                    </div>
                </div>
            </div>
        </div>

        <?php include __DIR__ . '/../../includes/dashboard-today-fees.php'; ?>

        <?php include __DIR__ . '/../../includes/dashboard-salary-payments.php'; ?>

        <?php include __DIR__ . '/../../includes/dashboard-monthly-fee-categories.php'; ?>

        <div class="col-6 col-md-6 col-xl-3" style="cursor: pointer; user-select: none;" onclick="window.location.href='../parent/parent-app-installs.php'">
            <div class="card border-start-3 border-start-warning shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Parent App Installs</div>
                            <div class="h5 mb-0"><?= $stats['total_parent_app_installs'] ?> active devices</div>
                        </div>
                        <div class="ms-3">
                            <i class="fa-brands fa-android fa-2x text-success opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-6 col-md-6 col-xl-3" style="cursor: pointer; user-select: none;">
            <div class="card border-start-3 border-start-warning shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Driver App Installs</div>
                            <div class="h5 mb-0"><?= $stats['total_driver_app_installs'] ?> active devices</div>
                        </div>
                        <div class="ms-3">
                            <i class="fa-brands fa-android fa-2x text-success opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12">
            <?php include __DIR__ . '/../../includes/inventory/dashboard-summary.php'; ?>
        </div>

        <div class="row g-4 mx-0 px-0">

            <div class="col-lg-6">
                <div class="card shadow-sm h-100">
                    <div class="card-header bg-white border-bottom-0 py-3" style="border-left: 5px solid <?= $theme_color ?>">
                        <h5 class="mb-0">Students by Class</h5>
                    </div>
                    <div class="card-body pt-0">
                        <div class="chart-container" style="height: 300px;">
                            <canvas id="studentsByClassChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Current Year Monthly Fees Collection Chart -->
            <div class="col-lg-6 fees-info-card">
                <div class="card shadow-sm h-100">
                    <div class="card-header bg-white border-bottom-0 py-3" style="border-left: 5px solid <?= $theme_color ?>">
                        <h5 class="mb-0">Monthly Fees Collection Overview (<?= date('Y') ?>)</h5>
                    </div>
                    <div class="card-body pt-0">
                        <div class="chart-container" style="height: 300px;">
                            <?php if ($can_see_financial_data): ?>
                                <canvas id="monthlyFeesCollectionChart"></canvas>
                            <?php else: ?>
                                <div class="h-100 d-flex align-items-center justify-content-center text-muted">-</div>
                            <?php endif; ?>
                        </div>
                        <div class="mt-3 d-flex justify-content-center">
                            <div class="me-4">
                                <span class="badge bg-success me-2">&nbsp;</span>
                                <span id="total-paid-fees-text-monthly">Paid Fees</span>
                            </div>
                            <div>
                                <span class="badge bg-danger me-2">&nbsp;</span>
                                <span id="total-pending-fees-text-monthly">Pending Fees</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Previous Year Monthly Fees Collection Chart -->
            <div class="col-lg-6 fees-info-card">
                <div class="card shadow-sm h-100">
                    <div class="card-header bg-white border-bottom-0 py-3" style="border-left: 5px solid <?= $theme_color ?>">
                        <h5 class="mb-0">Monthly Fees Collection Overview (<?= date('Y', strtotime('-1 year')) ?>)</h5>
                    </div>
                    <div class="card-body pt-0">
                        <div class="chart-container" style="height: 300px;">
                            <?php if ($can_see_financial_data): ?>
                                <canvas id="monthlyFeesCollectionPrevYearChart"></canvas>
                            <?php else: ?>
                                <div class="h-100 d-flex align-items-center justify-content-center text-muted">-</div>
                            <?php endif; ?>
                        </div>
                        <div class="mt-3 d-flex justify-content-center">
                            <div class="me-4">
                                <span class="badge bg-success me-2">&nbsp;</span>
                                <span id="total-paid-fees-text-monthly-prev">Paid Fees</span>
                            </div>
                            <div>
                                <span class="badge bg-danger me-2">&nbsp;</span>
                                <span id="total-pending-fees-text-monthly-prev">Pending Fees</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 fees-info-card">
                <div class="card shadow-sm h-100">
                    <div class="card-header bg-white border-bottom-0 py-3" style="border-left: 5px solid <?= $theme_color ?>">
                        <h5 class="mb-0">Admission Fees Collection Overview (12 Years)</h5>
                    </div>
                    <div class="card-body pt-0">
                        <div class="chart-container" style="height: 300px;">
                            <?php if ($can_see_financial_data): ?>
                                <canvas id="admissionFeesCollectionChart"></canvas>
                            <?php else: ?>
                                <div class="h-100 d-flex align-items-center justify-content-center text-muted">-</div>
                            <?php endif; ?>
                        </div>
                        <div class="mt-3 d-flex justify-content-center">
                            <div class="mt-3 d-flex justify-content-center">
                                <div class="me-4">
                                    <span class="badge bg-success me-2">&nbsp;</span>
                                    <span>Paid Fees</span>
                                </div>
                                <div>
                                    <span class="badge bg-danger me-2">&nbsp;</span>
                                    <span>Pending Fees</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 fees-info-card">
                <div class="card shadow-sm h-100">
                    <div class="card-header bg-white border-bottom-0 py-3" style="border-left: 5px solid <?= $theme_color ?>" title="Lifetime Monthly Fees Collected.">
                        <h5 class="mb-0">Monthly Fees Collected</h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container" style="height: 200px;">
                            <?php if ($can_see_financial_data): ?>
                                <canvas id="lifetimeMonthlyFeesChart"></canvas>
                            <?php else: ?>
                                <div class="h-100 d-flex align-items-center justify-content-center text-muted">-</div>
                            <?php endif; ?>
                        </div>
                        <div class="mt-3 text-center">
                            <div class="d-flex justify-content-center">
                                <div class="me-4">
                                    <span class="badge bg-success me-2">&nbsp;</span>
                                    <span>Collected: <?= $can_see_financial_data ? '₹' . number_format($stats['lifetime_monthly_fees_collected'], 2) : '-' ?></span>
                                </div>
                                <div>
                                    <span class="badge bg-danger me-2">&nbsp;</span>
                                    <span>Pending: <?= $can_see_financial_data ? '₹' . number_format($stats['lifetime_monthly_fees_pending'], 2) : '-' ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 fees-info-card">
                <div class="card shadow-sm h-100">
                    <div class="card-header bg-white border-bottom-0 py-3" style="border-left: 5px solid <?= $theme_color ?>" title="Lifetime Admission Fees Collected.">
                        <h5 class="mb-0">Admission Fees Collected</h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container" style="height: 200px;">
                            <?php if ($can_see_financial_data): ?>
                                <canvas id="lifetimeAdmissionFeesChart"></canvas>
                            <?php else: ?>
                                <div class="h-100 d-flex align-items-center justify-content-center text-muted">-</div>
                            <?php endif; ?>
                        </div>
                        <div class="mt-3 text-center">
                            <div class="d-flex justify-content-center">
                                <div class="me-4">
                                    <span class="badge bg-success me-2">&nbsp;</span>
                                    <span>Collected: <?= $can_see_financial_data ? '₹' . number_format($stats['lifetime_total_admission_fees_collected'], 2) : '-' ?></span>
                                </div>
                                <div>
                                    <span class="badge bg-danger me-2">&nbsp;</span>
                                    <span>Pending: <?= $can_see_financial_data ? '₹' . number_format($stats['lifetime_total_unpaid_admission_fees'], 2) : '-' ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="card shadow-sm h-100">
                            <div class="card-header bg-white border-bottom-0 py-3" style="border-left: 5px solid <?= $theme_color ?>">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0">Upcoming Exams</h5>
                                    <a href="../exam/list-exams.php" class="btn btn-sm btn-outline-primary">View All</a>
                                </div>
                            </div>
                            <div class="card-body">
                                <?php if (empty($stats['upcoming_exams'])): ?>
                                    <div class="text-center py-4">
                                        <i class="fas fa-calendar-check fa-2x text-muted mb-3"></i>
                                        <p class="text-muted mb-0">No upcoming exams</p>
                                    </div>
                                <?php else: ?>
                                    <div class="list-group list-group-flush">
                                        <?php foreach ($stats['upcoming_exams'] as $exam): ?>
                                            <div class="list-group-item border-0 px-0 py-2">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <h6 class="mb-1"><?= safe_htmlspecialchars($exam['exam_name']) ?></h6>
                                                        <small class="text-muted"><?= date('M j, Y', strtotime($exam['exam_date'])) ?></small>
                                                    </div>
                                                    <span class="badge bg-primary rounded-pill">
                                                        <?= date('D', strtotime($exam['exam_date'])) ?>
                                                    </span>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="card shadow-sm h-100">
                            <div class="card-header bg-white border-bottom-0 py-3" style="border-left: 5px solid <?= $theme_color ?>">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0">Latest Notices</h5>
                                    <a href="../notice/manage-school-notices.php" class="btn btn-sm btn-outline-primary">View All</a>
                                </div>
                            </div>
                            <div class="card-body">
                                <?php if (empty($stats['latest_notices'])): ?>
                                    <div class="text-center py-4">
                                        <i class="fas fa-bullhorn fa-2x text-muted mb-3"></i>
                                        <p class="text-muted mb-0">No notices available</p>
                                    </div>
                                <?php else: ?>
                                    <div class="list-group list-group-flush">
                                        <?php foreach ($stats['latest_notices'] as $notice): ?>
                                            <div class="list-group-item border-bottom px-0 py-2">
                                                <h6 class="mb-1"><?= safe_htmlspecialchars($notice['title']) ?></h6>
                                                <small class="text-muted">Posted on <?= date('M j, Y', strtotime($notice['notice_date'])) ?></small>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Keep the overview visible; only authorized admins load financial charts.
            initStudentsByClassChart();
            <?php if ($can_see_financial_data): ?>
            loadMonthlyFeesChart();
            loadPreviousYearMonthlyFeesChart();
            loadAdmissionFeesChart();
            initLifetimeMonthlyDoughnut();
            initLifetimeAdmissionDoughnut();
            <?php endif; ?>
        });

        // --- Functions --- //

        function initStudentsByClassChart() {
            const classNames = <?= json_encode(array_column($stats['students_by_class'], 'class_name')) ?>;
            const studentCounts = <?= json_encode(array_column($stats['students_by_class'], 'student_count')) ?>;
            const ctx = $('#studentsByClassChart');

            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: classNames,
                    datasets: [{
                        label: 'Students',
                        data: studentCounts,
                        backgroundColor: '<?= $theme_color ?>',
                        borderColor: '<?= $theme_color ?>',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                stepSize: 1,
                                precision: 0
                            },
                            grid: {
                                display: true,
                                drawBorder: false
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            callbacks: {
                                label: (ctx) => ctx.parsed.y + ' students'
                            }
                        }
                    }
                }
            });
        }

        <?php if ($can_see_financial_data): ?>
        function loadMonthlyFeesChart() {
            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/get/fees-x-payments/monthly/get-monthly-fees-data-current-year.php',
                method: 'GET',
                dataType: 'json',
                success: function(feesData) {
                    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                    const currentMonth = new Date().getMonth();
                    const displayedMonths = months.slice(0, 12 + 1);
                    // const displayedMonths = months.slice(0, currentMonth + 1);

                    const paidFees = [];
                    const pendingFees = [];

                    for (let i = 0; i <= 12; i++) {
                        const monthData = feesData.find(item => item.month === (i + 1));
                        paidFees.push(monthData ? parseFloat(monthData.paid) : 0);
                        pendingFees.push(monthData ? parseFloat(monthData.pending) : 0);
                    }

                    const totalPaid = paidFees.reduce((a, b) => a + b, 0);
                    const totalPending = pendingFees.reduce((a, b) => a + b, 0);
                    const formatCur = (amt) => '₹' + amt.toLocaleString('en-IN', {
                        minimumFractionDigits: 2
                    });

                    $('#total-paid-fees-text-monthly').text(`Paid Fees (${formatCur(totalPaid)})`);
                    $('#total-pending-fees-text-monthly').text(`Pending Fees (${formatCur(totalPending)})`);

                    new Chart($('#monthlyFeesCollectionChart'), {
                        type: 'bar',
                        data: {
                            labels: displayedMonths,
                            datasets: [{
                                    label: 'Paid Fees',
                                    data: paidFees,
                                    backgroundColor: '#28a745',
                                    borderColor: '#28a745',
                                    borderWidth: 1
                                },
                                {
                                    label: 'Pending Fees',
                                    data: pendingFees,
                                    backgroundColor: '#dc3545',
                                    borderColor: '#dc3545',
                                    borderWidth: 1
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    ticks: {
                                        callback: val => '₹' + val
                                    },
                                    grid: {
                                        display: true,
                                        drawBorder: false
                                    }
                                },
                                x: {
                                    grid: {
                                        display: false
                                    },
                                    stacked: true
                                }
                            },
                            plugins: {
                                tooltip: {
                                    callbacks: {
                                        label: ctx => (ctx.dataset.label ? ctx.dataset.label + ': ' : '') + '₹' + ctx.parsed.y.toFixed(2)
                                    }
                                },
                                legend: {
                                    display: false
                                }
                            },
                            interaction: {
                                mode: 'index',
                                intersect: false
                            },
                            animation: {
                                duration: 1000
                            }
                        }
                    });
                },
                error: () => console.error('Error loading fees data')
            });
        }

        function loadPreviousYearMonthlyFeesChart() {
            $.ajax({
                url: '../../api/admin/get/fees-x-payments/monthly/get-monthly-fees-data-previous-year.php',
                method: 'GET',
                dataType: 'json',
                success: function(feesData) {
                    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

                    const paidFees = [];
                    const pendingFees = [];

                    // গত বছরের জন্য ১২ মাসের ডেটাই লুপ করা হচ্ছে
                    for (let i = 0; i < 12; i++) {
                        const monthData = feesData.find(item => item.month === (i + 1));
                        paidFees.push(monthData ? parseFloat(monthData.paid) : 0);
                        pendingFees.push(monthData ? parseFloat(monthData.pending) : 0);
                    }

                    const totalPaid = paidFees.reduce((a, b) => a + b, 0);
                    const totalPending = pendingFees.reduce((a, b) => a + b, 0);
                    const formatCur = (amt) => '₹' + amt.toLocaleString('en-IN', {
                        minimumFractionDigits: 2
                    });

                    $('#total-paid-fees-text-monthly-prev').text(`Paid Fees (${formatCur(totalPaid)})`);
                    $('#total-pending-fees-text-monthly-prev').text(`Pending Fees (${formatCur(totalPending)})`);

                    new Chart($('#monthlyFeesCollectionPrevYearChart'), {
                        type: 'bar',
                        data: {
                            labels: months,
                            datasets: [{
                                    label: 'Paid Fees',
                                    data: paidFees,
                                    backgroundColor: '#28a745',
                                    borderColor: '#28a745',
                                    borderWidth: 1
                                },
                                {
                                    label: 'Pending Fees',
                                    data: pendingFees,
                                    backgroundColor: '#dc3545',
                                    borderColor: '#dc3545',
                                    borderWidth: 1
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    ticks: {
                                        callback: val => '₹' + val
                                    },
                                    grid: {
                                        display: true,
                                        drawBorder: false
                                    }
                                },
                                x: {
                                    grid: {
                                        display: false
                                    },
                                    stacked: true
                                }
                            },
                            plugins: {
                                tooltip: {
                                    callbacks: {
                                        label: ctx => (ctx.dataset.label ? ctx.dataset.label + ': ' : '') + '₹' + ctx.parsed.y.toFixed(2)
                                    }
                                },
                                legend: {
                                    display: false
                                }
                            },
                            interaction: {
                                mode: 'index',
                                intersect: false
                            },
                            animation: {
                                duration: 1000
                            }
                        }
                    });
                },
                error: () => console.error('Error loading previous year fees data')
            });
        }

        function loadAdmissionFeesChart() {
            $.ajax({
                url: '../../api/admin/get/fees-x-payments/get-admission-fees-data-last-few-years.php',
                method: 'GET',
                dataType: 'json',
                success: function(feesData) {
                    const academicYears = feesData.map(item => item.academic_year);
                    const paidFees = feesData.map(item => parseFloat(item.paid_amount));
                    const pendingFees = feesData.map(item => parseFloat(item.unpaid_amount));

                    new Chart($('#admissionFeesCollectionChart'), {
                        type: 'bar',
                        data: {
                            labels: academicYears,
                            datasets: [{
                                    label: 'Paid Fees',
                                    data: paidFees,
                                    backgroundColor: '#28a745',
                                    borderColor: '#28a745',
                                    borderWidth: 1
                                },
                                {
                                    label: 'Pending Fees',
                                    data: pendingFees,
                                    backgroundColor: '#dc3545',
                                    borderColor: '#dc3545',
                                    borderWidth: 1
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    ticks: {
                                        callback: val => '₹' + val.toLocaleString('en-IN')
                                    },
                                    grid: {
                                        display: true,
                                        drawBorder: false
                                    }
                                },
                                x: {
                                    grid: {
                                        display: false
                                    }
                                }
                            },
                            plugins: {
                                tooltip: {
                                    callbacks: {
                                        label: ctx => (ctx.dataset.label ? ctx.dataset.label + ': ' : '') + '₹' + ctx.parsed.y.toLocaleString('en-IN')
                                    }
                                },
                                legend: {
                                    display: false
                                }
                            },
                            interaction: {
                                mode: 'index',
                                intersect: false
                            }
                        }
                    });
                },
                error: function() {
                    const ctx = $('#admissionFeesCollectionChart')[0].getContext('2d');
                    ctx.font = '16px Arial';
                    ctx.fillStyle = 'red';
                    ctx.textAlign = 'center';
                    ctx.fillText('Error loading chart data.', 150, 150);
                }
            });
        }

        function initLifetimeMonthlyDoughnut() {
            const data = [<?= $stats['lifetime_monthly_fees_collected'] ?>, <?= $stats['lifetime_monthly_fees_pending'] ?>];
            new Chart($('#lifetimeMonthlyFeesChart'), getDoughnutConfig(data));
        }

        function initLifetimeAdmissionDoughnut() {
            const data = [<?= $stats['lifetime_total_admission_fees_collected'] ?>, <?= $stats['lifetime_total_unpaid_admission_fees'] ?>];
            new Chart($('#lifetimeAdmissionFeesChart'), getDoughnutConfig(data));
        }

        function getDoughnutConfig(dataArray) {
            return {
                type: 'doughnut',
                data: {
                    labels: ['Collected', 'Pending'],
                    datasets: [{
                        data: dataArray,
                        backgroundColor: ['#28a745', '#dc3545'],
                        borderColor: ['#ffffff', '#ffffff'],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '70%',
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            callbacks: {
                                label: ctx => (ctx.label ? ctx.label + ': ' : '') + '₹' + ctx.parsed.toLocaleString('en-IN')
                            }
                        }
                    },
                    animation: {
                        animateScale: true,
                        animateRotate: true
                    }
                }
            };
        }
        <?php endif; ?>
    </script>

    <?php include_once("../../includes/body-close.php"); ?>
