<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Dashboard - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Get dashboard statistics
$stats = [];

// Total Students
$stmt = $pdo->query("SELECT COUNT(*) as total FROM students");
$stats['total_students'] = $stmt->fetch()['total'];

// Total Active Students
$stmt = $pdo->query("SELECT COUNT(*) as total FROM students WHERE status = 'Active'");
$stats['total_active_students'] = $stmt->fetch()['total'];

// Total Teachers
$stmt = $pdo->query("SELECT COUNT(*) as total FROM teachers WHERE status = 'active'");
$stats['total_teachers'] = $stmt->fetch()['total'];

// Total Classes
$stmt = $pdo->query("SELECT COUNT(*) as total FROM classes");
$stats['total_classes'] = $stmt->fetch()['total'];

// Total Fees Collected (this month)
$current_month = date('F Y');
$stmt = $pdo->prepare("SELECT SUM(total_paid_amount) as total FROM student_full_paid_fees WHERE month_year = ?");
$stmt->execute([$current_month]);
$stats['this_month_total_fees'] = $stmt->fetch()['total'] ?? 0;

// Total Wallet Balance Collected
$stmt = $pdo->prepare("SELECT SUM(balance) as total FROM student_wallet");
$stmt->execute();
$stats['total_wallet_balance'] = $stmt->fetch()['total'] ?? 0;

// Upcoming Exams (next 7 days, only active)
$stmt = $pdo->query("SELECT * FROM exams 
                    WHERE status = 'active' 
                    AND exam_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY) 
                    ORDER BY exam_date LIMIT 3");
$stats['upcoming_exams'] = $stmt->fetchAll();

// Latest Notices
$stmt = $pdo->query("SELECT title, notice_date FROM notices ORDER BY notice_date DESC LIMIT 3");
$stats['latest_notices'] = $stmt->fetchAll();

// Recent Monthly Fees Payments History
$stmt = $pdo->query("SELECT s.name, sph.payment_amount, sph.payment_date, sph.remark  
                    FROM student_payment_history sph 
                    JOIN students s ON sph.student_id = s.student_id 
                    ORDER BY sph.id DESC LIMIT 5");
$stats['recent_monthly_fees_payments'] = $stmt->fetchAll();

// Recent Admission Fees Payments History
$stmt = $pdo->query("SELECT s.name, sph.payment_amount, sph.payment_date, sph.remark  
                    FROM admission_fees_payment_history sph 
                    JOIN students s ON sph.student_id = s.student_id 
                    ORDER BY sph.id DESC LIMIT 5");
$stats['recent_admission_fees_payments'] = $stmt->fetchAll();

// Student count by class
$stmt = $pdo->query("SELECT c.class_name, COUNT(s.id) as student_count 
                    FROM classes c 
                    LEFT JOIN students s ON c.id = s.class_id AND s.status = 'Active'
                    GROUP BY c.id 
                    ORDER BY c.id");
$stats['students_by_class'] = $stmt->fetchAll();

// Lifetime Monthly Fees Pending
$stmt = $pdo->query("SELECT SUM(unpaid_amount) as total FROM student_unpaid_fees");
$stats['lifetime_monthly_fees_pending'] = $stmt->fetch()['total'] ?? 0;

// Lifetime Monthly Fees Collected
$stmt = $pdo->query("SELECT SUM(total_paid_amount) as total FROM student_full_paid_fees");
$stats['lifetime_monthly_fees_collected'] = $stmt->fetch()['total'] ?? 0;

// Total number of students with unpaid monthly fees
$stmt = $pdo->query("SELECT COUNT(DISTINCT student_id) AS total FROM student_unpaid_fees WHERE unpaid_amount > 0");
$stats['total_students_with_unpaid_monthly_fees'] = $stmt->fetch()['total'] ?? 0;

// Lifetime Admission Fees Pending
$stmt = $pdo->query("SELECT SUM(unpaid_amount) as unpaid_amount FROM admission_unpaid_fees");
$stats['lifetime_total_unpaid_admission_fees'] = $stmt->fetch()['unpaid_amount'] ?? 0;

// Lifetime Admission Fees Collected
$stmt = $pdo->query("SELECT SUM(payment_amount) as total FROM admission_fees_payment_history");
$stats['lifetime_total_admission_fees_collected'] = $stmt->fetch()['total'] ?? 0;

// Total number of students with unpaid admission fees
$stmt = $pdo->query("SELECT COUNT(DISTINCT student_id) AS total FROM admission_unpaid_fees WHERE unpaid_amount > 0");
$stats['total_students_with_unpaid_admission_fees'] = $stmt->fetch()['total'] ?? 0;

// Lifetime Additional Extra Fees Pending
$stmt = $pdo->query("SELECT SUM(class_wise_additional_fees.amount) AS unpaid_amount 
                     FROM additional_fees_data 
                     INNER JOIN class_wise_additional_fees ON additional_fees_data.additional_fee_setup_id = class_wise_additional_fees.id 
                     WHERE additional_fees_data.additional_fee_status = 'unpaid'");
$stats['lifetime_total_unpaid_additional_fees'] = $stmt->fetch()['unpaid_amount'] ?? 0;

// Lifetime Additional Extra Fees Paid
$stmt = $pdo->query("SELECT SUM(class_wise_additional_fees.amount) AS paid_amount 
                     FROM additional_fees_data 
                     INNER JOIN class_wise_additional_fees ON additional_fees_data.additional_fee_setup_id = class_wise_additional_fees.id 
                     WHERE additional_fees_data.additional_fee_status = 'paid'");
$stats['lifetime_total_paid_additional_fees'] = $stmt->fetch()['paid_amount'] ?? 0;

// Total number of students with unpaid additional fees
$stmt = $pdo->query("SELECT COUNT(DISTINCT student_id) AS total FROM additional_fees_data WHERE additional_fee_status = 'unpaid'");
$stats['total_students_with_unpaid_additional_fees'] = $stmt->fetch()['total'] ?? 0;

// Total lifetime unpaid fees (Monthly + Admission + Additional Fees)
$stats['lifetime_pending_fees'] = $stats['lifetime_monthly_fees_pending'] + $stats['lifetime_total_unpaid_admission_fees'] + $stats['lifetime_total_unpaid_additional_fees'];

// Total parent app installs and active devices
$stmt = $pdo->query("SELECT COUNT(*) as total FROM parent_auth_sessions WHERE fcm_token IS NOT NULL AND fcm_token != ''");
$stats['total_parent_app_installs'] = $stmt->fetch()['total'];

// Total parent accounts
$stmt = $pdo->query("SELECT COUNT(*) as total FROM parent_accounts");
$stats['total_parent_accounts'] = $stmt->fetch()['total'];
?>

<style>
    .list-group-item:hover {
        background-color: rgb(235, 235, 235);
    }
</style>

<div class="container py-4">

    <!-- Summary Cards -->
    <div class="row g-4 mb-4">
        <!-- Students Card -->
        <div class="col-xl-3 col-md-6" onclick="location.href='../student/list-students.php';" style="cursor: pointer; user-select: none;">
            <div class="card border-start-3 border-start-primary shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Total Students</div>
                            <div class="h4 mb-0"><?= $stats['total_active_students'] ?>/<?= $stats['total_students'] ?></div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-users fa-2x text-primary opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Teachers Card -->
        <div class="col-xl-3 col-md-6" onclick="location.href='../teacher/list-teachers.php';" style="cursor: pointer;">
            <div class="card border-start-3 border-start-success shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Total Teachers</div>
                            <div class="h4 mb-0"><?= $stats['total_teachers'] ?></div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-chalkboard-teacher fa-2x text-success opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Classes Card -->
        <div class="col-xl-3 col-md-6">
            <div class="card border-start-3 border-start-info shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Total Classes</div>
                            <div class="h4 mb-0"><?= $stats['total_classes'] ?></div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-school fa-2x text-info opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Wallet Balance Card -->
        <div class="col-xl-3 col-md-6 fees-info-card" onclick="location.href='../fees-x-payments/wallet/manage-student-wallets.php';" style="cursor: pointer; user-select: none;">
            <div class="card border-start-3 border-start-warning shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Total Wallet Balance</div>
                            <div class="h4 mb-0">₹<?= number_format($stats['total_wallet_balance'], 2) ?></div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-wallet fa-2x text-success opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Unpaid Admission Fees Card -->
        <div class="col-xl-3 col-md-6 fees-info-card" title="Lifetime Total Pending Unpaid Admission Fees">
            <div class="card border-start-3 border-start-danger shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Unpaid Admission Fees</div>
                            <div class="h4 mb-0">₹<?= number_format($stats['lifetime_total_unpaid_admission_fees'], 2) ?></div>
                            <div class="text-muted small">(<?= number_format($stats['total_students_with_unpaid_admission_fees'], 0) ?> students)</div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-exclamation-triangle fa-2x text-danger opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Unpaid Monthly Fees Card -->
        <div class="col-xl-3 col-md-6 fees-info-card" title="Lifetime Total Pending Unpaid Monthly Fees">
            <div class="card border-start-3 border-start-danger shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Unpaid Monthly Fees</div>
                            <div class="h4 mb-0">₹<?= number_format($stats['lifetime_monthly_fees_pending'], 2) ?></div>
                            <div class="text-muted small">(<?= number_format($stats['total_students_with_unpaid_monthly_fees'], 0) ?> students)</div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-exclamation-triangle fa-2x text-danger opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Unpaid Additional Fees Card -->
        <div class="col-xl-3 col-md-6 fees-info-card" title="Lifetime Total Pending Unpaid Additional Fees">
            <div class="card border-start-3 border-start-danger shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Unpaid Additional Fees</div>
                            <div class="h4 mb-0">₹<?= number_format($stats['lifetime_total_unpaid_additional_fees'], 2) ?></div>
                            <div class="text-muted small">(<?= number_format($stats['total_students_with_unpaid_additional_fees'], 0) ?> students)</div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-exclamation-triangle fa-2x text-danger opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total pending fees (Admission + Monthly + Additional) -->
        <div class="col-xl-3 col-md-6 fees-info-card" title="Lifetime Total Pending Unpaid Fees (Monthly + Admission + Additional Fees)">
            <div class="card border-start-3 border-start-danger shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Total Unpaid Fees</div>
                            <div class="h4 mb-0">₹<?= number_format($stats['lifetime_pending_fees'], 2) ?></div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-exclamation-triangle fa-2x text-danger opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Fees Card -->
        <div class="col-xl-3 col-md-6 fees-info-card" onclick="location.href='<?= BASE_URL ?>/management/fees-x-payments/manage-payment-history-admission-x-monthly.php';" style="cursor: pointer; user-select: none;">
            <div class="card border-start-3 border-start-warning shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Fees Collected (<?= date('F') ?>)</div>
                            <div class="h4 mb-0">₹<?= number_format($stats['this_month_total_fees'], 2) ?></div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-money-bill-wave fa-2x text-warning opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Parent App Installs -->
        <div class="col-xl-3 col-md-6" style="cursor: pointer; user-select: none;">
            <div class="card border-start-3 border-start-warning shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Parent App Installs</div>
                            <div class="h5 mb-0"><?= $stats['total_parent_app_installs'] ?> active devices</div>
                        </div>
                        <div class="ms-3">
                            <i class="fa-brands fa-android fa-2x text-success opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Parent App Installs -->
        <div class="col-xl-3 col-md-6" style="cursor: pointer; user-select: none;">
            <div class="card border-start-3 border-start-warning shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="flex-grow-1">
                            <div class="text-muted small">Parent Accounts</div>
                            <div class="h5 mb-0"><?= $stats['total_parent_accounts'] ?> accounts</div>
                        </div>
                        <div class="ms-3">
                            <i class="fas fa-users fa-2x text-success opacity-100"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content Row -->
        <div class="row g-4 mx-0 px-0">
            <!-- Students by Class Chart -->
            <div class="col-lg-6">
                <div class="card shadow-sm h-100">
                    <div class="card-header bg-white border-bottom-0 py-3" style="border-left: 5px solid <?= $theme_color ?>">
                        <h5 class="mb-0">Students by Class</h5>
                    </div>
                    <div class="card-body pt-0">
                        <div class="chart-container" style="height: 300px;">
                            <canvas id="studentsByClassChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Monthly Fees Collection Overview Card -->
            <div class="col-lg-6 fees-info-card">
                <div class="card shadow-sm h-100">
                    <div class="card-header bg-white border-bottom-0 py-3" style="border-left: 5px solid <?= $theme_color ?>">
                        <h5 class="mb-0">Monthly Fees Collection Overview (<?= date('Y') ?>)</h5>
                    </div>
                    <div class="card-body pt-0">
                        <div class="chart-container" style="height: 300px;">
                            <canvas id="monthlyFeesCollectionChart"></canvas>
                        </div>
                        <div class="mt-3 d-flex justify-content-center">
                            <div class="me-4">
                                <span class="badge bg-success me-2">&nbsp;</span>
                                <span id="total-paid-fees-text-monthly">Paid Fees</span>
                            </div>
                            <div>
                                <span class="badge bg-danger me-2">&nbsp;</span>
                                <span id="total-pending-fees-text-monthly">Pending Fees</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Admission Fees Collection Overview Card -->
            <div class="col-lg-6 fees-info-card">
                <div class="card shadow-sm h-100">
                    <div class="card-header bg-white border-bottom-0 py-3" style="border-left: 5px solid <?= $theme_color ?>">
                        <h5 class="mb-0">Admission Fees Collection Overview (12 Years)</h5>
                    </div>
                    <div class="card-body pt-0">
                        <div class="chart-container" style="height: 300px;">
                            <canvas id="admissionFeesCollectionChart"></canvas>
                        </div>
                        <div class="mt-3 d-flex justify-content-center">
                            <div class="mt-3 d-flex justify-content-center">
                                <div class="me-4">
                                    <span class="badge bg-success me-2">&nbsp;</span>
                                    <span>Paid Fees</span>
                                </div>
                                <div>
                                    <span class="badge bg-danger me-2">&nbsp;</span>
                                    <span>Pending Fees</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Lifetime Monthly Fees Chart Card -->
            <div class="col-xl-3 col-md-6 fees-info-card">
                <div class="card shadow-sm h-100">
                    <div class="card-header bg-white border-bottom-0 py-3" style="border-left: 5px solid <?= $theme_color ?>" title="Lifetime Monthly Fees Collected. This is lifetime data.">
                        <h5 class="mb-0">Monthly Fees Collected</h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container" style="height: 200px;">
                            <canvas id="lifetimeMonthlyFeesChart"></canvas>
                        </div>
                        <div class="mt-3 text-center">
                            <div class="d-flex justify-content-center">
                                <div class="me-4">
                                    <span class="badge bg-success me-2">&nbsp;</span>
                                    <span>Collected: ₹<?= number_format($stats['lifetime_monthly_fees_collected'], 2) ?></span>
                                </div>
                                <div>
                                    <span class="badge bg-danger me-2">&nbsp;</span>
                                    <span>Pending: ₹<?= number_format($stats['lifetime_monthly_fees_pending'], 2) ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Lifetime Admission Fees Chart Card -->
            <div class="col-xl-3 col-md-6 fees-info-card">
                <div class="card shadow-sm h-100">
                    <div class="card-header bg-white border-bottom-0 py-3" style="border-left: 5px solid <?= $theme_color ?>" title="Lifetime Admission Fees Collected. This is lifetime data.">
                        <h5 class="mb-0">Admission Fees Collected</h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container" style="height: 200px;">
                            <canvas id="lifetimeAdmissionFeesChart"></canvas>
                        </div>
                        <div class="mt-3 text-center">
                            <div class="d-flex justify-content-center">
                                <div class="me-4">
                                    <span class="badge bg-success me-2">&nbsp;</span>
                                    <span>Collected: ₹<?= number_format($stats['lifetime_total_admission_fees_collected'], 2) ?></span>
                                </div>
                                <div>
                                    <span class="badge bg-danger me-2">&nbsp;</span>
                                    <span>Pending: ₹<?= number_format($stats['lifetime_total_unpaid_admission_fees'], 2) ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Upcoming Exams and Notices -->
            <div class="col-lg-6">
                <div class="row g-4">
                    <!-- Upcoming Exams -->
                    <div class="col-md-6">
                        <div class="card shadow-sm h-100">
                            <div class="card-header bg-white border-bottom-0 py-3" style="border-left: 5px solid <?= $theme_color ?>">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0">Upcoming Exams</h5>
                                    <a href="../exam/list-exams.php" class="btn btn-sm btn-outline-primary">View All</a>
                                </div>
                            </div>
                            <div class="card-body">
                                <?php if (empty($stats['upcoming_exams'])): ?>
                                    <div class="text-center py-4">
                                        <i class="fas fa-calendar-check fa-2x text-muted mb-3"></i>
                                        <p class="text-muted mb-0">No upcoming exams</p>
                                    </div>
                                <?php else: ?>
                                    <div class="list-group list-group-flush">
                                        <?php foreach ($stats['upcoming_exams'] as $exam): ?>
                                            <div class="list-group-item border-0 px-0 py-2">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <h6 class="mb-1"><?= safe_htmlspecialchars($exam['exam_name']) ?></h6>
                                                        <small class="text-muted"><?= date('M j, Y', strtotime($exam['exam_date'])) ?></small>
                                                    </div>
                                                    <span class="badge bg-primary rounded-pill">
                                                        <?= date('D', strtotime($exam['exam_date'])) ?>
                                                    </span>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Latest Notices -->
                    <div class="col-md-6">
                        <div class="card shadow-sm h-100">
                            <div class="card-header bg-white border-bottom-0 py-3" style="border-left: 5px solid <?= $theme_color ?>">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0">Latest Notices</h5>
                                    <a href="../notice/manage-school-notices.php" class="btn btn-sm btn-outline-primary">View All</a>
                                </div>
                            </div>
                            <div class="card-body">
                                <?php if (empty($stats['latest_notices'])): ?>
                                    <div class="text-center py-4">
                                        <i class="fas fa-bullhorn fa-2x text-muted mb-3"></i>
                                        <p class="text-muted mb-0">No notices available</p>
                                    </div>
                                <?php else: ?>
                                    <div class="list-group list-group-flush">
                                        <?php foreach ($stats['latest_notices'] as $notice): ?>
                                            <div class="list-group-item border-bottom px-0 py-2">
                                                <h6 class="mb-1"><?= safe_htmlspecialchars($notice['title']) ?></h6>
                                                <small class="text-muted">Posted on <?= date('M j, Y', strtotime($notice['notice_date'])) ?></small>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Monthly Fees Payment History -->
            <div class="col-12 fees-info-card">
                <div class="card shadow-sm">
                    <div class="card-header bg-white border-bottom-0 py-3" style="border-left: 5px solid <?= $theme_color ?>">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Monthly Fees Payment History</h5>
                            <a href="../fees-x-payments/manage-payment-history-admission-x-monthly.php?payment-type=monthly" class="btn btn-sm btn-outline-primary">Manage Payments</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead>
                                    <tr>
                                        <th>Student</th>
                                        <th>Amount</th>
                                        <th>Date</th>
                                        <th>Remark</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($stats['recent_monthly_fees_payments'])): ?>
                                        <tr>
                                            <td colspan="4" class="text-center py-4 text-muted">
                                                <i class="fas fa-wallet fa-2x mb-3"></i>
                                                <p class="mb-0">No recent payments</p>
                                            </td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($stats['recent_monthly_fees_payments'] as $payment): ?>
                                            <tr>
                                                <td width="25%"><?= safe_htmlspecialchars($payment['name']) ?></td>
                                                <td width="20%">₹<?= number_format($payment['payment_amount'], 2) ?></td>
                                                <td width="20%"><?= date('M j, Y', strtotime($payment['payment_date'])) ?></td>
                                                <td width="35%"><?= safe_htmlspecialchars($payment['remark']) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Admission Fees Payment History -->
            <div class="col-12 fees-info-card">
                <div class="card shadow-sm">
                    <div class="card-header bg-white border-bottom-0 py-3" style="border-left: 5px solid <?= $theme_color ?>">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Admission Fees Payment History</h5>
                            <a href="../fees-x-payments/manage-payment-history-admission-x-monthly.php?payment-type=admission" class="btn btn-sm btn-outline-primary">Manage Payments</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead>
                                    <tr>
                                        <th>Student</th>
                                        <th>Amount</th>
                                        <th>Date</th>
                                        <th>Remark</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($stats['recent_admission_fees_payments'])): ?>
                                        <tr>
                                            <td colspan="4" class="text-center py-4 text-muted">
                                                <i class="fas fa-wallet fa-2x mb-3"></i>
                                                <p class="mb-0">No recent payments</p>
                                            </td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($stats['recent_admission_fees_payments'] as $payment): ?>
                                            <tr>
                                                <td width="25%"><?= safe_htmlspecialchars($payment['name']) ?></td>
                                                <td width="20%">₹<?= number_format($payment['payment_amount'], 2) ?></td>
                                                <td width="20%"><?= date('M j, Y', strtotime($payment['payment_date'])) ?></td>
                                                <td width="35%"><?= safe_htmlspecialchars($payment['remark']) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Hide Payments Statics Using JavaScript According to the permission
            <?php
            if (!hasPermission(PERM_MANAGE_FEES)) {
                echo "$('.fees-info-card').hide();";
            }
            ?>

            // Students by Class Chart using jQuery
            const classNames = <?= json_encode(array_column($stats['students_by_class'], 'class_name')) ?>;
            const studentCounts = <?= json_encode(array_column($stats['students_by_class'], 'student_count')) ?>;

            const ctx = $('#studentsByClassChart');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: classNames,
                    datasets: [{
                        label: 'Students',
                        data: studentCounts,
                        backgroundColor: '<?= $theme_color ?>',
                        borderColor: '<?= $theme_color ?>',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                stepSize: 1,
                                precision: 0
                            },
                            grid: {
                                display: true,
                                drawBorder: false
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return context.parsed.y + ' students';
                                }
                            }
                        }
                    }
                }
            });


            // Get monthly fees data for the current year
            $.ajax({
                url: '../../api/admin/get/fees-x-payments/get-monthly-fees-data-current-year.php',
                method: 'GET',
                dataType: 'json',
                success: function(feesData) {
                    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                    const currentMonth = new Date().getMonth();
                    const displayedMonths = months.slice(0, currentMonth + 1);

                    const paidFees = [];
                    const pendingFees = [];

                    // Initialize all months with 0 values
                    for (let i = 0; i <= currentMonth; i++) {
                        const monthData = feesData.find(item => item.month === (i + 1));
                        paidFees.push(monthData ? parseFloat(monthData.paid) : 0);
                        pendingFees.push(monthData ? parseFloat(monthData.pending) : 0);
                    }

                    // Calculate the total for paid and pending fees
                    const totalPaid = paidFees.reduce((sum, current) => sum + current, 0);
                    const totalPending = pendingFees.reduce((sum, current) => sum + current, 0);

                    // Helper function to format numbers as Indian currency
                    const formatAsCurrency = (amount) => {
                        return '₹' + amount.toLocaleString('en-IN', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        });
                    };

                    // Update the text in the HTML
                    $('#total-paid-fees-text-monthly').text(`Paid Fees (${formatAsCurrency(totalPaid)})`);
                    $('#total-pending-fees-text-monthly').text(`Pending Fees (${formatAsCurrency(totalPending)})`);


                    const ctxFees = $('#monthlyFeesCollectionChart');
                    new Chart(ctxFees, {
                        type: 'bar',
                        data: {
                            labels: displayedMonths,
                            datasets: [{
                                    label: 'Paid Fees',
                                    data: paidFees,
                                    backgroundColor: '#28a745',
                                    borderColor: '#28a745',
                                    borderWidth: 1
                                },
                                {
                                    label: 'Pending Fees',
                                    data: pendingFees,
                                    backgroundColor: '#dc3545',
                                    borderColor: '#dc3545',
                                    borderWidth: 1
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    ticks: {
                                        callback: function(value) {
                                            return '₹' + value;
                                        }
                                    },
                                    grid: {
                                        display: true,
                                        drawBorder: false
                                    }
                                },
                                x: {
                                    grid: {
                                        display: false
                                    },
                                    stacked: true
                                }
                            },
                            plugins: {
                                tooltip: {
                                    callbacks: {
                                        label: function(context) {
                                            let label = context.dataset.label || '';
                                            if (label) {
                                                label += ': ';
                                            }
                                            if (context.parsed.y !== null) {
                                                label += '₹' + context.parsed.y.toFixed(2);
                                            }
                                            return label;
                                        }
                                    }
                                },
                                legend: {
                                    display: false
                                }
                            },
                            interaction: {
                                mode: 'index',
                                intersect: false
                            },
                            animation: {
                                duration: 1000
                            }
                        }
                    });
                },
                error: function() {
                    console.error('Error loading fees data');
                }
            });

            // Get admission fees data from last 12 years
            $.ajax({
                url: '../../api/admin/get/fees-x-payments/get-admission-fees-data-last-few-years.php',
                method: 'GET',
                dataType: 'json',
                success: function(feesData) {
                    // Prepare the data for the chart
                    const academicYears = [];
                    const paidFees = [];
                    const pendingFees = [];

                    // Loop through the API response data
                    feesData.forEach(item => {
                        academicYears.push(item.academic_year);
                        paidFees.push(parseFloat(item.paid_amount));
                        pendingFees.push(parseFloat(item.unpaid_amount));
                    });

                    // Get the canvas element
                    const ctx = $('#admissionFeesCollectionChart');

                    // Create the new chart instance
                    new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: academicYears,
                            datasets: [{
                                    label: 'Paid Fees',
                                    data: paidFees,
                                    backgroundColor: '#28a745', // Green color for paid fees
                                    borderColor: '#28a745',
                                    borderWidth: 1
                                },
                                {
                                    label: 'Pending Fees',
                                    data: pendingFees,
                                    backgroundColor: '#dc3545', // Red color for pending fees
                                    borderColor: '#dc3545',
                                    borderWidth: 1
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    ticks: {
                                        callback: function(value) {
                                            return '₹' + value.toLocaleString('en-IN');
                                        }
                                    },
                                    grid: {
                                        display: true,
                                        drawBorder: false
                                    }
                                },
                                x: {
                                    grid: {
                                        display: false
                                    }
                                }
                            },
                            plugins: {
                                tooltip: {
                                    callbacks: {
                                        label: function(context) {
                                            let label = context.dataset.label || '';
                                            if (label) {
                                                label += ': ';
                                            }
                                            if (context.parsed.y !== null) {
                                                label += '₹' + context.parsed.y.toLocaleString('en-IN');
                                            }
                                            return label;
                                        }
                                    }
                                },
                                legend: {
                                    display: false // Hide legend as it's already in HTML
                                }
                            },
                            interaction: {
                                mode: 'index',
                                intersect: false
                            }
                        }
                    });
                },
                error: function() {
                    console.error('Error loading admission fees data');
                    // Optionally, display an error message on the chart canvas
                    const ctx = $('#admissionFeesCollectionChart').getContext('2d');
                    ctx.font = '16px Arial';
                    ctx.fillStyle = 'red';
                    ctx.textAlign = 'center';
                    ctx.fillText('Error loading chart data.', 150, 150);
                }
            });
        });

        // Lifetime Monthly Fees Doughnut Chart
        $(document).ready(function() {
            const lifetimeMonthlyFeesCollected = <?= $stats['lifetime_monthly_fees_collected'] ?>;
            const lifetimeMonthlyFeesPending = <?= $stats['lifetime_monthly_fees_pending'] ?>;

            const ctxLifetime = $('#lifetimeMonthlyFeesChart');
            new Chart(ctxLifetime, {
                type: 'doughnut',
                data: {
                    labels: ['Collected', 'Pending'],
                    datasets: [{
                        data: [lifetimeMonthlyFeesCollected, lifetimeMonthlyFeesPending],
                        backgroundColor: [
                            '#28a745',
                            '#dc3545'
                        ],
                        borderColor: [
                            '#ffffff',
                            '#ffffff'
                        ],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '70%',
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    let label = context.label || '';
                                    if (label) {
                                        label += ': ';
                                    }
                                    if (context.parsed !== null) {
                                        label += '₹' + context.parsed.toLocaleString('en-IN');
                                    }
                                    return label;
                                }
                            }
                        }
                    },
                    animation: {
                        animateScale: true,
                        animateRotate: true
                    }
                }
            });
        });

        // Lifetime Admission Fees Doughnut Chart
        $(document).ready(function() {
            const lifetimeAdmissionFeesCollected = <?= $stats['lifetime_total_admission_fees_collected'] ?>;
            const lifetimeAdmissionFeesPending = <?= $stats['lifetime_total_unpaid_admission_fees'] ?>;

            const ctxLifetime = $('#lifetimeAdmissionFeesChart');
            new Chart(ctxLifetime, {
                type: 'doughnut',
                data: {
                    labels: ['Collected', 'Pending'],
                    datasets: [{
                        data: [lifetimeAdmissionFeesCollected, lifetimeAdmissionFeesPending],
                        backgroundColor: [
                            '#28a745',
                            '#dc3545'
                        ],
                        borderColor: [
                            '#ffffff',
                            '#ffffff'
                        ],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '70%',
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    let label = context.label || '';
                                    if (label) {
                                        label += ': ';
                                    }
                                    if (context.parsed !== null) {
                                        label += '₹' + context.parsed.toLocaleString('en-IN');
                                    }
                                    return label;
                                }
                            }
                        }
                    },
                    animation: {
                        animateScale: true,
                        animateRotate: true
                    }
                }
            });
        });
    </script>

    <?php include_once("../../includes/body-close.php"); ?>