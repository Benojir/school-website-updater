<?php
include_once "dashboard.php";
exit;