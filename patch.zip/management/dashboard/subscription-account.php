<?php
// Intentionally no header-close.php: an already logged-in owner can settle a blocked account.
require_once __DIR__ . '/../../includes/auth-check.php';
header('Cache-Control: no-store');
header('Referrer-Policy: no-referrer');
if (!isSuperAdmin()) {
    if (!isAnyAdminLoggedIn()) { header('Location: ' . BASE_URL . '/management/auth/login.php?subscription_account=1&target=' . (($_GET['target'] ?? '') === 'sms' ? 'sms' : 'subscription')); exit; }
    http_response_code(403); exit('Log in as the school super admin to open Subscription Account.');
}
$key = defined('SCHOOLSONGI_PORTAL_KEY') ? SCHOOLSONGI_PORTAL_KEY : getenv('SCHOOLSONGI_PORTAL_KEY');
if (!is_string($key) || !preg_match('/^[a-f0-9]{64}$/D', $key)) {
    http_response_code(503); exit('Subscription Account access has not been configured. Please contact School Songi.');
}
$ch = curl_init('https://schoolsongi.com/api/auth/create-school-account-link.php');
curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => http_build_query(['school_id' => SCHOOL_ID, 'target' => ($_GET['target'] ?? '') === 'sms' ? 'sms' : 'subscription']),
    CURLOPT_HTTPHEADER => ['X-Schoolsongi-Portal-Key: ' . $key], CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 10]);
$response = curl_exec($ch);
$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
$data = is_string($response) ? json_decode($response, true) : null;
if ($status !== 200 || ($data['success'] ?? false) !== true || !preg_match('/^[a-f0-9]{64}$/D', $data['code'] ?? '')) {
    http_response_code(503); exit('Subscription Account is temporarily unavailable. Please try again or contact support.');
}
header('Location: https://schoolsongi.com/admin/manage/school-subscription-account.php?code=' . rawurlencode($data['code']));
exit;
