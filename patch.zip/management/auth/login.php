<?php
/**@var string $school_name 
 * @var string $theme_color
 * @var array $websiteConfig
*/
include_once(__DIR__ . "/../../includes/auth-check.php");

// Check if user is logged in via session
if (isAnyAdminLoggedIn()) {
    header("Location: ../dashboard/");
    exit();

}

include_once(__DIR__ . "/../../includes/header-open.php");
?>
<title>Login - <?= $school_name; ?></title>

<style>
    .login-page {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        min-height: 100vh;
    }

    .login-page .card {
        border-radius: 15px;
        border: none;
        overflow: hidden;
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }

    .login-page .card-body {
        padding: 2rem;
    }

    .login-page .form-control {
        padding: 0.75rem 1rem;
        border-radius: 8px;
        border: 1px solid #dee2e6;
        transition: all 0.3s;
    }

    .login-page .form-control:focus {
        border-color: <?= $theme_color; ?>;
        box-shadow: 0 0 0 0.25rem rgba(<?= hexdec(substr($theme_color, 1, 2)) ?>, <?= hexdec(substr($theme_color, 3, 2)) ?>, <?= hexdec(substr($theme_color, 5, 2)) ?>, 0.25);
    }

    .login-page .input-group-text {
        background-color: #f8f9fa;
        border-right: none;
    }

    .login-page .btn-primary {
        padding: 0.75rem;
        border-radius: 8px;
        font-weight: 500;
        transition: all 0.3s;
    }

    .login-page .btn-primary:hover {
        opacity: 0.9;
        transform: translateY(-2px);
    }

    .login-page .toggle-password {
        cursor: pointer;
        border-left: none;
    }

    .login-page .toggle-password:hover {
        background-color: #f8f9fa;
    }

    /* Turnstile container styling */
    .turnstile-container {
        display: flex;
        justify-content: center;
        margin: 1rem 0;
    }

    /* Responsive adjustments */
    @media (max-width: 575.98px) {
        .login-page .card-body {
            padding: 1.5rem;
        }

        .turnstile-container {
            transform: scale(0.9);
            transform-origin: center;
        }
    }
</style>

<?php include_once(__DIR__ . "/../../includes/header-close.php"); ?>

<div class="login-page bg-light">
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-8 col-lg-6 col-xl-5">
                <div class="card shadow-sm">
                    <div class="card-body p-4 p-sm-5">
                        <div class="text-center mb-4">
                            <?php if (file_exists('../../uploads/school/logo-square.png')): ?>
                                <img src="<?= $logo_square; ?>" alt="School Logo" class="img-fluid mb-3" style="max-height: 80px;">
                            <?php endif; ?>
                            <h3 class="mb-1"><?= $school_name; ?></h3>
                            <p class="text-muted">School Management System</p>
                        </div>

                        <form id="loginForm" method="post" autocomplete="off">
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                                    <input type="text" class="form-control" id="username" name="username" placeholder="Enter username" required>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" required>
                                    <button class="btn btn-outline-secondary toggle-password" type="button">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>

                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="remember" name="remember">
                                <label class="form-check-label" for="remember">Remember me</label>
                            </div>

                            <!-- Cloudflare Turnstile -->
                            <div class="turnstile-container">
                                <div class="cf-turnstile" data-sitekey="<?= $websiteConfig['captcha_site_key'] ?>"></div>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary btn-lg" id="loginBtn" style="background-color: <?= $theme_color; ?>; border-color: <?= $theme_color; ?>">
                                    <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                                    Login
                                </button>
                            </div>
                        </form>

                        <div class="text-center mt-3">
                            <a href="admin-forgot-password.php" class="text-decoration-none">Forgot password?</a>
                        </div>
                    </div>
                </div>

                <div class="text-center mt-3">
                    <p class="text-muted mb-0">© <?= date('Y'); ?> <?= $school_name; ?>. All rights reserved.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    let turnstileWidgetId;

    // Initialize Turnstile when DOM is ready
    function initTurnstile() {
        const container = document.querySelector('.cf-turnstile');

        if (typeof turnstile !== 'undefined' && container && !turnstileWidgetId) {
            try {
                turnstileWidgetId = turnstile.render(container, {
                    sitekey: '<?= $websiteConfig['captcha_site_key'] ?>',
                    theme: 'light',
                    size: 'normal'
                });
                console.log('Turnstile initialized successfully');
            } catch (error) {
                console.error('Turnstile initialization error:', error);
                // Retry after a short delay
                setTimeout(initTurnstile, 500);
            }
        } else if (typeof turnstile === 'undefined') {
            // If Turnstile hasn't loaded yet, wait and try again
            setTimeout(initTurnstile, 200);
        }
    }

    // Helper function to reset Turnstile
    function resetTurnstile() {
        if (typeof turnstile !== 'undefined' && turnstileWidgetId !== undefined) {
            try {
                turnstile.reset(turnstileWidgetId);
            } catch (error) {
                console.error('Error resetting Turnstile:', error);
            }
        }
    }

    $(document).ready(function() {
        // Start initialization
        initTurnstile();

        // Toggle password visibility
        $('.toggle-password').click(function() {
            const passwordInput = $('#password');
            const icon = $(this).find('i');

            if (passwordInput.attr('type') === 'password') {
                passwordInput.attr('type', 'text');
                icon.removeClass('fa-eye').addClass('fa-eye-slash');
            } else {
                passwordInput.attr('type', 'password');
                icon.removeClass('fa-eye-slash').addClass('fa-eye');
            }
        });

        // Handle form submission
        $('#loginForm').submit(function(e) {
            e.preventDefault();

            // Check if Turnstile is completed
            let turnstileResponse = '';
            if (typeof turnstile !== 'undefined' && turnstileWidgetId !== undefined) {
                try {
                    turnstileResponse = turnstile.getResponse(turnstileWidgetId);
                } catch (error) {
                    console.error('Error getting Turnstile response:', error);
                }
            }

            if (!turnstileResponse) {
                toastr.error('Please complete the captcha verification');
                return;
            }

            const btn = $('#loginBtn');
            btn.prop('disabled', true);
            btn.find('.spinner-border').removeClass('d-none');

            $.ajax({
                url: '../../api/admin/auth/web-login.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        setTimeout(function() {
                            window.location.href = '../dashboard/';
                        }, 1500);
                    } else {
                        toastr.error(response.message);
                        // Reset Turnstile on error
                        resetTurnstile();
                        btn.prop('disabled', false);
                        btn.find('.spinner-border').addClass('d-none');
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred. Please try again.');
                    // Reset Turnstile on error
                    resetTurnstile();
                    btn.prop('disabled', false);
                    btn.find('.spinner-border').addClass('d-none');
                    console.error(xhr.responseText);
                }
            });
        });
    });
</script>

<?php include_once(__DIR__ . "/../../includes/body-close.php"); ?>