<?php
/** @var string $school_name
 * @var string $logo_square
 * @var array $websiteConfig
 */
include_once(__DIR__ . '/../../includes/header-open.php');
echo "<title>Forgot Password - " . $school_name . "</title>";
include_once(__DIR__ . '/../../includes/header-close.php');
?>

<style>
    .adjust-height {
        height: 3rem;
    }
</style>

<div class="container py-5">
    <div class="row mt-5 justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="justify-content-center text-center mb-5">
                <img src="<?= $logo_square; ?>" class="mb-2" width="100px" alt="<?= $school_name; ?>">
                <br>
                <h2 class="p-0 m-0 fw-bold"><?= $school_name; ?></h2>
            </div>

            <div class="card shadow">
                <div class="card-header p-3 bg-primary text-white">
                    <h3 class="m-0"><i class="fa-solid fa-key me-2"></i> Password Reset</h3>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <div id="alert-box" class="alert d-none" role="alert"></div>
                    </div>
                    <form id="sendUsernameForm" autocomplete="off">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username or Email Id:</label>
                            <input type="text" class="form-control adjust-height" name="username" id="username" placeholder="Enter your username or registered email id." required>
                        </div>
                        <div class="mb-3">
                            <!-- Turnstile Widget Container -->
                            <div id="turnstile-container-1"></div>
                            <input type="hidden" id="cf-turnstile-response-1" name="cf-turnstile-response">
                        </div>
                        <div class="mb-3">
                            <button class="btn btn-primary adjust-height" id="sendOtpBtn" type="submit"><i class="fa-solid fa-arrow-right"></i> Next</button>
                        </div>
                    </form>
                    <form id="verifyOtpForm" class="d-none" autocomplete="off">
                        <input type="hidden" id="adminUsername" name="adminUsername">
                        <div class="mb-3">
                            <label for="newPassword" class="form-label">New Password:</label>
                            <input type="password" class="form-control adjust-height" id="newPassword" name="newPassword" placeholder="Enter new password." required>
                        </div>
                        <div class="mb-3">
                            <label for="otp" class="form-label">One Time Password:</label>
                            <input type="text" class="form-control adjust-height" id="otp" name="otp" placeholder="Enter OTP." required>
                        </div>
                        <div class="mb-3">
                            <!-- Separate Turnstile for OTP verification -->
                            <div id="turnstile-container-2"></div>
                            <input type="hidden" id="cf-turnstile-response-2" name="cf-turnstile-response">
                        </div>
                        <div id="resendOTPOptionContainer" class="mb-3">
                            <span id="resendOTP" style="color:#0d6efd; cursor: pointer;">Resend OTP</span>
                        </div>
                        <div class="mb-3">
                            <button class="btn btn-primary adjust-height" id="verifyOtpBtn" type="submit"><i class="fa-solid fa-paper-plane"></i> Verify OTP</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Turnstile render script -->
<script>
    // Global variables to store Turnstile widget IDs
    var turnstileWidgetId1 = null;
    var turnstileWidgetId2 = null;

    // Function to render Turnstile widgets
    function renderTurnstile() {
        // First widget for username form
        if (document.getElementById('turnstile-container-1') && turnstileWidgetId1 === null) {
            turnstileWidgetId1 = turnstile.render('#turnstile-container-1', {
                sitekey: '<?=$websiteConfig['captcha_site_key']?>',
                callback: function(token) {
                    $('#cf-turnstile-response-1').val(token);
                },
                'expired-callback': function() {
                    $('#cf-turnstile-response-1').val('');
                },
                'error-callback': function() {
                    $('#cf-turnstile-response-1').val('');
                }
            });
        }

        // Second widget for OTP verification (initially hidden)
        if (document.getElementById('turnstile-container-2') && turnstileWidgetId2 === null) {
            turnstileWidgetId2 = turnstile.render('#turnstile-container-2', {
                sitekey: '<?=$websiteConfig['captcha_site_key']?>',
                callback: function(token) {
                    $('#cf-turnstile-response-2').val(token);
                },
                'expired-callback': function() {
                    $('#cf-turnstile-response-2').val('');
                },
                'error-callback': function() {
                    $('#cf-turnstile-response-2').val('');
                }
            });
        }
    }

    // Wait until the Turnstile script has loaded, then render the widgets
    function waitForTurnstile() {
        if (typeof turnstile !== 'undefined') {
            renderTurnstile();
        } else {
            setTimeout(waitForTurnstile, 200);
        }
    }

    waitForTurnstile();
</script>

<script>
    $(document).ready(function() {
        // Store timer variable globally to clear it when needed
        let resendTimer = null;
        
        // Send username form handler
        $('#sendUsernameForm').submit(function(e) {
            e.preventDefault();
            const turnstileResponse = $('#cf-turnstile-response-1').val();
            
            if (!turnstileResponse) {
                showAlert('Please complete the captcha challenge.', 'danger');
                return;
            }
            
            const formData = $(this).serialize();

            sendAjaxRequest({
                url: '../../api/admin/auth/send-password-reset-otp.php',
                formData: formData,
                button: $('#sendOtpBtn'),
                loadingText: 'Sending...',
                successCallback: function(response) {
                    if (response.success) {
                        showAlert(response.message, 'success');
                        $('#sendUsernameForm').addClass('d-none');
                        $('#verifyOtpForm').removeClass('d-none');
                        $('#adminUsername').val($('[name=username]').val());
                        // Start countdown for resend OTP
                        showResendCountDown();
                        // Reset first widget
                        if (turnstileWidgetId1 !== null) {
                            turnstile.reset(turnstileWidgetId1);
                        }
                    } else {
                        showAlert(response.message, 'danger');
                        // Reset first widget
                        if (turnstileWidgetId1 !== null) {
                            turnstile.reset(turnstileWidgetId1);
                        }
                    }
                },
                errorCallback: function(error) {
                    showAlert('An error occurred. Please try again.', 'danger');
                    // Reset first widget
                    if (turnstileWidgetId1 !== null) {
                        turnstile.reset(turnstileWidgetId1);
                    }
                }
            });
        });

        // Verify OTP form handler
        $('#verifyOtpForm').submit(function(e) {
            e.preventDefault();
            const turnstileResponse = $('#cf-turnstile-response-2').val();
            
            if (!turnstileResponse) {
                showAlert('Please complete the captcha challenge.', 'danger');
                return;
            }
            
            const formData = $(this).serialize();

            sendAjaxRequest({
                url: '../../api/admin/auth/verify-otp-change-admin-password.php',
                formData: formData,
                button: $('#verifyOtpBtn'),
                loadingText: 'Verifying OTP...',
                successCallback: function(response) {
                    if (response.success) {
                        showAlert(response.message, 'success');
                        setTimeout(function() {
                            window.location.href = '../auth/login.php';
                        }, 1500);
                    } else {
                        showAlert(response.message, 'danger');
                        // Reset second widget on failure
                        if (turnstileWidgetId2 !== null) {
                            turnstile.reset(turnstileWidgetId2);
                        }
                    }
                },
                errorCallback: function(error) {
                    showAlert('An error occurred. Please try again.', 'danger');
                    // Reset second widget on error
                    if (turnstileWidgetId2 !== null) {
                        turnstile.reset(turnstileWidgetId2);
                    }
                }
            });
        });

        // Resend OTP handler
        $('#resendOTP').click(() => {
            const formData = $('#sendUsernameForm').serialize();
            const turnstileResponse = $('#cf-turnstile-response-1').val();
            
            if (!turnstileResponse) {
                showAlert('Please complete the captcha challenge to resend OTP.', 'danger');
                return;
            }

            $('#resendOTPOptionContainer').html('<span class="text-muted">Wait 2 minutes for resending OTP again.</span>');

            sendAjaxRequest({
                url: '../../api/admin/auth/send-password-reset-otp.php',
                formData: formData,
                button: null,
                loadingText: null,
                successCallback: function(response) {
                    if (response.success) {
                        showAlert(response.message, 'success');
                        // Reset first widget after successful resend
                        if (turnstileWidgetId1 !== null) {
                            turnstile.reset(turnstileWidgetId1);
                        }
                    } else {
                        showAlert(response.message, 'danger');
                        // Reset first widget on failure
                        if (turnstileWidgetId1 !== null) {
                            turnstile.reset(turnstileWidgetId1);
                        }
                    }
                },
                errorCallback: function(error) {
                    showAlert('An error occurred. Please try again.', 'danger');
                    // Reset first widget on error
                    if (turnstileWidgetId1 !== null) {
                        turnstile.reset(turnstileWidgetId1);
                    }
                },
                completeCallback: function() {
                    showResendCountDown();
                }
            });
        });

        // Generic AJAX request function
        function sendAjaxRequest(options) {
            $.ajax({
                url: options.url,
                type: 'POST',
                data: options.formData,
                dataType: 'json',
                beforeSend: function() {
                    if (options.button) {
                        options.button.prop('disabled', true);
                        if (options.loadingText) {
                            options.button.html(`<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> ${options.loadingText}`);
                        }
                    }
                },
                success: function(response) {
                    if (typeof options.successCallback === 'function') {
                        options.successCallback(response);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error, 'Response:', xhr.responseText);
                    if (typeof options.errorCallback === 'function') {
                        options.errorCallback(error);
                    }
                },
                complete: function() {
                    if (options.button) {
                        setTimeout(function() {
                            options.button.prop('disabled', false);
                            if (options.button.attr('id') === 'sendOtpBtn') {
                                options.button.html('<i class="fa-solid fa-arrow-right"></i> Next');
                            } else if (options.button.attr('id') === 'verifyOtpBtn') {
                                options.button.html('<i class="fa-solid fa-paper-plane"></i> Verify OTP');
                            }
                        }, 1500);
                    }
                    if (typeof options.completeCallback === 'function') {
                        options.completeCallback();
                    }
                }
            });
        }

        // Show alert message
        function showAlert(message, type) {
            toastr[type === 'success' ? 'success' : 'error'](message);
            $('#alert-box').removeClass('d-none alert-success alert-danger')
                          .addClass(`alert-${type}`)
                          .html(message);
        }

        // Show reset count down function
        function showResendCountDown() {
            // Clear any existing timer
            if (resendTimer) {
                clearInterval(resendTimer);
            }
            
            let timeLeft = 120; // seconds

            resendTimer = setInterval(() => {
                $('#resendOTPOptionContainer').html(`<span class="text-muted">Wait ${timeLeft} seconds for resending OTP again.</span>`);
                timeLeft--;

                if (timeLeft < 0) {
                    clearInterval(resendTimer);
                    $('#resendOTPOptionContainer').html('<span id="resendOTP" style="color:#0d6efd; cursor: pointer;">Resend OTP</span>');
                }
            }, 1000);
        }
    });
</script>

<?php include_once(__DIR__ . '/../../includes/body-close.php'); ?>