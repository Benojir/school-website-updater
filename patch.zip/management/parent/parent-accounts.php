<?php

/** @var PDO $pdo
 * @var string $school_name
 */
include_once("../../includes/auth-check.php");

// ----------------- AJAX HANDLERS -----------------
// AJAX রিকোয়েস্টগুলোর জন্য লজিক (শুধুমাত্র JSON রিটার্ন করবে)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax_action'])) {
    header('Content-Type: application/json');
    
    // পারমিশন চেক (AJAX রিকোয়েস্টের জন্য)
    if (!hasPermission(PERM_MANAGE_PARENTS)) {
        echo json_encode(['status' => 'error', 'message' => 'Permission denied']);
        exit;
    }

    $action = $_POST['ajax_action'];

    // ১. অ্যাকাউন্ট ডিলিট করা
    if ($action === 'delete') {
        $phone = $_POST['phone_number'];
        $stmt = $pdo->prepare("DELETE FROM parent_accounts WHERE phone_number = :phone");
        $stmt->bindParam(':phone', $phone);
        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Account deleted successfully.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to delete account.']);
        }
        exit;
    } 
    
    // ২. পাসওয়ার্ড পরিবর্তন করা
    if ($action === 'change_password') {
        $phone = $_POST['phone_number'];
        $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE parent_accounts SET password_hash = :password WHERE phone_number = :phone");
        $stmt->bindParam(':password', $new_password);
        $stmt->bindParam(':phone', $phone);
        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Password updated successfully.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update password.']);
        }
        exit;
    }

    // ৩. ডেটা ফেচ (সার্চ ও পেজিনেশন সহ)
    if ($action === 'fetch') {
        $page = isset($_POST['page']) && is_numeric($_POST['page']) ? (int)$_POST['page'] : 1;
        $limit = 50;
        $offset = ($page - 1) * $limit;
        $search = trim($_POST['search'] ?? '');

        if (!empty($search)) {
            $searchParam = "%$search%";
            
            // পেজিনেশনের জন্য মোট রো-এর সংখ্যা বের করা
            $countStmt = $pdo->prepare("
                SELECT COUNT(DISTINCT pa.id) FROM parent_accounts pa
                LEFT JOIN students s ON pa.phone_number = s.phone_number
                WHERE pa.phone_number LIKE :search_phone 
                   OR s.name LIKE :search_name
                   OR s.father_name LIKE :search_father
                   OR s.mother_name LIKE :search_mother
            ");
            $countStmt->bindValue(':search_phone', $searchParam, PDO::PARAM_STR);
            $countStmt->bindValue(':search_name', $searchParam, PDO::PARAM_STR);
            $countStmt->bindValue(':search_father', $searchParam, PDO::PARAM_STR);
            $countStmt->bindValue(':search_mother', $searchParam, PDO::PARAM_STR);
            $countStmt->execute();
            $total_records = $countStmt->fetchColumn();

            // আসল ডেটা ফেচ করা
            $stmt = $pdo->prepare("
                SELECT DISTINCT pa.* FROM parent_accounts pa
                LEFT JOIN students s ON pa.phone_number = s.phone_number
                WHERE pa.phone_number LIKE :search_phone 
                   OR s.name LIKE :search_name
                   OR s.father_name LIKE :search_father
                   OR s.mother_name LIKE :search_mother
                ORDER BY pa.updated_at DESC 
                LIMIT :limit OFFSET :offset
            ");
            $stmt->bindValue(':search_phone', $searchParam, PDO::PARAM_STR);
            $stmt->bindValue(':search_name', $searchParam, PDO::PARAM_STR);
            $stmt->bindValue(':search_father', $searchParam, PDO::PARAM_STR);
            $stmt->bindValue(':search_mother', $searchParam, PDO::PARAM_STR);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        } else {
            $countStmt = $pdo->query("SELECT COUNT(id) FROM parent_accounts");
            $total_records = $countStmt->fetchColumn();

            $stmt = $pdo->prepare("SELECT * FROM parent_accounts ORDER BY updated_at DESC LIMIT :limit OFFSET :offset");
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        }
        $stmt->execute();
        $parent_accounts = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // HTML টেবিল রো তৈরি করা
        $html = '';
        if (empty($parent_accounts)) {
            $html .= '<tr><td colspan="5" class="text-center py-5 text-muted"><i class="fas fa-folder-open fs-1 mb-3 text-light"></i><br>No accounts found.</td></tr>';
        } else {
            foreach ($parent_accounts as $parent_account) {
                $phone = $parent_account['phone_number'];
                
                $childStmt = $pdo->prepare("SELECT * FROM students WHERE phone_number = :phone");
                $childStmt->bindParam(':phone', $phone);
                $childStmt->execute();
                $children = $childStmt->fetchAll(PDO::FETCH_ASSOC);

                // বাচ্চারা না থাকলে প্যারেন্ট অ্যাকাউন্ট ক্লিনআপ
                if (empty($children)) {
                    $delStmt = $pdo->prepare("DELETE FROM parent_accounts WHERE phone_number = :phone");
                    $delStmt->bindParam(':phone', $phone);
                    $delStmt->execute();
                    continue;
                }

                $father_name = htmlspecialchars($children[0]['father_name'] ?? 'N/A');
                $phone_safe = htmlspecialchars($phone);
                $id_safe = htmlspecialchars($parent_account['id']);
                
                $html .= "<tr>";
                $html .= "<td class='px-3 fw-bold text-muted'>{$id_safe}</td>";
                $html .= "<td>{$father_name}</td>";
                $html .= "<td><span class='badge bg-secondary px-2 py-2 fs-6'><i class='fas fa-phone-alt me-1'></i> {$phone_safe}</span></td>";
                
                $html .= "<td><div class='d-flex flex-column gap-2 my-2'>";
                foreach ($children as $child) {
                    $student_id = $child['student_id'];
                    $child_info = getStudentInfo($pdo, $student_id); // Assuming this is defined elsewhere
                    $c_name = htmlspecialchars($child_info['name'] ?? 'Unknown');
                    $c_class = htmlspecialchars($child_info['class_name'] ?? '-');
                    $c_sec = htmlspecialchars($child_info['section_name'] ?? '-');
                    $c_roll = htmlspecialchars($child_info['roll_no'] ?? '-');
                    $s_url = BASE_URL . "/parent/dashboard/student-details.php?student_id=" . urlencode($student_id);
                    
                    $html .= "<div class='p-2 border rounded bg-light border-start border-4 border-primary shadow-sm'>
                                <a href='{$s_url}' class='text-decoration-none fw-bold text-dark d-block mb-1' target='_blank'>
                                    <i class='fas fa-user-graduate me-1 text-primary'></i> {$c_name}
                                </a>
                                <div class='small text-muted d-flex justify-content-between'>
                                    <span><strong>Class:</strong> {$c_class} - {$c_sec}</span>
                                    <span><strong>Roll:</strong> {$c_roll}</span>
                                </div>
                              </div>";
                }
                $html .= "</div></td>";
                
                $html .= "<td class='text-end px-3'>
                            <div class='btn-group shadow-sm' role='group'>
                                <button type='button' class='btn btn-sm btn-warning text-dark' title='Change Password' onclick=\"openPasswordModal('{$phone_safe}')\">
                                    <i class='fas fa-key'></i>
                                </button>
                                <button type='button' class='btn btn-sm btn-danger' title='Delete Account' onclick=\"confirmDelete('{$phone_safe}')\">
                                    <i class='fas fa-trash-alt'></i>
                                </button>
                            </div>
                          </td>";
                $html .= "</tr>";
            }
        }

        // পেজিনেশন HTML তৈরি করা
        $total_pages = ceil($total_records / $limit);
        $pagination_html = '';
        if ($total_pages > 1) {
            $pagination_html .= '<nav><ul class="pagination justify-content-center mt-3 mb-0">';
            
            $prev_disabled = ($page <= 1) ? 'disabled' : '';
            $pagination_html .= "<li class='page-item {$prev_disabled}'><a class='page-link' href='#' onclick='loadData(" . ($page - 1) . "); return false;'>Previous</a></li>";
            
            // ডায়নামিক পেজ নাম্বার
            for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++) {
                $active = ($i == $page) ? 'active' : '';
                $pagination_html .= "<li class='page-item {$active}'><a class='page-link' href='#' onclick='loadData({$i}); return false;'>{$i}</a></li>";
            }

            $next_disabled = ($page >= $total_pages) ? 'disabled' : '';
            $pagination_html .= "<li class='page-item {$next_disabled}'><a class='page-link' href='#' onclick='loadData(" . ($page + 1) . "); return false;'>Next</a></li>";
            
            $pagination_html .= '</ul></nav>';
        }

        echo json_encode([
            'html' => $html,
            'pagination' => $pagination_html,
            'total_pages' => $total_pages
        ]);
        exit;
    }
}
// ----------------- END AJAX HANDLERS -----------------

// মূল পেজ লোড হলে নরমাল পারমিশন চেক
if (!hasPermission(PERM_MANAGE_PARENTS)) {
    include_once("../../includes/permission-denied.php");
    exit;
}

require_once("../../includes/header-open.php");
echo "<title>Parent Accounts - " . htmlspecialchars($school_name) . "</title>";
require_once("../../includes/header-close.php");
require_once("../../includes/dashboard-navbar.php");
?>

<div class="container mt-4">
    <div class="card shadow-sm mb-3 border-0">
        <div class="card-header d-flex flex-column flex-md-row justify-content-between align-items-center bg-primary text-white rounded-top">
            <div class="mb-2 mb-md-0">
                <h4 class="mb-0 fw-bold"><i class="fas fa-users me-2"></i>Parent Accounts</h4>
            </div>
            
            <form id="searchForm" class="d-flex mb-2 mb-md-0 mx-md-3" style="flex-grow: 1; max-width: 400px;">
                <div class="input-group input-group-sm">
                    <input type="text" id="searchInput" class="form-control" placeholder="Search by student, parent name or phone...">
                    <button type="submit" class="btn btn-light text-primary fw-bold"><i class="fas fa-search"></i> Search</button>
                    <button type="button" id="clearSearch" class="btn btn-danger d-none" title="Clear Search"><i class="fas fa-times"></i></button>
                </div>
            </form>

            <div>
                <button type="button" class="btn btn-sm btn-light" onclick="history.back();">
                    <i class="fas fa-arrow-left me-2"></i>Go Back
                </button>
            </div>
        </div>
        
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="px-3">ID</th>
                            <th>Father's Name</th>
                            <th>Phone</th>
                            <th style="min-width: 300px;">Children Details</th>
                            <th class="text-end px-3">Action</th>
                        </tr>
                    </thead>
                    <tbody id="tableBody">
                        <tr>
                            <td colspan="5" class="text-center py-5">
                                <div class="spinner-border text-primary" role="status"></div>
                                <div class="mt-2 text-muted">Loading data...</div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <div id="paginationContainer" class="p-3 bg-light border-top"></div>
        </div>
    </div>
</div>

<div class="modal fade" id="passwordModal" tabindex="-1" aria-labelledby="passwordModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="passwordModalLabel"><i class="fas fa-lock me-2"></i>Change Password</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="passwordForm">
                <div class="modal-body p-4">
                    <input type="hidden" name="phone_number" id="modal_phone_number">
                    
                    <div class="mb-3">
                        <label for="new_password" class="form-label fw-bold">New Password</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light"><i class="fas fa-key text-muted"></i></span>
                            <input type="text" class="form-control" id="new_password" name="new_password" required placeholder="Type new password...">
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" id="btnUpdatePassword" class="btn btn-primary"><i class="fas fa-save me-1"></i> Update Password</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
let currentPage = 1;

// ডেটা লোড করার প্রধান ফাংশন
function loadData(page = 1) {
    currentPage = page;
    let searchValue = $('#searchInput').val().trim();
    
    // Clear বাটন টগল করা
    if(searchValue !== '') {
        $('#clearSearch').removeClass('d-none');
    } else {
        $('#clearSearch').addClass('d-none');
    }

    // টেবিল লোডিং স্টেট
    $('#tableBody').html('<tr><td colspan="5" class="text-center py-5"><div class="spinner-border text-primary" role="status"></div><div class="mt-2 text-muted">Loading data...</div></td></tr>');
    
    $.post('parent-accounts.php', {
        ajax_action: 'fetch',
        page: currentPage,
        search: searchValue
    }, function(response) {
        $('#tableBody').html(response.html);
        $('#paginationContainer').html(response.pagination);
    }, 'json').fail(function() {
        $('#tableBody').html('<tr><td colspan="5" class="text-center py-4 text-danger">Failed to load data. Please try again.</td></tr>');
    });
}

$(document).ready(function() {
    // পেজ লোড হওয়ার সাথে সাথে ডেটা আনা হবে
    loadData();

    // Type and Search (Live Search with Debounce)
    let searchTimeout;
    $('#searchInput').on('input', function() {
        clearTimeout(searchTimeout);
        // ইউজার টাইপ করা থামানোর ৫০০ মিলি-সেকেন্ড পর অটোমেটিক সার্চ হবে
        searchTimeout = setTimeout(function() {
            loadData(1);
        }, 500); 
    });

    // ফর্ম সাবমিট (যদি কেউ এন্টার চাপে)
    $('#searchForm').submit(function(e) {
        e.preventDefault();
        clearTimeout(searchTimeout);
        loadData(1);
    });

    // ক্লিয়ার সার্চ বাটন
    $('#clearSearch').click(function() {
        $('#searchInput').val('');
        loadData(1);
    });

    // পাসওয়ার্ড আপডেট ফর্ম সাবমিট
    $('#passwordForm').submit(function(e) {
        e.preventDefault();
        let submitBtn = $('#btnUpdatePassword');
        submitBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-1"></span> Updating...');

        $.post('parent-accounts.php', {
            ajax_action: 'change_password',
            phone_number: $('#modal_phone_number').val(),
            new_password: $('#new_password').val()
        }, function(response) {
            submitBtn.prop('disabled', false).html('<i class="fas fa-save me-1"></i> Update Password');
            
            if(response.status === 'success') {
                toastr.success(response.message);
                $('#passwordModal').modal('hide');
            } else {
                toastr.error(response.message);
            }
        }, 'json');
    });
});

// পাসওয়ার্ড মডাল ওপেন করা
function openPasswordModal(phone) {
    $('#modal_phone_number').val(phone);
    $('#new_password').val('');
    var passwordModal = new bootstrap.Modal(document.getElementById('passwordModal'));
    passwordModal.show();
}

// অ্যাকাউন্ট ডিলিট কনফার্মেশন ও প্রসেস
function confirmDelete(phone) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this! All parent access for this number will be removed.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        cancelButtonColor: '#6c757d',
        confirmButtonText: '<i class="fas fa-trash-alt me-1"></i> Yes, delete it!',
        cancelButtonText: 'Cancel',
        customClass: {
            confirmButton: 'btn btn-danger py-2 px-4',
            cancelButton: 'btn btn-secondary py-2 px-4',
            popup: 'rounded-4 shadow-lg'
        }
    }).then((result) => {
        if (result.isConfirmed) {
            $.post('parent-accounts.php', {
                ajax_action: 'delete',
                phone_number: phone
            }, function(response) {
                if(response.status === 'success') {
                    toastr.success(response.message);
                    loadData(currentPage); // যে পেজে ছিলো সেই পেজেই আবার ডেটা লোড করবে
                } else {
                    toastr.error(response.message);
                }
            }, 'json');
        }
    });
}
</script>

<?php include_once("../../includes/body-close.php"); ?>