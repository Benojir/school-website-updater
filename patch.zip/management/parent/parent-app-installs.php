<?php
/** @var PDO $pdo
 * @var string $school_name
 */
require_once("../../includes/auth-check.php");
require_once("../../includes/header-open.php");
echo "<title>Parent App Installs - " . htmlspecialchars($school_name) . "</title>";
require_once("../../includes/header-close.php");
require_once("../../includes/dashboard-navbar.php");

// পারমিশন চেক
if (!hasPermission(PERM_MANAGE_PARENTS)) {
    include_once("../../includes/permission-denied.php");
    exit;
}

// Pagination Setup
$limit = 10;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Total records count for pagination
$totalStmt = $pdo->query("
    SELECT COUNT(DISTINCT pas.phone) 
    FROM parent_auth_sessions pas 
    WHERE pas.phone IS NOT NULL AND pas.phone != ''
");
$totalRecords = $totalStmt->fetchColumn();
$totalPages = ceil($totalRecords / $limit);

// Fetch paginated phones first to optimize query
$phoneStmt = $pdo->prepare("
    SELECT DISTINCT pas.phone 
    FROM parent_auth_sessions pas 
    WHERE pas.phone IS NOT NULL AND pas.phone != '' 
    ORDER BY pas.last_activity DESC 
    LIMIT :limit OFFSET :offset
");
$phoneStmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$phoneStmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$phoneStmt->execute();
$paginatedPhones = $phoneStmt->fetchAll(PDO::FETCH_COLUMN);

$installData = [];

if (!empty($paginatedPhones)) {
    // IN clause এর জন্য placeholder তৈরি
    $inQuery = implode(',', array_fill(0, count($paginatedPhones), '?'));
    
    $sql = "
        SELECT 
            pas.id AS session_id,
            pas.phone,
            pas.device_name,
            pas.app_version,
            pas.last_activity,
            pas.ip_address,
            pas.session_source,
            s.student_id,
            s.name AS student_name,
            s.father_name,
            s.mother_name,
            s.class_id,
            s.section_id,
            s.student_image
        FROM parent_auth_sessions pas
        LEFT JOIN students s 
            ON pas.phone = s.phone_number OR pas.phone = s.alternate_phone_number
        WHERE pas.phone IN ($inQuery)
        ORDER BY pas.last_activity DESC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($paginatedPhones);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($results as $row) {
        $phone = $row['phone'];
        
        if (!isset($installData[$phone])) {
            $installData[$phone] = [
                'phone'    => $phone,
                'students' => [],
                'sessions' => []
            ];
        }
        
        // স্টুডেন্ট লিস্ট আপডেট
        if (!empty($row['student_id'])) {
            $isDuplicateStudent = false;
            foreach ($installData[$phone]['students'] as $existingStudent) {
                if ($existingStudent['id'] === $row['student_id']) {
                    $isDuplicateStudent = true;
                    break;
                }
            }
            if (!$isDuplicateStudent) {
                $installData[$phone]['students'][] = [
                    'id'          => $row['student_id'],
                    'name'        => $row['student_name'],
                    'father_name' => $row['father_name'] ?: 'N/A',
                    'mother_name' => $row['mother_name'] ?: 'N/A',
                    'image'       => $row['student_image']
                ];
            }
        }

        // সেশন আপডেট
        $sessionId = $row['session_id'];
        $isDuplicateSession = false;
        foreach ($installData[$phone]['sessions'] as $existingSession) {
            if ($existingSession['session_id'] === $sessionId) {
                $isDuplicateSession = true;
                break;
            }
        }
        if (!$isDuplicateSession) {
            $installData[$phone]['sessions'][] = [
                'session_id'    => $sessionId,
                'device_name'   => $row['device_name'],
                'app_version'   => $row['app_version'] ?: 'N/A',
                'last_activity' => $row['last_activity'],
                'ip_address'    => $row['ip_address'] ?: 'N/A',
                'source'        => $row['session_source']
            ];
        }
    }
}

// --- Page-level summary stats ---
$pageDeviceCount = 0;
$pageMultiDeviceCount = 0;
$uniqueStudentIds = [];
$noStudentCount = 0;
foreach ($installData as $data) {
    $sessionCount = count($data['sessions']);
    $pageDeviceCount += $sessionCount;
    if ($sessionCount > 1) $pageMultiDeviceCount++;
    if (empty($data['students'])) {
        $noStudentCount++;
    } else {
        foreach ($data['students'] as $s) {
            $uniqueStudentIds[$s['id']] = true;
        }
    }
}
$pageStudentCount = count($uniqueStudentIds);
?>

<div class="pai-page container-fluid mt-4">

    <!-- Page Header -->
    <div class="pai-header d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
        <div>
            <h4 class="pai-title mb-1"><i class="fas fa-mobile-screen-button me-2"></i>Parent App Installations</h4>
            <p class="pai-subtitle mb-0">Track which parents have logged in, which students they're linked to, and manage their active devices.</p>
        </div>
    </div>

    <!-- Stat Cards -->
    <div class="row row-cols-2 row-cols-md-4 g-3 mb-4">
        <div class="col">
            <div class="pai-stat-card">
                <div class="pai-stat-icon bg-primary-soft text-primary"><i class="fas fa-users"></i></div>
                <div>
                    <div class="pai-stat-value"><?= number_format($totalRecords) ?></div>
                    <div class="pai-stat-label">Registered Parents</div>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="pai-stat-card">
                <div class="pai-stat-icon bg-info-soft text-info"><i class="fas fa-mobile-alt"></i></div>
                <div>
                    <div class="pai-stat-value"><?= number_format($pageDeviceCount) ?></div>
                    <div class="pai-stat-label">Devices (this page)</div>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="pai-stat-card">
                <div class="pai-stat-icon bg-success-soft text-success"><i class="fas fa-user-graduate"></i></div>
                <div>
                    <div class="pai-stat-value"><?= number_format($pageStudentCount) ?></div>
                    <div class="pai-stat-label">Linked Students (this page)</div>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="pai-stat-card">
                <div class="pai-stat-icon bg-warning-soft text-warning"><i class="fas fa-exclamation-triangle"></i></div>
                <div>
                    <div class="pai-stat-value"><?= number_format($noStudentCount) ?></div>
                    <div class="pai-stat-label">No Student Linked</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Card -->
    <div class="card shadow-sm border-0 pai-main-card">
        <div class="card-header bg-white border-bottom py-3">
            <div class="d-flex flex-wrap align-items-center justify-content-between gap-2">
                <h6 class="m-0 fw-bold text-primary"><i class="fas fa-list-ul me-2"></i>Installation Records</h6>
                <div class="pai-search-wrap">
                    <i class="fas fa-search pai-search-icon"></i>
                    <input type="text" id="liveSearch" class="form-control pai-search-input" placeholder="Search by name, phone or device...">
                    <button type="button" id="clearSearch" class="pai-search-clear" style="display:none;" title="Clear search">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
        </div>

        <div class="card-body p-3 p-md-4">

            <!-- Column labels (desktop only) -->
            <div class="pai-col-labels d-none d-lg-grid">
                <span>Phone Number</span>
                <span>Associated Students</span>
                <span class="text-center">Connected Devices</span>
            </div>

            <div id="appInstallsList" class="pai-list">
                <?php if (empty($installData)): ?>
                    <div class="pai-empty">
                        <div class="pai-empty-icon"><i class="fas fa-inbox"></i></div>
                        <h6 class="mb-1">No installation data found</h6>
                        <p class="text-muted mb-0">No parent has logged into the app yet.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($installData as $data):
                        $phoneId = preg_replace('/[^0-9]/', '', $data['phone']);
                        $totalDevices = count($data['sessions']);
                    ?>
                        <div class="pai-card" data-phone="<?= htmlspecialchars($data['phone']) ?>">
                            <div class="pai-card-cell pai-cell-phone">
                                <div class="pai-phone-icon"><i class="fas fa-phone-alt"></i></div>
                                <div class="flex-grow-1">
                                    <div class="pai-phone-number"><?= htmlspecialchars($data['phone']) ?></div>
                                    <button type="button" class="pai-copy-btn" data-copy="<?= htmlspecialchars($data['phone']) ?>" title="Copy number">
                                        <i class="far fa-copy me-1"></i>Copy
                                    </button>
                                </div>
                            </div>

                            <div class="pai-card-cell pai-cell-students">
                                <span class="pai-cell-label d-lg-none">Associated Students</span>
                                <?php if (empty($data['students'])): ?>
                                    <span class="badge pai-badge-warning"><i class="fas fa-exclamation-triangle me-1"></i>No Active Students Found</span>
                                <?php else: ?>
                                    <div class="d-flex flex-column gap-2">
                                        <?php foreach ($data['students'] as $student): ?>
                                            <div class="pai-student-chip">
                                                <div class="pai-student-avatar"><i class="fas fa-user-graduate"></i></div>
                                                <div class="flex-grow-1 min-w-0">
                                                    <div class="pai-student-name">
                                                        <a href="<?= BASE_URL ?>/parent/dashboard/student-details.php?student_id=<?= urlencode($student['id']) ?>" target="_blank">
                                                            <?= htmlspecialchars($student['name']) ?>
                                                        </a>
                                                        <span class="badge pai-badge-id">ID <?= htmlspecialchars($student['id']) ?></span>
                                                    </div>
                                                    <div class="pai-student-meta">
                                                        <span><i class="fas fa-user-tie me-1"></i><?= htmlspecialchars($student['father_name']) ?></span>
                                                        <span><i class="fas fa-user me-1"></i><?= htmlspecialchars($student['mother_name']) ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="pai-card-cell pai-cell-devices">
                                <span class="badge pai-badge-devices">
                                    <i class="fas fa-mobile-alt me-1"></i><?= $totalDevices ?> Device<?= $totalDevices == 1 ? '' : 's' ?>
                                </span>
                                <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#deviceModal_<?= $phoneId ?>">
                                    <i class="fas fa-eye me-1"></i>View Devices
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <div id="paginationContainer" class="pai-pagination mt-4 d-flex flex-wrap gap-2 justify-content-between align-items-center">
                <span class="text-muted small">Showing page <strong><?= $page ?></strong> of <strong><?= max($totalPages, 1) ?></strong> &middot; <?= number_format($totalRecords) ?> total parents</span>
                <nav aria-label="Page navigation">
                    <ul class="pagination pagination-sm mb-0">
                        <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page - 1 ?>"><i class="fas fa-chevron-left me-1"></i>Previous</a>
                        </li>
                        <li class="page-item <?= ($page >= $totalPages) ? 'disabled' : '' ?>">
                            <a class="page-link" href="?page=<?= $page + 1 ?>">Next<i class="fas fa-chevron-right ms-1"></i></a>
                        </li>
                    </ul>
                </nav>
            </div>

        </div>
    </div>
</div>

<div id="modalsContainer">
    <?php if (!empty($installData)): ?>
        <?php foreach ($installData as $data):
            $phoneId = preg_replace('/[^0-9]/', '', $data['phone']);
        ?>
            <div class="modal fade" id="deviceModal_<?= $phoneId ?>" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content border-0 shadow pai-modal">
                        <div class="modal-header pai-modal-header">
                            <div>
                                <h5 class="modal-title fw-bold mb-0">
                                    <i class="fas fa-mobile-alt me-2"></i>Devices for <?= htmlspecialchars($data['phone']) ?>
                                </h5>
                                <small class="pai-modal-subtitle"><?= count($data['sessions']) ?> active session(s)</small>
                            </div>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body p-0">
                            <div class="pai-device-list" id="deviceList_<?= $phoneId ?>">
                                <?php foreach ($data['sessions'] as $session): ?>
                                    <div class="pai-device-row" id="sessionRow_<?= htmlspecialchars($session['session_id']) ?>">
                                        <div class="pai-device-info">
                                            <div class="pai-device-icon"><i class="fas fa-mobile-alt"></i></div>
                                            <div class="min-w-0">
                                                <div class="fw-bold text-dark text-truncate"><?= htmlspecialchars($session['device_name']) ?></div>
                                                <div class="text-muted small">
                                                    <i class="fas fa-network-wired me-1"></i>
                                                    <a href="https://ipinfo.io/<?= htmlspecialchars($session['ip_address']) ?>" target="_blank" class="text-decoration-none">
                                                        <?= htmlspecialchars($session['ip_address']) ?>
                                                    </a>
                                                    <span class="badge pai-badge-source ms-2"><?= htmlspecialchars($session['source']) ?></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="pai-device-meta">
                                            <span class="badge pai-badge-version"><?= htmlspecialchars($session['app_version']) ?></span>
                                            <span class="pai-device-time"><i class="far fa-clock me-1"></i><?= date('d M Y, h:i A', strtotime($session['last_activity'])) ?></span>
                                        </div>
                                        <div class="pai-device-action">
                                            <button class="btn btn-sm btn-danger rounded-pill shadow-sm" onclick="logoutDevice(<?= $session['session_id'] ?>, this)">
                                                <i class="fas fa-sign-out-alt me-1"></i>Logout
                                            </button>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<style>
    .pai-page { --pai-radius: 14px; }

    .pai-title { color: var(--dark-color, #212529); font-weight: 800; }
    .pai-subtitle { color: #6c757d; font-size: 0.92rem; }

    /* Stat cards */
    .pai-stat-card {
        display: flex; align-items: center; gap: 14px;
        background: #fff; border: 1px solid #eef0f2; border-radius: var(--pai-radius);
        padding: 16px; height: 100%;
        box-shadow: 0 2px 10px rgba(20, 20, 43, 0.03);
        transition: transform .18s ease, box-shadow .18s ease;
    }
    .pai-stat-card:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(20, 20, 43, 0.07); }
    .pai-stat-icon {
        flex-shrink: 0; width: 44px; height: 44px; border-radius: 12px;
        display: flex; align-items: center; justify-content: center; font-size: 1.05rem;
    }
    .bg-primary-soft { background: color-mix(in srgb, var(--primary-color) 14%, white); }
    .bg-info-soft { background: rgba(13, 202, 240, 0.14); }
    .bg-success-soft { background: rgba(25, 135, 84, 0.12); }
    .bg-warning-soft { background: rgba(255, 193, 7, 0.16); }
    .pai-stat-value { font-size: 1.35rem; font-weight: 800; line-height: 1.1; color: #1c1c28; }
    .pai-stat-label { font-size: 0.78rem; color: #8a8f98; font-weight: 600; }

    .pai-main-card { border-radius: var(--pai-radius); overflow: hidden; }

    /* Search */
    .pai-search-wrap { position: relative; width: 100%; max-width: 340px; }
    .pai-search-icon { position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #a3a8b3; font-size: 0.85rem; }
    .pai-search-input { padding-left: 36px; padding-right: 34px; border-radius: 999px; border: 1px solid #e3e5e9; background: #f8f9fb; }
    .pai-search-input:focus { background: #fff; box-shadow: 0 0 0 3px color-mix(in srgb, var(--primary-color) 15%, transparent); border-color: var(--primary-color); }
    .pai-search-clear { position: absolute; right: 8px; top: 50%; transform: translateY(-50%); border: none; background: transparent; color: #a3a8b3; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; }
    .pai-search-clear:hover { background: #eee; color: #555; }

    /* Column labels */
    .pai-col-labels {
        grid-template-columns: 220px 1fr 220px;
        gap: 16px; padding: 0 16px 10px; font-size: 0.75rem; text-transform: uppercase;
        letter-spacing: .04em; color: #9aa0aa; font-weight: 700;
    }

    .pai-list { display: flex; flex-direction: column; gap: 12px; }

    .pai-card {
        display: grid; grid-template-columns: 220px 1fr 220px; gap: 16px;
        align-items: center; background: #fff; border: 1px solid #eef0f2; border-radius: 12px;
        padding: 16px; animation: paiFadeIn .35s ease both;
        transition: box-shadow .18s ease, border-color .18s ease;
    }
    .pai-card:hover { box-shadow: 0 6px 18px rgba(20,20,43,0.06); border-color: #e4e6ea; }

    @keyframes paiFadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }

    .pai-cell-phone { display: flex; align-items: center; gap: 12px; }
    .pai-phone-icon {
        flex-shrink: 0; width: 42px; height: 42px; border-radius: 50%;
        background: color-mix(in srgb, var(--primary-color) 12%, white); color: var(--primary-color);
        display: flex; align-items: center; justify-content: center;
    }
    .pai-phone-number { font-weight: 800; font-size: 1.02rem; color: #1c1c28; }
    .pai-copy-btn {
        border: none; background: transparent; padding: 0; font-size: 0.76rem; color: #8a8f98;
        font-weight: 600; margin-top: 2px;
    }
    .pai-copy-btn:hover { color: var(--primary-color); }

    .pai-cell-label { display: block; font-size: 0.72rem; text-transform: uppercase; letter-spacing: .04em; color: #9aa0aa; font-weight: 700; margin-bottom: 8px; }

    .pai-student-chip { display: flex; align-items: center; gap: 10px; background: #f8f9fb; border: 1px solid #eef0f2; border-radius: 10px; padding: 8px 10px; }
    .pai-student-avatar {
        flex-shrink: 0; width: 34px; height: 34px; border-radius: 50%; background: var(--primary-color);
        color: #fff; display: flex; align-items: center; justify-content: center; font-size: 0.82rem;
    }
    .pai-student-name a { color: #1c1c28; text-decoration: none; font-weight: 700; }
    .pai-student-name a:hover { color: var(--primary-color); text-decoration: underline; }
    .pai-student-meta { display: flex; flex-wrap: wrap; gap: 12px; color: #8a8f98; font-size: 0.78rem; margin-top: 2px; }

    .pai-cell-devices { display: flex; flex-direction: column; align-items: center; gap: 8px; text-align: center; }

    .pai-badge-warning { background: rgba(255, 193, 7, 0.18); color: #9a6b00; font-weight: 600; padding: 7px 12px; border-radius: 999px; }
    .pai-badge-id { background: #eef0f2; color: #666; font-weight: 600; margin-left: 6px; }
    .pai-badge-devices { background: rgba(13, 202, 240, 0.14); color: #0b7f96; font-weight: 700; padding: 7px 14px; border-radius: 999px; font-size: 0.82rem; }

    .pai-empty { text-align: center; padding: 60px 20px; color: #6c757d; }
    .pai-empty-icon { font-size: 2.2rem; color: #d7dae0; margin-bottom: 12px; }

    /* Modal */
    .pai-modal-header { background: linear-gradient(135deg, var(--primary-color), var(--primary-dark)); color: #fff; align-items: flex-start; }
    .pai-modal-subtitle { color: rgba(255,255,255,0.8); }
    .pai-device-list { max-height: 60vh; overflow-y: auto; }
    .pai-device-row {
        display: grid; grid-template-columns: 1fr auto auto; gap: 14px; align-items: center;
        padding: 14px 20px; border-bottom: 1px solid #f0f1f3; transition: background .3s ease, opacity .3s ease;
    }
    .pai-device-row:last-child { border-bottom: none; }
    .pai-device-info { display: flex; align-items: center; gap: 12px; min-width: 0; }
    .pai-device-icon {
        flex-shrink: 0; width: 38px; height: 38px; border-radius: 10px; background: #f1f2f5; color: #6c757d;
        display: flex; align-items: center; justify-content: center;
    }
    .pai-badge-source { background: #eef0f2; color: #777; font-weight: 600; font-size: 0.68rem; }
    .pai-badge-version { background: color-mix(in srgb, var(--primary-color) 12%, white); color: var(--primary-color); font-weight: 700; }
    .pai-device-meta { display: flex; flex-direction: column; align-items: flex-end; gap: 4px; }
    .pai-device-time { color: var(--primary-color); font-size: 0.8rem; white-space: nowrap; }
    .pai-device-row.pai-removing { opacity: 0; transform: scale(0.97); }

    /* Skeleton loading */
    .pai-skeleton-card { background: #fff; border: 1px solid #eef0f2; border-radius: 12px; padding: 16px; display: grid; grid-template-columns: 220px 1fr 220px; gap: 16px; }
    .pai-skel { background: linear-gradient(90deg, #eef0f2 25%, #f6f7f8 37%, #eef0f2 63%); background-size: 400% 100%; animation: paiShimmer 1.4s ease infinite; border-radius: 6px; }
    @keyframes paiShimmer { 0% { background-position: 100% 50%; } 100% { background-position: 0 50%; } }

    /* Responsive: stack cards below 992px */
    @media (max-width: 991.98px) {
        .pai-card { grid-template-columns: 1fr; gap: 14px; }
        .pai-card-cell:not(:last-child) { padding-bottom: 14px; border-bottom: 1px dashed #eef0f2; }
        .pai-cell-devices { flex-direction: row; justify-content: space-between; }
        .pai-skeleton-card { grid-template-columns: 1fr; }
    }
    @media (max-width: 575.98px) {
        .pai-header { flex-direction: column; align-items: flex-start !important; }
        .pai-search-wrap { max-width: 100%; }
        .pai-device-row { grid-template-columns: 1fr; text-align: left; }
        .pai-device-meta { align-items: flex-start; flex-direction: row; justify-content: space-between; }
    }
</style>

<script>
(function () {
    const listEl = document.getElementById('appInstallsList');
    const modalsContainer = document.getElementById('modalsContainer');
    const paginationContainer = document.getElementById('paginationContainer');
    const searchInput = document.getElementById('liveSearch');
    const clearBtn = document.getElementById('clearSearch');

    let debounceTimer = null;

    searchInput.addEventListener('input', function () {
        clearBtn.style.display = this.value.trim().length ? 'flex' : 'none';
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => runSearch(this.value.trim()), 350);
    });

    clearBtn.addEventListener('click', function () {
        searchInput.value = '';
        clearBtn.style.display = 'none';
        window.location.reload();
    });

    function skeletonHtml(n) {
        let html = '';
        for (let i = 0; i < n; i++) {
            html += `
                <div class="pai-skeleton-card">
                    <div class="pai-skel" style="height:42px;"></div>
                    <div class="pai-skel" style="height:42px;"></div>
                    <div class="pai-skel" style="height:36px;"></div>
                </div>`;
        }
        return html;
    }

    function escapeHtml(str) {
        return (str ?? '').toString()
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function buildStudentsHtml(students) {
        if (!students || students.length === 0) {
            return '<span class="badge pai-badge-warning"><i class="fas fa-exclamation-triangle me-1"></i>No Active Students Found</span>';
        }
        return '<div class="d-flex flex-column gap-2">' + students.map(student => `
            <div class="pai-student-chip">
                <div class="pai-student-avatar"><i class="fas fa-user-graduate"></i></div>
                <div class="flex-grow-1 min-w-0">
                    <div class="pai-student-name">
                        <a href="<?= BASE_URL ?>/parent/dashboard/student-details.php?student_id=${encodeURIComponent(student.id)}" target="_blank">${escapeHtml(student.name)}</a>
                        <span class="badge pai-badge-id">ID ${escapeHtml(student.id)}</span>
                    </div>
                    <div class="pai-student-meta">
                        <span><i class="fas fa-user-tie me-1"></i>${escapeHtml(student.father_name)}</span>
                        <span><i class="fas fa-user me-1"></i>${escapeHtml(student.mother_name)}</span>
                    </div>
                </div>
            </div>`).join('') + '</div>';
    }

    function buildCardHtml(item, phoneId) {
        const total = item.sessions.length;
        return `
            <div class="pai-card" data-phone="${escapeHtml(item.phone)}">
                <div class="pai-card-cell pai-cell-phone">
                    <div class="pai-phone-icon"><i class="fas fa-phone-alt"></i></div>
                    <div class="flex-grow-1">
                        <div class="pai-phone-number">${escapeHtml(item.phone)}</div>
                        <button type="button" class="pai-copy-btn" data-copy="${escapeHtml(item.phone)}" title="Copy number"><i class="far fa-copy me-1"></i>Copy</button>
                    </div>
                </div>
                <div class="pai-card-cell pai-cell-students">
                    <span class="pai-cell-label d-lg-none">Associated Students</span>
                    ${buildStudentsHtml(item.students)}
                </div>
                <div class="pai-card-cell pai-cell-devices">
                    <span class="badge pai-badge-devices"><i class="fas fa-mobile-alt me-1"></i>${total} Device${total === 1 ? '' : 's'}</span>
                    <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#deviceModal_${phoneId}">
                        <i class="fas fa-eye me-1"></i>View Devices
                    </button>
                </div>
            </div>`;
    }

    function buildModalHtml(item, phoneId) {
        const rows = item.sessions.map(session => `
            <div class="pai-device-row" id="sessionRow_${session.session_id}">
                <div class="pai-device-info">
                    <div class="pai-device-icon"><i class="fas fa-mobile-alt"></i></div>
                    <div class="min-w-0">
                        <div class="fw-bold text-dark text-truncate">${escapeHtml(session.device_name)}</div>
                        <div class="text-muted small">
                            <i class="fas fa-network-wired me-1"></i>
                            <a href="https://ipinfo.io/${escapeHtml(session.ip_address)}" target="_blank" class="text-decoration-none">${escapeHtml(session.ip_address)}</a>
                            <span class="badge pai-badge-source ms-2">${escapeHtml(session.source)}</span>
                        </div>
                    </div>
                </div>
                <div class="pai-device-meta">
                    <span class="badge pai-badge-version">${escapeHtml(session.app_version)}</span>
                    <span class="pai-device-time"><i class="far fa-clock me-1"></i>${escapeHtml(session.last_activity)}</span>
                </div>
                <div class="pai-device-action">
                    <button class="btn btn-sm btn-danger rounded-pill shadow-sm" onclick="logoutDevice(${session.session_id}, this)">
                        <i class="fas fa-sign-out-alt me-1"></i>Logout
                    </button>
                </div>
            </div>`).join('');

        return `
            <div class="modal fade" id="deviceModal_${phoneId}" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content border-0 shadow pai-modal">
                        <div class="modal-header pai-modal-header">
                            <div>
                                <h5 class="modal-title fw-bold mb-0"><i class="fas fa-mobile-alt me-2"></i>Devices for ${escapeHtml(item.phone)}</h5>
                                <small class="pai-modal-subtitle">${item.sessions.length} active session(s)</small>
                            </div>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body p-0">
                            <div class="pai-device-list" id="deviceList_${phoneId}">${rows}</div>
                        </div>
                    </div>
                </div>
            </div>`;
    }

    function runSearch(query) {
        if (query.length === 0) {
            window.location.reload();
            return;
        }

        paginationContainer.style.display = 'none';
        listEl.innerHTML = skeletonHtml(3);

        fetch(`<?= BASE_URL ?>/api/admin/get/parent/search.php?q=${encodeURIComponent(query)}`)
            .then(response => response.json())
            .then(data => {
                listEl.innerHTML = '';
                modalsContainer.innerHTML = '';

                if (!data || data.length === 0) {
                    listEl.innerHTML = `
                        <div class="pai-empty">
                            <div class="pai-empty-icon"><i class="fas fa-search"></i></div>
                            <h6 class="mb-1">No results found</h6>
                            <p class="text-muted mb-0">Nothing matched "${escapeHtml(query)}". Try a different phone, name or device.</p>
                        </div>`;
                    return;
                }

                data.forEach(item => {
                    const phoneId = item.phone.replace(/\D/g, '');
                    listEl.insertAdjacentHTML('beforeend', buildCardHtml(item, phoneId));
                    modalsContainer.insertAdjacentHTML('beforeend', buildModalHtml(item, phoneId));
                });
            })
            .catch(() => {
                listEl.innerHTML = `
                    <div class="pai-empty">
                        <div class="pai-empty-icon text-danger"><i class="fas fa-triangle-exclamation"></i></div>
                        <h6 class="mb-1 text-danger">Something went wrong</h6>
                        <p class="text-muted mb-0">Couldn't fetch search results. Please try again.</p>
                    </div>`;
                toastr.error('Failed to search parent installs.');
            });
    }

    // Copy phone number to clipboard (event delegation covers both static and dynamic cards)
    document.addEventListener('click', function (e) {
        const btn = e.target.closest('.pai-copy-btn');
        if (!btn) return;
        const phone = btn.dataset.copy;
        navigator.clipboard.writeText(phone).then(() => {
            toastr.success('Phone number copied to clipboard.');
        }).catch(() => {
            toastr.error('Could not copy phone number.');
        });
    });

    // Expose logoutDevice globally (used via inline onclick in PHP + JS-built markup)
    window.logoutDevice = function (sessionId, btn) {
        Swal.fire({
            title: 'Log out this device?',
            text: 'The parent will need to sign in again on this device.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: '<i class="fas fa-sign-out-alt me-1"></i> Yes, log out',
            cancelButtonText: 'Cancel',
            confirmButtonColor: '#dc3545',
            reverseButtons: true,
            customClass: {
                confirmButton: 'btn btn-danger px-4 py-2',
                cancelButton: 'btn btn-secondary px-4 py-2',
                popup: 'rounded-4 shadow-lg'
            }
        }).then((result) => {
            if (!result.isConfirmed) return;

            const originalText = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            btn.disabled = true;

            const formData = new FormData();
            formData.append('session_id', sessionId);

            fetch('<?= BASE_URL ?>/api/admin/put/parent/logout.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const row = document.getElementById('sessionRow_' + sessionId);
                        if (row) {
                            row.classList.add('pai-removing');
                            setTimeout(() => row.remove(), 300);
                        }
                        toastr.success('Device logged out successfully.');
                    } else {
                        toastr.error(data.message || 'Logout failed.');
                        btn.innerHTML = originalText;
                        btn.disabled = false;
                    }
                })
                .catch(() => {
                    toastr.error('An error occurred while logging out the device.');
                    btn.innerHTML = originalText;
                    btn.disabled = false;
                });
        });
    };
})();
</script>

<?php include_once("../../includes/body-close.php"); ?>