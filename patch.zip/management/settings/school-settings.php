<?php
/** @var string $school_name
 * @var array $schoolSettings
 * @var string $theme_color
 */
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>School Settings - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if (!isSuperAdmin()) {
    include_once("../../includes/permission-denied.php");
}

$auto_request_monthly_fees = $schoolSettings['auto_request_monthly_fees'] ?? 0;
$admissionOpen = $schoolSettings['admission_open'] ?? 0;
$teacherApplication = $schoolSettings['teacher_application'] ?? 0;
$totalStudents = $schoolSettings['total_student_show'] ?? 0;
$adminLogin = $schoolSettings['admin_login_option_show'] ?? 0;
$allowOnlinePayment = $schoolSettings['allow_online_payment'] ?? 0;
$show_teachers_on_front_page = $schoolSettings['show_teachers_on_front_page'] ?? 0;
$need_security_pin_for_payment_entry = $schoolSettings['need_security_pin_for_payment_entry'] ?? 0;
$hide_fees_structure_from_website = $schoolSettings['hide_fees_structure_from_website'] ?? 0;
$allow_edit_teacher_application = $schoolSettings['allow_edit_teacher_application'] ?? 0;
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div>
            <div class="card shadow border-0">
                <div class="card-header bg-primary text-white py-3">
                    <h4 class="mb-0"><i class="fa-solid fa-school"></i> School Settings</h4>
                </div>
                <div class="card-body p-4">
                    <form id="schoolSettingsForm" class="needs-validation" novalidate>
                        <div class="row g-3">
                            <!-- Fees Automation -->
                            <div class="col-md-12">
                                <h5 class="border-bottom pb-2 mb-3 text-primary">Fees Automation</h5>
                            </div>

                            <div class="col-md-4">
                                <label for="auto_request_monthly_fees_day" class="form-label">Auto request monthly fees day:</label>
                                <select id="auto_request_monthly_fees_day" name="auto_request_monthly_fees_day" class="form-control">
                                    <?php
                                    for ($i = 1; $i <= 28; $i++) {
                                        $selected = (($schoolSettings['auto_request_monthly_fees_day'] ?? 28) == $i) ? 'selected' : '';
                                        echo "<option value=\"$i\" $selected>Day " . getOrdinal($i) . "</option>";
                                    }
                                    ?>
                                </select>
                            </div>

                            <!-- School Features -->
                            <div class="col-md-12 mt-4">
                                <h5 class="border-bottom pb-2 mb-3 text-primary">School Features</h5>
                            </div>

                            <div class="col-md-12">
                                <div class="form-check">
                                    <input class="form-check-input" name="admission_open_checkbox" type="checkbox" value="1" id="admission_open_checkbox"
                                        <?= ($admissionOpen) ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="admission_open_checkbox">
                                        Students can apply for admission.
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" name="teacher_application" type="checkbox" value="1" id="teacher_application"
                                        <?= ($teacherApplication) ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="teacher_application">
                                        Teachers can apply for job.
                                    </label>
                                </div>
                                <div class="form-check ms-4">
                                    <input class="form-check-input" name="allow_edit_teacher_application" type="checkbox" value="1" id="allow_edit_teacher_application"
                                        <?= ($allow_edit_teacher_application) ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="allow_edit_teacher_application">
                                        Allow editing teacher's applications.
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" name="total_students_checkbox" type="checkbox" value="1" id="total_students_checkbox"
                                        <?= ($totalStudents) ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="total_students_checkbox">
                                        Show total students count on website's front page.
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" name="admin_login_option_show" type="checkbox" value="1" id="admin_login_option_show"
                                        <?= ($adminLogin) ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="admin_login_option_show">
                                        Show admin login option on website's front page.
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" name="show_teachers_on_front_page" type="checkbox" value="1" id="show_teachers_on_front_page"
                                        <?= ($show_teachers_on_front_page) ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="show_teachers_on_front_page">
                                        Show teachers on website's front page.
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" name="allow_online_payment" type="checkbox" value="1" id="allow_online_payment"
                                        <?= ($allowOnlinePayment) ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="allow_online_payment">
                                        Allow online payments.
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" name="auto_request_monthly_fees" type="checkbox" value="1" id="auto_request_monthly_fees"
                                        <?= ($auto_request_monthly_fees) ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="auto_request_monthly_fees">
                                        Auto request student monthly fees.
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" name="need_security_pin_for_payment_entry" type="checkbox" value="1" id="need_security_pin_for_payment_entry"
                                        <?= ($need_security_pin_for_payment_entry) ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="need_security_pin_for_payment_entry">
                                        Need security pin for payment entry.
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" name="hide_fees_structure_from_website" type="checkbox" value="1" id="hide_fees_structure_from_website"
                                        <?= ($hide_fees_structure_from_website) ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="hide_fees_structure_from_website">
                                        Hide fees structure from website.
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                            <button type="submit" class="btn btn-primary px-4 py-2" id="submitBtn">
                                <span id="submitText"><i class="fa-solid fa-floppy-disk"></i> Save Settings</span>
                                <span id="spinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Form validation
        (function() {
            'use strict';
            var form = document.getElementById('schoolSettingsForm');
            form.addEventListener('submit', function(event) {
                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
            }, false);
        })();

        // AJAX form submission
        $('#schoolSettingsForm').submit(function(e) {
            e.preventDefault();

            // Show loading state
            $('#submitBtn').prop('disabled', true);
            $('#submitText').text('Saving...');
            $('#spinner').removeClass('d-none');

            var formData = new FormData(this);

            $.ajax({
                url: '../../api/admin/put/school-settings/save-school-settings.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        // Reset form validation
                        $('#schoolSettingsForm').removeClass('was-validated');
                        // Show sweetalert success message
                        Swal.fire({
                            title: 'Success!',
                            text: response.message,
                            icon: 'success',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '<?= $theme_color; ?>',
                            customClass: {
                                popup: 'rounded-4 shadow-lg'
                            }
                        });
                    } else {
                        toastr.error(response.message);
                        // Show sweetalert error message
                        Swal.fire({
                            title: 'Error!',
                            text: response.message,
                            icon: 'error',
                            confirmButtonText: 'OK',
                            confirmButtonColor: '#d33',
                            customClass: {
                                popup: 'rounded-4 shadow-lg'
                            }
                        });
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred: ' + error);
                    console.error(xhr.responseText);
                    // Show sweetalert error message
                    Swal.fire({
                        title: 'Error!',
                        text: 'An error occurred: ' + error,
                        icon: 'error',
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#d33',
                        customClass: {
                            popup: 'rounded-4 shadow-lg'
                        }
                    });
                },
                complete: function() {
                    // Reset button state
                    $('#submitBtn').prop('disabled', false);
                    $('#submitText').html('<i class="fa-solid fa-floppy-disk"></i> Save Settings');
                    $('#spinner').addClass('d-none');
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>
