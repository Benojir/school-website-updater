<?php
/** @var string $school_name */
/** @var PDO $pdo */ // আপনার ডেটাবেস কানেকশন ভেরিয়েবল
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Apps Store Management - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if (!isSuperAdmin()) {
    include_once("../../includes/permission-denied.php");
    exit;
}

// Fetch existing apps links from database to pre-fill the form
$existing_links = ['parent_app_link' => '', 'student_attendance_app_link' => '', 'driver_app_link' => ''];
try {
    // এখানে আপনার প্রয়োজন অনুযায়ী WHERE ক্লজ (যেমন WHERE id = ?) যোগ করতে পারেন
    $stmt = $pdo->query("SELECT apps_link FROM school_information LIMIT 1"); 
    $schoolInfo = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($schoolInfo && !empty($schoolInfo['apps_link'])) {
        $decoded_links = json_decode($schoolInfo['apps_link'], true);
        if (is_array($decoded_links)) {
            $existing_links = array_merge($existing_links, $decoded_links);
        }
    }
} catch (PDOException $e) {
    // Handle error quietly or log it
}
?>

<div class="container mt-2">
    <div class="card shadow border rounded-3 overflow-hidden">
        <div class="card-header bg-primary text-white py-3">
            <h4 class="mb-0 fw-bold"><i class="fas fa-link me-2"></i> Apps Link</h4>
        </div>
        
        <div class="card-body p-4">
            <form id="appsStoreForm" class="needs-validation" novalidate>
                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="url" class="form-control shadow-sm" id="parent_app_link" name="parent_app_link" placeholder="Enter parent app link" value="<?= safe_htmlspecialchars($existing_links['parent_app_link']) ?>" required>
                            <label for="parent_app_link" class="text-secondary"><i class="fas fa-mobile-alt me-1"></i> Parent App Link</label>
                            <div class="invalid-feedback">
                                Please provide a valid URL for the parent app.
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="url" class="form-control shadow-sm" id="student_attendance_app_link" name="student_attendance_app_link" placeholder="Enter student attendance app link" value="<?= safe_htmlspecialchars($existing_links['student_attendance_app_link']) ?>" required>
                            <label for="student_attendance_app_link" class="text-secondary"><i class="fas fa-user-graduate me-1"></i> Student Attendance App Link</label>
                            <div class="invalid-feedback">
                                Please provide a valid URL for the student attendance app.
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="url" class="form-control shadow-sm" id="driver_app_link" name="driver_app_link" placeholder="Enter driver app link" value="<?= safe_htmlspecialchars($existing_links['driver_app_link']) ?>" required>
                            <label for="driver_app_link" class="text-secondary"><i class="fas fa-bus me-1"></i> Driver App Link</label>
                            <div class="invalid-feedback">
                                Please provide a valid URL for the driver app.
                            </div>
                        </div>
                    </div>
                </div>

                <div class="mt-5 text-end border-top pt-4">
                    <button type="submit" id="submitBtn" class="btn btn-primary btn-lg px-5 rounded-pill shadow-sm hover-shadow">
                        <span id="spinner" class="spinner-border spinner-border-sm d-none me-2" role="status" aria-hidden="true"></span>
                        <span id="submitText"><i class="fas fa-save me-2"></i> Save Links</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#appsStoreForm').submit(function(e) {
            e.preventDefault();
            
            // Check HTML5 validation before AJAX
            if (!this.checkValidity()) {
                e.stopPropagation();
                $(this).addClass('was-validated');
                return;
            }

            // Show loading state
            $('#submitBtn').prop('disabled', true);
            $('#submitText').text('Saving...');
            $('#spinner').removeClass('d-none');

            // Create FormData object
            var formData = new FormData(this);

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/put/school/save-apps-store.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        $('#appsStoreForm').removeClass('was-validated');
                        if (typeof showSuccessAlert === "function") {
                            showSuccessAlert(response.message);
                        }
                    } else {
                        toastr.error(response.message);
                        showErrorAlert(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred. Please try again.');
                    console.error(xhr.responseText);
                    sendErrorReport(xhr.responseText);
                },
                complete: function() {
                    // Reset button state
                    $('#submitBtn').prop('disabled', false);
                    $('#submitText').html('<i class="fas fa-save me-2"></i> Save Links');
                    $('#spinner').addClass('d-none');
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>