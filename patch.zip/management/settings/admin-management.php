<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage Admins - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if (!isSuperAdmin()) {
    include_once("../../includes/permission-denied.php");
    exit();
}
?>

<div class="container mt-5">
    <h1 class="h3 mb-4 text-gray-800"><i class="fas fa-users-cog me-2"></i>Admin Management</h1>

    <div class="row mb-4">
        <div class="col-md-6">
            <button class="btn btn-primary w-100" onclick="openRoleModal()">
                <i class="fa-solid fa-plus"></i> Create New Role
            </button>
        </div>
        <div class="col-md-6">
            <button class="btn btn-primary w-100" onclick="openAdminModal()">
                <i class="fa-solid fa-user-plus"></i> Create New Admin
            </button>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header bg-dark text-white">Existing Admins</div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" width="100%">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="adminsTableBody">
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header bg-dark text-white">Existing Roles</div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" width="100%">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Role Name</th>
                            <th>Description</th>
                            <th>Perms</th>
                            <th>Admins</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="rolesTableBody">
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="roleModal" tabindex="-1" aria-labelledby="roleModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="roleModalTitle">Manage Role</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="roleForm">
                <div class="modal-body">
                    <input type="hidden" name="action" value="save_role">
                    <input type="hidden" name="role_id" id="role_id">
                    <div class="form-group mb-3">
                        <label class="form-label fw-bold" for="role_name">Role Name</label>
                        <input type="text" name="role_name" id="role_name" class="form-control" placeholder="eg: Gallery Manager" required>
                    </div>
                    <div class="form-group mb-3" for="role_description">
                        <label class="form-label fw-bold">Description</label>
                        <textarea name="role_description" id="role_description" class="form-control" placeholder="Enter the role description..."></textarea>
                    </div>

                    <h6 class="mt-3 fw-bold">Permissions</h6>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-check">
                                <input class="form-check-input perm-chk" type="checkbox" name="permissions[]" value="manage_students" id="permStudents">
                                <label class="form-check-label" for="permStudents">Manage Students</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input perm-chk" type="checkbox" name="permissions[]" value="manage_teachers" id="permTeachers">
                                <label class="form-check-label" for="permTeachers">Manage Teachers</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input perm-chk" type="checkbox" name="permissions[]" value="manage_results" id="permResults">
                                <label class="form-check-label" for="permResults">Manage Results & Marksheets</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input perm-chk" type="checkbox" name="permissions[]" value="manage_school_gallery" id="permGallery">
                                <label class="form-check-label" for="permGallery">Manage School Gallery</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input perm-chk" type="checkbox" name="permissions[]" value="manage_students_attendance" id="permAttendance">
                                <label class="form-check-label" for="permAttendance">Manage Students Attendance</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input perm-chk" type="checkbox" name="permissions[]" value="manage_transport" id="permDriver">
                                <label class="form-check-label" for="permDriver">Manage Drivers</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input perm-chk" type="checkbox" name="permissions[]" value="can_see_financial_report" id="permCanSeeFinancialReport">
                                <label class="form-check-label" for="permCanSeeFinancialReport">Can See Financial Reports</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-check">
                                <input class="form-check-input perm-chk" type="checkbox" name="permissions[]" value="manage_class_routines" id="permRoutines">
                                <label class="form-check-label" for="permRoutines">Manage Class Routines</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input perm-chk" type="checkbox" name="permissions[]" value="manage_fees" id="permFees">
                                <label class="form-check-label" for="permFees">Manage Fees</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input perm-chk" type="checkbox" name="permissions[]" value="manage_notices" id="permNotices">
                                <label class="form-check-label" for="permNotices">Manage Notices</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input perm-chk" type="checkbox" name="permissions[]" value="manage_exams" id="permExams">
                                <label class="form-check-label" for="permExams">Manage Exams</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input perm-chk" type="checkbox" name="permissions[]" value="manage_teachers_attendance" id="permTeachersAttendance">
                                <label class="form-check-label" for="permTeachersAttendance">Manage Teachers Attendance</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input perm-chk" type="checkbox" name="permissions[]" value="manage_expenses" id="permSchoolExpenses">
                                <label class="form-check-label" for="permSchoolExpenses">Manage School Expenses</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Role</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="adminModal" tabindex="-1" aria-labelledby="adminModalTitle" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="adminModalTitle">Manage Admin</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="adminForm">
                <div class="modal-body">
                    <input type="hidden" name="action" value="save_admin">
                    <input type="hidden" name="admin_id" id="admin_id">

                    <div class="mb-3"> <label class="form-label">Full Name</label>
                        <input type="text" name="full_name" id="admin_fullname" class="form-control" placeholder="eg: Bellal Ahamed" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" name="username" id="admin_username" class="form-control" placeholder="Enter an username" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" id="admin_email" class="form-control" placeholder="Enter valid email id" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Role</label>
                        <select name="role_id" id="admin_role_select" class="form-select" required>
                            <option value="">Select Role</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password <small class="text-muted">(Leave blank if not changing)</small></label>
                        <div class="input-group">
                            <input type="password" name="password" id="admin_password" class="form-control">

                            <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                <i class="fa-solid fa-eye"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Admin</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        loadAdmins();
        loadRoles();

        // --- FORM SUBMISSIONS ---

        // Save Admin
        $('#adminForm').on('submit', function(e) {
            e.preventDefault();
            $.post('../../api/admin/put/administration/api-process-admin-data.php', $(this).serialize(), function(res) {
                if (res.success) {
                    toastr.success(res.message);
                    showSuccessAlert(res.message);
                    $('#adminModal').modal('hide');
                    loadAdmins();
                    $('#adminForm')[0].reset();
                } else {
                    toastr.error(res.message);
                    showErrorAlert(res.message);
                }
            }, 'json');
        });

        // Save Role
        $('#roleForm').on('submit', function(e) {
            e.preventDefault();
            $.post('../../api/admin/put/administration/api-process-admin-data.php', $(this).serialize(), function(res) {
                if (res.success) {
                    toastr.success(res.message);
                    showSuccessAlert(res.message);
                    $('#roleModal').modal('hide');
                    loadRoles();
                    $('#roleForm')[0].reset();
                } else {
                    toastr.error(res.message);
                    showErrorAlert(res.message);
                }
            }, 'json');
        });

        // --- EDIT CLICKS ---

        // Edit Admin
        $(document).on('click', '.edit-admin', function() {
            let id = $(this).data('id');
            $.get('../../api/admin/get/administration/api-fetch-admin-data.php', {
                action: 'get_single_admin',
                id: id
            }, function(res) {
                if (res.success) {
                    openAdminModal('Edit Admin');
                    $('#admin_id').val(res.data.id);
                    $('#admin_fullname').val(res.data.full_name);
                    $('#admin_username').val(res.data.username);
                    $('#admin_email').val(res.data.email);
                    $('#admin_role_select').val(res.data.role_id);
                }
            }, 'json');
        });

        // Edit Role
        $(document).on('click', '.edit-role', function() {
            let id = $(this).data('id');
            $.get('../../api/admin/get/administration/api-fetch-admin-data.php', {
                action: 'get_single_role',
                id: id
            }, function(res) {
                if (res.success) {
                    openRoleModal('Edit Role');
                    $('#role_id').val(res.role.id);
                    $('#role_name').val(res.role.name);
                    $('#role_description').val(res.role.description);
                    // Check permissions
                    $('.perm-chk').prop('checked', false);
                    if (res.permissions) {
                        res.permissions.forEach(p => $(`.perm-chk[value="${p}"]`).prop('checked', true));
                    }
                }
            }, 'json');
        });

        // --- DELETE CLICKS (SWEETALERT2) ---

        // Delete Admin
        $(document).on('click', '.delete-admin', function() {
            let adminId = $(this).data('id');

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                customClass: {
                    popup: 'rounded-4 shadow-lg',
                    confirmButton: 'btn btn-danger px-4 py-2',
                    cancelButton: 'btn btn-secondary px-4 py-2'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    $.post('../../api/admin/delete/administration/api-delete-admin-data.php', {
                        delete_admin_id: adminId
                    }, function(res) {
                        if (res.success) {
                            showSuccessAlert(res.message, "Deleted!");
                            loadAdmins();
                        } else {
                            toastr.error(res.message);
                            showErrorAlert(res.message);
                        }
                    }, 'json');
                }
            });
        });

        // Delete Role
        $(document).on('click', '.delete-role', function() {
            let roleId = $(this).data('id');

            Swal.fire({
                title: 'Are you sure?',
                text: "Delete this role? This removes all associated admins.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                customClass: {
                    popup: 'rounded-4 shadow-lg',
                    confirmButton: 'btn btn-danger px-4 py-2',
                    cancelButton: 'btn btn-secondary px-4 py-2'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    $.post('../../api/admin/delete/administration/api-delete-admin-data.php', {
                        delete_role_id: roleId
                    }, function(res) {
                        if (res.success) {
                            showSuccessAlert(res.message, "Deleted!");
                            loadRoles();
                            loadAdmins();
                        } else {
                            toastr.error(res.message);
                            showErrorAlert(res.message);
                        }
                    }, 'json');
                }
            });
        });

        // --- PASSWORD TOGGLE ---
        $('#togglePassword').on('click', function() {
            const passwordInput = $('#admin_password');
            const icon = $(this).find('i');

            if (passwordInput.attr('type') === 'password') {
                passwordInput.attr('type', 'text');
                icon.removeClass('fa-eye').addClass('fa-eye-slash');
            } else {
                passwordInput.attr('type', 'password');
                icon.removeClass('fa-eye-slash').addClass('fa-eye');
            }
        });
    });

    // --- HELPER FUNCTIONS ---

    function loadAdmins() {
        $('#adminsTableBody').load('../../api/admin/get/administration/api-fetch-admin-data.php?action=get_admins_table');
    }

    function loadRoles() {
        $.get('../../api/admin/get/administration/api-fetch-admin-data.php?action=get_roles_list', function(data) {
            let html = '';
            let options = '<option value="">Select Role</option>';
            data.forEach(r => {
                // Table Row
                html += `<tr>
                <td>${r.id}</td>
                <td>${r.name}</td>
                <td>${r.description}</td>
                <td>${r.permissions_count}</td>
                <td>${r.admins_count}</td>
                <td>
                    <button class="btn btn-sm btn-info edit-role" data-id="${r.id}">Edit</button>
                    <button class="btn btn-sm btn-danger delete-role" data-id="${r.id}">Delete</button>
                </td>
            </tr>`;
                // Dropdown Option
                options += `<option value="${r.id}">${r.name}</option>`;
            });
            $('#rolesTableBody').html(html);
            $('#admin_role_select').html(options);
        }, 'json');
    }

    function openAdminModal(title = 'Create New Admin') {
        $('#admin_id').val(''); // Clear ID for create mode
        $('#adminModalTitle').text(title);
        // Reset password field visibility to hidden
        $('#admin_password').attr('type', 'password');
        $('#togglePassword i').removeClass('fa-eye-slash').addClass('fa-eye');
        $('#adminModal').modal('show');
    }

    function openRoleModal(title = 'Create New Role') {
        $('#role_id').val(''); // Clear ID for create mode
        $('#roleModalTitle').text(title);
        $('#roleModal').modal('show');
    }
</script>

<?php include_once("../../includes/body-close.php"); ?>