<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
// admin-management.php
include_once("../../includes/header-open.php");
echo "<title>Manage Admins - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if ($_SESSION['user']['role'] !== 'superadmin') {
    include_once("../../includes/permission-denied.php");
    exit();
}
?>

<div class="container mt-5">
    <h1 class="h3 mb-4 text-gray-800"><i class="fa-solid fa-users-gear"></i> Admin Management</h1>

    <div class="row">
        <!-- Create Role Form -->
        <div class="col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header bg-primary py-3">
                    <h5 class="m-0 font-weight-bold text-white"><i class="fa-solid fa-list-check"></i> Create New Role</h5>
                </div>
                <div class="card-body">
                    <form id="createRoleForm">
                        <div class="form-group">
                            <label>Role Name <span class="text-danger">*</span></label>
                            <input type="text" name="role_name" class="form-control" required>
                        </div>
                        <div class="form-group mt-2">
                            <label>Description</label>
                            <textarea name="role_description" class="form-control"></textarea>
                        </div>
                        <div class="form-group mt-2">
                            <label>Permissions</label>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="permissions[]" value="manage_students" id="permStudents">
                                        <label class="form-check-label" for="permStudents">Manage Students</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="permissions[]" value="manage_teachers" id="permTeachers">
                                        <label class="form-check-label" for="permTeachers">Manage Teachers</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="permissions[]" value="manage_results" id="permResults">
                                        <label class="form-check-label" for="permResults">Manage Results & Marksheets</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="permissions[]" value="manage_school_gallery" id="permGallery">
                                        <label class="form-check-label" for="permGallery">Manage School Gallery</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="permissions[]" value="manage_students_attendance" id="permAttendance">
                                        <label class="form-check-label" for="permAttendance">Manage Students Attendance</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="permissions[]" value="manage_class_routines" id="permRoutines">
                                        <label class="form-check-label" for="permRoutines">Manage Class Routines</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="permissions[]" value="manage_fees" id="permFees">
                                        <label class="form-check-label" for="permFees">Manage Fees</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="permissions[]" value="manage_notices" id="permNotices">
                                        <label class="form-check-label" for="permNotices">Manage Notices</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="permissions[]" value="manage_exams" id="permExams">
                                        <label class="form-check-label" for="permExams">Manage Exams</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="permissions[]" value="manage_teachers_attendance" id="permTeachersAttendance">
                                        <label class="form-check-label" for="permTeachersAttendance">Manage Teachers Attendance</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary mt-3"><i class="fa-solid fa-plus"></i> Create Role</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Create Admin Form -->
        <div class="col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header bg-primary py-3">
                    <h5 class="m-0 font-weight-bold text-white"><i class="fa-solid fa-user-plus"></i> Create New Admin</h5>
                </div>
                <div class="card-body">
                    <form id="createAdminForm">
                        <div class="form-group">
                            <label>Full Name <span class="text-danger">*</span></label>
                            <input type="text" name="full_name" class="form-control" required>
                        </div>
                        <div class="form-group mt-2">
                            <label>Username <span class="text-danger">*</span></label>
                            <input type="text" name="username" class="form-control" required>
                        </div>
                        <div class="form-group mt-2">
                            <label>Password <span class="text-danger">*</span></label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="form-group mt-2">
                            <label>Email ID <span class="text-danger">*</span></label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="form-group mt-2">
                            <label>Role <span class="text-danger">*</span></label>
                            <select name="role_id" class="form-control" required>
                                <option value="">Select Role</option>
                                <?php
                                $roles = $pdo->query("SELECT * FROM admin_roles")->fetchAll();
                                foreach ($roles as $role): ?>
                                    <option value="<?= $role['id'] ?>"><?= safe_htmlspecialchars($role['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary mt-4"><i class="fa-solid fa-plus"></i> Create Admin</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Existing Admins Table -->
    <div class="card shadow mb-4">
        <div class="card-header bg-dark py-3 d-flex justify-content-between align-items-center">
            <h5 class="m-0 font-weight-bold text-white"><i class="fa-solid fa-users"></i> Existing Admins</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="adminsTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Email Id</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $admins = $pdo->query("
                            SELECT u.*, r.name as role_name 
                            FROM users u
                            LEFT JOIN admin_roles r ON u.role_id = r.id
                            WHERE u.user_role = 'admin'
                        ")->fetchAll();

                        foreach ($admins as $admin): ?>
                            <tr data-id="<?= $admin['id'] ?>">
                                <td><?= $admin['id'] ?></td>
                                <td><?= safe_htmlspecialchars($admin['full_name']) ?></td>
                                <td><?= safe_htmlspecialchars($admin['username']) ?></td>
                                <td><?= safe_htmlspecialchars($admin['email']) ?></td>
                                <td><?= safe_htmlspecialchars($admin['role_name'] ?? 'No Role') ?></td>
                                <td><?= ucfirst($admin['status']) ?></td>
                                <td>
                                    <button class="btn btn-sm btn-danger delete-admin"
                                        data-id="<?= $admin['id'] ?>"
                                        data-name="<?= safe_htmlspecialchars($admin['full_name']) ?>">
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Roles Table -->
    <div class="card shadow mb-4">
        <div class="card-header bg-dark py-3 d-flex justify-content-between align-items-center">
            <h5 class="m-0 font-weight-bold text-white"><i class="fa-solid fa-rectangle-list"></i> Existing Roles</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="rolesTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Role Name</th>
                            <th>Description</th>
                            <th>Permissions Count</th>
                            <th>Admins Count</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $rolesWithCounts = $pdo->query("
                            SELECT r.*, 
                                   COUNT(p.id) as permissions_count,
                                   COUNT(u.id) as admins_count
                            FROM admin_roles r
                            LEFT JOIN admin_permissions p ON r.id = p.role_id
                            LEFT JOIN users u ON r.id = u.role_id AND u.user_role = 'admin'
                            GROUP BY r.id
                        ")->fetchAll();

                        foreach ($rolesWithCounts as $role):
                        ?>
                            <tr data-id="<?= $role['id'] ?>">
                                <td><?= $role['id'] ?></td>
                                <td><?= safe_htmlspecialchars($role['name']) ?></td>
                                <td><?= safe_htmlspecialchars($role['description']) ?></td>
                                <td><?= $role['permissions_count'] ?></td>
                                <td><?= $role['admins_count'] ?></td>
                                <td>
                                    <button class="btn btn-sm btn-danger delete-role"
                                        data-id="<?= $role['id'] ?>"
                                        data-name="<?= safe_htmlspecialchars($role['name']) ?>">
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Create Role Form Submission
        $('#createRoleForm').on('submit', function(e) {
            e.preventDefault();

            $.ajax({
                url: '../action/admin-management-action.php',
                type: 'POST',
                data: $(this).serialize() + '&create_role=1',
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        $('#createRoleForm')[0].reset();
                        // Reload roles table
                        loadRoles();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred: ' + error);
                }
            });
        });

        // Create Admin Form Submission
        $('#createAdminForm').on('submit', function(e) {
            e.preventDefault();

            $.ajax({
                url: '../action/admin-management-action.php',
                type: 'POST',
                data: $(this).serialize() + '&create_admin=1',
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        $('#createAdminForm')[0].reset();
                        // Reload admins table
                        loadAdminsTable();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred: ' + error);
                }
            });
        });

        // Delete Admin Button
        $(document).on('click', '.delete-admin', function() {
            const adminId = $(this).data('id');
            const adminName = $(this).data('name');

            Swal.fire({
                title: 'Delete Admin?',
                text: `Are you sure you want to delete ${adminName}?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '../action/admin-management-action.php',
                        type: 'GET',
                        data: {
                            delete_admin: adminId
                        },
                        dataType: 'json',
                        success: function(response) {
                            if (response.success) {
                                toastr.success(response.message);
                                // Reload admins table
                                loadAdminsTable();
                            } else {
                                toastr.error(response.message);
                            }
                        },
                        error: function(xhr, status, error) {
                            toastr.error('An error occurred: ' + error);
                        }
                    });
                }
            });
        });

        // Delete Role Button
        $(document).on('click', '.delete-role', function() {
            const roleId = $(this).data('id');
            const roleName = $(this).data('name');

            Swal.fire({
                title: 'Delete Role?',
                text: `Are you sure you want to delete ${roleName}? This will delete all permissions and unassign all admins from this role.`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '../action/admin-management-action.php',
                        type: 'GET',
                        data: {
                            delete_role: roleId
                        },
                        dataType: 'json',
                        success: function(response) {
                            if (response.success) {
                                toastr.success(response.message);
                                // Reload roles and admins tables
                                loadRoles();
                                loadAdminsTable();
                            } else {
                                toastr.error(response.message);
                            }
                        },
                        error: function(xhr, status, error) {
                            toastr.error('An error occurred: ' + error);
                        }
                    });
                }
            });
        });

        // Function to load admins table
        function loadAdminsTable() {
            $.ajax({
                url: '../action/admin-management-action.php',
                type: 'GET',
                data: {
                    get_admins: 1
                },
                dataType: 'html',
                success: function(response) {
                    $('#adminsTable tbody').html(response);
                },
                error: function(xhr, status, error) {
                    toastr.error('Failed to load admins: ' + error);
                }
            });
        }

        // Function to load roles table
        function loadRoles() {
            $.ajax({
                url: '../action/admin-management-action.php',
                type: 'GET',
                data: {
                    get_roles: 1
                },
                dataType: 'json',
                success: function(response) {
                    let tbody = $('#rolesTable tbody');
                    tbody.empty();

                    let select = $('select[name="role_id"]');
                    select.empty();
                    select.append('<option value="">Select Role</option>');

                    if (response.length > 0) {
                        response.forEach(function(role) {

                            let row = `
                                <tr data-id="${role.id}">
                                    <td>${role.id}</td>
                                    <td>${$('<div>').text(role.name).html()}</td>
                                    <td>${$('<div>').text(role.description).html()}</td>
                                    <td>${role.permissions_count}</td>
                                    <td>${role.admins_count}</td>
                                    <td>
                                        <button class="btn btn-sm btn-danger delete-role" 
                                                data-id="${role.id}" 
                                                data-name="${$('<div>').text(role.name).html()}">
                                            Delete
                                        </button>
                                    </td>
                                </tr>`;
                            tbody.append(row);

                            // modify the select options in the create admin form
                            select.append(`
                                <option value="${role.id}">${role.name}</option>
                            `);
                        });
                    } else {
                        tbody.append('<tr><td colspan="6" class="text-center">No roles found.</td></tr>');
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('Failed to load roles: ' + error);
                }
            });
        }

    });
</script>

<?php include_once("../../includes/body-close.php"); ?>