<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Update School Logo - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if (!isSuperAdmin()) {
   include_once("../../includes/permission-denied.php");
}

// Check if logo exists
$logoExists = file_exists("../../uploads/school/logo-square.png");
$faviconExists = file_exists("../../uploads/school/favicon.png");
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-lg border-0 rounded-4 overflow-hidden">
                <div class="card-header bg-primary text-white py-4">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-image fa-2x me-3"></i>
                        <h4 class="mb-0">School Brand Assets</h4>
                    </div>
                </div>
                <div class="card-body p-5">
                    <div class="text-center mb-5">
                        <?php if ($logoExists): ?>
                            <div class="current-logo mb-5">
                                <h5 class="mb-4 text-muted fw-light">Current Logo</h5>
                                <div class="logo-preview-container p-4 bg-light rounded-3 shadow-sm">
                                    <img src="../../uploads/school/logo-square.png?<?= time() ?>" alt="School Logo" class="img-fluid" style="max-width: 256px;">
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($faviconExists): ?>
                            <div class="current-favicon mb-5">
                                <h5 class="mb-4 text-muted fw-light">Current Favicon</h5>
                                <div class="favicon-preview-container p-4 bg-light rounded-3 d-inline-block shadow-sm">
                                    <img src="../../uploads/school/favicon.png?<?= time() ?>" alt="Favicon" style="width: 48px; height: 48px;">
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <form id="logoUploadForm" enctype="multipart/form-data" class="needs-validation" novalidate>
                        <div class="mb-5">
                            <div class="file-upload-card bg-light rounded-3 p-4 text-center border-2 border-dashed border-primary-hover transition-all">
                                <div class="file-upload-icon mb-3">
                                    <i class="fas fa-cloud-upload-alt fa-4x text-primary opacity-75"></i>
                                </div>
                                <h5 class="mb-2 fw-normal">Upload School Logo</h5>
                                <p class="text-muted mb-4">512×512 PNG, maximum 2MB</p>
                                
                                <div class="file-upload-wrapper position-relative">
                                    <input type="file" class="form-control visually-hidden" id="schoolLogo" name="schoolLogo" accept=".png" required>
                                    <label for="schoolLogo" class="btn btn-primary px-4 py-2 rounded-pill shadow-sm">
                                        <i class="fas fa-folder-open me-2"></i> Browse Files
                                    </label>
                                    <div class="file-info mt-3 small text-muted" id="fileInfo">
                                        <div class="file-name d-none">
                                            <i class="fas fa-file-image me-1 text-success"></i>
                                            <span id="fileName"></span>
                                            <span class="file-size badge bg-light text-dark ms-2" id="fileSize"></span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="invalid-feedback mt-2">Please upload a valid 512×512 PNG logo (max 2MB)</div>
                                <div class="form-text mt-3">
                                    <i class="fas fa-info-circle me-1 text-primary"></i> 
                                    The logo will be automatically resized to create a favicon.
                                </div>
                            </div>
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary btn-lg px-4 py-3 rounded-pill shadow-sm" id="uploadBtn">
                                <span id="uploadText">
                                    <i class="fas fa-upload me-2"></i> Upload & Process
                                </span>
                                <span id="spinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.file-upload-card {
    transition: all 0.3s ease;
    border-color: rgba(13, 110, 253, 0.2);
}

.file-upload-card:hover {
    border-color: rgba(13, 110, 253, 0.5);
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
}

.file-upload-icon {
    transition: all 0.3s ease;
}

.file-upload-card:hover .file-upload-icon {
    transform: scale(1.05);
    opacity: 1 !important;
}

.logo-preview-container, .favicon-preview-container {
    background-color: #f8f9fa;
    border: 1px solid rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease;
}

.logo-preview-container:hover, .favicon-preview-container:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
}

.border-primary-hover {
    border-color: rgba(13, 110, 253, 0.2);
}

.rounded-4 {
    border-radius: 1rem !important;
}

.transition-all {
    transition: all 0.3s ease;
}
</style>

<script>
$(document).ready(function() {
    // Update file input display
    $('#schoolLogo').on('change', function() {
        const file = this.files[0];
        if (file) {
            // Update file info display
            const fileName = file.name;
            const fileSize = (file.size / (1024 * 1024)).toFixed(2) + 'MB';
            
            $('#fileName').text(fileName);
            $('#fileSize').text(fileSize);
            $('#fileInfo .file-name').removeClass('d-none');
            
            // Validate file
            if (file.type !== 'image/png') {
                $('#schoolLogo').addClass('is-invalid');
                $('#fileInfo .file-name i').removeClass('text-success').addClass('text-danger');
                return;
            }
            
            if (file.size > 2 * 1024 * 1024) {
                $('#schoolLogo').addClass('is-invalid');
                $('#fileInfo .file-name i').removeClass('text-success').addClass('text-danger');
                return;
            }
            
            $('#schoolLogo').removeClass('is-invalid');
            $('#fileInfo .file-name i').removeClass('text-danger').addClass('text-success');
        }
    });

    // AJAX form submission
    $('#logoUploadForm').submit(function(e) {
        e.preventDefault();
        
        const fileInput = $('#schoolLogo')[0];
        const file = fileInput.files[0];
        
        // Validate file
        if (!file) {
            toastr.error('Please select a file to upload');
            $('#schoolLogo').addClass('is-invalid');
            return false;
        }
        
        // Check file type
        if (file.type !== 'image/png') {
            toastr.error('Only PNG files are allowed');
            $('#schoolLogo').addClass('is-invalid');
            return false;
        }
        
        // Check file size (2MB max)
        if (file.size > 2 * 1024 * 1024) {
            toastr.error('Logo file must be less than 2MB');
            $('#schoolLogo').addClass('is-invalid');
            return false;
        }
        
        // Show loading state
        $('#uploadBtn').prop('disabled', true);
        $('#uploadText').html('<i class="fas fa-circle-notch fa-spin me-2"></i> Processing...');
        $('#spinner').removeClass('d-none');
        
        // Create FormData object
        const formData = new FormData();
        formData.append('schoolLogo', file);
        
        // AJAX request
        $.ajax({
            url: '../../api/admin/put/school/upload-school-logo.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                    // Refresh logo previews
                    setTimeout(() => {
                        $('.current-logo img').attr('src', '../../uploads/school/logo-square.png?' + new Date().getTime());
                        $('.current-favicon img').attr('src', '../../uploads/school/favicon.png?' + new Date().getTime());
                        
                        // If previews didn't exist, create them
                        if (!$('.current-logo').length) {
                            $('#logoUploadForm').before(`
                                <div class="text-center mb-5">
                                    <div class="current-logo mb-5">
                                        <h5 class="mb-4 text-muted fw-light">Current Logo</h5>
                                        <div class="logo-preview-container p-4 bg-light rounded-3 shadow-sm">
                                            <img src="../../uploads/school/logo-square.png?${new Date().getTime()}" alt="School Logo" class="img-fluid" style="max-width: 256px;">
                                        </div>
                                    </div>
                                    <div class="current-favicon mb-5">
                                        <h5 class="mb-4 text-muted fw-light">Current Favicon</h5>
                                        <div class="favicon-preview-container p-4 bg-light rounded-3 d-inline-block shadow-sm">
                                            <img src="../../uploads/school/favicon.png?${new Date().getTime()}" alt="Favicon" style="width: 48px; height: 48px;">
                                        </div>
                                    </div>
                                </div>
                            `);
                        }
                    }, 500);
                } else {
                    toastr.error(response.message);
                }
            },
            error: function(xhr, status, error) {
                toastr.error('An error occurred: ' + error);
            },
            complete: function() {
                // Reset button state
                $('#uploadBtn').prop('disabled', false);
                $('#uploadText').html('<i class="fas fa-upload me-2"></i> Upload & Process');
                $('#spinner').addClass('d-none');
            }
        });
    });
    
    // Drag and drop functionality
    const $fileUploadCard = $('.file-upload-card');
    
    $fileUploadCard.on('dragover', function(e) {
        e.preventDefault();
        $(this).addClass('border-primary bg-primary-light');
        $('.file-upload-icon').addClass('text-white');
    });
    
    $fileUploadCard.on('dragleave', function(e) {
        e.preventDefault();
        $(this).removeClass('border-primary bg-primary-light');
        $('.file-upload-icon').removeClass('text-white');
    });
    
    $fileUploadCard.on('drop', function(e) {
        e.preventDefault();
        $(this).removeClass('border-primary bg-primary-light');
        $('.file-upload-icon').removeClass('text-white');
        
        const file = e.originalEvent.dataTransfer.files[0];
        if (file) {
            $('#schoolLogo')[0].files = e.originalEvent.dataTransfer.files;
            $('#schoolLogo').trigger('change');
        }
    });
});
</script>

<?php include_once("../../includes/body-close.php"); ?>