<?php
/** @var string $school_name */
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Update School Logo - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if (!isSuperAdmin()) {
   include_once("../../includes/permission-denied.php");
}

// Check if logo exists
$logoExists = file_exists("../../uploads/school/logo-square.png");
$faviconExists = file_exists("../../uploads/school/favicon.png");
$rectLogoExists = file_exists("../../uploads/school/logo-rectangle.png");
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow-lg border-0 rounded-4 overflow-hidden">
                <div class="card-header bg-primary text-white py-4">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-image fa-2x me-3"></i>
                        <h4 class="mb-0">School Brand Assets</h4>
                    </div>
                </div>
                <div class="card-body p-5">
                    <div class="text-center mb-5 row">
                        <?php if ($logoExists): ?>
                            <div class="col-md-4 current-logo mb-4">
                                <h5 class="mb-4 text-muted fw-light">Current Square Logo</h5>
                                <div class="logo-preview-container p-4 bg-light rounded-3 shadow-sm d-inline-block">
                                    <img src="../../uploads/school/logo-square.png?<?= time() ?>" alt="School Logo" class="img-fluid" style="max-width: 150px;">
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($rectLogoExists): ?>
                            <div class="col-md-5 current-logo-rect mb-4">
                                <h5 class="mb-4 text-muted fw-light">Current Rectangle Logo</h5>
                                <div class="logo-preview-container p-4 bg-light rounded-3 shadow-sm d-inline-block">
                                    <img src="../../uploads/school/logo-rectangle.png?<?= time() ?>" alt="Rectangle Logo" class="img-fluid" style="max-width: 250px;">
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if ($faviconExists): ?>
                            <div class="col-md-3 current-favicon mb-4">
                                <h5 class="mb-4 text-muted fw-light">Current Favicon</h5>
                                <div class="favicon-preview-container p-4 bg-light rounded-3 d-inline-block shadow-sm">
                                    <img src="../../uploads/school/favicon.png?<?= time() ?>" alt="Favicon" style="width: 48px; height: 48px;">
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <form id="logoUploadForm" enctype="multipart/form-data" class="needs-validation" novalidate>
                        <div class="row mb-4">
                            <!-- Square Logo Upload -->
                            <div class="col-md-6 mb-3">
                                <div class="file-upload-card bg-light rounded-3 p-4 text-center border-2 border-dashed border-primary-hover transition-all h-100">
                                    <div class="file-upload-icon mb-3">
                                        <i class="fas fa-cloud-upload-alt fa-3x text-primary opacity-75"></i>
                                    </div>
                                    <h5 class="mb-2 fw-normal">Upload Square Logo</h5>
                                    <p class="text-muted mb-4">Crop to 1:1 · Minimum original: 300×300px · PNG, max 2MB</p>
                                    
                                    <div class="file-upload-wrapper position-relative">
                                        <input type="file" class="form-control visually-hidden" id="schoolLogo" name="schoolLogo" accept=".png">
                                        <label for="schoolLogo" class="btn btn-outline-primary px-4 py-2 rounded-pill shadow-sm">
                                            <i class="fas fa-folder-open me-2"></i> Browse Files
                                        </label>
                                        <div class="file-info mt-3 small text-muted" id="fileInfoSquare">
                                            <div class="file-name d-none">
                                                <i class="fas fa-file-image me-1 text-success"></i>
                                                <span class="name-text"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-text mt-3">
                                        <i class="fas fa-info-circle me-1 text-primary"></i> 
                                        Auto-resized to create a favicon.
                                    </div>
                                </div>
                            </div>

                            <!-- Rectangle Logo Upload -->
                            <div class="col-md-6 mb-3">
                                <div class="file-upload-card bg-light rounded-3 p-4 text-center border-2 border-dashed border-primary-hover transition-all h-100">
                                    <div class="file-upload-icon mb-3">
                                        <i class="fas fa-images fa-3x text-primary opacity-75"></i>
                                    </div>
                                    <h5 class="mb-2 fw-normal">Upload Rectangle Logo</h5>
                                    <p class="text-muted mb-4">Crop to 60:17 · Minimum original: 600×170px · PNG, max 2MB</p>
                                    
                                    <div class="file-upload-wrapper position-relative">
                                        <input type="file" class="form-control visually-hidden" id="logoRectangle" name="logoRectangle" accept=".png">
                                        <label for="logoRectangle" class="btn btn-outline-primary px-4 py-2 rounded-pill shadow-sm">
                                            <i class="fas fa-folder-open me-2"></i> Browse Files
                                        </label>
                                        <div class="file-info mt-3 small text-muted" id="fileInfoRect">
                                            <div class="file-name d-none">
                                                <i class="fas fa-file-image me-1 text-success"></i>
                                                <span class="name-text"></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="d-grid mt-4">
                            <button type="submit" class="btn btn-primary btn-lg px-4 py-3 rounded-pill shadow-sm" id="uploadBtn">
                                <span id="uploadText">
                                    <i class="fas fa-upload me-2"></i> Upload & Process
                                </span>
                                <span id="spinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="logoCropModal" tabindex="-1" aria-labelledby="logoCropTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="logoCropTitle">Crop logo</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cancel"></button>
            </div>
            <div class="modal-body">
                <p class="text-muted">Drag the image or resize the crop area to frame your logo.</p>
                <div style="height: 360px;"><img id="logoCropImage" alt="Logo to crop" style="display: block; max-width: 100%;"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="applyLogoCrop" disabled>Use cropped logo</button>
            </div>
        </div>
    </div>
</div>

<style>
/* CSS remain unchanged from your original source */
.file-upload-card { transition: all 0.3s ease; border-color: rgba(13, 110, 253, 0.2); }
.file-upload-card:hover { border-color: rgba(13, 110, 253, 0.5); transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05); }
.file-upload-icon { transition: all 0.3s ease; }
.file-upload-card:hover .file-upload-icon { transform: scale(1.05); opacity: 1 !important; }
.logo-preview-container, .favicon-preview-container { background-color: #f8f9fa; border: 1px solid rgba(0, 0, 0, 0.05); transition: all 0.3s ease; }
.logo-preview-container:hover, .favicon-preview-container:hover { transform: translateY(-3px); box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05); }
.border-primary-hover { border-color: rgba(13, 110, 253, 0.2); }
.rounded-4 { border-radius: 1rem !important; }
.transition-all { transition: all 0.3s ease; }
</style>

<script src="../../assets/js/school-logo.js?v=<?= filemtime(__DIR__ . '/../../assets/js/school-logo.js') ?>"></script>

<?php include_once("../../includes/body-close.php"); ?>
