<?php
/** @var string $school_name */
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Update School Logo - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if (!isSuperAdmin()) {
   include_once("../../includes/permission-denied.php");
}

// Check if logo exists
$logoExists = file_exists("../../uploads/school/logo-square.png");
$faviconExists = file_exists("../../uploads/school/favicon.png");
$rectLogoExists = file_exists("../../uploads/school/logo-rectangle.png");
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow-lg border-0 rounded-4 overflow-hidden">
                <div class="card-header bg-primary text-white py-4">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-image fa-2x me-3"></i>
                        <h4 class="mb-0">School Brand Assets</h4>
                    </div>
                </div>
                <div class="card-body p-5">
                    <div class="text-center mb-5 row">
                        <?php if ($logoExists): ?>
                            <div class="col-md-4 current-logo mb-4">
                                <h5 class="mb-4 text-muted fw-light">Current Square Logo</h5>
                                <div class="logo-preview-container p-4 bg-light rounded-3 shadow-sm d-inline-block">
                                    <img src="../../uploads/school/logo-square.png?<?= time() ?>" alt="School Logo" class="img-fluid" style="max-width: 150px;">
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($rectLogoExists): ?>
                            <div class="col-md-5 current-logo-rect mb-4">
                                <h5 class="mb-4 text-muted fw-light">Current Rectangle Logo</h5>
                                <div class="logo-preview-container p-4 bg-light rounded-3 shadow-sm d-inline-block">
                                    <img src="../../uploads/school/logo-rectangle.png?<?= time() ?>" alt="Rectangle Logo" class="img-fluid" style="max-width: 250px;">
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if ($faviconExists): ?>
                            <div class="col-md-3 current-favicon mb-4">
                                <h5 class="mb-4 text-muted fw-light">Current Favicon</h5>
                                <div class="favicon-preview-container p-4 bg-light rounded-3 d-inline-block shadow-sm">
                                    <img src="../../uploads/school/favicon.png?<?= time() ?>" alt="Favicon" style="width: 48px; height: 48px;">
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <form id="logoUploadForm" enctype="multipart/form-data" class="needs-validation" novalidate>
                        <div class="row mb-4">
                            <!-- Square Logo Upload -->
                            <div class="col-md-6 mb-3">
                                <div class="file-upload-card bg-light rounded-3 p-4 text-center border-2 border-dashed border-primary-hover transition-all h-100">
                                    <div class="file-upload-icon mb-3">
                                        <i class="fas fa-cloud-upload-alt fa-3x text-primary opacity-75"></i>
                                    </div>
                                    <h5 class="mb-2 fw-normal">Upload Square Logo</h5>
                                    <p class="text-muted mb-4">512×512 PNG, max 2MB</p>
                                    
                                    <div class="file-upload-wrapper position-relative">
                                        <input type="file" class="form-control visually-hidden" id="schoolLogo" name="schoolLogo" accept=".png">
                                        <label for="schoolLogo" class="btn btn-outline-primary px-4 py-2 rounded-pill shadow-sm">
                                            <i class="fas fa-folder-open me-2"></i> Browse Files
                                        </label>
                                        <div class="file-info mt-3 small text-muted" id="fileInfoSquare">
                                            <div class="file-name d-none">
                                                <i class="fas fa-file-image me-1 text-success"></i>
                                                <span class="name-text"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-text mt-3">
                                        <i class="fas fa-info-circle me-1 text-primary"></i> 
                                        Auto-resized to create a favicon.
                                    </div>
                                </div>
                            </div>

                            <!-- Rectangle Logo Upload -->
                            <div class="col-md-6 mb-3">
                                <div class="file-upload-card bg-light rounded-3 p-4 text-center border-2 border-dashed border-primary-hover transition-all h-100">
                                    <div class="file-upload-icon mb-3">
                                        <i class="fas fa-images fa-3x text-primary opacity-75"></i>
                                    </div>
                                    <h5 class="mb-2 fw-normal">Upload Rectangle Logo</h5>
                                    <p class="text-muted mb-4">600×170 PNG, max 2MB</p>
                                    
                                    <div class="file-upload-wrapper position-relative">
                                        <input type="file" class="form-control visually-hidden" id="logoRectangle" name="logoRectangle" accept=".png">
                                        <label for="logoRectangle" class="btn btn-outline-primary px-4 py-2 rounded-pill shadow-sm">
                                            <i class="fas fa-folder-open me-2"></i> Browse Files
                                        </label>
                                        <div class="file-info mt-3 small text-muted" id="fileInfoRect">
                                            <div class="file-name d-none">
                                                <i class="fas fa-file-image me-1 text-success"></i>
                                                <span class="name-text"></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="d-grid mt-4">
                            <button type="submit" class="btn btn-primary btn-lg px-4 py-3 rounded-pill shadow-sm" id="uploadBtn">
                                <span id="uploadText">
                                    <i class="fas fa-upload me-2"></i> Upload & Process
                                </span>
                                <span id="spinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* CSS remain unchanged from your original source */
.file-upload-card { transition: all 0.3s ease; border-color: rgba(13, 110, 253, 0.2); }
.file-upload-card:hover { border-color: rgba(13, 110, 253, 0.5); transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05); }
.file-upload-icon { transition: all 0.3s ease; }
.file-upload-card:hover .file-upload-icon { transform: scale(1.05); opacity: 1 !important; }
.logo-preview-container, .favicon-preview-container { background-color: #f8f9fa; border: 1px solid rgba(0, 0, 0, 0.05); transition: all 0.3s ease; }
.logo-preview-container:hover, .favicon-preview-container:hover { transform: translateY(-3px); box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05); }
.border-primary-hover { border-color: rgba(13, 110, 253, 0.2); }
.rounded-4 { border-radius: 1rem !important; }
.transition-all { transition: all 0.3s ease; }
</style>

<script>
$(document).ready(function() {
    function handleFileInput(inputId, infoId) {
        $(inputId).on('change', function() {
            const file = this.files[0];
            if (file) {
                const fileName = file.name;
                const fileSize = (file.size / (1024 * 1024)).toFixed(2) + 'MB';
                
                $(infoId + ' .name-text').text(fileName + ' (' + fileSize + ')');
                $(infoId + ' .file-name').removeClass('d-none');
                
                if (file.type !== 'image/png' || file.size > 2 * 1024 * 1024) {
                    $(inputId).addClass('is-invalid');
                    $(infoId + ' .file-name i').removeClass('text-success').addClass('text-danger');
                } else {
                    $(inputId).removeClass('is-invalid');
                    $(infoId + ' .file-name i').removeClass('text-danger').addClass('text-success');
                }
            }
        });
    }

    handleFileInput('#schoolLogo', '#fileInfoSquare');
    handleFileInput('#logoRectangle', '#fileInfoRect');

    // AJAX form submission
    $('#logoUploadForm').submit(function(e) {
        e.preventDefault();
        
        const squareFile = $('#schoolLogo')[0].files[0];
        const rectFile = $('#logoRectangle')[0].files[0];
        
        if (!squareFile && !rectFile) {
            toastr.error('Please select at least one file to upload');
            return false;
        }
        
        const formData = new FormData();
        
        if (squareFile) {
            if (squareFile.type !== 'image/png' || squareFile.size > 2 * 1024 * 1024) {
                toastr.error('Square logo must be PNG and less than 2MB');
                return false;
            }
            formData.append('schoolLogo', squareFile);
        }

        if (rectFile) {
            if (rectFile.type !== 'image/png' || rectFile.size > 2 * 1024 * 1024) {
                toastr.error('Rectangle logo must be PNG and less than 2MB');
                return false;
            }
            formData.append('logoRectangle', rectFile);
        }
        
        // Show loading state
        $('#uploadBtn').prop('disabled', true);
        $('#uploadText').html('<i class="fas fa-circle-notch fa-spin me-2"></i> Processing...');
        $('#spinner').removeClass('d-none');
        
        // AJAX request
        $.ajax({
            url: '../../api/admin/put/school/upload-school-logo.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                    setTimeout(() => {
                        window.location.reload(); // Reload to see fresh images and layout
                    }, 1000);
                } else {
                    toastr.error(response.message);
                }
            },
            error: function(xhr, status, error) {
                toastr.error('An error occurred: ' + error);
            },
            complete: function() {
                $('#uploadBtn').prop('disabled', false);
                $('#uploadText').html('<i class="fas fa-upload me-2"></i> Upload & Process');
                $('#spinner').addClass('d-none');
            }
        });
    });
});
</script>

<?php include_once("../../includes/body-close.php"); ?>