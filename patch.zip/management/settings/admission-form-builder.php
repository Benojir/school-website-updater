<?php
define('ID_CARD_AUDIENCE', 'admission');
require __DIR__ . '/student-id-card-builder.php';
