<?php

/** @var string $school_name */
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage School Information - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if (!isSuperAdmin()) {
    include_once("../../includes/permission-denied.php");
}

// Get existing school information
$schoolInfo = [];
$stmt = $pdo->query("SELECT * FROM school_information LIMIT 1");
if ($stmt) {
    $schoolInfo = $stmt->fetch();
}

// Check if principal signature exists
$signatureExists = file_exists("../../uploads/school/principle_sign.png");
$headmasterSignatureExists = file_exists("../../uploads/school/headmaster_sign.png");
$stampExists = file_exists("../../uploads/school/school_stamp.png");
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div>
            <div class="card shadow-lg border-0">
                <div class="card-header bg-primary text-white py-3">
                    <h4 class="mb-0"><i class="fas fa-school me-2"></i> School Information</h4>
                </div>
                <div class="card-body p-4">
                    <form id="schoolInfoForm" class="needs-validation" novalidate enctype="multipart/form-data">
                        <div class="row g-3">
                            <!-- General Information -->
                            <div class="col-md-12 mt-4">
                                <h5 class="border-bottom pb-2 mb-3 text-primary">General Information</h5>
                            </div>

                            <!-- School Name -->
                            <div class="col-md-4">
                                <label for="name" class="form-label">School Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="name" name="name"
                                    value="<?= safe_htmlspecialchars($schoolInfo['name'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter school name</div>
                            </div>

                            <div class="col-md-4">
                                <label for="foundation_name" class="form-label">Foundation Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="foundation_name" name="foundation_name"
                                    value="<?= safe_htmlspecialchars($schoolInfo['foundation_name'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter foundation name</div>
                            </div>

                            <!-- Contact Info -->
                            <div class="col-md-4">
                                <label for="phone" class="form-label">Phone Number <span class="text-danger">*</span></label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    value="<?= safe_htmlspecialchars($schoolInfo['phone'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter phone number</div>
                            </div>

                            <!-- Contact Info -->
                            <div class="col-md-4">
                                <label for="alternate_phone" class="form-label">Alt. Number <span class="text-danger">*</span></label>
                                <input type="tel" class="form-control" id="alternate_phone" name="alternate_phone"
                                    value="<?= safe_htmlspecialchars($schoolInfo['alternate_phone'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter alternate phone number</div>
                            </div>

                            <div class="col-md-4">
                                <label for="village" class="form-label">Village/Town <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="village" name="village"
                                    value="<?= safe_htmlspecialchars($schoolInfo['village'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter village</div>
                            </div>

                            <div class="col-md-4">
                                <label for="post_office" class="form-label">Post Office <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="post_office" name="post_office"
                                    value="<?= safe_htmlspecialchars($schoolInfo['post_office'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter post office</div>
                            </div>

                            <div class="col-md-4">
                                <label for="police_station" class="form-label">Police Station <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="police_station" name="police_station"
                                    value="<?= safe_htmlspecialchars($schoolInfo['police_station'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter police station</div>
                            </div>

                            <div class="col-md-4">
                                <label for="district" class="form-label">District <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="district" name="district"
                                    value="<?= safe_htmlspecialchars($schoolInfo['district'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter district</div>
                            </div>

                            <div class="col-md-4">
                                <label for="pincode" class="form-label">Pincode <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="pincode" name="pincode"
                                    value="<?= safe_htmlspecialchars($schoolInfo['pincode'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter pincode</div>
                            </div>

                            <div class="col-md-4">
                                <label for="campus_name" class="form-label">Campus Name</label>
                                <input type="text" class="form-control" id="campus_name" name="campus_name"
                                    value="<?= safe_htmlspecialchars($schoolInfo['campus_name'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter campus name</div>
                            </div>

                            <div class="col-md-4">
                                <label for="trust_registration_number" class="form-label">Trust Registration Number</label>
                                <input type="text" class="form-control" id="trust_registration_number" name="trust_registration_number"
                                    value="<?= safe_htmlspecialchars($schoolInfo['trust_registration_number'] ?? '') ?>">
                                <div class="invalid-feedback">Please enter trust registration number</div>
                            </div>

                            <div class="col-md-4">
                                <label for="school_registration_number" class="form-label">School Registration Number</label>
                                <input type="text" class="form-control" id="school_registration_number" name="school_registration_number"
                                    value="<?= safe_htmlspecialchars($schoolInfo['school_registration_number'] ?? '') ?>">
                                <div class="invalid-feedback">Please enter school registration number</div>
                            </div>

                            <div class="col-md-6">
                                <label for="email" class="form-label">School Email Address <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" id="email" name="email"
                                    value="<?= safe_htmlspecialchars($schoolInfo['email'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter valid email</div>
                            </div>

                            <!-- Established Year and Website Address -->
                            <div class="col-md-6">
                                <label for="established_year" class="form-label">Established Year <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="established_year" name="established_year"
                                    min="1800" max="<?= date('Y') ?>"
                                    value="<?= safe_htmlspecialchars($schoolInfo['established_year'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter valid year</div>
                            </div>

                            <div class="col-md-6">
                                <label for="school_website_address" class="form-label">School Website <span class="text-danger">*</span></label>
                                <input type="url" class="form-control" id="school_website_address" name="school_website_address"
                                    value="<?= safe_htmlspecialchars($schoolInfo['school_website_address'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter website url</div>
                            </div>

                            <!-- Map & Play Store App Link -->
                            <div class="col-md-6">
                                <label for="google_map_link" class="form-label">Google Map Link <span class="text-danger">*</span></label>
                                <input type="url" class="form-control" id="google_map_link" name="google_map_link"
                                    value="<?= safe_htmlspecialchars($schoolInfo['google_map_link'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter map link</div>
                            </div>

                            <div class="col-md-6">
                                <label for="google_map_embed_link" class="form-label">Map Embed Link <span class="text-danger">*</span></label>
                                <input type="url" class="form-control" id="google_map_embed_link" name="google_map_embed_link"
                                    value="<?= safe_htmlspecialchars($schoolInfo['google_map_embed_link'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter the map embed link</div>
                            </div>

                            <div class="col-md-6">
                                <label for="feedback_tg_chat_id" class="form-label">Feedback Telegram Chat ID</label>
                                <input type="url" class="form-control" id="feedback_tg_chat_id" name="feedback_tg_chat_id"
                                    value="<?= safe_htmlspecialchars($schoolInfo['feedback_tg_chat_id'] ?? '') ?>">
                                <div class="invalid-feedback">Please enter the feedback telegram chat id</div>
                            </div>

                            <!-- School Description -->
                            <div class="col-md-12">
                                <label for="description" class="form-label">School Description <span class="text-danger">*</span></label>
                                <textarea class="form-control" id="description" name="description" rows="3" required><?= safe_htmlspecialchars($schoolInfo['description'] ?? '') ?></textarea>
                                <div class="invalid-feedback">Please enter school description</div>
                            </div>

                            <!-- General Information -->
                            <div class="col-md-12 mt-4">
                                <h5 class="border-bottom pb-2 mb-3 text-primary">SEO Information</h5>
                            </div>

                            <div class="col-md-12">
                                <label for="meta_description" class="form-label">Meta Description <span class="text-danger">*</span></label>
                                <textarea class="form-control" maxlength="200" id="meta_description" name="meta_description" rows="2" required><?= safe_htmlspecialchars($schoolInfo['meta_description'] ?? '') ?></textarea>
                                <div class="invalid-feedback">Please enter meta description</div>
                            </div>

                            <div class="col-md-12">
                                <label for="meta_keywords" class="form-label">Meta Keywords <span class="text-danger">*</span></label>
                                <textarea class="form-control" id="meta_keywords" name="meta_keywords" rows="2" required><?= safe_htmlspecialchars($schoolInfo['meta_keywords'] ?? '') ?></textarea>
                                <div class="invalid-feedback">Please enter meta keywords</div>
                            </div>

                            <!-- Social Media Links -->
                            <div class="col-md-12 mt-4">
                                <h5 class="border-bottom pb-2 mb-3 text-primary">Social Media Links</h5>
                            </div>

                            <div class="col-md-6">
                                <label for="facebook" class="form-label">Facebook URL <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fab fa-facebook-f"></i></span>
                                    <input type="url" class="form-control" id="facebook" name="facebook"
                                        value="<?= safe_htmlspecialchars($schoolInfo['facebook'] ?? '') ?>" required>
                                </div>
                                <div class="invalid-feedback">Please enter Facebook URL</div>
                            </div>

                            <div class="col-md-6">
                                <label for="youtube" class="form-label">YouTube URL <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fab fa-youtube"></i></span>
                                    <input type="url" class="form-control" id="youtube" name="youtube"
                                        value="<?= safe_htmlspecialchars($schoolInfo['youtube'] ?? '') ?>" required>
                                </div>
                                <div class="invalid-feedback">Please enter YouTube URL</div>
                            </div>

                            <div class="col-md-6">
                                <label for="instagram" class="form-label">Instagram URL <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fab fa-instagram"></i></span>
                                    <input type="url" class="form-control" id="instagram" name="instagram"
                                        value="<?= safe_htmlspecialchars($schoolInfo['instagram'] ?? '') ?>" required>
                                </div>
                                <div class="invalid-feedback">Please enter Instagram URL</div>
                            </div>

                            <div class="col-md-6">
                                <label for="whatsapp" class="form-label">WhatsApp Channel <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fab fa-whatsapp"></i></span>
                                    <input type="url" class="form-control" id="whatsapp" name="whatsapp"
                                        value="<?= safe_htmlspecialchars($schoolInfo['whatsapp'] ?? '') ?>" required>
                                </div>
                                <div class="invalid-feedback">Please enter WhatsApp URL</div>
                            </div>
                        </div>

                        <!-- Principal Signature Upload -->
                        <div class="col-md-12 row mt-5">
                            <h5 class="border-bottom pb-2 mb-3 text-primary">Principal</h5>
                            <div class="mb-3 col-md-6">
                                <label for="principal_name" class="form-label">Principal Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="principal_name" name="principal_name"
                                    value="<?= safe_htmlspecialchars($schoolInfo['principal_name'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter principal name</div>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="principal_phone" class="form-label">Principal Phone <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="principal_phone" name="principal_phone"
                                    value="<?= safe_htmlspecialchars($schoolInfo['principal_phone'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter principal phone</div>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="principal_email" class="form-label">Principal Email <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" id="principal_email" name="principal_email"
                                    value="<?= safe_htmlspecialchars($schoolInfo['principal_email'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter principal email</div>
                            </div>
                            <div class="mb-3">
                                <label for="principal_signature" class="form-label">Principal Signature (PNG only, 2:1 ratio, max 2MB) <span class="text-danger">*</span></label>
                                <input type="file" class="form-control" id="principal_signature" name="principal_signature" accept=".png" required>
                                <div class="invalid-feedback">Please upload a valid PNG signature (2:1 ratio, max 2MB)</div>
                            </div>
                            <?php if ($signatureExists): ?>
                                <div class="current-signature mb-3">
                                    <p class="mb-1">Current Signature:</p>
                                    <img src="../../uploads/school/principle_sign.png?<?= time() ?>" alt="Principal Signature" style="max-height: 100px; background: #f8f9fa; padding: 10px; border: 1px solid #dee2e6;" class="img-thumbnail">
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Head Master Details Upload -->
                        <div class="col-md-12 row mt-5">
                            <h5 class="border-bottom pb-2 mb-3 text-primary">Head Master</h5>
                            <div class="mb-3 col-md-6">
                                <label for="headmaster_name" class="form-label">Head Master Name</label>
                                <input type="text" class="form-control" id="headmaster_name" name="headmaster_name"
                                    value="<?= safe_htmlspecialchars($schoolInfo['headmaster_name'] ?? '') ?>">
                                <div class="invalid-feedback">Please enter head master name</div>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="headmaster_phone" class="form-label">Head Master Phone</label>
                                <input type="tel" class="form-control" id="headmaster_phone" name="headmaster_phone"
                                    value="<?= safe_htmlspecialchars($schoolInfo['headmaster_phone'] ?? '') ?>">
                                <div class="invalid-feedback">Please enter head master phone</div>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="headmaster_email" class="form-label">Head Master Email</label>
                                <input type="email" class="form-control" id="headmaster_email" name="headmaster_email"
                                    value="<?= safe_htmlspecialchars($schoolInfo['headmaster_email'] ?? '') ?>">
                                <div class="invalid-feedback">Please enter valid email</div>
                            </div>
                            <div class="mb-3">
                                <label for="headmaster_signature" class="form-label">Head Master Signature (PNG only, 2:1 ratio, max 2MB)</label>
                                <input type="file" class="form-control" id="headmaster_signature" name="headmaster_signature" accept=".png">
                                <div class="invalid-feedback">Please upload a valid PNG signature (2:1 ratio, max 2MB)</div>
                            </div>
                            <?php if ($headmasterSignatureExists): ?>
                                <div class="current-headmaster-signature mb-3">
                                    <p class="mb-1">Current Signature:</p>
                                    <img src="../../uploads/school/headmaster_sign.png?<?= time() ?>" alt="Head Master Signature" style="max-height: 100px; background: #f8f9fa; padding: 10px; border: 1px solid #dee2e6;" class="img-thumbnail">
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- School Stamp Upload -->
                        <div class="col-md-12 row mt-5">
                            <h5 class="border-bottom pb-2 mb-3 text-primary">School Stamp</h5>
                            <div class="mb-3">
                                <label for="school_stamp" class="form-label">School Stamp (PNG only, 1:1 ratio, max 2MB)</label>
                                <input type="file" class="form-control" id="school_stamp" name="school_stamp" accept=".png">
                                <div class="invalid-feedback">Please upload a valid PNG stamp (1:1 ratio, max 2MB)</div>
                            </div>
                            <?php if ($stampExists): ?>
                                <div class="current-stamp mb-3">
                                    <p class="mb-1">Current Stamp:</p>
                                    <img src="../../uploads/school/school_stamp.png?<?= time() ?>" alt="School Stamp" style="max-height: 120px; max-width: 120px; object-fit: contain; background: #f8f9fa; padding: 10px; border: 1px solid #dee2e6;" class="img-thumbnail">
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                            <button type="submit" class="btn btn-primary px-4 py-2" id="submitBtn">
                                <span id="submitText"><i class="fa-solid fa-floppy-disk"></i> Save Information</span>
                                <span id="spinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

        // Form validation
        (function() {
            'use strict';
            var form = document.getElementById('schoolInfoForm');
            form.addEventListener('submit', function(event) {
                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
            }, false);
        })();

        // Initialize Cropper.js for signature / stamp upload
        function initSignatureCropper(inputId, defaultFileName, aspectRatio = 2) {
            const signatureInput = document.getElementById(inputId);
            if (!signatureInput) return;

            let cropper = null;
            const imageBox = document.createElement('div');
            imageBox.className = 'img-container d-none';
            imageBox.innerHTML = `
                <div class="text-center mb-3">
                    <img src="#" alt="Preview" class="img-fluid signature-preview-img" style="max-height: 300px;">
                </div>
                <div class="text-center">
                    <button type="button" class="btn btn-primary me-2 crop-btn">Crop & Save</button>
                    <button type="button" class="btn btn-secondary cancel-crop-btn">Cancel</button>
                </div>
            `;
            signatureInput.parentNode.insertBefore(imageBox, signatureInput.nextSibling);

            const previewImg = imageBox.querySelector('.signature-preview-img');
            const cropBtn = imageBox.querySelector('.crop-btn');
            const cancelBtn = imageBox.querySelector('.cancel-crop-btn');

            signatureInput.addEventListener('change', function(e) {
                if (this.files && this.files[0]) {
                    const file = this.files[0];

                    // Check file type
                    if (!file.type.match('image.*')) {
                        toastr.error('Please select an image file');
                        return;
                    }

                    // Check file size (2MB max)
                    if (file.size > 2 * 1024 * 1024) {
                        toastr.error('File must be less than 2MB');
                        return;
                    }

                    const reader = new FileReader();
                    reader.onload = function(event) {
                        previewImg.src = event.target.result;

                        // Show the cropper interface
                        imageBox.classList.remove('d-none');
                        signatureInput.classList.add('d-none');

                        // Initialize cropper with ratio
                        if (cropper) {
                            cropper.destroy();
                        }

                        cropper = new Cropper(previewImg, {
                            aspectRatio: aspectRatio,
                            viewMode: 1,
                            autoCropArea: 1,
                            responsive: true,
                            guides: false,
                            center: false,
                            highlight: false,
                            cropBoxMovable: true,
                            cropBoxResizable: true,
                            toggleDragModeOnDblclick: false
                        });
                    };
                    reader.readAsDataURL(file);
                }
            });

            // Handle crop button
            cropBtn.addEventListener('click', function() {
                if (cropper) {
                    // Get the cropped canvas
                    const canvasOptions = aspectRatio === 1 ? {
                        width: 400,
                        height: 400,
                        minWidth: 200,
                        minHeight: 200,
                        maxWidth: 800,
                        maxHeight: 800,
                        fillColor: 'transparent',
                        imageSmoothingEnabled: true,
                        imageSmoothingQuality: 'high'
                    } : {
                        width: 600,
                        height: 300,
                        minWidth: 400,
                        minHeight: 200,
                        maxWidth: 800,
                        maxHeight: 400,
                        fillColor: 'transparent',
                        imageSmoothingEnabled: true,
                        imageSmoothingQuality: 'high'
                    };
                    const canvas = cropper.getCroppedCanvas(canvasOptions);

                    if (canvas) {
                        // Convert canvas to blob
                        canvas.toBlob(function(blob) {
                            // Create a new File object from the blob
                            const file = new File([blob], defaultFileName, {
                                type: 'image/png',
                                lastModified: Date.now()
                            });

                            // Create a new DataTransfer object and add the file
                            const dataTransfer = new DataTransfer();
                            dataTransfer.items.add(file);

                            // Update the file input with the cropped image
                            signatureInput.files = dataTransfer.files;

                            // Hide the cropper interface
                            imageBox.classList.add('d-none');
                            signatureInput.classList.remove('d-none');

                            // Destroy cropper
                            cropper.destroy();
                            cropper = null;

                            toastr.success('Image cropped successfully');
                        }, 'image/png', 0.9);
                    }
                }
            });

            // Handle cancel crop
            cancelBtn.addEventListener('click', function() {
                imageBox.classList.add('d-none');
                signatureInput.classList.remove('d-none');
                signatureInput.value = '';

                if (cropper) {
                    cropper.destroy();
                    cropper = null;
                }
            });
        }

        initSignatureCropper('principal_signature', 'signature.png', 2);
        initSignatureCropper('headmaster_signature', 'headmaster_signature.png', 2);
        initSignatureCropper('school_stamp', 'school_stamp.png', 1);

        // AJAX form submission with file upload
        $('#schoolInfoForm').submit(function(e) {
            e.preventDefault();

            // Show loading state
            $('#submitBtn').prop('disabled', true);
            $('#submitText').text('Saving...');
            $('#spinner').removeClass('d-none');

            // Create FormData object for file upload
            var formData = new FormData(this);

            $.ajax({
                url: '../../api/admin/put/school/save-school-info.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        // Refresh signature preview
                        if (response.signature_updated) {
                            if ($('.current-signature img').length) {
                                $('.current-signature img').attr('src', '../../uploads/school/principle_sign.png?' + new Date().getTime());
                            } else {
                                $('#principal_signature').closest('.mb-3').after(`
                                    <div class="current-signature mb-3">
                                        <p class="mb-1">Current Signature:</p>
                                        <img src="../../uploads/school/principle_sign.png?${new Date().getTime()}" alt="Principal Signature" style="max-height: 100px; background: #f8f9fa; padding: 10px; border: 1px solid #dee2e6;" class="img-thumbnail">
                                    </div>
                                `);
                            }
                        }
                        if (response.headmaster_signature_updated) {
                            if ($('.current-headmaster-signature img').length) {
                                $('.current-headmaster-signature img').attr('src', '../../uploads/school/headmaster_sign.png?' + new Date().getTime());
                            } else {
                                $('#headmaster_signature').closest('.mb-3').after(`
                                    <div class="current-headmaster-signature mb-3">
                                        <p class="mb-1">Current Signature:</p>
                                        <img src="../../uploads/school/headmaster_sign.png?${new Date().getTime()}" alt="Head Master Signature" style="max-height: 100px; background: #f8f9fa; padding: 10px; border: 1px solid #dee2e6;" class="img-thumbnail">
                                    </div>
                                `);
                            }
                        }
                        if (response.stamp_updated) {
                            if ($('.current-stamp img').length) {
                                $('.current-stamp img').attr('src', '../../uploads/school/school_stamp.png?' + new Date().getTime());
                            } else {
                                $('#school_stamp').closest('.mb-3').after(`
                                    <div class="current-stamp mb-3">
                                        <p class="mb-1">Current Stamp:</p>
                                        <img src="../../uploads/school/school_stamp.png?${new Date().getTime()}" alt="School Stamp" style="max-height: 120px; max-width: 120px; object-fit: contain; background: #f8f9fa; padding: 10px; border: 1px solid #dee2e6;" class="img-thumbnail">
                                    </div>
                                `);
                            }
                        }
                        // Reset form validation
                        $('#schoolInfoForm').removeClass('was-validated');
                        // Show sweetalert success
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message,
                            customClass: {
                                confirmButton: 'btn btn-primary px-4 py-2',
                                popup: 'rounded-4 shadow-lg'
                            },
                            buttonsStyling: false
                        });
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred: ' + error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'An unexpected error occurred. Please try again later.',
                        customClass: {
                            confirmButton: 'btn btn-danger px-4 py-2',
                            popup: 'rounded-4 shadow-lg'
                        },
                        buttonsStyling: false
                    });
                },
                complete: function() {
                    // Reset button state
                    $('#submitBtn').prop('disabled', false);
                    $('#submitText').html('<i class="fa-solid fa-floppy-disk"></i> Save Information');
                    $('#spinner').addClass('d-none');
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>