<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage School Information - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if ($_SESSION['user']['role'] !== 'superadmin') {
    include_once("../../includes/permission-denied.php");
}

// Get existing school information
$schoolInfo = [];
$stmt = $pdo->query("SELECT * FROM school_information LIMIT 1");
if ($stmt) {
    $schoolInfo = $stmt->fetch();
}

// Check if principal signature exists
$signatureExists = file_exists("../../uploads/school/principle_sign.png");
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div>
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white py-3">
                    <h4 class="mb-0"><i class="fas fa-school me-2"></i> School Information</h4>
                </div>
                <div class="card-body p-4">
                    <form id="schoolInfoForm" class="needs-validation" novalidate enctype="multipart/form-data">
                        <div class="row g-3">
                            <!-- School Name -->
                            <div class="col-md-12">
                                <label for="name" class="form-label">School Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="name" name="name"
                                    value="<?= safe_htmlspecialchars($schoolInfo['name'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter school name</div>
                            </div>

                            <!-- School Address -->
                            <div class="col-md-12">
                                <label for="address" class="form-label">School Address <span class="text-danger">*</span></label>
                                <textarea class="form-control" id="address" name="address" rows="2" required><?= safe_htmlspecialchars($schoolInfo['address'] ?? '') ?></textarea>
                                <div class="invalid-feedback">Please enter school address</div>
                            </div>

                            <!-- Contact Info -->
                            <div class="col-md-6">
                                <label for="phone" class="form-label">Phone Number <span class="text-danger">*</span></label>
                                <input type="tel" class="form-control" id="phone" name="phone"
                                    value="<?= safe_htmlspecialchars($schoolInfo['phone'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter phone number</div>
                            </div>

                            <div class="col-md-6">
                                <label for="email" class="form-label">School Email Address <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" id="email" name="email"
                                    value="<?= safe_htmlspecialchars($schoolInfo['email'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter valid email</div>
                            </div>

                            <!-- Established Year and Website Address -->
                            <div class="col-md-6">
                                <label for="established_year" class="form-label">Established Year <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="established_year" name="established_year"
                                    min="1800" max="<?= date('Y') ?>"
                                    value="<?= safe_htmlspecialchars($schoolInfo['established_year'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter valid year</div>
                            </div>

                            <div class="col-md-6">
                                <label for="school_website_address" class="form-label">School Website <span class="text-danger">*</span></label>
                                <input type="url" class="form-control" id="school_website_address" name="school_website_address"
                                    value="<?= safe_htmlspecialchars($schoolInfo['school_website_address'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter website url</div>
                            </div>

                            <!-- Map & Play Store App Link -->
                            <div class="col-md-6">
                                <label for="google_map_link" class="form-label">Google Map Link <span class="text-danger">*</span></label>
                                <input type="url" class="form-control" id="google_map_link" name="google_map_link"
                                    value="<?= safe_htmlspecialchars($schoolInfo['google_map_link'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter map link</div>
                            </div>

                            <div class="col-md-6">
                                <label for="app_download_link" class="form-label">App Download Link <span class="text-danger">*</span></label>
                                <input type="url" class="form-control" id="app_download_link" name="app_download_link"
                                    value="<?= safe_htmlspecialchars($schoolInfo['app_download_link'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter app download link</div>
                            </div>

                            <!-- School Description -->
                            <div class="col-md-12">
                                <label for="description" class="form-label">School Description <span class="text-danger">*</span></label>
                                <textarea class="form-control" id="description" name="description" rows="3" required><?= safe_htmlspecialchars($schoolInfo['description'] ?? '') ?></textarea>
                                <div class="invalid-feedback">Please enter school description</div>
                            </div>

                            <!-- Social Media Links -->
                            <div class="col-md-12 mt-4">
                                <h5 class="border-bottom pb-2 mb-3 text-primary">Social Media Links</h5>
                            </div>

                            <div class="col-md-6">
                                <label for="facebook" class="form-label">Facebook URL <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fab fa-facebook-f"></i></span>
                                    <input type="url" class="form-control" id="facebook" name="facebook"
                                        value="<?= safe_htmlspecialchars($schoolInfo['facebook'] ?? '') ?>" required>
                                </div>
                                <div class="invalid-feedback">Please enter Facebook URL</div>
                            </div>

                            <div class="col-md-6">
                                <label for="youtube" class="form-label">YouTube URL <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fab fa-youtube"></i></span>
                                    <input type="url" class="form-control" id="youtube" name="youtube"
                                        value="<?= safe_htmlspecialchars($schoolInfo['youtube'] ?? '') ?>" required>
                                </div>
                                <div class="invalid-feedback">Please enter YouTube URL</div>
                            </div>

                            <div class="col-md-6">
                                <label for="instagram" class="form-label">Instagram URL <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fab fa-instagram"></i></span>
                                    <input type="url" class="form-control" id="instagram" name="instagram"
                                        value="<?= safe_htmlspecialchars($schoolInfo['instagram'] ?? '') ?>" required>
                                </div>
                                <div class="invalid-feedback">Please enter Instagram URL</div>
                            </div>

                            <div class="col-md-6">
                                <label for="whatsapp" class="form-label">WhatsApp Channel <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fab fa-whatsapp"></i></span>
                                    <input type="url" class="form-control" id="whatsapp" name="whatsapp"
                                        value="<?= safe_htmlspecialchars($schoolInfo['whatsapp'] ?? '') ?>" required>
                                </div>
                                <div class="invalid-feedback">Please enter WhatsApp URL</div>
                            </div>
                        </div>

                        <!-- Principal Signature Upload -->
                        <div class="col-md-12 row mt-5">
                            <h5 class="border-bottom pb-2 mb-3 text-primary">Principal</h5>
                            <div class="mb-3 col-md-6">
                                <label for="principal_name" class="form-label">Principal Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="principal_name" name="principal_name"
                                    value="<?= safe_htmlspecialchars($schoolInfo['principal_name'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter principal name</div>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="principal_phone" class="form-label">Principal Phone <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="principal_phone" name="principal_phone"
                                    value="<?= safe_htmlspecialchars($schoolInfo['principal_phone'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter principal phone</div>
                            </div>
                            <div class="mb-3 col-md-6">
                                <label for="principal_email" class="form-label">Principal Email <span class="text-danger">*</span></label>
                                <input type="email" class="form-control" id="principal_email" name="principal_email"
                                    value="<?= safe_htmlspecialchars($schoolInfo['principal_email'] ?? '') ?>" required>
                                <div class="invalid-feedback">Please enter principal email</div>
                            </div>
                            <div class="mb-3">
                                <label for="principal_signature" class="form-label">Principal Signature (PNG only, 2:1 ratio, max 2MB) <span class="text-danger">*</span></label>
                                <input type="file" class="form-control" id="principal_signature" name="principal_signature" accept=".png" required>
                                <div class="invalid-feedback">Please upload a valid PNG signature (2:1 ratio, max 2MB)</div>
                            </div>
                            <?php if ($signatureExists): ?>
                                <div class="current-signature mb-3">
                                    <p class="mb-1">Current Signature:</p>
                                    <img src="../../uploads/school/principle_sign.png?<?= time() ?>" alt="Principal Signature" style="max-height: 100px; background: #f8f9fa; padding: 10px; border: 1px solid #dee2e6;" class="img-thumbnail">
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                            <button type="submit" class="btn btn-primary px-4 py-2" id="submitBtn">
                                <span id="submitText"><i class="fa-solid fa-floppy-disk"></i> Save Information</span>
                                <span id="spinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        
        // Form validation
        (function() {
            'use strict';
            var form = document.getElementById('schoolInfoForm');
            form.addEventListener('submit', function(event) {
                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
            }, false);
        })();

        // Initialize Cropper.js for signature upload
        let cropper;
        const signatureInput = document.getElementById('principal_signature');
        const imageBox = document.createElement('div');
        imageBox.className = 'img-container d-none';
        imageBox.innerHTML = `
            <div class="text-center mb-3">
                <img id="signature-preview" src="#" alt="Signature Preview" class="img-fluid" style="max-height: 300px;">
            </div>
            <div class="text-center">
                <button type="button" id="crop-btn" class="btn btn-primary me-2">Crop & Save</button>
                <button type="button" id="cancel-crop" class="btn btn-secondary">Cancel</button>
            </div>
        `;
        signatureInput.parentNode.insertBefore(imageBox, signatureInput.nextSibling);

        signatureInput.addEventListener('change', function(e) {
            if (this.files && this.files[0]) {
                const file = this.files[0];
                
                // Check file type
                if (!file.type.match('image.*')) {
                    toastr.error('Please select an image file');
                    return;
                }
                
                // Check file size (2MB max)
                if (file.size > 2 * 1024 * 1024) {
                    toastr.error('File must be less than 2MB');
                    return;
                }
                
                const reader = new FileReader();
                reader.onload = function(event) {
                    const img = document.getElementById('signature-preview');
                    img.src = event.target.result;
                    
                    // Show the cropper interface
                    imageBox.classList.remove('d-none');
                    signatureInput.classList.add('d-none');
                    
                    // Initialize cropper with 2:1 ratio
                    if (cropper) {
                        cropper.destroy();
                    }
                    
                    cropper = new Cropper(img, {
                        aspectRatio: 2,
                        viewMode: 1,
                        autoCropArea: 1,
                        responsive: true,
                        guides: false,
                        center: false,
                        highlight: false,
                        cropBoxMovable: true,
                        cropBoxResizable: true,
                        toggleDragModeOnDblclick: false
                    });
                };
                reader.readAsDataURL(file);
            }
        });

        // Handle crop button
        document.getElementById('crop-btn').addEventListener('click', function() {
            if (cropper) {
                // Get the cropped canvas
                const canvas = cropper.getCroppedCanvas({
                    width: 600,
                    height: 300,
                    minWidth: 400,
                    minHeight: 200,
                    maxWidth: 800,
                    maxHeight: 400,
                    fillColor: '#fff',
                    imageSmoothingEnabled: true,
                    imageSmoothingQuality: 'high'
                });
                
                if (canvas) {
                    // Convert canvas to blob
                    canvas.toBlob(function(blob) {
                        // Create a new File object from the blob
                        const file = new File([blob], 'signature.png', {
                            type: 'image/png',
                            lastModified: Date.now()
                        });
                        
                        // Create a new DataTransfer object and add the file
                        const dataTransfer = new DataTransfer();
                        dataTransfer.items.add(file);
                        
                        // Update the file input with the cropped image
                        signatureInput.files = dataTransfer.files;
                        
                        // Hide the cropper interface
                        imageBox.classList.add('d-none');
                        signatureInput.classList.remove('d-none');
                        
                        // Destroy cropper
                        cropper.destroy();
                        cropper = null;
                        
                        toastr.success('Signature cropped successfully');
                    }, 'image/png', 0.9);
                }
            }
        });

        // Handle cancel crop
        document.getElementById('cancel-crop').addEventListener('click', function() {
            imageBox.classList.add('d-none');
            signatureInput.classList.remove('d-none');
            signatureInput.value = '';
            
            if (cropper) {
                cropper.destroy();
                cropper = null;
            }
        });

        // AJAX form submission with file upload
        $('#schoolInfoForm').submit(function(e) {
            e.preventDefault();

            // Show loading state
            $('#submitBtn').prop('disabled', true);
            $('#submitText').text('Saving...');
            $('#spinner').removeClass('d-none');

            // Create FormData object for file upload
            var formData = new FormData(this);

            $.ajax({
                url: '../../api/admin/put/school/save-school-info.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        // Refresh signature preview
                        if (response.signature_updated) {
                            $('.current-signature img').attr('src', '../../uploads/school/principle_sign.png?' + new Date().getTime());
                        }
                        // Reset form validation
                        $('#schoolInfoForm').removeClass('was-validated');
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred: ' + error);
                },
                complete: function() {
                    // Reset button state
                    $('#submitBtn').prop('disabled', false);
                    $('#submitText').html('<i class="fa-solid fa-floppy-disk"></i> Save Information');
                    $('#spinner').addClass('d-none');
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>