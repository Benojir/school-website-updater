<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
/** @var string $school_name */
echo "<title>Admit Card Settings - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

if (!hasPermission(PERM_MANAGE_EXAMS)) {
    include_once("../../includes/permission-denied.php");
}

$stmt = $pdo->query("SELECT * FROM settings_admit_card LIMIT 1");
$admit_settings = $stmt->fetch();

// Decode JSON colors
$saved_colors = json_decode($admit_settings['colors'] ?? '{}', true);

// Settings default colors (ফেলব্যাক হিসেবে)
$default_colors = [
    'primary' => '#3a4a6d',
    'dark' => '#2b3a5a',
    'light' => '#F0F5FF',
    'background' => '#FFFFFF',
    'school_name' => '#EFF0F2',
    'school_address' => '#333333'
];

$theme_color_primary = $saved_colors['primary'] ?? $default_colors['primary'];
$theme_color_dark = $saved_colors['dark'] ?? $default_colors['dark'];
$theme_color_light = $saved_colors['light'] ?? $default_colors['light'];
$background_color = $saved_colors['background'] ?? $default_colors['background'];
$school_name_color = $saved_colors['school_name'] ?? $default_colors['school_name'];
$school_address_color = $saved_colors['school_address'] ?? $default_colors['school_address'];

// New Fields Variables
$school_address = $admit_settings['school_address'] ?? '';
$school_contact = $admit_settings['school_contact'] ?? '';
$admit_instructions = $admit_settings['instructions'] ?? '';

$admit_designs = ['design-1', 'design-2'];
$current_admit_design = $admit_settings['admit_card_design'] ?? 'design-1';

$admit_preview_path = BASE_URL . "/assets/img/preview/admit-card/";
?>

<div class="container py-5 px-0">
    <div class="row justify-content-center mx-0">
        <div class="col-lg-10">
            <div class="card shadow-lg border-0 rounded-4 overflow-hidden">
                <div class="card-header bg-primary text-white py-4 text-center">
                    <i class="fas fa-id-badge fa-3x mb-2"></i>
                    <h3 class="mb-0 fw-bold">Admit Card Configuration</h3>
                    <p class="mb-0 text-white-50">Customize the appearance and details of student admit cards</p>
                </div>
                
                <div class="card-body p-4 p-md-5 bg-white">
                    <form id="admit_settings_form" enctype="multipart/form-data">
                        
                        <!-- Design Selection Section -->
                        <div class="mb-5">
                            <h5 class="fw-bold pb-2 text-primary border-bottom mb-4">
                                <i class="fas fa-layer-group me-2"></i>Template Design
                            </h5>
                            <div class="row align-items-center">
                                <div class="col-md-5 mb-3 mb-md-0 text-center">
                                    <label class="form-label fw-bold text-muted">Select Template</label>
                                    <select
                                        name="admit_card_design"
                                        class="form-select form-select-lg border-primary border-2 rounded-3 shadow-sm"
                                        onchange="updatePreviewImgTag()">
                                        <?php foreach ($admit_designs as $design): ?>
                                            <option value="<?= $design ?>" <?= $current_admit_design == $design ? 'selected' : '' ?>>
                                                <?= ucwords(str_replace("-", " ", $design)) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-7 d-flex justify-content-center">
                                    <div class="preview-container p-2 border border-2 rounded-3 shadow-sm bg-light">
                                        <img
                                            src=""
                                            alt="Admit Card Template Preview"
                                            class="img-fluid rounded-2"
                                            style="max-width: 100%; max-height: 250px; object-fit: contain;"
                                            id="admit_card_preview"
                                            data-fancybox="admitcard"
                                            data-caption="Admit Card Template" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- School Information Section -->
                        <div class="mb-5">
                            <h5 class="fw-bold pb-2 text-primary border-bottom mb-4">
                                <i class="fas fa-school me-2"></i>School Details & Instructions
                            </h5>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">School Address</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light text-primary"><i class="fas fa-map-marker-alt"></i></span>
                                        <input type="text" class="form-control" name="school_address" value="<?= safe_htmlspecialchars($school_address) ?>" placeholder="e.g., 123 Education St, City">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">School Contact</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light text-primary"><i class="fas fa-phone-alt"></i></span>
                                        <input type="text" class="form-control" name="school_contact" value="<?= safe_htmlspecialchars($school_contact) ?>" placeholder="Phone number or Email">
                                    </div>
                                </div>
                                <div class="col-12 mt-4">
                                    <label class="form-label fw-bold">Exam Instructions</label>
                                    <textarea class="form-control rounded-3" name="admit_instructions" rows="4" placeholder="Enter instructions to be printed on the admit card..."><?= safe_htmlspecialchars($admit_instructions) ?></textarea>
                                    <div class="form-text text-muted">These instructions will be displayed at the bottom of the admit card.</div>
                                </div>
                            </div>
                        </div>

                        <!-- Visuals & Branding Section -->
                        <div class="mb-4">
                            <h5 class="fw-bold pb-2 text-primary border-bottom mb-4">
                                <i class="fas fa-palette me-2"></i>Visuals & Branding
                            </h5>
                            
                            <div class="row mb-4">
                                <div class="col-12">
                                    <label class="form-label fw-bold">Background Image</label>
                                    <input type="file" class="form-control" name="background_image" accept="image/png, image/jpeg, image/jpg">
                                    <div class="form-text text-muted">Upload a high-resolution image to set as the admit card background (leave blank to keep current).</div>
                                </div>
                            </div>

                            <label class="form-label fw-bold w-100 mb-3">Color Scheme</label>
                            <div class="row g-3">
                                <div class="col-md-4 col-sm-6">
                                    <div class="color-picker-wrapper p-3 border rounded-3 bg-light text-center h-100">
                                        <label class="form-label small fw-bold text-muted d-block">Primary Color</label>
                                        <input type="color" class="form-control form-control-color w-100 mx-auto" name="theme_color_primary" value="<?= safe_htmlspecialchars($theme_color_primary) ?>" title="Choose primary color">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6">
                                    <div class="color-picker-wrapper p-3 border rounded-3 bg-light text-center h-100">
                                        <label class="form-label small fw-bold text-muted d-block">Dark Color</label>
                                        <input type="color" class="form-control form-control-color w-100 mx-auto" name="theme_color_dark" value="<?= safe_htmlspecialchars($theme_color_dark) ?>" title="Choose dark color">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6">
                                    <div class="color-picker-wrapper p-3 border rounded-3 bg-light text-center h-100">
                                        <label class="form-label small fw-bold text-muted d-block">Light Color</label>
                                        <input type="color" class="form-control form-control-color w-100 mx-auto" name="theme_color_light" value="<?= safe_htmlspecialchars($theme_color_light) ?>" title="Choose light color">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6">
                                    <div class="color-picker-wrapper p-3 border rounded-3 bg-light text-center h-100">
                                        <label class="form-label small fw-bold text-muted d-block">Background Color</label>
                                        <input type="color" class="form-control form-control-color w-100 mx-auto" name="background_color" value="<?= safe_htmlspecialchars($background_color) ?>" title="Choose background color">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6">
                                    <div class="color-picker-wrapper p-3 border rounded-3 bg-light text-center h-100">
                                        <label class="form-label small fw-bold text-muted d-block">School Name Color</label>
                                        <input type="color" class="form-control form-control-color w-100 mx-auto" name="school_name_color" value="<?= safe_htmlspecialchars($school_name_color) ?>" title="Choose school name color">
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6">
                                    <div class="color-picker-wrapper p-3 border rounded-3 bg-light text-center h-100">
                                        <label class="form-label small fw-bold text-muted d-block">Address Color</label>
                                        <input type="color" class="form-control form-control-color w-100 mx-auto" name="school_address_color" value="<?= safe_htmlspecialchars($school_address_color) ?>" title="Choose address color">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr class="my-4">

                        <!-- Action Buttons -->
                        <div class="d-flex justify-content-end gap-3 mt-4">
                            <button class="btn btn-light border px-4 py-2" type="button" onclick="setDefaultValues()">
                                <i class="fas fa-undo me-2"></i>Reset Colors
                            </button>
                            <button class="btn btn-primary px-5 py-2 fw-bold shadow-sm" type="submit" id="save_btn">
                                <i class="fas fa-save me-2"></i>Save Changes
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .rounded-4 {
        border-radius: 1rem !important;
    }
    
    .color-picker-wrapper {
        transition: transform 0.2s ease;
    }
    
    .color-picker-wrapper:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.05);
    }

    .form-control-color {
        height: 40px;
        border-radius: 8px;
        cursor: pointer;
    }

    .btn-primary {
        transition: all 0.3s ease;
    }

    .btn-primary:hover {
        background-color: #0b5ed7;
        border-color: #0b5ed7;
        transform: translateY(-2px);
        box-shadow: 0 4px 15px rgba(13, 110, 253, 0.4) !important;
    }
    
    .preview-container {
        position: relative;
        overflow: hidden;
        background: #f8f9fa;
    }
</style>

<script>
    function setDefaultValues() {
        $('[name="theme_color_primary"]').val('<?= $default_colors['primary'] ?>');
        $('[name="theme_color_dark"]').val('<?= $default_colors['dark'] ?>');
        $('[name="theme_color_light"]').val('<?= $default_colors['light'] ?>');
        $('[name="background_color"]').val('<?= $default_colors['background'] ?>');
        $('[name="school_name_color"]').val('<?= $default_colors['school_name'] ?>');
        $('[name="school_address_color"]').val('<?= $default_colors['school_address'] ?>');
        toastr.info("Colors reset to default values.");
    }

    function updatePreviewImgTag() {
        let design = $('select[name="admit_card_design"]').val();
        let previewPath = '<?= $admit_preview_path ?>' + design + '.jpg';

        $('#admit_card_preview').attr('src', previewPath).hide().fadeIn(300);
    }

    function submitForm() {
        let formData = new FormData($('#admit_settings_form')[0]);

        $.ajax({
            url: '<?= BASE_URL ?>' + '/api/admin/put/website-config/save-admit-card-settings.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            beforeSend: function() {
                showLoadingAlert(); // Assuming this is defined globally
            },
            success: function(response) {
                Swal.close();
                if (response.success) {
                    Swal.fire({
                        title: 'Success!',
                        text: response.message,
                        icon: 'success',
                        customClass: {
                            popup: "rounded-4 shadow-lg",
                            confirmButton: "btn btn-success px-4 py-2"
                        }
                    });
                } else {
                    Swal.fire({
                        title: 'Error!',
                        text: response.message,
                        icon: 'error',
                        customClass: {
                            popup: "rounded-4 shadow-lg",
                            confirmButton: "btn btn-danger px-4 py-2"
                        }
                    });
                }
            },
            error: function(e) {
                Swal.close();
                toastr.error('An error occurred while connecting to the server.');
            }
        });
    }

    $(document).ready(function() {
        updatePreviewImgTag();

        $('#admit_settings_form').on('submit', function(e) {
            e.preventDefault();
            submitForm();
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>