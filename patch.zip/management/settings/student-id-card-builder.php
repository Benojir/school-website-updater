<?php
/**
 * id-card-builder.php
 * Visual Drag-and-Drop ID Card Builder — Editor Page
 * -----------------------------------------------------------------
 * On this page a superadmin designs the ID card using a Fabric.js canvas.
 * The canvas state (JSON) is sent via AJAX to save-student-id-card-design.php at the end.
 *
 * UPDATE:
 *  - Photoshop-style Layers panel (drag-reorder, show/hide, lock)
 *  - Undo / Redo (Ctrl+Z / Ctrl+Y)
 *  - Keyboard shortcuts: arrow-key move, Delete, Ctrl+D duplicate,
 *    Ctrl+C / Ctrl+V style copy-paste, ] [ layer order
 *  - Text stroke (color + width) and text shadow (color, blur, offset)
 *  - Image border radius and image background color
 *  - More fonts (Google Fonts)
 *  - New dynamic variables for school name / address / contact number
 *  - Loading overlay before the canvas is ready (font preload + safety timeout)
 *
 * UPDATE (Aug 2026) — free-form card formats:
 *  - Any card SIZE (Card Setup panel: presets + custom width/height in mm)
 *  - Horizontal (landscape) as well as vertical (portrait) cards
 *  - Optional BACK side — Front/Back tabs, each side its own design & undo stack
 */
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
/** @var string $school_name */
echo "<title>Student ID Card Builder - " . $school_name . "</title>";

if (!isSuperAdmin()) {
    include_once("../../includes/permission-denied.php");
    return;
}

// The previously saved design (if any) is loaded from the DB and injected into JS.
// Both sides plus the card size come from the same active row.
$stmt = $pdo->query("SELECT design_json, back_design_json, has_back, canvas_width, canvas_height
                     FROM student_id_card_templates WHERE is_active = 1 LIMIT 1");
$row = $stmt->fetch(PDO::FETCH_ASSOC);

$existing_design_json      = $row ? $row['design_json'] : 'null';
$existing_back_design_json = ($row && !empty($row['back_design_json'])) ? $row['back_design_json'] : 'null';
$existing_has_back         = ($row && !empty($row['has_back'])) ? 1 : 0;
// Card size is stored in pixels; the builder's scale is a fixed 10 px per mm
// (see PX_PER_MM in id-card-builder.js), so the mm inputs are just px / 10.
$existing_canvas_width     = $row ? (int)$row['canvas_width'] : 550;
$existing_canvas_height    = $row ? (int)$row['canvas_height'] : 850;
?>

<!-- Preconnect so the CDNs resolve faster -->
<link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<!-- Google Fonts for more font options -->
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Open+Sans:wght@400;600;700&family=Lato:wght@400;700&family=Nunito:wght@400;700&family=Oswald:wght@400;600&family=Playfair+Display:wght@400;700&family=Merriweather:wght@400;700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">

<!-- Fabric.js CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.0/fabric.min.js"></script>

<style>
    .builder-wrapper { display: flex; gap: 16px; height: calc(100vh - 140px); }

    /* --- Sidebar / Toolbox --- */
    .builder-sidebar {
        width: 240px; flex-shrink: 0; background: #fff; border-radius: 8px;
        box-shadow: 0 1px 4px rgba(0,0,0,.08); padding: 14px; overflow-y: auto;
    }
    .builder-sidebar h6 { font-size: .8rem; text-transform: uppercase; color: #6c757d; margin: 14px 0 8px; }
    .builder-sidebar h6:first-child { margin-top: 0; }
    .tool-btn {
        width: 100%; text-align: left; margin-bottom: 6px; font-size: .85rem;
    }
    .shortcuts-box {
        font-size: .72rem; color: #6c757d; background: #f8f9fa; border-radius: 6px;
        padding: 8px 10px; line-height: 1.6;
    }
    .shortcuts-box kbd {
        background: #888888; border-radius: 3px; padding: 0 4px; font-size: .7rem;
    }

    /* --- Canvas Stage --- */
    /* Column layout: the Front/Back tab bar sits on top, the canvas area fills
       the rest. fitCanvasToStage() in id-card-builder.js measures
       #stageCanvasArea (NOT .builder-stage) so the tab bar's height is already
       excluded from the space the card is scaled to fit. */
    .builder-stage {
        flex: 1; position: relative; display: flex; flex-direction: column;
        align-items: center; gap: 10px; padding: 10px;
        background: #e9ecef; border-radius: 8px; overflow: hidden;
    }
    .stage-canvas-area {
        flex: 1; width: 100%; min-height: 0; overflow: auto;
        display: flex; align-items: center; justify-content: center;
    }
    #idCardCanvas { box-shadow: 0 2px 10px rgba(0,0,0,.25); }

    /* --- Front / Back side tabs (above the canvas) --- */
    .side-tabs { display: flex; gap: 6px; flex-shrink: 0; }
    .side-tabs .side-tab {
        font-size: .78rem; font-weight: 600; padding: 5px 18px; border-radius: 6px;
        border: 1px solid #ced4da; background: #f8f9fa; color: #495057;
    }
    .side-tabs .side-tab.active { background: #4F46E5; border-color: #4F46E5; color: #fff; }
    .side-tabs .side-tab:disabled { opacity: .45; cursor: not-allowed; }

    /* --- Card Setup (size / orientation / sides) --- */
    .card-setup-row { display: flex; gap: 8px; margin-bottom: 6px; }
    .card-setup-row > div { flex: 1; }
    .card-size-note { font-size: .7rem; color: #6c757d; display: block; margin-top: 4px; }
    .card-size-note b { color: #495057; }

    .canvas-loading-overlay {
        position: absolute; inset: 0; display: flex; flex-direction: column;
        align-items: center; justify-content: center; gap: 10px;
        background: rgba(233,236,239,.9); z-index: 5; border-radius: 8px;
        font-size: .85rem; color: #495057;
    }
    .canvas-loading-overlay .spinner-border { width: 2rem; height: 2rem; }

    /* --- Properties Panel --- */
    .builder-props {
        width: 280px; flex-shrink: 0; background: #fff; border-radius: 8px;
        box-shadow: 0 1px 4px rgba(0,0,0,.08); padding: 14px; overflow-y: auto;
    }
    .builder-props .prop-group { margin-bottom: 14px; }
    .builder-props label { font-size: .78rem; font-weight: 600; margin-bottom: 3px; display: block; }
    .no-selection-msg { color: #adb5bd; font-size: .85rem; text-align: center; margin-top: 40px; }
    .prop-subrow { display: flex; gap: 8px; align-items: center; }
    .prop-subrow .form-control-color { width: 44px; padding: 2px; flex-shrink: 0; }
    .prop-inline-label { font-size: .72rem; color: #6c757d; margin-bottom: 2px; display: block; }
    .prop-range-row { display: flex; align-items: center; gap: 8px; }
    .prop-range-row input[type="range"] { flex: 1; }
    .prop-range-value { font-size: .75rem; color: #495057; min-width: 34px; text-align: right; }

    /* --- Layers Panel --- */
    #layersList { max-height: 220px; overflow-y: auto; border: 1px solid #eee; border-radius: 6px; }
    .layer-item {
        display: flex; align-items: center; gap: 6px; padding: 6px 8px;
        font-size: .78rem; border-bottom: 1px solid #f1f1f1; cursor: pointer; background: #fff;
    }
    .layer-item:last-child { border-bottom: none; }
    .layer-item:hover { background: #f8f9fa; }
    .layer-item.active { background: #e7f1ff; }
    .layer-item.dragging { opacity: .4; }
    .layer-icon { width: 16px; text-align: center; color: #6c757d; flex-shrink: 0; }
    .layer-name { flex: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .layer-visibility-btn, .layer-lock-btn {
        border: none; background: transparent; color: #adb5bd; font-size: .75rem; padding: 2px 4px;
    }
    .layer-visibility-btn:hover, .layer-lock-btn:hover { color: #495057; }
    /* Locked layers get a distinct red lock icon (and a faint tinted row) so a
       locked element is obvious at a glance, not just via the icon shape. */
    .layer-lock-btn.locked { color: #dc3545; }
    .layer-lock-btn.locked:hover { color: #b02a37; }
    .layer-item.is-locked { background: #fff5f5; }
    .layer-item.is-locked.active { background: #ffe3e3; }

    .line-count-indicator { font-size: .68rem; margin-top: 4px; display: block; }
</style>

<?php
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");
?>

<div class="container-fluid mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="m-0"><i class="fas fa-id-card me-2"></i>Student ID Card Builder</h4>
        <div class="d-flex gap-2">
            <button id="btnUndo" class="btn btn-outline-secondary" title="Undo (Ctrl+Z)">
                <i class="fas fa-undo"></i>
            </button>
            <button id="btnRedo" class="btn btn-outline-secondary" title="Redo (Ctrl+Y)">
                <i class="fas fa-redo"></i>
            </button>
            <button id="btnSaveDesign" class="btn btn-primary px-4">
                <i class="fas fa-save me-2"></i>Save Design
            </button>
        </div>
    </div>

    <div class="builder-wrapper">

        <!-- ================= SIDEBAR / TOOLBOX ================= -->
        <div class="builder-sidebar">
            <!-- Card Setup: physical size, orientation and number of sides.
                 Size is entered in millimetres and converted at a fixed
                 10 px per mm (PX_PER_MM in id-card-builder.js) — that ratio is
                 what keeps print resolution constant at any card size. -->
            <h6>Card Setup</h6>
            <select id="cardPresetSelect" class="form-select form-select-sm mb-2">
                <option value="55x85">55 × 85 mm — Vertical</option>
                <option value="54x85.6">54 × 85.6 mm — CR80 Card, Vertical</option>
                <option value="85.6x54">85.6 × 54 mm — CR80 Card, Horizontal</option>
                <option value="51x83.9">51 × 83.9 mm — CR79, Vertical</option>
                <option value="83.9x51">83.9 × 51 mm — CR79, Horizontal</option>
                <option value="74x105">74 × 105 mm — A7, Vertical</option>
                <option value="105x74">105 × 74 mm — A7, Horizontal</option>
                <option value="custom">Custom size…</option>
            </select>
            <div class="card-setup-row">
                <div>
                    <span class="prop-inline-label">Width (mm)</span>
                    <input type="number" id="cardWidthMm" class="form-control form-control-sm"
                           min="20" max="300" step="0.1">
                </div>
                <div>
                    <span class="prop-inline-label">Height (mm)</span>
                    <input type="number" id="cardHeightMm" class="form-control form-control-sm"
                           min="20" max="300" step="0.1">
                </div>
            </div>
            <div class="d-flex gap-2 mb-2">
                <button class="btn btn-outline-secondary btn-sm flex-fill" id="btnSwapDimensions"
                        title="Swap width and height (vertical ⇄ horizontal)">
                    <i class="fas fa-exchange-alt me-1"></i> Swap W/H
                </button>
                <button class="btn btn-outline-primary btn-sm flex-fill" id="btnApplyCardSize">
                    <i class="fas fa-check me-1"></i> Apply Size
                </button>
            </div>
            <small class="card-size-note" id="cardOrientationLabel"></small>

            <h6>Sides</h6>
            <select id="cardSidesSelect" class="form-select form-select-sm">
                <option value="single">Front only (single-sided)</option>
                <option value="both">Front &amp; Back (double-sided)</option>
            </select>
            <small class="card-size-note">
                Switching back to <b>Front only</b> doesn't delete the back design — it just stops it from being printed.
            </small>

            <h6>Dynamic Variables</h6>
            <select id="dynamicVarSelect" class="form-select form-select-sm mb-2">
                <optgroup label="Student">
                    <option value="{{student_name}}">Student Name</option>
                    <option value="{{roll_no}}">Roll No</option>
                    <option value="{{class}}">Class & Section</option>
                    <option value="{{dob}}">Date of Birth</option>
                    <option value="{{student_id}}">Student ID</option>
                    <option value="{{gender}}">Gender</option>
                    <option value="{{blood_group}}">Blood Group</option>
                    <option value="{{academic_year}}">Academic Year</option>
                    <option value="{{admission_date}}">Admission Date</option>
                    <option value="{{registration_no}}">Registration No</option>
                    <option value="{{aadhaar_no}}">Aadhaar Number</option>
                </optgroup>
                <optgroup label="Family & Contact">
                    <option value="{{father_name}}">Father's Name</option>
                    <option value="{{student_contact}}">Contact No</option>
                    <option value="{{alt_contact}}">Alternative Contact No</option>
                </optgroup>
                <optgroup label="Address">
                    <option value="{{student_address}}">Address</option>
                    <option value="{{village}}">Village</option>
                    <option value="{{post_office}}">Post Office</option>
                    <option value="{{police_station}}">Police Station</option>
                    <option value="{{district}}">District</option>
                    <option value="{{pin_code}}">PIN Code</option>
                </optgroup>
                <optgroup label="School">
                    <option value="{{school_name}}">School Name</option>
                    <option value="{{school_address}}">School Address</option>
                    <option value="{{school_contact_no}}">School Contact No</option>
                </optgroup>
            </select>
            <button class="btn btn-outline-primary btn-sm tool-btn" id="btnAddDynamicText">
                <i class="fas fa-plus me-1"></i> Add Variable Text
            </button>

            <h6>Static / Assets</h6>
            <button class="btn btn-outline-secondary btn-sm tool-btn" id="btnAddStaticText">
                <i class="fas fa-font me-1"></i> Add Static Text
            </button>
            <button class="btn btn-outline-secondary btn-sm tool-btn" id="btnAddSchoolLogo">
                <i class="fas fa-image me-1"></i> Add School Logo
            </button>
            <button class="btn btn-outline-secondary btn-sm tool-btn" id="btnAddStudentPhoto">
                <i class="fas fa-user-circle me-1"></i> Add Student Photo
            </button>
            <button class="btn btn-outline-secondary btn-sm tool-btn" id="btnAddQrPlaceholder">
                <i class="fas fa-qrcode me-1"></i> Add QR Placeholder
            </button>
            <label class="btn btn-outline-secondary btn-sm tool-btn mb-0">
                <i class="fas fa-upload me-1"></i> Upload Custom Image
                <input type="file" id="customImageInput" accept="image/*" hidden>
            </label>

            <h6>Style Tools</h6>
            <button class="btn btn-outline-info btn-sm tool-btn" id="btnCopyStyle">
                <i class="fas fa-copy me-1"></i> Copy Style (Ctrl+C)
            </button>
            <button class="btn btn-outline-info btn-sm tool-btn" id="btnPasteStyle">
                <i class="fas fa-paste me-1"></i> Paste Style (Ctrl+V)
            </button>
            <button class="btn btn-outline-secondary btn-sm tool-btn" id="btnDuplicateSelected">
                <i class="fas fa-clone me-1"></i> Duplicate (Ctrl+D)
            </button>

            <h6>Layers</h6>
            <div class="d-flex gap-2 mb-2">
                <button class="btn btn-outline-dark btn-sm flex-fill" id="btnBringForward" title="]">
                    <i class="fas fa-arrow-up"></i>
                </button>
                <button class="btn btn-outline-dark btn-sm flex-fill" id="btnSendBackward" title="[">
                    <i class="fas fa-arrow-down"></i>
                </button>
                <button class="btn btn-outline-danger btn-sm flex-fill" id="btnDeleteSelected" title="Delete">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
            <div class="d-flex gap-2 mb-2">
                <button class="btn btn-outline-secondary btn-sm flex-fill" id="btnLockAll" title="Lock all layers">
                    <i class="fas fa-lock me-1"></i> Lock All
                </button>
                <button class="btn btn-outline-secondary btn-sm flex-fill" id="btnUnlockAll" title="Unlock all layers">
                    <i class="fas fa-unlock me-1"></i> Unlock All
                </button>
            </div>
            <div id="layersList"></div>

            <h6>Shortcuts</h6>
            <div class="shortcuts-box">
                <kbd>↑↓←→</kbd> Move (Shift = larger step)<br>
                <kbd>Delete</kbd> Remove selected<br>
                <kbd>Ctrl+Z</kbd> / <kbd>Ctrl+Y</kbd> Undo / Redo<br>
                <kbd>Ctrl+C</kbd> / <kbd>Ctrl+V</kbd> Copy / Paste style<br>
                <kbd>Ctrl+D</kbd> Duplicate<br>
                <kbd>]</kbd> / <kbd>[</kbd> Forward / Backward
            </div>
        </div>

        <!-- ================= CANVAS STAGE ================= -->
        <div class="builder-stage">
            <div class="canvas-loading-overlay" id="canvasLoadingOverlay">
                <div class="spinner-border text-primary" role="status"></div>
                <span>Preparing canvas...</span>
            </div>

            <!-- Front / Back tabs. Both sides share ONE Fabric canvas whose
                 contents are swapped on switch (see switchSide() in
                 id-card-builder.js); each side keeps its own undo history.
                 The Back tab stays disabled while Sides = "Front only". -->
            <div class="side-tabs" id="sideTabs">
                <button type="button" class="side-tab active" id="tabSideFront">
                    <i class="fas fa-id-card me-1"></i> Front
                </button>
                <button type="button" class="side-tab" id="tabSideBack" disabled
                        title="Set Sides to &quot;Front &amp; Back&quot; to design the back">
                    <i class="fas fa-id-card-alt me-1"></i> Back
                </button>
            </div>

            <div class="stage-canvas-area" id="stageCanvasArea">
                <canvas id="idCardCanvas"></canvas>
            </div>
        </div>

        <!-- ================= PROPERTIES PANEL ================= -->
        <div class="builder-props" id="propsPanel">
            <div class="no-selection-msg" id="noSelectionMsg">
                No element selected.<br>Click an element on the canvas.
            </div>

            <div id="propsFields" style="display:none;">
                <!-- Font-related controls only apply to text objects (hidden when an image is selected) -->
                <div id="textOnlyProps">
                    <div class="prop-group">
                        <label>Font Family</label>
                        <select id="propFontFamily" class="form-select form-select-sm"></select>
                    </div>
                    <div class="prop-group">
                        <label>Font Size</label>
                        <input type="number" id="propFontSize" class="form-control form-control-sm" min="4" max="120">
                    </div>
                    <div class="prop-group">
                        <label>Text Color</label>
                        <input type="color" id="propColor" class="form-control form-control-color form-control-sm">
                    </div>
                    <div class="prop-group d-flex gap-2">
                        <button class="btn btn-outline-secondary btn-sm flex-fill" id="propBold"><b>B</b></button>
                        <button class="btn btn-outline-secondary btn-sm flex-fill" id="propItalic"><i>I</i></button>
                        <button class="btn btn-outline-secondary btn-sm flex-fill" id="propUnderline"><u>U</u></button>
                    </div>
                    <div class="prop-group">
                        <label>Alignment</label>
                        <div class="btn-group w-100" role="group">
                            <button class="btn btn-outline-secondary btn-sm" data-align="left"><i class="fas fa-align-left"></i></button>
                            <button class="btn btn-outline-secondary btn-sm" data-align="center"><i class="fas fa-align-center"></i></button>
                            <button class="btn btn-outline-secondary btn-sm" data-align="right"><i class="fas fa-align-right"></i></button>
                        </div>
                    </div>

                    <!-- Text case (Uppercase / Lowercase / Capitalize) -->
                    <div class="prop-group">
                        <label>Text Case</label>
                        <select id="propTextCase" class="form-select form-select-sm">
                            <option value="none">Normal (As Typed)</option>
                            <option value="uppercase">UPPERCASE</option>
                            <option value="lowercase">lowercase</option>
                            <option value="capitalize">Capitalize Each Word</option>
                        </select>
                        <small class="text-muted d-block mt-1" style="font-size:.68rem;">
                            For Variable Text, this is applied to the real student data at print time — this canvas preview only shows the field's label.
                        </small>
                    </div>

                    <!-- Line height (spacing between wrapped lines) -->
                    <div class="prop-group">
                        <label>Line Height</label>
                        <div class="prop-range-row">
                            <input type="range" id="propLineHeight" min="0.8" max="2.5" step="0.05" value="1.16">
                            <span class="prop-range-value" id="propLineHeightValue">1.16</span>
                        </div>
                    </div>

                    <!-- Max lines: prevents long names/addresses from overflowing the card -->
                    <div class="prop-group">
                        <label>Max Lines <span class="text-muted fw-normal">(0 = unlimited)</span></label>
                        <input type="number" id="propMaxLines" class="form-control form-control-sm" min="0" max="20" step="1" value="0">
                        <small class="text-muted line-count-indicator" id="propLineCountIndicator"></small>
                    </div>

                    <!-- Fixed-height clip: HARD safety net so this field can NEVER visually
                         spill outside its own box (onto other elements or off the card),
                         no matter how long the real student data turns out to be. Works
                         together with Max Lines above (which just truncates nicely with
                         "…") — recommended to turn this ON for every field. -->
                    <div class="prop-group">
                        <label class="d-flex align-items-center gap-2">
                            <input type="checkbox" id="propClipEnable" class="form-check-input mt-0">
                            Clip to Fixed Height
                        </label>
                        <div class="prop-subrow mb-1">
                            <input type="number" id="propBoxHeight" class="form-control form-control-sm" min="10" step="1" placeholder="Height (px)">
                            <button type="button" class="btn btn-outline-secondary btn-sm" id="btnUseCurrentHeight" title="Use this field's current height as the box height">Use Current</button>
                        </div>
                        <small class="text-muted d-block" id="propClipWarning" style="font-size:.68rem;"></small>
                    </div>

                    <!-- Fixed-width clip: same idea as Clip to Fixed Height, but
                         horizontal — the field can never visually spill past the
                         given width (onto other elements or off the card edge),
                         no matter how long the real student data turns out to be. -->
                    <div class="prop-group">
                        <label class="d-flex align-items-center gap-2">
                            <input type="checkbox" id="propClipWidthEnable" class="form-check-input mt-0">
                            Clip to Fixed Width
                        </label>
                        <div class="prop-subrow mb-1">
                            <input type="number" id="propBoxWidth" class="form-control form-control-sm" min="10" step="1" placeholder="Width (px)">
                            <button type="button" class="btn btn-outline-secondary btn-sm" id="btnUseCurrentWidth" title="Use this field's current width as the box width">Use Current</button>
                        </div>
                        <small class="text-muted d-block" id="propClipWidthWarning" style="font-size:.68rem;"></small>
                    </div>

                    <!-- Gradient text fill -->
                    <div class="prop-group">
                        <label class="d-flex align-items-center gap-2">
                            <input type="checkbox" id="propGradientEnable" class="form-check-input mt-0">
                            Gradient Color
                        </label>
                        <div class="prop-subrow mb-2">
                            <div>
                                <span class="prop-inline-label">Color 1</span>
                                <input type="color" id="propGradientColor1" class="form-control form-control-color form-control-sm" disabled>
                            </div>
                            <div>
                                <span class="prop-inline-label">Color 2</span>
                                <input type="color" id="propGradientColor2" class="form-control form-control-color form-control-sm" disabled>
                            </div>
                        </div>
                        <span class="prop-inline-label">Angle</span>
                        <div class="prop-range-row">
                            <input type="range" id="propGradientAngle" min="0" max="360" step="1" value="0" disabled>
                            <span class="prop-range-value" id="propGradientAngleValue">0°</span>
                        </div>
                    </div>

                    <!-- Text background color + rounded corners -->
                    <div class="prop-group">
                        <label class="d-flex align-items-center gap-2">
                            <input type="checkbox" id="propTextBgEnable" class="form-check-input mt-0">
                            Background Color
                        </label>
                        <input type="color" id="propTextBgColor" class="form-control form-control-color form-control-sm mb-2" disabled>
                        <span class="prop-inline-label">Background Border Radius</span>
                        <div class="prop-range-row">
                            <input type="range" id="propTextBgRadius" min="0" max="50" step="1" value="0" disabled>
                            <span class="prop-range-value" id="propTextBgRadiusValue">0%</span>
                        </div>
                    </div>
                    <hr>
                </div>

                <!-- Image-only controls: border radius + background color (hidden when text is selected) -->
                <div id="imageOnlyProps">
                    <div class="prop-group">
                        <label>Border Radius</label>
                        <div class="prop-range-row">
                            <input type="range" id="propBorderRadius" min="0" max="100" step="1" value="0">
                            <span class="prop-range-value" id="propBorderRadiusValue">0%</span>
                        </div>
                    </div>
                    <div class="prop-group">
                        <label class="d-flex align-items-center gap-2">
                            <input type="checkbox" id="propBgColorEnable" class="form-check-input mt-0">
                            Background Color
                        </label>
                        <input type="color" id="propBgColor" class="form-control form-control-color form-control-sm" disabled>
                    </div>
                    <hr>
                </div>

                <!-- Stroke and Shadow — apply to both text and images (common Fabric properties) -->
                <div class="prop-group">
                    <label class="d-flex align-items-center gap-2">
                        <input type="checkbox" id="propStrokeEnable" class="form-check-input mt-0">
                        Stroke / Outline
                    </label>
                    <div class="prop-subrow mb-2">
                        <div>
                            <span class="prop-inline-label">Color</span>
                            <input type="color" id="propStrokeColor" class="form-control form-control-color form-control-sm" disabled>
                        </div>
                        <div class="flex-fill">
                            <span class="prop-inline-label">Width</span>
                            <input type="number" id="propStrokeWidth" class="form-control form-control-sm" min="0" max="20" step="0.5" disabled>
                        </div>
                    </div>
                    <span class="prop-inline-label">Position</span>
                    <select id="propStrokePosition" class="form-select form-select-sm" disabled>
                        <option value="center">Center</option>
                        <option value="inside">Inside</option>
                        <option value="outside">Outside</option>
                    </select>
                    <small class="text-muted d-block mt-1" style="font-size:.68rem;">
                        Inside/Outside are pixel-exact on images. On text, Outside is exact; Inside is a close approximation (very thick strokes may slightly bleed between letters).
                    </small>
                </div>

                <hr>

                <div class="prop-group">
                    <label class="d-flex align-items-center gap-2">
                        <input type="checkbox" id="propShadowEnable" class="form-check-input mt-0">
                        Shadow
                    </label>
                    <div class="prop-subrow mb-2">
                        <div>
                            <span class="prop-inline-label">Color</span>
                            <input type="color" id="propShadowColor" class="form-control form-control-color form-control-sm">
                        </div>
                        <div class="flex-fill">
                            <span class="prop-inline-label">Blur</span>
                            <input type="number" id="propShadowBlur" class="form-control form-control-sm" min="0" max="50">
                        </div>
                    </div>
                    <div class="prop-subrow">
                        <div class="flex-fill">
                            <span class="prop-inline-label">Offset X</span>
                            <input type="number" id="propShadowOffsetX" class="form-control form-control-sm" min="-50" max="50">
                        </div>
                        <div class="flex-fill">
                            <span class="prop-inline-label">Offset Y</span>
                            <input type="number" id="propShadowOffsetY" class="form-control form-control-sm" min="-50" max="50">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Previously saved design (if any), injected from PHP into JS variables.
    // EXISTING_DESIGN_JSON is the FRONT side; EXISTING_BACK_DESIGN_JSON is the
    // BACK side (null when the card has never had one).
    const EXISTING_DESIGN_JSON = <?= $existing_design_json ?: 'null' ?>;
    const EXISTING_BACK_DESIGN_JSON = <?= $existing_back_design_json ?: 'null' ?>;
    // Card format of the saved design. widthPx/heightPx are the canvas size in
    // pixels; the builder shows them as millimetres at 10 px per mm.
    const CARD_CONFIG = {
        widthPx: <?= $existing_canvas_width ?>,
        heightPx: <?= $existing_canvas_height ?>,
        hasBack: <?= $existing_has_back ? 'true' : 'false' ?>
    };
    const SAVE_DESIGN_URL = '../../api/admin/put/website-config/save-student-id-card-design.php';
</script>
<script src="../../assets/js/student/id-card/id-card-builder.js"></script>

<?php include_once("../../includes/body-close.php"); ?>