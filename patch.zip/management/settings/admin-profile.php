<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Admin Profile - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is logged in
if (!isAnyAdminLoggedIn()) {
    header("Location: ../../auth/login.php");
    exit();
}

$authData = authenticateAdminApiRequest($pdo);

// Get admin details from database
$admin_id = $authData['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch();

// Get admin role name if role_id exists
$role_name = "Super Admin";
if (!empty($admin['role_id'])) {
    $stmt = $pdo->prepare("SELECT name FROM admin_roles WHERE id = ?");
    $stmt->execute([$admin['role_id']]);
    $role = $stmt->fetch();
    $role_name = $role['name'] ?? "Custom Role";
}
?>

<div class="container">

    <h2 class="m-0"><i class="fas fa-user-cog me-2"></i>Admin Profile</h2>

    <div class="card shadow-sm my-4">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0"><i class="fas fa-info-circle me-2"></i>Account Information</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Name:</strong> <?= safe_htmlspecialchars($admin['full_name']) ?></p>
                    <p class="mb-0"><strong>Email:</strong> <span id="currentEmailShowSpan"><?= safe_htmlspecialchars($admin['email']) ?></span></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Admin Type:</strong> <?= safe_htmlspecialchars($role_name) ?></p>
                    <p class="mb-0"><strong>Account Status:</strong>
                        <span class="badge bg-<?= $admin['status'] == 'active' ? 'success' : 'danger' ?>">
                            <?= ucfirst($admin['status']) ?>
                        </span>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card shadow-sm my-4">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="fas fa-user-edit me-2"></i>Update Username</h4>
                </div>
                <div class="card-body">
                    <form id="updateUsernameForm" autocomplete="off">
                        <div class="mb-3">
                            <label for="currentUsernameShowInput" class="form-label">Current Username</label>
                            <input type="text" class="form-control" id="currentUsernameShowInput"
                                value="<?= safe_htmlspecialchars($admin['username']) ?>" readonly disabled>
                        </div>
                        <div class="mb-3">
                            <label for="newUsernameInput" class="form-label">New Username</label>
                            <input type="text" class="form-control" id="newUsernameInput" name="newUsernameInput"
                                minlength="3" maxlength="25" required>
                            <div class="form-text">Username must be 3-25 characters long</div>
                        </div>
                        <div class="mb-3">
                            <label for="confirm_password_input_for_username" class="form-label">Confirm Password</label>
                            <input type="password" class="form-control" id="confirm_password_input_for_username"
                                name="confirmPassword" required>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Update Username
                        </button>
                        <div id="usernameMessage" class="mt-2 small"></div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow-sm my-4">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="fas fa-key me-2"></i>Change Password</h4>
                </div>
                <div class="card-body">
                    <form id="updatePasswordForm" autocomplete="off">
                        <div class="mb-3">
                            <label for="current_password_input" class="form-label">Current Password</label>
                            <input type="password" class="form-control" id="current_password_input"
                                name="currentPassword" required>
                        </div>
                        <div class="mb-3">
                            <label for="new_password_input" class="form-label">New Password</label>
                            <input type="password" class="form-control" id="new_password_input"
                                name="newPassword" minlength="6" required>
                            <div class="form-text">Password must be at least 6 characters long</div>
                        </div>
                        <div class="mb-3">
                            <label for="confirm_new_password" class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" id="confirm_new_password"
                                name="confirmPassword" required>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Change Password
                        </button>
                        <div id="passwordMessage" class="mt-2 small"></div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow-sm my-4">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="fas fa-user-edit me-2"></i>User Information</h4>
                </div>
                <div class="card-body">
                    <form id="updateUserInfoForm" autocomplete="off">
                        <div class="mb-3">
                            <label for="adminName" class="form-label">Admin Name</label>
                            <input type="text" class="form-control" name="adminName" id="adminName"
                                value="<?= safe_htmlspecialchars($admin['full_name']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="loginEmail" class="form-label">Login Email</label>
                            <input type="email" class="form-control" name="loginEmail" id="loginEmail"
                                value="<?= safe_htmlspecialchars($admin['email']) ?>" <?=(isSuperAdmin() ? 'disabled' : '')?>>
                        </div>
                        <div class="mb-3">
                            <label for="confirm_password_input_for_userinfo" class="form-label">Confirm Password</label>
                            <input type="password" class="form-control" id="confirm_password_input_for_userinfo"
                                name="confirmPassword" required>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Update Now
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Update Username Form Submission
        $('#updateUsernameForm').on('submit', function(e) {
            e.preventDefault();
            const form = $(this);
            const btn = form.find('button[type="submit"]');
            const originalBtnText = btn.html();

            btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Updating...');
            $('#usernameMessage').removeClass('text-success text-danger').html('');

            $.ajax({
                url: '../../api/admin/auth/update-admin-username.php',
                type: 'POST',
                data: {
                    newUsername: $('#newUsernameInput').val(),
                    confirmPassword: $('#confirm_password_input_for_username').val(),
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $('#usernameMessage').addClass('text-success').html(response.message);
                        $('#currentUsernameShowInput').val($('#newUsernameInput').val());
                        $('#newUsernameInput').val("")
                        $('#confirm_password_input_for_username').val("")
                        toastr.success(response.message);
                        showSuccessAlert(response.message);
                    } else {
                        $('#usernameMessage').addClass('text-danger').html(response.message);
                        toastr.error(response.message);
                        showErrorAlert(response.message);
                    }
                },
                error: function(e) {
                    $('#usernameMessage').addClass('text-danger').html('An error occurred. Please try again.');
                    toastr.error('An error occured. Please try again.');
                    showErrorAlert('An error occurred. Please try again.');
                    console.error(e.responseText);
                },
                complete: function() {
                    btn.prop('disabled', false).html(originalBtnText);
                }
            });
        });

        // Update Password Form Submission
        $('#updatePasswordForm').on('submit', function(e) {
            e.preventDefault();
            const form = $(this);
            const btn = form.find('button[type="submit"]');
            const originalBtnText = btn.html();

            // Validate password match
            if ($('#new_password_input').val() !== $('#confirm_new_password').val()) {
                $('#passwordMessage').addClass('text-danger').html('Passwords do not match');
                toastr.error('Passwords do not match');
                return;
            }

            btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Updating...');
            $('#passwordMessage').removeClass('text-success text-danger').html('');

            $.ajax({
                url: '../../api/admin/auth/update-admin-password.php',
                type: 'POST',
                data: form.serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $('#passwordMessage').addClass('text-success').html(response.message);
                        form.trigger('reset');
                        toastr.success(response.message);
                        showSuccessAlert(response.message);
                    } else {
                        $('#passwordMessage').addClass('text-danger').html(response.message);
                        toastr.error(response.message);
                        showErrorAlert(response.message);
                    }
                },
                error: function(e) {
                    $('#passwordMessage').addClass('text-danger').html('An error occurred. Please try again.');
                    toastr.error('An error occured. Please try again.');
                    console.error(e.responseText);
                    showErrorAlert('An error occurred. Please try again.');
                },
                complete: function() {
                    btn.prop('disabled', false).html(originalBtnText);
                }
            });
        });

        // Update User Info Form Submission
        $('#updateUserInfoForm').on('submit', function(e) {
            e.preventDefault();
            const form = $(this);
            const btn = form.find('button[type="submit"]');
            const originalBtnText = btn.html();

            btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Updating...');
            $('#passwordMessage').removeClass('text-success text-danger').html('');

            $.ajax({
                url: '../../api/admin/auth/update-userinfo.php',
                type: 'POST',
                data: form.serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        showSuccessAlert(response.message);
                    } else {
                        toastr.error(response.message);
                        showErrorAlert(response.message);
                    }
                },
                error: function(e) {
                    showErrorAlert('An error occurred. Please try again.');
                    toastr.error('An error occured. Please try again.');
                    console.error(e.responseText);
                },
                complete: function() {
                    btn.prop('disabled', false).html(originalBtnText);
                }
            });
        });

        // Remove all spaces from new username field
        $('#newUsernameInput').on('input', function() {
            $(this).val($(this).val().replace(/\s+/g, ''));
        });

    });
</script>

<?php include_once("../../includes/body-close.php"); ?>