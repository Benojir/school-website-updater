<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Admin Profile - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is logged in
if (!isAnyAdminLoggedIn()) {
    header("Location: ../../auth/login.php");
    exit();
}

$authData = authenticateAdminApiRequest($pdo);

// Get admin details from database
$admin_id = $authData['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch();

// Get admin role name if role_id exists
$role_name = "Super Admin";
if (!empty($admin['role_id'])) {
    $stmt = $pdo->prepare("SELECT name FROM admin_roles WHERE id = ?");
    $stmt->execute([$admin['role_id']]);
    $role = $stmt->fetch();
    $role_name = $role['name'] ?? "Custom Role";
}

// Get all logins
// --- PAGINATION LOGIC START ---
$items_per_page = 4;
$current_page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
if ($current_page < 1) $current_page = 1;

// 1. Get total count of sessions (excluding current one)
$countStmt = $pdo->prepare("SELECT COUNT(*) FROM admin_auth_sessions WHERE user_id = ? AND id != ?");
$countStmt->execute([$admin_id, $authData['session_id']]);
$total_records = $countStmt->fetchColumn();
$total_pages = ceil($total_records / $items_per_page);

// Adjust page if it exceeds total pages
if ($current_page > $total_pages && $total_pages > 0) {
    $current_page = $total_pages;
}
$offset = ($current_page - 1) * $items_per_page;

// 2. Get paginated sessions using bindValue for integer safety with LIMIT
$stmt = $pdo->prepare("SELECT * FROM admin_auth_sessions WHERE user_id = :uid AND id != :sid ORDER BY created_at DESC LIMIT :limit OFFSET :offset");
$stmt->bindValue(':uid', $admin_id);
$stmt->bindValue(':sid', $authData['session_id']);
$stmt->bindValue(':limit', $items_per_page, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$authSessions = $stmt->fetchAll();
// --- PAGINATION LOGIC END ---
?>

<div class="container">

    <h2 class="m-0"><i class="fas fa-user-cog me-2"></i>Admin Profile</h2>

    <div class="card shadow-sm my-4">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0"><i class="fas fa-info-circle me-2"></i>Account Information</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Name:</strong> <?= safe_htmlspecialchars($admin['full_name']) ?></p>
                    <p class="mb-0"><strong>Email:</strong> <span id="currentEmailShowSpan"><?= safe_htmlspecialchars($admin['email']) ?></span></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Admin Type:</strong> <?= safe_htmlspecialchars($role_name) ?></p>
                    <p class="mb-0"><strong>Account Status:</strong>
                        <span class="badge bg-<?= $admin['status'] == 'active' ? 'success' : 'danger' ?>">
                            <?= ucfirst($admin['status']) ?>
                        </span>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card shadow-sm my-4">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="fas fa-user-edit me-2"></i>Update Username</h4>
                </div>
                <div class="card-body">
                    <form id="updateUsernameForm" autocomplete="off">
                        <div class="mb-3">
                            <label for="currentUsernameShowInput" class="form-label">Current Username</label>
                            <input type="text" class="form-control" id="currentUsernameShowInput"
                                value="<?= safe_htmlspecialchars($admin['username']) ?>" readonly disabled>
                        </div>
                        <div class="mb-3">
                            <label for="newUsernameInput" class="form-label">New Username</label>
                            <input type="text" class="form-control" id="newUsernameInput" name="newUsernameInput"
                                minlength="3" maxlength="25" required>
                            <div class="form-text">Username must be 3-25 characters long</div>
                        </div>
                        <div class="mb-3">
                            <label for="confirm_password_input_for_username" class="form-label">Confirm Password</label>
                            <div class="input-group">
                                <input type="password" class="form-control" id="confirm_password_input_for_username"
                                    name="confirmPassword" required>
                                <button class="btn btn-outline-secondary toggle-password" type="button">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Update Username
                        </button>
                        <div id="usernameMessage" class="mt-2 small"></div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow-sm my-4">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="fas fa-key me-2"></i>Change Password</h4>
                </div>
                <div class="card-body">
                    <form id="updatePasswordForm" autocomplete="off">
                        <div class="mb-3">
                            <label for="current_password_input" class="form-label">Current Password</label>
                            <div class="input-group">
                                <input type="password" class="form-control" id="current_password_input"
                                    name="currentPassword" required>
                                <button class="btn btn-outline-secondary toggle-password" type="button">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="new_password_input" class="form-label">New Password</label>
                            <div class="input-group">
                                <input type="password" class="form-control" id="new_password_input"
                                    name="newPassword" minlength="6" required>
                                <button class="btn btn-outline-secondary toggle-password" type="button">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            <div class="form-text">Password must be at least 6 characters long</div>
                        </div>
                        <div class="mb-3">
                            <label for="confirm_new_password" class="form-label">Confirm New Password</label>
                            <div class="input-group">
                                <input type="password" class="form-control" id="confirm_new_password"
                                    name="confirmPassword" required>
                                <button class="btn btn-outline-secondary toggle-password" type="button">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Change Password
                        </button>
                        <div id="passwordMessage" class="mt-2 small"></div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow-sm my-4">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="fas fa-user-edit me-2"></i>User Information</h4>
                </div>
                <div class="card-body">
                    <form id="updateUserInfoForm" autocomplete="off">
                        <div class="mb-3">
                            <label for="adminName" class="form-label">Admin Name</label>
                            <input type="text" class="form-control" name="adminName" id="adminName"
                                value="<?= safe_htmlspecialchars($admin['full_name']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="loginEmail" class="form-label">Login Email</label>
                            <input type="email" class="form-control" name="loginEmail" id="loginEmail"
                                value="<?= safe_htmlspecialchars($admin['email']) ?>" <?=(isSuperAdmin() ? 'disabled' : '')?>>
                        </div>
                        <div class="mb-3">
                            <label for="confirm_password_input_for_userinfo" class="form-label">Confirm Password</label>
                            <div class="input-group">
                                <input type="password" class="form-control" id="confirm_password_input_for_userinfo"
                                    name="confirmPassword" required>
                                <button class="btn btn-outline-secondary toggle-password" type="button">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Update Now
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow-sm my-4">
                <div class="card-header bg-primary text-white d-flex justify-content-between">
                    <h4 class="mb-0"><i class="fas fa-user-edit me-2"></i>Logged Devices</h4>
                    <button type="button" class="btn btn-sm btn-light" onclick="logoutAll()" title="Logout from other devices">Logout All</button>
                </div>
                <div class="card-body">
                    <div class="table-responsive m-0">
                        <table class="table table-striped table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Device Name</th>
                                    <th>IP Address</th>
                                    <th>Activity</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($authSessions) > 0): ?>
                                    <?php foreach ($authSessions as $session): ?>
                                    <tr id="row_<?= $session['id'] ?>">
                                        <td class="align-middle" title="<?= safe_htmlspecialchars($session['device_name']) ?>">
                                            <span class="text-line-clamp-2"><?= safe_htmlspecialchars($session['device_name']) ?></span>
                                        </td>
                                        <td class="align-middle text-center">
                                            <a class="text-decoration-none" href="https://whatismyipaddress.com/ip/<?= safe_htmlspecialchars($session['ip_address']) ?>" target="_blank">
                                                <?= safe_htmlspecialchars($session['ip_address']) ?>
                                            </a>
                                        </td>
                                        <td class="align-middle text-center small">
                                            <?= safe_htmlspecialchars(date("d/m/y g:i A", strtotime($session['last_activity']))) ?>
                                        </td>
                                        <td class="align-middle text-center">
                                            <button type="button" title="Revoke Session" class="btn btn-sm btn-danger" onclick="revokeSession(<?= $session['id'] ?>)">
                                                <i class="fas fa-ban"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-center text-muted py-3">No other active sessions found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if ($total_pages > 1): ?>
                    <nav aria-label="Device navigation" class="mt-3">
                        <ul class="pagination justify-content-center mb-0">
                            <li class="page-item <?= ($current_page <= 1) ? 'disabled' : '' ?>">
                                <a class="page-link" href="?page=<?= $current_page - 1 ?>" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                            
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <li class="page-item <?= ($i == $current_page) ? 'active' : '' ?>">
                                    <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                                </li>
                            <?php endfor; ?>

                            <li class="page-item <?= ($current_page >= $total_pages) ? 'disabled' : '' ?>">
                                <a class="page-link" href="?page=<?= $current_page + 1 ?>" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Revoke all sessions except the current one
    function logoutAll() {
        Swal.fire({
            title: 'Are you sure?',
            text: "Do you really want to revoke access for all devices? The user will be logged out immediately.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, revoke it!',
            cancelButtonText: 'Cancel',
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-danger px-4 py-2',
                cancelButton: 'btn btn-primary px-4 py-2'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                // Show loading state while processing
                showLoadingAlert('Revoking all sessions', 'Processing...');

                $.ajax({
                    url: '<?= BASE_URL ?>/api/admin/auth/revoke-all-sessions.php',
                    type: 'POST',
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            showSuccessAlert(response.message);
                            setTimeout(function() {
                                window.location.reload();
                            }, 2000);
                        } else {
                            showErrorAlert(response.message);
                        }
                    },
                    error: function(e) {
                        showErrorAlert('An error occurred while processing your request.');
                        console.log(e);
                    }
                });
            }
        })
    }

    // Revoke session function
    function revokeSession(sessionId) {
        Swal.fire({
            title: 'Are you sure?',
            text: "Do you really want to revoke access for this device? The user will be logged out immediately.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, revoke it!',
            cancelButtonText: 'Cancel',
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-danger px-4 py-2',
                cancelButton: 'btn btn-primary px-4 py-2'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                // Show loading state while processing
                Swal.fire({
                    title: 'Processing...',
                    text: 'Revoking session access',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                $.ajax({
                    url: '../../api/admin/auth/revoke-session.php',
                    type: 'POST',
                    data: {
                        sessionId: sessionId
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            showSuccessAlert(response.message);
                            $('#row_' + sessionId).remove();
                            toastr.success(response.message);
                        } else {
                            showErrorAlert(response.message);
                            toastr.error(response.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                        showErrorAlert('An error occurred. Please try again.');
                    }
                });
            }
        });
    }

    $(document).ready(function() {
        
        // --- NEW: Toggle Password Visibility Logic ---
        $(document).on('click', '.toggle-password', function() {
            // Find the input field associated with this button
            const input = $(this).closest('.input-group').find('input');
            const icon = $(this).find('i');

            if (input.attr('type') === 'password') {
                input.attr('type', 'text');
                icon.removeClass('fa-eye').addClass('fa-eye-slash');
            } else {
                input.attr('type', 'password');
                icon.removeClass('fa-eye-slash').addClass('fa-eye');
            }
        });
        // ---------------------------------------------

        // Update Username Form Submission
        $('#updateUsernameForm').on('submit', function(e) {
            e.preventDefault();
            const form = $(this);
            const btn = form.find('button[type="submit"]');
            const originalBtnText = btn.html();

            btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Updating...');
            $('#usernameMessage').removeClass('text-success text-danger').html('');

            $.ajax({
                url: '../../api/admin/auth/update-admin-username.php',
                type: 'POST',
                data: {
                    newUsername: $('#newUsernameInput').val(),
                    confirmPassword: $('#confirm_password_input_for_username').val(),
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $('#usernameMessage').addClass('text-success').html(response.message);
                        $('#currentUsernameShowInput').val($('#newUsernameInput').val());
                        $('#newUsernameInput').val("")
                        $('#confirm_password_input_for_username').val("")
                        toastr.success(response.message);
                        showSuccessAlert(response.message);
                    } else {
                        $('#usernameMessage').addClass('text-danger').html(response.message);
                        toastr.error(response.message);
                        showErrorAlert(response.message);
                    }
                },
                error: function(e) {
                    $('#usernameMessage').addClass('text-danger').html('An error occurred. Please try again.');
                    toastr.error('An error occured. Please try again.');
                    showErrorAlert('An error occurred. Please try again.');
                    console.error(e.responseText);
                },
                complete: function() {
                    btn.prop('disabled', false).html(originalBtnText);
                }
            });
        });

        // Update Password Form Submission
        $('#updatePasswordForm').on('submit', function(e) {
            e.preventDefault();
            const form = $(this);
            const btn = form.find('button[type="submit"]');
            const originalBtnText = btn.html();

            // Validate password match
            if ($('#new_password_input').val() !== $('#confirm_new_password').val()) {
                $('#passwordMessage').addClass('text-danger').html('Passwords do not match');
                toastr.error('Passwords do not match');
                return;
            }

            btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Updating...');
            $('#passwordMessage').removeClass('text-success text-danger').html('');

            $.ajax({
                url: '../../api/admin/auth/update-admin-password.php',
                type: 'POST',
                data: form.serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $('#passwordMessage').addClass('text-success').html(response.message);
                        form.trigger('reset');
                        toastr.success(response.message);
                        showSuccessAlert(response.message);
                    } else {
                        $('#passwordMessage').addClass('text-danger').html(response.message);
                        toastr.error(response.message);
                        showErrorAlert(response.message);
                    }
                },
                error: function(e) {
                    $('#passwordMessage').addClass('text-danger').html('An error occurred. Please try again.');
                    toastr.error('An error occured. Please try again.');
                    console.error(e.responseText);
                    showErrorAlert('An error occurred. Please try again.');
                },
                complete: function() {
                    btn.prop('disabled', false).html(originalBtnText);
                }
            });
        });

        // Update User Info Form Submission
        $('#updateUserInfoForm').on('submit', function(e) {
            e.preventDefault();
            const form = $(this);
            const btn = form.find('button[type="submit"]');
            const originalBtnText = btn.html();

            btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Updating...');
            $('#passwordMessage').removeClass('text-success text-danger').html('');

            $.ajax({
                url: '../../api/admin/auth/update-userinfo.php',
                type: 'POST',
                data: form.serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        showSuccessAlert(response.message);
                    } else {
                        toastr.error(response.message);
                        showErrorAlert(response.message);
                    }
                },
                error: function(e) {
                    showErrorAlert('An error occurred. Please try again.');
                    toastr.error('An error occured. Please try again.');
                    console.error(e.responseText);
                },
                complete: function() {
                    btn.prop('disabled', false).html(originalBtnText);
                }
            });
        });

        // Remove all spaces from new username field
        $('#newUsernameInput').on('input', function() {
            $(this).val($(this).val().replace(/\s+/g, ''));
        });

    });
</script>

<?php include_once("../../includes/body-close.php"); ?>