<?php

/** @var string $school_name */
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Telegram Setup - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if (!isSuperAdmin()) {
    include_once("../../includes/permission-denied.php");
}

$stmt = $pdo->prepare("SELECT * FROM classes ORDER BY id ASC");
$stmt->execute();
$classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

$bot_token = $websiteConfig['telegram_bot_token'] ?? '';
?>

<div class="container mt-5">

    <form id="telegramSetupForm" action="" method="POST">

        <div class="card shadow border-0 mb-5">
            <div class="card-header bg-primary text-white py-3">
                <div class="d-flex justify-content-between align-items-center">
                    <h4 class="mb-0 fw-bold text-white"><i class="fa-brands fa-telegram"></i> Telegram Setup</h4>
                    <button type="submit" class="btn btn-sm btn-light"><i class="fas fa-save me-2"></i> Save Changes</button>
                </div>
            </div>
            <div class="card-body">

                <?php foreach ($classes as $class) : ?>

                    <div class="card border mb-4 rounded-4 overflow-hidden">
                        <div class="card-header bg-light text-primary py-3">
                            <h5 class="mb-0 fw-bold"><i class="fas fa-school me-2"></i> <?= $class['class_name']; ?></h5>
                        </div>
                        <div class="card-body">
                            <div class="row ">
                                <?php
                                $stmt = $pdo->prepare("SELECT * FROM sections WHERE class_id = :class_id");
                                $stmt->execute([':class_id' => $class['id']]);
                                $sections = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                foreach ($sections as $section) : ?>
                                    <div class="col-md-4 mb-3">
                                        <label for="chat_id" class="form-label fw-bold text-primary"><i class="fa-brands fa-telegram me-2"></i> Section <?= $section['section_name']; ?> Chat ID</label>
                                        <input type="text" class="form-control" name="chat_ids[<?= $section['id']; ?>]" value="<?= $section['telegram_chat_id'] ?? '' ?>" placeholder="Telegram Chat ID">
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>

                <?php endforeach; ?>

                <!-- Add Save Changes Button Here too -->
                 <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save me-2"></i> Save Changes</button>
                </div>
            </div>
        </div>

    </form>
</div>

<script>
    $(document).ready(function() {
        $('#telegramSetupForm').on('submit', function(e) {
            e.preventDefault(); // ফর্মের ডিফল্ট সাবমিশন বন্ধ করবে

            // সাবমিট বাটনে লোডিং স্টেট দেখানোর জন্য (ঐচ্ছিক)
            let submitButtons = $(this).find('button[type="submit"]');
            let originalText = submitButtons.first().html();
            submitButtons.html('<i class="fas fa-spinner fa-spin me-2"></i> Saving...');
            submitButtons.prop('disabled', true);

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/put/website-config/save-telegram-setup.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response) {
                    if(response.success) {
                        showSuccessAlert(response.message);
                    } else {
                        showErrorAlert(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    showErrorAlert('An error occurred: ' + error);
                    console.error(xhr.responseText);
                },
                complete: function() {
                    // সাবমিট বাটন আগের অবস্থায় ফিরিয়ে আনা
                    submitButtons.html(originalText);
                    submitButtons.prop('disabled', false);
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>