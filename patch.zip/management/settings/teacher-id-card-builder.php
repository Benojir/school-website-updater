<?php
// Use the complete Fabric editor with teacher fields and a separate template library.
define('ID_CARD_AUDIENCE', 'teacher');
require __DIR__ . '/student-id-card-builder.php';
