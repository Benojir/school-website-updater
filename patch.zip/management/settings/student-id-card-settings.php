<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>ID Cards Styles - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if (!isSuperAdmin()) {
    include_once("../../includes/permission-denied.php");
}

$available_designs = ["design-1"];

$current_design = $available_designs[0];
$school_address = $schoolInfo['address'];
$school_contacts = "";
$default_colors = [
    'school_name' => '#FFFFFF',
    'school_address' => '#FFFFFF',
    'school_contacts' => '#FFFFFF',
    'student_name' => '#FFFFFF',
    'details_title' => '#0B3C5D',
    'details_data' => '#333333',
    'student_address_title' => '#FFFFFF',
    'student_address_data' => '#FFFFFF',
];
$colors = $default_colors;

$stmt = $pdo->query("SELECT * FROM student_id_card_settings LIMIT 1");
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if ($row) {
    $current_design = (isset($row["template"]) && !empty($row["template"])) ? $row["template"] : $available_designs[0];
    $school_address = (isset($row["school_address"]) && !empty($row["school_address"])) ? $row["school_address"] : $schoolInfo['address'];
    $school_contacts = (isset($row["school_contacts"]) && !empty($row["school_contacts"])) ? $row["school_contacts"] : "";
    $colors = (isset($row["colors"]) && !empty($row["colors"])) ? json_decode($row["colors"], true) : $default_colors;
}
?>

<div class="container mt-5">
    <div class="card shadow m-0 p-0">
        <div class="card-header bg-primary text-white py-3 d-flex justify-content-between align-items-center">
            <h4 class="card-title p-0 m-0"><i class="fas fa-id-card me-2"></i> Student ID Cards Settings</h4>

            <!-- Dropdown Button -->
            <div class="dropdown">
                <button class="btn btn-light btn-sm text-primary shadow-sm dropdown-toggle" type="button"
                    data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-ellipsis-v me-1"></i> More
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#previewModal">
                            <i class="fas fa-eye me-2"></i> Live Preview
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#backgroundModal">
                            <i class="fas fa-image me-2"></i> Stock Background Image
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="card-body">
            <form id="idCardSettingsForm" enctype="multipart/form-data">

                <h5 class="text-primary border-bottom pb-2 mb-3"><i class="fas fa-palette me-2"></i>Design & Assets</h5>
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label for="idDesignLayout" class="form-label fw-bold">Select Layout Design</label>
                        <select class="form-select" id="idDesignLayout" name="id_design_layout">
                            <?php
                            foreach ($available_designs as $design) {
                                $selected = ($design == $current_design) ? "selected" : "";
                                echo '<option value="' . $design . '" ' . $selected . '>' . ucwords(str_replace("-", " Layout ", $design)) . '</option>';
                            }
                            ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="bgImage" class="form-label fw-bold">ID Card Background Image</label>
                        <div class="input-group">
                            <input type="file" class="form-control" id="bgImage" name="id_card_bg_image" accept="image/*">
                        </div>
                        <div class="form-text text-primary">Required Ratio: 55mm (W) x 85mm (H) | Max Size: 5MB</div>
                    </div>
                </div>

                <h5 class="text-primary border-bottom pb-2 mb-3"><i class="fas fa-align-left me-2"></i>Card Text Content</h5>
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label for="schoolAddress" class="form-label fw-bold">School Address (on Card)</label>
                        <input type="text" class="form-control" id="schoolAddress" name="school_address_on_card" value="<?= htmlspecialchars($school_address) ?>" placeholder="e.g. 123 Education Lane, Cityville">
                    </div>

                    <div class="col-md-6">
                        <label for="schoolContacts" class="form-label fw-bold">School Contacts</label>
                        <input type="text" class="form-control" id="schoolContacts" name="school_contacts_on_card" value="<?= htmlspecialchars($school_contacts) ?>" placeholder="e.g. Ph: +1 234 567 890 | Web: www.school.com">
                    </div>
                </div>

                <h5 class="text-primary border-bottom pb-2 mb-3"><i class="fas fa-fill-drip me-2"></i>Color Configuration</h5>

                <div class="row g-3 mb-4">
                    <?php
                    $fields = [
                        'school_name' => 'School Name',
                        'school_address' => 'School Address',
                        'school_contacts' => 'School Contacts',
                        'student_name' => 'Student Name',
                        'details_title' => 'Details Title (Label)',
                        'details_data' => 'Details Data (Value)',
                        'student_address_title' => 'Student Addr. Title',
                        'student_address_data' => 'Student Addr. Data'
                    ];

                    foreach ($fields as $key => $label):
                    ?>
                        <div class="col-md-3 col-6">
                            <label class="form-label small fw-bold"><?= $label ?></label>
                            <div class="input-group">
                                <input type="color" class="form-control form-control-color" id="color_<?= $key ?>" name="color_<?= $key ?>" value="<?= $colors[$key] ?? '#000000' ?>" title="Choose color">
                                <input type="text" class="form-control" value="<?= $colors[$key] ?? '#000000' ?>" readonly>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="d-grid gap-2 d-md-flex justify-content-md-end border-top pt-3">
                    <button type="submit" name="save_id_settings" class="btn btn-primary px-4">
                        <i class="fas fa-save me-2"></i> Save Settings
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

        // Sync Color Input with Text Input
        $('.form-control-color').on('input change', function() {
            var colorVal = $(this).val().toUpperCase();
            $(this).next('input').val(colorVal);
        });

        // Form Submission Logic
        $('#idCardSettingsForm').on('submit', function(e) {
            e.preventDefault();

            // 1. Get the form data
            var form = this;
            var formData = new FormData(form);
            var fileInput = $('#bgImage')[0];

            // 2. Client Side Validation Logic
            if (fileInput.files.length > 0) {
                var file = fileInput.files[0];

                // Check Size (5MB)
                if (file.size > 5 * 1024 * 1024) {
                    showErrorAlert("The uploaded image exceeds the 5MB limit.", "File Too Large");
                    return;
                }

                // Check Image Ratio (Asynchronous check)
                var img = new Image();
                var _URL = window.URL || window.webkitURL;
                img.src = _URL.createObjectURL(file);

                img.onload = function() {
                    var width = this.width;
                    var height = this.height;
                    var ratio = width / height;
                    var targetRatio = 11 / 17; // Approx 0.647

                    // Allow a small tolerance of 0.02
                    if (Math.abs(ratio - targetRatio) > 0.02) {
                        showErrorAlert("The image ratio must be approximately 11:17 (e.g., 55mm Width x 85mm Height).<br>Current dimensions: " + width + "x" + height, "Invalid Ratio");
                    } else {
                        // Ratio passed, proceed to submit
                        submitForm(formData);
                    }
                };

                img.onerror = function() {
                    showErrorAlert("The file uploaded is not a valid image.", "Invalid File");
                };

            } else {
                // No file uploaded, just submit text data
                submitForm(formData);
            }
        });

        function submitForm(formData) {
            showLoadingAlert();

            $.ajax({
                url: '../../api/admin/put/website-config/save-student-id-card-settings.php',
                type: 'POST',
                data: formData,
                contentType: false, // Required for FormData
                processData: false, // Required for FormData
                dataType: 'json',
                success: function(response) {
                    Swal.close(); // Close loading
                    if (response.success) {
                        showSuccessAlert(response.message, "Saved!");
                    } else {
                        showErrorAlert(response.message, "Error");
                    }
                },
                error: function(xhr, status, error) {
                    Swal.close();
                    showErrorAlert("An unexpected system error occurred: " + error, "System Error");
                }
            });
        }
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>