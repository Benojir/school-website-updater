<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>ID Cards Styles - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if (!isSuperAdmin()) {
   include_once("../../includes/permission-denied.php");
}
?>

<div class="container mt-5">
    <div class="card shadow m-0 p-0">
        <div class="card-header bg-primary text-white py-3">
            <h4 class="card-title p-0 m-0"><i class="fas fa-id-card me-2"></i> Student ID Cards Settings</h4>
        </div>
        <div class="card-body">
            
        </div>
    </div>
</div>

<?php include_once("../../includes/body-close.php"); ?>