<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>ID Cards Styles - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if (!isSuperAdmin()) {
   include_once("../../includes/permission-denied.php");
}
?>

<div class="container mt-5">
    <div class="card shadow m-0 p-0">
        <div class="card-header bg-primary text-white py-3 d-flex justify-content-between align-items-center">
            <h4 class="card-title p-0 m-0"><i class="fas fa-id-card me-2"></i> Student ID Cards Settings</h4>
            <button type="button" class="btn btn-light btn-sm text-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#previewModal">
                <i class="fas fa-eye me-1"></i> Live Preview
            </button>
        </div>
        <div class="card-body">
            <form action="process-id-card-settings.php" method="POST" enctype="multipart/form-data">
                
                <h5 class="text-primary border-bottom pb-2 mb-3"><i class="fas fa-palette me-2"></i>Design & Assets</h5>
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label for="idDesignLayout" class="form-label fw-bold">Select Layout Design</label>
                        <select class="form-select" id="idDesignLayout" name="id_design_layout">
                            <option value="design_1">Design Layout 1 (Standard)</option>
                            <option value="design_2">Design Layout 2 (Modern)</option>
                            <option value="design_3">Design Layout 3 (Minimal)</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="bgImage" class="form-label fw-bold">ID Card Background Image</label>
                        <div class="input-group">
                            <input type="file" class="form-control" id="bgImage" name="id_card_bg_image" accept="image/*">
                            <button class="btn btn-outline-secondary" type="button" id="btnStockBg">
                                <i class="fas fa-images me-1"></i> Stock Backgrounds
                            </button>
                        </div>
                        <div class="form-text">Recommended size: 85mm x 55mm (Standard ID size)</div>
                    </div>
                </div>

                <h5 class="text-primary border-bottom pb-2 mb-3"><i class="fas fa-align-left me-2"></i>Card Text Content</h5>
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label for="schoolAddress" class="form-label fw-bold">School Address (on Card)</label>
                        <input type="text" class="form-control" id="schoolAddress" name="school_address_on_card" placeholder="e.g. 123 Education Lane, Cityville">
                    </div>

                    <div class="col-md-6">
                        <label for="schoolContacts" class="form-label fw-bold">School Contacts</label>
                        <input type="text" class="form-control" id="schoolContacts" name="school_contacts_on_card" placeholder="e.g. Ph: +1 234 567 890 | Web: www.school.com">
                    </div>
                </div>

                <h5 class="text-primary border-bottom pb-2 mb-3"><i class="fas fa-fill-drip me-2"></i>Color Configuration</h5>
                
                <div class="row g-3 mb-4">
                    <div class="col-md-3 col-6">
                        <label class="form-label small fw-bold">School Name</label>
                        <div class="input-group">
                            <input type="color" class="form-control form-control-color" id="colorSchoolName" name="color_school_name" value="#000000" title="Choose color">
                            <input type="text" class="form-control" value="#000000" readonly>
                        </div>
                    </div>

                    <div class="col-md-3 col-6">
                        <label class="form-label small fw-bold">School Address</label>
                        <div class="input-group">
                            <input type="color" class="form-control form-control-color" id="colorSchoolAddress" name="color_school_address" value="#333333" title="Choose color">
                            <input type="text" class="form-control" value="#333333" readonly>
                        </div>
                    </div>

                    <div class="col-md-3 col-6">
                        <label class="form-label small fw-bold">Student Name</label>
                        <div class="input-group">
                            <input type="color" class="form-control form-control-color" id="colorStudentName" name="color_student_name" value="#0d6efd" title="Choose color">
                            <input type="text" class="form-control" value="#0d6efd" readonly>
                        </div>
                    </div>

                     <div class="col-md-3 col-6">
                        <label class="form-label small fw-bold">Details Title (Label)</label>
                        <div class="input-group">
                            <input type="color" class="form-control form-control-color" id="colorDetailsTitle" name="color_details_title" value="#555555" title="Choose color">
                            <input type="text" class="form-control" value="#555555" readonly>
                        </div>
                    </div>

                    <div class="col-md-3 col-6">
                        <label class="form-label small fw-bold">Details Data (Value)</label>
                        <div class="input-group">
                            <input type="color" class="form-control form-control-color" id="colorDetailsData" name="color_details_data" value="#000000" title="Choose color">
                            <input type="text" class="form-control" value="#000000" readonly>
                        </div>
                    </div>

                    <div class="col-md-3 col-6">
                        <label class="form-label small fw-bold">Student Addr. Title</label>
                        <div class="input-group">
                            <input type="color" class="form-control form-control-color" id="colorStdAddrTitle" name="color_student_address_title" value="#555555" title="Choose color">
                            <input type="text" class="form-control" value="#555555" readonly>
                        </div>
                    </div>

                    <div class="col-md-3 col-6">
                        <label class="form-label small fw-bold">Student Addr. Data</label>
                        <div class="input-group">
                            <input type="color" class="form-control form-control-color" id="colorStdAddr" name="color_student_address" value="#000000" title="Choose color">
                            <input type="text" class="form-control" value="#000000" readonly>
                        </div>
                    </div>
                </div>

                <div class="d-grid gap-2 d-md-flex justify-content-md-end border-top pt-3">
                    <button type="button" class="btn btn-light me-md-2">Default</button>
                    <button type="submit" name="save_id_settings" class="btn btn-success px-4">
                        <i class="fas fa-save me-2"></i> Save Settings
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('.form-control-color').on('input change', function() {
        var colorVal = $(this).val().toUpperCase();
        $(this).next('input').val(colorVal);
    });
});
</script>

<?php include_once("../../includes/body-close.php"); ?>