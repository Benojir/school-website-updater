<?php
// Use the complete Fabric editor with driver fields and an independent library.
define('ID_CARD_AUDIENCE', 'driver');
require __DIR__ . '/student-id-card-builder.php';
