<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
/** @var string $school_name */
echo "<title>Marksheet Settings - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if (!hasPermission(PERM_MANAGE_RESULTS) && !hasPermission(PERM_MANAGE_EXAMS)) {
    include_once("../../includes/permission-denied.php");
}

// Fetch all marksheet settings from database
$stmt = $pdo->query("SELECT * FROM settings_marksheet LIMIT 1");
$marksheet_settings = $stmt->fetch();

if (!$marksheet_settings) {
    echo "<div class='container'><div class='alert alert-danger'>No marksheet settings found. Please add some.</div></div>";
    exit();
}

// Settings default colors
$default_theme_color_primary = '#3a4a6d';
$default_theme_color_dark = '#2b3a5a';
$default_theme_color_light = '#F0F5FF';
$default_background_color = '#FFFFFF';
$default_school_name_color = '#EFF0F2';
$default_school_address_color = '#333333';

$theme_color_primary = $marksheet_settings['primary_theme_color'] ?? $default_theme_color_primary;
$theme_color_dark = $marksheet_settings['dark_theme_color'] ?? $default_theme_color_dark;
$theme_color_light = $marksheet_settings['light_theme_color'] ?? $default_theme_color_light;
$background_color = $marksheet_settings['background_color'] ?? $default_background_color;
$school_name_color = $marksheet_settings['school_name_text_color'] ?? $default_school_name_color;
$school_address_color = $marksheet_settings['school_address_text_color'] ?? $default_school_address_color;

$fast_generation = $marksheet_settings['fast_generation'] ?? 0;
$make_overall_average = $marksheet_settings['make_overall_average'] ?? 0;
$include_minor_subjects_marks = $marksheet_settings['include_minor_subjects_marks'] ?? 0;
$show_text_watermark = $marksheet_settings['show_text_watermark'] ?? 0;
$section_based_ranking = $marksheet_settings['section_based_ranking'] ?? 0;
$hide_top_rankers = $marksheet_settings['hide_top_rankers'] ?? 0;
$hide_position_in_class = $marksheet_settings['hide_position_in_class'] ?? 0;

// Get available marksheet systems
// $marksheet_systems = ['system-1', 'system-2', 'system-3'];
// $current_marksheet_system = $marksheet_settings['marksheet_system'] ?? 'system-1';

$single_marksheet_preview_path = BASE_URL . "/assets/img/preview/marksheet/single/";
$combined_marksheet_preview_path = BASE_URL . "/assets/img/preview/marksheet/combined/";

// Get current selection
$current_style_single = $marksheet_settings['single_marksheet_design'] ?? 'design-1';
$current_style_combined = $marksheet_settings['combined_marksheet_design'] ?? 'design-1';
?>

<div class="container py-5 px-0">
    <div class="row justify-content-center mx-0">
        <div class="col-lg-12">
            <div class="card shadow-lg border-0 rounded-3 overflow-hidden">
                <div class="card-header bg-primary text-white py-3">
                    <div class="d-flex align-items-center justify-content-left">
                        <i class="fas fa-file-alt fa-2x me-3"></i>
                        <h4 class="mb-0">Marksheet Settings</h4>
                    </div>
                </div>
                <div class="card-body p-4 p-md-5">
                    <form id="marksheets_settings_form">
                        <div class="row mx-0">
                            <div class="col-md-6 row mx-0 mb-2">
                                <div class="col-md-12">
                                    <h5 class="fw-bold pb-2 text-primary text-center">
                                        <i class="fas fa-file-alt me-2"></i>Single Marksheet Design
                                    </h5>
                                </div>

                                <div class="col-md-12 mb-3 d-flex justify-content-center">
                                    <select
                                        name="single_marksheet_design"
                                        class="form-control w-75 border border-primary border-2 rounded-3"
                                        onchange="updatePreviewImgTag('single')">
                                    </select>
                                </div>

                                <div class="col-md-12 d-flex justify-content-center mb-3">
                                    <img
                                        src=""
                                        alt="Single Marksheet Template"
                                        class="img-fluid border border-primary border-2 rounded-3 w-75"
                                        id="single_marksheet_preview"
                                        data-fancybox="marksheet"
                                        data-caption="Single Marksheet Template"
                                        onerror="if (this.src.indexOf('design-1.jpg') === -1) { this.src = '<?= $single_marksheet_preview_path ?>design-1.jpg'; }" />
                                </div>
                            </div>

                            <div class="col-md-6 row mx-0 mb-3">
                                <div class="col-md-12 mb-2">
                                    <h5 class="fw-bold pb-2 text-primary text-center">
                                        <i class="fas fa-file-alt me-2"></i>Combined Marksheet Design
                                    </h5>
                                </div>

                                <div class="col-md-12 mb-3 d-flex justify-content-center">
                                    <select
                                        name="combined_marksheet_design"
                                        class="form-control w-75 border border-primary border-2 rounded-3"
                                        onchange="updatePreviewImgTag('combined')">
                                    </select>
                                </div>

                                <div class="col-md-12 d-flex justify-content-center mb-3">
                                    <img
                                        src=""
                                        alt="Combined Marksheet Template"
                                        class="img-fluid border border-primary border-2 rounded-3 w-75"
                                        id="combined_marksheet_preview"
                                        data-fancybox="marksheet"
                                        data-caption="Combined Marksheet Template" />
                                </div>
                            </div>
                        </div>

                        <div class="row mx-0">

                            <hr class="my-3">

                            <div class="col-md-6 row mx-0 mt-3">
                                <div class="col-md-12">
                                    <h5 class="fw-bold pb-2 text-primary text-center">
                                        <i class="fa-solid fa-paintbrush me-2"></i>Theme Color (Primary)
                                    </h5>
                                </div>

                                <div class="col-md-12">
                                    <div class="color-picker-container p-4 bg-light rounded-3 shadow-sm">
                                        <input type="color" class="form-control form-control-color w-100"
                                            name="theme_color_primary" value="<?= safe_htmlspecialchars($theme_color_primary) ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 row mx-0 mt-3">
                                <div class="col-md-12">
                                    <h5 class="fw-bold pb-2 text-primary text-center">
                                        <i class="fa-solid fa-paintbrush me-2"></i>Theme Color (Dark)
                                    </h5>
                                </div>

                                <div class="col-md-12">
                                    <div class="color-picker-container p-4 bg-light rounded-3 shadow-sm">
                                        <input type="color" class="form-control form-control-color w-100"
                                            name="theme_color_dark" value="<?= safe_htmlspecialchars($theme_color_dark) ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 row mx-0 mt-3">
                                <div class="col-md-12">
                                    <h5 class="fw-bold pb-2 text-primary text-center">
                                        <i class="fa-solid fa-paintbrush me-2"></i>Theme Color (Light)
                                    </h5>
                                </div>

                                <div class="col-md-12">
                                    <div class="color-picker-container p-4 bg-light rounded-3 shadow-sm">
                                        <input type="color" class="form-control form-control-color w-100"
                                            name="theme_color_light" value="<?= safe_htmlspecialchars($theme_color_light) ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 row mx-0 mt-3">
                                <div class="col-md-12">
                                    <h5 class="fw-bold pb-2 text-primary text-center">
                                        <i class="fa-solid fa-paintbrush me-2"></i>Background Color
                                    </h5>
                                </div>

                                <div class="col-md-12">
                                    <div class="color-picker-container p-4 bg-light rounded-3 shadow-sm">
                                        <input type="color" class="form-control form-control-color w-100"
                                            name="marksheet_background_color" value="<?= safe_htmlspecialchars($background_color) ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 row mx-0 mt-3">
                                <div class="col-md-12">
                                    <h5 class="fw-bold pb-2 text-primary text-center">
                                        <i class="fa-solid fa-paintbrush me-2"></i>School Name Color
                                    </h5>
                                </div>

                                <div class="col-md-12">
                                    <div class="color-picker-container p-4 bg-light rounded-3 shadow-sm">
                                        <input type="color" class="form-control form-control-color w-100"
                                            name="school_name_color" value="<?= safe_htmlspecialchars($school_name_color) ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 row mx-0 mt-3">
                                <div class="col-md-12">
                                    <h5 class="fw-bold pb-2 text-primary text-center">
                                        <i class="fa-solid fa-paintbrush me-2"></i>School Address Text Color
                                    </h5>
                                </div>

                                <div class="col-md-12">
                                    <div class="color-picker-container p-4 bg-light rounded-3 shadow-sm">
                                        <input type="color" class="form-control form-control-color w-100"
                                            name="school_address_text_color" value="<?= safe_htmlspecialchars($school_address_color) ?>">
                                    </div>
                                </div>
                            </div>

                            <hr class="my-3">

                            <div class="col-md-6 row mx-0 mt-3">
                                <div class="col-md-12">
                                    <h5 class="fw-bold pb-2 text-primary">
                                        <i class="fa-solid fa-gears me-2"></i>Additional Options
                                    </h5>
                                </div>

                                <div class="col-md-12">
                                    <input type="checkbox" id="fast_download_marksheets" class="form-control-check me-1" name="fast_download_marksheets" <?= ($fast_generation == 1 ? "checked" : "") ?>>
                                    <label for="fast_download_marksheets" class="form-label">Generate marksheets as fast as possible</label>
                                </div>

                                <div class="col-md-12">
                                    <input type="checkbox" id="make_overall_table_average" class="form-control-check me-1" name="make_overall_table_average" <?= ($make_overall_average == 1 ? "checked" : "") ?>>
                                    <label for="make_overall_table_average" class="form-label">Make overall table average</label>
                                </div>

                                <div class="col-md-12">
                                    <input type="checkbox" id="include_minor_subjects_marks" class="form-control-check me-1" name="include_minor_subjects_marks" <?= ($include_minor_subjects_marks == 1 ? "checked" : "") ?>>
                                    <label for="include_minor_subjects_marks" class="form-label">Add minor subjects marks with total</label>
                                </div>

                                <div class="col-md-12">
                                    <input type="checkbox" id="hide_top_rankers" class="form-control-check me-1" name="hide_top_rankers" <?= ($hide_top_rankers == 1 ? "checked" : "") ?>>
                                    <label for="hide_top_rankers" class="form-label">Hide top rankers and show QR instead</label>
                                </div>

                                <div class="col-md-12">
                                    <input type="checkbox" id="hide_position_in_class" class="form-control-check me-1" name="hide_position_in_class" <?= ($hide_position_in_class == 1 ? "checked" : "") ?>>
                                    <label for="hide_position_in_class" class="form-label">Hide position in class</label>
                                </div>

                                <div class="col-md-12">
                                    <input type="checkbox" id="show_text_watermark" class="form-control-check me-1" name="show_text_watermark" <?= ($show_text_watermark == 1 ? "checked" : "") ?>>
                                    <label for="show_text_watermark" class="form-label">Show school name watermark <span class="badge bg-primary rounded-pill py-1 px-2">Experimental</span></label>
                                </div>

                                <div class="col-md-12">
                                    <input type="checkbox" id="section_based_ranking" class="form-control-check me-1" name="section_based_ranking" <?= ($section_based_ranking == 1 ? "checked" : "") ?>>
                                    <label for="section_based_ranking" class="form-label">Section based ranking</label>
                                </div>
                            </div>

                            <div class="col-md-6 row mx-0 mt-3">
                                <div class="col-md-12">
                                    <h5 class="fw-bold pb-2 text-primary">
                                        <i class="fa-solid fa-gears me-2"></i>Configure Subjects
                                    </h5>
                                </div>

                                <div class="col-md-6">
                                    <select class="form-select" name="class_id" id="classDropdown">

                                    </select>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <button type="button" class="btn btn-outline-dark w-100" data-bs-toggle="modal" data-bs-target="#subjectSortModal">
                                        <i class="fas fa-sort me-2"></i>Configure Subject Order
                                    </button>
                                </div>
                            </div>

                            <div class="col-md-12 d-flex justify-content-center gap-3 mt-5">
                                <button class="btn btn-outline-primary" type="button" onclick="setDefaultValues()"><i class="fas fa-history me-2"></i>Set Default Colors</button>
                                <button class="btn btn-primary" type="submit" id="save_btn"><i class="fas fa-save me-2"></i>Save Changes</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="subjectSortModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow-lg">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-list-ol me-2"></i>Reorder Subjects</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <div class="alert alert-info m-3 py-2"><small>Drag and drop items to reorder how they appear on marksheets.</small></div>
                <ul id="subject-sort-list" class="list-group list-group-flush" style="max-height: 400px; overflow-y: auto;">
                    <li class="list-group-item text-center py-4"><i class="fas fa-spinner fa-spin"></i> Loading...</li>
                </ul>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="save_subject_order_btn">Save Order</button>
            </div>
        </div>
    </div>
</div>

<style>
    .rounded-4 {
        border-radius: 1rem !important;
    }

    .btn-primary {
        transition: all 0.3s ease;
    }

    .btn-primary:hover {
        background-color: #0b5ed7;
        border-color: #0b5ed7;
        transform: translateY(-2px);
        box-shadow: 0 4px 15px rgba(13, 110, 253, 0.4) !important;
    }
</style>

<script>
    // Function to set default values
    function setDefaultValues() {
        $('[name="theme_color_primary"]').val('<?= $default_theme_color_primary ?>');
        $('[name="theme_color_dark"]').val('<?= $default_theme_color_dark ?>');
        $('[name="theme_color_light"]').val('<?= $default_theme_color_light ?>');
        $('[name="marksheet_background_color"]').val('<?= $default_background_color ?>');
        $('[name="school_name_color"]').val('<?= $default_school_name_color ?>');
        $('[name="school_address_text_color"]').val('<?= $default_school_address_color ?>');
    }

    function updateMarksheetDesignSelectors() {
        let single_options = ['design-1', 'design-2', 'design-3'];
        let combined_options = ['design-1', 'design-2', 'design-3'];

        let single_marksheet_design_options = single_options.map(option => `
            <option value="${option}" ${'<?= $current_style_single ?>' === option ? 'selected' : ''}>
                ${option.replace("-", " ").toUpperCase()}
            </option>
        `).join('');

        let combined_marksheet_design_options = combined_options.map(option => `
            <option value="${option}" ${'<?= $current_style_combined ?>' === option ? 'selected' : ''}>
                ${option.replace("-", " ").toUpperCase()}
            </option>
        `).join('');

        $('select[name="single_marksheet_design"]').html(single_marksheet_design_options);
        $('select[name="combined_marksheet_design"]').html(combined_marksheet_design_options);
    }

    // Function to change single marksheet items
    function updatePreviewImgTag(marksheet_type) {
        let designSelector = null;
        let livePreviewImg = null;
        let marksheetPreviewPath = null;

        if (marksheet_type == "single") {
            designSelector = $('select[name="single_marksheet_design"]');
            livePreviewImg = $('#single_marksheet_preview');
            marksheetPreviewPath = '<?= $single_marksheet_preview_path ?>' + '/';
        } else if (marksheet_type == "combined") {
            designSelector = $('select[name="combined_marksheet_design"]');
            livePreviewImg = $('#combined_marksheet_preview');
            marksheetPreviewPath = '<?= $combined_marksheet_preview_path ?>' + '/';
        } else {
            return;
        }

        let selectedDesign = designSelector.val();
        livePreviewImg.attr('src', `${marksheetPreviewPath}${selectedDesign}.jpg`);
    }

    // Function to submit form data via ajax
    function submitForm() {
        let formData = new FormData($('#marksheets_settings_form')[0]);

        $.ajax({
            url: '<?= BASE_URL ?>/api/admin/put/website-config/save-marksheets-settings.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json', // 👈 Important: Expect JSON response
            beforeSend: function() {
                showLoadingAlert();
            },
            success: function(response) {
                Swal.close(); // close loading
                if (response.success) {
                    Swal.fire({
                        title: 'Success!',
                        text: response.message || 'Settings saved successfully.',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        customClass: {
                            popup: "rounded-4 shadow-lg",
                            confirmButton: "btn btn-success px-4 py-2"
                        }
                    });
                    toastr.success(response.message);
                } else {
                    Swal.fire({
                        title: 'Error!',
                        text: response.message || 'Error saving settings. Please try again.',
                        icon: 'error',
                        confirmButtonText: 'OK',
                        customClass: {
                            popup: "rounded-4 shadow-lg",
                            confirmButton: "btn btn-danger px-4 py-2"
                        }
                    });
                    toastr.error(response.message);
                }
            },
            error: function(e) {
                Swal.close();
                Swal.fire({
                    title: 'Request Failed!',
                    text: 'Something went wrong while connecting to the server.',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    customClass: {
                        popup: "rounded-4 shadow-lg",
                        confirmButton: "btn btn-danger px-4 py-2"
                    }
                });
                toastr.error('An error occurred.');
                console.error(e);
                let errorMessage = "Page: " + window.location.href + "\n\n" + e.responseText;
                sendErrorReport(errorMessage);
            }
        });
    }

    // Function load classes
    function loadClassesForDropdown() {
        $.ajax({
            url: '<?= BASE_URL ?>/api/admin/get/class/get-all-classes.php',
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    let classes = response.data;
                    let classDropdown = $('#classDropdown');
                    classDropdown.empty();
                    classDropdown.append(`<option value="" selected disabled>Select Class</option>`);
                    classes.forEach(function(classItem) {
                        classDropdown.append(`<option value="${classItem.id}">${classItem.name}</option>`);
                    });
                    classDropdown.val('');
                } else {
                    toastr.error(response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                toastr.error('An error occurred.');
            }
        })
    }

    $(document).ready(function() {

        loadClassesForDropdown();
        updateMarksheetDesignSelectors();
        updatePreviewImgTag("single");
        updatePreviewImgTag("combined");

        $('select[name="marksheet_system"]').change(function() {
            updateMarksheetDesignSelectors();
            updatePreviewImgTag("single");
            updatePreviewImgTag("combined");
        });

        // Submit form on button click
        $('#marksheets_settings_form').on('submit', function(e) {
            e.preventDefault();
            submitForm();
        });

        // 1. Fetch subjects when Modal Opens
        // const subjectModal = document.getElementById('subjectSortModal');
        $("#subjectSortModal").on('show.bs.modal', function() {
            const listContainer = document.getElementById('subject-sort-list');
            listContainer.innerHTML = '<li class="list-group-item text-center py-4"><i class="fas fa-spinner fa-spin"></i> Loading...</li>';

            let classId = $('#classDropdown').val();

            if (!classId) {
                listContainer.innerHTML = '<li class="list-group-item text-center py-4 text-danger">Please select a class first.</li>';
                return;
            }

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/get/subject/get-subjects-for-listing.php?page=1&limit=100&order_by=marksheet_order_asc&class_id=' + classId,
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        listContainer.innerHTML = '';
                        response.subjects.forEach(function(sub) {
                            let badgeColor = sub.subject_type === 'Main' ? 'bg-success' : 'bg-warning text-dark';
                            let item = `
                            <li class="list-group-item d-flex justify-content-between align-items-center" data-id="${sub.id}" style="cursor: move;">
                                <span><i class="fas fa-grip-vertical text-muted me-3"></i>${sub.subject_name}</span>
                                <span class="badge ${badgeColor} rounded-pill">${sub.subject_type}</span>
                            </li>
                        `;
                            listContainer.innerHTML += item;
                        });

                        // Initialize SortableJS
                        new Sortable(listContainer, {
                            animation: 150,
                            ghostClass: 'bg-light'
                        });
                    } else {
                        listContainer.innerHTML = '<li class="list-group-item text-danger">Error loading subjects.</li>';
                    }
                }
            });
        });

        // 2. Save new Order
        $('#save_subject_order_btn').click(function() {
            const listItems = document.querySelectorAll('#subject-sort-list li');
            let orderIds = [];

            listItems.forEach((li) => {
                if (li.getAttribute('data-id')) orderIds.push(li.getAttribute('data-id'));
            });

            if (orderIds.length === 0) {
                return;
            }

            $(this).prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Saving...');

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/put/subject/save-subject-order-for-marksheet.php',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({
                    order: orderIds
                }),
                success: function(response) {
                    $('#save_subject_order_btn').prop('disabled', false).html('Save Order');
                    if (response.success) {
                        showSuccessAlert('Subject order updated.');
                        $('#subjectSortModal').modal('hide');
                    } else {
                        toastr.error('Failed to save order.');
                    }
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>