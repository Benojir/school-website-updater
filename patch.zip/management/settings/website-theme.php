<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Customize School Website Theme (Front Side) - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if (!isSuperAdmin()) {
   include_once("../../includes/permission-denied.php");
}

// Get current theme color
$currentColor = $theme_color ?? '#007bff'; // Default color
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-lg border-0 rounded-4 overflow-hidden">
                <div class="card-header bg-gradient-primary text-white py-4" style="--bs-bg-opacity: 1; background-color: <?= safe_htmlspecialchars($currentColor) ?> !important">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-palette fa-2x me-3"></i>
                        <h4 class="mb-0">Website Theme Color</h4>
                    </div>
                </div>
                <div class="card-body p-5">
                    <form id="themeColorForm">
                        <div class="row align-items-center mb-5">
                            <div class="col-md-6">
                                <div class="color-picker-container p-4 bg-light rounded-3 shadow-sm">
                                    <label for="themeColor" class="form-label fw-bold mb-3">Select Theme Color</label>
                                    <input type="color" class="form-control form-control-color w-100" id="themeColor" 
                                           name="themeColor" value="<?= safe_htmlspecialchars($currentColor) ?>" 
                                           title="Choose your theme color">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="color-preview p-4 rounded-3 shadow-sm" style="background-color: <?= safe_htmlspecialchars($currentColor) ?>">
                                    <h5 class="text-white mb-3">Preview</h5>
                                    <div class="d-flex gap-3">
                                        <button class="btn btn-light shadow-sm">Button</button>
                                        <button class="btn btn-outline-light shadow-sm">Outline</button>
                                    </div>
                                    <div class="mt-3">
                                        <div class="progress" style="height: 10px;">
                                            <div class="progress-bar" style="width: 45%"></div>
                                        </div>
                                        <div class="form-check form-switch mt-3">
                                            <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" checked>
                                            <label class="form-check-label text-white" for="flexSwitchCheckChecked">Toggle</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary btn-lg px-4 py-3 rounded-pill shadow-sm" id="saveBtn">
                                <span id="saveText">
                                    <i class="fas fa-save me-2"></i> Save Theme Color
                                </span>
                                <span id="spinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.color-picker-container input[type="color"] {
    height: 80px;
    width: 100% !important;
    cursor: pointer;
    border-radius: 0.5rem;
    border: 2px solid #dee2e6;
}

.color-preview {
    transition: all 0.3s ease;
    height: 100%;
}

.bg-gradient-primary {
    background: linear-gradient(135deg, var(--theme-color) 0%, var(--theme-color-dark) 100%);
}

:root {
    --theme-color: <?= safe_htmlspecialchars($currentColor) ?>;
    --theme-color-dark: <?= safe_htmlspecialchars(adjustBrightness($currentColor, -20)) ?>;
}

.rounded-4 {
    border-radius: 1rem !important;
}

.btn-primary {
    background-color: var(--theme-color);
    border-color: var(--theme-color);
}

.btn-primary:hover {
    background-color: var(--theme-color-dark);
    border-color: var(--theme-color-dark);
}

.btn-outline-primary {
    border-color: var(--theme-color);
    color: var(--theme-color);
}

.btn-outline-primary:hover {
    background-color: var(--theme-color);
    border-color: var(--theme-color);
}

.progress-bar {
    background-color: var(--theme-color);
}

.form-check-input:checked {
    background-color: var(--theme-color);
    border-color: var(--theme-color);
}
</style>

<script>
$(document).ready(function() {
    // Update preview when color changes
    $('#themeColor').on('input', function() {
        const newColor = $(this).val();
        $('.color-preview').css('background-color', newColor);
        $('.card-header').css('background-color', newColor);
        
        // Update button colors in real-time
        $('#saveBtn').css({
            'background-color': newColor,
            'border-color': newColor
        });
    });

    // AJAX form submission
    $('#themeColorForm').submit(function(e) {
        e.preventDefault();
        
        const themeColor = $('#themeColor').val();
        const lightColor = adjustBrightness(themeColor, 40); // Lighten by 40
        
        // Show loading state
        $('#saveBtn').prop('disabled', true);
        $('#saveText').html('<i class="fas fa-circle-notch fa-spin me-2"></i> Saving...');
        $('#spinner').removeClass('d-none');
        
        // AJAX request
        $.ajax({
            url: '../../api/admin/put/website-config/save-theme-color.php',
            type: 'POST',
            data: { themeColor: themeColor },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                    // Update CSS variables
                    document.documentElement.style.setProperty('--theme-color', themeColor);
                    document.documentElement.style.setProperty('--theme-color-dark', response.darkColor);
                    
                    // Update button colors
                    $('.btn-primary').css({
                        'background-color': themeColor,
                        'border-color': themeColor
                    });
                    
                    // Update header color
                    $('.card-header').css('background-color', themeColor);

                    // Update the navbar color
                    $('.gradient-heading-bg')
                    .css('background', `linear-gradient(90deg, ${response.darkColor} 0%, ${themeColor} 43%, ${lightColor} 100%)`)
                    .css('border-left', `5px solid ${lightColor}`);
                } else {
                    toastr.error(response.message);
                }
            },
            error: function(xhr, status, error) {
                toastr.error('An error occurred: ' + error);
            },
            complete: function() {
                // Reset button state
                $('#saveBtn').prop('disabled', false);
                $('#saveText').html('<i class="fas fa-save me-2"></i> Save Theme Color');
                $('#spinner').addClass('d-none');
            }
        });
    });
});

// Helper function to adjust color brightness
function adjustBrightness(color, amount) {
    return '#' + color.replace(/^#/, '').replace(/../g, color => 
        ('0' + Math.min(255, Math.max(0, parseInt(color, 16) + amount)).toString(16)).substr(-2)
    );
}
</script>

<?php 
// PHP function to adjust color brightness
function adjustBrightness($hex, $steps) {
    $steps = max(-255, min(255, $steps));
    $hex = str_replace('#', '', $hex);
    
    if (strlen($hex) == 3) {
        $hex = str_repeat(substr($hex, 0, 1), 2) . str_repeat(substr($hex, 1, 1), 2) . str_repeat(substr($hex, 2, 1), 2);
    }
    
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    
    $r = max(0, min(255, $r + $steps));
    $g = max(0, min(255, $g + $steps));
    $b = max(0, min(255, $b + $steps));
    
    $r_hex = str_pad(dechex($r), 2, '0', STR_PAD_LEFT);
    $g_hex = str_pad(dechex($g), 2, '0', STR_PAD_LEFT);
    $b_hex = str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
    
    return '#' . $r_hex . $g_hex . $b_hex;
}

include_once("../../includes/body-close.php"); 
?>