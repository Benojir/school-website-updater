<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Admission Form Settings - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if ($_SESSION['user']['role'] !== 'superadmin') {
    include_once("../../includes/permission-denied.php");
}

// Fetch all admissionForm settings from database
$stmt = $pdo->query("SELECT * FROM settings_admission_form LIMIT 1");
$admissionFormSettings = $stmt->fetch();

if (!$admissionFormSettings) {
    echo "<div class='container'><div class='alert alert-danger'>No admission form settings found. Please add some.</div></div>";
    exit();
}

// Get available templates admission Forms
$admissionFormPreviewPath = "../../assets/img/admission-forms-designs/";
$admissionFormTemplates = glob($admissionFormPreviewPath . "*.jpg");
$admissionFormTemplateOptions = [];
foreach ($admissionFormTemplates as $template) {
    $admissionFormTemplateOptions[] = str_replace('.jpg', '', basename($template));
}

// Get current selection
$currentStyle= $admissionFormSettings['admission_form_design'] ?? 'design-1'; // Default to design-1 if not set

// Settings default colors
$default_theme_color_primary = '#004ff8';
$default_theme_color_secondary = '#003cbd';
$default_theme_color_dark = '#4200ad';
$default_theme_color_light = '#f0f5ff';
$default_background_color = '#f9f9ff';
$default_school_name_color = '#003297ff';
$default_school_address_color = '#333333';

$theme_color_primary = $admissionFormSettings['primary_theme_color'] ?? $default_theme_color_primary;
$theme_color_secondary = $admissionFormSettings['secondary_theme_color'] ?? $default_theme_color_secondary;
$theme_color_dark = $admissionFormSettings['dark_theme_color'] ?? $default_theme_color_dark;
$theme_color_light = $admissionFormSettings['light_theme_color'] ?? $default_theme_color_light;
$background_color = $admissionFormSettings['background_color'] ?? $default_background_color;
$school_name_color = $admissionFormSettings['school_name_text_color'] ?? $default_school_name_color;
$school_address_color = $admissionFormSettings['school_address_text_color'] ?? $default_school_address_color;

$fast_generation = $admissionFormSettings['fast_generation'] ?? 0;
?>

<div class="container py-5 px-0">
    <div class="row justify-content-center mx-0">
        <div class="col-lg-12">
            <div class="card shadow-lg border-0 rounded-3 overflow-hidden">
                <div class="card-header bg-primary text-white py-3">
                    <div class="d-flex align-items-center justify-content-left">
                        <i class="fas fa-file-alt fa-2x me-3"></i>
                        <h4 class="mb-0">Admission Form Settings</h4>
                    </div>
                </div>
                <div class="card-body p-4 p-md-5">
                    <form id="admission_form_settings_form">
                        <div class="row mx-0">
                            <div class="col-md-4 row mx-0 mb-2">
                                <!-- This col is just for spacing -->
                            </div>

                            <div class="col-md-4 row mx-0 mb-2">
                                <div class="col-md-12">
                                    <h5 class="fw-bold pb-2 text-primary text-center">
                                        <i class="fas fa-file-alt me-2"></i>Admission Form Design
                                    </h5>
                                </div>

                                <div class="col-md-12 mb-3 d-flex justify-content-center">
                                    <select
                                        name="admissionFormDesignSelector"
                                        id="admissionFormDesignSelector"
                                        class="form-control w-75 border border-primary border-2 rounded-3">
                                        <?php foreach ($admissionFormTemplateOptions as $index => $template): ?>
                                            <option value="<?= safe_htmlspecialchars($template) ?>" <?= $template == $currentStyle ? 'selected' : '' ?>>
                                                Admission Form Design <?= $index + 1 ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="col-md-12 d-flex justify-content-center mb-3">
                                    <img
                                        src=""
                                        alt="Admission Form Template"
                                        class="img-fluid border border-primary border-2 rounded-3 w-75"
                                        id="admission_form_preview"
                                        data-fancybox="AdmissionForm"
                                        data-caption=" Admission Form Template"
                                    />
                                </div>

                                <div class="col-md-12 d-flex justify-content-center">
                                    <a href="" class="btn btn-outline-primary" id="live_preview_admission_form" target="_blank">Live Preview</a>
                                </div>
                            </div>

                            <div class="col-md-4 row mx-0 mb-2">
                                <!-- This col is just for spacing -->
                            </div>
                        </div>

                        <div class="row mx-0">

                            <hr class="my-3">

                            <div class="col-md-6 row mx-0 mt-3">
                                <div class="col-md-12">
                                    <h5 class="fw-bold pb-2 text-primary text-center">
                                        <i class="fa-solid fa-paintbrush me-2"></i>Theme Color (Primary)
                                    </h5>
                                </div>

                                <div class="col-md-12">
                                    <div class="color-picker-container p-4 bg-light rounded-3 shadow-sm">
                                        <input type="color" class="form-control form-control-color w-100"
                                            name="theme_color_primary" value="<?= safe_htmlspecialchars($theme_color_primary) ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 row mx-0 mt-3">
                                <div class="col-md-12">
                                    <h5 class="fw-bold pb-2 text-primary text-center">
                                        <i class="fa-solid fa-paintbrush me-2"></i>Theme Color (Secondary)
                                    </h5>
                                </div>

                                <div class="col-md-12">
                                    <div class="color-picker-container p-4 bg-light rounded-3 shadow-sm">
                                        <input type="color" class="form-control form-control-color w-100"
                                            name="theme_color_secondary" value="<?= safe_htmlspecialchars($theme_color_secondary) ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 row mx-0 mt-3">
                                <div class="col-md-12">
                                    <h5 class="fw-bold pb-2 text-primary text-center">
                                        <i class="fa-solid fa-paintbrush me-2"></i>Theme Color (Dark)
                                    </h5>
                                </div>

                                <div class="col-md-12">
                                    <div class="color-picker-container p-4 bg-light rounded-3 shadow-sm">
                                        <input type="color" class="form-control form-control-color w-100"
                                            name="theme_color_dark" value="<?= safe_htmlspecialchars($theme_color_dark) ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 row mx-0 mt-3">
                                <div class="col-md-12">
                                    <h5 class="fw-bold pb-2 text-primary text-center">
                                        <i class="fa-solid fa-paintbrush me-2"></i>Theme Color (Light)
                                    </h5>
                                </div>

                                <div class="col-md-12">
                                    <div class="color-picker-container p-4 bg-light rounded-3 shadow-sm">
                                        <input type="color" class="form-control form-control-color w-100"
                                            name="theme_color_light" value="<?= safe_htmlspecialchars($theme_color_light) ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 row mx-0 mt-3">
                                <div class="col-md-12">
                                    <h5 class="fw-bold pb-2 text-primary text-center">
                                        <i class="fa-solid fa-paintbrush me-2"></i>Background Color
                                    </h5>
                                </div>

                                <div class="col-md-12">
                                    <div class="color-picker-container p-4 bg-light rounded-3 shadow-sm">
                                        <input type="color" class="form-control form-control-color w-100"
                                            name="background_color" value="<?= safe_htmlspecialchars($background_color) ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 row mx-0 mt-3">
                                <div class="col-md-12">
                                    <h5 class="fw-bold pb-2 text-primary text-center">
                                        <i class="fa-solid fa-paintbrush me-2"></i>School Name Color
                                    </h5>
                                </div>

                                <div class="col-md-12">
                                    <div class="color-picker-container p-4 bg-light rounded-3 shadow-sm">
                                        <input type="color" class="form-control form-control-color w-100"
                                            name="school_name_color" value="<?= safe_htmlspecialchars($school_name_color) ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6 row mx-0 mt-3">
                                <div class="col-md-12">
                                    <h5 class="fw-bold pb-2 text-primary text-center">
                                        <i class="fa-solid fa-paintbrush me-2"></i>School Address Text Color
                                    </h5>
                                </div>

                                <div class="col-md-12">
                                    <div class="color-picker-container p-4 bg-light rounded-3 shadow-sm">
                                        <input type="color" class="form-control form-control-color w-100"
                                            name="school_address_text_color" value="<?= safe_htmlspecialchars($school_address_color) ?>">
                                    </div>
                                </div>
                            </div>

                            <hr class="my-3">

                            <div class="col-md-6 row mx-0 mt-3">
                                <div class="col-md-12">
                                    <h5 class="fw-bold pb-2 text-primary">
                                        <i class="fa-solid fa-gears me-2"></i>Additional Options
                                    </h5>
                                </div>

                                <div class="col-md-12">
                                    <input type="checkbox" id="fast_generation" class="form-control-check me-1" name="fast_generation" <?= ($fast_generation == 1 ? "checked" : "") ?>>
                                    <label for="fast_generation" class="form-label">Generate admission forms as fast as possible</label>
                                </div>
                            </div>

                            <div class="col-md-12 d-flex justify-content-center gap-3 mt-5">
                                <button class="btn btn-outline-primary" id="set_default_btn" type="button"><i class="fas fa-history me-2"></i>Set Default Colors</button>
                                <button class="btn btn-primary" type="submit" id="save_btn"><i class="fas fa-save me-2"></i>Save Changes</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .rounded-4 {
        border-radius: 1rem !important;
    }

    .btn-primary {
        transition: all 0.3s ease;
    }

    .btn-primary:hover {
        background-color: #0b5ed7;
        border-color: #0b5ed7;
        transform: translateY(-2px);
        box-shadow: 0 4px 15px rgba(13, 110, 253, 0.4) !important;
    }
</style>

<script>
    // Function to change  admissionForm items
    function updateHtmlElements() {
        let admissionFormPreviewPath = '<?= $admissionFormPreviewPath ?>';
        let selectedDesign = $('#admissionFormDesignSelector').val();
        $('#live_preview_admission_form').attr('href', `${admissionFormPreviewPath}${selectedDesign}.html`);
        $('#admission_form_preview').attr('src', `${admissionFormPreviewPath}${selectedDesign}.jpg`);
    }

    // Function to set default values
    function setDefaultValues() {
        $('[name="theme_color_primary"]').val('<?= $default_theme_color_primary ?>');
        $('[name="theme_color_secondary"]').val('<?= $default_theme_color_secondary ?>');
        $('[name="theme_color_dark"]').val('<?= $default_theme_color_dark ?>');
        $('[name="theme_color_light"]').val('<?= $default_theme_color_light ?>');
        $('[name="background_color"]').val('<?= $default_background_color ?>');
        $('[name="school_name_color"]').val('<?= $default_school_name_color ?>');
        $('[name="school_address_text_color"]').val('<?= $default_school_address_color ?>');
    }

    // Function to submit form data via ajax
    function submitForm() {
        let formData = new FormData($('#admission_form_settings_form')[0]);

        // Show SweetAlert2 processing dialog
        Swal.fire({
            title: 'Saving settings...',
            text: 'Please wait while we process your request.',
            icon: 'info',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        $.ajax({
            url: '../../api/admin/put/website-config/save-admission-forms-settings.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json', // 👈 Important: Expect JSON response
            success: function(response) {
                Swal.close(); // close loading

                if (response.success) {
                    Swal.fire({
                        title: 'Success!',
                        text: response.message || 'Settings saved successfully.',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    });
                    toastr.success(response.message);
                } else {
                    Swal.fire({
                        title: 'Error!',
                        text: response.message || 'Error saving settings. Please try again.',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                    toastr.error(response.message);
                }
            },
            error: function(xhr, status, error) {
                Swal.close();
                Swal.fire({
                    title: 'Request Failed!',
                    text: 'Something went wrong while connecting to the server.',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
                toastr.error('An error occurred.');
                console.error('AJAX Error:', error);
            }
        });
    }


    $(document).ready(function() {
        // Change admissionForm items
        $('#admissionFormDesignSelector').change(function() {
            updateHtmlElements();
        });

        // Set default values on page load
        updateHtmlElements();

        // Set default values on button click
        $('#set_default_btn').click(function() {
            setDefaultValues();
        });

        // Submit form on button click
        $('#admission_form_settings_form').on('submit', function(e) {
            e.preventDefault();
            submitForm();
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>