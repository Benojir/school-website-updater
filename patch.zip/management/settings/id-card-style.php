<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>ID Cards Styles - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if ($_SESSION['user']['role'] !== 'superadmin') {
   include_once("../../includes/permission-denied.php");
}

// Get available ID card templates
$previewPath = "../../assets/img/id-preview/";
$templates = glob($previewPath . "*.jpg");
$templateOptions = [];
foreach ($templates as $template) {
    $templateOptions[] = basename($template);
}

// Get current selection
$currentStyle = '1.jpg'; // Default

if ($websiteConfig['id_card_style']) {
    $currentStyle = $websiteConfig['id_card_style'];
}

?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow-lg border-0 rounded-4 overflow-hidden">
                <div class="card-header bg-primary text-white py-4">
                    <div class="d-flex align-items-center justify-content-center">
                        <i class="fas fa-id-card fa-2x me-3"></i>
                        <h4 class="mb-0">Student ID Card Style</h4>
                    </div>
                </div>
                <div class="card-body p-4 p-md-5">
                    <form id="idCardStyleForm">
                        <div class="text-center mb-5">
                            <div class="d-inline-block position-relative">
                                <h5 class="mb-0 display-5 fw-bold text-dark">Select a Template Design</h5>
                                <div class="title-underline"></div>
                            </div>
                        </div>
                        
                        <div class="row g-4 justify-content-center template-grid">
                            <?php foreach ($templateOptions as $index => $template): ?>
                                <div class="col-xl-3 col-lg-4 col-md-6">
                                    <div class="template-card <?= $template === $currentStyle ? 'selected' : '' ?>">
                                        <input type="radio" name="idCardStyle" id="style-<?= $index ?>" 
                                               value="<?= safe_htmlspecialchars($template) ?>" 
                                               <?= $template === $currentStyle ? 'checked' : '' ?> 
                                               class="visually-hidden">
                                        <label for="style-<?= $index ?>" class="d-block">
                                            <div class="template-preview position-relative mx-auto">
                                                <img src="../../assets/img/id-preview/<?= safe_htmlspecialchars($template) ?>" 
                                                     alt="ID Card Template <?= $index + 1 ?>" 
                                                     class="img-fluid border">
                                                <div class="selection-badge bg-primary">
                                                    <i class="fas fa-check-circle"></i>
                                                </div>
                                            </div>
                                            <div class="template-name text-center mt-3">
                                                <span class="badge bg-primary bg-opacity-10 text-white fs-6 fw-normal py-2 px-3">
                                                    Style <?= $index + 1 ?>
                                                </span>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="text-center mt-5 pt-3">
                            <button type="submit" class="btn btn-primary btn-lg px-5 py-3 rounded-pill shadow" id="saveBtn">
                                <span id="saveText">
                                    <i class="fas fa-save me-2"></i> Save Selection
                                </span>
                                <span id="spinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.template-grid {
    max-width: 1200px;
    margin: 0 auto;
}

.template-card {
    position: relative;
    cursor: pointer;
    transition: all 0.3s ease;
    margin-bottom: 1.5rem;
}

.template-card:hover {
    transform: translateY(-5px);
}

.template-card.selected {
    transform: translateY(-5px);
}

.template-preview {
    width: 319px;
    height: 508px;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease;
    border: 1px solid rgba(0, 0, 0, 0.1) !important;
}

.template-card:hover .template-preview {
    box-shadow: 0 8px 25px rgba(13, 110, 253, 0.2);
}

.template-card.selected .template-preview {
    box-shadow: 0 0 0 3px #0d6efd, 0 8px 25px rgba(13, 110, 253, 0.2);
}

.template-preview img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.selection-badge {
    position: absolute;
    top: 15px;
    right: 15px;
    width: 32px;
    height: 32px;
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transform: scale(0.8);
    transition: all 0.3s ease;
    background-color: #0d6efd !important;
    font-size: 1rem;
}

.template-card.selected .selection-badge {
    opacity: 1;
    transform: scale(1);
}

.title-underline {
    position: absolute;
    bottom: -8px;
    left: 0;
    width: 100%;
    height: 4px;
    background: linear-gradient(90deg, #0d6efd 0%, rgba(13, 110, 253, 0.3) 100%);
    border-radius: 2px;
}

.rounded-4 {
    border-radius: 1rem !important;
}

.btn-primary {
    background-color: #0d6efd;
    border-color: #0d6efd;
    transition: all 0.3s ease;
}

.btn-primary:hover {
    background-color: #0b5ed7;
    border-color: #0b5ed7;
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(13, 110, 253, 0.4) !important;
}
</style>

<script>
$(document).ready(function() {
    // Handle template selection
    $('.template-card').on('click', function() {
        $('.template-card').removeClass('selected');
        $(this).addClass('selected');
        $(this).find('input[type="radio"]').prop('checked', true);
    });

    // AJAX form submission
    $('#idCardStyleForm').submit(function(e) {
        e.preventDefault();
        
        const selectedStyle = $('input[name="idCardStyle"]:checked').val();
        
        if (!selectedStyle) {
            toastr.error('Please select a template');
            return false;
        }
        
        // Show loading state
        $('#saveBtn').prop('disabled', true);
        $('#saveText').html('<i class="fas fa-circle-notch fa-spin me-2"></i> Saving...');
        $('#spinner').removeClass('d-none');
        
        // AJAX request
        $.ajax({
            url: '../action/save-id-card-style.php',
            type: 'POST',
            data: { idCardStyle: selectedStyle },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                } else {
                    toastr.error(response.message);
                }
            },
            error: function(xhr, status, error) {
                toastr.error('An error occurred: ' + error);
            },
            complete: function() {
                // Reset button state
                $('#saveBtn').prop('disabled', false);
                $('#saveText').html('<i class="fas fa-save me-2"></i> Save Selection');
                $('#spinner').addClass('d-none');
            }
        });
    });
});
</script>

<?php include_once("../../includes/body-close.php"); ?>