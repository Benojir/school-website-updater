<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage Website Design - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if ($_SESSION['user']['role'] !== 'superadmin') {
    include_once("../../includes/permission-denied.php");
    exit();
}

?>

<div class="container py-4">
    <div class="row">
        <div class="col-md-10 mx-auto">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><i class="fas fa-palette me-2"></i>Website Design Management</h4>
                </div>
                <div class="card-body">
                    <form id="templateForm">
                        <div class="mb-3">
                            <label for="template_select" class="form-label fw-bold">Select Website Template</label>
                            <select class="form-select" id="template_select" name="website_template" required>
                                <option value="">-- Select a Template --</option>
                                <?php
                                $designsDir = '../../assets/templates/website-interfaces/';
                                $templates = glob($designsDir . '*.php');
                                
                                foreach ($templates as $template) {
                                    $templateName = basename($template, '.php');
                                    $selected = ($templateName == $websiteConfig['website_template']) ? 'selected' : '';
                                    echo "<option value='$templateName' $selected>$templateName</option>";
                                }
                                ?>
                            </select>
                            <div class="form-text">Choose a template for your school website</div>
                        </div>
                        
                        <div class="d-flex justify-content-between align-items-center mt-4">
                            <button type="submit" class="btn btn-primary px-4">
                                <i class="fas fa-save me-2"></i> Save Changes
                            </button>
                            <div id="formMessage" class="text-muted small"></div>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="card shadow-sm mt-4">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="fas fa-eye me-2"></i>Template Preview</h5>
                </div>
                <div class="card-body">
                    <div class="text-center mb-3">
                        <div class="spinner-border text-primary" id="previewSpinner"></div>
                    </div>
                    <iframe id="templatePreview" class="w-100 border rounded" style="height: 500px; display: none;"></iframe>
                    <div id="noPreview" class="text-center py-4 text-muted" style="display: none;">
                        <i class="fas fa-image fa-3x mb-3"></i>
                        <p>Select a template to see preview</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Handle form submission
    $('#templateForm').on('submit', function(e) {
        e.preventDefault();
        
        const formData = $(this).serialize();
        const btn = $(this).find('button[type="submit"]');
        const originalBtnText = btn.html();
        
        btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Saving...');
        $('#formMessage').removeClass('text-success text-danger text-muted').html('');
        
        $.ajax({
            url: '../../api/admin/put/website-config/update-website-template.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    $('#formMessage').addClass('text-success').html(response.message);
                    toastr.success(response.message);
                    // Update preview if template changed
                    if ($('#template_select').val() !== '<?= $websiteConfig['website_template'] ?? '' ?>') {
                        loadTemplatePreview($('#template_select').val());
                    }
                } else {
                    $('#formMessage').addClass('text-danger').html(response.message);
                    toastr.error(response.message);
                }
            },
            error: function(xhr, status, error) {
                $('#formMessage').addClass('text-danger').html('An error occurred. Please try again.');
                toastr.error('An error occurred. Please try again.');
            },
            complete: function() {
                btn.prop('disabled', false).html(originalBtnText);
                setTimeout(() => $('#formMessage').fadeOut(), 3000);
            }
        });
    });
    
    // Load preview when template selection changes
    $('#template_select').on('change', function() {
        if ($(this).val()) {
            loadTemplatePreview($(this).val());
        } else {
            $('#templatePreview').hide();
            $('#noPreview').show();
            $('#previewSpinner').hide();
        }
    });
    
    // Initial preview load if template is already selected
    if ($('#template_select').val()) {
        loadTemplatePreview($('#template_select').val());
    } else {
        $('#previewSpinner').hide();
        $('#noPreview').show();
    }
    
    // Function to load template preview
    function loadTemplatePreview(templateName) {
        $('#templatePreview').hide();
        $('#noPreview').hide();
        $('#previewSpinner').show();
        
        // Use a timeout to show loading spinner for at least 500ms
        setTimeout(function() {
            $('#templatePreview').attr('src', `../../assets/templates/website-interfaces/${templateName}.php?preview=true`).on('load', function() {
                $('#previewSpinner').hide();
                $('#templatePreview').show();
            });
        }, 500);
    }
});
</script>

<?php include_once("../../includes/body-close.php"); ?>