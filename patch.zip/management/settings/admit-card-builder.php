<?php
// Reuse the complete canvas editor with an independent admit-card library.
define('ID_CARD_AUDIENCE', 'admit');
require __DIR__ . '/student-id-card-builder.php';
