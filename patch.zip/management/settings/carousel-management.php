<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/imgbb-upload.php");
include_once("../../includes/header-open.php");
echo "<title>Carousel Management - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if ($_SESSION['user']['role'] !== 'superadmin') {
   include_once("../../includes/permission-denied.php");
}

// Get current carousel images
$carouselImages = [];
$stmt = $pdo->query("SELECT * FROM carousel_images ORDER BY uploaded_at DESC");
if ($stmt) {
    $carouselImages = $stmt->fetchAll();
}

// Check current count
$imageCount = count($carouselImages);
$maxImages = 10;
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card shadow-lg border-0 rounded-4 overflow-hidden">
                <div class="card-header bg-primary text-white py-4">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <i class="fas fa-images fa-2x me-3"></i>
                            <h4 class="mb-0 d-inline-block">Carousel Image Management</h4>
                        </div>
                        <div class="badge bg-white text-primary fs-6">
                            <?= $imageCount ?>/<?= $maxImages ?> Images
                        </div>
                    </div>
                </div>
                <div class="card-body p-4 p-md-5">
                    <!-- Upload Form -->
                    <form id="uploadCarouselForm" enctype="multipart/form-data" class="mb-5">
                        <div class="text-center mb-4">
                            <div class="d-inline-block position-relative">
                                <h5 class="mb-0 display-5 fw-bold text-dark">Upload New Image</h5>
                                <div class="title-underline"></div>
                            </div>
                        </div>
                        
                        <div class="row g-3">
                            <div class="col-md-8">
                                <div class="file-upload-card bg-light rounded-3 p-4 text-center border-2 border-dashed border-primary-hover transition-all">
                                    <div class="file-upload-icon mb-3">
                                        <i class="fas fa-cloud-upload-alt fa-4x text-primary opacity-75"></i>
                                    </div>
                                    <h5 class="mb-2 fw-normal">Choose Carousel Image</h5>
                                    <p class="text-muted mb-4">16:9 aspect ratio recommended (max 5MB)</p>
                                    
                                    <div class="file-upload-wrapper position-relative">
                                        <input type="file" class="form-control visually-hidden" id="carouselImage" name="carouselImage" accept="image/*" required>
                                        <label for="carouselImage" class="btn btn-primary px-4 py-2 rounded-pill shadow-sm">
                                            <i class="fas fa-folder-open me-2"></i> Browse Files
                                        </label>
                                        <div class="file-info mt-3 small text-muted" id="fileInfo">
                                            <div class="file-name d-none">
                                                <i class="fas fa-file-image me-1 text-success"></i>
                                                <span id="fileName"></span>
                                                <span class="file-size badge bg-light text-dark ms-2" id="fileSize"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="invalid-feedback mt-2">Please select a valid image file</div>
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="h-100 d-flex flex-column">
                                    <label for="imageCaption" class="form-label fw-bold mb-3">Image Caption</label>
                                    <textarea class="form-control flex-grow-1" id="imageCaption" name="imageCaption" 
                                              placeholder="Enter caption text (optional)" rows="3"></textarea>
                                    <div class="mt-3">
                                        <button type="submit" class="btn btn-primary w-100 py-3" id="uploadBtn">
                                            <span id="uploadText">
                                                <i class="fas fa-upload me-2"></i> Upload Image
                                            </span>
                                            <span id="spinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    
                    <!-- Image Gallery -->
                    <div class="mt-5 pt-4 border-top">
                        <div class="text-center mb-4">
                            <div class="d-inline-block position-relative">
                                <h5 class="mb-0 display-5 fw-bold text-dark">Current Carousel Images</h5>
                                <div class="title-underline"></div>
                            </div>
                        </div>
                        
                        <?php if (empty($carouselImages)): ?>
                            <div class="text-center py-5">
                                <i class="fas fa-images fa-4x text-muted mb-4"></i>
                                <h5 class="text-muted">No carousel images uploaded yet</h5>
                            </div>
                        <?php else: ?>
                            <div class="row g-4 image-gallery">
                                <?php foreach ($carouselImages as $image): ?>
                                    <div class="col-lg-4 col-md-6" data-id="<?= $image['id'] ?>">
                                        <div class="gallery-card card h-100 border-0 shadow-sm overflow-hidden">
                                            <div class="ratio ratio-16x9">
                                                <img src="<?= safe_htmlspecialchars($image['thumbnail_url']) ?>" 
                                                     class="card-img-top object-fit-cover" 
                                                     alt="Carousel image" 
                                                     data-full-image="<?= safe_htmlspecialchars($image['image_url']) ?>">
                                            </div>
                                            <div class="card-body">
                                                <p class="card-text"><?= safe_htmlspecialchars($image['caption']) ?></p>
                                            </div>
                                            <div class="card-footer bg-transparent border-0 pt-0">
                                                <button class="btn btn-sm btn-danger w-100 delete-image">
                                                    <i class="fas fa-trash-alt me-2"></i> Delete
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.file-upload-card {
    transition: all 0.3s ease;
    border-color: rgba(13, 110, 253, 0.2);
}

.file-upload-card:hover {
    border-color: rgba(13, 110, 253, 0.5);
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
}

.file-upload-icon {
    transition: all 0.3s ease;
}

.file-upload-card:hover .file-upload-icon {
    transform: scale(1.05);
    opacity: 1 !important;
}

.title-underline {
    position: absolute;
    bottom: -8px;
    left: 0;
    width: 100%;
    height: 4px;
    background: linear-gradient(90deg, #0d6efd 0%, rgba(13, 110, 253, 0.3) 100%);
    border-radius: 2px;
}

.image-gallery .gallery-card {
    transition: all 0.3s ease;
}

.image-gallery .gallery-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1) !important;
}

.object-fit-cover {
    object-fit: cover;
}

.rounded-4 {
    border-radius: 1rem !important;
}

.btn-primary {
    background-color: #0d6efd;
    border-color: #0d6efd;
    transition: all 0.3s ease;
}

.btn-primary:hover {
    background-color: #0b5ed7;
    border-color: #0b5ed7;
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(13, 110, 253, 0.4) !important;
}

.btn-danger {
    transition: all 0.3s ease;
}

.btn-danger:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(220, 53, 69, 0.4) !important;
}
</style>

<script>
$(document).ready(function() {
    // Update file input display
    $('#carouselImage').on('change', function() {
        const file = this.files[0];
        if (file) {
            // Update file info display
            const fileName = file.name;
            const fileSize = (file.size / (1024 * 1024)).toFixed(2) + 'MB';
            
            $('#fileName').text(fileName);
            $('#fileSize').text(fileSize);
            $('#fileInfo .file-name').removeClass('d-none');
            
            // Validate file size
            if (file.size > 5 * 1024 * 1024) {
                $('#carouselImage').addClass('is-invalid');
                $('#fileInfo .file-name i').removeClass('text-success').addClass('text-danger');
            } else {
                $('#carouselImage').removeClass('is-invalid');
                $('#fileInfo .file-name i').removeClass('text-danger').addClass('text-success');
            }
        }
    });

    // AJAX form submission for upload
    $('#uploadCarouselForm').submit(function(e) {
        e.preventDefault();
        
        const fileInput = $('#carouselImage')[0];
        const file = fileInput.files[0];
        const caption = $('#imageCaption').val();
        
        // Validate file
        if (!file) {
            toastr.error('Please select an image file');
            return false;
        }
        
        // Check file size (5MB max)
        if (file.size > 5 * 1024 * 1024) {
            toastr.error('Image file must be less than 5MB');
            return false;
        }
        
        // Check image count
        if (<?= $imageCount ?> >= <?= $maxImages ?>) {
            toastr.error(`Maximum ${<?= $maxImages ?>} images allowed. Please delete some images first.`);
            return false;
        }
        
        // Show loading state
        $('#uploadBtn').prop('disabled', true);
        $('#uploadText').html('<i class="fas fa-circle-notch fa-spin me-2"></i> Uploading...');
        $('#spinner').removeClass('d-none');
        
        // Create FormData object
        const formData = new FormData();
        formData.append('carouselImage', file);
        formData.append('caption', caption);
        
        // AJAX request
        $.ajax({
            url: '../action/upload-carousel-image.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                    // Reload the page to show new image
                    setTimeout(() => location.reload(), 1500);
                } else {
                    toastr.error(response.message || 'Upload failed');
                }
            },
            error: function(xhr, status, error) {
                toastr.error('An error occurred: ' + error);
            },
            complete: function() {
                // Reset button state
                $('#uploadBtn').prop('disabled', false);
                $('#uploadText').html('<i class="fas fa-upload me-2"></i> Upload Image');
                $('#spinner').addClass('d-none');
            }
        });
    });

    // Delete image handler
    $('.delete-image').on('click', function() {
        const card = $(this).closest('[data-id]');
        const imageId = card.data('id');
        
        Swal.fire({
            title: 'Are you sure?',
            text: "This image will be permanently deleted!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '../action/delete-carousel-image.php',
                    type: 'POST',
                    data: { id: imageId },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            toastr.success(response.message);
                            card.fadeOut(300, function() {
                                $(this).remove();
                                // Update image count
                                const countBadge = $('.badge.bg-white');
                                const currentCount = parseInt(countBadge.text().split('/')[0]);
                                countBadge.text((currentCount - 1) + '/<?= $maxImages ?>');
                            });
                        } else {
                            toastr.error(response.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        toastr.error('An error occurred: ' + error);
                    }
                });
            }
        });
    });
});
</script>

<?php include_once("../../includes/body-close.php"); ?>