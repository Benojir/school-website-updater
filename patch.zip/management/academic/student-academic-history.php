<?php
require_once __DIR__ . '/../../includes/auth-check.php';
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    http_response_code(403);
    exit('Permission denied.');
}

// Pure form helpers: a browser date input cannot represent permissive legacy dates.
function academicHistoryDateInput(mixed $value): array
{
    $raw = (string)($value ?? '');
    $valid = preg_match('/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/D', $raw) === 1
        && checkdate((int)substr($raw, 5, 2), (int)substr($raw, 8, 2), (int)substr($raw, 0, 4));
    return ['raw' => $raw, 'legacy' => $raw !== '' && !$valid, 'value' => $valid ? $raw : ''];
}

function academicHistoryPostedFields(array $post): array
{
    $fields = array_intersect_key($post, array_flip(academicFields()));
    if (($fields['status'] ?? '') === '__preserve__') unset($fields['status']);
    foreach (['admission_date', 'promoted_date'] as $field) {
        if (($post['keep_legacy_' . $field] ?? null) === '1') unset($fields[$field]);
    }
    return $fields;
}

$_SESSION['academic_history_csrf'] ??= bin2hex(random_bytes(32));
$message = '';
$error = '';
$rowId = (int)($_GET['student_row_id'] ?? $_POST['student_row_id'] ?? 0);
if (!$rowId && !empty($_GET['student_id'])) {
    $stmt = $pdo->prepare('SELECT id FROM students WHERE student_id = ?');
    $stmt->execute([$_GET['student_id']]);
    $rowId = (int)$stmt->fetchColumn();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($_SESSION['academic_history_csrf'], (string)($_POST['csrf'] ?? ''))) throw new InvalidArgumentException('Please reload this page and try again.');
        $recordId = (int)($_POST['record_id'] ?? 0);
        if (!$rowId || !$recordId) throw new InvalidArgumentException('Select an existing academic record.');
        $fields = academicHistoryPostedFields($_POST);
        academicSaveRecord($pdo, $rowId, $fields, $recordId);
        $message = 'Academic record saved. Other years and the original migration snapshot were preserved.';
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}
$student = null;
$records = [];
if ($rowId) {
    $stmt = $pdo->prepare('SELECT * FROM students WHERE id = ?');
    $stmt->execute([$rowId]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$student) { http_response_code(404); exit('Student not found.'); }
    $records = academicGetHistory($pdo, $rowId);
}
$unknown = $pdo->query("SELECT s.id AS student_row_id, s.student_id, s.name, ar.status, snap.academic_year AS legacy_year FROM student_academic_records ar JOIN students s ON s.id = ar.student_row_id LEFT JOIN student_academic_legacy_snapshot snap ON snap.student_row_id = s.id WHERE ar.academic_year IS NULL ORDER BY s.name")->fetchAll(PDO::FETCH_ASSOC);
$classes = $pdo->query('SELECT id, class_name FROM classes ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
$sections = $pdo->query('SELECT id, class_id, section_name FROM sections ORDER BY class_id, id')->fetchAll(PDO::FETCH_ASSOC);
$h = static fn($value) => htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
include_once __DIR__ . '/../../includes/header-open.php';
echo '<title>Academic History - ' . $h($school_name) . '</title>';
include_once __DIR__ . '/../../includes/header-close.php';
include_once __DIR__ . '/../../includes/dashboard-navbar.php';
?>
<main class="container py-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <h1 class="h4 mb-0">Student Academic History</h1>
        <a class="btn btn-outline-secondary" href="../student/list-students.php">Student list</a>
    </div>
    <p>Current school year: <strong><?= $h(academicCurrentYear($pdo) ?? 'Not configured') ?></strong> · <a href="../settings/school-settings.php">School Settings</a></p>
    <?php if ($message): ?><div class="alert alert-success" role="status"><?= $h($message) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger" role="alert"><?= $h($error) ?></div><?php endif; ?>
    <form method="get" class="row g-2 mb-4">
        <div class="col-sm-8"><label for="student-search" class="form-label">Student ID</label><input id="student-search" name="student_id" class="form-control" value="<?= $h($student['student_id'] ?? '') ?>" required></div>
        <div class="col-sm-4 align-self-end"><button class="btn btn-primary">View history</button></div>
    </form>
    <?php if ($student): ?>
        <h2 class="h5"><?= $h($student['name']) ?> <small class="text-muted"><?= $h($student['student_id']) ?></small></h2>
        <p>First admission date: <?= $h($student['first_admission_date'] ?: 'Not verified in legacy data') ?>. Annual admission dates are shown below.</p>
        <div class="table-responsive mb-3"><table class="table table-bordered">
            <thead><tr><th>Year</th><th>Class</th><th>Section</th><th>Roll</th><th>Registration</th><th>Admission date</th><th>Promotion date</th><th>Status</th></tr></thead>
            <tbody><?php foreach ($records as $record): ?><tr>
                <?php foreach (['academic_year','class_name','section_name','roll_no','registration_no','admission_date','promoted_date','status'] as $key): ?><td><?= $h($record[$key] ?? ($key === 'academic_year' ? 'Needs review' : '—')) ?></td><?php endforeach; ?>
            </tr><?php endforeach; ?></tbody>
        </table></div>
        <p class="text-muted">Correct one year's record here. To add another year, use promotion/re-admission. A missing legacy year must be verified from school records; admission dates do not establish its academic year.</p>
        <?php foreach ($records as $record): ?>
        <details class="card mb-3">
            <summary class="card-header">Edit <?= $h($record['academic_year'] ?? 'unresolved legacy record') ?></summary>
            <form method="post" class="card-body row g-3 academic-record-form">
                <input type="hidden" name="csrf" value="<?= $h($_SESSION['academic_history_csrf']) ?>">
                <input type="hidden" name="student_row_id" value="<?= (int)$rowId ?>">
                <input type="hidden" name="record_id" value="<?= (int)$record['id'] ?>">
                <div class="col-md-4"><label class="form-label" for="year-<?= (int)$record['id'] ?>">Academic year</label><input class="form-control" id="year-<?= (int)$record['id'] ?>" name="academic_year" type="number" min="2000" max="2200" value="<?= $h($record['academic_year']) ?>" <?= $record['academic_year'] !== null ? 'readonly' : '' ?> required></div>
                <div class="col-md-4"><label class="form-label">Class<select class="form-select academic-class" name="class_id"><option value="">Unassigned</option><?php foreach ($classes as $class): ?><option value="<?= (int)$class['id'] ?>" <?= $record['class_id'] == $class['id'] ? 'selected' : '' ?>><?= $h($class['class_name']) ?></option><?php endforeach; ?></select></label></div>
                <div class="col-md-4"><label class="form-label">Section<select class="form-select academic-section" name="section_id"><option value="">Unassigned</option><?php foreach ($sections as $section): ?><option data-class="<?= (int)$section['class_id'] ?>" value="<?= (int)$section['id'] ?>" <?= $record['section_id'] == $section['id'] ? 'selected' : '' ?>><?= $h($section['section_name']) ?> (class <?= (int)$section['class_id'] ?>)</option><?php endforeach; ?></select></label></div>
                <div class="col-md-4"><label class="form-label">Roll<input class="form-control" name="roll_no" type="number" min="1" step="1" value="<?= $h($record['roll_no']) ?>"></label></div>
                <div class="col-md-4"><label class="form-label">Registration<input class="form-control" name="registration_no" maxlength="50" value="<?= $h($record['registration_no']) ?>"></label></div>
                <div class="col-md-4"><label class="form-label">Status<select class="form-select" name="status"><?php if (!in_array(strtolower((string)$record['status']), ['active','left','alumni'], true)): ?><option value="__preserve__" selected>Legacy value (unchanged)</option><?php endif; ?><?php foreach (['Active','Left','Alumni'] as $status): $selected = strcasecmp((string)$record['status'], $status) === 0; ?><option value="<?= $h($selected ? $record['status'] : $status) ?>" <?= $selected ? 'selected' : '' ?>><?= $h($status) ?></option><?php endforeach; ?></select></label></div>
                <!-- Academic date controls -->
                <?php foreach (['admission_date' => 'Annual admission date', 'promoted_date' => 'Promotion date'] as $dateField => $dateLabel):
                    $dateInput = academicHistoryDateInput($record[$dateField] ?? null);
                    $dateInputId = $dateField . '-' . (int)$record['id']; ?>
                <div class="col-md-4">
                    <label class="form-label" for="<?= $h($dateInputId) ?>"><?= $h($dateLabel) ?></label>
                    <?php if ($dateInput['legacy']): ?>
                        <div class="small mb-2">Stored legacy value: <code class="text-break" style="white-space: pre-wrap"><?= $h($dateInput['raw']) ?></code></div>
                        <div class="form-check mb-2">
                            <input class="form-check-input keep-legacy-date" id="keep-<?= $h($dateInputId) ?>" name="keep_legacy_<?= $h($dateField) ?>" type="checkbox" value="1" data-date-input="<?= $h($dateInputId) ?>" checked>
                            <label class="form-check-label" for="keep-<?= $h($dateInputId) ?>">Keep legacy date unchanged</label>
                        </div>
                    <?php endif; ?>
                    <input class="form-control" id="<?= $h($dateInputId) ?>" name="<?= $h($dateField) ?>" type="date" value="<?= $h($dateInput['value']) ?>" <?= $dateInput['legacy'] ? 'disabled' : '' ?>>
                    <?php if ($dateInput['legacy']): ?><div class="form-text">Uncheck to enter a valid date, or leave the enabled date field empty to clear it.</div><?php endif; ?>
                </div>
                <?php endforeach; ?>
                <!-- End academic date controls -->
                <div class="col-md-4"><label class="form-label">Custom class fee<input class="form-control" name="custom_class_fee" type="number" min="0" step="0.01" value="<?= $h($record['custom_class_fee']) ?>"></label></div>
                <div><button class="btn btn-primary">Save this record</button></div>
            </form>
        </details>
        <?php endforeach; ?>
    <?php endif; ?>
    <h2 class="h5 mt-4">Legacy years needing review (<?= count($unknown) ?>)</h2>
    <p>Original values remain in the migration snapshot. Assign a year only after checking your school records.</p>
    <div class="table-responsive"><table class="table table-striped"><thead><tr><th>Student</th><th>ID</th><th>Original year value</th><th>Status</th><th></th></tr></thead><tbody>
    <?php foreach ($unknown as $item): ?><tr><td><?= $h($item['name']) ?></td><td><?= $h($item['student_id']) ?></td><td><?= $h($item['legacy_year'] ?? '(empty)') ?></td><td><?= $h($item['status']) ?></td><td><a href="?student_row_id=<?= (int)$item['student_row_id'] ?>">Review</a></td></tr><?php endforeach; ?>
    </tbody></table></div>
</main>
<script>
document.querySelectorAll('.academic-record-form').forEach(form => {
    form.querySelectorAll('.keep-legacy-date').forEach(checkbox => {
        const input = document.getElementById(checkbox.dataset.dateInput);
        const updateDateInput = () => { input.disabled = checkbox.checked; };
        checkbox.addEventListener('change', updateDateInput);
        updateDateInput();
    });
    const cls = form.querySelector('.academic-class');
    const sec = form.querySelector('.academic-section');
    const filter = () => {
        for (const option of sec.options) {
            option.hidden = !!option.value && option.dataset.class !== cls.value;
            option.disabled = option.hidden;
        }
        if (sec.selectedOptions[0]?.disabled) sec.value = '';
    };
    cls.addEventListener('change', filter);
    filter();
});
</script>
<?php include_once __DIR__ . '/../../includes/body-close.php'; ?>
