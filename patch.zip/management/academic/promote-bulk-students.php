<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Promote Students - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");
include_once("../../includes/academic/fun-academic-functions.php");

// Check admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    include_once("../../includes/permission-denied.php");
    exit;
}

// Get student IDs from GET parameter (comma-separated)
$student_ids = isset($_GET['student_ids']) ? explode(',', $_GET['student_ids']) : [];
$student_ids = array_filter(array_map('trim', $student_ids));

if (empty($student_ids)) {
    die("No student IDs provided.");
}

// First check if all students are from the same class
$placeholders = implode(',', array_fill(0, count($student_ids), '?'));
$stmt = $pdo->prepare("
    SELECT s.class_id, c.class_name, c.is_final_class, COUNT(*) as student_count,
           COUNT(DISTINCT s.class_id) as distinct_class_count
    FROM students s
    JOIN classes c ON s.class_id = c.id
    WHERE s.student_id IN ($placeholders)
    GROUP BY s.class_id
");
$stmt->execute($student_ids);
$class_results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// If we got more than one result, students are from different classes
if (count($class_results) > 1) {
?>
    <div class="container mt-4">
        <div class="card shadow">
            <div class="card-header bg-danger text-white">
                <h3><i class="fas fa-exclamation-triangle"></i> Cannot Promote Students</h3>
            </div>
            <div class="card-body">
                <div class="alert alert-danger">
                    <h5>You have selected students from different classes.</h5>
                    <p>All students must be from the same class for bulk promotion.</p>
                </div>
                <a href="../student/list-students.php" class="btn btn-primary">
                    <i class="fas fa-arrow-left"></i> Back to Student List
                </a>
            </div>
        </div>
    </div>
<?php
    include_once("../../includes/body-close.php");
    exit;
}

// If we got exactly one result, all students are in the same class
if (count($class_results) === 1) {
    $class_info = $class_results[0];
} else {
    die("No valid students found.");
}

// Get all students details - this is the critical fixed section
$stmt = $pdo->prepare("
    SELECT s.student_id, s.name, s.roll_no, sec.section_name
    FROM students s
    LEFT JOIN sections sec ON s.section_id = sec.id
    WHERE s.student_id IN ($placeholders)
    ORDER BY s.roll_no ASC
");
$stmt->execute($student_ids);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($students)) {
    die("No valid student records found for the provided IDs.");
}

// Check if this is the final class
// In the section where you check for final class, replace the existing code with:
if ($class_info['is_final_class']) {
?>
    <div class="container mt-4">
        <div class="card shadow">
            <div class="card-header bg-info text-white">
                <h3><i class="fas fa-graduation-cap"></i> Final Class Students</h3>
            </div>
            <div class="card-body">
                <div class="alert alert-info">
                    <h5>These students are in the final class (<?= safe_htmlspecialchars($class_info['class_name']) ?>)</h5>
                    <p>Students in the final class will be marked as Alumni.</p>

                    <form id="graduateForm">
                        <input type="hidden" name="student_ids" value="<?= safe_htmlspecialchars(implode(',', $student_ids)) ?>">
                        <input type="hidden" name="current_class_id" value="<?= $class_info['class_id'] ?>">

                        <div class="mb-3">
                            <label class="form-label">Graduation Date</label>
                            <input type="date" class="form-control" name="graduation_date"
                                value="<?= date('Y-m-d') ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Remarks</label>
                            <input type="text" class="form-control" name="remarks"
                                placeholder="Optional remarks about graduation">
                        </div>

                        <div class="table-responsive mb-4">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Student ID</th>
                                        <th>Name</th>
                                        <th>Roll No</th>
                                        <th>Current Section</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($students as $student): ?>
                                        <tr>
                                            <td><?= safe_htmlspecialchars($student['student_id']) ?></td>
                                            <td><?= safe_htmlspecialchars($student['name']) ?></td>
                                            <td><?= safe_htmlspecialchars($student['roll_no']) ?></td>
                                            <td><?= safe_htmlspecialchars($student['section_name']) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="text-center mt-4">
                            <button type="submit" class="btn btn-success" id="graduateButton">
                                <i class="fas fa-graduation-cap"></i> Mark as Alumni
                            </button>
                            <a href="../student/list-students.php" class="btn btn-secondary">
                                <i class="fas fa-times"></i> Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Handle graduation form submission
            $('#graduateForm').submit(function(e) {
                e.preventDefault();

                const formData = $(this).serialize();

                $('#graduateButton').prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Processing...');

                $.ajax({
                    url: '../../api/admin/put/student/process-graduation.php',
                    type: 'POST',
                    data: formData,
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            toastr.success(response.message);
                            // Redirect after 2 seconds
                            setTimeout(() => {
                                window.location.href = '../student/list-students.php';
                            }, 2000);
                        } else {
                            toastr.error(response.message);
                        }
                    },
                    error: function(xhr) {
                        toastr.error('An error occurred while processing graduation');
                        console.error('Error:', xhr.statusText);
                    },
                    complete: function() {
                        $('#graduateButton').prop('disabled', false).html('<i class="fas fa-graduation-cap"></i> Mark as Alumni');
                    }
                });
            });
        });
    </script>
<?php
    include_once("../../includes/body-close.php");
    exit;
}

// Get all classes ordered by level
$stmt = $pdo->prepare("SELECT * FROM classes ORDER BY id ASC");
$stmt->execute();
$all_classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get next class (if exists)
$next_class_id = $class_info['class_id'] + 1;
$next_class_exists = false;
foreach ($all_classes as $class) {
    if ($class['id'] == $next_class_id) {
        $next_class_exists = true;
        break;
    }
}

// Get sections for the next class by default (if exists)
$sections = [];
if ($next_class_exists) {
    $stmt = $pdo->prepare("SELECT * FROM sections WHERE class_id = ? ORDER BY section_name");
    $stmt->execute([$next_class_id]);
    $sections = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get existing students in potential target classes (for roll number management)
$existing_students = [];
if ($next_class_exists) {
    $stmt = $pdo->prepare("
        SELECT section_id, COUNT(*) as student_count, MAX(roll_no) as max_roll_no
        FROM students 
        WHERE class_id = ?
        GROUP BY section_id
    ");
    $stmt->execute([$next_class_id]);
    $existing_students = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<div class="container mt-4">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h3><i class="fas fa-graduation-cap"></i> Promote Students</h3>
        </div>
        <div class="card-body">
            <div id="messageContainer"></div>

            <div class="alert alert-info mb-4">
                <h5>Promoting <b><?= $class_info['student_count'] ?></b> students from class <b><?= safe_htmlspecialchars($class_info['class_name']) ?></b></h5>
                <?php if (!empty($existing_students)): ?>
                    <p>The target class currently has:</p>
                    <ul>
                        <?php foreach ($existing_students as $section): ?>
                            <li>Section <?= getSectionNameById($pdo, $section['section_id']) ?>: <?= $section['student_count'] ?> students (Max Roll: <?= $section['max_roll_no'] ?>)</li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>

            <form id="bulkPromotionForm">
                <input type="hidden" name="student_ids" value="<?= safe_htmlspecialchars(implode(',', $student_ids)) ?>">
                <input type="hidden" name="current_class_id" value="<?= $class_info['class_id'] ?>">

                <div class="row mb-3">
                    <div class="col-md-4">
                        <label class="form-label">New Class</label>
                        <select class="form-select" name="new_class_id" id="newClassSelect" required>
                            <option value="">-- Select New Class --</option>
                            <?php foreach ($all_classes as $class): ?>
                                <?php if ($class['id'] > $class_info['class_id'] || $class['id'] < $class_info['class_id']): ?>
                                    <option value="<?= $class['id'] ?>" <?= ($class['id'] == $next_class_id) ? 'selected' : '' ?>>
                                        <?= safe_htmlspecialchars($class['class_name']) ?>
                                        <?= $class['is_final_class'] ? ' (Final Class)' : '' ?>
                                    </option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">New Section</label>
                        <select class="form-select" name="new_section_id" id="newSectionSelect">
                            <option value="">-- Select Section (Optional) --</option>
                            <?php foreach ($sections as $section): ?>
                                <option value="<?= $section['id'] ?>">
                                    <?= safe_htmlspecialchars($section['section_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Roll Number Assignment</label>
                        <select class="form-select" name="roll_number_strategy" required>
                            <option value="blank">Leave blank (assign later) (Recommended)</option>
                            <option value="by_exam_rank">Assign by latest exam rank</option>
                            <option value="auto_increment">Auto-increment from current max</option>
                            <option value="preserve_order">Preserve current order (starting from 1)</option>
                            <option value="keep_existing">Keep existing roll numbers</option>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="academic_year" class="form-label">Academic Year</label>
                        <select class="form-control" id="academic_year" name="academic_year" required>
                            <?php
                            $current_year = date('Y');
                            for ($year = $current_year; $year <= $current_year + 2; $year++) {
                                $selected = ($year == $current_year) ? 'selected' : '';
                                echo "<option value='$year' $selected>$year</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Admission/Promoted Date</label>
                        <input type="date" class="form-control" name="promotion_date"
                            value="<?= date('Y-m-d') ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Remarks</label>
                        <input type="text" class="form-control" name="remarks"
                            placeholder="Optional remarks about promotion">
                    </div>
                </div>

                <div class="mb-3">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="mark_results_promoted" id="markResultsPromoted" checked>
                        <label class="form-check-label" for="markResultsPromoted">
                            Mark previous results as promoted
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="auto_include_admission_fee" name="auto_include_admission_fee" checked>
                        <label class="form-check-label" for="auto_include_admission_fee">
                            Auto Include Admission Fee
                        </label>
                    </div>
                </div>

                <div class="table-responsive mb-4">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Current Roll No</th>
                                <th>Current Section</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students as $student): ?>
                                <tr>
                                    <td><?= safe_htmlspecialchars($student['student_id']) ?></td>
                                    <td><?= safe_htmlspecialchars($student['name']) ?></td>
                                    <td><?= safe_htmlspecialchars($student['roll_no']) ?></td>
                                    <td><?= safe_htmlspecialchars($student['section_name']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="text-center mt-4">
                    <button type="submit" class="btn btn-primary" id="promoteButton">
                        <i class="fas fa-save"></i> Promote Students
                    </button>
                    <a href="../student/list-students.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Load sections when new class selection changes
        $('#newClassSelect').change(function() {
            const classId = $(this).val();
            if (!classId) return;

            $.ajax({
                url: '../../api/admin/get/class/get-sections-by-class.php',
                type: 'GET',
                data: {
                    class_id: classId
                },
                dataType: 'json',
                success: function(sections) {
                    const sectionSelect = $('#newSectionSelect');
                    sectionSelect.empty();
                    sectionSelect.append('<option value="">-- Select Section --</option>');

                    sections.forEach(function(section) {
                        sectionSelect.append(
                            $('<option></option>').val(section.id).text(section.section_name)
                        );
                    });
                },
                error: function(xhr) {
                    console.error('Error loading sections:', xhr.statusText);
                }
            });
        });

        // Handle form submission
        $('#bulkPromotionForm').submit(function(e) {
            e.preventDefault();

            const formData = $(this).serialize();

            $('#promoteButton').prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Processing...');

            $.ajax({
                url: '../../api/admin/put/student/process-bulk-promotion.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        showMessage(response.message, 'success');
                    } else {
                        showMessage(response.message, 'danger');
                    }
                },
                error: function(xhr) {
                    showMessage('An error occurred while processing your request', 'danger');
                    console.error('Error:', xhr.statusText);
                },
                complete: function() {
                    $('#promoteButton').prop('disabled', false).html('<i class="fas fa-save"></i> Promote Students');
                }
            });
        });

        function showMessage(message, type) {
            const container = $('#messageContainer');
            container.html(`<div class="alert alert-${type}">${message}</div>`);

            if (type === 'success') {
                toastr.success(message);
                Swal.fire({
                    title: 'Success!',
                    text: message,
                    icon: 'success',
                    confirmButtonText: 'OK'
                });
            } else {
                toastr.error(message);
                Swal.fire({
                    title: 'Error!',
                    text: message,
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
            }
        }
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>