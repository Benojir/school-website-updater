<?php
require_once __DIR__ . '/../../includes/auth-check.php';
require_once __DIR__ . '/../../includes/academic/admission-enquiry-edit-service.php';
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    http_response_code(403);
    exit('Permission denied.');
}
$h = static fn($value) => htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
$enquiry = null;
$classes = [];
$error = '';
$id = filter_input(INPUT_GET, 'enquiry_id', FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    http_response_code(400);
    $error = 'Please select an application from the admission enquiries list.';
} else {
    try {
        $stmt = $pdo->prepare('SELECT * FROM admission_enquiries WHERE id = ?');
        $stmt->execute([$id]);
        $enquiry = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        if (!$enquiry) {
            http_response_code(404);
            $error = 'This application has already been processed or deleted.';
        } else {
            $classes = $pdo->query('SELECT id, class_name FROM classes ORDER BY sort_order ASC, id ASC')->fetchAll(PDO::FETCH_ASSOC);
        }
    } catch (Throwable $e) {
        error_log('Could not load admission enquiry editor: ' . $e->getMessage());
        http_response_code(500);
        $enquiry = null;
        $error = 'The application could not be loaded. Please try again.';
    }
}
$_SESSION['admission_enquiry_edit_csrf'] ??= bin2hex(random_bytes(32));
$v = static fn($field) => $h($enquiry[$field] ?? '');
$version = $enquiry ? admissionEnquiryVersion($enquiry) : '';
$photoUrl = schoolPhotoUrl('students', $enquiry['student_image'] ?? null);
$defaultPhotoUrl = schoolPhotoUrl('students', null);
require_once __DIR__ . '/../../includes/header-open.php';
echo '<title>Edit Admission Application - ' . $h($school_name) . '</title>';
require_once __DIR__ . '/../../includes/header-close.php';
require_once __DIR__ . '/../../includes/dashboard-navbar.php';
?>
<!-- admission-enquiry-editor -->
<style>
    .enquiry-edit { max-width: 1140px; }
    .enquiry-edit .card { border-radius: 12px; }
    .enquiry-edit .card-header { background: #f8f9fa; font-weight: 600; }
    #enquiry-photo-preview { width: 100px; height: 120px; object-fit: cover; border-radius: 8px; border: 1px solid #dee2e6; }
    #enquiry-crop-image { display: block; max-width: 100%; }
    .enquiry-crop-stage { height: min(60vh, 480px); }
</style>
<main class="container enquiry-edit py-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <h1 class="h4 mb-0">Edit Admission Application</h1>
        <a href="manage-admission-enquiries.php" class="btn btn-outline-secondary btn-sm"><i class="fas fa-arrow-left me-1"></i>Back to Applications</a>
    </div>
    <?php if ($error): ?>
        <div class="alert alert-danger" role="alert"><?= $h($error) ?></div>
    <?php elseif ($enquiry): ?>
        <div class="d-flex flex-wrap align-items-center gap-2 mb-2">
            <strong>Application #<?= str_pad((string)$enquiry['id'], 6, '0', STR_PAD_LEFT) ?></strong>
            <span class="badge bg-warning text-dark">Pending Review</span>
            <span class="small text-muted">Applied: <?= $v('created_at') ?></span>
        </div>
        <p class="text-muted">Correct the applicant's information and save. The application will remain pending until you approve it.</p>
        <div id="enquiry-edit-message" class="alert d-none" role="status" aria-live="polite"></div>
        <form id="enquiry-edit-form" action="../../api/admin/put/student/update-admission-enquiry.php" method="post" enctype="multipart/form-data"
              data-photo-url="<?= $h($photoUrl) ?>" data-default-photo-url="<?= $h($defaultPhotoUrl) ?>">
            <input type="hidden" name="csrf" value="<?= $h($_SESSION['admission_enquiry_edit_csrf']) ?>">
            <input type="hidden" name="enquiry_id" value="<?= (int)$enquiry['id'] ?>">
            <input type="hidden" name="original_version" value="<?= $h($version) ?>">
            <input type="hidden" name="cropped_image_data" value="">
            <fieldset id="enquiry-edit-fields">
                <div class="card mb-3">
                    <div class="card-header">Student &amp; Application</div>
                    <div class="card-body row g-3">
                        <div class="col-md-6"><label for="enquiry-name" class="form-label">Student Name <span class="text-danger">*</span></label><input id="enquiry-name" name="name" class="form-control" maxlength="100" value="<?= $v('name') ?>" required></div>
                        <div class="col-md-3"><label for="enquiry-gender" class="form-label">Gender <span class="text-danger">*</span></label><select id="enquiry-gender" name="gender" class="form-select" required><option value="">Select gender</option><?php foreach (['Male', 'Female', 'Other'] as $gender): ?><option value="<?= $gender ?>" <?= strcasecmp((string)$enquiry['gender'], $gender) === 0 ? 'selected' : '' ?>><?= $gender ?></option><?php endforeach; ?></select></div>
                        <div class="col-md-3"><label for="enquiry-dob" class="form-label">Date of Birth <span class="text-danger">*</span></label><input id="enquiry-dob" name="date_of_birth" type="date" class="form-control" value="<?= $v('date_of_birth') ?>" max="<?= date('Y-m-d') ?>" required></div>
                        <div class="col-md-6"><label for="enquiry-class" class="form-label">Applied Class <span class="text-danger">*</span></label><select id="enquiry-class" name="class_id" class="form-select" required>
                            <option value="">Select class</option>
                            <?php if (!in_array((int)$enquiry['class_id'], array_map('intval', array_column($classes, 'id')), true)): ?><option value="<?= (int)$enquiry['class_id'] ?>" selected>Previous class unavailable — select a class</option><?php endif; ?>
                            <?php foreach ($classes as $class): ?><option value="<?= (int)$class['id'] ?>" <?= (int)$enquiry['class_id'] === (int)$class['id'] ? 'selected' : '' ?>><?= $h($class['class_name']) ?></option><?php endforeach; ?>
                        </select></div>
                        <div class="col-md-3"><label for="enquiry-year" class="form-label">Academic Year <span class="text-danger">*</span></label><input id="enquiry-year" name="academic_year" type="number" class="form-control" min="2000" max="2200" step="1" value="<?= $v('academic_year') ?>" required></div>
                        <div class="col-md-3"><label for="enquiry-blood" class="form-label">Blood Group</label><select id="enquiry-blood" name="blood_group" class="form-select"><option value="">Not provided</option><?php foreach (['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as $group): ?><option value="<?= $group ?>" <?= strtoupper((string)($enquiry['blood_group'] ?? '')) === $group ? 'selected' : '' ?>><?= $group ?></option><?php endforeach; ?></select></div>
                        <?php foreach (['religion' => ['Religion', 30], 'student_adhaar' => ['Student Aadhaar No.', 20], 'preferred_by' => ['Referred / Preferred By', 100]] as $field => [$label, $limit]): ?>
                            <div class="col-md-4"><label class="form-label" for="enquiry-<?= $field ?>"><?= $label ?></label><input class="form-control" id="enquiry-<?= $field ?>" name="<?= $field ?>" maxlength="<?= $limit ?>" value="<?= $v($field === 'student_adhaar' ? 'student_adhaar_no' : $field) ?>"></div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="card mb-3">
                    <div class="card-header">Parents &amp; Contact</div>
                    <div class="card-body row g-3">
                        <?php foreach (['father_name' => ["Father's Name", 100], 'mother_name' => ["Mother's Name", 100], 'father_occupation' => ["Father's Occupation", 100], 'mother_occupation' => ["Mother's Occupation", 100], 'father_adhaar' => ["Father's Aadhaar No.", 20], 'mother_adhaar' => ["Mother's Aadhaar No.", 20], 'phone_number' => ['Primary Phone', 10], 'alternate_phone_number' => ['Alternate Phone', 10], 'email' => ['Email', 100]] as $field => [$label, $limit]):
                            $required = in_array($field, ['father_name', 'phone_number'], true);
                            $isPhone = in_array($field, ['phone_number', 'alternate_phone_number'], true);
                            $storedField = str_ends_with($field, '_adhaar') ? $field . '_no' : $field;
                        ?>
                            <div class="col-md-6"><label class="form-label" for="enquiry-<?= $field ?>"><?= $h($label) ?><?= $required ? ' <span class="text-danger">*</span>' : '' ?></label><input class="form-control" id="enquiry-<?= $field ?>" name="<?= $field ?>" type="<?= $field === 'email' ? 'email' : ($isPhone ? 'tel' : 'text') ?>" maxlength="<?= $limit ?>" value="<?= $v($storedField) ?>" <?= $isPhone ? 'pattern="[0-9]{10}" inputmode="numeric" title="Enter a 10-digit phone number"' : '' ?> <?= $required ? 'required' : '' ?>></div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="card mb-3">
                    <div class="card-header">Address</div>
                    <div class="card-body row g-3">
                        <?php foreach (['village' => 'Village / Town', 'post_office' => 'Post Office', 'police_station' => 'Police Station', 'district' => 'District', 'pin_code' => 'PIN Code'] as $field => $label): ?>
                            <div class="col-md-4"><label class="form-label" for="enquiry-<?= $field ?>"><?= $label ?></label><input class="form-control enquiry-address-part" id="enquiry-<?= $field ?>" name="<?= $field ?>" maxlength="<?= $field === 'pin_code' ? 10 : 50 ?>" value="<?= $v($field) ?>"></div>
                        <?php endforeach; ?>
                        <div class="col-12"><label class="form-label" for="enquiry-address">Full Address</label><textarea class="form-control" id="enquiry-address" name="address" rows="2"><?= $v('address') ?></textarea><div class="form-text">Updating the fields above fills this address. You can also edit it directly.</div></div>
                    </div>
                </div>
                <div class="card mb-3">
                    <div class="card-header">Student Photo</div>
                    <div class="card-body d-flex flex-wrap align-items-start gap-3">
                        <img id="enquiry-photo-preview" src="<?= $h($photoUrl) ?>" alt="Student photo" width="100" height="120">
                        <div class="flex-grow-1">
                            <label for="enquiry-photo-file" class="form-label">Replace Photo</label>
                            <input id="enquiry-photo-file" name="student_image" type="file" accept="image/jpeg,image/png,image/webp" class="form-control mb-1">
                            <div class="form-text mb-2">JPG, PNG or WebP, up to 5 MB. Crop the replacement before saving.</div>
                            <button id="enquiry-clear-photo" type="button" class="btn btn-outline-secondary btn-sm mb-2" hidden>Discard Replacement</button>
                            <div class="form-check"><input id="enquiry-remove-photo" name="remove_photo" value="1" type="checkbox" class="form-check-input" <?= empty($enquiry['student_image']) ? 'disabled' : '' ?>><label class="form-check-label" for="enquiry-remove-photo">Remove existing photo</label></div>
                        </div>
                    </div>
                </div>
                <div class="d-flex gap-2"><button id="enquiry-save" type="submit" class="btn btn-primary"><i class="fas fa-save me-1"></i>Save Changes</button><a class="btn btn-outline-secondary" href="manage-admission-enquiries.php">Cancel</a></div>
            </fieldset>
        </form>
        <div class="modal fade" id="enquiry-crop-modal" tabindex="-1" aria-labelledby="enquiry-crop-title" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered"><div class="modal-content">
                <div class="modal-header"><h2 id="enquiry-crop-title" class="modal-title fs-5">Crop Student Photo</h2><button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button></div>
                <div class="modal-body"><div class="enquiry-crop-stage"><img id="enquiry-crop-image" alt="Crop replacement photo"></div></div>
                <div class="modal-footer"><button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Cancel</button><button id="enquiry-apply-crop" class="btn btn-primary" type="button" disabled>Use Cropped Photo</button></div>
            </div></div>
        </div>
        <script src="../../assets/js/admission-enquiry-edit.js"></script>
    <?php endif; ?>
</main>
<?php require_once __DIR__ . '/../../includes/body-close.php'; ?>
