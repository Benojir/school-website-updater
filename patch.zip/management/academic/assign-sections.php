<?php
include_once("../../includes/auth-check.php");

// Check admin permission (Standard page check)
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    include_once("../../includes/permission-denied.php");
    exit;
}

// --- STANDARD PAGE LOAD ---
include_once("../../includes/header-open.php");
echo "<title>Assign Sections - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Fetch all classes for the dropdown (Initial Load)
$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
    table th, table td {
        text-align: center;
        vertical-align: middle;
        cursor: pointer; /* Indicates the row is clickable */
    }
    
    /* Style for the selected row */
    .selected-row {
        background-color: #e8f2ff !important; /* Light Blue */
        border-left: 4px solid #0d6efd; /* Blue accent border */
    }

    .loading-overlay {
        position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(255,255,255,0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 10;
        display: none;
    }
</style>

<div class="container mt-4">
    <div class="card shadow position-relative rounded-2 overflow-hidden">
        <!-- Loading Overlay -->
        <div id="cardLoader" class="loading-overlay">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>

        <div class="card-header bg-primary text-white">
            <h3><i class="fas fa-users me-2"></i>Assign Sections</h3>
        </div>
        <div class="card-body">
            <!-- Class Selection Form -->
            <form id="filterForm" class="mb-4">
                <div class="row align-items-end">
                    <div class="col-md-10">
                        <label class="form-label">Class</label>
                        <select class="form-select" name="class_id" id="classSelect" required>
                            <option value="">-- Select Class --</option>
                            <?php foreach ($classes as $c): ?>
                                <option value="<?= $c['id'] ?>">
                                    <?= safe_htmlspecialchars($c['class_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-filter me-2"></i>Fetch
                        </button>
                    </div>
                </div>
            </form>

            <!-- Main Content Area (Hidden initially) -->
            <div id="assignmentArea" style="display: none;">
                
                <!-- Class Info Alert -->
                <div class="alert alert-info mb-4">
                    <h5 id="classNameDisplay">Class: </h5>
                    <p class="mb-0"><span id="studentCountDisplay">0</span> students need section assignment</p>
                </div>

                <div id="noSectionsAlert" class="alert alert-warning" style="display:none;">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    No sections available for this class. Please create sections first.
                </div>

                <div id="allAssignedAlert" class="alert alert-success" style="display:none;">
                    <i class="fas fa-check-circle me-2"></i>
                    All students in this class already have sections assigned.
                </div>

                <!-- Assignment Form -->
                <form id="sectionAssignmentForm" style="display:none;">
                    <input type="hidden" name="class_id" id="hiddenClassId" value="">

                    <div class="row mb-3 g-2">
                        <!-- Bulk Select -->
                        <div class="col-md-3">
                            <label class="form-label">Select Section</label>
                            <select class="form-control" id="bulkSectionSelect">
                                <option value="">-- Select Section --</option>
                                <!-- Populated via JS -->
                            </select>
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <button type="button" id="assignBulkBtn" class="btn btn-primary w-100">
                                <i class="fas fa-arrow-down me-2"></i>Assign Selected
                            </button>
                        </div>
                        
                        <!-- Search & Sort -->
                        <div class="col-md-3">
                             <label class="form-label">Sort By</label>
                             <select class="form-select" id="sortBy">
                                <option value="default" selected>Recently Admitted</option>
                                <option value="default_reverse">Recently Admitted (Reverse)</option>
                                <option value="name_asc">Name (A-Z)</option>
                                <option value="name_desc">Name (Z-A)</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="search_input" class="form-label">Search</label>
                            <input type="text" class="form-control" id="search_input" placeholder="Name or ID..." />
                        </div>
                    </div>

                    <div class="table-responsive">
                        <!-- Selected Students Summary -->
                        <div class="alert alert-info mb-2" id="selectedSummary" style="display: none;">
                            <strong><span id="selectedCount">0</span> student(s) selected</strong>
                        </div>

                        <table class="table table-bordered table-hover" id="studentsTable">
                            <thead class="table-dark">
                                <tr>
                                    <th width="5%">
                                        <input type="checkbox" id="selectAll">
                                    </th>
                                    <th width="10%">Student ID</th>
                                    <th width="25%">Name</th>
                                    <th width="25%">Father</th>
                                    <th width="30%">Address</th>
                                    <th width="10%">Assigned Section</th>
                                </tr>
                            </thead>
                            <tbody id="studentsTableBody">
                                <!-- Rows generated via JS -->
                            </tbody>
                        </table>
                    </div>

                    <div class="text-center mt-4">
                        <button type="submit" class="btn btn-success" id="saveButton">
                            <i class="fas fa-save me-2"></i>Save All Assignments
                        </button>
                    </div>
                </form>
            </div>
            
            <!-- Initial State Message -->
            <div id="initialStateMsg" class="alert alert-secondary">
                <i class="fas fa-info-circle me-2"></i>
                Select a class to begin assigning sections.
            </div>

        </div>
    </div>
</div>

<script>
    // Global State
    let currentStudents = [];
    let currentSections = [];
    let assignments = {}; // Map student_id -> section_id (for UI state)

    // 1. Color Palette for Sections
    const badgeClasses = [
        'bg-primary', 'bg-success', 'bg-danger', 
        'bg-warning text-dark', 'bg-info text-dark', 
        'bg-dark', 'bg-secondary', 'bg-indigo'
    ];

    $(document).ready(function() {
        
        // Handle Filter Form Submit (AJAX)
        $('#filterForm').on('submit', function(e) {
            e.preventDefault();
            const classId = $('#classSelect').val();
            if(!classId) {
                toastr.warning("Please select a class.");
                return;
            }
            loadClassData(classId);
        });

        // Search Input
        $('#search_input').on('input', function() {
            renderTable();
        });

        // Sort Change
        $('#sortBy').on('change', function() {
            renderTable();
        });

        // Select All Checkbox
        $('#selectAll').change(function() {
            const isChecked = $(this).prop('checked');
            $('.student-check:visible').prop('checked', isChecked).trigger('change');
        });

        // --- NEW: Row Click Selection Logic ---
        $('#studentsTableBody').on('click', 'tr', function(e) {
            // Prevent double toggle if user clicked the checkbox directly
            if ($(e.target).is('input[type="checkbox"]')) return;
            
            // Find the checkbox in this row and toggle it
            const checkbox = $(this).find('.student-check');
            checkbox.prop('checked', !checkbox.prop('checked')).trigger('change');
        });

        // --- UPDATED: Individual Checkbox Change ---
        $('#studentsTableBody').on('change', '.student-check', function() {
            updateSelectedSummary();
            
            const sId = $(this).val();
            const row = $(this).closest('tr');
            const isChecked = $(this).prop('checked');

            // 2. Toggle Background Color on Selection
            if (isChecked) {
                row.addClass('selected-row');
            } else {
                row.removeClass('selected-row');
            }

            // Update data model
            const student = currentStudents.find(s => s.id == sId);
            if(student) {
                student.selected = isChecked;
            }
        });

        // Bulk Assign Button
        $('#assignBulkBtn').click(function() {
            const sectionId = $('#bulkSectionSelect').val();
            const sectionName = $('#bulkSectionSelect option:selected').text();

            if (!sectionId) {
                toastr.error('Please select a section first');
                return;
            }

            const checkedBoxes = $('.student-check:checked');
            if (checkedBoxes.length === 0) {
                toastr.error('Please select at least one student');
                return;
            }

            // Get unique color class for this section
            const colorClass = getSectionBadgeClass(sectionId);

            checkedBoxes.each(function() {
                const sId = $(this).val();
                
                // Update internal state
                assignments[sId] = { id: sectionId, name: sectionName };
                
                // Update UI visually with dynamic color
                const row = $(this).closest('tr');
                row.find('.section-display').html(
                    `<span class="badge ${colorClass}">${sectionName}</span>
                     <input type="hidden" name="sections[${sId}]" value="${sectionId}">`
                );
                
                // Uncheck and remove selection highlight
                const checkbox = $(this);
                checkbox.prop('checked', false).trigger('change'); 
                
                // Update data model
                const student = currentStudents.find(s => s.id == sId);
                if(student) student.selected = false;
            });

            $('#selectAll').prop('checked', false);
            toastr.success(`Assigned ${checkedBoxes.length} students to ${sectionName}`);
            updateSelectedSummary();
        });

        // Handle Final Save
        $('#sectionAssignmentForm').submit(function(e) {
            e.preventDefault();

            if ($(this).find('input[name^="sections["]').length === 0) {
                toastr.error('No section assignments made');
                return;
            }

            $('#saveButton').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Saving...');

            const formData = $(this).serialize();

            $.ajax({
                url: '../../api/admin/put/class/save-assign-sections.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        setTimeout(() => {
                            loadClassData($('#hiddenClassId').val()); 
                        }, 1500);
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr) {
                    toastr.error('An error occurred while saving sections');
                    console.error('Error:', xhr.responseText);
                },
                complete: function() {
                    $('#saveButton').prop('disabled', false).html('<i class="fas fa-save me-2"></i>Save All Assignments');
                }
            });
        });

        // Check if URL has class_id
        const urlParams = new URLSearchParams(window.location.search);
        const preClassId = urlParams.get('class_id');
        if(preClassId) {
            $('#classSelect').val(preClassId);
            loadClassData(preClassId);
        }
    });

    // --- Core Functions ---

    function loadClassData(classId) {
        $('#cardLoader').show();
        $('#assignmentArea').hide();
        $('#initialStateMsg').hide();
        
        currentStudents = [];
        currentSections = [];
        assignments = {};
        $('#studentsTableBody').empty();

        $.ajax({
            url: '../../api/admin/get/class/fetch-section-assignment-data.php',
            type: 'GET',
            data: { class_id: classId },
            dataType: 'json',
            success: function(response) {
                if(response.success) {
                    currentStudents = response.students.map(s => ({...s, selected: false}));
                    currentSections = response.sections;
                    
                    $('#classNameDisplay').text('Class: ' + response.class_name);
                    $('#studentCountDisplay').text(currentStudents.length);
                    $('#hiddenClassId').val(classId);

                    const secSelect = $('#bulkSectionSelect');
                    secSelect.empty().append('<option value="">-- Select Section --</option>');
                    
                    if(currentSections.length === 0) {
                        $('#noSectionsAlert').show();
                        $('#sectionAssignmentForm').hide();
                        $('#allAssignedAlert').hide();
                    } else if (currentStudents.length === 0) {
                         $('#noSectionsAlert').hide();
                         $('#sectionAssignmentForm').hide();
                         $('#allAssignedAlert').show();
                    } else {
                        // Populate sections with colors for reference? No, just list them.
                        currentSections.forEach(sec => {
                            secSelect.append(`<option value="${sec.id}">${sec.section_name}</option>`);
                        });
                        $('#noSectionsAlert').hide();
                        $('#allAssignedAlert').hide();
                        $('#sectionAssignmentForm').show();
                    }

                    renderTable();
                    $('#assignmentArea').fadeIn();
                    
                    const newUrl = window.location.pathname + '?class_id=' + classId;
                    window.history.pushState({path:newUrl}, '', newUrl);

                } else {
                    toastr.error(response.message);
                }
            },
            error: function(xhr) {
                console.error(xhr.responseText);
                toastr.error("Failed to load class data.");
            },
            complete: function() {
                $('#cardLoader').hide();
            }
        });
    }

    function renderTable() {
        const tbody = $('#studentsTableBody');
        tbody.empty();

        const searchTerm = $('#search_input').val().toLowerCase();
        const sortOrder = $('#sortBy').val();

        let filtered = currentStudents.filter(s => {
            return s.student_id.toLowerCase().includes(searchTerm) || 
                   s.name.toLowerCase().includes(searchTerm);
        });

        // --- UPDATED SORT LOGIC START ---
        filtered.sort((a, b) => {
            if (sortOrder === 'default') {
                // Sort by ID (Assuming standard database order)
                return parseInt(b.id) - parseInt(a.id);
            }

            if (sortOrder === 'default_reverse') {
                // Sort by ID (Assuming standard database order)
                return parseInt(a.id) - parseInt(b.id);
            }
            
            const nameA = a.name.toLowerCase();
            const nameB = b.name.toLowerCase();
            
            if (sortOrder === 'name_asc') {
                return nameA.localeCompare(nameB);
            } else {
                return nameB.localeCompare(nameA); // name_desc
            }
        });
        // --- UPDATED SORT LOGIC END ---
        
        if(filtered.length === 0) {
            tbody.append('<tr class="table-warning"><td colspan="6" class="text-center">No students found</td></tr>');
            return;
        }

        filtered.forEach(student => {
            // ... (rest of your existing render code remains exactly the same)
            let assignmentHtml = '<span class="text-muted">Not assigned</span>';
            if(assignments[student.id]) {
                const colorClass = getSectionBadgeClass(assignments[student.id].id);
                assignmentHtml = `<span class="badge ${colorClass}">${assignments[student.id].name}</span>
                                  <input type="hidden" name="sections[${student.id}]" value="${assignments[student.id].id}">`;
            }

            const isChecked = student.selected ? 'checked' : '';
            const rowClass = student.selected ? 'selected-row' : '';

            const row = `
                <tr data-id="${student.id}" class="${rowClass}">
                    <td>
                        <input type="checkbox" class="student-check" value="${student.id}" ${isChecked}>
                    </td>
                    <td>${escapeHtml(student.student_id)}</td>
                    <td>${escapeHtml(student.name)}</td>
                    <td>${escapeHtml(student.father_name)}</td>
                    <td>${escapeHtml(student.address)}</td>
                    <td class="section-display" data-student="${student.id}">
                        ${assignmentHtml}
                    </td>
                </tr>
            `;
            tbody.append(row);
        });
        
        updateSelectedSummary();
    }

    function updateSelectedSummary() {
        const count = $('.student-check:checked').length;
        $('#selectedCount').text(count);
        if (count > 0) {
            $('#selectedSummary').show();
        } else {
            $('#selectedSummary').hide();
        }
        
        const totalVisible = $('.student-check').length;
        if(totalVisible > 0 && count === totalVisible) {
            $('#selectAll').prop('checked', true);
        } else {
            $('#selectAll').prop('checked', false);
        }
    }

    // Helper: Get unique color for a section ID
    function getSectionBadgeClass(sectionId) {
        // Find index of this section in the currentSections array
        const index = currentSections.findIndex(sec => sec.id == sectionId);
        
        if (index === -1) return 'bg-success'; // Fallback
        
        // Use modulo to cycle through colors if there are more sections than colors
        return badgeClasses[index % badgeClasses.length];
    }
</script>

<?php include_once("../../includes/body-close.php"); ?>