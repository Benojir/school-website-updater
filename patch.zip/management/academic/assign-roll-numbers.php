<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Assign Roll Numbers - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    include_once("../../includes/permission-denied.php");
    exit;
}

// Fetch all classes for the dropdown
$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY class_name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Initialize variables
$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : null;
$section_id = isset($_GET['section_id']) ? (int)$_GET['section_id'] : null;
$students = [];
$sections = [];
$class = null;
$section = null;

// If class is selected, fetch its sections
if ($class_id) {
    $stmt = $pdo->prepare("SELECT id, section_name FROM sections WHERE class_id = ? ORDER BY section_name ASC");
    $stmt->execute([$class_id]);
    $sections = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get class name
    $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
    $stmt->execute([$class_id]);
    $class = $stmt->fetch(PDO::FETCH_ASSOC);

    // Get section name if section is selected
    if ($section_id) {
        $stmt = $pdo->prepare("SELECT section_name FROM sections WHERE id = ?");
        $stmt->execute([$section_id]);
        $section = $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Fetch students without roll numbers
    $whereClause = "s.class_id = ? AND (s.roll_no IS NULL OR s.roll_no <= 0) AND s.status = 'Active'";
    $params = [$class_id];

    if ($section_id) {
        $whereClause .= " AND s.section_id = ?";
        $params[] = $section_id;
    } else {
        $whereClause .= " AND (s.section_id IS NULL OR s.section_id = 0)";
    }

    $stmt = $pdo->prepare("
        SELECT s.id, s.student_id, s.name, s.father_name, s.address 
        FROM students s
        WHERE $whereClause
        ORDER BY s.name ASC
    ");
    $stmt->execute($params);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<style>
    /* For Chrome, Safari, Edge, Opera */
    input[type=number]::-webkit-inner-spin-button,
    input[type=number]::-webkit-outer-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    /* For Firefox */
    input[type=number] {
        appearance: textfield;
    }
</style>

<div class="container mt-4">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h3><i class="fas fa-sort-numeric-up me-2"></i>Assign Roll Numbers</h3>
        </div>
        <div class="card-body">
            <!-- Class and Section Selection Form -->
            <form method="get" id="filterForm" class="mb-4">
                <div class="row">
                    <div class="col-md-6">
                        <label class="form-label">Class</label>
                        <select class="form-select" name="class_id" id="classSelect" required>
                            <option value="">-- Select Class --</option>
                            <?php foreach ($classes as $c): ?>
                                <option value="<?= $c['id'] ?>" <?= $class_id == $c['id'] ? 'selected' : '' ?>>
                                    <?= safe_htmlspecialchars($c['class_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Section</label>
                        <select class="form-select" name="section_id" id="sectionSelect" <?= !$class_id ? 'disabled' : '' ?>>
                            <option value="">-- All Students Without Section --</option>
                            <?php if ($class_id): ?>
                                <?php foreach ($sections as $s): ?>
                                    <option value="<?= $s['id'] ?>" <?= $section_id == $s['id'] ? 'selected' : '' ?>>
                                        <?= safe_htmlspecialchars($s['section_name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>
                <div class="text-center mt-3">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter me-2"></i>Filter Students
                    </button>
                    <?php if ($class_id && $section_id): ?>
                        <a href="assign-roll-numbers.php" class="btn btn-secondary">
                            <i class="fas fa-times me-2"></i>Clear Filters
                        </a>
                    <?php endif; ?>
                </div>
            </form>

            <?php if ($class_id): ?>
                <!-- Display class/section info -->
                <div class="alert alert-info mb-4">
                    <h5>Class: <?= safe_htmlspecialchars($class['class_name']) ?>
                        <?php if ($section_id): ?>
                            - Section: <?= safe_htmlspecialchars($section['section_name']) ?>
                        <?php else: ?>
                            (Students without section)
                        <?php endif; ?>
                    </h5>
                    <p class="mb-0"><?= count($students) ?> students need roll numbers assigned</p>
                </div>

                <?php if (empty($students)): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle me-2"></i>
                        <?php if ($section_id): ?>
                            All students in this class section already have roll numbers assigned.
                        <?php else: ?>
                            All students in this class without sections already have roll numbers assigned.
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <!-- Roll Number Assignment Form -->
                    <form id="rollNumberForm">
                        <input type="hidden" name="class_id" value="<?= $class_id ?>">
                        <input type="hidden" name="section_id" value="<?= $section_id ?>">

                        <div class="row mb-3">
                            <div class="col-md-12">
                                <label for="search_input" class="form-label">Search:</label>
                                <input type="text" class="form-control" id="search_input" placeholder="Search by name or student id" />
                            </div>
                        </div>

                        <!-- Roll Numbers Summary -->
                        <div class="alert alert-info mb-2" id="rollNumbersSummary">
                            <strong><span id="assignedCount">0</span> student(s) have roll numbers assigned</strong>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-bordered" id="studentsTable">
                                <thead class="table-dark">
                                    <tr>
                                        <th width="15%">Student ID</th>
                                        <th width="20%">Name</th>
                                        <th width="20%">Father</th>
                                        <th width="25%">Address</th>
                                        <th width="20%">Roll Number</th>
                                    </tr>
                                </thead>
                                <tbody id="studentsTableBody">
                                    <?php foreach ($students as $student): ?>
                                        <tr data-student-id="<?= $student['id'] ?>">
                                            <td><?= safe_htmlspecialchars($student['student_id']) ?></td>
                                            <td><?= safe_htmlspecialchars($student['name']) ?></td>
                                            <td><?= safe_htmlspecialchars($student['father_name']) ?></td>
                                            <td><?= safe_htmlspecialchars($student['address']) ?></td>
                                            <td>
                                                <input type="number" class="form-control roll-number-input"
                                                    name="roll_numbers[<?= $student['id'] ?>]"
                                                    min="1" required>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="text-center mt-4">
                            <button type="submit" class="btn btn-success" id="saveButton">
                                <i class="fas fa-save me-2"></i>Save Roll Numbers
                            </button>
                        </div>
                    </form>
                <?php endif; ?>
            <?php elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['class_id'])): ?>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Please select a class to view students needing roll numbers.
                </div>
            <?php else: ?>
                <div class="alert alert-secondary">
                    <i class="fas fa-info-circle me-2"></i>
                    Select a class to begin assigning roll numbers.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
    /* Add this to your CSS */
    .is-invalid {
        border-color: #dc3545 !important;
        background-color: #fff5f5 !important;
    }

    .invalid-feedback {
        color: #dc3545;
        font-size: 0.875em;
        margin-top: 0.25rem;
    }
</style>

<script>
    // Function to validate roll number inputs
    function validateRollNumbers() {
        const inputs = $('.roll-number-input');
        const values = {};
        let hasErrors = false;

        // Reset all inputs to valid state first
        inputs.each(function() {
            $(this).removeClass('is-invalid');
            $(this).next('.invalid-feedback').remove();
        });

        // Check each input
        inputs.each(function() {
            const input = $(this);
            const value = input.val().trim();

            // Check if empty (but don't mark as error since it's not required until submission)
            if (value === '') return;

            // Check if numeric
            if (!/^\d+$/.test(value)) {
                input.addClass('is-invalid');
                input.after('<div class="invalid-feedback">Only numbers are allowed</div>');
                hasErrors = true;
                return;
            }

            // Check for duplicates
            if (values[value]) {
                input.addClass('is-invalid');
                input.after('<div class="invalid-feedback">Duplicate roll number</div>');
                // Also highlight the original duplicate
                $(`[name="${values[value]}"]`).addClass('is-invalid');
                hasErrors = true;
            } else {
                values[value] = input.attr('name');
            }
        });

        $('input[type="number"]').each(function() {
            let value = $(this).val();
            value = value.replace(/\s+/g, '');
            $(this).val(value);
        });


        return !hasErrors;
    }

    // Function to update roll numbers summary and reorder rows
    function updateRollNumbersDisplay() {
        let assignedCount = 0;
        const tbody = $('#studentsTableBody');
        const allRows = tbody.find('tr');

        // Count and move rows with roll numbers to top
        allRows.each(function() {
            const input = $(this).find('.roll-number-input');
            if (input.val().trim() !== '') {
                assignedCount++;
                tbody.prepend($(this));
            }
        });

        // Update summary
        $('#assignedCount').text(assignedCount);
        if (assignedCount > 0) {
            $('#rollNumbersSummary').show();
        } else {
            $('#rollNumbersSummary').hide();
        }
    }

    $(document).ready(function() {
        // Store original student rows for filtering
        const originalRows = $('#studentsTableBody tr').clone();

        // Initialize display
        updateRollNumbersDisplay();

        // Update display when roll numbers change
        $('body').on('input', '.roll-number-input', function() {
            validateRollNumbers();
        });

        $('body').on('blur', '.roll-number-input', function() {
            console.log('Roll number input blurred');
            // Your code here, e.g.
            validateRollNumbers();
            updateRollNumbersDisplay();
        });


        // Real-time search filtering
        $('#search_input').on('input', function() {
            const searchText = $(this).val().toLowerCase();

            // Reset to original rows when search is empty
            // if (searchText === '') {
            //     $('#studentsTableBody').html(originalRows.clone());
            //     updateRollNumbersDisplay();
            //     return;
            // }

            // Filter rows
            const filteredRows = originalRows.filter(function() {
                const studentId = $(this).find('td:eq(0)').text().toLowerCase();
                const studentName = $(this).find('td:eq(1)').text().toLowerCase();
                return studentId.includes(searchText) || studentName.includes(searchText);
            });

            // Update table with filtered rows
            $('#studentsTableBody').html(filteredRows);
            updateRollNumbersDisplay();
        });

        // Load sections when class is selected
        $('#classSelect').change(function() {
            const classId = $(this).val();
            const sectionSelect = $('#sectionSelect');

            if (!classId) {
                sectionSelect.prop('disabled', true);
                sectionSelect.html('<option value="">-- All Students Without Section --</option>');
                return;
            }

            // Show loading state
            sectionSelect.prop('disabled', true);
            sectionSelect.html('<option value="">Loading sections...</option>');

            // Fetch sections via AJAX
            $.ajax({
                url: '../../api/admin/get/class/get-sections-by-class.php',
                type: 'GET',
                data: {
                    class_id: classId
                },
                dataType: 'json',
                success: function(sections) {
                    sectionSelect.html('<option value="">-- All Students Without Section --</option>');

                    if (sections.length > 0) {
                        sections.forEach(function(section) {
                            sectionSelect.append(
                                $('<option></option>').val(section.id).text(section.section_name)
                            );
                        });
                        sectionSelect.prop('disabled', false);
                    } else {
                        sectionSelect.append(
                            $('<option></option>').val('').text('No sections available')
                        );
                    }
                },
                error: function(xhr) {
                    sectionSelect.html('<option value="">Error loading sections</option>');
                    console.error('Error loading sections:', xhr.statusText);
                }
            });
        });

        // Preselect section if coming from URL with both parameters
        <?php if ($class_id && $section_id): ?>
            $('#classSelect').trigger('change');
        <?php endif; ?>

        // Handle roll number form submission
        $('#rollNumberForm').submit(function(e) {
            e.preventDefault();

            if (!validateRollNumbers()) {
                toastr.error('Please fix the errors in roll numbers before saving');
                return;
            }

            const formData = $(this).serialize();

            $('#saveButton').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Saving...');

            $.ajax({
                url: '../../api/admin/put/student/save-roll-numbers.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        setTimeout(() => {
                            window.location.reload(); // Refresh to show updated list
                        }, 1500);
                    } else {
                        toastr.error(response.message);
                        Swal.fire({
                            title: "Error",
                            text: response.message,
                            icon: "error",
                            allowOutsideClick: false,
                            confirmButtonText: "OK",
                            confirmButtonColor: "#d33"
                        });
                    }
                },
                error: function(xhr) {
                    toastr.error('An error occurred while saving roll numbers');
                    console.error('Error:', xhr.responseText);
                },
                complete: function() {
                    $('#saveButton').prop('disabled', false).html('<i class="fas fa-save me-2"></i>Save Roll Numbers');
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>