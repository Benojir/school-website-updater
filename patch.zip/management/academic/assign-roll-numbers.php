<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Assign Roll Numbers - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    include_once("../../includes/permission-denied.php");
    exit;
}

// Fetch all classes for the dropdown (Initial load)
$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
    table th,
    table td {
        text-align: center;
        vertical-align: middle;
        cursor: pointer;
        /* Indicates the row is clickable */
    }

    /* For Chrome, Safari, Edge, Opera */
    input[type=number]::-webkit-inner-spin-button,
    input[type=number]::-webkit-outer-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    /* For Firefox */
    input[type=number] {
        appearance: textfield;
    }

    .is-invalid {
        border-color: #dc3545 !important;
        background-color: #fff5f5 !important;
    }

    .invalid-feedback {
        color: #dc3545;
        font-size: 0.875em;
        margin-top: 0.25rem;
    }

    #loadingSpinner {
        display: none;
    }
</style>

<div class="container mt-4">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h3><i class="fas fa-sort-numeric-up me-2"></i>Assign Roll Numbers</h3>
        </div>
        <div class="card-body">
            <!-- Filter Controls -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <label class="form-label">Class</label>
                    <select class="form-select" id="classSelect">
                        <option value="">-- Select Class --</option>
                        <?php foreach ($classes as $c): ?>
                            <option value="<?= $c['id'] ?>">
                                <?= safe_htmlspecialchars($c['class_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Section</label>
                    <select class="form-select" id="sectionSelect" disabled>
                        <option value="">-- Select Section --</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Sort By</label>
                    <select class="form-select" id="sortSelect" disabled>
                        <option value="name_asc">Student Name (A-Z)</option>
                        <option value="name_desc">Student Name (Z-A)</option>
                        <option value="father_asc">Father Name (A-Z)</option>
                        <option value="father_desc">Father Name (Z-A)</option>
                    </select>
                </div>
            </div>

            <div class="text-center mb-4">
                <button type="button" class="btn btn-primary" id="loadStudentsBtn" disabled>
                    <i class="fas fa-search me-2"></i>Load Students
                </button>
            </div>

            <!-- Loading Spinner -->
            <div id="loadingSpinner" class="text-center py-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2 text-muted">Fetching students...</p>
            </div>

            <!-- Content Area -->
            <div id="studentsContainer" style="display:none;">

                <!-- Info Alert -->
                <div class="alert alert-info mb-4">
                    <h5 id="classInfoTitle">Class Details</h5>
                    <p class="mb-0"><span id="studentCount">0</span> students need roll numbers assigned</p>
                </div>

                <div id="noStudentsMsg" class="alert alert-success" style="display:none;">
                    <i class="fas fa-check-circle me-2"></i>
                    All students in this selection already have roll numbers assigned.
                </div>

                <!-- Assignment Form -->
                <form id="rollNumberForm" style="display:none;">
                    <input type="hidden" name="class_id" id="formClassId">
                    <input type="hidden" name="section_id" id="formSectionId">

                    <label for="search_input" class="form-label">Search in list:</label>
                    <div class="row mb-3">
                        <div class="col-md-6 mb-2">
                            <input type="text" class="form-control" id="search_input" placeholder="Quick search by name or ID..." />
                        </div>
                        <div class="col-md-6">
                            <div class="input-group">
                                <select class="form-select" id="roll_number_strategy">
                                    <option value="" selected disabled>Select a roll number strategy</option>
                                    <option value="by_exam_rank">Assign by latest exam rank</option>
                                    <option value="auto_increment">Auto-increment from current max</option>
                                    <option value="preserve_order">Preserve current order (starting from 1)</option>
                                </select>
                                <button class="btn btn-outline-secondary" type="button" id="roll_number_strategy_btn">Fill Inputs</button>
                            </div>
                        </div>
                    </div>

                    <!-- Summary -->
                    <div class="alert alert-info mb-2" id="rollNumbersSummary" style="display:none;">
                        <strong><span id="assignedCount">0</span> student(s) have roll numbers assigned</strong>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="studentsTable">
                            <thead class="table-dark">
                                <tr>
                                    <th width="15%">Student ID</th>
                                    <th width="20%">Name</th>
                                    <th width="20%">Father Name</th>
                                    <th width="25%">Address</th>
                                    <th width="20%">Roll Number</th>
                                </tr>
                            </thead>
                            <tbody id="studentsTableBody">
                                <!-- Rows will be populated via JS -->
                            </tbody>
                        </table>
                    </div>

                    <div class="text-center mt-4">
                        <button type="submit" class="btn btn-success" id="saveButton">
                            <i class="fas fa-save me-2"></i>Save Roll Numbers
                        </button>
                    </div>
                </form>
            </div>

            <!-- Initial State Message -->
            <div id="initialStateMsg" class="alert alert-secondary text-center">
                <i class="fas fa-info-circle me-2"></i>
                Select a class to begin assigning roll numbers.
            </div>

        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

        let cachedRollNumbers = {};

        // --- Event Listeners ---

        // 1. Class Selection Change
        $('#classSelect').change(function() {
            cachedRollNumbers = {};
            const classId = $(this).val();
            const sectionSelect = $('#sectionSelect');
            const loadBtn = $('#loadStudentsBtn');
            const sortSelect = $('#sortSelect');

            // Reset UI
            resetStudentView();
            sectionSelect.html('<option value="">-- Select Section --</option>').prop('disabled', true);
            loadBtn.prop('disabled', true);
            sortSelect.prop('disabled', true);

            if (classId) {
                // Fetch Sections
                $.ajax({
                    url: '../../api/admin/get/class/get-sections-by-class.php',
                    type: 'GET',
                    data: {
                        class_id: classId
                    },
                    dataType: 'json',
                    success: function(sections) {
                        if (sections.length > 0) {
                            sections.forEach(function(section) {
                                sectionSelect.append(
                                    $('<option></option>').val(section.id).text(section.section_name)
                                );
                            });
                            sectionSelect.prop('disabled', false);
                        } else {
                            sectionSelect.append($('<option></option>').val('0').text('No Sections (Default)'));
                            // If no sections, we effectively select "Default" implicitly or force user to select it
                            // Here we let them select the "No Sections" option
                            sectionSelect.prop('disabled', false);
                        }
                        loadBtn.prop('disabled', false);
                        sortSelect.prop('disabled', false);
                    },
                    error: function() {
                        toastr.error('Error loading sections');
                    }
                });
            }
        });

        // 2. Load Students Button Click
        $('#loadStudentsBtn').click(function() {
            loadStudents();
        });

        // 3. Sort Change (Auto-reload if data is visible)
        $('#sortSelect').change(function() {
            if ($('#studentsContainer').is(':visible')) {
                loadStudents();
            }
        });

        // 4. Real-time Search within loaded table
        $('#search_input').on('input', function() {
            const searchText = $(this).val().toLowerCase();
            const rows = $('#studentsTableBody tr');

            rows.each(function() {
                const row = $(this);
                const text = row.text().toLowerCase();
                if (text.indexOf(searchText) === -1) {
                    row.hide();
                } else {
                    row.show();
                }
            });
        });

        // 5. Input Validation on typing
        $('body').on('input', '.roll-number-input', function() {
            validateRollNumbers();
            updateRollNumbersDisplay();
        });

        // --- Save Submission ---
        $('#rollNumberForm').submit(function(e) {
            e.preventDefault();

            if (!validateRollNumbers()) {
                toastr.error('Please fix duplicates or errors before saving.');
                return;
            }

            const btn = $('#saveButton');
            const originalBtnText = btn.html();
            btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Saving...');

            $.ajax({
                url: '../../api/admin/put/class/save-assigned-roll-numbers.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        Swal.fire({
                            title: "Success!",
                            text: "Roll numbers assigned successfully.",
                            icon: "success",
                            timer: 2000,
                            showConfirmButton: false,
                            customClass: {
                                popup: 'rounded-4 shadow-lg'
                            }
                        }).then(() => {
                            loadStudents(); // Reload table to refresh list
                        });
                    } else {
                        showErrorAlert(response.message);
                    }
                },
                error: function(xhr) {
                    showErrorAlert('Server error occurred');
                    console.error(xhr.responseText);
                },
                complete: function() {
                    btn.prop('disabled', false).html(originalBtnText);
                }
            });
        });

        // --- Roll Number Strategy Button ---
        $('#roll_number_strategy_btn').click(function() {
            const strategy = $('#roll_number_strategy').val();
            const inputs = $('.roll-number-input:visible');

            if (!strategy) {
                toastr.warning('Please select a roll number strategy');
                return;
            }

            if (inputs.length === 0) {
                toastr.info('No visible students to assign roll numbers to.');
                return;
            }

            if (strategy === 'by_exam_rank') {
                // Fetch current max roll number via AJAX
                const classId = $('#formClassId').val();
                const sectionId = $('#formSectionId').val();

                $.ajax({
                    url: '../../api/admin/get/class/get-roll-numbers-suggestions.php',
                    type: 'GET',
                    data: {
                        first_student_id: inputs.first().closest('tr').data('student-id'),
                        last_student_id: inputs.last().closest('tr').data('student-id'),
                        class_id: classId,
                        section_id: sectionId
                    },
                    dataType: 'json',
                    success: function(response) {

                        if (response.success == false) {
                            toastr.error('Error fetching roll number suggestions');
                            return;
                        }

                        toastr.info(response.message || 'Roll number suggestions fetched');
                        console.log(response);

                        response.suggestions.forEach(function(suggestion) {
                            const input = $(`#roll_number_${suggestion.student_id}`);
                            if (input.length && input.is(':visible')) {
                                input.val(suggestion.suggested_roll_no);
                            }
                        });

                        updateRollNumbersDisplay();
                        validateRollNumbers();
                    },
                    error: function(e) {
                        toastr.error('Error fetching roll number suggestions');
                        console.error(e.responseText);
                    }
                });
                return; // Exit to wait for AJAX

            } else if (strategy === 'auto_increment') {
                // Fetch current max roll number via AJAX
                const classId = $('#formClassId').val();
                const sectionId = $('#formSectionId').val();

                $.ajax({
                    url: '../../api/admin/get/class/get-max-roll-number.php',
                    type: 'GET',
                    data: {
                        class_id: classId,
                        section_id: sectionId
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success == false) {
                            toastr.error('Error fetching max roll number');
                            return;
                        }

                        let start = response.max_roll + 1;
                        inputs.each(function() {
                            $(this).val(start++);
                        });
                        updateRollNumbersDisplay();
                        validateRollNumbers();
                    },
                    error: function(e) {
                        toastr.error('Error fetching max roll number');
                        console.error(e.responseText);
                    }
                });
                return; // Exit to wait for AJAX
            } else if (strategy === 'preserve_order') {
                let num = 1;
                inputs.each(function() {
                    $(this).val(num++);
                });
            }

            // After filling, update display and validate
            updateRollNumbersDisplay();
            validateRollNumbers();
        });

        // --- Core Functions ---

        function loadStudents() {
            const classId = $('#classSelect').val();
            const sectionId = $('#sectionSelect').val();
            const sortBy = $('#sortSelect').val();

            if (!classId) {
                toastr.warning('Please select a class');
                return;
            }

            if (!sectionId) {
                toastr.warning('Please select a section');
                return;
            }

            // --- STEP A: SAVE CURRENT INPUTS BEFORE RELOAD ---
            // Iterate over current inputs and save them to our object
            $('.roll-number-input').each(function() {
                const studentId = $(this).closest('tr').data('student-id');
                const val = $(this).val();
                if (val !== '') {
                    cachedRollNumbers[studentId] = val;
                }
            });

            // UI State: Loading
            $('#initialStateMsg').hide();
            $('#studentsContainer').hide();
            $('#loadingSpinner').show();
            $('#studentsTableBody').empty();

            $.ajax({
                url: '../../api/admin/get/class/get-students-no-roll.php',
                type: 'GET',
                data: {
                    class_id: classId,
                    section_id: sectionId,
                    sort_by: sortBy
                },
                dataType: 'json',
                success: function(response) {
                    $('#loadingSpinner').hide();
                    $('#studentsContainer').show();

                    // ... (Your existing Title/Info update code) ...
                    const className = $('#classSelect option:selected').text().trim();
                    const sectionName = sectionId && sectionId !== '0' ?
                        $('#sectionSelect option:selected').text().trim() :
                        'No Section';

                    $('#classInfoTitle').text(`Class: ${className} - ${sectionName}`);
                    $('#studentCount').text(response.data.length);

                    $('#formClassId').val(classId);
                    $('#formSectionId').val(sectionId);

                    if (response.data.length === 0) {
                        $('#noStudentsMsg').show();
                        $('#rollNumberForm').hide();
                    } else {
                        $('#noStudentsMsg').hide();
                        $('#rollNumberForm').show();

                        // Render Table
                        let html = '';
                        response.data.forEach(student => {
                            // --- STEP B: CHECK IF WE HAVE A SAVED VALUE ---
                            // If we have a value in cache, use it. Otherwise empty string.
                            let savedValue = cachedRollNumbers[student.id] ? cachedRollNumbers[student.id] : '';

                            html += `
                                <tr data-student-id="${student.student_id}">
                                    <td>${student.student_id || '-'}</td>
                                    <td>${student.name}</td>
                                    <td>${student.father_name || '-'}</td>
                                    <td>${student.address || '-'}</td>
                                    <td>
                                        <input type="number" class="form-control roll-number-input"
                                            name="roll_numbers[${student.student_id}]"
                                            value="${savedValue}" 
                                            min="1" placeholder="Roll No" 
                                            id="roll_number_${student.student_id}"
                                        />
                                    </td>
                                </tr>
                            `;
                        });
                        $('#studentsTableBody').html(html);

                        // --- STEP C: TRIGGER VALIDATION UPDATE ---
                        // Because we injected values manually, we need to update the 
                        // "Assigned Count" display and check for duplicates immediately
                        updateRollNumbersDisplay();
                        validateRollNumbers();
                    }
                },
                error: function(xhr) {
                    $('#loadingSpinner').hide();
                    toastr.error("Error fetching data: " + xhr.statusText);
                }
            });
        }

        function resetStudentView() {
            $('#studentsContainer').hide();
            $('#initialStateMsg').show();
            $('#rollNumberForm').trigger("reset");
        }

        function validateRollNumbers() {
            const inputs = $('.roll-number-input');
            const values = {};
            let hasErrors = false;

            // Reset UI
            inputs.removeClass('is-invalid');
            $('.invalid-feedback').remove();

            inputs.each(function() {
                const input = $(this);
                // Skip hidden inputs (from search filter)
                if (input.closest('tr').css('display') === 'none') return;

                const value = input.val().trim();

                if (value === '') return; // Allow empty while typing

                // Check numeric
                if (!/^\d+$/.test(value)) {
                    showError(input, 'Numbers only');
                    hasErrors = true;
                    return;
                }

                // Check duplicates
                if (values[value]) {
                    showError(input, 'Duplicate');
                    showError($(`[name="${values[value]}"]`), 'Duplicate');
                    hasErrors = true;
                } else {
                    values[value] = input.attr('name');
                }
            });

            return !hasErrors;
        }

        function showError(input, msg) {
            input.addClass('is-invalid');
            if (input.next('.invalid-feedback').length === 0) {
                input.after(`<div class="invalid-feedback">${msg}</div>`);
            }
        }

        function updateRollNumbersDisplay() {
            let assignedCount = 0;
            $('.roll-number-input').each(function() {
                if ($(this).val().trim() !== '') assignedCount++;
            });

            $('#assignedCount').text(assignedCount);
            if (assignedCount > 0) {
                $('#rollNumbersSummary').show();
            } else {
                $('#rollNumbersSummary').hide();
            }
        }
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>