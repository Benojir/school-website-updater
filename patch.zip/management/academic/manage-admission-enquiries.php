<?php
include_once("../../includes/auth-check.php");
require_once("../../includes/header-open.php");
echo "<title>Admission Enquiries Management - " . $school_name . "</title>";
require_once("../../includes/header-close.php");
require_once("../../includes/dashboard-navbar.php");

// Check permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    die("You don't have permission to access this page.");
}

// Initialize variables
$page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, [
    'options' => ['default' => 1, 'min_range' => 1]
]) ?: 1;

$search = safe_htmlspecialchars(trim(filter_input(INPUT_GET, 'search', FILTER_DEFAULT) ?? ''));
$class_filter = filter_input(INPUT_GET, 'class', FILTER_VALIDATE_INT) ?: 0;

$per_page = 25;
$offset = ($page - 1) * $per_page;

try {
    // Build query with search and filter conditions
    $where_conditions = [];
    $params = [];
    
    if (!empty($search)) {
        $where_conditions[] = "(se.name LIKE ? OR se.father_name LIKE ? OR se.phone_number LIKE ? OR se.email LIKE ?)";
        $search_param = "%$search%";
        $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param]);
    }
    
    if ($class_filter > 0) {
        $where_conditions[] = "se.class_id = ?";
        $params[] = $class_filter;
    }
    
    $where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";
    
    // Get total count
    $count_sql = "SELECT COUNT(*) FROM admission_enquiries se $where_clause";
    $count_stmt = $pdo->prepare($count_sql);
    $count_stmt->execute($params);
    $total_enquiries = $count_stmt->fetchColumn();
    $total_pages = ceil($total_enquiries / $per_page);
    
    // Get enquiries with class information
    $sql = "SELECT se.*, c.class_name 
            FROM admission_enquiries se 
            LEFT JOIN classes c ON se.class_id = c.id 
            $where_clause 
            ORDER BY se.created_at DESC 
            LIMIT ? OFFSET ?";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array_merge($params, [$per_page, $offset]));
    $enquiries = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get all classes for filter dropdown
    $classes_stmt = $pdo->query("SELECT id, class_name FROM classes ORDER BY class_name");
    $classes = $classes_stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    error_log("Database error in manage enquiries: " . $e->getMessage());
    $enquiries = [];
    $classes = [];
    $total_enquiries = 0;
    $total_pages = 0;
}
?>

<style>
    .admission-enquiries .stats-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 12px;
        padding: 24px;
    }
    .admission-enquiries .search-filters {
        background: #f8f9fa;
        border: 1px solid #e9ecef;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 24px;
    }
    .admission-enquiries .table-responsive { overflow-x: auto; }
    .admission-enquiries .table { min-width: 1060px; }
    .admission-enquiries .table th { white-space: nowrap; font-size: .8rem; padding: 14px 12px; }
    .admission-enquiries .table td { padding: 16px 12px; }
    .admission-enquiries .student-name { max-width: 220px; overflow-wrap: anywhere; }
    .admission-photo { display: inline-block; border-radius: 10px; overflow: hidden; border: 1px solid #dee2e6; }
    a.admission-photo { cursor: zoom-in; }
    a.admission-photo:focus-visible { outline: 3px solid #0d6efd; outline-offset: 3px; }
    .admission-photo img { display: block; width: 50px; height: 60px; object-fit: cover; }
    .admission-photo-placeholder { display: inline-flex; align-items: center; justify-content: center;
        width: 50px; height: 60px; background: #f1f3f5; color: #8a949e; font-size: 22px; }
    .admission-actions { display: grid; grid-template-columns: repeat(2, auto); gap: 6px; justify-content: end; }
    .admission-actions .btn { white-space: nowrap; font-size: .78rem; }
    #enquiryDetailsModal .modal-body { background: #f8f9fa; }
    #enquiryDetailsModal .admission-profile { background: white; border: 1px solid #e9ecef;
        border-radius: 12px; padding: 24px; margin-bottom: 20px; display: flex; align-items: center; gap: 24px; }
    #enquiryDetailsModal .admission-profile .admission-photo img,
    #enquiryDetailsModal .admission-profile .admission-photo-placeholder { width: 100px; height: 120px; }
    #enquiryDetailsModal .card { border-color: #e9ecef; border-radius: 10px; overflow: hidden; }
    #enquiryDetailsModal .card-header { padding: 14px 16px; }
    #enquiryDetailsModal .col-8 { overflow-wrap: anywhere; }
    @media (max-width: 575.98px) {
        .admission-enquiries .stats-card, .admission-enquiries .search-filters { padding: 16px; }
        #enquiryDetailsModal .admission-profile { align-items: flex-start; gap: 16px; padding: 16px; }
        #enquiryDetailsModal .admission-profile h4 { font-size: 1.1rem; overflow-wrap: anywhere; }
    }
</style>

<div class="container-fluid mt-4 mb-4 admission-enquiries">
    <!-- Stats Card -->
    <div class="row mb-3">
        <div class="col-12">
            <div class="stats-card">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h4 class="mb-1"><i class="fas fa-graduation-cap me-2"></i>Admission Enquiries Management</h4>
                        <p class="mb-0">Total Pending Applications: <?= number_format($total_enquiries) ?></p>
                    </div>
                    <div class="col-md-4 text-md-end mt-3 mt-md-0">
                        <a href="../student/list-students.php" class="btn btn-light btn-sm">
                            <i class="fas fa-arrow-left me-1"></i> Back to Students
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
                <h5 class="mb-0"><i class="fas fa-inbox text-primary me-2"></i>Admission Applications</h5>
                <span class="badge bg-warning text-dark px-3 py-2"><i class="fas fa-hourglass-half me-1"></i>Pending Review</span>
            </div>
            <!-- Search and Filter Section -->
            <div class="search-filters">
                <form method="GET" class="row g-3" id="filterForm">
                    <div class="col-lg-6 col-md-12">
                        <label for="search" class="form-label">Search</label>
                        <input type="text" class="form-control" id="search" name="search" 
                               value="<?= safe_htmlspecialchars($search) ?>" 
                               placeholder="Search by name, father name, phone, or email">
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <label for="class" class="form-label">Filter by Class</label>
                        <select class="form-select" id="class" name="class">
                            <option value="">All Classes</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?= $class['id'] ?>" <?= $class_filter == $class['id'] ? 'selected' : '' ?>>
                                    <?= safe_htmlspecialchars($class['class_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-lg-3 col-md-6 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary me-2">
                            <i class="fas fa-search me-1"></i> Search
                        </button>
                        <a href="?" class="btn btn-outline-secondary">
                            <i class="fas fa-times me-1"></i> Clear
                        </a>
                    </div>

                </form>
            </div>

            <!-- Results Info -->
            <?php if (!empty($search) || $class_filter > 0): ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    Showing <?= number_format(count($enquiries)) ?> of <?= number_format($total_enquiries) ?> results
                    <?php if (!empty($search)): ?>
                        for "<strong><?= safe_htmlspecialchars($search) ?></strong>"
                    <?php endif; ?>
                    <?php if ($class_filter > 0): ?>
                        in class: <strong><?= safe_htmlspecialchars($classes[array_search($class_filter, array_column($classes, 'id'))]['class_name'] ?? 'Unknown') ?></strong>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <!-- Table -->
            <div class="table-responsive">
                <table class="table table-striped table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Photo</th>
                            <th>Student Details</th>
                            <th>Contact Info</th>
                            <th>Parent Details</th>
                            <th>Class / Year</th>
                            <th>Application Date</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($enquiries)): ?>
                            <tr>
                                <td colspan="8" class="text-center py-5">
                                    <div class="text-muted">
                                        <i class="fas fa-search fa-3x mb-3"></i>
                                        <h5>No enquiries found</h5>
                                        <p>Try adjusting your search criteria or filters.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($enquiries as $index => $enquiry): ?>
                                <tr id="enquiry-row-<?= $enquiry['id'] ?>" data-academic-year="<?= safe_htmlspecialchars($enquiry['academic_year'] ?? '') ?>">
                                    <td><?= $offset + $index + 1 ?></td>
                                    <td>
                                        <?php
                                        $photoFile = basename((string)($enquiry['student_image'] ?? ''));
                                        $hasPhoto = $photoFile !== '' && is_file(__DIR__ . '/../../uploads/students/' . $photoFile);
                                        ?>
                                        <?php if ($hasPhoto): ?>
                                            <a class="admission-photo" href="<?= safe_htmlspecialchars(BASE_URL . '/uploads/students/' . rawurlencode($photoFile)) ?>"
                                               data-fancybox="admission-enquiry-list-<?= (int)$enquiry['id'] ?>"
                                               data-caption="<?= safe_htmlspecialchars(safe_htmlspecialchars($enquiry['name'])) ?>"
                                               aria-label="View photo of <?= safe_htmlspecialchars($enquiry['name']) ?>">
                                                <img src="<?= safe_htmlspecialchars(BASE_URL . '/uploads/students/' . rawurlencode($photoFile)) ?>" alt="Student photo" width="50" height="60" loading="lazy">
                                            </a>
                                        <?php else: ?>
                                            <span class="admission-photo admission-photo-placeholder" role="img" aria-label="No student photo" title="No photo provided"><i class="fas fa-user-graduate" aria-hidden="true"></i></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="fw-bold student-name mb-1"><?= safe_htmlspecialchars($enquiry['name']) ?></div>
                                        <div class="small text-muted mb-1">Application #<?= str_pad((string)$enquiry['id'], 6, '0', STR_PAD_LEFT) ?></div>
                                        <small class="text-muted">
                                            <?= safe_htmlspecialchars($enquiry['gender']) ?>
                                            <?php if (!empty($enquiry['date_of_birth'])): ?>
                                                | DOB: <?= date('d/m/Y', strtotime($enquiry['date_of_birth'])) ?>
                                            <?php endif; ?>
                                        </small>
                                    </td>
                                    <td>
                                        <div class="mb-1"><a href="tel:<?= safe_htmlspecialchars($enquiry['phone_number']) ?>" class="text-decoration-none text-nowrap"><i class="fas fa-phone fa-sm me-1"></i><?= safe_htmlspecialchars($enquiry['phone_number']) ?></a></div>
                                        <?php if (!empty($enquiry['email'])): ?>
                                            <small class="text-muted">
                                                <i class="fas fa-envelope fa-sm me-1"></i><?= safe_htmlspecialchars($enquiry['email']) ?>
                                            </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="small">
                                            <strong>Father:</strong> <?= safe_htmlspecialchars($enquiry['father_name']) ?>
                                            <?php if (!empty($enquiry['mother_name'])): ?>
                                                <br><strong>Mother:</strong> <?= safe_htmlspecialchars($enquiry['mother_name']) ?>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-info text-dark">
                                            <?= safe_htmlspecialchars($enquiry['class_name'] ?? 'N/A') ?>
                                        </span>
                                        <div class="mt-2"><span class="badge bg-light text-dark border"><i class="fas fa-calendar-alt me-1"></i><?= safe_htmlspecialchars($enquiry['academic_year'] ?? 'Select year on approval') ?></span></div>
                                    </td>
                                    <td>
                                        <div><?= date('d M Y', strtotime($enquiry['created_at'])) ?></div>
                                        <small class="text-muted"><?= date('h:i A', strtotime($enquiry['created_at'])) ?></small>
                                    </td>
                                    <td>
                                        <div class="admission-actions" role="group" aria-label="Application actions">
                                            <button type="button" class="btn btn-success btn-sm" 
                                                    onclick="handleEnquiry(<?= $enquiry['id'] ?>, 'approve')"
                                                    title="Approve Application">
                                                <i class="fas fa-check me-1"></i>Approve
                                            </button>
                                            <button type="button" class="btn btn-warning btn-sm" 
                                                    onclick="handleEnquiry(<?= $enquiry['id'] ?>, 'reject')"
                                                    title="Reject Application">
                                                <i class="fas fa-times me-1"></i>Reject
                                            </button>
                                            <button type="button" class="btn btn-outline-primary btn-sm"
                                                    onclick="viewEnquiryDetails(<?= $enquiry['id'] ?>)"
                                                    title="View Details">
                                                <i class="fas fa-eye me-1"></i>Details
                                            </button>
                                            <button type="button" class="btn btn-outline-danger btn-sm"
                                                    onclick="handleEnquiry(<?= $enquiry['id'] ?>, 'delete')"
                                                    title="Delete Enquiry">
                                                <i class="fas fa-trash me-1"></i>Delete
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
                <nav aria-label="Enquiries pagination" class="mt-4">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <p class="text-muted mb-0">
                                Showing <?= $offset + 1 ?> to <?= min($offset + $per_page, $total_enquiries) ?> 
                                of <?= number_format($total_enquiries) ?> entries
                            </p>
                        </div>
                        <div class="col-md-6">
                            <ul class="pagination justify-content-end mb-0">
                                <?php
                                $query_params = $_GET;
                                unset($query_params['page']);
                                $base_url = '?' . http_build_query($query_params);
                                $base_url = $base_url === '?' ? '?' : $base_url . '&';
                                ?>
                                
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="<?= $base_url ?>page=1" aria-label="First">
                                            <span aria-hidden="true">&laquo;&laquo;</span>
                                        </a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="<?= $base_url ?>page=<?= $page - 1 ?>" aria-label="Previous">
                                            <span aria-hidden="true">&laquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php
                                $start = max(1, $page - 2);
                                $end = min($total_pages, $page + 2);
                                for ($i = $start; $i <= $end; $i++): ?>
                                    <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                        <a class="page-link" href="<?= $base_url ?>page=<?= $i ?>"><?= $i ?></a>
                                    </li>
                                <?php endfor; ?>

                                <?php if ($page < $total_pages): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="<?= $base_url ?>page=<?= $page + 1 ?>" aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                        </a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="<?= $base_url ?>page=<?= $total_pages ?>" aria-label="Last">
                                            <span aria-hidden="true">&raquo;&raquo;</span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- View Details Modal -->
<div class="modal fade" id="enquiryDetailsModal" tabindex="-1" aria-labelledby="enquiryDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="enquiryDetailsModalLabel">
                    <i class="fas fa-user-graduate me-2"></i>Enquiry Details
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="enquiryDetailsContent">
                <!-- Content will be loaded here -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
    // Delegated binding also handles photos inserted into the details modal via AJAX.
    if (typeof Fancybox !== 'undefined') {
        Fancybox.bind('[data-fancybox^="admission-enquiry-"]', {});
    }

    // Helper function to get session year options
    function getSessionYearOptions() {
        const options = <?php
                        $currentYear = (int)(academicCurrentYear($pdo) ?? date('Y'));
                        $sessions = [];
                        // Create an object for more descriptive options, e.g., "2025-2026"
                        for ($i = 0; $i < 2; $i++) {
                            $startYear = $currentYear + $i;
                            $endYear = $startYear + 1;
                            // $sessions[$startYear] = $startYear . '-' . $endYear;
                            $sessions[$startYear] = $startYear;
                        }
                        echo json_encode($sessions);
                        ?>;
        return options;
    }

    // Enhanced enquiry handling function
    function handleEnquiry(enquiry_id, action) {
        const actionTexts = {
            'approve': { title: 'Approve Application', text: 'approve this enquiry and add student to system', color: '#28a745' },
            'reject': { title: 'Reject Application', text: 'reject this enquiry and send notification', color: '#ffc107' },
            'delete': { title: 'Delete Enquiry', text: 'permanently delete this enquiry', color: '#dc3545' }
        };

        const actionInfo = actionTexts[action];
        const applicationYear = document.getElementById(`enquiry-row-${enquiry_id}`)?.dataset.academicYear || '';
        const yearMessage = action === 'approve' && applicationYear ? ` Academic year: ${applicationYear}.` : '';
        
        Swal.fire({
            title: actionInfo.title,
            text: `Are you sure you want to ${actionInfo.text}?${yearMessage}`,
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: actionInfo.color,
            cancelButtonColor: "#6c757d",
            confirmButtonText: `Yes, ${action}!`,
            cancelButtonText: "Cancel",
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {

                if (action == 'approve') {
                    if (applicationYear) {
                        performEnquiryAction(enquiry_id, applicationYear, action);
                        return;
                    }
                    // Older enquiries have no saved year: ask the administrator explicitly.
                    Swal.fire({
                        title: 'Select Academic Year',
                        text: 'In which academic year will this student be admitted?',
                        icon: "warning",
                        input: 'select',
                        inputOptions: getSessionYearOptions(),
                        inputPlaceholder: 'Select a academic year',
                        showCancelButton: true,
                        confirmButtonColor: actionInfo.color,
                        cancelButtonColor: "#6c757d",
                        confirmButtonText: `Yes, ${action}!`,
                        cancelButtonText: "Cancel",
                        reverseButtons: true,
                        preConfirm: (sessionYear) => {
                            // 1. Validation: Ensure a session year was selected
                            if (!sessionYear) {
                                Swal.showValidationMessage('Please select an academic year year');
                            }
                            // 2. Return the selected value so it can be used in .then()
                            return sessionYear;
                        }
                    }).then((result) => {
                        // Check if the user clicked "Download" and a value was confirmed
                        if (result.isConfirmed) {
                            // The selected sessionYear is in result.value
                            let academic_year = result.value;
                            performEnquiryAction(enquiry_id, academic_year, action);
                        }
                    });
                } else {
                    performEnquiryAction(enquiry_id, '', action,);
                }
            }
        });
    }

    function performEnquiryAction(enquiry_id, academic_year, action) {
        $.ajax({
            url: "../../api/admin/put/student/process-admission-enquiry.php",
            type: "POST",
            data: {
                enquiry_id: enquiry_id,
                academic_year: academic_year,
                action: action
            },
            beforeSend: function() {
                Swal.fire({
                    title: "Processing...",
                    text: `Please wait while the enquiry is being processed.`,
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    showConfirmButton: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });
            },
            success: function(response) {
                if (response.success) {
                    const successMessages = {
                        'approve': 'Application approved successfully!',
                        'reject': 'Application rejected and notification sent!',
                        'delete': 'Enquiry deleted successfully!'
                    };

                    Swal.fire({
                        icon: "success",
                        title: "Success!",
                        text: successMessages[action] || response.message,
                        confirmButtonColor: "#0d6efd",
                        timer: 3000,
                        timerProgressBar: true
                    }).then(() => {
                        // Remove row with animation
                        $(`#enquiry-row-${enquiry_id}`).fadeOut(500, function() {
                            $(this).remove();
                            
                            // If no more rows, show empty state or reload page
                            if ($('#enquiry-row-' + enquiry_id).siblings('tr').length === 0) {
                                location.reload();
                            }
                        });
                    });
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Operation Failed",
                        text: response.message || "Something went wrong while processing the request.",
                        confirmButtonText: "OK",
                        confirmButtonColor: "#dc3545"
                    });
                }
            },
            error: function(xhr, status, error) {
                let errorMessage = "Something went wrong while processing the request.";

                try {
                    const res = JSON.parse(xhr.responseText);
                    if (res.message) {
                        errorMessage = res.message;
                    }
                } catch (e) {
                    if (xhr.status === 403) {
                        errorMessage = "You don't have permission to perform this action.";
                    } else if (xhr.status === 404) {
                        errorMessage = "The requested enquiry was not found.";
                    }
                }

                Swal.fire({
                    icon: "error",
                    title: "Request Failed",
                    text: errorMessage,
                    confirmButtonColor: "#dc3545"
                });

                console.error("Error details:", xhr.responseText);
            }
        });
    }

    function viewEnquiryDetails(enquiry_id) {
        // Show loading in modal
        $('#enquiryDetailsContent').html(`
            <div class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2">Loading enquiry details...</p>
            </div>
        `);
        
        bootstrap.Modal.getOrCreateInstance(document.getElementById('enquiryDetailsModal'), { focus: false }).show();
        
        // Load enquiry details via AJAX
        $.ajax({
            url: "../../api/admin/get/student/get-admission-enquiry-details.php",
            type: "GET",
            data: { enquiry_id: enquiry_id },
            success: function(response) {
                if (response.success) {
                    $('#enquiryDetailsContent').html(response.html);
                } else {
                    $('#enquiryDetailsContent').html(`
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            ${response.message || 'Failed to load enquiry details.'}
                        </div>
                    `);
                    
                    console.log(response);
                }
            },
            error: function() {
                $('#enquiryDetailsContent').html(`
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Failed to load enquiry details. Please try again.
                    </div>
                `);
            }
        });
    }

    // function exportEnquiries() {
    //     const currentUrl = new URL(window.location);
    //     currentUrl.pathname = currentUrl.pathname.replace('manage-admission-enquiries.php', '../action/export-enquiries.php');
    //     window.open(currentUrl.toString(), '_blank');
    // }

    // Auto-submit form on filter change
    $('#class').on('change', function() {
        $('#filterForm').submit();
    });

    // Search with debouncing
    let searchTimeout;
    $('#search').on('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            $('#filterForm').submit();
        }, 500);
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>