<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage Subjects - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if ($_SESSION['user']['role'] !== 'superadmin') {
   include_once("../../includes/permission-denied.php");
}

// Fetch all classes for filter dropdown
$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container py-4">

    <!-- Add Classes Section Card -->
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-book me-2"></i> Add New Subject</h3>
            </div>
        </div>

        <div class="card-body p-4 p-md-5">
            <form id="addSubjectForm" method="POST">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="subject_name" class="form-label fw-bold">Subject Name</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-book-open"></i></span>
                                <input type="text" name="subject_name" id="subject_name" class="form-control" required
                                    placeholder="e.g. Mathematics">
                            </div>
                            <div class="form-text">Enter the subject name</div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="class_id" class="form-label fw-bold">Class</label>
                            <select name="class_id" id="class_id" class="form-select" required>
                                <option value="" selected disabled>Select Class</option>
                                <?php foreach ($classes as $class): ?>
                                    <option value="<?= safe_htmlspecialchars($class['id']) ?>">
                                        <?= safe_htmlspecialchars($class['class_name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text">Select the class for this subject</div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="subject_type" class="form-label fw-bold">Subject Type</label>
                            <select name="subject_type" id="subject_type" class="form-select" required>
                                <option value="" selected disabled>Select Subject Type</option>
                                <option value="Main">Main (Core Subject)</option>
                                <option value="Minor">Minor (Elective Subject)</option>
                            </select>
                            <div class="form-text">Select the subject type</div>
                        </div>
                    </div>
                </div>

                <div class="text-center mt-4">
                    <button type="submit" id="submitBtn" class="btn btn-primary px-4">
                        <i class="fas fa-save me-2"></i> Save Subject
                    </button>
                </div>
            </form>
        </div>
    </div>

     <!-- View Classes Section Card -->
    <div class="card shadow-lg mt-5">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-book-open me-2"></i> Manage Subjects</h3>
            </div>
        </div>

        <div class="card-body">
            <!-- Search and Filter Section -->
            <div class="row mb-4">
                <div class="col-md-12">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-search"></i></span>
                                <input type="text" id="searchInput" class="form-control" 
                                       placeholder="Search subjects...">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <select id="classFilter" class="form-select">
                                <option value="">All Classes</option>
                                <?php foreach ($classes as $class): ?>
                                    <option value="<?= $class['id'] ?>"><?= safe_htmlspecialchars($class['class_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select id="typeFilter" class="form-select">
                                <option value="">All Types</option>
                                <option value="Main">Main</option>
                                <option value="Minor">Minor</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button id="resetFilters" class="btn btn-outline-secondary w-100">
                                <i class="fas fa-undo me-1"></i> Reset
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Subjects Table -->
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th width="5%">#</th>
                            <th>Subject Name</th>
                            <th>Subject Type</th>
                            <th>Class</th>
                            <th width="15%" class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="subjectsTableBody">
                        <!-- AJAX will load content here -->
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center" id="paginationContainer">
                    <!-- AJAX will load pagination here -->
                </ul>
            </nav>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    let currentPage = 1;
    const limit = 10;
    
    // Load subjects with AJAX
    function loadSubjects(page = 1, search = '', classId = '', type = '') {
        currentPage = page;
        $.ajax({
            url: '../../api/admin/get/subject/get-subjects-for-listing.php',
            type: 'GET',
            data: {
                page: page,
                limit: limit,
                search: search,
                class_id: classId,
                type: type
            },
            dataType: 'json',
            beforeSend: function() {
                $('#subjectsTableBody').html(`
                    <tr>
                        <td colspan="5" class="text-center py-4">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </td>
                    </tr>
                `);
            },
            success: function(response) {
                if (response.subjects.length > 0) {
                    let html = '';
                    response.subjects.forEach((subject, index) => {
                        html += `
                            <tr id="subject-${subject.id}">
                                <td>${index + 1 + ((page - 1) * limit)}</td>
                                <td>${escapeHtml(subject.subject_name)}</td>
                                <td>
                                    <span class="badge ${subject.subject_type === 'Main' ? 'bg-primary' : 'bg-secondary'}">
                                        ${escapeHtml(subject.subject_type)}
                                    </span>
                                </td>
                                <td>${escapeHtml(subject.class_name)}</td>
                                <td class="text-end">
                                    <button class="btn btn-sm btn-outline-danger delete-btn" 
                                            data-id="${subject.id}" 
                                            data-name="${escapeHtml(subject.subject_name)}">
                                        <i class="fas fa-trash-alt me-1"></i> Delete
                                    </button>
                                </td>
                            </tr>
                        `;
                    });
                    $('#subjectsTableBody').html(html);
                } else {
                    $('#subjectsTableBody').html(`
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">
                                <i class="fas fa-book-open fa-3x mb-3"></i>
                                <h4>No subjects found</h4>
                                <p>Try adjusting your search filters</p>
                            </td>
                        </tr>
                    `);
                }
                
                // Update pagination
                updatePagination(response.total, page);
            },
            error: function() {
                toastr.error('Failed to load subjects. Please try again.');
            }
        });
    }
    
    // Update pagination
    function updatePagination(totalRecords, currentPage) {
        const totalPages = Math.ceil(totalRecords / limit);
        let html = '';
        
        if (totalPages > 1) {
            if (currentPage > 1) {
                html += `
                    <li class="page-item">
                        <a class="page-link" href="#" data-page="1" aria-label="First">
                            <i class="fas fa-angle-double-left"></i>
                        </a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="#" data-page="${currentPage - 1}" aria-label="Previous">
                            <i class="fas fa-angle-left"></i>
                        </a>
                    </li>
                `;
            }
            
            // Show limited page numbers
            const start = Math.max(1, currentPage - 2);
            const end = Math.min(totalPages, currentPage + 2);
            
            if (start > 1) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
            
            for (let i = start; i <= end; i++) {
                html += `
                    <li class="page-item ${i === currentPage ? 'active' : ''}">
                        <a class="page-link" href="#" data-page="${i}">${i}</a>
                    </li>
                `;
            }
            
            if (end < totalPages) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
            
            if (currentPage < totalPages) {
                html += `
                    <li class="page-item">
                        <a class="page-link" href="#" data-page="${currentPage + 1}" aria-label="Next">
                            <i class="fas fa-angle-right"></i>
                        </a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="#" data-page="${totalPages}" aria-label="Last">
                            <i class="fas fa-angle-double-right"></i>
                        </a>
                    </li>
                `;
            }
        }
        
        $('#paginationContainer').html(html);
    }
    
    // Helper function to escape HTML
    function escapeHtml(unsafe) {
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }
    
    // Initial load
    loadSubjects();
    
    // Search input handler with debounce
    let searchTimer;
    $('#searchInput').on('input', function() {
        clearTimeout(searchTimer);
        searchTimer = setTimeout(() => {
            loadSubjects(
                1,
                $(this).val(),
                $('#classFilter').val(),
                $('#typeFilter').val()
            );
        }, 500);
    });
    
    // Filter change handlers
    $('#classFilter, #typeFilter').change(function() {
        loadSubjects(
            1,
            $('#searchInput').val(),
            $('#classFilter').val(),
            $('#typeFilter').val()
        );
    });
    
    // Reset filters
    $('#resetFilters').click(function() {
        $('#searchInput').val('');
        $('#classFilter').val('');
        $('#typeFilter').val('');
        loadSubjects(1);
    });
    
    // Pagination click handler
    $(document).on('click', '.page-link', function(e) {
        e.preventDefault();
        const page = $(this).data('page');
        if (page) {
            loadSubjects(
                page,
                $('#searchInput').val(),
                $('#classFilter').val(),
                $('#typeFilter').val()
            );
            $('html, body').animate({ scrollTop: 0 }, 'fast');
        }
    });
    
    // Delete subject with SweetAlert confirmation
    $(document).on('click', '.delete-btn', function() {
        const subjectId = $(this).data('id');
        const subjectName = $(this).data('name');
        const subjectRow = $('#subject-' + subjectId);
        
        Swal.fire({
            title: 'Delete Subject',
            html: `Are you sure you want to delete <strong>${subjectName}</strong>?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '../../api/admin/delete/subject/delete-subject.php',
                    type: 'POST',
                    data: { id: subjectId },
                    dataType: 'json',
                    beforeSend: function() {
                        subjectRow.find('.delete-btn').html('<span class="spinner-border spinner-border-sm me-1"></span> Deleting');
                    },
                    success: function(response) {
                        if (response.success) {
                            toastr.success(response.message);
                            // Reload current page after delete
                            loadSubjects(
                                currentPage,
                                $('#searchInput').val(),
                                $('#classFilter').val(),
                                $('#typeFilter').val()
                            );
                        } else {
                            toastr.error(response.message);
                            subjectRow.find('.delete-btn').html('<i class="fas fa-trash-alt me-1"></i> Delete');
                        }
                    },
                    error: function() {
                        toastr.error('An error occurred. Please try again.');
                        subjectRow.find('.delete-btn').html('<i class="fas fa-trash-alt me-1"></i> Delete');
                    }
                });
            }
        });
    });

    // Add Class Section JS

    // AJAX form submission
    $('#addSubjectForm').submit(function(e) {
        e.preventDefault();
        const formData = $(this).serialize();
        const submitBtn = $('#submitBtn');
        
        // Change button state
        submitBtn.prop('disabled', true).html(
            '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Saving...'
        );

        $.ajax({
            url: '../../api/admin/put/subject/save-subject.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                    // Reset form on success
                    $('#subject_name').val("");
                } else {
                    toastr.error(response.message);
                }
                submitBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i> Save Subject');

                loadSubjects(
                    1,
                    $('#searchInput').val(),
                    $('#classFilter').val(),
                    $('#typeFilter').val()
                );
            },
            error: function(xhr, status, error) {
                toastr.error('An error occurred. Please try again.');
                console.error(error);
                submitBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i> Save Subject');

                loadSubjects(
                    1,
                    $('#searchInput').val(),
                    $('#classFilter').val(),
                    $('#typeFilter').val()
                );
            }
        });
    });

    // Initialize select2 for better dropdowns (if you have select2 included)
    if ($.fn.select2) {
        $('#class_id, #subject_type').select2({
            theme: 'bootstrap-5',
            width: '100%'
        });
    }
});
</script>

<?php include_once("../../includes/body-close.php"); ?>