<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
/** @var string $school_name */
echo "<title>Manage Subjects - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if (!isSuperAdmin()) {
    include_once("../../includes/permission-denied.php");
}

// Fetch all classes for filter dropdown and modals
$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container py-4">

    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-book me-2"></i> Add New Subject</h3>
            </div>
        </div>

        <div class="card-body p-4 p-md-5">
            <form id="addSubjectForm" method="POST">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="subject_name" class="form-label fw-bold">Subject Name</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-book-open"></i></span>
                                <input type="text" name="subject_name" id="subject_name" class="form-control" required
                                    placeholder="e.g. Mathematics">
                            </div>
                            <div class="form-text">Enter the subject name</div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="subject_type" class="form-label fw-bold">Subject Type</label>
                            <select name="subject_type" id="subject_type" class="form-select" required>
                                <option value="" selected disabled>Select Subject Type</option>
                                <option value="Main">Main (Core Subject)</option>
                                <option value="Minor">Minor (Elective Subject)</option>
                            </select>
                            <div class="form-text">Select the subject type</div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="class_id" class="form-label fw-bold">Class</label>
                            <select name="class_id[]" id="class_id" class="form-select custom-multiselect" multiple="multiple">
                                <?php foreach ($classes as $class): ?>
                                    <option value="<?= safe_htmlspecialchars($class['id']) ?>">
                                        <?= safe_htmlspecialchars($class['class_name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text">Select the class for this subject</div>
                        </div>
                    </div>

                    <div class="col-md-6 d-flex align-items-center px-3">
                        <input type="checkbox" name="exclude_from_marksheet" id="exclude_from_marksheet">
                        <label for="exclude_from_marksheet" class="form-check-label ms-2">Exclude from Marksheet</label>
                    </div>
                </div>

                <div class="text-center mt-4">
                    <button type="submit" id="submitBtn" class="btn btn-primary px-4">
                        <i class="fas fa-save me-2"></i> Save Subject
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow-lg mt-5">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-book-open me-2"></i> Manage Subjects</h3>
            </div>
        </div>

        <div class="card-body">
            <div class="row mb-4">
                <div class="col-md-12">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-search"></i></span>
                                <input type="text" id="searchInput" class="form-control"
                                    placeholder="Search subjects...">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <select id="classFilter" class="form-select">
                                <option value="">All Classes</option>
                                <?php foreach ($classes as $class): ?>
                                    <option value="<?= $class['id'] ?>"><?= safe_htmlspecialchars($class['class_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select id="typeFilter" class="form-select">
                                <option value="">All Types</option>
                                <option value="Main">Main</option>
                                <option value="Minor">Minor</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button id="resetFilters" class="btn btn-outline-secondary w-100">
                                <i class="fas fa-undo me-1"></i> Reset
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th width="5%">#</th>
                            <th>Subject Name</th>
                            <th>Subject Type</th>
                            <th>Class</th>
                            <th width="20%" class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="subjectsTableBody">
                    </tbody>
                </table>
            </div>

            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center" id="paginationContainer">
                </ul>
            </nav>
        </div>
    </div>
</div>

<div class="modal fade" id="editSubjectModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Edit Subject</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editSubjectForm">
                    <input type="hidden" id="edit_subject_id" name="id">

                    <div class="mb-3">
                        <label for="edit_subject_name" class="form-label fw-bold">Subject Name</label>
                        <input type="text" class="form-control" id="edit_subject_name" name="subject_name" required>
                    </div>

                    <div class="mb-3">
                        <label for="edit_subject_type" class="form-label fw-bold">Subject Type</label>
                        <select class="form-select" id="edit_subject_type" name="subject_type" required>
                            <option value="Main">Main (Core Subject)</option>
                            <option value="Minor">Minor (Elective Subject)</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="edit_class_id" class="form-label fw-bold">Class</label>
                        <select class="form-select" id="edit_class_id" name="class_id" required>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?= safe_htmlspecialchars($class['id']) ?>">
                                    <?= safe_htmlspecialchars($class['class_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3 ps-2">
                        <input type="checkbox" name="exclude_from_marksheet" id="exclude_from_marksheet_update">
                        <label for="exclude_from_marksheet_update" class="form-check-label ms-2">Exclude from Marksheet</label>
                    </div>

                    <div class="d-grid">
                        <button type="submit" id="updateBtn" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i> Update Subject
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        let currentPage = 1;
        const limit = 40;

        // Load subjects with AJAX
        function loadSubjects(page = 1, search = '', classId = '', type = '') {
            currentPage = page;
            $.ajax({
                url: '../../api/admin/get/subject/get-subjects-for-listing.php',
                type: 'GET',
                data: {
                    page: page,
                    limit: limit,
                    search: search,
                    class_id: classId,
                    type: type
                },
                dataType: 'json',
                beforeSend: function() {
                    $('#subjectsTableBody').html(`
                    <tr>
                        <td colspan="5" class="text-center py-4">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </td>
                    </tr>
                `);
                },
                success: function(response) {
                    if (response.subjects.length > 0) {
                        let html = '';
                        response.subjects.forEach((subject, index) => {
                            html += `
                            <tr id="subject-${subject.id}">
                                <td>${index + 1 + ((page - 1) * limit)}</td>
                                <td>${escapeHtml(subject.subject_name)}</td>
                                <td>
                                    <span class="badge ${subject.subject_type === 'Main' ? 'bg-primary' : 'bg-secondary'}">
                                        ${escapeHtml(subject.subject_type)}
                                    </span>
                                </td>
                                <td>${escapeHtml(subject.class_name)}</td>
                                <td class="text-end">
                                    <button class="btn btn-sm btn-outline-primary edit-btn me-2" 
                                            data-id="${subject.id}" 
                                            data-name="${escapeHtml(subject.subject_name)}"
                                            data-type="${escapeHtml(subject.subject_type)}"
                                            data-class-id="${subject.class_id}"
                                            data-exclude-from-marksheet="${subject.exclude_from_marksheet}">
                                        <i class="fas fa-edit me-1"></i> Edit
                                    </button>
                                    <button class="btn btn-sm btn-outline-danger delete-btn" 
                                            data-id="${subject.id}" 
                                            data-name="${escapeHtml(subject.subject_name)}">
                                        <i class="fas fa-trash-alt me-1"></i> Delete
                                    </button>
                                </td>
                            </tr>
                        `;
                        });
                        $('#subjectsTableBody').html(html);
                    } else {
                        $('#subjectsTableBody').html(`
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">
                                <i class="fas fa-book-open fa-3x mb-3"></i>
                                <h4>No subjects found</h4>
                                <p>Try adjusting your search filters</p>
                            </td>
                        </tr>
                    `);
                    }

                    // Update pagination
                    updatePagination(response.total, page);
                },
                error: function() {
                    showErrorAlert('Failed to load subjects. Please try again.');
                }
            });
        }

        // Update pagination
        function updatePagination(totalRecords, currentPage) {
            const totalPages = Math.ceil(totalRecords / limit);
            let html = '';

            if (totalPages > 1) {
                if (currentPage > 1) {
                    html += `
                    <li class="page-item">
                        <a class="page-link" href="javascript:void(0)" data-page="1" aria-label="First">
                            <i class="fas fa-angle-double-left"></i>
                        </a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="javascript:void(0)" data-page="${currentPage - 1}" aria-label="Previous">
                            <i class="fas fa-angle-left"></i>
                        </a>
                    </li>
                `;
                }

                // Show limited page numbers
                const start = Math.max(1, currentPage - 2);
                const end = Math.min(totalPages, currentPage + 2);

                if (start > 1) {
                    html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
                }

                for (let i = start; i <= end; i++) {
                    html += `
                    <li class="page-item ${i === currentPage ? 'active' : ''}">
                        <a class="page-link" href="javascript:void(0)" data-page="${i}">${i}</a>
                    </li>
                `;
                }

                if (end < totalPages) {
                    html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
                }

                if (currentPage < totalPages) {
                    html += `
                    <li class="page-item">
                        <a class="page-link" href="javascript:void(0)" data-page="${currentPage + 1}" aria-label="Next">
                            <i class="fas fa-angle-right"></i>
                        </a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="javascript:void(0)" data-page="${totalPages}" aria-label="Last">
                            <i class="fas fa-angle-double-right"></i>
                        </a>
                    </li>
                `;
                }
            }

            $('#paginationContainer').html(html);
        }

        // Initial load
        loadSubjects();

        // Search input handler with debounce
        let searchTimer;
        $('#searchInput').on('input', function() {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => {
                loadSubjects(
                    1,
                    $(this).val(),
                    $('#classFilter').val(),
                    $('#typeFilter').val()
                );
            }, 500);
        });

        // Filter change handlers
        $('#classFilter, #typeFilter').change(function() {
            loadSubjects(
                1,
                $('#searchInput').val(),
                $('#classFilter').val(),
                $('#typeFilter').val()
            );
        });

        // Reset filters
        $('#resetFilters').click(function() {
            $('#searchInput').val('');
            $('#classFilter').val('');
            $('#typeFilter').val('');
            loadSubjects(1);
        });

        // Pagination click handler
        $(document).on('click', '.page-link', function(e) {
            e.preventDefault();
            const page = $(this).data('page');
            if (page) {
                loadSubjects(
                    page,
                    $('#searchInput').val(),
                    $('#classFilter').val(),
                    $('#typeFilter').val()
                );
                $('html, body').animate({
                    scrollTop: 0
                }, 'fast');
            }
        });

        // OPEN EDIT MODAL
        $(document).on('click', '.edit-btn', function() {
            const id = $(this).data('id');
            const name = $(this).data('name');
            const type = $(this).data('type');
            const classId = $(this).data('class-id');
            const excludeMarksheet = $(this).data('exclude-from-marksheet');

            // Populate form fields
            $('#edit_subject_id').val(id);
            $('#edit_subject_name').val(name);
            $('#edit_subject_type').val(type);
            $('#edit_class_id').val(classId);
            $('#exclude_from_marksheet_update').prop('checked', excludeMarksheet === 1);

            // Show Modal
            $('#editSubjectModal').modal('show');
        });

        // SUBMIT EDIT FORM
        $('#editSubjectForm').submit(function(e) {
            e.preventDefault();
            const formData = $(this).serialize();
            const updateBtn = $('#updateBtn');

            updateBtn.prop('disabled', true).html(
                '<span class="spinner-border spinner-border-sm me-2"></span> Updating...'
            );

            $.ajax({
                url: '../../api/admin/put/subject/update-subject.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        $('#editSubjectModal').modal('hide');

                        // Reload list to show changes
                        loadSubjects(
                            currentPage,
                            $('#searchInput').val(),
                            $('#classFilter').val(),
                            $('#typeFilter').val()
                        );
                    } else {
                        toastr.error(response.message);
                    }
                    updateBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i> Update Subject');
                },
                error: function() {
                    toastr.error('Failed to update. Please try again.');
                    updateBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i> Update Subject');
                }
            });
        });

        // Delete subject with SweetAlert confirmation
        $(document).on('click', '.delete-btn', function() {
            const subjectId = $(this).data('id');
            const subjectName = $(this).data('name');
            const subjectRow = $('#subject-' + subjectId);

            Swal.fire({
                title: 'Delete Subject',
                html: `Are you sure you want to delete <strong>${subjectName}</strong>?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel',
                customClass: {
                    popup: 'rounded-4 shadow-lg'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '../../api/admin/delete/subject/delete-subject.php',
                        type: 'POST',
                        data: {
                            id: subjectId
                        },
                        dataType: 'json',
                        beforeSend: function() {
                            subjectRow.find('.delete-btn').html('<span class="spinner-border spinner-border-sm me-1"></span> Deleting');
                        },
                        success: function(response) {
                            if (response.success) {
                                toastr.success(response.message);
                                // Reload current page after delete
                                loadSubjects(
                                    currentPage,
                                    $('#searchInput').val(),
                                    $('#classFilter').val(),
                                    $('#typeFilter').val()
                                );
                            } else {
                                toastr.error(response.message);
                                subjectRow.find('.delete-btn').html('<i class="fas fa-trash-alt me-1"></i> Delete');
                            }
                        },
                        error: function() {
                            toastr.error('An error occurred. Please try again.');
                            subjectRow.find('.delete-btn').html('<i class="fas fa-trash-alt me-1"></i> Delete');
                        }
                    });
                }
            });
        });

        // Add Class Section JS
        $('#addSubjectForm').submit(function(e) {
            e.preventDefault();
            const formData = $(this).serialize();
            const submitBtn = $('#submitBtn');

            // Change button state
            submitBtn.prop('disabled', true).html(
                '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Saving...'
            );

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/put/subject/save-subject.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        let htmlMessage = '';

                        if (response.total_skipped_classes > 0) {
                            htmlMessage += `<p>${response.total_skipped_classes} class${response.total_skipped_classes > 1 ? 'es' : ''} skipped:</p>`;
                            htmlMessage += '<ul>';
                            response.skipped_classes.forEach(function(skipped_class) {
                                htmlMessage += `<li>${skipped_class.id}: ${skipped_class.error}</li>`;
                            });
                            htmlMessage += '</ul>';
                        } else {
                            htmlMessage += '<p>All classes saved successfully.</p>';
                        }

                        showSuccessAlert(htmlMessage, 'Subject Saved');
                        $('#addSubjectForm')[0].reset(); // Reset form on success
                        $('#class_id').val(null).trigger('change'); // If using select2
                        $('#class_id').multiselect('deselectAll', false);
                        $('#class_id').multiselect('updateButtonText');
                    } else {
                        showErrorAlert(response.error);
                    }
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i> Save Subject');

                    loadSubjects(
                        1,
                        $('#searchInput').val(),
                        $('#classFilter').val(),
                        $('#typeFilter').val()
                    );
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred. Please try again.');
                    console.error(error);
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i> Save Subject');
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>