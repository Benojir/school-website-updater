<?php
http_response_code(301);
header("Location: auth/login.php");
exit;