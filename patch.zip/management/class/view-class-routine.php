<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage Class Routines - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_CLASS_ROUTINES)) {
    include_once("../../includes/permission-denied.php");
}


// Fetch all classes and sections
$classes = $pdo->query("SELECT * FROM classes ORDER BY class_name")->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
    .delete-routine-btn {
        transition: all 0.2s;
        width: 30px;
        height: 30px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }

    .delete-routine-btn:hover {
        transform: scale(1.1);
    }

    .deleting {
        opacity: 0.5;
        background-color: #ffeeee;
    }
</style>

<div class="container py-4">
    <div class="card border-0 shadow-lg">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-calendar-alt me-2"></i> View Class Routine</h3>
                <a href="../class/add-class-routine.php" class="btn btn-light btn-sm">
                    <i class="fas fa-plus me-1"></i> Add Class Routine
                </a>
            </div>
        </div>
        <div class="card-body">
            <form id="routineFilterForm" class="row g-3">
                <div class="col-md-6">
                    <label for="class_id" class="form-label">Class</label>
                    <select class="form-select select2" id="class_id" name="class_id" required>
                        <option value="" selected disabled>Select Class</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?= $class['id'] ?>"><?= safe_htmlspecialchars($class['class_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="section_id" class="form-label">Section</label>
                    <select class="form-select select2" id="section_id" name="section_id" required disabled>
                        <option value="" selected disabled>Select Section</option>
                    </select>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search me-2"></i> View Routine
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div id="routineContainer" class="card border-0 shadow-lg mt-4">
        <div class="card-header bg-info text-white">
            <h3 class="mb-0"><i class="fas fa-table me-2"></i> Class Routine</h3>
        </div>
        <div class="card-body">
            <div class="text-center py-5">
                <i class="fas fa-calendar fa-3x text-muted mb-3"></i>
                <p class="text-muted">Select a class and section to view the routine</p>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Initialize Select2
        $('.select2').select({
            theme: 'bootstrap-5',
            width: '100%'
        });

        // Load sections when class is selected
        $('#class_id').change(function() {
            var classId = $(this).val();
            if (classId) {
                $('#section_id').prop('disabled', false);
                $.ajax({
                    url: '../../api/admin/get/class/get-sections-by-class.php',
                    type: 'GET',
                    data: {
                        class_id: classId
                    },
                    dataType: 'json',
                    beforeSend: function() {
                        $('#section_id').html('<option value="" selected disabled>Loading...</option>');
                    },
                    success: function(response) {
                        var options = '<option value="" selected disabled>Select Section</option>';
                        $.each(response, function(index, section) {
                            options += '<option value="' + section.id + '">' + section.section_name + '</option>';
                        });
                        $('#section_id').html(options);
                        $('#section_id').select({
                            theme: 'bootstrap-5',
                            width: '100%'
                        });
                    },
                    error: function(xhr) {
                        $('#section_id').html('<option value="" selected disabled>Error loading sections</option>');
                        console.error(xhr.responseText);
                    }
                });
            } else {
                $('#section_id').prop('disabled', true).html('<option value="" selected disabled>Select Section</option>');
            }
        });

        // Form submission to load routine
        $('#routineFilterForm').on('submit', function(e) {
            e.preventDefault();
            var classId = $('#class_id').val();
            var sectionId = $('#section_id').val();

            if (!classId || !sectionId) {
                toastr.error('Please select both class and section');
                return;
            }

            $.ajax({
                url: '../../api/admin/get/class/get-class-routine.php',
                type: 'POST',
                data: {
                    class_id: classId,
                    section_id: sectionId
                },
                beforeSend: function() {
                    $('#routineContainer .card-body').html(`
                        <div class="text-center py-4">
                            <i class="fas fa-spinner fa-spin fa-2x text-primary mb-3"></i>
                            <p>Loading routine...</p>
                        </div>
                    `);
                },
                success: function(response) {
                    $('#routineContainer .card-body').html(response);
                },
                error: function(xhr) {
                    $('#routineContainer .card-body').html(`
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            Failed to load routine. Please try again.
                        </div>
                    `);
                    console.error(xhr.responseText);
                }
            });
        });


        // Handle delete routine button clicks with SweetAlert2 and Toastr
        $(document).on('click', '.delete-routine-btn', function() {
            const routineId = $(this).data('routine-id');
            const $row = $(this).closest('tr');
            const dayName = $row.find('td:first').text().trim();

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel',
                reverseButtons: true,
                showLoaderOnConfirm: true,
                preConfirm: () => {
                    $row.addClass('deleting');
                    $(this).html('<i class="fas fa-spinner fa-spin"></i>').prop('disabled', true);
                    return $.ajax({
                        url: '../../api/admin/delete/class/delete-class-routine.php',
                        type: 'POST',
                        data: {
                            routine_id: routineId
                        },
                        dataType: 'json'
                    }).fail(error => {
                        Swal.showValidationMessage(
                            `Request failed: ${error.statusText}`
                        );
                    });
                },
                allowOutsideClick: () => !Swal.isLoading()
            }).then((result) => {

                $row.removeClass('deleting');
                $(this).html('<i class="fas fa-trash-alt"></i>').prop('disabled', false);

                if (result.isConfirmed) {
                    const response = result.value;

                    if (response.success) {
                        // Show success notification
                        toastr.success(response.message, 'Success', {
                            closeButton: true,
                            progressBar: true,
                            positionClass: 'toast-top-right',
                            timeOut: 3000
                        });

                        // Remove the row with animation
                        $row.fadeOut(300, function() {
                            $(this).remove();

                            // Check if this was the last routine for the day
                            const dayRows = $(`tr:contains('${dayName}')`).not('.bg-light');
                            if (dayRows.length === 0) {
                                // Remove the day header row if no more routines exist for that day
                                $(`td:contains('${dayName}')`).closest('tr').remove();
                            }
                        });
                    } else {
                        // Show error notification
                        toastr.error(response.message, 'Error', {
                            closeButton: true,
                            progressBar: true,
                            positionClass: 'toast-top-right',
                            timeOut: 5000
                        });
                    }
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>