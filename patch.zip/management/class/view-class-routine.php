<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage Class Routines - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// check admin permission
if (!hasPermission(PERM_MANAGE_CLASS_ROUTINES)) {
    include_once("../../includes/permission-denied.php");
}

// Fixed days of the week
$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

// Fetch all classes
$classes = $pdo->query("SELECT * FROM classes ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);

// Fetch teachers for the modal dropdown
$teachers = $pdo->query("SELECT * FROM teachers WHERE status = 'active' ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
    .delete-routine-btn, .edit-routine-btn {
        transition: all 0.2s;
        width: 30px;
        height: 30px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }
    .delete-routine-btn:hover, .edit-routine-btn:hover {
        transform: scale(1.1);
    }
    .deleting {
        opacity: 0.5;
        background-color: #ffeeee;
    }
</style>

<div class="container py-4">
    <div class="card border-0 shadow-lg">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-calendar-alt me-2"></i> View Class Routine</h3>
                <a href="../class/add-class-routine.php" class="btn btn-light btn-sm">
                    <i class="fas fa-plus me-1"></i> Add Class Routine
                </a>
            </div>
        </div>
        <div class="card-body">
            <form id="routineFilterForm" class="row g-3">
                <div class="col-md-6">
                    <label for="class_id" class="form-label">Class</label>
                    <select class="form-select select2" id="class_id" name="class_id" required>
                        <option value="" selected disabled>Select Class</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?= $class['id'] ?>"><?= safe_htmlspecialchars($class['class_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="section_id" class="form-label">Section</label>
                    <select class="form-select select2" id="section_id" name="section_id" required disabled>
                        <option value="" selected disabled>Select Section</option>
                    </select>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search me-2"></i> View Routine
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div id="routineContainer" class="card border-0 shadow-lg mt-4">
        <div class="card-header bg-info text-white">
            <h3 class="mb-0"><i class="fas fa-table me-2"></i> Class Routine</h3>
        </div>
        <div class="card-body">
            <div class="text-center py-5">
                <i class="fas fa-calendar fa-3x text-muted mb-3"></i>
                <p class="text-muted">Select a class and section to view the routine</p>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="editRoutineModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Edit Routine</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editRoutineForm">
                    <input type="hidden" id="edit_routine_id" name="routine_id">
                    <input type="hidden" id="edit_class_id" name="class_id">
                    <input type="hidden" id="edit_section_id" name="section_id">

                    <div class="row g-3">
                        <div class="col-md-4">
                            <label for="edit_day_name" class="form-label">Day</label>
                            <select class="form-select" id="edit_day_name" name="day_name" required>
                                <?php foreach ($days as $day): ?>
                                    <option value="<?= $day ?>"><?= $day ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="edit_start_time" class="form-label">Start Time</label>
                            <input type="time" class="form-control" id="edit_start_time" name="start_time" required>
                        </div>
                        <div class="col-md-4">
                            <label for="edit_end_time" class="form-label">End Time</label>
                            <input type="time" class="form-control" id="edit_end_time" name="end_time" required>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_subject_id" class="form-label">Subject</label>
                            <select class="form-select" id="edit_subject_id" name="subject_id" required>
                                <option value="" selected disabled>Loading...</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_teacher_id" class="form-label">Teacher</label>
                            <select class="form-select" id="edit_teacher_id" name="teacher_id">
                                <option value="" selected disabled>Select Teacher</option>
                                <?php foreach ($teachers as $teacher): ?>
                                    <option value="<?= $teacher['id'] ?>"><?= safe_htmlspecialchars($teacher['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-12">
                            <label for="edit_room_number" class="form-label">Room Number</label>
                            <input type="text" class="form-control" id="edit_room_number" name="room_number">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="saveRoutineChangesBtn">Save Changes</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Initialize Select2
        $('.select2').select({
            theme: 'bootstrap-5',
            width: '100%'
        });

        // Load sections when class is selected
        $('#class_id').change(function() {
            var classId = $(this).val();
            if (classId) {
                $('#section_id').prop('disabled', false);
                $.ajax({
                    url: '../../api/admin/get/class/get-sections-by-class.php',
                    type: 'GET',
                    data: { class_id: classId },
                    dataType: 'json',
                    beforeSend: function() {
                        $('#section_id').html('<option value="" selected disabled>Loading...</option>');
                    },
                    success: function(response) {
                        var options = '<option value="" selected disabled>Select Section</option>';
                        $.each(response, function(index, section) {
                            options += '<option value="' + section.id + '">' + section.section_name + '</option>';
                        });
                        $('#section_id').html(options);
                    }
                });
            } else {
                $('#section_id').prop('disabled', true).html('<option value="" selected disabled>Select Section</option>');
            }
        });

        // Load routine table
        function loadRoutineTable() {
            var classId = $('#class_id').val();
            var sectionId = $('#section_id').val();

            if (!classId || !sectionId) return;

            $.ajax({
                url: '../../api/admin/get/class/get-class-routine.php',
                type: 'POST',
                data: { class_id: classId, section_id: sectionId },
                beforeSend: function() {
                    $('#routineContainer .card-body').html('<div class="text-center py-4"><i class="fas fa-spinner fa-spin fa-2x text-primary"></i></div>');
                },
                success: function(response) {
                    $('#routineContainer .card-body').html(response);
                },
                error: function() {
                     $('#routineContainer .card-body').html('<div class="alert alert-danger">Error loading routine</div>');
                }
            });
        }

        $('#routineFilterForm').on('submit', function(e) {
            e.preventDefault();
            loadRoutineTable();
        });

        // ----------------------------------------------------
        // EDIT FUNCTIONALITY
        // ----------------------------------------------------
        $(document).on('click', '.edit-routine-btn', function() {
            var routineId = $(this).data('routine-id');
            var currentClassId = $('#class_id').val();
            var currentSectionId = $('#section_id').val();
            
            // Set hidden fields
            $('#edit_class_id').val(currentClassId);
            $('#edit_section_id').val(currentSectionId);

            // Fetch Routine Details
            $.ajax({
                url: '../../api/admin/get/class/get-routine-details.php',
                type: 'GET',
                data: { routine_id: routineId },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        var data = response.data;
                        
                        $('#edit_routine_id').val(data.id);
                        $('#edit_day_name').val(data.day_name);
                        $('#edit_start_time').val(data.start_time);
                        $('#edit_end_time').val(data.end_time);
                        $('#edit_room_number').val(data.room_number);
                        $('#edit_teacher_id').val(data.teacher_id);
                        
                        // Load Subjects for the selected class, then select the correct one
                        $.ajax({
                            url: '../../api/admin/get/subject/get-subjects.php',
                            type: 'GET',
                            data: { class_id: currentClassId },
                            dataType: 'json',
                            success: function(subjects) {
                                var options = '<option value="" disabled>Select Subject</option>';
                                $.each(subjects, function(index, sub) {
                                    var selected = (sub.id == data.subject_id) ? 'selected' : '';
                                    options += '<option value="' + sub.id + '" ' + selected + '>' + sub.subject_name + '</option>';
                                });
                                $('#edit_subject_id').html(options);
                            }
                        });

                        // Show Modal
                        var myModal = new bootstrap.Modal(document.getElementById('editRoutineModal'));
                        myModal.show();
                    } else {
                        toastr.error('Could not fetch routine details');
                    }
                }
            });
        });

        // Save Changes
        $('#saveRoutineChangesBtn').click(function() {
            var btn = $(this);
            var form = $('#editRoutineForm');
            
            // Basic Time Validation
            var start = $('#edit_start_time').val();
            var end = $('#edit_end_time').val();
            if(start >= end) {
                toastr.error('End time must be after start time');
                return;
            }

            btn.prop('disabled', true).text('Saving...');

            $.ajax({
                url: '../../api/admin/put/class/update-class-routine.php',
                type: 'POST',
                data: form.serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        $('#editRoutineModal').modal('hide'); // Hide modal
                        $('.modal-backdrop').remove(); // Ensure backdrop is removed
                        loadRoutineTable(); // Refresh table
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function() {
                    toastr.error('An error occurred');
                },
                complete: function() {
                    btn.prop('disabled', false).text('Save Changes');
                }
            });
        });

        // ----------------------------------------------------
        // DELETE FUNCTIONALITY (Keep existing)
        // ----------------------------------------------------
        $(document).on('click', '.delete-routine-btn', function() {
            const routineId = $(this).data('routine-id');
            const $row = $(this).closest('tr');
            
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '../../api/admin/delete/class/delete-class-routine.php',
                        type: 'POST',
                        data: { routine_id: routineId },
                        dataType: 'json',
                        success: function(response) {
                            if (response.success) {
                                toastr.success(response.message);
                                loadRoutineTable(); // Reload to fix rowspan layout
                            } else {
                                toastr.error(response.message);
                            }
                        }
                    });
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>