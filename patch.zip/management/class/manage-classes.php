<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage Classes & Sections - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if ($_SESSION['user']['role'] !== 'superadmin') {
    include_once("../../includes/permission-denied.php");
}

// Fetch all classes and their sections
$classes = $pdo->query("SELECT * FROM classes ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="mb-0"><i class="fas fa-cogs me-2"></i>Manage Classes & Sections</h2>
        <div>
            <a href="../class/add-class.php" class="btn btn-primary">
                <i class="fas fa-plus me-2"></i>Add Class
            </a>
            <a href="../class/add-section.php" class="btn btn-secondary">
                <i class="fas fa-plus me-2"></i>Add Section
            </a>
        </div>
    </div>

    <div id="classes-container">
        <?php if (count($classes) > 0): ?>
            <div class="row">
                <?php foreach ($classes as $class): ?>
                    <div class="col-md-6 mb-4" id="class-<?= $class['id'] ?>">
                        <div class="card shadow-sm h-100">
                            <div class="card-header d-flex justify-content-between align-items-center bg-primary text-white">
                                <div>
                                    <h5 class="mb-0"><?= safe_htmlspecialchars($class['class_name']) ?></h5>
                                    <?php if ($class['is_final_class']): ?>
                                        <span class="badge bg-warning text-dark">Final Class</span>
                                    <?php endif; ?>
                                </div>
                                <div>
                                    <button class="btn btn-sm btn-light toggle-final-class me-2"
                                        data-id="<?= $class['id'] ?>"
                                        data-current="<?= $class['is_final_class'] ?>">
                                        <i class="fas fa-graduation-cap me-1"></i>
                                        <?= $class['is_final_class'] ? 'Unmark Final' : 'Mark Final' ?>
                                    </button>
                                    <button class="btn btn-sm btn-light delete-class" data-id="<?= $class['id'] ?>">
                                        <i class="fas fa-trash me-1"></i>Delete
                                    </button>
                                    <button class="btn btn-sm btn-warning rename-btn" data-rename="class" data-id="<?= $class['id'] ?>">
                                        <i class="fas fa-pencil me-1"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="card-body">
                                <?php
                                $stmt = $pdo->prepare("SELECT * FROM sections WHERE class_id = :class_id ORDER BY section_name");
                                $stmt->execute([':class_id' => $class['id']]);
                                $sections = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                ?>

                                <h6 class="mb-3">Sections:</h6>

                                <div class="sections-list" id="sections-<?= $class['id'] ?>">
                                    <?php if (count($sections) > 0): ?>
                                        <?php foreach ($sections as $section): ?>
                                            <div class="list-group-item d-flex justify-content-between align-items-center mb-2" id="section-<?= $section['id'] ?>">
                                                <span>Section <?= safe_htmlspecialchars($section['section_name']) ?></span>
                                                <div class="section-action-btns">
                                                    <button class="btn btn-sm btn-outline-danger delete-section" data-id="<?= $section['id'] ?>">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                    <button class="btn btn-sm btn-outline-primary rename-btn" data-rename="section" data-id="<?= $section['id'] ?>">
                                                        <i class="fas fa-pencil"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <div class="alert alert-info mb-0">No sections added yet.</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i>No classes found. Add your first class to get started.
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Toggle final class status
        $(document).on('click', '.toggle-final-class', function(e) {
            e.preventDefault();
            var classId = $(this).data('id');
            var currentStatus = $(this).data('current');
            var button = $(this);
            var className = $('#class-' + classId).find('.card-header h5').text();

            Swal.fire({
                title: currentStatus ? 'Unmark Final Class?' : 'Mark as Final Class?',
                html: `Are you sure you want to ${currentStatus ? 'remove' : 'set'} <strong>${className}</strong> as ${currentStatus ? 'a regular class' : 'the final class'}?`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: currentStatus ? 'Yes, unmark it' : 'Yes, mark it',
                cancelButtonText: 'Cancel',
                showLoaderOnConfirm: true,
                preConfirm: () => {
                    return $.ajax({
                        url: '../../api/admin/put/class/toggle-final-class.php',
                        type: 'POST',
                        data: {
                            class_id: classId,
                            new_status: currentStatus ? 0 : 1
                        },
                        dataType: 'json'
                    }).then(response => {
                        return response;
                    }).catch(error => {
                        Swal.showValidationMessage(
                            'Request failed: ' + error.responseText
                        );
                    });
                }
            }).then((result) => {
                if (result.isConfirmed && result.value.success) {
                    // Update button appearance
                    button.data('current', !currentStatus);
                    button.html(`
                    <i class="fas fa-graduation-cap me-1"></i>
                    ${!currentStatus ? 'Unmark Final' : 'Mark Final'}
                `);

                    // Update badge in header
                    var header = $('#class-' + classId).find('.card-header');
                    if (!currentStatus) {
                        header.find('h5').after('<span class="badge bg-warning text-dark">Final Class</span>');
                    } else {
                        header.find('.badge').remove();
                    }

                    toastr.success(result.value.message);
                } else if (result.isConfirmed && !result.value.success) {
                    toastr.error(result.value.message);
                }
            });
        });

        // Class deletion with SweetAlert and AJAX
        $(document).on('click', '.delete-class', function(e) {
            e.preventDefault();
            var classId = $(this).data('id');
            var classCard = $('#class-' + classId);
            var className = classCard.find('.card-header h5').text();

            Swal.fire({
                title: 'Delete Class?',
                html: `Are you sure you want to delete <strong>${className}</strong> and all its sections?<br>This action cannot be undone!`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel',
                showLoaderOnConfirm: true,
                preConfirm: () => {
                    return $.ajax({
                        url: '../../api/admin/delete/class/delete-class.php',
                        type: 'POST',
                        data: {
                            class_id: classId
                        },
                        dataType: 'json'
                    }).then(response => {
                        return response;
                    }).catch(error => {
                        Swal.showValidationMessage(
                            'Request failed: ' + error.responseText
                        );
                    });
                }
            }).then((result) => {
                if (result.isConfirmed && result.value.success) {
                    classCard.fadeOut(300, function() {
                        $(this).remove();
                        checkEmptyState();
                    });
                    toastr.success(result.value.message);
                } else if (result.isConfirmed && !result.value.success) {
                    toastr.error(result.value.message);
                }
            });
        });

        // Section deletion with SweetAlert and AJAX
        $(document).on('click', '.delete-section', function(e) {
            e.preventDefault();
            var sectionId = $(this).data('id');
            var sectionItem = $('#section-' + sectionId);
            var sectionName = sectionItem.find('span').text();
            var classId = sectionItem.closest('.card').find('.delete-class').data('id');

            Swal.fire({
                title: 'Delete Section?',
                html: `Are you sure you want to delete <strong>${sectionName}</strong>?<br>This action cannot be undone!`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel',
                showLoaderOnConfirm: true,
                preConfirm: () => {
                    return $.ajax({
                        url: '../../api/admin/delete/class/delete-section.php',
                        type: 'POST',
                        data: {
                            section_id: sectionId
                        },
                        dataType: 'json'
                    }).then(response => {
                        return response;
                    }).catch(error => {
                        Swal.showValidationMessage(
                            'Request failed: ' + error.responseText
                        );
                    });
                }
            }).then((result) => {
                if (result.isConfirmed && result.value.success) {
                    sectionItem.fadeOut(300, function() {
                        $(this).remove();
                        checkSectionsEmptyState(classId);
                    });
                    toastr.success(result.value.message);
                } else if (result.isConfirmed && !result.value.success) {
                    toastr.error(result.value.message);
                }
            });
        });

        // Rename button click
        $(document).on('click', '.rename-btn', function(e) {
            e.preventDefault();

            let itemId = $(this).data('id');
            let itemType = $(this).data('rename');

            let classCard = $('#class-' + itemId);
            let classNameSelector = classCard.find('.card-header h5');
            let className = classNameSelector.text();

            let sectionItem = $('#section-' + itemId);
            let sectionNameSelector = sectionItem.find('span');
            let sectionName = sectionNameSelector.text();

            let itemName = "";

            if (itemType == 'section') {
                itemName = sectionName;
            }

            if (itemType == 'class') {
                itemName = className;
            }

            Swal.fire({
                title: `Rename ${itemType} (${itemName})`,
                input: "text",
                icon: 'warning',
                inputAttributes: {
                    autocapitalize: "off"
                },
                inputValidator: (value) => {
                    if (!value) {
                        return 'Please enter a value!' // message shown if empty
                    }
                },
                showCancelButton: true,
                confirmButtonColor: '<?= $theme_color ?>',
                cancelButtonColor: '#f10000ff',
                confirmButtonText: 'Yes, rename it!',
                cancelButtonText: 'Cancel',
                showLoaderOnConfirm: true,
                preConfirm: (newName) => {
                    return $.ajax({
                        url: '../../api/admin/put/class/rename-class-x-section.php',
                        type: 'POST',
                        data: {
                            itemId: itemId,
                            itemType: itemType,
                            newName: newName
                        },
                        dataType: 'json'
                    }).then(response => {
                        return response;
                    }).catch(error => {
                        Swal.showValidationMessage(
                            'Request failed: ' + error.responseText
                        );
                    });
                }
            }).then((result) => {
                if (result.isConfirmed && result.value.success) {
                    if (itemType == 'section') {
                        sectionNameSelector.text('Section ' + result.value.newName);
                    }
                    if (itemType == 'class') {
                        classNameSelector.text(result.value.newName);
                    }
                    toastr.success(result.value.message);
                } else if (result.isConfirmed && !result.value.success) {
                    toastr.error(result.value.message);
                }
            });
        });

        // Check if all classes are deleted
        function checkEmptyState() {
            if ($('#classes-container .col-md-6').length === 0) {
                $('#classes-container').html(`
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>No classes found. Add your first class to get started.
                </div>
            `);
            }
        }

        // Check if all sections are deleted for a class
        function checkSectionsEmptyState(classId) {
            var sectionsList = $('#sections-' + classId);
            if (sectionsList.children('.list-group-item').length === 0) {
                sectionsList.html(`
                <div class="alert alert-info mb-0">No sections added yet.</div>
            `);
            }
        }
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>