<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Add Class Routines - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_CLASS_ROUTINES)) {
    include_once("../../includes/permission-denied.php");
}

// Fixed days of the week
$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

// Fetch other data
$classes = $pdo->query("SELECT * FROM classes ORDER BY class_name")->fetchAll(PDO::FETCH_ASSOC);
$subjects = $pdo->query("SELECT * FROM subjects ORDER BY subject_name")->fetchAll(PDO::FETCH_ASSOC);
$teachers = $pdo->query("SELECT * FROM teachers WHERE status = 'active' ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container py-4">
    <div class="card border-0 shadow-lg">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-calendar-plus me-2"></i> Add Class Routine</h3>
                <a href="../class/view-class-routine.php" class="btn btn-light btn-sm">
                    <i class="fas fa-eye me-1"></i> View Routines
                </a>
            </div>
        </div>
        <div class="card-body">
            <div id="message-container"></div>

            <form id="addRoutineForm" class="needs-validation" novalidate>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="class_id" class="form-label">Class</label>
                        <select class="form-select select2" id="class_id" name="class_id" required>
                            <option value="" selected disabled>Select Class</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?= $class['id'] ?>"><?= safe_htmlspecialchars($class['class_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback">Please select a class</div>
                    </div>

                    <div class="col-md-6">
                        <label for="section_id" class="form-label">Section</label>
                        <select class="form-select select2" id="section_id" name="section_id" required disabled>
                            <option value="" selected disabled>Select Section</option>
                        </select>
                        <div class="invalid-feedback">Please select a section</div>
                    </div>

                    <div class="col-md-4">
                        <label for="day_name" class="form-label">Day</label>
                        <select class="form-select select2" id="day_name" name="day_name" required>
                            <option value="" selected disabled>Select Day</option>
                            <?php foreach ($days as $day): ?>
                                <option value="<?= $day ?>"><?= $day ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback">Please select a day</div>
                    </div>

                    <div class="col-md-4">
                        <label for="start_time" class="form-label">Start Time</label>
                        <input type="time" class="form-control" id="start_time" name="start_time" required>
                        <div class="invalid-feedback">Please select start time</div>
                    </div>

                    <div class="col-md-4">
                        <label for="end_time" class="form-label">End Time</label>
                        <input type="time" class="form-control" id="end_time" name="end_time" required>
                        <div class="invalid-feedback">Please select end time</div>
                    </div>

                    <div class="col-md-6">
                        <label for="subject_id" class="form-label">Subject</label>
                        <select class="form-select select2" id="subject_id" name="subject_id" required disabled>
                            <option value="" selected disabled>Select Subject</option>
                            <!-- Subjects will be loaded via AJAX -->
                        </select>
                        <div class="invalid-feedback">Please select a subject</div>
                    </div>

                    <div class="col-md-6">
                        <label for="teacher_id" class="form-label">Teacher</label>
                        <select class="form-select select2" id="teacher_id" name="teacher_id">
                            <option value="" selected disabled>Select Teacher</option>
                            <?php foreach ($teachers as $teacher): ?>
                                <option value="<?= $teacher['id'] ?>"><?= safe_htmlspecialchars($teacher['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="invalid-feedback">Please select a teacher</div>
                    </div>

                    <div class="col-md-12">
                        <label for="room_number" class="form-label">Room Number</label>
                        <input type="text" class="form-control" id="room_number" name="room_number" placeholder="Optional">
                    </div>
                </div>

                <div class="d-flex justify-content-end mt-4">
                    <button type="submit" class="btn btn-primary px-4 py-2" id="submitBtn">
                        <i class="fas fa-save me-2"></i> Save Routine
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div id="routineContainer" class="card border-0 shadow-lg mt-4">
        <div class="card-header bg-info text-white">
            <h3 class="mb-0"><i class="fas fa-table me-2"></i> Class Routine</h3>
        </div>
        <div class="card-body">
            <div class="text-center py-5">
                <i class="fas fa-calendar fa-3x text-muted mb-3"></i>
                <p class="text-muted">Select a class and section to view the routine</p>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

        // Load sections and subjects when class is selected
        $('#class_id').change(function() {
            var classId = $(this).val();
            if (classId) {
                // Enable and load sections
                $('#section_id').prop('disabled', false);
                loadSections(classId);
                
                // Enable and load subjects
                $('#subject_id').prop('disabled', false);
                loadSubjects(classId);
            } else {
                $('#section_id').prop('disabled', true).html('<option value="" selected disabled>Select Section</option>');
                $('#subject_id').prop('disabled', true).html('<option value="" selected disabled>Select Subject</option>');
            }
        });

        // When section changes, load existing routines
        $('#section_id').change(function() {
            var classId = $('#class_id').val();
            if (classId) {
                loadExistingRoutines(classId);
            }
        });

        // Function to load sections
        function loadSections(classId) {
            $.ajax({
                url: '../../api/admin/get/class/get-sections-by-class.php',
                type: 'GET',
                data: { class_id: classId },
                dataType: 'json',
                beforeSend: function() {
                    $('#section_id').html('<option value="" selected disabled>Loading...</option>');
                },
                success: function(response) {
                    var options = '<option value="" selected disabled>Select Section</option>';
                    $.each(response, function(index, section) {
                        options += '<option value="' + section.id + '">' + section.section_name + '</option>';
                    });
                    $('#section_id').html(options);
                    $('#section_id').select({
                        theme: 'bootstrap-5',
                        width: '100%'
                    });
                },
                error: function(xhr) {
                    $('#section_id').html('<option value="" selected disabled>Error loading sections</option>');
                    console.error(xhr.responseText);
                }
            });
        }

        // Function to load subjects
        function loadSubjects(classId) {
            $.ajax({
                url: '../../api/admin/get/subject/get-subjects.php',
                type: 'GET',
                data: { class_id: classId },
                dataType: 'json',
                beforeSend: function() {
                    $('#subject_id').html('<option value="" selected disabled>Loading...</option>');
                },
                success: function(response) {
                    var options = '<option value="" selected disabled>Select Subject</option>';
                    $.each(response, function(index, subject) {
                        options += '<option value="' + subject.id + '">' + subject.subject_name + '</option>';
                    });
                    $('#subject_id').html(options);
                    $('#subject_id').select({
                        theme: 'bootstrap-5',
                        width: '100%'
                    });
                },
                error: function(xhr) {
                    $('#subject_id').html('<option value="" selected disabled>Error loading subjects</option>');
                    console.error(xhr.responseText);
                }
            });
        }

        // Function to load existing routines for the selected class/section
        function loadExistingRoutines(classId) {
            var sectionId = $('#section_id').val();
            if (!sectionId) return;
            
            $.ajax({
                url: '../../api/admin/get/class/get-class-routine.php',
                type: 'POST',
                data: { 
                    class_id: classId,
                    section_id: sectionId
                },
                dataType: 'html',
                beforeSend: function() {
                    $('#routineContainer .card-body').html(`
                        <div class="text-center py-4">
                            <i class="fas fa-spinner fa-spin fa-2x text-primary mb-3"></i>
                            <p>Loading routine...</p>
                        </div>
                    `);
                },
                success: function(response) {
                    $('#routineContainer .card-body').html(response);
                },
                error: function(xhr) {
                    $('#routineContainer .card-body').html(`
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            Failed to load routine. Please try again.
                        </div>
                    `);
                    console.error(xhr.responseText);
                }
            });
        }

        // Handle delete routine button clicks with SweetAlert2 and Toastr
        $(document).on('click', '.delete-routine-btn', function() {
            const routineId = $(this).data('routine-id');
            const $row = $(this).closest('tr');
            const dayName = $row.find('td:first').text().trim();

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel',
                reverseButtons: true,
                showLoaderOnConfirm: true,
                preConfirm: () => {
                    $row.addClass('deleting');
                    $(this).html('<i class="fas fa-spinner fa-spin"></i>').prop('disabled', true);
                    return $.ajax({
                        url: '../../api/admin/delete/class/delete-class-routine.php',
                        type: 'POST',
                        data: {
                            routine_id: routineId
                        },
                        dataType: 'json'
                    }).fail(error => {
                        Swal.showValidationMessage(
                            `Request failed: ${error.statusText}`
                        );
                    });
                },
                allowOutsideClick: () => !Swal.isLoading()
            }).then((result) => {

                $row.removeClass('deleting');
                $(this).html('<i class="fas fa-trash-alt"></i>').prop('disabled', false);

                if (result.isConfirmed) {
                    const response = result.value;

                    if (response.success) {
                        // Show success notification
                        toastr.success(response.message, 'Success', {
                            closeButton: true,
                            progressBar: true,
                            positionClass: 'toast-top-right',
                            timeOut: 3000
                        });

                        // Remove the row with animation
                        $row.fadeOut(300, function() {
                            $(this).remove();

                            // Check if this was the last routine for the day
                            const dayRows = $(`tr:contains('${dayName}')`).not('.bg-light');
                            if (dayRows.length === 0) {
                                // Remove the day header row if no more routines exist for that day
                                $(`td:contains('${dayName}')`).closest('tr').remove();
                            }
                        });
                    } else {
                        // Show error notification
                        toastr.error(response.message, 'Error', {
                            closeButton: true,
                            progressBar: true,
                            positionClass: 'toast-top-right',
                            timeOut: 5000
                        });
                    }
                }
            });
        });

        // Form submission with AJAX
        $('#addRoutineForm').on('submit', function(e) {
            e.preventDefault();
            var form = $(this);
            var submitBtn = $('#submitBtn');

            if (form[0].checkValidity() === false) {
                e.stopPropagation();
                form.addClass('was-validated');
                return;
            }

            // Validate time
            var startTime = new Date('1970-01-01T' + $('#start_time').val() + 'Z');
            var endTime = new Date('1970-01-01T' + $('#end_time').val() + 'Z');
            
            if (endTime <= startTime) {
                toastr.error('End time must be after start time');
                return;
            }

            submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i> Saving...');

            $.ajax({
                url: '../../api/admin/put/class/save-class-routine.php',
                type: 'POST',
                data: form.serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);

                        var classId = $('#class_id').val();
                        if (classId) {
                            loadExistingRoutines(classId);
                        }
                        // form[0].reset();
                        // form.removeClass('was-validated');
                        // $('.select2').val(null).trigger('change');
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr) {
                    toastr.error('An error occurred. Please try again.');
                    console.error(xhr.responseText);
                },
                complete: function() {
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i> Save Routine');
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>