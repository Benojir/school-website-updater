<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage Class Routines - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// check admin permission
if (!hasPermission(PERM_MANAGE_CLASS_ROUTINES)) {
    include_once("../../includes/permission-denied.php");
}

// Fixed days of the week
$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

// Fetch other data
$classes = $pdo->query("SELECT * FROM classes ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
$teachers = $pdo->query("SELECT * FROM teachers WHERE status = 'active' ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container py-4">
    
    <div class="card border-0 shadow-lg mb-4">
        <div class="card-header bg-primary text-white">
            <h3 class="mb-0"><i class="fas fa-calendar-plus me-2"></i> Add Class Routine</h3>
        </div>
        <div class="card-body">
            <form id="addRoutineForm" class="needs-validation" novalidate>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="class_id" class="form-label">Class</label>
                        <select class="form-select select2" id="class_id" name="class_id" required>
                            <option value="" selected disabled>Select Class</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?= $class['id'] ?>"><?= safe_htmlspecialchars($class['class_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="section_id" class="form-label">Section</label>
                        <select class="form-select select2" id="section_id" name="section_id" required disabled>
                            <option value="" selected disabled>Select Section</option>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="day_name" class="form-label">Day(s)</label>
                        <select class="form-select custom-multiselect" id="day_name" name="day_name[]" multiple="multiple" required>
                            <?php foreach ($days as $day): ?>
                                <option value="<?= $day ?>"><?= $day ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="start_time" class="form-label">Start Time</label>
                        <input type="time" class="form-control" id="start_time" name="start_time" required>
                    </div>

                    <div class="col-md-4">
                        <label for="end_time" class="form-label">End Time</label>
                        <input type="time" class="form-control" id="end_time" name="end_time" required>
                    </div>

                    <div class="col-md-6">
                        <label for="subject_id" class="form-label">Subject</label>
                        <select class="form-select select2" id="subject_id" name="subject_id" required disabled>
                            <option value="" selected disabled>Select Subject</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="teacher_id" class="form-label">Teacher</label>
                        <select class="form-select select2" id="teacher_id" name="teacher_id">
                            <option value="" selected disabled>Select Teacher</option>
                            <?php foreach ($teachers as $teacher): ?>
                                <option value="<?= $teacher['id'] ?>"><?= safe_htmlspecialchars($teacher['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-12">
                        <label for="room_number" class="form-label">Room Number</label>
                        <input type="text" class="form-control" id="room_number" name="room_number" placeholder="Optional">
                    </div>
                </div>

                <div class="d-flex justify-content-end mt-4">
                    <button type="submit" class="btn btn-primary px-4 py-2" id="submitBtn">
                        <i class="fas fa-save me-2"></i> Save Routine
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div id="routineContainer" class="card border-0 shadow-lg mt-4">
        <div class="card-header bg-primary text-white">
            <h3 class="mb-0"><i class="fas fa-table me-2"></i> Manage Class Routine</h3>
        </div>
        <div class="card-body">
            <div class="text-center py-5">
                <i class="fas fa-calendar fa-3x text-muted mb-3"></i>
                <p class="text-muted">Select a class and section above to view the routine</p>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="editRoutineModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Edit Routine</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editRoutineForm">
                    <input type="hidden" id="edit_routine_id" name="routine_id">
                    <input type="hidden" id="edit_class_id" name="class_id">
                    <input type="hidden" id="edit_section_id" name="section_id">

                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Day</label>
                            <select class="form-select" id="edit_day_name" name="day_name" required>
                                <?php foreach ($days as $day): ?>
                                    <option value="<?= $day ?>"><?= $day ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Start Time</label>
                            <input type="time" class="form-control" id="edit_start_time" name="start_time" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">End Time</label>
                            <input type="time" class="form-control" id="edit_end_time" name="end_time" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Subject</label>
                            <select class="form-select" id="edit_subject_id" name="subject_id" required>
                                <option value="" disabled>Loading...</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Teacher</label>
                            <select class="form-select" id="edit_teacher_id" name="teacher_id">
                                <option value="" selected disabled>Select Teacher</option>
                                <?php foreach ($teachers as $teacher): ?>
                                    <option value="<?= $teacher['id'] ?>"><?= safe_htmlspecialchars($teacher['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">Room Number</label>
                            <input type="text" class="form-control" id="edit_room_number" name="room_number">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="saveRoutineChangesBtn">Save Changes</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

        // Load sections and subjects when class is selected
        $('#class_id').change(function() {
            var classId = $(this).val();
            if (classId) {
                $('#section_id, #subject_id').prop('disabled', false);
                loadSections(classId);
                loadSubjects(classId);
            } else {
                $('#section_id, #subject_id').prop('disabled', true).html('<option value="" selected disabled>Select...</option>');
            }
        });

        // When section changes, load existing routines
        $('#section_id').change(function() {
            loadExistingRoutines();
        });

        function loadSections(classId) {
            $.ajax({
                url: '../../api/admin/get/class/get-sections-by-class.php',
                type: 'GET',
                data: { class_id: classId },
                dataType: 'json',
                success: function(response) {
                    var options = '<option value="" selected disabled>Select Section</option>';
                    $.each(response, function(i, item) { options += `<option value="${item.id}">${item.section_name}</option>`; });
                    $('#section_id').html(options);
                }
            });
        }

        function loadSubjects(classId) {
            $.ajax({
                url: '../../api/admin/get/subject/get-subjects.php',
                type: 'GET',
                data: { class_id: classId },
                dataType: 'json',
                success: function(response) {
                    var options = '<option value="" selected disabled>Select Subject</option>';
                    $.each(response, function(i, item) { options += `<option value="${item.id}">${item.subject_name}</option>`; });
                    $('#subject_id').html(options);
                }
            });
        }

        function loadExistingRoutines() {
            var classId = $('#class_id').val();
            var sectionId = $('#section_id').val();
            if (!classId || !sectionId) return;
            
            $.ajax({
                url: '../../api/admin/get/class/get-class-routine.php',
                type: 'POST',
                data: { class_id: classId, section_id: sectionId },
                beforeSend: function() {
                    $('#routineContainer .card-body').html('<div class="text-center py-4"><i class="fas fa-spinner fa-spin fa-2x text-primary"></i><p>Loading...</p></div>');
                },
                success: function(response) {
                    $('#routineContainer .card-body').html(response);
                }
            });
        }

        // --- ADD ROUTINE SUBMIT ---
        $('#addRoutineForm').on('submit', function(e) {
            e.preventDefault();
            var form = $(this);
            var submitBtn = $('#submitBtn');

            // Basic Date Validation
            if ($('#start_time').val() >= $('#end_time').val()) {
                toastr.error('End time must be after start time'); return;
            }

            submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i> Saving...');

            $.ajax({
                url: '../../api/admin/put/class/save-class-routine.php',
                type: 'POST',
                data: form.serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        loadExistingRoutines(); // Refresh Table
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function() { toastr.error('Error saving routine'); },
                complete: function() { submitBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i> Save Routine'); }
            });
        });

        // --- DELETE ROUTINE ---
        $(document).on('click', '.delete-routine-btn', function() {
            const routineId = $(this).data('routine-id');
            Swal.fire({
                title: 'Are you sure?', text: "You won't be able to revert this!", icon: 'warning',
                showCancelButton: true, confirmButtonColor: '#d33', confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '../../api/admin/delete/class/delete-class-routine.php',
                        type: 'POST',
                        data: { routine_id: routineId },
                        dataType: 'json',
                        success: function(res) {
                            if(res.success) { toastr.success(res.message); loadExistingRoutines(); }
                            else { toastr.error(res.message); }
                        }
                    });
                }
            });
        });

        // --- EDIT ROUTINE CLICK ---
        $(document).on('click', '.edit-routine-btn', function() {
            var routineId = $(this).data('routine-id');
            var classId = $('#class_id').val();
            var sectionId = $('#section_id').val();

            // Set hidden IDs for update script
            $('#edit_class_id').val(classId);
            $('#edit_section_id').val(sectionId);

            $.ajax({
                url: '../../api/admin/get/class/get-routine-details.php',
                type: 'GET',
                data: { routine_id: routineId },
                dataType: 'json',
                success: function(res) {
                    if (res.success) {
                        var data = res.data;
                        $('#edit_routine_id').val(data.id);
                        $('#edit_day_name').val(data.day_name);
                        $('#edit_start_time').val(data.start_time);
                        $('#edit_end_time').val(data.end_time);
                        $('#edit_room_number').val(data.room_number);
                        $('#edit_teacher_id').val(data.teacher_id);

                        // Load Subjects into Modal
                        $.ajax({
                            url: '../../api/admin/get/subject/get-subjects.php',
                            type: 'GET',
                            data: { class_id: classId },
                            dataType: 'json',
                            success: function(subs) {
                                var opts = '<option value="" disabled>Select Subject</option>';
                                $.each(subs, function(i, s) {
                                    var sel = (s.id == data.subject_id) ? 'selected' : '';
                                    opts += `<option value="${s.id}" ${sel}>${s.subject_name}</option>`;
                                });
                                $('#edit_subject_id').html(opts);
                            }
                        });

                        new bootstrap.Modal(document.getElementById('editRoutineModal')).show();
                    } else { toastr.error('Failed to fetch details'); }
                }
            });
        });

        // --- SAVE EDIT CHANGES ---
        $('#saveRoutineChangesBtn').click(function() {
            var btn = $(this);
            var form = $('#editRoutineForm');
            
            if ($('#edit_start_time').val() >= $('#edit_end_time').val()) {
                toastr.error('End time must be after start time'); return;
            }

            btn.prop('disabled', true).text('Saving...');

            $.ajax({
                url: '../../api/admin/put/class/update-class-routine.php',
                type: 'POST',
                data: form.serialize(),
                dataType: 'json',
                success: function(res) {
                    if (res.success) {
                        toastr.success(res.message);
                        $('#editRoutineModal').modal('hide');
                        loadExistingRoutines();
                    } else { toastr.error(res.message); }
                },
                error: function() { toastr.error('Update failed'); },
                complete: function() { btn.prop('disabled', false).text('Save Changes'); }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>