<?php
include_once("../../includes/auth-check.php");
require_once("../../includes/db.php");

// Handle the form submission (for both AJAX and regular POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $class_name = ucwords(trim($_POST['class_name']));
    $response = ['success' => false, 'message' => ''];

    if (!empty($class_name)) {
        $check = $pdo->prepare("SELECT * FROM classes WHERE class_name = :class_name");
        $check->execute([':class_name' => $class_name]);

        if ($check->rowCount() > 0) {
            $response['message'] = "Class already exists.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO classes (class_name) VALUES (:class_name)");
            if ($stmt->execute([':class_name' => $class_name])) {
                $response['success'] = true;
                $response['message'] = "Class added successfully!";
            } else {
                $response['message'] = "Failed to add class. Please try again.";
            }
        }
    } else {
        $response['message'] = "Please enter class name.";
    }

    // If it's an AJAX request, return JSON response
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

    // For non-AJAX requests, store the message to display later
    $message = $response['success']
        ? "<div class='alert alert-success mt-3'>{$response['message']}</div>"
        : "<div class='alert alert-danger mt-3'>{$response['message']}</div>";
}

// Now output the HTML
include_once("../../includes/header-open.php");
echo "<title>Add Classes - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if (!isSuperAdmin()) {
    include_once("../../includes/permission-denied.php");
}
?>

<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="mb-0"><i class="fas fa-school me-2"></i>Add New Class</h4>
                <a href="../class/add-section.php" class="btn btn-light btn-sm">
                    <i class="fas fa-plus me-1"></i> Add New Section
                </a>
            </div>
        </div>
        <div class="card-body">
            <div id="message-container"></div>

            <form id="addClassForm" method="POST" action="add-class.php">
                <div class="mb-3">
                    <label for="class_name" class="form-label">Class Name</label>
                    <input type="text" name="class_name" id="class_name" class="form-control"
                        placeholder="Please enter class name" required>
                    <div class="form-text">Enter the name of the class you want to add</div>
                </div>

                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button type="submit" class="btn btn-primary px-4">
                        <i class="fas fa-save me-2"></i>Save Class
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow-sm mt-5">
        <div class="card-header bg-info text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="mb-0"><i class="fas fa-school me-2"></i>All Classes</h4>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-striped table-bordered" id="classesTable">
                <thead>
                    <tr>
                        <th>Class ID</th>
                        <th>Class Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Ajax will load classes -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Load classes on page load
        loadClasses();

        // Handle form submission via AJAX
        $('#addClassForm').on('submit', function(e) {
            e.preventDefault();

            var form = $(this);
            var formData = form.serialize();
            var submitBtn = form.find('button[type="submit"]');

            // Disable button during processing
            submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Processing...');

            $.ajax({
                url: form.attr('action'),
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        form[0].reset();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred. Please try again.');
                    console.error(xhr.responseText);
                },
                complete: function() {
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i>Save Class');
                    loadClasses(); // Reload classes after submission
                }
            });
        });

        // Add PHP response handling for non-JS users
        <?php if (!empty($message)): ?>
            $('#message-container').html(`<?= $message ?>`);
        <?php endif; ?>

        // Function to Load classes
        function loadClasses() {
            $.ajax({
                url: '../../api/admin/get/class/get-all-classes.php',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        var tbody = $('#classesTable tbody');
                        tbody.empty();
                        response.data.forEach(function(classItem) {
                            tbody.append(`<tr id='class-${classItem.id}'>
                                <td>${classItem.id}</td>
                                <td>${classItem.name}</td>
                                <td>
                                    <button class='btn btn-sm btn-danger' onclick='deleteClass(${classItem.id}, "${classItem.name}")'>
                                        <i class='fas fa-trash'></i> Delete
                                    </button>
                                </td>
                            </tr>`);
                        });
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('Failed to load classes.');
                    console.error(xhr.responseText);
                }
            });
        }

        // Function to delete class
        window.deleteClass = function(classId, className) {
            var classRow = $('#class-' + classId);

            Swal.fire({
                title: 'Delete Class?',
                html: `Are you sure you want to delete <strong>${className}</strong> and all its sections?<br>This action cannot be undone!`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel',
                showLoaderOnConfirm: true,
                preConfirm: () => {
                    return $.ajax({
                        url: '../../api/admin/delete/class/delete-class.php',
                        type: 'POST',
                        data: {
                            class_id: classId
                        },
                        dataType: 'json'
                    }).then(response => {
                        return response;
                    }).catch(error => {
                        Swal.showValidationMessage(
                            'Request failed: ' + error.responseText
                        );
                    });
                }
            }).then((result) => {
                if (result.isConfirmed && result.value.success) {
                    classRow.fadeOut(300, function() {
                        $(this).remove();
                        // checkEmptyState();
                    });
                    toastr.success(result.value.message);
                } else if (result.isConfirmed && !result.value.success) {
                    toastr.error(result.value.message);
                }
            });
        };
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>