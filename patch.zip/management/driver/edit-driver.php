<?php
// Standard includes
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Edit Driver - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check permission
if (!hasPermission('PERM_MANAGE_TRANSPORT')) {
    include_once("../../includes/permission-denied.php");
    exit();
}

// Get Driver ID from URL
$driver_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($driver_id === 0) {
    echo '<div class="container py-5"><div class="alert alert-danger">Invalid Driver ID provided. <a href="list-drivers.php">Go back</a></div></div>';
    include_once("../../includes/body-close.php");
    exit();
}

// Fetch Driver Data
try {
    $stmt = $pdo->prepare("SELECT * FROM drivers WHERE id = :id");
    $stmt->execute(['id' => $driver_id]);
    $driver = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$driver) {
        echo '<div class="container py-5"><div class="alert alert-warning">Driver not found. <a href="list-drivers.php">Go back</a></div></div>';
        include_once("../../includes/body-close.php");
        exit();
    }
} catch (Exception $e) {
    echo '<div class="container py-5"><div class="alert alert-danger">Database error: ' . $e->getMessage() . '</div></div>';
    exit();
}

// Get routes for dropdown
$routes = $pdo->query("SELECT id, route_name FROM driving_routes ORDER BY route_name ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
    .image-preview-wrapper {
        border: 1px dashed #ccc;
        padding: 5px;
        margin-bottom: 10px;
        text-align: center;
        background-color: #f8f9fa;
        height: 250px;
        /* Slightly larger for the edit page */
        display: flex;
        align-items: center;
        justify-content: center;
    }

    #imagePreview {
        max-height: 100%;
        max-width: 100%;
        display: block;
    }

    .img-container {
        height: 500px;
        overflow: hidden;
        background: #f7f7f7;
    }
</style>

<div class="container py-4">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h3 class="mb-0"><i class="fas fa-edit me-2"></i> Edit Driver Details</h3>
            <a href="list-drivers.php" class="btn btn-light btn-sm"><i class="fas fa-arrow-left me-1"></i> Back to List</a>
        </div>

        <div class="card-body p-4">
            <form id="editDriverForm">
                <input type="hidden" name="id" value="<?php echo $driver['id']; ?>">

                <div class="row g-4">
                    <div class="col-md-7">
                        <h5 class="text-primary mb-3">Personal Information</h5>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Full Name <span class="text-danger">*</span></label>
                                <input type="text" name="name" class="form-control" value="<?php echo safe_htmlspecialchars($driver['name']); ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Email <span class="text-danger">*</span></label>
                                <input type="email" name="email" class="form-control" value="<?php echo safe_htmlspecialchars($driver['email']); ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Phone <span class="text-danger">*</span></label>
                                <input type="text" name="phone" class="form-control" value="<?php echo safe_htmlspecialchars($driver['phone']); ?>" required>
                            </div>
                        </div>

                        <h5 class="text-primary mt-4 mb-3">Assignment Details</h5>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Serial No. <span class="text-danger">*</span></label>
                                <input type="text" name="serial_number" class="form-control" value="<?php echo safe_htmlspecialchars($driver['serial_number']); ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Vehicle No.</label>
                                <input type="text" name="vehicle_number" class="form-control" value="<?php echo safe_htmlspecialchars($driver['vehicle_number']); ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Route <span class="text-danger">*</span></label>
                                <select name="route" class="form-select" required>
                                    <option value="">Select Route</option>
                                    <?php foreach ($routes as $route): ?>
                                        <option value="<?php echo $route['id']; ?>" <?php echo ($driver['route_id'] == $route['id']) ? 'selected' : ''; ?>>
                                            <?php echo safe_htmlspecialchars($route['route_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Aadhaar No.</label>
                                <input type="number" name="aadhaar_number" class="form-control" value="<?php echo safe_htmlspecialchars($driver['aadhaar_number']); ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Account Status <span class="text-danger">*</span></label>
                                <select name="status" class="form-select">
                                    <option value="active" <?php echo ($driver['status'] == 'active') ? 'selected' : ''; ?>>Active</option>
                                    <option value="inactive" <?php echo ($driver['status'] == 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                                </select>
                            </div>
                        </div>

                        <h5 class="text-primary mt-4 mb-3">Address</h5>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Village/Town.</label>
                                <input type="text" name="village" class="form-control" value="<?php echo safe_htmlspecialchars($driver['village']); ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Post Office.</label>
                                <input type="text" name="post_office" class="form-control" value="<?php echo safe_htmlspecialchars($driver['post_office']); ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Police Station.</label>
                                <input type="text" name="police_station" class="form-control" value="<?php echo safe_htmlspecialchars($driver['police_station']); ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">District.</label>
                                <input type="text" name="district" class="form-control" value="<?php echo safe_htmlspecialchars($driver['district']); ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Pincode.</label>
                                <input type="text" name="pincode" class="form-control" value="<?php echo safe_htmlspecialchars($driver['pincode']); ?>">
                            </div>
                        </div>
                    </div>

                    <div class="col-md-5">
                        <h5 class="text-primary mb-3">Driver Photo</h5>
                        <div class="card bg-light border-0">
                            <div class="card-body">
                                <div class="image-preview-wrapper mb-3">
                                    <img id="imagePreview" src="../../uploads/drivers/<?php echo !empty($driver['driver_image']) ? safe_htmlspecialchars($driver['driver_image']) : 'default_driver_dp.jpg'; ?>" class="img-fluid rounded">
                                </div>
                                <label for="driverPhoto" class="form-label fw-bold">Update Photo</label>
                                <input type="file" id="driverPhoto" name="driver_photo" class="form-control" accept="image/*">
                                <div class="form-text small">Recommended aspect ratio: 5:6</div>

                                <?php if (!empty($driver['driver_image'])): ?>
                                    <div class="form-check mt-3">
                                        <input class="form-check-input" type="checkbox" name="remove_photo" id="removePhoto">
                                        <label class="form-check-label text-danger" for="removePhoto">Remove current photo</label>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                    <button type="submit" class="btn btn-primary px-4"><i class="fas fa-save me-2"></i>Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="cropModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-crop me-2"></i> Crop Image</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="img-container">
                    <img id="modalCropper" src="" class="img-fluid">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" id="confirmCrop" class="btn btn-primary">Crop & Save</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        let cropper;
        let croppedImageBlob = null;
        let cropConfirmed = false;

        // --- Image Cropping Logic ---
        $('#driverPhoto').on('change', function(e) {
            if (this.files && this.files[0]) {
                cropConfirmed = false;
                const reader = new FileReader();
                reader.onload = (event) => {
                    $('#modalCropper').attr('src', event.target.result);
                    $('#cropModal').modal('show');
                };
                reader.readAsDataURL(this.files[0]);
            }
        });

        $('#cropModal').on('shown.bs.modal', function() {
            if (cropper) cropper.destroy();
            cropper = new Cropper(document.getElementById('modalCropper'), {
                aspectRatio: 5 / 6,
                viewMode: 1
            });
        });

        $('#confirmCrop').click(function() {
            if (!cropper) return;
            cropper.getCroppedCanvas({
                width: 500,
                height: 600
            }).toBlob((blob) => {
                croppedImageBlob = blob;
                $('#imagePreview').attr('src', URL.createObjectURL(blob));
                cropConfirmed = true;
                $('#cropModal').modal('hide');
            }, 'image/jpeg', 0.9);
        });

        $('#cropModal').on('hidden.bs.modal', function() {
            if (!cropConfirmed) $('#driverPhoto').val(null);
            if (cropper) {
                cropper.destroy();
                cropper = null;
            }
        });

        // --- Form Submission ---
        $('#editDriverForm').on('submit', function(e) {
            e.preventDefault();

            // Create FormData object
            const formData = new FormData(this);

            // Append cropped image if available
            if (croppedImageBlob) {
                formData.append('cropped_image', croppedImageBlob, 'driver_photo.jpg');
            }
            // Remove original file input from formData to avoid sending the uncropped version
            formData.delete('driver_photo');

            const submitBtn = $(this).find('button[type="submit"]');
            const originalBtnText = submitBtn.html();

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/put/driver/update-driver.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                processData: false,
                contentType: false,
                beforeSend: function() {
                    submitBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span>Saving...');
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message,
                            showConfirmButton: true,
                            confirmButtonText: 'OK',
                            customClass: {
                                confirmButton: 'btn btn-success px-4 py-2',
                                popup: 'rounded-4 shadow-lg'
                            },
                            willClose: () => {
                                window.location.href = 'list-drivers.php';
                            }
                        });
                    } else {
                        showErrorAlert(response.message);
                    }
                },
                error: function() {
                    showErrorAlert('An error occurred. Please try again.');
                },
                complete: function() {
                    submitBtn.prop('disabled', false).html(originalBtnText);
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>