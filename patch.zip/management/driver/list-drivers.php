<?php
// Standard includes for authentication, permission checks, and page headers.
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage Drivers - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check permission
if (!hasPermission('PERM_MANAGE_TRANSPORT')) {
    include_once("../../includes/permission-denied.php");
}
?>

<style>
    /* Ensures the action dropdown menu appears correctly within the responsive table */
    .table-responsive {
        overflow: visible !important;
    }
    /* Controls for bulk actions, hidden by default */
    .selection-controls {
        display: none;
    }
    #driversTableBody img {
        cursor: pointer;
    }
</style>

<div class="container py-4">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-shuttle-van me-2"></i> Driver Management</h3>
                <div class="d-flex gap-2">
                    <a href="../driver/add-driving-route.php" class="btn btn-light btn-sm">
                        <i class="fas fa-plus me-1"></i> Add Driving Route
                    </a>
                    <a href="../driver/add-driver.php" class="btn btn-light btn-sm">
                        <i class="fas fa-plus me-1"></i> Add Driver
                    </a>
                </div>
            </div>
        </div>

        <div class="card-body">
            <div class="row mb-4 align-items-center">
                <div class="col-md-8">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" id="searchInput" class="form-control" placeholder="Search drivers by name, email, phone, or vehicle...">
                        <select id="statusFilter" class="form-select" style="max-width: 150px;">
                            <option value="">All Status</option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                        <button id="refreshDrivers" class="btn btn-outline-secondary" title="Refresh list">
                            <i class="fas fa-sync-alt"></i>
                        </button>
                    </div>
                </div>
                <div class="col-md-4 text-end">
                    <div class="selection-controls">
                        <span id="selectionCount" class="me-3 fw-bold">0 selected</span>
                        <button id="id_cards_download_btn" class="btn btn-primary btn-sm">
                            <i class="fas fa-id-card me-2"></i>Download ID Cards
                        </button>
                    </div>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 5%;"><input class="form-check-input" type="checkbox" id="selectAllCheckbox"></th>
                            <th>ID</th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Vehicle No.</th>
                            <th>Status</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="driversTableBody">
                        </tbody>
                </table>
            </div>

            <nav>
                <ul class="pagination justify-content-center mt-3" id="paginationContainer">
                    </ul>
            </nav>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // --- STATE MANAGEMENT ---
        let currentPage = 1;
        const limit = 10; 
        let selectedDrivers = new Set(); 

        // --- CORE FUNCTIONS ---

        function loadDrivers(page = 1, search = '', status = '') {
            currentPage = page;
            $.ajax({
                url: '../../api/admin/get/driver/get-drivers.php',
                type: 'GET',
                data: {
                    page: page,
                    limit: limit,
                    search: search,
                    status: status
                },
                dataType: 'json',
                beforeSend: function() {
                    $('#driversTableBody').html(`<tr><td colspan="8" class="text-center py-4"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div></td></tr>`);
                },
                success: function(response) {
                    const tableBody = $('#driversTableBody');
                    if (response.drivers && response.drivers.length > 0) {
                        let html = '';
                        response.drivers.forEach((driver) => {
                            const isChecked = selectedDrivers.has(driver.id.toString());
                            // Build the HTML for each driver row.
                            html += `
                            <tr id="driver-${driver.id}" class="${isChecked ? 'table-primary' : ''}">
                                <td><input class="form-check-input driver-checkbox" type="checkbox" data-id="${driver.id}" ${isChecked ? 'checked' : ''}></td>
                                <td>${escapeHtml(driver.driver_id)}</td>
                                <td><img src="../../uploads/drivers/${driver.driver_image}" alt="${driver.name}" data-fancybox data-caption="${driver.name}" class="rounded-circle border" width="60" height="60"></td>
                                <td>${escapeHtml(driver.name)}</td>
                                <td>${escapeHtml(driver.email)}</td>
                                <td>${escapeHtml(driver.phone)}</td>
                                <td>${escapeHtml(driver.vehicle_number)}</td>
                                <td>
                                    <span class="badge ${driver.status === 'active' ? 'bg-success' : 'bg-secondary'}">
                                        ${capitalizeFirstLetter(driver.status)}
                                    </span>
                                </td>
                                <td class="text-end">
                                    <div class="dropdown action-dropdown">
                                        <button class="btn btn-sm btn-outline-primary dropdown-toggle" type="button" data-bs-toggle="dropdown"><i class="fas fa-cog"></i></button>
                                        <ul class="dropdown-menu dropdown-menu-end">
                                            <li><a class="dropdown-item" href="edit-driver.php?id=${driver.id}"><i class="fas fa-edit me-2"></i>Edit</a></li>
                                            <li><a class="dropdown-item status-btn" href="#" data-id="${driver.id}" data-status="${driver.status === 'active' ? 'inactive' : 'active'}"><i class="fas fa-power-off me-2"></i>${driver.status === 'active' ? 'Deactivate' : 'Activate'}</a></li>
                                            <li><hr class="dropdown-divider"></li>
                                            <li><a class="dropdown-item delete-btn" href="#" data-id="${driver.id}" data-name="${escapeHtml(driver.name)}"><i class="fas fa-trash-alt me-2 text-danger"></i>Delete</a></li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>`;
                        });
                        tableBody.html(html);
                    } else {
                        tableBody.html(`<tr><td colspan="8" class="text-center py-5 text-muted"><i class="fas fa-shuttle-van fa-3x mb-3"></i><h4>No drivers found</h4><p>${search ? 'Try a different search term' : 'Add your first driver to get started'}</p></td></tr>`);
                    }
                    updatePagination(response.total, page);
                    updateSelectionState();
                },
                error: function() {
                    toastr.error('Failed to load drivers. Please try again.');
                    $('#driversTableBody').html(`<tr><td colspan="8" class="text-center py-5 text-danger">Error loading data. Please refresh the page.</td></tr>`);
                }
            });
        }

        function updateSelectionState() {
            const selectionCount = selectedDrivers.size;
            $('#selectionCount').text(`${selectionCount} selected`);
            $('.selection-controls').toggle(selectionCount > 0);

            const allVisibleCheckboxes = $('.driver-checkbox');
            const allVisibleSelected = allVisibleCheckboxes.length > 0 && allVisibleCheckboxes.filter(':checked').length === allVisibleCheckboxes.length;
            $('#selectAllCheckbox').prop('checked', allVisibleSelected);
        }

        function updatePagination(totalRecords, currentPage) {
            const totalPages = Math.ceil(totalRecords / limit);
            let html = '';
            if (totalPages <= 1) {
                $('#paginationContainer').html('');
                return;
            }
            if (currentPage > 1) {
                html += `<li class="page-item"><a class="page-link" href="#" data-page="1"><i class="fas fa-angle-double-left"></i></a></li>`;
                html += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage - 1}"><i class="fas fa-angle-left"></i></a></li>`;
            }
            const start = Math.max(1, currentPage - 2);
            const end = Math.min(totalPages, currentPage + 2);
            if (start > 1) html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            for (let i = start; i <= end; i++) {
                html += `<li class="page-item ${i === currentPage ? 'active' : ''}"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
            }
            if (end < totalPages) html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            if (currentPage < totalPages) {
                html += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage + 1}"><i class="fas fa-angle-right"></i></a></li>`;
                html += `<li class="page-item"><a class="page-link" href="#" data-page="${totalPages}"><i class="fas fa-angle-double-right"></i></a></li>`;
            }
            $('#paginationContainer').html(html);
        }

        // --- EVENT HANDLERS ---
        loadDrivers();

        let searchTimer;
        $('#searchInput').on('input', function() {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => {
                loadDrivers(1, $(this).val(), $('#statusFilter').val())
            }, 500); 
        });
        $('#statusFilter').change(() => loadDrivers(1, $('#searchInput').val(), $('#statusFilter').val()));
        $('#refreshDrivers').click(() => loadDrivers(currentPage, $('#searchInput').val(), $('#statusFilter').val()));

        // Checkbox logic
        $('#selectAllCheckbox').on('click', function() {
            const isChecked = $(this).is(':checked');
            $('.driver-checkbox').each(function() {
                const driverId = $(this).data('id').toString();
                if (isChecked) {
                    selectedDrivers.add(driverId);
                    $(this).closest('tr').addClass('table-primary');
                } else {
                    selectedDrivers.delete(driverId);
                    $(this).closest('tr').removeClass('table-primary');
                }
                $(this).prop('checked', isChecked);
            });
            updateSelectionState();
        });

        $(document).on('click', '.driver-checkbox', function() {
            const driverId = $(this).data('id').toString();
            if ($(this).is(':checked')) {
                selectedDrivers.add(driverId);
                $(this).closest('tr').addClass('table-primary');
            } else {
                selectedDrivers.delete(driverId);
                $(this).closest('tr').removeClass('table-primary');
            }
            updateSelectionState();
        });
        
        // Pagination logic
        $(document).on('click', '.page-link', function(e) {
            e.preventDefault();
            const page = $(this).data('page');
            if (page) {
                loadDrivers(page, $('#searchInput').val(), $('#statusFilter').val());
            }
        });

        // Status Change Action
        $(document).on('click', '.status-btn', function(e) {
            e.preventDefault();
            const driverId = $(this).data('id');
            const newStatus = $(this).data('status');
            const action = newStatus === 'active' ? 'activate' : 'deactivate';

            Swal.fire({
                title: `Are you sure?`,
                text: `Do you want to ${action} this driver?`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: `Yes, ${action}!`,
                customClass: {
                    popup: 'rounded-4 shadow-lg'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '../../api/admin/put/driver/update-driver-status.php',
                        type: 'POST',
                        data: { id: driverId, status: newStatus },
                        dataType: 'json',
                        success: (response) => {
                            if (response.success) {
                                toastr.success(response.message);
                                loadDrivers(currentPage, $('#searchInput').val(), $('#statusFilter').val());
                            } else {
                                toastr.error(response.message);
                            }
                        },
                        error: () => toastr.error('An error occurred.')
                    });
                }
            });
        });

        // Delete Action
        $(document).on('click', '.delete-btn', function(e) {
            e.preventDefault();
            const driverId = $(this).data('id');
            const driverName = $(this).data('name');

            Swal.fire({
                title: 'Delete Driver',
                html: `Are you sure you want to delete <strong>${driverName}</strong>? This action cannot be undone.`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!',
                customClass: {
                    popup: 'rounded-4 shadow-lg'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '../../api/admin/delete/driver/delete-driver.php',
                        type: 'POST',
                        data: { id: driverId },
                        dataType: 'json',
                        success: (response) => {
                            if (response.success) {
                                toastr.success(response.message);
                                selectedDrivers.delete(driverId.toString());
                                loadDrivers(1, $('#searchInput').val(), $('#statusFilter').val());
                            } else {
                                toastr.error(response.message);
                            }
                        },
                        error: () => toastr.error('An error occurred.')
                    });
                }
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>