<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");
require_once("../../includes/db.php");

// Handle the form submission (for both AJAX and regular POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $driving_route = ucwords(trim($_POST['driving_route']));
    $response = ['success' => false, 'message' => ''];

    if (!empty($driving_route)) {
        $check = $pdo->prepare("SELECT * FROM driving_routes WHERE route_name = :route_name");
        $check->execute([':route_name' => $driving_route]);

        if ($check->rowCount() > 0) {
            $response['message'] = "Driving route already exists.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO driving_routes (route_name) VALUES (:route_name)");
            if ($stmt->execute([':route_name' => $driving_route])) {
                $response['success'] = true;
                $response['message'] = "Driving route added successfully!";
            } else {
                $response['message'] = "Failed to add driving route. Please try again.";
            }
        }
    } else {
        $response['message'] = "Please enter driving route name.";
    }

    // If it's an AJAX request, return JSON response
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }

    // For non-AJAX requests, store the message to display later
    $message = $response['success']
        ? "<div class='alert alert-success mt-3'>{$response['message']}</div>"
        : "<div class='alert alert-danger mt-3'>{$response['message']}</div>";
}

// Now output the HTML
include_once("../../includes/header-open.php");
echo "<title>Add Classes - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if ($_SESSION['user']['role'] !== 'superadmin') {
    include_once("../../includes/permission-denied.php");
}
?>

<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="mb-0"><i class="fas fa-road me-2"></i>Manage Driving Routes</h4>
                <a href="../driver/list-drivers.php" class="btn btn-light btn-sm">
                    <i class="fas fa-list me-1"></i> View Drivers
                </a>
            </div>
        </div>
        <div class="card-body">
            <div id="message-container"></div>

            <form id="addDrivingRouteForm" method="POST" action="add-driving-route.php">
                <div class="mb-3">
                    <label for="driving_route" class="form-label">Driving Route Name</label>
                    <input type="text" name="driving_route" id="driving_route" class="form-control"
                        placeholder="Please enter driving route name" required>
                    <div class="form-text">Enter the name of the driving route you want to add</div>
                </div>

                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button type="submit" class="btn btn-primary px-4">
                        <i class="fas fa-save me-2"></i>Save Driving Route
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow-sm mt-5">
        <div class="card-header bg-info text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="mb-0"><i class="fas fa-road me-2"></i>All Driving Routes</h4>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-striped table-bordered" id="drivingRoutesTable">
                <thead>
                    <tr>
                        <th>Route ID</th>
                        <th>Route Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Load driving routes on page load
        loadDrivingRoutes();

        // Handle form submission via AJAX
        $('#addDrivingRouteForm').on('submit', function(e) {
            e.preventDefault();

            var form = $(this);
            var formData = form.serialize();
            var submitBtn = form.find('button[type="submit"]');

            // Disable button during processing
            submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Processing...');

            $.ajax({
                url: form.attr('action'),
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        form[0].reset();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred. Please try again.');
                    console.error(xhr.responseText);
                },
                complete: function() {
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i>Save Driving Route');
                    loadDrivingRoutes(); // Reload driving routes after submission
                }
            });
        });

        // Add PHP response handling for non-JS users
        <?php if (!empty($message)): ?>
            $('#message-container').html(`<?= $message ?>`);
        <?php endif; ?>

        // Function to Load driving routes
        function loadDrivingRoutes() {
            $.ajax({
                url: '../../api/admin/get/driver/get-all-driving-routes.php',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        var tbody = $('#drivingRoutesTable tbody');
                        tbody.empty();
                        response.data.forEach(function(routeItem) {
                            tbody.append(`<tr id='route-${routeItem.id}'>
                                <td>${routeItem.id}</td>
                                <td>${routeItem.name}</td>
                                <td>
                                    <button class='btn btn-sm btn-danger' onclick='deleteDrivingRoute(${routeItem.id}, "${routeItem.name}")'>
                                        <i class='fas fa-trash'></i> Delete
                                    </button>
                                </td>
                            </tr>`);
                        });
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('Failed to load driving routes.');
                    console.error(xhr.responseText);
                }
            });
        }

        // Function to delete driving route
        window.deleteDrivingRoute = function(routeId, routeName) {
            var routeRow = $('#route-' + routeId);

            Swal.fire({
                title: 'Delete Driving Route?',
                html: `Are you sure you want to delete <strong>${routeName}</strong>?<br>This action cannot be undone!`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel',
                showLoaderOnConfirm: true,
                preConfirm: () => {
                    return $.ajax({
                        url: '../../api/admin/delete/driver/delete-driving-route.php',
                        type: 'POST',
                        data: {
                            route_id: routeId
                        },
                        dataType: 'json'
                    }).then(response => {
                        return response;
                    }).catch(error => {
                        Swal.showValidationMessage(
                            'Request failed: ' + error.responseText
                        );
                    });
                }
            }).then((result) => {
                if (result.isConfirmed && result.value.success) {
                    routeRow.fadeOut(300, function() {
                        $(this).remove();
                        // checkEmptyState();
                    });
                    toastr.success(result.value.message);
                } else if (result.isConfirmed && !result.value.success) {
                    toastr.error(result.value.message);
                }
            });
        };
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>