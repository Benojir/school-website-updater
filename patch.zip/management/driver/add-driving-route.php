<?php

/** @var string $school_name */
include_once("../../includes/auth-check.php");

// Now output the HTML
include_once("../../includes/header-open.php");
echo "<title>Add Driving Route - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check if user is superadmin only
if (!hasPermission(PERM_MANAGE_TRANSPORT)) {
    include_once("../../includes/permission-denied.php");
}
?>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4 class="mb-0"><i class="fas fa-road me-2"></i>Add Driving Routes</h4>
                        <a href="../driver/list-drivers.php" class="btn btn-light btn-sm">
                            <i class="fas fa-list me-1"></i> View Drivers
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <form id="addDrivingRouteForm">
                        <div class="mb-3">
                            <label for="driving_route" class="form-label">Driving Route Name</label>
                            <input type="text" name="driving_route" id="driving_route" class="form-control"
                                placeholder="Please enter driving route name" required>
                            <div class="form-text">Enter the name of the driving route you want to add</div>
                        </div>

                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="submit" class="btn btn-primary px-4">
                                <i class="fas fa-save me-2"></i>Save Driving Route
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4 class="mb-0"><i class="fas fa-road me-2"></i>All Driving Routes</h4>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table table-striped table-bordered table-hover" id="drivingRoutesTable">
                        <thead>
                            <tr>
                                <th>Route ID</th>
                                <th>Route Name</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
    $(document).ready(function() {
        // Load driving routes on page load
        loadDrivingRoutes();

        // Handle form submission via AJAX
        $('#addDrivingRouteForm').on('submit', function(e) {
            e.preventDefault();

            let form = $(this);
            let formData = form.serialize();
            let submitBtn = form.find('button[type="submit"]');

            // Disable button during processing
            submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i>Processing...');

            $.ajax({
                url: '<?= BASE_URL ?>/api/admin/put/driver/add-driving-route.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        form[0].reset();
                    } else {
                        toastr.error(response.message);
                        showErrorAlert(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred. Please try again.');
                    showErrorAlert('An error occurred. Please try again.');
                    console.error(xhr.responseText);
                    sendErrorReport(xhr.responseText);
                },
                complete: function() {
                    submitBtn.prop('disabled', false).html('<i class="fas fa-save me-2"></i>Save Driving Route');
                    loadDrivingRoutes(); // Reload driving routes after submission
                }
            });
        });
    });

    // Function to Load driving routes
    function loadDrivingRoutes() {
        $.ajax({
            url: '<?= BASE_URL ?>/api/admin/get/driver/get-all-driving-routes.php',
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    let tbody = $('#drivingRoutesTable tbody');
                    tbody.empty();
                    response.data.forEach(function(routeItem) {
                        tbody.append(`<tr id='route-${routeItem.id}'>
                                <td>${routeItem.id}</td>
                                <td>${routeItem.name}</td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <button class="btn btn-sm btn-primary"
                                                onclick='editDrivingRoute(${routeItem.id}, "${routeItem.name}")'>
                                            <i class="fas fa-edit"></i> Edit
                                        </button>

                                        <button class="btn btn-sm btn-danger"
                                                onclick='deleteDrivingRoute(${routeItem.id}, "${routeItem.name}")'>
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>`);
                    });
                } else {
                    toastr.error(response.message);
                    showErrorAlert(response.message);
                }
            },
            error: function(xhr, status, error) {
                toastr.error('Failed to load driving routes.');
                console.error(xhr.responseText);
                sendErrorReport(xhr.responseText);
            }
        });
    }

    // Function to edit driving route
    function editDrivingRoute(routeId, currentRouteName) {
        Swal.fire({
            title: 'Edit Driving Route',
            input: 'text',
            inputLabel: 'New Route Name',
            inputValue: currentRouteName,
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: '<i class="fas fa-save me-1"></i> Update',
            cancelButtonText: 'Cancel',
            showLoaderOnConfirm: true,
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-primary px-4 py-2 me-2',
                cancelButton: 'btn btn-secondary px-4 py-2'
            },
            inputValidator: (value) => {
                if (!value || value.trim() === '') {
                    return 'Route name cannot be empty!';
                }
            },
            preConfirm: (newRouteName) => {
                return $.ajax({
                    // নিচে আপনার update API-এর সঠিক ইউআরএল দিন
                    url: '<?= BASE_URL ?>/api/admin/put/driver/update-driving-route.php',
                    type: 'POST',
                    data: {
                        route_id: routeId,
                        driving_route: newRouteName // API-তে যে নামের প্যারামিটার প্রয়োজন সেটি দিন
                    },
                    dataType: 'json'
                }).then(response => {
                    return response;
                }).catch(error => {
                    Swal.showValidationMessage(
                        'Request failed: ' + error.responseText
                    );
                });
            }
        }).then((result) => {
            if (result.isConfirmed) {
                if (result.value.success) {
                    toastr.success(result.value.message);
                    loadDrivingRoutes(); // টেবিল আপডেট করার জন্য
                } else {
                    toastr.error(result.value.message);
                    showErrorAlert(result.value.message);
                }
            }
        });
    }

    // Function to delete driving route
    function deleteDrivingRoute(routeId, routeName) {
        let routeRow = $('#route-' + routeId);

        Swal.fire({
            title: 'Delete Driving Route?',
            html: `Are you sure you want to delete <strong>${routeName}</strong>?<br>This action cannot be undone!`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            showLoaderOnConfirm: true,
            customClass: {
                popup: 'rounded-4 shadow-lg',
                confirmButton: 'btn btn-danger px-4 py-2',
                cancelButton: 'btn btn-secondary px-4 py-2'
            },
            preConfirm: () => {
                return $.ajax({
                    url: '<?= BASE_URL ?>/api/admin/delete/driver/delete-driving-route.php',
                    type: 'POST',
                    data: {
                        route_id: routeId
                    },
                    dataType: 'json'
                }).then(response => {
                    return response;
                }).catch(error => {
                    Swal.showValidationMessage(
                        'Request failed: ' + error.responseText
                    );
                });
            }
        }).then((result) => {
            if (result.isConfirmed && result.value.success) {
                routeRow.fadeOut(300, function() {
                    $(this).remove();
                    // checkEmptyState();
                });
                toastr.success(result.value.message);
            } else if (result.isConfirmed && !result.value.success) {
                toastr.error(result.value.message);
            }
        });
    };
</script>

<?php include_once("../../includes/body-close.php"); ?>