<?php

/** @var array $websiteConfig */
// Standard includes
include_once("../../includes/auth-check.php");

// URL থেকে Driver ID নেওয়া
$driver_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($driver_id === 0) {
    die("Invalid Driver ID.");
}

// ডাটাবেস থেকে ড্রাইভারের ইনফরমেশন ফেচ করা
$stmt = $pdo->prepare("SELECT * FROM drivers WHERE id = ?");
$stmt->execute([$driver_id]);
$driver = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$driver) {
    die("Driver not found.");
}

// Header includes
include_once("../../includes/header-open.php");
echo "<title>Driver Profile - " . safe_htmlspecialchars($driver['name']) . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// ঠিকানার স্ট্রিং তৈরি করা
$address_parts = array_filter([$driver['village'], $driver['post_office'], $driver['police_station'], $driver['district'], $driver['pincode']]);
$full_address = !empty($address_parts) ? implode(", ", $address_parts) : "Address not updated";

// Documents: JSON list of {document_name, document_url}
$documents = json_decode($driver['documents'] ?? '[]', true);
if (!is_array($documents)) {
    $documents = [];
}

// Detail groups rendered below the live map. Each row: label, value and icon,
// optionally mono to render the value in a monospace font.
$info_sections = [
    [
        'title' => 'Family Details',
        'icon'  => 'fa-people-roof',
        'width' => 'col-lg-6',
        'rows'  => [
            ['label' => "Father's Name", 'value' => $driver['father_name'], 'icon' => 'fa-person'],
            ['label' => "Father's Phone", 'value' => $driver['father_phone'], 'icon' => 'fa-phone'],
            ['label' => "Mother's Name", 'value' => $driver['mother_name'], 'icon' => 'fa-person-dress'],
            ['label' => "Mother's Phone", 'value' => $driver['mother_phone'], 'icon' => 'fa-phone'],
        ],
    ],
    [
        'title' => 'Bank & Statutory Details',
        'icon'  => 'fa-building-columns',
        'width' => 'col-lg-6',
        'rows'  => [
            ['label' => 'Bank Name', 'value' => $driver['bank_name'], 'icon' => 'fa-building-columns'],
            ['label' => 'Branch Name', 'value' => $driver['bank_branch'], 'icon' => 'fa-location-dot'],
            ['label' => 'Account Number', 'value' => $driver['account_number'], 'icon' => 'fa-hashtag', 'mono' => true],
            ['label' => 'IFSC Code', 'value' => $driver['ifsc_code'], 'icon' => 'fa-code', 'mono' => true],
            ['label' => 'PAN No.', 'value' => $driver['pan_number'], 'icon' => 'fa-id-badge', 'mono' => true],
            ['label' => 'Voter EPIC No.', 'value' => $driver['voter_epic_number'], 'icon' => 'fa-id-badge', 'mono' => true],
        ],
    ],
];
?>

<style>
    .profile-card {
        border-radius: 15px;
        border: none;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
    }

    .profile-img {
        width: 120px;
        height: 120px;
        object-fit: cover;
        border-radius: 50%;
        border: 4px solid #fff;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .info-label {
        font-size: 12px;
        color: #6c757d;
        text-transform: uppercase;
        font-weight: bold;
        margin-bottom: 2px;
    }

    .info-value {
        font-size: 15px;
        color: #333;
        font-weight: 500;
        margin-bottom: 15px;
    }

    /* ---------- Documents ---------- */
    .doc-tile {
        border: 1px solid #e9ecef;
        border-radius: 12px;
        overflow: hidden;
        background: #fff;
        height: 100%;
        transition: transform .15s ease, box-shadow .15s ease;
    }

    .doc-tile:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 22px rgba(0, 0, 0, .1);
    }

    .doc-thumb {
        display: block;
        width: 100%;
        height: 165px;
        object-fit: cover;
        background: #f8f9fa;
        cursor: zoom-in;
    }

    .doc-caption {
        padding: 10px 12px;
        border-top: 1px solid #eef1f4;
    }

    .doc-name {
        font-size: .88rem;
        font-weight: 700;
        color: #212529;
        word-break: break-word;
    }

    #map-container {
        position: relative;
        height: 600px;
        width: 100%;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
    }

    #map {
        height: 100%;
        width: 100%;
    }

    #offline-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(255, 255, 255, 0.85);
        backdrop-filter: blur(5px);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        z-index: 10;
    }
</style>

<div class="container-fluid">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center mb-4">
            <h3 class="mb-0"><i class="fas fa-user-tie me-2"></i> Driver Profile</h3>
            <a href="javascript:window.close();" class="btn btn-sm btn-danger"><i class="fas fa-times me-1"></i> Close Tab</a>
        </div>

        <div class="row">
            <div class="col-lg-4 mb-4">
                <div class="card profile-card">
                    <div class="card-body text-center pt-4">
                        <img src="../../uploads/drivers/<?= safe_htmlspecialchars($driver['driver_image']) ?>" alt="Driver Image" class="profile-img mb-3">
                        <h4 class="fw-bold mb-1"><?= safe_htmlspecialchars($driver['name']) ?></h4>
                        <span class="badge <?= $driver['status'] === 'active' ? 'bg-success' : 'bg-danger' ?> mb-3">
                            <?= ucfirst($driver['status']) ?>
                        </span>
                        <hr>
                    </div>
                    <div class="card-body px-4 pt-0">
                        <div class="info-label">Phone Number</div>
                        <div class="info-value"><i class="fas fa-phone-alt text-primary me-2"></i>+91 <?= safe_htmlspecialchars($driver['phone']) ?></div>

                        <div class="info-label">Email Address</div>
                        <div class="info-value"><i class="fas fa-envelope text-primary me-2"></i><?= safe_htmlspecialchars($driver['email']) ?></div>

                        <div class="info-label">Vehicle Number</div>
                        <div class="info-value"><i class="fas fa-car text-primary me-2"></i><?= safe_htmlspecialchars($driver['vehicle_number']) ?: 'N/A' ?></div>

                        <div class="info-label">Serial Number</div>
                        <div class="info-value"><i class="fas fa-hashtag text-primary me-2"></i><?= safe_htmlspecialchars($driver['serial_number']) ?: 'N/A' ?></div>

                        <div class="info-label">Aadhaar Number</div>
                        <div class="info-value"><i class="fas fa-id-card text-primary me-2"></i><?= safe_htmlspecialchars($driver['aadhaar_number']) ?: 'N/A' ?></div>

                        <div class="info-label">Full Address</div>
                        <div class="info-value"><i class="fas fa-map-marker-alt text-primary me-2"></i><?= safe_htmlspecialchars($full_address) ?></div>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="card profile-card h-100">
                    <div class="card-header bg-white border-0 py-3">
                        <h5 class="mb-0 fw-bold"><i class="fas fa-map-marked-alt text-success me-2"></i> Live Location Tracking</h5>
                    </div>
                    <div class="card-body p-0 pb-3 px-3">
                        <div id="map-container">
                            <div id="map"></div>

                            <div id="offline-overlay">
                                <i class="fas fa-signal-slash fa-4x text-danger mb-3"></i>
                                <h4 class="text-dark fw-bold">Driver is Offline</h4>
                                <p class="text-muted">Live location is currently unavailable.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ===================== DETAIL SECTIONS ===================== -->
        <div class="row g-4">
            <?php foreach ($info_sections as $section): ?>
                <div class="<?= $section['width'] ?>">
                    <div class="card profile-card h-100">
                        <div class="card-header bg-white border-0 py-3">
                            <h6 class="mb-0 fw-bold text-primary"><i class="fas <?= $section['icon'] ?> me-2"></i><?= $section['title'] ?></h6>
                        </div>
                        <div class="card-body">
                            <div class="row g-3">
                                <?php foreach ($section['rows'] as $row):
                                    $value = trim((string) ($row['value'] ?? ''));
                                    $is_empty = ($value === '');
                                ?>
                                    <div class="col-md-6">
                                        <div class="info-label"><i class="fas <?= $row['icon'] ?> me-1"></i><?= $row['label'] ?></div>
                                        <div class="info-value <?= !empty($row['mono']) ? 'font-monospace' : '' ?>">
                                            <?php if ($is_empty): ?>
                                                <span class="text-muted fw-normal">&mdash;</span>
                                            <?php else: ?>
                                                <?= safe_htmlspecialchars($value) ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- ===================== DOCUMENTS ===================== -->
        <div class="card profile-card mt-4 mb-4">
            <div class="card-header bg-white border-0 py-3 d-flex justify-content-between align-items-center">
                <h6 class="mb-0 fw-bold text-primary">
                    <i class="fas fa-folder-open me-2"></i>Documents
                    <span class="badge bg-secondary ms-1"><?= count($documents) ?></span>
                </h6>
                <a href="edit-bulk-drivers.php?driver_ids=<?= (int) $driver['id'] ?>" class="btn btn-sm btn-outline-primary">
                    <i class="fas fa-pen me-1"></i> Manage Documents
                </a>
            </div>
            <div class="card-body">
                <?php if (!empty($documents)): ?>
                    <div class="row g-3">
                        <?php foreach ($documents as $document):
                            $doc_name = trim((string) ($document['document_name'] ?? 'Document'));
                            $doc_url = trim((string) ($document['document_url'] ?? ''));
                            if ($doc_url === '') {
                                continue;
                            }
                        ?>
                            <div class="col-6 col-md-4 col-lg-3">
                                <div class="doc-tile shadow-sm">
                                    <img src="<?= safe_htmlspecialchars($doc_url) ?>"
                                        class="doc-thumb"
                                        alt="<?= safe_htmlspecialchars($doc_name) ?>"
                                        loading="lazy"
                                        data-fancybox="driver-documents"
                                        data-caption="<?= safe_htmlspecialchars($doc_name) ?>">
                                    <div class="doc-caption d-flex justify-content-between align-items-center gap-2">
                                        <span class="doc-name" title="<?= safe_htmlspecialchars($doc_name) ?>"><?= safe_htmlspecialchars($doc_name) ?></span>
                                        <a href="<?= safe_htmlspecialchars($doc_url) ?>" target="_blank" rel="noopener"
                                            class="btn btn-sm btn-outline-secondary flex-shrink-0" title="Open original">
                                            <i class="fas fa-up-right-from-square"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-folder-open fa-3x mb-3 opacity-50"></i>
                        <p class="mb-0">No documents uploaded for this driver yet.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- <script type="module">
    import { initializeApp } from "https://www.gstatic.com/firebasejs/12.15.0/firebase-app.js";
    import { getDatabase, ref, onValue } from "https://www.gstatic.com/firebasejs/12.15.0/firebase-database.js";
    import { getAuth, signInAnonymously, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.15.0/firebase-auth.js";

    const firebaseConfig = <?= $websiteConfig['firebase_config'] ?>;

    const app = initializeApp(firebaseConfig);
    const db = getDatabase(app);
    const auth = getAuth(app);

    // ফায়ারবেসের নির্দিষ্ট ড্রাইভারের নোড (যেমন: educare_public_school_driver_1)
    const driverFirebaseKey = '<?= FULL_SCHOOL_ID ?>_driver_<?= $driver_id ?>'; 
    const driverRef = ref(db, 'ActiveDrivers/' + driverFirebaseKey);

    let map;
    let driverMarker = null;

    // ১. গুগল ম্যাপ ইনিশিয়ালাইজ করা
    window.initMap = function() {
        map = new google.maps.Map(document.getElementById("map"), {
            center: { lat: 23.6850, lng: 88.0697 }, // ডিফল্ট লোকেশন
            zoom: 12,
            mapTypeControl: false,
            streetViewControl: false
        });

        // ম্যাপ রেডি হলে ফায়ারবেস অথেন্টিকেশন শুরু হবে
        checkFirebaseAuth();
    };

    // ২. ফায়ারবেস অথেন্টিকেশন
    function checkFirebaseAuth() {
        onAuthStateChanged(auth, (user) => {
            if (user) {
                startTracking();
            } else {
                signInAnonymously(auth).catch((error) => console.error("Auth Error:", error));
            }
        });
    }

    // ৩. রিয়েল-টাইম লোকেশন লিসেনার
    function startTracking() {
        onValue(driverRef, (snapshot) => {
            if (snapshot.exists()) {
                // ড্রাইভার অনলাইনে আছে
                document.getElementById('offline-overlay').style.display = 'none';
                
                const data = snapshot.val();
                const currentLatLng = new google.maps.LatLng(data.lat, data.lng);

                if (!driverMarker) {
                    // প্রথমবার মার্কার তৈরি করা (চাইলে কাস্টম গাড়ির আইকন দিতে পারেন)
                    driverMarker = new google.maps.Marker({
                        position: currentLatLng,
                        map: map,
                        title: "<?= safe_htmlspecialchars($driver['name']) ?>",
                        icon: {
                            url: "<?= BASE_URL ?>/assets/img/icons/car.png", // গাড়ির একটি স্যাম্পল আইকন
                            scaledSize: new google.maps.Size(40, 40)
                        }
                    });
                    map.setCenter(currentLatLng);
                    map.setZoom(16);
                } else {
                    // মার্কার মুভ করা এবং ম্যাপ সেন্টার করা
                    driverMarker.setPosition(currentLatLng);
                    map.panTo(currentLatLng);
                }
            } else {
                // ড্রাইভার অফলাইনে চলে গেছে
                document.getElementById('offline-overlay').style.display = 'flex';
                if (driverMarker) {
                    driverMarker.setMap(null);
                    driverMarker = null;
                }
            }
        });
    }
</script>

<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAOVYRIgupAurZup5y1PRh8Ismb1A3lLao&callback=initMap"></script> -->

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<script type="module">
    import {
        initializeApp
    } from "https://www.gstatic.com/firebasejs/12.15.0/firebase-app.js";
    import {
        getDatabase,
        ref,
        onValue
    } from "https://www.gstatic.com/firebasejs/12.15.0/firebase-database.js";
    import {
        getAuth,
        signInAnonymously,
        onAuthStateChanged
    } from "https://www.gstatic.com/firebasejs/12.15.0/firebase-auth.js";

    const firebaseConfig = <?= $websiteConfig['firebase_config'] ?>;

    const app = initializeApp(firebaseConfig);
    const db = getDatabase(app);
    const auth = getAuth(app);

    const driverFirebaseKey = '<?= FULL_SCHOOL_ID ?>_driver_<?= $driver_id ?>';
    const driverRef = ref(db, 'ActiveDrivers/' + driverFirebaseKey);

    let map;
    let driverMarker = null;

    // ১. OpenStreetMap (Leaflet) ইনিশিয়ালাইজ করা
    window.initMap = function() {
        // ম্যাপ তৈরি করা এবং ডিফল্ট লোকেশন সেট করা
        map = L.map('map', {
            zoomControl: false // ডিফল্ট জুম কন্ট্রোল সরাতে চাইলে
        }).setView([23.6850, 88.0697], 12);

        // ডানদিকে নিচে জুম বাটন রাখা
        L.control.zoom({
            position: 'bottomright'
        }).addTo(map);

        // OpenStreetMap এর টাইল (Tile) লেয়ার যুক্ত করা
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        // ম্যাপ রেডি হলে ফায়ারবেস অথেন্টিকেশন শুরু হবে
        checkFirebaseAuth();
    };

    // ২. ফায়ারবেস অথেন্টিকেশন
    function checkFirebaseAuth() {
        onAuthStateChanged(auth, (user) => {
            if (user) {
                startTracking();
            } else {
                signInAnonymously(auth).catch((error) => console.error("Auth Error:", error));
            }
        });
    }

    // ৩. রিয়েল-টাইম লোকেশন লিসেনার (Leaflet Marker এর জন্য)
    function startTracking() {
        onValue(driverRef, (snapshot) => {
            if (snapshot.exists()) {
                // ড্রাইভার অনলাইনে আছে
                document.getElementById('offline-overlay').style.display = 'none';

                const data = snapshot.val();
                const currentLatLng = [data.lat, data.lng]; // Leaflet এ Array হিসেবে [lat, lng] দিতে হয়

                if (!driverMarker) {
                    // কাস্টম গাড়ির আইকন তৈরি করা
                    var carIcon = L.icon({
                        iconUrl: '<?= BASE_URL ?>/assets/img/icons/car.png',
                        iconSize: [40, 40], // আইকনের সাইজ
                        iconAnchor: [20, 20] // সেন্টারে রাখার জন্য
                    });

                    // মার্কার ম্যাপে যুক্ত করা
                    driverMarker = L.marker(currentLatLng, {
                        icon: carIcon
                    }).addTo(map);

                    // ড্রাইভারের নামের একটি পপআপ যুক্ত করা
                    driverMarker.bindPopup("<b><?= safe_htmlspecialchars($driver['name']) ?></b><br>Driver is Online");

                    map.setView(currentLatLng, 16); // ক্যামেরা জুম করা
                } else {
                    // মার্কার মুভ করা এবং ম্যাপ সেন্টার করা
                    driverMarker.setLatLng(currentLatLng);
                    map.panTo(currentLatLng);
                }
            } else {
                // ড্রাইভার অফলাইনে চলে গেছে
                document.getElementById('offline-overlay').style.display = 'flex';
                if (driverMarker) {
                    map.removeLayer(driverMarker); // Leaflet থেকে মার্কার রিমুভ করার নিয়ম
                    driverMarker = null;
                }
            }
        });
    }

    // পেজ লোড হলে ম্যাপ চালু করা
    window.onload = window.initMap;
</script>

<?php include_once("../../includes/body-close.php"); ?>