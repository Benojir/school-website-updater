<?php

/** @var array $websiteConfig */
// Standard includes
include_once("../../includes/auth-check.php");

// URL থেকে Driver ID নেওয়া
$driver_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($driver_id === 0) {
    die("Invalid Driver ID.");
}

// ডাটাবেস থেকে ড্রাইভারের ইনফরমেশন ফেচ করা
$stmt = $pdo->prepare("SELECT * FROM drivers WHERE id = ?");
$stmt->execute([$driver_id]);
$driver = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$driver) {
    die("Driver not found.");
}

// Header includes
include_once("../../includes/header-open.php");
echo "<title>Driver Profile - " . safe_htmlspecialchars($driver['name']) . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// ঠিকানার স্ট্রিং তৈরি করা
$address_parts = array_filter([$driver['village'], $driver['post_office'], $driver['police_station'], $driver['district'], $driver['pincode']]);
$full_address = !empty($address_parts) ? implode(", ", $address_parts) : "Address not updated";
?>

<style>
    .profile-card {
        border-radius: 15px;
        border: none;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
    }

    .profile-img {
        width: 120px;
        height: 120px;
        object-fit: cover;
        border-radius: 50%;
        border: 4px solid #fff;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .info-label {
        font-size: 12px;
        color: #6c757d;
        text-transform: uppercase;
        font-weight: bold;
        margin-bottom: 2px;
    }

    .info-value {
        font-size: 15px;
        color: #333;
        font-weight: 500;
        margin-bottom: 15px;
    }

    #map-container {
        position: relative;
        height: 600px;
        width: 100%;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
    }

    #map {
        height: 100%;
        width: 100%;
    }

    #offline-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(255, 255, 255, 0.85);
        backdrop-filter: blur(5px);
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        z-index: 10;
    }
</style>

<div class="container-fluid">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center mb-4">
            <h3 class="mb-0"><i class="fas fa-user-tie me-2"></i> Driver Profile</h3>
            <a href="javascript:window.close();" class="btn btn-sm btn-danger"><i class="fas fa-times me-1"></i> Close Tab</a>
        </div>

        <div class="row">
            <div class="col-lg-4 mb-4">
                <div class="card profile-card">
                    <div class="card-body text-center pt-4">
                        <img src="../../uploads/drivers/<?= safe_htmlspecialchars($driver['driver_image']) ?>" alt="Driver Image" class="profile-img mb-3">
                        <h4 class="fw-bold mb-1"><?= safe_htmlspecialchars($driver['name']) ?></h4>
                        <span class="badge <?= $driver['status'] === 'active' ? 'bg-success' : 'bg-danger' ?> mb-3">
                            <?= ucfirst($driver['status']) ?>
                        </span>
                        <hr>
                    </div>
                    <div class="card-body px-4 pt-0">
                        <div class="info-label">Phone Number</div>
                        <div class="info-value"><i class="fas fa-phone-alt text-primary me-2"></i>+91 <?= safe_htmlspecialchars($driver['phone']) ?></div>

                        <div class="info-label">Email Address</div>
                        <div class="info-value"><i class="fas fa-envelope text-primary me-2"></i><?= safe_htmlspecialchars($driver['email']) ?></div>

                        <div class="info-label">Vehicle Number</div>
                        <div class="info-value"><i class="fas fa-car text-primary me-2"></i><?= safe_htmlspecialchars($driver['vehicle_number']) ?: 'N/A' ?></div>

                        <div class="info-label">Serial Number</div>
                        <div class="info-value"><i class="fas fa-hashtag text-primary me-2"></i><?= safe_htmlspecialchars($driver['serial_number']) ?: 'N/A' ?></div>

                        <div class="info-label">Aadhaar Number</div>
                        <div class="info-value"><i class="fas fa-id-card text-primary me-2"></i><?= safe_htmlspecialchars($driver['aadhaar_number']) ?: 'N/A' ?></div>

                        <div class="info-label">Full Address</div>
                        <div class="info-value"><i class="fas fa-map-marker-alt text-primary me-2"></i><?= safe_htmlspecialchars($full_address) ?></div>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="card profile-card h-100">
                    <div class="card-header bg-white border-0 py-3">
                        <h5 class="mb-0 fw-bold"><i class="fas fa-map-marked-alt text-success me-2"></i> Live Location Tracking</h5>
                    </div>
                    <div class="card-body p-0 pb-3 px-3">
                        <div id="map-container">
                            <div id="map"></div>

                            <div id="offline-overlay">
                                <i class="fas fa-signal-slash fa-4x text-danger mb-3"></i>
                                <h4 class="text-dark fw-bold">Driver is Offline</h4>
                                <p class="text-muted">Live location is currently unavailable.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- <script type="module">
    import { initializeApp } from "https://www.gstatic.com/firebasejs/12.15.0/firebase-app.js";
    import { getDatabase, ref, onValue } from "https://www.gstatic.com/firebasejs/12.15.0/firebase-database.js";
    import { getAuth, signInAnonymously, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/12.15.0/firebase-auth.js";

    const firebaseConfig = <?= $websiteConfig['firebase_config'] ?>;

    const app = initializeApp(firebaseConfig);
    const db = getDatabase(app);
    const auth = getAuth(app);

    // ফায়ারবেসের নির্দিষ্ট ড্রাইভারের নোড (যেমন: educare_public_school_driver_1)
    const driverFirebaseKey = '<?= FULL_SCHOOL_ID ?>_driver_<?= $driver_id ?>'; 
    const driverRef = ref(db, 'ActiveDrivers/' + driverFirebaseKey);

    let map;
    let driverMarker = null;

    // ১. গুগল ম্যাপ ইনিশিয়ালাইজ করা
    window.initMap = function() {
        map = new google.maps.Map(document.getElementById("map"), {
            center: { lat: 23.6850, lng: 88.0697 }, // ডিফল্ট লোকেশন
            zoom: 12,
            mapTypeControl: false,
            streetViewControl: false
        });

        // ম্যাপ রেডি হলে ফায়ারবেস অথেন্টিকেশন শুরু হবে
        checkFirebaseAuth();
    };

    // ২. ফায়ারবেস অথেন্টিকেশন
    function checkFirebaseAuth() {
        onAuthStateChanged(auth, (user) => {
            if (user) {
                startTracking();
            } else {
                signInAnonymously(auth).catch((error) => console.error("Auth Error:", error));
            }
        });
    }

    // ৩. রিয়েল-টাইম লোকেশন লিসেনার
    function startTracking() {
        onValue(driverRef, (snapshot) => {
            if (snapshot.exists()) {
                // ড্রাইভার অনলাইনে আছে
                document.getElementById('offline-overlay').style.display = 'none';
                
                const data = snapshot.val();
                const currentLatLng = new google.maps.LatLng(data.lat, data.lng);

                if (!driverMarker) {
                    // প্রথমবার মার্কার তৈরি করা (চাইলে কাস্টম গাড়ির আইকন দিতে পারেন)
                    driverMarker = new google.maps.Marker({
                        position: currentLatLng,
                        map: map,
                        title: "<?= safe_htmlspecialchars($driver['name']) ?>",
                        icon: {
                            url: "<?= BASE_URL ?>/assets/img/icons/car.png", // গাড়ির একটি স্যাম্পল আইকন
                            scaledSize: new google.maps.Size(40, 40)
                        }
                    });
                    map.setCenter(currentLatLng);
                    map.setZoom(16);
                } else {
                    // মার্কার মুভ করা এবং ম্যাপ সেন্টার করা
                    driverMarker.setPosition(currentLatLng);
                    map.panTo(currentLatLng);
                }
            } else {
                // ড্রাইভার অফলাইনে চলে গেছে
                document.getElementById('offline-overlay').style.display = 'flex';
                if (driverMarker) {
                    driverMarker.setMap(null);
                    driverMarker = null;
                }
            }
        });
    }
</script>

<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAOVYRIgupAurZup5y1PRh8Ismb1A3lLao&callback=initMap"></script> -->

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<script type="module">
    import {
        initializeApp
    } from "https://www.gstatic.com/firebasejs/12.15.0/firebase-app.js";
    import {
        getDatabase,
        ref,
        onValue
    } from "https://www.gstatic.com/firebasejs/12.15.0/firebase-database.js";
    import {
        getAuth,
        signInAnonymously,
        onAuthStateChanged
    } from "https://www.gstatic.com/firebasejs/12.15.0/firebase-auth.js";

    const firebaseConfig = <?= $websiteConfig['firebase_config'] ?>;

    const app = initializeApp(firebaseConfig);
    const db = getDatabase(app);
    const auth = getAuth(app);

    const driverFirebaseKey = '<?= FULL_SCHOOL_ID ?>_driver_<?= $driver_id ?>';
    const driverRef = ref(db, 'ActiveDrivers/' + driverFirebaseKey);

    let map;
    let driverMarker = null;

    // ১. OpenStreetMap (Leaflet) ইনিশিয়ালাইজ করা
    window.initMap = function() {
        // ম্যাপ তৈরি করা এবং ডিফল্ট লোকেশন সেট করা
        map = L.map('map', {
            zoomControl: false // ডিফল্ট জুম কন্ট্রোল সরাতে চাইলে
        }).setView([23.6850, 88.0697], 12);

        // ডানদিকে নিচে জুম বাটন রাখা
        L.control.zoom({
            position: 'bottomright'
        }).addTo(map);

        // OpenStreetMap এর টাইল (Tile) লেয়ার যুক্ত করা
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        // ম্যাপ রেডি হলে ফায়ারবেস অথেন্টিকেশন শুরু হবে
        checkFirebaseAuth();
    };

    // ২. ফায়ারবেস অথেন্টিকেশন
    function checkFirebaseAuth() {
        onAuthStateChanged(auth, (user) => {
            if (user) {
                startTracking();
            } else {
                signInAnonymously(auth).catch((error) => console.error("Auth Error:", error));
            }
        });
    }

    // ৩. রিয়েল-টাইম লোকেশন লিসেনার (Leaflet Marker এর জন্য)
    function startTracking() {
        onValue(driverRef, (snapshot) => {
            if (snapshot.exists()) {
                // ড্রাইভার অনলাইনে আছে
                document.getElementById('offline-overlay').style.display = 'none';

                const data = snapshot.val();
                const currentLatLng = [data.lat, data.lng]; // Leaflet এ Array হিসেবে [lat, lng] দিতে হয়

                if (!driverMarker) {
                    // কাস্টম গাড়ির আইকন তৈরি করা
                    var carIcon = L.icon({
                        iconUrl: '<?= BASE_URL ?>/assets/img/icons/car.png',
                        iconSize: [40, 40], // আইকনের সাইজ
                        iconAnchor: [20, 20] // সেন্টারে রাখার জন্য
                    });

                    // মার্কার ম্যাপে যুক্ত করা
                    driverMarker = L.marker(currentLatLng, {
                        icon: carIcon
                    }).addTo(map);

                    // ড্রাইভারের নামের একটি পপআপ যুক্ত করা
                    driverMarker.bindPopup("<b><?= safe_htmlspecialchars($driver['name']) ?></b><br>Driver is Online");

                    map.setView(currentLatLng, 16); // ক্যামেরা জুম করা
                } else {
                    // মার্কার মুভ করা এবং ম্যাপ সেন্টার করা
                    driverMarker.setLatLng(currentLatLng);
                    map.panTo(currentLatLng);
                }
            } else {
                // ড্রাইভার অফলাইনে চলে গেছে
                document.getElementById('offline-overlay').style.display = 'flex';
                if (driverMarker) {
                    map.removeLayer(driverMarker); // Leaflet থেকে মার্কার রিমুভ করার নিয়ম
                    driverMarker = null;
                }
            }
        });
    }

    // পেজ লোড হলে ম্যাপ চালু করা
    window.onload = window.initMap;
</script>

<?php include_once("../../includes/body-close.php"); ?>