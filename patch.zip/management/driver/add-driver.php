<?php
include_once("../../includes/auth-check.php");
// Assuming you have a permission constant for managing transport/drivers
// If not, you can create one or use an existing relevant permission.
include_once("../../includes/permission-check.php"); 
include_once("../../includes/header-open.php");
echo "<title>Add Driver - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check user permission for managing transport
// You might need to define PERM_MANAGE_TRANSPORT in your permission system
if (!hasPermission('PERM_MANAGE_TRANSPORT')) { 
    include_once("../../includes/permission-denied.php");
}

// Generate a new driver ID
$lastDriver = $pdo->query("SELECT driver_id FROM drivers ORDER BY id DESC LIMIT 1")->fetch();
$lastId = $lastDriver ? intval(substr($lastDriver['driver_id'], 3)) : 0;
$newDriverId = 'DRV' . str_pad($lastId + 1, 4, '0', STR_PAD_LEFT);

// Get list of routes for the route dropdown
$routes = $pdo->query("SELECT id, route_name FROM driving_routes ORDER BY route_name")->fetchAll();
?>

<div class="container py-4">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-user-plus me-2"></i> Add New Driver</h3>
                <a href="../driver/list-drivers.php" class="btn btn-light btn-sm">
                    <i class="fas fa-list me-1"></i> View Drivers
                </a>
            </div>
        </div>

        <div class="card-body">
            <form id="addDriverForm" enctype="multipart/form-data">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Driver ID <span class="text-danger">*</span></label>
                            <input type="text" name="driver_id" class="form-control" 
                                   value="<?= $newDriverId ?>" readonly>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Driver Name <span class="text-danger">*</span></label>
                            <input type="text" name="driver_name" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Driver Email ID <span class="text-danger">*</span></label>
                            <input type="email" name="driver_email" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Phone Number <span class="text-danger">*</span></label>
                            <input type="text" name="phone_number" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Driver Vehicle Number <span class="text-danger">*</span></label>
                            <input type="text" name="vehicle_number" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Route <span class="text-danger">*</span></label>
                            <select name="route" class="form-control" required>
                                <option value="">Select Route</option>
                                <?php foreach ($routes as $route): ?>
                                    <option value="<?= $route['id'] ?>"><?= $route['route_name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <!-- Image Upload Section -->
                    <div class="col-12">
                        <div class="form-group">
                            <label class="form-label fw-bold">Driver Photo</label>
                            <div class="image-upload-container">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="image-preview-container mb-3">
                                            <div class="image-preview-wrapper">
                                                <img id="imagePreview" src="../../assets/img/avatars/default_driver_dp.jpg" 
                                                     class="img-fluid" style="max-height: 200px; display: block;">
                                            </div>
                                        </div>
                                        <input type="file" id="driverPhoto" name="driver_photo" 
                                               class="form-control" accept="image/*">
                                        <div class="form-text">Please upload a photo with 5:6 aspect ratio (e.g., 500x600px)</div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="cropper-container" style="display: none;">
                                            <div class="cropper-wrapper">
                                                <img id="imageCropper" class="img-fluid" style="max-height: 300px;">
                                            </div>
                                            <div class="mt-3">
                                                <button type="button" id="cropImageBtn" class="btn btn-primary btn-sm">
                                                    <i class="fas fa-crop me-1"></i> Crop Image
                                                </button>
                                                <button type="button" id="cancelCropBtn" class="btn btn-secondary btn-sm ms-2">
                                                    <i class="fas fa-times me-1"></i> Cancel
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-end mt-4">
                    <button type="submit" id="submitBtn" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i> Save Driver
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal for cropping -->
<div class="modal fade" id="cropModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-crop me-2"></i> Crop Image</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="img-container">
                    <img id="modalCropper" src="" class="img-fluid">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" id="confirmCrop" class="btn btn-primary">Crop & Save</button>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    let cropper;
    let originalImageURL;
    let croppedImageBlob;
    
    $('#driverPhoto').change(function(e) {
        if (this.files && this.files[0]) {
            const file = this.files[0];
            
            if (!file.type.match('image.*')) {
                toastr.error('Please select an image file');
                return;
            }
            
            const reader = new FileReader();
            
            reader.onload = function(event) {
                originalImageURL = event.target.result;
                
                $('#modalCropper').attr('src', originalImageURL);
                $('#cropModal').modal('show');
                
                $('#cropModal').on('shown.bs.modal', function() {
                    if (cropper) {
                        cropper.destroy();
                    }
                    
                    const image = document.getElementById('modalCropper');
                    cropper = new Cropper(image, {
                        aspectRatio: 5/6, // Aspect ratio as requested
                        viewMode: 1,
                        autoCropArea: 0.8,
                        responsive: true,
                        guides: true
                    });
                });
            };
            
            reader.readAsDataURL(file);
        }
    });
    
    $('#confirmCrop').click(function() {
        if (cropper) {
            const canvas = cropper.getCroppedCanvas({
                width: 500,
                height: 600
            });
            
            if (canvas) {
                canvas.toBlob(function(blob) {
                    croppedImageBlob = blob;
                    const previewURL = URL.createObjectURL(blob);
                    $('#imagePreview').attr('src', previewURL);
                    $('#cropModal').modal('hide');
                    
                    if (cropper) {
                        cropper.destroy();
                        cropper = null;
                    }
                }, 'image/jpeg', 0.9);
            }
        }
    });
    
    $('#cropModal').on('hidden.bs.modal', function() {
        if (cropper) {
            cropper.destroy();
            cropper = null;
        }
    });
    
    $('#addDriverForm').submit(function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        const submitBtn = $('#submitBtn');
        
        if (croppedImageBlob) {
            formData.append('cropped_image', croppedImageBlob, 'driver_photo.jpg');
        } else if ($('#driverPhoto')[0].files[0]) {
            formData.append('original_image', $('#driverPhoto')[0].files[0]);
        }
        
        submitBtn.prop('disabled', true).html(`
            <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
            Saving...
        `);
        
        $.ajax({
            url: '../../api/admin/put/driver/save-driver.php', // Action file to save driver data
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                    setTimeout(() => {
                        window.location.reload();
                    }, 2000);
                } else {
                    toastr.error(response.message);
                }
                submitBtn.prop('disabled', false).html(`
                    <i class="fas fa-save me-2"></i> Save Driver
                `);
            },
            error: function() {
                toastr.error('An error occurred. Please try again.');
                submitBtn.prop('disabled', false).html(`
                    <i class="fas fa-save me-2"></i> Save Driver
                `);
            }
        });
    });
});
</script>

<style>
    .image-preview-wrapper {
        border: 1px dashed #ccc;
        padding: 5px;
        margin-bottom: 10px;
        text-align: center;
        background-color: #f8f9fa;
    }
    .img-container {
        height: 500px;
        overflow: hidden;
    }
</style>

<?php include_once("../../includes/body-close.php"); ?>
