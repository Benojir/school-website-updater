<?php
/** @var string $school_name */
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Add Driver - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// Check user permission for managing transport
// You might need to define PERM_MANAGE_TRANSPORT in your permission system
if (!hasPermission(PERM_MANAGE_TRANSPORT)) { 
    include_once("../../includes/permission-denied.php");
}

// Get list of routes for the route dropdown
$routes = $pdo->query("SELECT id, route_name FROM driving_routes ORDER BY route_name")->fetchAll();
?>

<div class="container py-4">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-user-plus me-2"></i> Add New Driver</h3>
                <a href="../driver/list-drivers.php" class="btn btn-light btn-sm">
                    <i class="fas fa-list me-1"></i> View Drivers
                </a>
            </div>
        </div>

        <div class="card-body">
            <form id="addDriverForm" enctype="multipart/form-data">
                <div class="row g-3">
                    <div class="col-12">
                        <h5 class="border-bottom pb-2 text-primary">Personal Information</h5>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label fw-bold">Driver Name <span class="text-danger">*</span></label>
                            <input type="text" name="driver_name" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label fw-bold">Driver Email ID</label>
                            <input type="email" name="driver_email" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label fw-bold">Phone Number <span class="text-danger">*</span></label>
                            <input type="text" name="phone_number" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label fw-bold">Driver Serial Number <span class="text-danger">*</span></label>
                            <input type="number" name="serial_number" class="form-control" required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label fw-bold">Driver Vehicle Number</label>
                            <input type="text" name="vehicle_number" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label fw-bold">Route <span class="text-danger">*</span></label>
                            <select name="routes[]" class="form-control custom-multiselect" multiple required>
                                <?php foreach ($routes as $route): ?>
                                    <option value="<?= $route['id'] ?>"><?= $route['route_name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label fw-bold">Aadhaar No.</label>
                            <input type="number" name="aadhaar_number" class="form-control">
                            <div class="form-text">Must be unique if provided.</div>
                        </div>
                    </div>

                    <div class="col-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">Family Details</h5>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Father's Name</label>
                            <input type="text" name="father_name" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Father's Phone</label>
                            <input type="text" name="father_phone" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Mother's Name</label>
                            <input type="text" name="mother_name" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Mother's Phone</label>
                            <input type="text" name="mother_phone" class="form-control">
                        </div>
                    </div>

                    <div class="col-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">Access Settings</h5>
                    </div>
                    <div class="col-12">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="can_view_student_financial_report" id="canViewStudentFinancialReport" value="1">
                            <label class="form-check-label fw-bold" for="canViewStudentFinancialReport">Allow this driver to see students' financial report</label>
                            <div class="form-text">When checked, this driver's app can see the fee amounts, bank details and family income recorded for the students assigned to them. Leave unchecked to hide all financial figures.</div>
                        </div>
                    </div>

                    <div class="col-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">Bank Details</h5>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">PAN Card No.</label>
                            <input type="text" name="pan_number" class="form-control" placeholder="ABCDE1234F" maxlength="10" style="text-transform:uppercase;">
                            <div class="form-text">Must be unique if provided.</div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Voter EPIC No.</label>
                            <input type="text" name="voter_epic_number" class="form-control" placeholder="ABC1234567" style="text-transform:uppercase;">
                            <div class="form-text">Must be unique if provided.</div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Bank Name</label>
                            <input type="text" name="bank_name" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Branch Name</label>
                            <input type="text" name="bank_branch" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">IFSC Code</label>
                            <input type="text" name="ifsc_code" class="form-control" style="text-transform:uppercase;">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="form-label fw-bold">Account Number</label>
                            <input type="text" name="account_number" class="form-control">
                        </div>
                    </div>

                    <div class="col-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">Address Details</h5>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label fw-bold">Village/Town</label>
                            <input type="text" name="village" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label fw-bold">Post Office</label>
                            <input type="text" name="post_office" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label fw-bold">Police Station</label>
                            <input type="text" name="police_station" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label fw-bold">District</label>
                            <input type="text" name="district" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="form-label fw-bold">Pincode</label>
                            <input type="text" name="pincode" class="form-control">
                        </div>
                    </div>

                    <!-- ===================== DOCUMENTS SECTION ===================== -->
                    <div class="col-12 mt-4">
                        <div class="d-flex justify-content-between align-items-center border-bottom pb-2">
                            <h5 class="text-primary mb-0">
                                Documents
                                <span id="documentsCounter" class="badge bg-secondary ms-2">0 / <?= MAX_DRIVER_DOCUMENTS ?></span>
                            </h5>
                            <button type="button" id="addDocumentBtn" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-plus me-1"></i> Add Document Field
                            </button>
                        </div>
                    </div>
                    <div class="col-12">
                        <div id="documentsContainer">
                            <!-- Dynamic document rows are injected here by JS -->
                        </div>
                        <div id="noDocumentsMsg" class="text-muted small">No document fields added yet. Click "Add Document Field" to attach driving licence, PAN card, etc.</div>
                        <div id="documentsLimitMsg" class="text-danger small" style="display:none;">
                            <i class="fas fa-circle-exclamation me-1"></i> Maximum of <?= MAX_DRIVER_DOCUMENTS ?> documents reached. Remove a field to add another.
                        </div>
                    </div>

                    <div class="col-12 mt-4">
                        <h5 class="border-bottom pb-2 text-primary">Profile Photo</h5>
                    </div>
                    <!-- Image Upload Section -->
                    <div class="col-12">
                        <div class="form-group">
                            <label class="form-label fw-bold">Driver Photo</label>
                            <div class="image-upload-container">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="image-preview-container mb-3">
                                            <div class="image-preview-wrapper">
                                                <img id="imagePreview" src="../../assets/img/avatars/default_driver_dp.jpg"
                                                     class="img-fluid" style="max-height: 200px; display: block;">
                                            </div>
                                        </div>
                                        <input type="file" id="driverPhoto" name="driver_photo"
                                               class="form-control" accept="image/*">
                                        <div class="form-text">Please upload a photo with 5:6 aspect ratio (e.g., 500x600px)</div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="cropper-container" style="display: none;">
                                            <div class="cropper-wrapper">
                                                <img id="imageCropper" class="img-fluid" style="max-height: 300px;">
                                            </div>
                                            <div class="mt-3">
                                                <button type="button" id="cropImageBtn" class="btn btn-primary btn-sm">
                                                    <i class="fas fa-crop me-1"></i> Crop Image
                                                </button>
                                                <button type="button" id="cancelCropBtn" class="btn btn-secondary btn-sm ms-2">
                                                    <i class="fas fa-times me-1"></i> Cancel
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Upload / Save Progress Bar -->
                <div class="col-12 mt-4" id="uploadProgressWrapper" style="display:none;">
                    <label class="form-label fw-bold mb-1" id="uploadProgressLabel">Uploading...</label>
                    <div class="progress" style="height: 22px;">
                        <div id="uploadProgressBar" class="progress-bar progress-bar-striped progress-bar-animated bg-primary"
                             role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">0%</div>
                    </div>
                </div>

                <div class="text-end mt-4">
                    <button type="submit" id="submitBtn" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i> Save Driver
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal for cropping -->
<div class="modal fade" id="cropModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title"><i class="fas fa-crop me-2"></i> Crop Image</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="img-container">
                    <img id="modalCropper" src="" class="img-fluid">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" id="confirmCrop" class="btn btn-primary">Crop & Save</button>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    let cropper;
    let originalImageURL;
    let croppedImageBlob;
    let documentRowIndex = 0;
    const MAX_DOCUMENTS = <?= MAX_DRIVER_DOCUMENTS ?>;

    // ===================== Dynamic Document Fields =====================
    function countDocumentRows() {
        return $('#documentsContainer .document-row').length;
    }

    function refreshDocumentsUI() {
        const total = countDocumentRows();
        const limitReached = total >= MAX_DOCUMENTS;

        $('#documentsCounter').text(total + ' / ' + MAX_DOCUMENTS)
            .toggleClass('bg-secondary', !limitReached)
            .toggleClass('bg-danger', limitReached);
        $('#noDocumentsMsg').toggle(total === 0);
        $('#documentsLimitMsg').toggle(limitReached);
        $('#addDocumentBtn').prop('disabled', limitReached);
    }

    function addDocumentRow() {
        if (countDocumentRows() >= MAX_DOCUMENTS) {
            toastr.error(`You can add a maximum of ${MAX_DOCUMENTS} documents.`);
            return;
        }

        documentRowIndex++;
        const rowId = 'docRow_' + documentRowIndex;
        const rowHtml = `
            <div class="document-row row g-2 align-items-center mb-2" id="${rowId}">
                <div class="col-md-4">
                    <input type="text" name="document_name[]" class="form-control" placeholder="Document Name (e.g. Driving Licence)" required>
                </div>
                <div class="col-md-5">
                    <input type="file" name="document_file[]" class="form-control" accept="image/*" required>
                </div>
                <div class="col-md-2">
                    <div class="progress" style="height: 8px; display:none;" data-doc-progress>
                        <div class="progress-bar bg-success" role="progressbar" style="width: 0%;"></div>
                    </div>
                </div>
                <div class="col-md-1 text-end">
                    <button type="button" class="btn btn-outline-danger btn-sm remove-document-btn" title="Remove">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `;
        $('#documentsContainer').append(rowHtml);
        refreshDocumentsUI();
    }

    $('#addDocumentBtn').click(function() {
        addDocumentRow();
    });

    $('#documentsContainer').on('click', '.remove-document-btn', function() {
        $(this).closest('.document-row').remove();
        refreshDocumentsUI();
    });

    refreshDocumentsUI();

    // Auto-uppercase PAN / IFSC / Voter EPIC as the admin types
    $('input[name="pan_number"], input[name="ifsc_code"], input[name="voter_epic_number"]').on('input', function() {
        this.value = this.value.toUpperCase();
    });

    $('#driverPhoto').change(function(e) {
        if (this.files && this.files[0]) {
            const file = this.files[0];

            if (!file.type.match('image.*')) {
                toastr.error('Please select an image file');
                return;
            }

            const reader = new FileReader();

            reader.onload = function(event) {
                originalImageURL = event.target.result;

                $('#modalCropper').attr('src', originalImageURL);
                $('#cropModal').modal('show');

                $('#cropModal').on('shown.bs.modal', function() {
                    if (cropper) {
                        cropper.destroy();
                    }

                    const image = document.getElementById('modalCropper');
                    cropper = new Cropper(image, {
                        aspectRatio: 5/6, // Aspect ratio as requested
                        viewMode: 1,
                        autoCropArea: 0.8,
                        responsive: true,
                        guides: true
                    });
                });
            };

            reader.readAsDataURL(file);
        }
    });

    $('#confirmCrop').click(function() {
        if (cropper) {
            const canvas = cropper.getCroppedCanvas({
                width: 500,
                height: 600
            });

            if (canvas) {
                canvas.toBlob(function(blob) {
                    croppedImageBlob = blob;
                    const previewURL = URL.createObjectURL(blob);
                    $('#imagePreview').attr('src', previewURL);
                    $('#cropModal').modal('hide');

                    if (cropper) {
                        cropper.destroy();
                        cropper = null;
                    }
                }, 'image/jpeg', 0.9);
            }
        }
    });

    $('#cropModal').on('hidden.bs.modal', function() {
        if (cropper) {
            cropper.destroy();
            cropper = null;
        }
    });

    // ===================== Progress Bar Helpers =====================
    function setProgress(percent, label) {
        $('#uploadProgressWrapper').show();
        $('#uploadProgressBar').css('width', percent + '%').attr('aria-valuenow', percent).text(percent + '%');
        if (label) {
            $('#uploadProgressLabel').text(label);
        }
    }

    function resetProgress() {
        $('#uploadProgressWrapper').hide();
        $('#uploadProgressBar').css('width', '0%').attr('aria-valuenow', 0).text('0%');
    }

    $('#addDriverForm').submit(function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        const submitBtn = $('#submitBtn');

        if (croppedImageBlob) {
            formData.append('cropped_image', croppedImageBlob, 'driver_photo.jpg');
        } else if ($('#driverPhoto')[0].files[0]) {
            formData.append('original_image', $('#driverPhoto')[0].files[0]);
        }

        submitBtn.prop('disabled', true).html(`
            <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
            Saving...
        `);

        setProgress(0, 'Uploading data & files...');

        $.ajax({
            url: '<?= BASE_URL ?>/api/admin/put/driver/save-driver.php', // Action file to save driver data
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            xhr: function() {
                const xhr = $.ajaxSettings.xhr();
                if (xhr.upload) {
                    xhr.upload.addEventListener('progress', function(evt) {
                        if (evt.lengthComputable) {
                            // Upload itself counts for 0-70%; the remaining 70-100%
                            // is the server-side processing (ImgBB upload + DB insert).
                            const uploadPercent = Math.round((evt.loaded / evt.total) * 70);
                            setProgress(uploadPercent, uploadPercent < 70 ? 'Uploading data & files...' : 'Upload complete, processing...');
                        }
                    }, false);
                }
                return xhr;
            },
            beforeSend: function() {
                setProgress(5, 'Uploading data & files...');
            },
            success: function(response) {
                setProgress(100, 'Done!');
                if (response.success) {
                    toastr.success(response.message);
                    showSuccessAlert(response.message);
                    setTimeout(() => {
                        window.location.reload();
                    }, 2000);
                } else {
                    toastr.error(response.message);
                    showErrorAlert(response.message);
                }
                submitBtn.prop('disabled', false).html(`<i class="fas fa-save me-2"></i> Save Driver`);
                setTimeout(resetProgress, 1500);
            },
            error: function(e) {
                toastr.error('An error occurred. Please try again.');
                showErrorAlert('An error occurred. Please try again.');
                submitBtn.prop('disabled', false).html(`<i class="fas fa-save me-2"></i> Save Driver`);
                console.error(e.responseText);
                resetProgress();
            }
        });
    });
});
</script>

<style>
    .image-preview-wrapper {
        border: 1px dashed #ccc;
        padding: 5px;
        margin-bottom: 10px;
        text-align: center;
        background-color: #f8f9fa;
    }
    .img-container {
        height: 500px;
        overflow: hidden;
    }

    .document-row {
        background-color: #f8f9fa;
        border: 1px solid #e9ecef;
        border-radius: 6px;
        padding: 8px 6px;
    }
</style>

<?php include_once("../../includes/body-close.php"); ?>
