<?php
require_once __DIR__ . '/../../includes/auth-check.php';
require_once __DIR__ . '/../../includes/inventory/inventory-service.php';
header('Cache-Control: no-store');
if (!isAnyAdminLoggedIn() || !hasPermission(PERM_MANAGE_INVENTORY)) {
    http_response_code(403);
    exit('You do not have permission to view this receipt.');
}
try {
    $service = new InventoryService($pdo, (int)getAuthenticatedAdmin($pdo)['user_id']);
    $doc = $service->detail(inventoryInteger($_GET['id'] ?? 0, 'Entry', 1, PHP_INT_MAX));
} catch (Throwable $e) {
    http_response_code(404);
    exit('This inventory receipt is not available.');
}
$h = fn($value) => htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
$money = fn($value) => $h($currency_symbol) . number_format((int)$value / 100, 2);
$labels = ['sale'=>'Sales receipt', 'purchase'=>'Stock purchase', 'gift'=>'Free distribution', 'damage'=>'Stock loss record', 'return'=>'Full return & refund'];
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>INV-<?= (int)$doc['id'] ?> · Inventory receipt</title>
<style>
body{font:15px/1.5 Arial,sans-serif;color:#213c30;background:#f0f4f1;margin:0;padding:30px}.receipt{max-width:760px;margin:auto;background:white;padding:36px;border:1px solid #dce6df;border-radius:12px}h1{margin:0;font-size:25px}h2{font-size:18px;margin-top:28px}.muted{color:#64786b;font-size:13px}.split{display:flex;justify-content:space-between;gap:20px}table{border-collapse:collapse;width:100%;margin:20px 0}td,th{text-align:left;padding:10px;border-bottom:1px solid #dce6df}th{background:#f2f7f4;font-size:13px}.right{text-align:right}.total{font-size:18px;font-weight:bold}.note{white-space:pre-wrap}button{background:#176b52;color:white;border:0;border-radius:6px;padding:10px 20px;cursor:pointer;margin-bottom:16px}@media print{body{background:white;padding:0}.receipt{border:0;padding:0;border-radius:0}button{display:none}tr{break-inside:avoid}}@media(max-width:600px){body{padding:8px}.receipt{padding:15px}td,th{padding:7px}.split{flex-wrap:wrap}}
</style></head><body><article class="receipt"><button onclick="window.print()">Print receipt</button>
<div class="split"><div><h1><?= $h($school_name) ?></h1><div class="muted"><?= $h($schoolInfo['address'] ?? '') ?></div></div><div class="right"><b>INV-<?= (int)$doc['id'] ?></b><br><span class="muted"><?= $h($doc['created_at']) ?></span></div></div>
<h2><?= $labels[$doc['kind']] ?><?= $doc['status'] === 'returned' ? ' — RETURNED' : '' ?></h2>
<p><b><?= $h($doc['customer_name'] ?: ($doc['supplier'] ?: 'School stock')) ?></b><br><?= $h($doc['student_id']) ?> <?= $h($doc['class_name']) ?></p>
<?php if ($doc['original_document_id']): ?><p>Original bill: INV-<?= (int)$doc['original_document_id'] ?></p><?php endif; ?>
<table><thead><tr><th>Product</th><th>Qty</th><th class="right">Price</th><th class="right">Amount</th></tr></thead><tbody>
<?php foreach ($doc['items'] as $item): ?><tr><td><?= $h($item['product_name']) ?></td><td><?= (int)$item['quantity'] ?> <?= $h($item['unit']) ?></td><td class="right"><?= $money($item['unit_price_paise']) ?></td><td class="right"><?= $money($item['line_total_paise']) ?></td></tr><?php endforeach; ?>
</tbody></table><div class="right"><p class="total">Total: <?= $money($doc['total_paise']) ?></p><p><?= $doc['kind'] === 'return' ? 'Refund recorded' : 'Actual payment recorded' ?>: <?= $money(abs((int)$doc['paid_paise'])) ?><br><?= $doc['kind'] === 'return' ? 'Waiver reversed' : 'Balance waived' ?>: <?= $money(abs((int)$doc['waived_paise'])) ?><br>Balance due: <?= $money($doc['due_paise']) ?></p></div>
<?php if ($doc['payments']): ?><h2>Payment history</h2><table><thead><tr><th>Date</th><th>Method / reference</th><th class="right">Received / refunded</th></tr></thead><tbody><?php foreach ($doc['payments'] as $payment): ?><tr><td><?= $h($payment['created_at']) ?></td><td><?= $h(ucfirst($payment['method'])) ?><br><span class="muted"><?= $h($payment['reference']) ?></span></td><td class="right"><?= $money($payment['amount_paise']) ?></td></tr><?php endforeach; ?></tbody></table><?php endif; ?>
<p class="note"><?= $h($doc['note']) ?></p><p class="muted">Reference: <?= $h($doc['reference'] ?: '-') ?><br>Recorded by: <?= $h($doc['admin_name'] ?: '-') ?></p>
<?php if ($doc['adjustments']): ?><h2>Settlement / waiver history</h2><table><thead><tr><th>Date / recorded by</th><th>Reason</th><th class="right">Waived / reversed</th></tr></thead><tbody><?php foreach ($doc['adjustments'] as $adjustment): ?><tr><td><?= $h($adjustment['created_at']) ?><br><?= $h($adjustment['admin_name'] ?: '-') ?></td><td><?= $h($adjustment['reason']) ?></td><td class="right"><?= $money($adjustment['amount_paise']) ?></td></tr><?php endforeach; ?></tbody></table><?php endif; ?>
<?php if ($doc['kind'] === 'return'): ?><p class="muted">All items were returned to stock. The original bill's remaining due is cleared.</p><?php endif; ?>
</article></body></html>
