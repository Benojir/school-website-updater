<?php
require_once __DIR__ . '/../../includes/auth-check.php';
require_once __DIR__ . '/../../includes/header-open.php';
echo '<title>Inventory - ' . safe_htmlspecialchars($school_name) . '</title>';
require_once __DIR__ . '/../../includes/header-close.php';
require_once __DIR__ . '/../../includes/dashboard-navbar.php';
if (!hasPermission(PERM_MANAGE_INVENTORY)) require __DIR__ . '/../../includes/permission-denied.php';
$canReport = hasPermission(PERM_CAN_SEE_FINANCIAL_REPORT);
$_SESSION['inventory_csrf'] ??= bin2hex(random_bytes(32));
?>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/inventory.css?v=<?= $assets_version ?>">
<main class="container inventory-app py-3" id="inventoryApp">
    <div class="inventory-heading mb-4">
        <div><span class="inventory-eyebrow">SCHOOL STORE</span><h1>Inventory</h1><p class="text-muted mb-0">Books, bags and everyday supplies. Keep every item accounted for.</p></div>
        <button class="btn btn-primary btn-lg" data-action="sale"><i class="fas fa-bag-shopping me-2"></i>Sell / give to student</button>
    </div>
    <div id="inventoryNotice" role="alert" class="alert alert-danger d-none"></div>
    <div class="row g-3 mb-4" aria-label="Stock overview">
        <div class="col-4"><div class="inventory-stat"><span>Active products</span><strong id="statProducts">-</strong></div></div>
        <div class="col-4"><div class="inventory-stat"><span>Items in stock</span><strong id="statUnits">-</strong></div></div>
        <div class="col-4"><button class="inventory-stat inventory-low w-100 text-start" data-action="low"><span>Need restocking</span><strong id="statLow">-</strong></button></div>
    </div>
    <div class="inventory-guide mb-4"><i class="fas fa-circle-info me-2"></i><span>First time here? <b>1.</b> Add a product. <b>2.</b> Add the stock you bought. <b>3.</b> Sell or give items to students.</span></div>
    <section class="card border-0 shadow-sm inventory-workspace">
        <div class="inventory-tabs" role="tablist" aria-label="Inventory views">
            <button role="tab" aria-selected="true" data-tab="products" class="active">Products & stock</button>
            <button role="tab" aria-selected="false" data-tab="sales">Sales & dues</button>
            <button role="tab" aria-selected="false" data-tab="purchases">Stock purchases</button>
            <button role="tab" aria-selected="false" data-tab="report">Profit & loss</button>
        </div>
        <div class="card-body p-3 p-lg-4">
            <div class="inventory-toolbar mb-3">
                <div><h2 class="h5 mb-1" id="viewTitle">Products & stock</h2><p class="small text-muted mb-0" id="viewHint">See what is available and what needs restocking.</p></div>
                <div class="d-flex gap-2 flex-wrap" id="stockActions"><button class="btn btn-outline-primary" data-action="purchase"><i class="fas fa-plus me-1"></i>Add stock</button><button class="btn btn-primary" data-action="product">New product</button><button class="btn btn-outline-secondary" data-action="damage">Record stock loss</button></div>
            </div>
            <form id="inventoryFilters" class="row g-2 align-items-end mb-3">
                <div class="col-md-4" id="searchWrap"><label class="form-label small" for="inventorySearch">Search</label><input id="inventorySearch" class="form-control" placeholder="Product name, code or category" maxlength="100"></div>
                <div class="col-md-2" id="stockStatusWrap"><label class="form-label small" for="stockStatus">Products</label><select id="stockStatus" class="form-select"><option value="active">Active</option><option value="inactive">Inactive</option><option value="all">All products</option></select></div>
                <div class="col-md-2" id="stockLowWrap"><label class="form-label small" for="stockLow">Stock</label><select id="stockLow" class="form-select"><option value="">All stock levels</option><option value="1">Low / out of stock</option></select></div>
                <div class="col-md-2 d-none" id="dueWrap"><label class="form-label small" for="onlyDue">Payment</label><select id="onlyDue" class="form-select"><option value="">All entries</option><option value="1">Unpaid / part paid</option></select></div>
                <div class="col-md-2 d-none date-wrap"><label class="form-label small" for="inventoryFrom">From</label><input type="date" id="inventoryFrom" class="form-control"></div>
                <div class="col-md-2 d-none date-wrap"><label class="form-label small" for="inventoryTo">To</label><input type="date" id="inventoryTo" class="form-control"></div>
                <div class="col-auto"><button class="btn btn-outline-primary" type="submit">Apply</button></div>
                <div class="col-auto ms-auto d-none" id="reportExportWrap"><button type="button" class="btn btn-outline-secondary" data-action="export">Download CSV</button></div>
            </form>
            <div id="inventoryResults" aria-live="polite"><div class="inventory-empty">Loading your inventory…</div></div>
            <div id="inventoryPagination" class="d-flex justify-content-between align-items-center mt-3"></div>
        </div>
    </section>
    <p class="small text-muted mt-3">Stock changes are saved with the person and time of entry. Recorded entries stay in history.</p>
</main>
<div class="modal fade" id="inventoryModal" tabindex="-1" aria-labelledby="inventoryModalTitle" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content">
        <div class="modal-header"><h2 class="modal-title fs-5" id="inventoryModalTitle"></h2><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
        <div class="modal-body" id="inventoryModalBody"></div>
    </div></div>
</div>
<script>
window.inventoryConfig = <?= json_encode([
    'api' => BASE_URL . '/api/admin/inventory.php',
    'receipt' => BASE_URL . '/management/inventory/receipt.php',
    'csrf' => $_SESSION['inventory_csrf'],
    'canReport' => $canReport,
    'currency' => $currency_symbol,
    'today' => date('Y-m-d'),
    'monthStart' => date('Y-m-01')
], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
</script>
<script defer src="<?= BASE_URL ?>/assets/js/inventory.js?v=<?= $assets_version ?>"></script>
<?php require_once __DIR__ . '/../../includes/body-close.php'; ?>
