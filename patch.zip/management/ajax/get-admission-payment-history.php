<?php
require_once("../../includes/config.php");
header('Content-Type: application/json');

// Validate inputs
if (!isset($_GET['student_id']) || !isset($_GET['page']) || !isset($_GET['per_page'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

$student_id = $_GET['student_id'];
$page = max(1, (int)$_GET['page']);
$per_page = max(1, (int)$_GET['per_page']);
$offset = ($page - 1) * $per_page;

try {
    // Get total count
    $count_stmt = $pdo->prepare("SELECT COUNT(*) as total FROM admission_fees_payment_history WHERE student_id = ?");
    $count_stmt->execute([$student_id]);
    $total = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
    $total_pages = ceil($total / $per_page);

    // Get paginated data
    $stmt = $pdo->prepare("
        SELECT * FROM admission_fees_payment_history 
        WHERE student_id = ?
        ORDER BY payment_date DESC, updated_at DESC
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$student_id, $per_page, $offset]);
    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'data' => $payments,
        'current_page' => $page,
        'total_pages' => $total_pages,
        'total_items' => $total
    ]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}