<?php
// Include the database connection file.
require_once("../../includes/db.php");

// Set the response header to JSON.
header('Content-Type: application/json');

// Get the driver ID from the GET request. Default to 0 if not provided.
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Initialize the response array.
$response = ['success' => false, 'driver' => null];

try {
    // Proceed only if a valid ID is provided.
    if ($id > 0) {
        // Prepare and execute a query to select the driver by their ID.
        $stmt = $pdo->prepare("SELECT * FROM drivers WHERE id = ?");
        $stmt->execute([$id]);
        $driver = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // If a driver is found, set the response to success and return the data.
        if ($driver) {
            $response['success'] = true;
            $response['driver'] = $driver;
        } else {
            // If no driver is found, set an error message.
            $response['message'] = 'Driver not found';
        }
    } else {
        $response['message'] = 'Invalid driver ID';
    }
} catch (PDOException $e) {
    // Handle any database errors.
    $response['message'] = 'Database error: ' . $e->getMessage();
}

// Send the JSON response.
echo json_encode($response);
