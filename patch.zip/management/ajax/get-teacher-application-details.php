<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");

header('Content-Type: application/json');

// Check permission
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

// Validate input
if (!isset($_GET['application_id']) || empty(trim($_GET['application_id']))) {
    echo json_encode(['success' => false, 'message' => 'Application ID is required']);
    exit;
}

$application_id = trim($_GET['application_id']);

try {
    // Fetch application details
    $stmt = $pdo->prepare("SELECT * FROM teacher_applications WHERE id = ?");
    $stmt->execute([$application_id]);
    $application = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$application) {
        echo json_encode(['success' => false, 'message' => 'Application not found']);
        exit;
    }

    // Generate HTML for modal
    $html = '
    <div class="row">
        <div class="col-md-4 text-center mb-4">
            <img src="../../uploads/teachers/' . $application['applicant_image'] . '" 
                 class="img-fluid rounded-circle border" 
                 style="width: 200px; height: 200px; object-fit: cover;" 
                 alt="Applicant Photo">
        </div>
        <div class="col-md-8">
            <h4>' . safe_htmlspecialchars($application['name']) . '</h4>
            <p class="text-muted">' . 
                ($application['has_experience'] == 'yes' ? 'Experienced Teacher' : 'New Teacher') . 
                (!empty($application['previous_school']) ? ' - Previously at ' . safe_htmlspecialchars($application['previous_school']) : '') . 
            '</p>
            
            <div class="row mt-3">
                <div class="col-md-6">
                    <h5>Contact Information</h5>
                    <p>
                        <i class="fas fa-envelope me-2"></i> ' . safe_htmlspecialchars($application['email']) . '<br>
                        <i class="fas fa-phone me-2"></i> ' . safe_htmlspecialchars($application['phone_number']) . '<br>
                        <i class="fas fa-map-marker-alt me-2"></i> ' . nl2br(safe_htmlspecialchars($application['address'])) . '
                    </p>
                </div>
                <div class="col-md-6">
                    <h5>Professional Details</h5>
                    <p>
                        <strong>Qualification:</strong> ' . safe_htmlspecialchars($application['qualification']) . '<br>
                        <strong>Specialization:</strong> ' . safe_htmlspecialchars($application['specialization']) . '<br>
                        <strong>Applied On:</strong> ' . date('d M Y h:i A', strtotime($application['application_date'])) . '
                    </p>
                </div>
            </div>
            
            <div class="mt-4">
                <h5>Additional Information</h5>
                <div class="card">
                    <div class="card-body">
                        ' . (!empty($application['previous_school']) ? 
                            '<p><strong>Previous School:</strong> ' . safe_htmlspecialchars($application['previous_school']) . '</p>' : 
                            '<p>No previous teaching experience mentioned.</p>') . '
                    </div>
                </div>
            </div>
        </div>
    </div>';

    echo json_encode(['success' => true, 'html' => $html]);
    
} catch (PDOException $e) {
    error_log("Database error in get teacher application details: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error occurred']);
} catch (Exception $e) {
    error_log("Error in get teacher application details: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'An error occurred']);
}
?>