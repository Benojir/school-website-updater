<?php
require_once("../../includes/db.php");
header('Content-Type: application/json');

try {
    // Get classes
    $stmt = $pdo->prepare("SELECT * FROM classes ORDER BY id ASC");
    $stmt->execute();
    $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $classes_array = [];

    foreach ($classes as $class) {
        $classes_array[] = array(
            'id' => $class['id'],
            'name' => $class['class_name']
        );
    }
    
    echo json_encode([
        'success' => true,
        'data' => $classes_array
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}