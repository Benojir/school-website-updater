<?php
include_once("../../includes/db.php");

// Set the content type to application/json
header('Content-Type: application/json');

// Get the last 12 years of admission fees data
try {
    $stmt = $pdo->prepare("SELECT MAX(academic_year) AS highest_year FROM admission_unpaid_fees");
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    $admission_fees_data = [];

    $highest_year = $row['highest_year'];
    $start_year = $highest_year - 11;

    for ($year = $start_year; $year <= $highest_year; $year++) { 

        $year_data = [];

        $stmt = $pdo->prepare("SELECT SUM(unpaid_amount) AS unpaid_amount FROM admission_unpaid_fees WHERE academic_year = :year");
        $stmt->execute(['year' => $year]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $unpaid_amount = $row['unpaid_amount'] ?? 0;

        $stmt = $pdo->prepare("SELECT SUM(partial_paid_amount) AS paid_amount FROM admission_partial_fees_payments WHERE academic_year = :year");
        $stmt->execute(['year' => $year]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $paid_amount = $row['paid_amount'] ?? 0;

        $year_data['academic_year'] = $year;
        $year_data['unpaid_amount'] = $unpaid_amount;
        $year_data['paid_amount'] = $paid_amount;

        $admission_fees_data[] = $year_data;
    }

    echo json_encode($admission_fees_data);

} catch (PDOException $e) {
    // Handle database errors
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>