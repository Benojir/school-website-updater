<?php
require_once("../../includes/db.php");
header('Content-Type: application/json');

$student_id = $_REQUEST['student_id'] ?? '';

if (empty($student_id)) {
    echo json_encode(['success' => false, 'message' => 'Required fields are missing']);
    exit;
}

try {
    // Fetch student info
    $stmt = $pdo->prepare("SELECT * FROM students WHERE student_id = ?");
    $stmt->execute([$student_id]);
    $student_info = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student_info || in_array(strtolower($student_info['status']), ['left', 'alumni'])) {
        throw new Exception('Student not found or has left or is alumni.');
    }

    $car_fee = $student_info['car_fee'] ?? 0;
    $hostel_fee = $student_info['hostel_fee'] ?? 0;
    $custom_class_fee = $student_info['custom_class_fee'] ?? 0;
    $class_id = $student_info['class_id'];
    $remark = "Monthly fee";

    // Fetch class-wise fee
    $stmt = $pdo->prepare("SELECT amount FROM class_wise_fee WHERE class_id = ?");
    $stmt->execute([$class_id]);
    $class_fee_row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$class_fee_row) {
        throw new Exception('No class-wise fee found. Please add it in general settings.');
    }

    $class_fee = $custom_class_fee > 0 ? $custom_class_fee : $class_fee_row['amount'];

    $total_fees = ($class_fee + $car_fee + $hostel_fee);

    $remark.= " total <b>{$total_fees}/-</b>";

    $includes = [];
    if ($custom_class_fee > 0) $includes[] = "<b>{$custom_class_fee}/-</b> custom class fee";
    if ($car_fee > 0) $includes[] = "<b>{$car_fee}/-</b> car fee";
    if ($hostel_fee > 0) $includes[] = "<b>{$hostel_fee}/-</b> hostel";

    if ($includes) {
        $remark .= ' <br>(includes ' . implode(' and ', $includes) . ' fee)';
    }

    echo json_encode([
        'success' => true,
        'message' => $remark
    ]);
    exit;

} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database Error: ' . $e->getMessage()
    ]);
    exit;
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
    exit;
}
