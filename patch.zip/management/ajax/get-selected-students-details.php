<?php
// ../ajax/get-selected-students-details.php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");

header('Content-Type: application/json');

try {
    if (!isset($_POST['student_ids']) || empty($_POST['student_ids'])) {
        throw new Exception('No student IDs provided');
    }

    $studentIds = explode(',', $_POST['student_ids']);

    if (empty($studentIds)) {
        throw new Exception('Invalid student IDs');
    }

    $placeholders = str_repeat('?,', count($studentIds) - 1) . '?';
    
    $stmt = $pdo->prepare("
        SELECT 
            s.student_id,
            s.name,
            c.class_name,
            sec.section_name
        FROM students s
        JOIN classes c ON s.class_id = c.id
        JOIN sections sec ON s.section_id = sec.id
        WHERE s.student_id IN ($placeholders)
        ORDER BY s.name
    ");
    
    $stmt->execute($studentIds);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'students' => $students
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>