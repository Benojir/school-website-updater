<?php
require_once("../../includes/db.php");
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$exam_id = $_GET['exam_id'] ?? '';
$class_id = $_GET['class_id'] ?? '';

if (empty($exam_id) || empty($class_id)) {
    echo json_encode(['success' => false, 'message' => 'Required fields are missing']);
    exit;
}

try {
    // Get all results for this exam and class
    $stmt = $pdo->prepare("
        SELECT r.id, r.student_id, r.exam_id, r.class_id,
               r.total_marks, r.obtained_marks, r.percentage,
               r.grade, r.remarks
        FROM results r
        WHERE r.exam_id = ? AND r.class_id = ?
    ");
    $stmt->execute([$exam_id, $class_id]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get subject marks for each result
    foreach ($results as &$result) {
        $stmt = $pdo->prepare("
            SELECT subject_id, theory_marks, practical_marks,
                   total_marks, obtained_marks, grade, remarks, is_absent, is_excluded
            FROM subject_marks
            WHERE result_id = ?
        ");
        $stmt->execute([$result['id']]);
        $result['subjects'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    echo json_encode([
        'success' => true,
        'data' => $results
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}