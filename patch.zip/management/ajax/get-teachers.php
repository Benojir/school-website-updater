<?php
require_once("../../includes/db.php");

header('Content-Type: application/json');

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$offset = ($page - 1) * $limit;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$status = isset($_GET['status']) ? trim($_GET['status']) : '';

$response = [
    'teachers' => [],
    'total' => 0
];

try {
    // Base query
    $sql = "SELECT SQL_CALC_FOUND_ROWS * FROM teachers WHERE 1=1";
    $params = [];
    
    // Add search condition
    if (!empty($search)) {
        $sql .= " AND (name LIKE ? OR teacher_id LIKE ? OR email LIKE ? OR phone LIKE ?)";
        $searchParam = "%$search%";
        $params = array_merge($params, array_fill(0, 4, $searchParam));
    }
    
    // Add status filter
    if (!empty($status)) {
        $sql .= " AND status = ?";
        $params[] = $status;
    }
    
    // Add sorting and pagination
    $sql .= " ORDER BY name ASC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    
    // Prepare and execute query
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $response['teachers'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total count
    $totalStmt = $pdo->query("SELECT FOUND_ROWS()");
    $response['total'] = $totalStmt->fetchColumn();
} catch (PDOException $e) {
    http_response_code(500);
    $response['error'] = 'Database error: ' . $e->getMessage();
}

echo json_encode($response);