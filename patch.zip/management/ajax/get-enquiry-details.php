<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/permission-check.php");

header('Content-Type: application/json');

// Check permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

// Validate input parameters
if (!isset($_REQUEST['enquiry_id']) || empty(trim($_REQUEST['enquiry_id']))) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid request. Required parameters missing.']);
    exit;
}

$enquiry_id = filter_var(trim($_REQUEST['enquiry_id']), FILTER_VALIDATE_INT);

if ($enquiry_id === false || $enquiry_id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid enquiry ID provided.']);
    exit;
}

$table = "admission_enquiries";

try {
    // Get enquiry details with class information
    $sql = "SELECT se.*, c.class_name 
            FROM admission_enquiries se 
            LEFT JOIN classes c ON se.class_id = c.id 
            WHERE se.id = ?";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$enquiry_id]);
    $enquiry = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$enquiry) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Enquiry not found.']);
        exit;
    }
    
    // Calculate age from date of birth
    $age = '';
    if (!empty($enquiry['date_of_birth'])) {
        $birth_date = new DateTime($enquiry['date_of_birth']);
        $current_date = new DateTime();
        $age_diff = $current_date->diff($birth_date);
        $age = $age_diff->y . ' years';
        if ($age_diff->m > 0) {
            $age .= ', ' . $age_diff->m . ' months';
        }
    }
    
    // Format dates
    $formatted_dob = !empty($enquiry['date_of_birth']) ? date('d F Y', strtotime($enquiry['date_of_birth'])) : 'Not provided';
    $formatted_created = date('d F Y \a\t h:i A', strtotime($enquiry['created_at']));
    
    // Generate HTML content
    $html = '
    <div class="row">
        <!-- Student Information -->
        <div class="col-md-6">
            <div class="card mb-3">
                <div class="card-header bg-primary text-white">
                    <h6 class="mb-0"><i class="fas fa-user me-2"></i>Student Information</h6>
                </div>
                <div class="card-body">
                    <div class="row mb-2">
                        <div class="col-4"><strong>Name:</strong></div>
                        <div class="col-8">' . safe_htmlspecialchars($enquiry['name'] ?? 'N/A') . '</div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-4"><strong>Gender:</strong></div>
                        <div class="col-8">
                            <span class="badge bg-' . (strtolower($enquiry['gender']) === 'male' ? 'info' : 'pink') . '">
                                ' . safe_htmlspecialchars($enquiry['gender'] ?? 'N/A') . '
                            </span>
                        </div>
                    </div>
                    <div class="row mb-2">
                        <div class="col-4"><strong>Date of Birth:</strong></div>
                        <div class="col-8">' . $formatted_dob . '</div>
                    </div>';
    
    if (!empty($age)) {
        $html .= '
                    <div class="row mb-2">
                        <div class="col-4"><strong>Age:</strong></div>
                        <div class="col-8">' . $age . '</div>
                    </div>';
    }
    
    $html .= '
                    <div class="row mb-2">
                        <div class="col-4"><strong>Blood Group:</strong></div>
                        <div class="col-8">
                            <span class="badge bg-danger">' . safe_htmlspecialchars($enquiry['blood_group'] ?? 'N/A') . '</span>
                        </div>
                    </div>
                    <div class="row mb-0">
                        <div class="col-4"><strong>Applied Class:</strong></div>
                        <div class="col-8">
                            <span class="badge bg-success">' . safe_htmlspecialchars($enquiry['class_name'] ?? 'N/A') . '</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Contact Information -->
        <div class="col-md-6">
            <div class="card mb-3">
                <div class="card-header bg-success text-white">
                    <h6 class="mb-0"><i class="fas fa-phone me-2"></i>Contact Information</h6>
                </div>
                <div class="card-body">
                    <div class="row mb-2">
                        <div class="col-4"><strong>Phone:</strong></div>
                        <div class="col-8">
                            <a href="tel:' . safe_htmlspecialchars($enquiry['phone_number'] ?? '') . '" class="text-decoration-none">
                                <i class="fas fa-phone-alt me-1"></i>' . safe_htmlspecialchars($enquiry['phone_number'] ?? 'N/A') . '
                            </a>
                        </div>
                    </div>';
    
    if (!empty($enquiry['alternate_phone_number'])) {
        $html .= '
                    <div class="row mb-2">
                        <div class="col-4"><strong>Alt. Phone:</strong></div>
                        <div class="col-8">
                            <a href="tel:' . safe_htmlspecialchars($enquiry['alternate_phone_number']) . '" class="text-decoration-none">
                                <i class="fas fa-phone me-1"></i>' . safe_htmlspecialchars($enquiry['alternate_phone_number']) . '
                            </a>
                        </div>
                    </div>';
    }
    
    $html .= '
                    <div class="row mb-2">
                        <div class="col-4"><strong>Email:</strong></div>
                        <div class="col-8">';
    
    if (!empty($enquiry['email'])) {
        $html .= '<a href="mailto:' . safe_htmlspecialchars($enquiry['email']) . '" class="text-decoration-none">
                            <i class="fas fa-envelope me-1"></i>' . safe_htmlspecialchars($enquiry['email']) . '
                        </a>';
    } else {
        $html .= 'N/A';
    }
    
    $html .= '
                        </div>
                    </div>
                    <div class="row mb-0">
                        <div class="col-4"><strong>Address:</strong></div>
                        <div class="col-8">' . (!empty($enquiry['address']) ? nl2br(safe_htmlspecialchars($enquiry['address'])) : 'N/A') . '</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Parent Information -->
    <div class="row">
        <div class="col-12">
            <div class="card mb-3">
                <div class="card-header bg-warning text-dark">
                    <h6 class="mb-0"><i class="fas fa-users me-2"></i>Parent Information</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="text-primary"><i class="fas fa-male me-2"></i>Father Details</h6>
                            <div class="row mb-2">
                                <div class="col-4"><strong>Name:</strong></div>
                                <div class="col-8">' . safe_htmlspecialchars($enquiry['father_name'] ?? 'N/A') . '</div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-4"><strong>Occupation:</strong></div>
                                <div class="col-8">' . safe_htmlspecialchars($enquiry['father_occupation'] ?? 'N/A') . '</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-danger"><i class="fas fa-female me-2"></i>Mother Details</h6>
                            <div class="row mb-2">
                                <div class="col-4"><strong>Name:</strong></div>
                                <div class="col-8">' . safe_htmlspecialchars($enquiry['mother_name'] ?? 'N/A') . '</div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-4"><strong>Occupation:</strong></div>
                                <div class="col-8">' . safe_htmlspecialchars($enquiry['mother_occupation'] ?? 'N/A') . '</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Application Information -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0"><i class="fas fa-calendar me-2"></i>Application Information</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="row mb-2">
                                <div class="col-4"><strong>Application ID:</strong></div>
                                <div class="col-8">
                                    <span class="badge bg-secondary">#' . str_pad($enquiry['id'], 6, '0', STR_PAD_LEFT) . '</span>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-4"><strong>Submitted On:</strong></div>
                                <div class="col-8">' . $formatted_created . '</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="row mb-2">
                                <div class="col-4"><strong>Status:</strong></div>
                                <div class="col-8">
                                    <span class="badge bg-warning">Pending Review</span>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-4"><strong>Days Pending:</strong></div>
                                <div class="col-8">';
    
    $created_date = new DateTime($enquiry['created_at']);
    $current_date = new DateTime();
    $days_pending = $current_date->diff($created_date)->days;
    
    $html .= '<span class="badge bg-' . ($days_pending > 7 ? 'danger' : ($days_pending > 3 ? 'warning' : 'success')) . '">' . $days_pending . ' days</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>';
    
    // Return success response
    echo json_encode([
        'success' => true,
        'html' => $html,
        'message' => 'Enquiry fetched successfully!',
        'enquiry_data' => $enquiry
    ]);
    
} catch (PDOException $e) {
    error_log("Database error in get enquiry details: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Database error occurred while fetching enquiry details.'
    ]);
} catch (Exception $e) {
    error_log("General error in get enquiry details: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'An unexpected error occurred while processing the request.'
    ]);
}
?>