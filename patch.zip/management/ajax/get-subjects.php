<?php
require_once("../../includes/db.php");

header('Content-Type: application/json');

if (isset($_GET['class_id'])) {
    $class_id = (int)$_GET['class_id'];
    $stmt = $pdo->prepare("SELECT id, subject_name FROM subjects WHERE class_id = ?");
    $stmt->execute([$class_id]);
    $subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($subjects);
} else {
    echo json_encode([]);
}
?>