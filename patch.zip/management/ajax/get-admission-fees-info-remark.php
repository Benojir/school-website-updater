<?php
require_once("../../includes/config.php");
header('Content-Type: application/json');

$student_id = $_REQUEST['student_id'] ?? '';

if (empty($student_id)) {
    echo json_encode(['success' => false, 'message' => 'Required fields are missing']);
    exit;
}

try {
    // Fetch all unpaid fees for the student
    $stmt = $pdo->prepare("SELECT * FROM admission_unpaid_fees WHERE student_id = ?");
    $stmt->execute([$student_id]);
    // Use fetchAll() to get all rows as an array of arrays
    $admission_fees_info = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($admission_fees_info)) { // Check if the array is empty
        throw new Exception('No admission fees information found. Maybe the student admission fees are already cleared?');
    }

    $total_unpaid_amount = 0;
    $unpaid_amount_info = [];

    // Prepare the class name query once before the loop for efficiency
    $class_stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");

    // Now the foreach loop will work correctly
    foreach ($admission_fees_info as $admission_fee) {
        $total_unpaid_amount += $admission_fee['unpaid_amount'];
        $academic_year = $admission_fee['academic_year'];
        $class_id = $admission_fee['class_id'];
        
        // Safely execute the prepared statement inside the loop
        $class_stmt->execute([$class_id]);
        $class_name = $class_stmt->fetchColumn();

        $unpaid_amount_info[] = "Unpaid " . $websiteConfig['currency_symbol'] . number_format($admission_fee['unpaid_amount'], 2) . " for " . htmlspecialchars($class_name) . " (" . htmlspecialchars($academic_year) . ")";
    }

    $remark = "Admission Fees: " . implode(", ", $unpaid_amount_info) . ". <br>Total Unpaid Amount: <b>" . $websiteConfig['currency_symbol'] . number_format($total_unpaid_amount, 2) . "</b>";

    echo json_encode([
        'success' => true,
        'message' => $remark
    ]);
    exit;

} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database Error: ' . $e->getMessage()
    ]);
    exit;
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
    exit;
}