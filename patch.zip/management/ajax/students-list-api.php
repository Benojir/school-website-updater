<?php
require_once("../../includes/db.php");

// Initialize filter variables
$search = trim($_GET['search'] ?? '');
$class_filter = isset($_GET['class']) ? (int)$_GET['class'] : '';
$section_filter = isset($_GET['section']) ? (int)$_GET['section'] : '';
$gender_filter = isset($_GET['gender']) ? $_GET['gender'] : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$fee_status_filter = isset($_GET['fee_status']) ? $_GET['fee_status'] : '';
$hosteler_filter = isset($_GET['hosteler']) ? $_GET['hosteler'] : '';
$car_route_filter = isset($_GET['car_route']) ? $_GET['car_route'] : '';

// This page will only respond to AJAX requests
header('Content-Type: application/json');

// Pagination configuration
$per_page = 1000;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) {
    $page = 1;
}
$offset = ($page - 1) * $per_page;

// Base query with fee status consideration
// Replace the fee status related queries with this new implementation:
if (!empty($fee_status_filter)) {
    // New query that works with the current system
    $query = "
    SELECT s.*, c.class_name, sec.section_name,
           COALESCE((
               SELECT SUM(total_paid_amount) 
               FROM student_full_paid_fees 
               WHERE student_id = s.student_id
           ), 0) as paid_amount,
           COALESCE((
               SELECT SUM(unpaid_amount) 
               FROM student_unpaid_fees 
               WHERE student_id = s.student_id
           ), 0) as unpaid_amount
    FROM students s
    LEFT JOIN classes c ON s.class_id = c.id
    LEFT JOIN sections sec ON s.section_id = sec.id
    ";
} else {
    $query = "
    SELECT s.*, c.class_name, sec.section_name
    FROM students s
    LEFT JOIN classes c ON s.class_id = c.id
    LEFT JOIN sections sec ON s.section_id = sec.id
    ";
}

// Where conditions
$where = [];
$params = [];

if (!empty($search)) {
    $where[] = "(s.student_id LIKE :search_id 
            OR s.name LIKE :search_name
            OR s.father_name LIKE :search_father
            OR s.mother_name LIKE :search_mother)";
    $params[':search_id'] = "%$search%";
    $params[':search_name'] = "%$search%";
    $params[':search_father'] = "%$search%";
    $params[':search_mother'] = "%$search%";
}

if (!empty($class_filter)) {
    $where[] = "s.class_id = :class_id";
    $params[':class_id'] = $class_filter;
}

if (!empty($section_filter)) {
    $where[] = "s.section_id = :section_id";
    $params[':section_id'] = $section_filter;
}

if (!empty($gender_filter)) {
    $where[] = "s.gender = :gender";
    $params[':gender'] = $gender_filter;
}

if (!empty($status_filter)) {
    $where[] = "s.status = :status";
    $params[':status'] = $status_filter;
}

if ($hosteler_filter !== '') {
    $where[] = "s.is_hosteler = :is_hosteler";
    $params[':is_hosteler'] = (int)$hosteler_filter;
}

if ($car_route_filter === 'has_route') {
    $where[] = "s.car_route IS NOT NULL AND s.car_route != ''";
} elseif ($car_route_filter === 'no_route') {
    $where[] = "(s.car_route IS NULL OR s.car_route = '')";
}

// Fee status conditions
// Update the fee status conditions to work with the new system
if (!empty($fee_status_filter)) {
    if ($fee_status_filter === 'paid') {
        $where[] = "EXISTS (SELECT 1 FROM student_full_paid_fees WHERE student_id = s.student_id)";
    } elseif ($fee_status_filter === 'unpaid') {
        $where[] = "EXISTS (SELECT 1 FROM student_unpaid_fees WHERE student_id = s.student_id)";
    } elseif ($fee_status_filter === 'fully_paid') {
        $where[] = "NOT EXISTS (SELECT 1 FROM student_unpaid_fees WHERE student_id = s.student_id)";
    }
}

// Add WHERE clause if needed
if (!empty($where)) {
    $query .= " WHERE " . implode(" AND ", $where);
}

// Group by if using fee status
if (!empty($fee_status_filter)) {
    $query .= " GROUP BY s.id";
}

// Count total records for pagination
// Replace the count query with:
$count_query = "SELECT COUNT(DISTINCT s.id) FROM students s";
if (!empty($fee_status_filter)) {
    $count_query .= " 
    LEFT JOIN student_full_paid_fees f ON s.student_id = f.student_id
    LEFT JOIN student_unpaid_fees u ON s.student_id = u.student_id";
}
$count_query .= " LEFT JOIN classes c ON s.class_id = c.id";
$count_query .= " LEFT JOIN sections sec ON s.section_id = sec.id";

if (!empty($where)) {
    $count_query .= " WHERE " . implode(" AND ", $where);
}

$count_stmt = $pdo->prepare($count_query);
foreach ($params as $key => $val) {
    $count_stmt->bindValue($key, $val);
}
$count_stmt->execute();
$total_students = $count_stmt->fetchColumn();
$total_pages = ceil($total_students / $per_page);

// Add sorting and pagination
$query .= " ORDER BY s.id DESC LIMIT :limit OFFSET :offset";
$params[':limit'] = $per_page;
$params[':offset'] = $offset;

// Execute query and fetch students
$stmt = $pdo->prepare($query);
foreach ($params as $key => &$val) {
    if ($key === ':limit' || $key === ':offset') {
        $stmt->bindParam($key, $val, PDO::PARAM_INT);
    } else {
        $stmt->bindParam($key, $val);
    }
}
$stmt->execute();
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Prepare response
$response = [
    'success' => true,
    'students' => $students,
    'total_students' => $total_students,
    'total_pages' => $total_pages,
    'current_page' => $page,
    'classes' => $pdo->query("SELECT * FROM classes ORDER BY class_name")->fetchAll(),
    'sections' => $pdo->query("SELECT s.id, s.section_name, c.class_name FROM sections s JOIN classes c ON s.class_id = c.id ORDER BY c.class_name, s.section_name")->fetchAll(),
    'exams' => $pdo->query("SELECT * FROM exams WHERE status = 'active' ORDER BY exam_date DESC")->fetchAll(),
    'admit_cards' => $pdo->query("SELECT ea.id, e.exam_name, c.class_name FROM exam_admit_releases ea JOIN exams e ON ea.exam_id = e.id JOIN classes c ON ea.class_id = c.id WHERE ea.status = 'released' ORDER BY e.exam_date DESC")->fetchAll()
];

echo json_encode($response);
exit;
