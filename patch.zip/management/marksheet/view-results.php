<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage Student Results - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_RESULTS)) {
    include_once("../../includes/permission-denied.php");
}


// Check if student ID is provided
if (!isset($_GET['student_id'])) {
    die("Student ID not provided.");
}

$student_id = $_GET['student_id'];

// Get student details
$stmt = $pdo->prepare("
    SELECT s.*, c.class_name as class, sec.section_name as section 
    FROM students s
    LEFT JOIN classes c ON s.class_id = c.id
    LEFT JOIN sections sec ON s.section_id = sec.id
    WHERE s.student_id = ?
");
$stmt->execute([$student_id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    die("Student not found.");
}

// Get all exams with results for this student
$stmt = $pdo->prepare("
    SELECT 
        e.id as exam_id, 
        e.exam_name, 
        e.exam_date,
        r.id as result_id,
        r.class_id,
        c.class_name,
        r.percentage, 
        r.grade,
        (SELECT COUNT(*) FROM results WHERE exam_id = e.id AND class_id = r.class_id) as total_students
    FROM exams e
    JOIN results r ON e.id = r.exam_id
    JOIN classes c ON r.class_id = c.id
    WHERE r.student_id = ?
    ORDER BY r.class_id DESC, e.exam_date DESC
");
$stmt->execute([$student_id]);
$exams = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container mt-4">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h3><i class="fas fa-chart-line"></i> Academic Results</h3>
        </div>
        <div class="card-body">
            <div class="row mb-4">
                <div class="col-md-8">
                    <h4><?= safe_htmlspecialchars($student['name']) ?></h4>
                    <p class="mb-1">ID: <?= safe_htmlspecialchars($student['student_id']) ?></p>
                    <p class="mb-1">Current Class: <?= safe_htmlspecialchars($student['class']) ?> - <?= safe_htmlspecialchars($student['section']) ?></p>
                </div>
                <div class="col-md-4 text-md-end">
                    <a href="../marksheet/students-mark-entry.php?student_ids=<?= urlencode($student_id) ?>" class="btn btn-success">
                        <i class="fas fa-plus"></i> Add New Result
                    </a>
                </div>
            </div>

            <?php if (count($exams) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th>Class</th>
                                <th>Exam</th>
                                <th>Date</th>
                                <th>Percentage</th>
                                <th>Grade</th>
                                <th>Position</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $current_class = null;
                            foreach ($exams as $exam): 
                                if ($current_class !== $exam['class_id']): 
                                    $current_class = $exam['class_id'];
                            ?>
                                <tr class="table-active">
                                    <td colspan="7" class="fw-bold">
                                        Class <?= safe_htmlspecialchars($exam['class_name']) ?>
                                    </td>
                                </tr>
                                <?php endif; ?>
                                <tr>
                                    <td><?= safe_htmlspecialchars($exam['class_name']) ?></td>
                                    <td><?= safe_htmlspecialchars($exam['exam_name']) ?></td>
                                    <td><?= safe_htmlspecialchars($exam['exam_date']) ?></td>
                                    <td><?= number_format($exam['percentage'], 2) ?>%</td>
                                    <td>
                                        <span class="badge bg-<?= $exam['grade'] === 'F' ? 'danger' : 'success' ?>">
                                            <?= safe_htmlspecialchars($exam['grade']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?= '-' ?>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <a href="../../api/download/download-marksheet.php?result_id=<?= $exam['result_id'] ?>" 
                                               class="btn btn-sm btn-primary" title="Download Marksheet">
                                                <i class="fas fa-download"></i>
                                            </a>
                                            <a href="../marksheet/students-mark-entry.php?student_ids=<?= $student_id;?>" 
                                               class="btn btn-sm btn-warning" title="Edit Result">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <button class="btn btn-sm btn-danger delete-result" 
                                                    data-result-id="<?= $exam['result_id'] ?>" 
                                                    title="Delete Result">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> No results found for this student.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this result? This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDelete">Delete</button>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Delete result handler
    let resultIdToDelete = null;
    
    $('.delete-result').click(function() {
        resultIdToDelete = $(this).data('result-id');
        $('#deleteModal').modal('show');
    });
    
    $('#confirmDelete').click(function() {
        if (!resultIdToDelete) return;
        
        $.ajax({
            url: '../../api/admin/delete/marksheet/delete-result.php',
            type: 'POST',
            data: { result_id: resultIdToDelete },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                    setTimeout(function() {
                        window.location.reload();
                    }, 1000);
                } else {
                    toastr.error(response.message);
                }
            },
            error: function(xhr) {
                toastr.error('Error: ' + xhr.statusText);
            },
            complete: function() {
                $('#deleteModal').modal('hide');
            }
        });
    });
});
</script>

<?php include_once("../../includes/body-close.php"); ?>