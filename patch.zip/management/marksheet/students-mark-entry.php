<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Add Results - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_RESULTS)) {
    include_once("../../includes/permission-denied.php");
}

// Get student IDs from URL
$student_ids_str = $_GET['student_ids'] ?? '';
if (empty($student_ids_str)) {
    die("No students selected");
}

$student_ids = explode(',', $student_ids_str);

// Fetch students data
$placeholders = implode(',', array_fill(0, count($student_ids), '?'));
$stmt = $pdo->prepare("
    SELECT s.*, c.class_name, sec.section_name 
    FROM students s
    LEFT JOIN classes c ON s.class_id = c.id
    LEFT JOIN sections sec ON s.section_id = sec.id
    WHERE s.student_id IN ($placeholders) AND s.status = 'Active'
    ORDER BY s.roll_no ASC
");
$stmt->execute($student_ids);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($students)) {
    die("<script>toastr.error('No students found');</script>");
}

// Verify all students are from the same class
$class_ids = array_unique(array_column($students, 'class_id'));
if (count($class_ids) > 1) {
    die("Selected students must be from the same class");
}

$class_id = $class_ids[0];
$class_name = $students[0]['class_name'];

// Fetch active exams
$stmt = $pdo->prepare("
    SELECT * FROM exams 
    WHERE status = 'active'
    ORDER BY exam_date DESC
");
$stmt->execute();
$exams = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch subjects for the class
$stmt = $pdo->prepare("
    SELECT * FROM subjects 
    WHERE class_id = ? AND exclude_from_marksheet = 0
    ORDER BY mark_entry_order_by ASC
");
$stmt->execute([$class_id]);
$subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
    .is-invalid {
        border: 1px solid #dc3545;
    }

    .is-invalid:focus {
        border-color: #dc3545;
        box-shadow: 0 0 0 0.25rem rgba(220, 53, 69, 0.25);
    }

    table,
    th,
    td {
        text-align: center;
        /* Horizontal centering */
        vertical-align: middle;
        /* Vertical centering */
    }

    /* Chrome, Safari, Edge, Opera */
    input[type=number]::-webkit-outer-spin-button,
    input[type=number]::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    /* Firefox */
    input[type=number] {
        appearance: textfield;
    }

    .checkbox-container {
        display: flex;
        align-items: center;
        gap: 5px;
    }

    .table-responsive {
        max-height: 75vh;
        /* Takes up 75% of the screen height */
        overflow-y: auto;
        /* Enables vertical scrolling within the table */
        border-bottom: 2px solid #dee2e6;
        /* Visual separation at bottom */
    }

    /* 2. Stick the header */
    thead th {
        position: sticky;
        top: 0;
        z-index: 100;
        /* Ensure it floats above input fields */

        /* 3. Opaque Background is REQUIRED */
        /* Since you use .table-dark, we match that color (#212529) */
        background-color: #212529 !important;
        color: white;

        /* Optional: Small shadow to separate header from body */
        box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);
    }
</style>

<div class="container-fluid mt-4">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h3><i class="fas fa-plus-circle"></i> Students Mark Entry</h3>
        </div>
        <div class="card-body">
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> You are adding results for <?= count($students) ?> students from <b>(<?= safe_htmlspecialchars($class_name) ?>)</b>.
            </div>
            <div class="alert alert-dismissible fade show" role="alert" id="responseAlert" style="display: none;"></div>

            <form id="bulkResultForm">
                <input type="hidden" name="class_id" value="<?= safe_htmlspecialchars($class_id) ?>">

                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <div class="mb-3">
                                <label for="exam_id" class="form-label">Exam</label>
                                <select class="form-select" id="exam_id" name="exam_id" required>
                                    <option value="">-- Select Exam --</option>
                                    <?php foreach ($exams as $exam): ?>
                                        <option value="<?= $exam['id'] ?>">
                                            <?= safe_htmlspecialchars($exam['exam_name']) ?> (<?= safe_htmlspecialchars($exam['exam_date']) ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div>
                                <label for="student_sort_by" class="form-label">Sort by</label>
                                <select class="form-select" id="student_sort_by" name="student_sort_by" required>
                                    <option value="roll_low_high">Roll (Low to High)</option>
                                    <option value="roll_high_low">Roll (High to Low)</option>
                                    <option value="name_az">Name (A-Z)</option>
                                    <option value="name_za">Name (Z-A)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label for="subject_filter" class="form-label">Subjects to Include</label>
                        <div class="input-group">
                            <select class="form-select" size="5" id="subject_filter" multiple>
                                <option value="all" selected>All Subjects</option>
                                <?php foreach ($subjects as $subject): ?>
                                    <option value="<?= $subject['id'] ?>"><?= safe_htmlspecialchars($subject['subject_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="button" class="btn btn-outline-secondary" id="btnOpenReorder" title="Rearrange Columns">
                                <i class="fas fa-sort"></i> Sort
                            </button>
                        </div>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead class="table-dark">
                            <tr>
                                <th>Student</th>
                                <th>Class</th>
                                <th>Section</th>
                                <th>Roll No</th>
                                <?php foreach ($subjects as $subject): ?>
                                    <th class="subject-col" data-subject-id="<?= $subject['id'] ?>">
                                        <?= safe_htmlspecialchars($subject['subject_name']) ?>
                                        <br>
                                        <span style="color:rgb(136, 189, 250);" id="id-<?= safe_htmlspecialchars($subject['id']) ?>"></span>
                                        <input type="hidden" name="subjects[<?= $subject['id'] ?>][subject_id]" value="<?= $subject['id'] ?>">
                                        <input type="hidden" name="subjects[<?= $subject['id'] ?>][subject_name]" value="<?= safe_htmlspecialchars($subject['subject_name']) ?>">
                                    </th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students as $student): ?>
                                <tr data-name="<?= safe_htmlspecialchars(strtolower($student['name'])) ?>" data-roll="<?= (int)$student['roll_no'] ?>">
                                    <td>
                                        <?= safe_htmlspecialchars($student['name']) ?>
                                        <input type="hidden" name="students[<?= $student['student_id'] ?>][student_id]" value="<?= $student['student_id'] ?>">
                                        <input type="hidden" name="students[<?= $student['student_id'] ?>][name]" value="<?= safe_htmlspecialchars($student['name']) ?>">
                                    </td>
                                    <td><?= safe_htmlspecialchars($student['class_name']) ?></td>
                                    <td><?= safe_htmlspecialchars($student['section_name']) ?></td>
                                    <td><?= safe_htmlspecialchars($student['roll_no']) ?></td>

                                    <?php foreach ($subjects as $subject): ?>
                                        <td class="subject-col" data-subject-id="<?= $subject['id'] ?>">
                                            <div class="row g-2">
                                                <div class="col-12 col-md-6 checkbox-container" style="text-align: left;">
                                                    <input type="checkbox" id="absent[<?= $student['student_id'] ?>][<?= $subject['id'] ?>]" name="absent[<?= $student['student_id'] ?>][<?= $subject['id'] ?>]" value="1" tabindex="-1">
                                                    <label class="small" for="absent[<?= $student['student_id'] ?>][<?= $subject['id'] ?>]">Absent</label>
                                                </div>
                                                <div class="col-12 col-md-6 checkbox-container" style="text-align: left;">
                                                    <input type="checkbox" id="exclude[<?= $student['student_id'] ?>][<?= $subject['id'] ?>]" name="exclude[<?= $student['student_id'] ?>][<?= $subject['id'] ?>]" value="1" tabindex="-1">
                                                    <label class="small" for="exclude[<?= $student['student_id'] ?>][<?= $subject['id'] ?>]">Exclude</label>
                                                </div>

                                                <input type="hidden" class="form-control"
                                                    name="minor_subject[<?= $student['student_id'] ?>][<?= $subject['id'] ?>]"
                                                    value="<?= (strtolower($subject['subject_type']) == 'minor') ? '1' : '0' ?>"
                                                    required readonly tabindex="-1">

                                                <input type="hidden" class="form-control total-marks"
                                                    name="students[<?= $student['student_id'] ?>][subjects][<?= $subject['id'] ?>][total_marks]"
                                                    min="0" step="0.01" required readonly tabindex="-1">

                                                <div class="col-12" style="text-align: left;">
                                                    <label class="small">Written</label>
                                                    <input type="text" class="form-control theory-marks"
                                                        name="students[<?= $student['student_id'] ?>][subjects][<?= $subject['id'] ?>][theory_marks]"
                                                        min="0" step="0.01" />
                                                </div>
                                                <div class="col-12" style="text-align: left;">
                                                    <label class="small">Oral</label>
                                                    <input type="text" class="form-control practical-marks"
                                                        name="students[<?= $student['student_id'] ?>][subjects][<?= $subject['id'] ?>][practical_marks]"
                                                        min="0" step="0.01" />
                                                </div>
                                                <div class="col-12" style="text-align: left;">
                                                    <label class="small">Obtained</label>
                                                    <input type="text" class="form-control obtained-marks"
                                                        name="students[<?= $student['student_id'] ?>][subjects][<?= $subject['id'] ?>][obtained_marks]"
                                                        min="0" step="0.01" readonly tabindex="-1">
                                                </div>
                                            </div>
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="text-center mt-4">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save All Results
                    </button>
                    <a href="../student/list-students.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="reorderModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Rearrange Subject Columns</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="small text-muted">Click Up/Down to change the order.</p>
                <ul class="list-group" id="sortableSubjects">
                </ul>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="btnApplyOrder">Apply Order</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

        const studentIds = <?= json_encode(array_values($student_ids)); ?>;

        $('.table-responsive').hide();

        $('body').on('input', 'input.theory-marks, input.practical-marks', function() {
            let original = $(this).val();
            let noSpaces = original.replace(/\s/g, '');

            // Updated Regex: Allows digits and an optional decimal point
            let isValid = /^\d*\.?\d*$/.test(noSpaces);

            $(this).toggleClass('is-invalid', !isValid);
            $(this).val(noSpaces);
        });

        $('#subject_filter').select({
            placeholder: "Select subjects to show",
            allowClear: true
        });

        $('#subject_filter').on('change', function() {
            const selected = $(this).val();
            if (selected && selected.includes('all')) {
                $('.subject-col').show();
            } else if (selected && selected.length > 0) {
                $('.subject-col').hide();
                selected.forEach(subjectId => {
                    $(`.subject-col[data-subject-id="${subjectId}"]`).show();
                });
            } else {
                $('.subject-col').show();
            }
        });

        $('#exam_id').change(function() {
            const examId = $(this).val();
            if (!examId) {
                $('.table-responsive').hide();
                return;
            } else {
                $('.table-responsive').show();
            }

            const submitBtn = $('#bulkResultForm').find('[type="submit"]');
            const originalText = submitBtn.html();
            submitBtn.prop('disabled', true).html(
                '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Loading exam data...'
            );

            showLoadingAlert("Please wait...", "Loading exam data...");

            $.when(
                $.ajax({
                    url: '../../api/admin/get/exam/get-exam-routine.php',
                    type: 'GET',
                    data: {
                        exam_id: examId,
                        class_id: <?= $class_id ?>
                    },
                    dataType: 'json'
                }),
                $.ajax({
                    url: '../../api/admin/get/exam/get-existing-results.php',
                    type: 'GET',
                    data: {
                        exam_id: examId,
                        class_id: <?= $class_id ?>
                    },
                    dataType: 'json'
                }),
                $.ajax({
                    url: '../../api/admin/get/exam/get-first-exam-status.php',
                    type: 'GET',
                    data: {
                        student_ids: studentIds,
                        class_id: <?= $class_id ?>
                    },
                    dataType: 'json'
                })
            ).then(function(routineResponse, resultsResponse, firstExamStatusResponse) {
                Swal.close();
                // Handle routine data
                if (routineResponse[0].success && routineResponse[0].data.length == <?= count($subjects) ?>) {
                    window.subjectMarksData = {};
                    let errorMessageIfHave = null;
                    routineResponse[0].data.forEach(subject => {
                        let theoryMarks = parseFloat(subject.theory_marks) || 0;
                        let practicalMarks = parseFloat(subject.practical_marks) || 0;
                        let totalMarks = theoryMarks + practicalMarks;
                        if (totalMarks <= 0) {
                            errorMessageIfHave += `<li>${subject.subject_name} has not been assigned any marks</li>`;
                        }
                        $(`#id-${subject.subject_id}`).text(`(${totalMarks})`);
                        window.subjectMarksData[subject.subject_id] = {
                            theory_marks: subject.theory_marks,
                            practical_marks: subject.practical_marks
                        };
                        $(`input[name*="[${subject.subject_id}][total_marks]"]`).val(totalMarks);
                        $(`input[name*="[${subject.subject_id}][theory_marks]"]`).attr('max', subject.theory_marks);
                        $(`input[name*="[${subject.subject_id}][practical_marks]"]`).attr('max', subject.practical_marks);
                    });

                    if (errorMessageIfHave) {
                        Swal.fire({
                            icon: "error",
                            title: "Error",
                            html: `<ul>${errorMessageIfHave}</ul>`,
                            allowOutsideClick: false,
                            confirmButtonText: "Close",
                            customClass: {
                                confirmButton: "btn btn-danger px-4 py-2",
                                popup: "rounded-4 shadow-lg"
                            }
                        })
                    }
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Error",
                        text: `There are total <?= count($subjects) ?> subjects in the class. But ${routineResponse[0].data.length} subjects have been assigned marks.`,
                        allowOutsideClick: false,
                        confirmButtonText: "Check Routine",
                        allowEscapeKey: false,
                        customClass: {
                            confirmButton: "btn btn-primary px-4 py-2",
                            popup: "rounded-4 shadow-lg"
                        }
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = `../exam/list-exam-routines.php?exam_id=${examId}&class_id=<?= $class_id ?>`;
                        }
                    });
                }

                // Handle existing results
                if (resultsResponse[0].success && resultsResponse[0].data.length > 0) {
                    resultsResponse[0].data.forEach(result => {
                        const studentId = result.student_id;
                        result.subjects.forEach(subject => {
                            if (subject.theory_marks >= 0) $(`input[name*="[${studentId}][subjects][${subject.subject_id}][theory_marks]"]`).val(subject.theory_marks);
                            if (subject.practical_marks >= 0) $(`input[name*="[${studentId}][subjects][${subject.subject_id}][practical_marks]"]`).val(subject.practical_marks);
                            if (subject.obtained_marks >= 0) $(`input[name*="[${studentId}][subjects][${subject.subject_id}][obtained_marks]"]`).val(subject.obtained_marks);
                            if (subject.is_absent == 1) {
                                $(`input[name="absent[${studentId}][${subject.subject_id}]"]`).prop('checked', true);
                                $(`input[name*="[${studentId}][subjects][${subject.subject_id}][theory_marks]"]`).val(0).prop('disabled', true);
                                $(`input[name*="[${studentId}][subjects][${subject.subject_id}][practical_marks]"]`).val(0).prop('disabled', true);
                                $(`input[name*="[${studentId}][subjects][${subject.subject_id}][obtained_marks]"]`).val(0).prop('disabled', true);
                            }
                            if (subject.is_excluded == 1) {
                                $(`input[name="exclude[${studentId}][${subject.subject_id}]"]`).prop('checked', true);
                                $(`input[name*="[${studentId}][subjects][${subject.subject_id}][theory_marks]"]`).val(0).prop('disabled', true);
                                $(`input[name*="[${studentId}][subjects][${subject.subject_id}][practical_marks]"]`).val(0).prop('disabled', true);
                                $(`input[name*="[${studentId}][subjects][${subject.subject_id}][obtained_marks]"]`).val(0).prop('disabled', true);
                            }
                        });
                    });
                }

                // Logic to lock 'Exclude' checkboxes based on first exam status
                const selectedExamId = $('#exam_id').val();
                $('input[name^="exclude"]').prop('disabled', false); // Reset all first

                if (firstExamStatusResponse[0].success) {
                    const firstExamData = firstExamStatusResponse[0].data;
                    for (const studentId in firstExamData) {
                        const studentData = firstExamData[studentId];
                        if (studentData.first_exam_id && selectedExamId != studentData.first_exam_id) {
                            $(`input[name^="exclude[${studentId}]"]`).each(function() {
                                const $checkbox = $(this);
                                const name = $checkbox.attr('name');
                                const match = name.match(/\[(\d+)\]$/);
                                if (match) {
                                    const subjectId = match[1];
                                    let isExcludedInFirst = false;
                                    if (studentData.subjects && studentData.subjects[subjectId]) {
                                        isExcludedInFirst = (studentData.subjects[subjectId].is_excluded == '1');
                                    }
                                    $checkbox.prop('checked', isExcludedInFirst).prop('disabled', true);
                                }
                            });
                        }
                    }
                }

            }).fail(function(xhr) {
                toastr.error('Error loading data: ' + xhr.statusText);
            }).always(function() {
                submitBtn.prop('disabled', false).html(originalText);
            });
        });

        // Real-time validation for theory/practical marks
        $(document).on('input', '.theory-marks, .practical-marks', function() {
            if (!window.subjectMarksData) return;
            const subjectId = $(this).closest('[data-subject-id]').data('subject-id');
            const subjectData = window.subjectMarksData[subjectId];
            if (!subjectData) return;
            const fieldType = $(this).hasClass('theory-marks') ? 'theory' : 'practical';
            const maxValue = fieldType === 'theory' ? subjectData.theory_marks : subjectData.practical_marks;
            const currentValue = parseFloat($(this).val()) || 0;
            if (currentValue > maxValue) {
                $(this).css('background-color', '#FF7777');
                $('.theory-marks, .practical-marks').not(this).attr('readonly', true);
                toastr.warning(`${fieldType.charAt(0).toUpperCase() + fieldType.slice(1)} marks cannot exceed ${maxValue}`);
                Swal.fire({
                    icon: "error",
                    title: `${fieldType.charAt(0).toUpperCase() + fieldType.slice(1)} marks cannot exceed ${maxValue}`,
                    allowOutsideClick: false
                });
            } else {
                $(this).css('background-color', '');
                $('.theory-marks, .practical-marks').attr('readonly', false);
            }
            const row = $(this).closest('.row');
            const theory = parseFloat(row.find('.theory-marks').val()) || 0;
            const practical = parseFloat(row.find('.practical-marks').val()) || 0;
            row.find('.obtained-marks').val((theory + practical).toFixed(2));
        });

        // [MODIFIED] Handle absent and exclude checkbox functionality with the fix
        $(document).on('change', 'input[type="checkbox"][name^="absent"], input[type="checkbox"][name^="exclude"]', function() {
            const $td = $(this).closest('td');
            const $absentCheckbox = $td.find('input[type="checkbox"][name^="absent"]');
            const $excludeCheckbox = $td.find('input[type="checkbox"][name^="exclude"]');
            const markInputs = $td.find('.theory-marks, .practical-marks, .obtained-marks');

            // If the checkbox that was just changed is 'absent' and it's now checked...
            if ($(this).is($absentCheckbox) && $absentCheckbox.is(':checked')) {
                // ...only uncheck 'exclude' if it is NOT disabled. This is the fix.
                if (!$excludeCheckbox.is(':disabled')) {
                    $excludeCheckbox.prop('checked', false);
                }
            }
            // If the checkbox that was just changed is 'exclude' and it's now checked...
            else if ($(this).is($excludeCheckbox) && $excludeCheckbox.is(':checked')) {
                // ...always uncheck 'absent' as it can't be locked.
                $absentCheckbox.prop('checked', false);
            }

            // This part of the logic remains the same
            if ($absentCheckbox.is(':checked') || $excludeCheckbox.is(':checked')) {
                markInputs.val('0').prop('disabled', true);
            } else {
                markInputs.prop('disabled', false);
            }
        });


        // Replace your existing form submission code with this:
        $('#bulkResultForm').submit(async function(e) {
            e.preventDefault();

            // 1. Validate data first (keep your existing validation logic here)
            let isValid = true;
            // ... insert your existing validation loop here ...
            if (!isValid) return;

            const submitBtn = $(this).find('[type="submit"]');
            const originalText = submitBtn.html();
            submitBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span> Processing batches...');

            // 2. Collect all student IDs (rows)
            const studentRows = $('tbody tr').toArray();
            const batchSize = 10; // Send 10 students per request
            const totalBatches = Math.ceil(studentRows.length / batchSize);

            let successCount = 0;
            let errorCount = 0;

            // 3. Process in chunks
            for (let i = 0; i < totalBatches; i++) {
                const start = i * batchSize;
                const end = start + batchSize;
                const batchRows = studentRows.slice(start, end);

                // Update button text to show progress
                submitBtn.html(`<span class="spinner-border spinner-border-sm"></span> Saving batch ${i + 1} of ${totalBatches}...`);

                // Create a temporary FormData object for just this batch
                const formData = new FormData();

                // Add common fields (class_id, exam_id, etc.)
                formData.append('class_id', $('input[name="class_id"]').val());
                formData.append('exam_id', $('#exam_id').val());

                // Add Subject headers (needed for processing)
                $('input[name^="subjects["]').each(function() {
                    formData.append($(this).attr('name'), $(this).val());
                });

                // Add ONLY inputs for the students in this batch
                batchRows.forEach(row => {
                    $(row).find('input, select, textarea').each(function() {
                        // serialized name and value
                        if (this.type === 'checkbox') {
                            if (this.checked) formData.append(this.name, this.value);
                        } else {
                            formData.append(this.name, this.value);
                        }
                    });
                });

                // Send this batch
                try {
                    await $.ajax({
                        url: '../../api/admin/put/marksheet/process-students-mark-entry.php',
                        type: 'POST',
                        data: formData,
                        processData: false,
                        contentType: false
                    });
                    successCount++;
                } catch (error) {
                    console.error("Batch failed", error);
                    errorCount++;
                    toastr.error(`Batch ${i+1} failed to save.`);
                }
            }

            // 4. Final Cleanup
            submitBtn.prop('disabled', false).html(originalText);

            if (errorCount === 0) {
                // Swal.fire("Success", "All students saved successfully!", "success");
                showSuccessAlert(`All students saved successfully!`);
            } else {
                // Swal.fire("Warning", `Saved with errors. ${errorCount} batches failed. Check console.`, "warning");
                showWarningAlert(`Saved with errors. ${errorCount} batches failed. Check console.`);
            }
        });

        // --- START: Subject Reordering Logic ---

        // 1. Open Modal and Populate List
        $('#btnOpenReorder').click(function() {
            const list = $('#sortableSubjects');
            list.empty();

            // Get current order from the table headers
            $('table thead th.subject-col').each(function() {
                const id = $(this).data('subject-id');
                // Find the subject name (cleaned of extra spaces/newlines)
                let name = $(this).clone().children().remove().end().text().trim();

                list.append(`
                <li class="list-group-item d-flex justify-content-between align-items-center" data-subject-id="${id}">
                    ${name}
                    <div class="btn-group btn-group-sm">
                        <button type="button" class="btn btn-outline-secondary move-up"><i class="fas fa-arrow-up"></i></button>
                        <button type="button" class="btn btn-outline-secondary move-down"><i class="fas fa-arrow-down"></i></button>
                    </div>
                </li>
            `);
            });

            new bootstrap.Modal(document.getElementById('reorderModal')).show();
        });

        // 2. Handle Up/Down Clicks in Modal
        $(document).on('click', '.move-up', function() {
            const current = $(this).closest('li');
            const prev = current.prev();
            if (prev.length !== 0) {
                current.insertBefore(prev);
            }
        });

        $(document).on('click', '.move-down', function() {
            const current = $(this).closest('li');
            const next = current.next();
            if (next.length !== 0) {
                current.insertAfter(next);
            }
        });

        // 3. Apply New Order to Table AND Save to DB
        $('#btnApplyOrder').click(function() {
            const $btn = $(this);
            const originalText = $btn.html();

            // 1. Gather the new order of IDs
            const newOrderIds = [];
            $('#sortableSubjects li').each(function() {
                newOrderIds.push($(this).data('subject-id'));
            });

            // 2. Disable button to prevent double clicks
            $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span> Saving...');

            // 3. Send to Backend
            $.ajax({
                url: '../../api/admin/put/subject/save-subject-order-for-markentry.php',
                type: 'POST',
                data: {
                    subject_order: newOrderIds
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // A. Apply Client-Side Visual Changes (Your existing logic)
                        const $headerRow = $('table thead tr');
                        newOrderIds.forEach(id => {
                            const $th = $headerRow.find(`th[data-subject-id="${id}"]`);
                            $headerRow.append($th);
                        });

                        $('table tbody tr').each(function() {
                            const $row = $(this);
                            newOrderIds.forEach(id => {
                                const $td = $row.find(`td[data-subject-id="${id}"]`);
                                $row.append($td);
                            });
                        });

                        // B. Close Modal and Notify
                        bootstrap.Modal.getInstance(document.getElementById('reorderModal')).hide();
                        toastr.success('Order saved permanently!');
                    } else {
                        toastr.error(response.message || 'Failed to save order.');
                    }
                },
                error: function(xhr) {
                    toastr.error('Server error while saving order.');
                    console.error(xhr);
                },
                complete: function() {
                    $btn.prop('disabled', false).html(originalText);
                }
            });
        });

        // --- END: Subject Reordering Logic ---

        // --- START: Client-Side Sorting Logic ---
        $('#student_sort_by').on('change', function() {
            const sortBy = $(this).val();
            const $tbody = $('table tbody');
            // Get all rows as an array of DOM elements
            const rows = $tbody.find('tr').toArray();

            // Sort the rows based on the data attributes we added
            rows.sort(function(a, b) {
                const nameA = $(a).data('name');
                const nameB = $(b).data('name');
                const rollA = parseInt($(a).data('roll')) || 0;
                const rollB = parseInt($(b).data('roll')) || 0;

                switch (sortBy) {
                    case 'name_az':
                        return nameA.localeCompare(nameB);
                    case 'name_za':
                        return nameB.localeCompare(nameA);
                    case 'roll_low_high':
                        return rollA - rollB;
                    case 'roll_high_low':
                        return rollB - rollA;
                    default:
                        return 0;
                }
            });

            // Append the sorted rows back to the body.
            // This moves the existing elements (preserving input values) rather than recreating them.
            $.each(rows, function(index, row) {
                $tbody.append(row);
            });

            toastr.info('List re-sorted');
        });
        // --- END: Client-Side Sorting Logic ---

        $('input').focus(function() {
            $(this).closest('tr').addClass('table-active'); // Bootstrap highlight class
        }).blur(function() {
            $(this).closest('tr').removeClass('table-active');
        });

        // Auto-select value when clicking or tabbing into the input
        $(document).on('focus', '.theory-marks, .practical-marks', function() {
            var $this = $(this);

            // Select the text
            $this.select();

            // Workaround for Chrome/Safari:
            // Prevent the mouseup event from immediately deselecting the text
            // We use .one() so this only happens the first time you click in
            $this.one('mouseup', function(e) {
                e.preventDefault();
                $this.select();
            });
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>