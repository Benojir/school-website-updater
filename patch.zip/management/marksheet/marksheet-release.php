<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Manage Marksheet Releases - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_RESULTS)) {
    include_once("../../includes/permission-denied.php");
}

// Get all exams and classes
$exams = $pdo->query("SELECT * FROM exams WHERE status = 'active' ORDER BY exam_date DESC")->fetchAll();
$classes = $pdo->query("SELECT * FROM classes ORDER BY class_name")->fetchAll();

// Mark expired releases (moved to AJAX handler)
$currentDateTime = date('Y-m-d H:i:s');
$twoMonthsAgo = date('Y-m-d H:i:s', strtotime('-2 months'));
$pdo->exec("
    UPDATE exam_admit_releases 
    SET status = 'expired' 
    WHERE status != 'expired' 
    AND release_date < '$twoMonthsAgo'
");
?>

<style>
    .table-responsive {
        overflow-x: unset !important;
    }
    .action-dropdown .dropdown-menu {
        min-width: 200px;
    }
</style>

<div class="container py-4">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fa-solid fa-square-poll-horizontal me-2"></i> Marksheet Release Management</h3>
            </div>
        </div>
        
        <div class="card-body">
            <div class="row">
                <div class="col-lg-6">
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h4 class="mb-0"><i class="fas fa-cog me-2"></i> Configure Release</h4>
                        </div>
                        <div class="card-body">
                            <form id="releaseForm" method="POST">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Exam</label>
                                    <select name="exam_id" class="form-select" required>
                                        <option value="" selected disabled>Select Exam</option>
                                        <?php foreach ($exams as $exam): ?>
                                            <option value="<?= $exam['id'] ?>">
                                                <?= safe_htmlspecialchars($exam['exam_name']) ?> 
                                                (<?= date('M d, Y', strtotime($exam['exam_date'])) ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Class</label>
                                    <select name="class_id" class="form-select" required>
                                        <option value="" selected disabled>Select Class</option>
                                        <?php foreach ($classes as $class): ?>
                                            <option value="<?= $class['id'] ?>">
                                                <?= safe_htmlspecialchars($class['class_name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Release Date & Time</label>
                                    <input type="date" name="release_date" class="form-control" required>
                                </div>
                                
                                <div class="text-end">
                                    <button type="submit" id="submitBtn" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i> Release Now
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <div class="d-flex justify-content-between align-items-center">
                                <h4 class="mb-0"><i class="fas fa-list me-2"></i> Current Releases</h4>
                                <button id="refreshReleases" class="btn btn-light btn-sm">
                                    <i class="fas fa-sync-alt me-1"></i> Refresh
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover align-middle">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Exam</th>
                                            <th>Class</th>
                                            <th>Release Date</th>
                                            <th>Status</th>
                                            <th class="text-end">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="releasesTableBody">
                                        <!-- AJAX will load content here -->
                                    </tbody>
                                </table>
                            </div>
                            
                            <nav aria-label="Page navigation">
                                <ul class="pagination justify-content-center" id="paginationContainer">
                                    <!-- AJAX will load pagination here -->
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    let currentPage = 1;
    const itemsPerPage = 10;
    
    // Load releases with AJAX
    function loadReleases(page = 1) {
        currentPage = page;
        $.ajax({
            url: '../../api/admin/get/marksheet/get-marksheet-releases.php',
            type: 'GET',
            data: {
                page: page,
                limit: itemsPerPage
            },
            dataType: 'json',
            beforeSend: function() {
                $('#releasesTableBody').html(`
                    <tr>
                        <td colspan="5" class="text-center py-4">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </td>
                    </tr>
                `);
            },
            success: function(response) {
                if (response.releases.length > 0) {
                    let html = '';
                    response.releases.forEach((release) => {
                        html += `
                            <tr id="release-${release.id}">
                                <td>${escapeHtml(release.exam_name)}</td>
                                <td>${escapeHtml(release.class_name)}</td>
                                <td>${formatDateTime(release.release_date)}</td>
                                <td>
                                    <span class="badge ${getStatusBadgeClass(release.status)}">
                                        ${capitalizeFirstLetter(release.status)}
                                    </span>
                                </td>
                                <td class="text-end">
                                    <div class="dropdown">
                                        <button title="Delete Marksheet Release" class="btn btn-sm btn-danger delete-btn"  type="button" data-id="${release.id}">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `;
                    });
                    $('#releasesTableBody').html(html);
                } else {
                    $('#releasesTableBody').html(`
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">
                                <i class="fas fa-id-card fa-3x mb-3"></i>
                                <h4>No marksheet releases found</h4>
                                <p>Configure a release to get started</p>
                            </td>
                        </tr>
                    `);
                }
                
                // Update pagination
                updatePagination(response.total, page);
            },
            error: function() {
                toastr.error('Failed to load admit card releases. Please try again.');
            }
        });
    }
    
    // Update pagination
    function updatePagination(totalRecords, currentPage) {
        const totalPages = Math.ceil(totalRecords / itemsPerPage);
        let html = '';
        
        if (totalPages > 1) {
            if (currentPage > 1) {
                html += `
                    <li class="page-item">
                        <a class="page-link" href="#" data-page="1" aria-label="First">
                            <i class="fas fa-angle-double-left"></i>
                        </a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="#" data-page="${currentPage - 1}" aria-label="Previous">
                            <i class="fas fa-angle-left"></i>
                        </a>
                    </li>
                `;
            }
            
            // Show limited page numbers
            const start = Math.max(1, currentPage - 2);
            const end = Math.min(totalPages, currentPage + 2);
            
            if (start > 1) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
            
            for (let i = start; i <= end; i++) {
                html += `
                    <li class="page-item ${i === currentPage ? 'active' : ''}">
                        <a class="page-link" href="#" data-page="${i}">${i}</a>
                    </li>
                `;
            }
            
            if (end < totalPages) {
                html += '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
            
            if (currentPage < totalPages) {
                html += `
                    <li class="page-item">
                        <a class="page-link" href="#" data-page="${currentPage + 1}" aria-label="Next">
                            <i class="fas fa-angle-right"></i>
                        </a>
                    </li>
                    <li class="page-item">
                        <a class="page-link" href="#" data-page="${totalPages}" aria-label="Last">
                            <i class="fas fa-angle-double-right"></i>
                        </a>
                    </li>
                `;
            }
        }
        
        $('#paginationContainer').html(html);
    }
    
    function getStatusBadgeClass(status) {
        return {
            'released': 'bg-success',
            'pending': 'bg-warning text-dark',
            'expired': 'bg-secondary'
        }[status] || 'bg-light text-dark';
    }
    
    // Initial load
    loadReleases();
    
    // Form submission
    $('#releaseForm').submit(function(e) {
        e.preventDefault();
        const formData = $(this).serialize() + '&status=released'; // Default status is released
        const submitBtn = $('#submitBtn');
        
        submitBtn.prop('disabled', true).html(`
            <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
            Processing...
        `);
        
        $.ajax({
            url: '../../api/admin/put/marksheet/save-marksheet-release.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    toastr.success(response.message);
                    $('#releaseForm')[0].reset();
                    loadReleases(1); // Reload first page
                } else {
                    toastr.error(response.message);
                }
                submitBtn.prop('disabled', false).html(`
                    <i class="fas fa-save me-2"></i> Release Now
                `);
            },
            error: function() {
                toastr.error('An error occurred. Please try again.');
                submitBtn.prop('disabled', false).html(`
                    <i class="fas fa-save me-2"></i> Release Now
                `);
            }
        });
    });
    
    // Refresh button
    $('#refreshReleases').click(function() {
        loadReleases(currentPage);
    });
    
    // Pagination click handler
    $(document).on('click', '.page-link', function(e) {
        e.preventDefault();
        const page = $(this).data('page');
        if (page) {
            loadReleases(page);
            $('html, body').animate({ scrollTop: 0 }, 'fast');
        }
    });
    
    // Delete release
    $(document).on('click', '.delete-btn', function(e) {
        e.preventDefault();
        const releaseId = $(this).data('id');
        
        Swal.fire({
            title: 'Delete Release',
            text: 'Are you sure you want to delete this marksheet release?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: '../../api/admin/delete/marksheet/delete-marksheet-release.php',
                    type: 'POST',
                    data: { id: releaseId },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            toastr.success(response.message);
                            loadReleases(currentPage);
                        } else {
                            toastr.error(response.message);
                        }
                    },
                    error: function() {
                        toastr.error('An error occurred. Please try again.');
                    }
                });
            }
        });
    });
});
</script>

<?php include_once("../../includes/body-close.php"); ?>