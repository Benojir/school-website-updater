<?php
include_once("../../includes/auth-check.php");
include_once("../../includes/header-open.php");
echo "<title>Students Ranking - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/dashboard-navbar.php");

// chech admin permission
if (!hasPermission(PERM_MANAGE_RESULTS)) {
    include_once("../../includes/permission-denied.php");
}
?>

<div class="container">
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0"><i class="fas fa-clipboard-list me-2"></i>Students Ranking</h4>
        </div>
        <div class="card-body">
            <form id="filterForm" novalidate>
                <div class="row">
                    <div class="col-md-4">
                        <label for="examSelect" class="form-label fw-bold">Exam(s):</label>
                        <select class="form-select custom-multiselect" name="exam_ids[]" id="examSelect" multiple required></select>
                        <div class="form-text">Select one exam for single ranking, or multiple exams for combined ranking.</div>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Class:</label>
                        <select class="form-select" name="class_id" id="classSelect" required>
                            <option value="" disabled selected>-- Select Class --</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">Section:</label>
                        <select class="form-select" name="section_id" id="sectionSelect">
                            <option value="" selected>-- Select Section --</option>
                        </select>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary mt-3"><i class="fas fa-filter me-2"></i>Filter</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow-sm mt-4">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0"><i class="fas fa-clipboard-list me-2"></i>Students Ranking List</h4>
            <button id="export_btn" class="btn btn-light"><i class="fas fa-download me-2"></i>Export</button>
        </div>
        <div class="card-body">
            <p id="rankingSummary" class="text-muted" aria-live="polite"></p>
            <div class="row mb-3">
                <div class="col-md-4 ms-auto">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" id="tableSearch" class="form-control" placeholder="Search Name, Marks or Percentage...">
                    </div>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle text-center table-striped-columns" id="student_ranking_table">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Rank</th>
                            <th>Class</th>
                            <th>Section</th>
                            <th>Roll No</th>
                            <th>Name</th>
                            <th>Percentage</th>
                            <th>Obtained</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Table rows will be dynamically added here -->
                        <tr class="text-center">
                            <td colspan="8" class="text-muted"> <i class="fas fa-info-circle fa-2x mb-2"></i><br>No data available</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    // Function to load exams
    function loadExams() {
        let examDropdown = $('#examSelect');

        $.ajax({
            url: '../../api/admin/get/exam/get-all-exams.php',
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    examDropdown.empty();
                    response.data.forEach(function(examItem) {
                        examDropdown.append(new Option(`${examItem.exam_name} (${examItem.exam_date})`, examItem.id));
                    });
                    examDropdown.multiselect('rebuild');
                } else {
                    toastr.error(response.message);
                }
            },
            error: function(xhr, status, error) {
                toastr.error('Failed to load exams.');
                console.error(xhr.responseText);
            }
        });
    }

    // Function to Load classes
    function loadClasses() {
        let classDropdown = $('#classSelect');

        $.ajax({
            url: '../../api/admin/get/class/get-all-classes.php',
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    classDropdown.empty();
                    classDropdown.append(`<option value="" selected disabled>-- Select Class --</option>`);
                    response.data.forEach(function(classItem) {
                        let optionHtml = `<option value="${classItem.id}">${classItem.name}</option>`;
                        classDropdown.append(optionHtml);
                    });
                } else {
                    toastr.error(response.message);
                }
            },
            error: function(xhr, status, error) {
                toastr.error('Failed to load classes.');
                console.error(xhr.responseText);
            }
        });
    }

    // Function to load sections
    function loadSections() {
        let classId = $('#classSelect').val();
        let sectionDropdown = $('#sectionSelect');
        sectionDropdown.empty();
        sectionDropdown.append(`<option value="" selected>-- Select Section --</option>`);

        $.ajax({
            url: '../../api/admin/get/class/get-sections-by-class.php',
            type: 'POST',
            data: {
                class_id: classId
            },
            dataType: 'json',
            success: function(response) {
                if (response.length > 0) {
                    response.forEach(sec => {
                        sectionDropdown.append(`<option value="${sec.id}">${sec.section_name}</option>`);
                    });
                } else {
                    showWarningAlert('No sections available for the selected class');
                    sectionDropdown.html('<option value="">No sections available</option>');
                }
            },
            error: function(xhr, status, error) {
                toastr.error('Failed to load sections.');
                console.error(xhr.responseText);
            }
        });
    }

    $(document).ready(function() {
        let rankingRequest = null;

        function hasRankingSelection() {
            if (!($('#examSelect').val() || []).length || !$('#classSelect').val()) {
                showWarningAlert('Please select at least one exam and a class.');
                return false;
            }
            return true;
        }

        loadExams();
        loadClasses();

        $('#classSelect').on('change', function() {
            loadSections();
        });

        // Filter form submission
        $('#filterForm').on('submit', function(e) {
            e.preventDefault();
            if (!hasRankingSelection()) return;
            if (rankingRequest) rankingRequest.abort();
            let formData = $(this).serialize();
            const selectedExams = $('#examSelect option:selected').map(function() {
                return $(this).text();
            }).get();

            rankingRequest = $.ajax({
                url: '../../api/admin/get/marksheet/get-top-rankers.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $('#rankingSummary').text((selectedExams.length > 1 ? 'Combined ranking: ' : 'Single exam ranking: ') + selectedExams.join(' + '));
                        let tableBody = $('#student_ranking_table tbody');
                        tableBody.empty();

                        if (response.data.length === 0) {
                            tableBody.append(`
                                <tr class="text-center">
                                    <td colspan="8" class="text-muted"> <i class="fas fa-info-circle fa-2x mb-2"></i><br>No data available</td>
                                </tr>
                            `);
                        } else {
                            response.data.forEach(function(student, index) {
                                const row = $('<tr>');
                                [index + 1, getOrdinal(student.rank), student.class_name,
                                    student.section_name, student.roll_no, student.name,
                                    `${student.percentage}%`, student.obtained_marks
                                ].forEach(value => row.append($('<td>').text(value)));
                                tableBody.append(row);
                            });
                        }
                        $('#tableSearch').trigger('keyup');
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    if (status === 'abort') return;
                    toastr.error('Failed to get students ranking.');
                    console.error(xhr.responseText);
                }
            })
        });

        // Client-side Table Search
        $("#tableSearch").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            
            $("#student_ranking_table tbody tr").filter(function() {
                // Ignore the "No data available" row if it exists
                if ($(this).find('td').length < 2) return;

                // Column Indices (0-based): 5=Name, 6=Percentage, 7=Obtained
                var name = $(this).find('td:eq(5)').text().toLowerCase();
                var percentage = $(this).find('td:eq(6)').text().toLowerCase();
                var obtained = $(this).find('td:eq(7)').text().toLowerCase();

                // Show row if any of the 3 columns match the search value
                var isMatch = name.indexOf(value) > -1 || 
                              percentage.indexOf(value) > -1 || 
                              obtained.indexOf(value) > -1;
                
                $(this).toggle(isMatch);
            });
        });

        // Handle export button
        $('#export_btn').on('click', function() {
            // Validate form before exporting
            if (!hasRankingSelection()) return;

            let formData = $('#filterForm').serialize();
            window.location.href = `../../api/download/students-ranking-export.php?${formData}`;
        });
    });
</script>

<?php include_once("../../includes/body-close.php"); ?>
