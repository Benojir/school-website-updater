<?php include_once "includes/config.php"; 

// First fetch all partial payments
$partial_payments = $pdo->query("SELECT * FROM student_partial_payments")->fetchAll(PDO::FETCH_ASSOC);

foreach ($partial_payments as $partial_payment) {
    // Fetch student
    $full_paid_fee_id = $partial_payment['full_paid_fees_id'];

    if (empty($full_paid_fee_id)) {
        continue;
    }

    // Check this full paid fees id available in student_full_paid_fees table
    $stmt = $pdo->prepare("SELECT * FROM student_full_paid_fees WHERE id = ?");
    $stmt->execute([$full_paid_fee_id]);
    $payment = $stmt->fetch(PDO::FETCH_ASSOC);

    if (empty($payment)) {
        $stmt = $pdo->prepare("DELETE FROM student_partial_payments WHERE id = ?");
        $stmt->execute([$partial_payment['id']]);

        echo "<span style='color: yellow;'>Removed partial payment: " . $partial_payment['id'] . "</span><br>";
    }
}