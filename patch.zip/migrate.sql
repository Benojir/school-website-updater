-- Manual / attendance-based teacher salary mode (review and execute manually).
-- Requires the existing staff attendance/payroll tables already installed.
-- Creates an empty school-wide, effective-month history. Existing calculations
-- default to attendance mode; no teacher, attendance or payment data is changed.
CREATE TABLE IF NOT EXISTS staff_payroll_modes (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    effective_month CHAR(7) NOT NULL,
    mode ENUM('manual','attendance') NOT NULL,
    created_by INT NOT NULL,
    reason VARCHAR(1000) NOT NULL,
    created_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    KEY idx_staff_payroll_mode_month (effective_month, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
