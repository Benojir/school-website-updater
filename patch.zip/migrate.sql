-- Teacher self-attendance / payroll (free on-device liveness + mandatory review).
-- Review and run ONLY this new section if earlier sections were already applied.
-- One school per existing database/deployment, matching the current application.
-- All DATETIME values below are UTC. Policies contain the school's time zone.
-- Photos live on ImgBB; only URLs, hashes and challenge metadata are stored here.
CREATE TABLE IF NOT EXISTS staff_attendance_control (
    id TINYINT UNSIGNED NOT NULL PRIMARY KEY
) ENGINE=InnoDB;
INSERT IGNORE INTO staff_attendance_control (id) VALUES (1);

CREATE TABLE IF NOT EXISTS staff_attendance_policies (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    effective_date DATE NOT NULL,
    rules_json TEXT NOT NULL,
    created_by INT NOT NULL,
    reason VARCHAR(1000) NOT NULL,
    created_at DATETIME NOT NULL,
    KEY idx_staff_policy_date (effective_date, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS staff_attendance_devices (
    teacher_id INT NOT NULL PRIMARY KEY,
    device_hash CHAR(64) NOT NULL,
    enrolled_at DATETIME NOT NULL,
    UNIQUE KEY uq_staff_attendance_device (device_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS staff_attendance_challenges (
    id CHAR(32) NOT NULL PRIMARY KEY,
    teacher_id INT NOT NULL,
    auth_session_id INT NOT NULL,
    policy_id BIGINT UNSIGNED NOT NULL,
    work_date DATE NOT NULL,
    punch_type VARCHAR(10) NOT NULL,
    steps_json TEXT NOT NULL,
    location_json TEXT NOT NULL,
    state VARCHAR(20) NOT NULL DEFAULT 'issued',
    issued_at DATETIME NOT NULL,
    expires_at DATETIME NOT NULL,
    processing_at DATETIME DEFAULT NULL,
    event_id BIGINT UNSIGNED DEFAULT NULL,
    KEY idx_staff_challenge_rate (teacher_id, issued_at),
    KEY idx_staff_challenge_month (teacher_id, work_date, state)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS staff_attendance_events (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    challenge_id CHAR(32) NOT NULL,
    teacher_id INT NOT NULL,
    work_date DATE NOT NULL,
    punch_type VARCHAR(10) NOT NULL,
    occurred_at DATETIME NOT NULL,
    selfie_url VARCHAR(1000) NOT NULL,
    evidence_url VARCHAR(1000) NOT NULL,
    selfie_delete_url VARCHAR(1000) NOT NULL,
    evidence_delete_url VARCHAR(1000) NOT NULL,
    selfie_hash CHAR(64) NOT NULL,
    evidence_hash CHAR(64) NOT NULL,
    proof_json TEXT NOT NULL,
    location_json TEXT NOT NULL,
    device_hash CHAR(64) NOT NULL,
    UNIQUE KEY uq_staff_event_challenge (challenge_id),
    UNIQUE KEY uq_staff_selfie_hash (selfie_hash),
    KEY idx_staff_event_review (teacher_id, work_date, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS staff_attendance_days (
    teacher_id INT NOT NULL,
    work_date DATE NOT NULL,
    policy_id BIGINT UNSIGNED NOT NULL,
    check_in DATETIME DEFAULT NULL,
    check_out DATETIME DEFAULT NULL,
    in_event_id BIGINT UNSIGNED DEFAULT NULL,
    out_event_id BIGINT UNSIGNED DEFAULT NULL,
    override_status VARCHAR(20) DEFAULT NULL,
    review_status VARCHAR(20) NOT NULL DEFAULT 'pending',
    version INT UNSIGNED NOT NULL DEFAULT 1,
    PRIMARY KEY (teacher_id, work_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS staff_salary_terms (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    teacher_id INT NOT NULL,
    effective_date DATE NOT NULL,
    salary_paise BIGINT UNSIGNED NOT NULL,
    employment_end DATE DEFAULT NULL,
    created_by INT DEFAULT NULL,
    reason VARCHAR(1000) NOT NULL,
    created_at DATETIME NOT NULL,
    KEY idx_staff_salary_term (teacher_id, effective_date, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
-- Import existing salaries ONCE as opening terms; no existing teacher is changed.
INSERT INTO staff_salary_terms (teacher_id,effective_date,salary_paise,created_by,reason,created_at)
SELECT t.id, '2000-01-01', GREATEST(0, ROUND(t.monthly_salary * 100)), NULL,
       'Opening salary imported from teacher profile', UTC_TIMESTAMP()
FROM teachers t
WHERE t.status NOT IN ('pending','reject')
AND NOT EXISTS (SELECT 1 FROM staff_salary_terms s WHERE s.teacher_id=t.id);

CREATE TABLE IF NOT EXISTS staff_attendance_calendar (
    work_date DATE NOT NULL PRIMARY KEY,
    kind VARCHAR(20) NOT NULL,
    reason VARCHAR(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS staff_payroll_adjustments (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    teacher_id INT NOT NULL,
    payroll_month CHAR(7) NOT NULL,
    amount_paise BIGINT NOT NULL,
    reason VARCHAR(1000) NOT NULL,
    created_by INT NOT NULL,
    created_at DATETIME NOT NULL,
    KEY idx_staff_payroll_adjustment (teacher_id, payroll_month)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS staff_payroll_months (
    teacher_id INT NOT NULL,
    payroll_month CHAR(7) NOT NULL,
    state VARCHAR(20) NOT NULL,
    snapshot_json LONGTEXT NOT NULL,
    finalized_by INT NOT NULL,
    finalized_at DATETIME NOT NULL,
    paid_reference VARCHAR(200) DEFAULT NULL,
    paid_at DATETIME DEFAULT NULL,
    PRIMARY KEY (teacher_id, payroll_month)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS staff_attendance_audit (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    actor_id INT NOT NULL,
    action_name VARCHAR(50) NOT NULL,
    teacher_id INT DEFAULT NULL,
    reference_key VARCHAR(100) NOT NULL,
    reason VARCHAR(1000) NOT NULL,
    before_json LONGTEXT NOT NULL,
    after_json LONGTEXT NOT NULL,
    created_at DATETIME NOT NULL,
    KEY idx_staff_audit_teacher (teacher_id, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Personal attendance settings: school rules remain the default for every teacher.
-- If the original attendance migration was already applied, review/run only this
-- CREATE TABLE statement. No existing policy, salary or attendance is modified.
CREATE TABLE IF NOT EXISTS staff_attendance_teacher_rules (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    teacher_id INT NOT NULL,
    effective_date DATE NOT NULL,
    end_date DATE DEFAULT NULL,
    overrides_json TEXT NOT NULL,
    created_by INT NOT NULL,
    reason VARCHAR(1000) NOT NULL,
    created_at DATETIME NOT NULL,
    KEY idx_staff_teacher_rule_date (teacher_id, effective_date, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
