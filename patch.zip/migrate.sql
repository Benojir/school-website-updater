-- Student academic history migration, version 20260921_01.
-- MANUAL EXECUTION ONLY. This file has not been executed by the coding agent.
-- Read docs/academic-migration.md before running this on EACH client database.
-- Make and restore-test a complete backup. Stop website, app API, cron and
-- webhook writes; keep maintenance mode enabled until code and checks are ready.
-- Use a fresh connection, select the intended database, and import this entire
-- file with a client that supports DELIMITER. Do not use --force/ignore errors.
-- Requires MySQL 8.0+ or MariaDB 10.5+, InnoDB, routine/DDL/DML privileges.
-- No USE statement, client data, credentials, or server-specific database name.
-- No DELETE/REPLACE/TRUNCATE of application rows, no disabling foreign keys,
-- no inferred dates, and no updates to existing fee ledgers. A separate follow-up
-- applies the user's explicit 2026 choice to unresolved pre-upgrade enrollments.
--
-- DDL commits implicitly: this is a checkpointed migration, NOT one atomic DDL
-- transaction. A partial run can leave added objects. V1 preserves the baseline;
-- the follow-up updates approved years/current projections in one transaction.
-- The migration ledger is the authoritative completion flag for each version.
-- Legacy zero/partial-zero dates are copied verbatim. Only this procedure's
-- session mode temporarily permits them; existing strictness and all value
-- checks remain. No source dates, global modes or application settings change.

-- Read-only deployment report. Unresolved years are retained, not guessed.
SELECT DATABASE() AS selected_database, VERSION() AS server_version,
       @@sql_mode AS sql_mode, @@foreign_key_checks AS foreign_key_checks;
SELECT COUNT(*) AS source_students,
       SUM(CASE WHEN s.academic_year IS NOT NULL AND CHAR_LENGTH(s.academic_year) = 4 AND s.academic_year REGEXP '^[0-9]{4}$' AND s.academic_year BETWEEN '2000' AND '2200' THEN 0 ELSE 1 END) AS unresolved_academic_years,
       SUM(CASE WHEN s.student_id IS NULL OR TRIM(s.student_id) = '' THEN 1 ELSE 0 END) AS missing_public_student_ids
FROM students AS s;
SELECT COUNT(*) AS legacy_zero_date_rows_to_preserve
FROM students
WHERE CAST(admission_date AS CHAR) LIKE '0000-%' OR CAST(admission_date AS CHAR) LIKE '%-00%'
   OR CAST(promoted_date AS CHAR) LIKE '0000-%' OR CAST(promoted_date AS CHAR) LIKE '%-00%'
   OR CAST(updated_at AS CHAR) LIKE '0000-%' OR CAST(updated_at AS CHAR) LIKE '%-00%';

DELIMITER $$

-- Only migration-owned helper routines are replaced, never application tables.
DROP PROCEDURE IF EXISTS academic_history_assert_column_v1$$
CREATE PROCEDURE academic_history_assert_column_v1(
    IN p_table VARCHAR(64), IN p_column VARCHAR(64), IN p_type VARCHAR(64),
    IN p_nullable VARCHAR(3), IN p_collation VARCHAR(64)
)
SQL SECURITY INVOKER
BEGIN
    DECLARE v_count INT DEFAULT 0;
    DECLARE v_type VARCHAR(64);
    DECLARE v_nullable VARCHAR(3);
    DECLARE v_collation VARCHAR(64);
    DECLARE v_message VARCHAR(128);
    SELECT COUNT(*),
           MAX(CASE WHEN DATA_TYPE IN ('int', 'bigint', 'tinyint')
                    THEN CONCAT(DATA_TYPE, IF(COLUMN_TYPE LIKE '%unsigned%', ' unsigned', ''))
                    ELSE LOWER(COLUMN_TYPE) END),
           MAX(IS_NULLABLE), MAX(COLLATION_NAME)
      INTO v_count, v_type, v_nullable, v_collation
      FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = p_table AND COLUMN_NAME = p_column;
    IF v_count <> 1 OR v_type <> p_type OR v_nullable <> p_nullable
       OR (p_collation IS NOT NULL AND NOT (v_collation <=> p_collation)) THEN
        SET v_message = LEFT(CONCAT('Academic migration: incompatible column ', p_table, '.', p_column, '. Review schema; no coercion performed.'), 128);
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = v_message;
    END IF;
END$$

DROP PROCEDURE IF EXISTS academic_history_assert_index_v1$$
CREATE PROCEDURE academic_history_assert_index_v1(
    IN p_table VARCHAR(64), IN p_index VARCHAR(64),
    IN p_columns VARCHAR(255), IN p_unique TINYINT
)
SQL SECURITY INVOKER
BEGIN
    DECLARE v_columns VARCHAR(255);
    DECLARE v_non_unique INT;
    DECLARE v_partial INT;
    DECLARE v_message VARCHAR(128);
    SELECT GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX SEPARATOR ','),
           MAX(NON_UNIQUE), SUM(CASE WHEN SUB_PART IS NOT NULL THEN 1 ELSE 0 END)
      INTO v_columns, v_non_unique, v_partial
      FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = p_table AND INDEX_NAME = p_index;
    IF NOT (v_columns <=> p_columns) OR NOT (v_non_unique <=> (1 - p_unique)) OR COALESCE(v_partial, 0) <> 0 THEN
        SET v_message = LEFT(CONCAT('Academic migration: incompatible index ', p_table, '.', p_index, '. Review partial schema.'), 128);
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = v_message;
    END IF;
END$$

DROP PROCEDURE IF EXISTS academic_history_assert_fk_v1$$
CREATE PROCEDURE academic_history_assert_fk_v1(
    IN p_constraint VARCHAR(64), IN p_column VARCHAR(64),
    IN p_parent VARCHAR(64), IN p_parent_column VARCHAR(64)
)
SQL SECURITY INVOKER
BEGIN
    DECLARE v_count INT DEFAULT 0;
    DECLARE v_message VARCHAR(128);
    SELECT COUNT(*) INTO v_count
      FROM information_schema.KEY_COLUMN_USAGE AS k
      JOIN information_schema.REFERENTIAL_CONSTRAINTS AS r
        ON r.CONSTRAINT_SCHEMA = k.CONSTRAINT_SCHEMA AND r.TABLE_NAME = k.TABLE_NAME
       AND r.CONSTRAINT_NAME = k.CONSTRAINT_NAME
     WHERE k.TABLE_SCHEMA = DATABASE() AND k.TABLE_NAME = 'student_academic_records'
       AND k.CONSTRAINT_NAME = p_constraint AND k.COLUMN_NAME = p_column
       AND k.REFERENCED_TABLE_SCHEMA = DATABASE() AND k.REFERENCED_TABLE_NAME = p_parent
       AND k.REFERENCED_COLUMN_NAME = p_parent_column AND k.ORDINAL_POSITION = 1
       AND r.DELETE_RULE IN ('RESTRICT', 'NO ACTION')
       AND r.UPDATE_RULE IN ('RESTRICT', 'NO ACTION');
    IF v_count <> 1 THEN
        SET v_message = LEFT(CONCAT('Academic migration: incompatible history foreign key ', p_constraint, '.'), 128);
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = v_message;
    END IF;
END$$

DROP PROCEDURE IF EXISTS academic_history_migrate_v1$$
CREATE PROCEDURE academic_history_migrate_v1()
SQL SECURITY INVOKER
migration: BEGIN
    DECLARE v_version VARCHAR(100) DEFAULT '20260921_01_student_academic_history';
    DECLARE v_phase VARCHAR(20) DEFAULT NULL;
    DECLARE v_source_rows BIGINT UNSIGNED DEFAULT 0;
    DECLARE v_count BIGINT DEFAULT 0;
    DECLARE v_saved_rows BIGINT UNSIGNED DEFAULT 0;
    DECLARE v_lock_name VARCHAR(64);
    DECLARE v_lock INT DEFAULT 0;
    DECLARE v_engine_version VARCHAR(100);
    DECLARE v_major INT;
    DECLARE v_minor INT;
    DECLARE v_expression LONGTEXT;
    DECLARE v_table_comment VARCHAR(2048);
    DECLARE v_original_sql_mode TEXT DEFAULT NULL;
    DECLARE v_copy_sql_mode TEXT;
    DECLARE v_sql_mode_changed TINYINT DEFAULT 0;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        IF v_sql_mode_changed = 1 THEN
            BEGIN
                -- Only the SQL-mode combination deprecation is expected here.
                DECLARE CONTINUE HANDLER FOR 3135 BEGIN END;
                SET SESSION sql_mode = v_original_sql_mode;
            END;
            SET v_sql_mode_changed = 0;
        END IF;
        IF v_lock = 1 THEN
            DO RELEASE_LOCK(v_lock_name);
        END IF;
        RESIGNAL;
    END;
    -- A conversion warning is a migration failure, never silently accepted.
    DECLARE EXIT HANDLER FOR SQLWARNING
    BEGIN
        ROLLBACK;
        IF v_sql_mode_changed = 1 THEN
            BEGIN
                DECLARE CONTINUE HANDLER FOR 3135 BEGIN END;
                SET SESSION sql_mode = v_original_sql_mode;
            END;
            SET v_sql_mode_changed = 0;
        END IF;
        IF v_lock = 1 THEN
            DO RELEASE_LOCK(v_lock_name);
        END IF;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Academic migration stopped on SQL warning; preserve objects and inspect before retrying.';
    END;

    SET v_original_sql_mode = @@SESSION.sql_mode;
    IF DATABASE() IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Select the intended school database before running migrate.sql.';
    END IF;
    IF @@foreign_key_checks <> 1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Academic migration requires foreign_key_checks=1. Reconnect normally and retry.';
    END IF;
    SET v_engine_version = VERSION();
    IF LEFT(v_engine_version, 6) = '5.5.5-' THEN
        SET v_engine_version = SUBSTRING(v_engine_version, 7);
    END IF;
    SET v_major = CAST(SUBSTRING_INDEX(v_engine_version, '.', 1) AS UNSIGNED);
    SET v_minor = CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(v_engine_version, '.', 2), '.', -1) AS UNSIGNED);
    IF (VERSION() LIKE '%MariaDB%' AND (v_major < 10 OR (v_major = 10 AND v_minor < 5)))
       OR (VERSION() NOT LIKE '%MariaDB%' AND v_major < 8) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Academic migration requires MySQL 8.0+ or MariaDB 10.5+; client compatibility must be reviewed.';
    END IF;
    SET v_lock_name = CONCAT('school-academic-v1:', LEFT(SHA2(DATABASE(), 256), 32));
    SET v_lock = GET_LOCK(v_lock_name, 0);
    IF NOT (v_lock <=> 1) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Another academic migration holds the database migration lock.';
    END IF;

    -- Source schema preflight. Display widths on integer columns are ignored.
    -- Additional personal columns are deliberately not touched.
    SELECT COUNT(*) INTO v_count FROM information_schema.TABLES
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('students', 'classes', 'sections', 'school_settings', 'exams')
       AND TABLE_TYPE = 'BASE TABLE' AND ENGINE = 'InnoDB';
    IF v_count <> 5 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Expected students/classes/sections/school_settings/exams InnoDB base tables; review client schema.';
    END IF;
    CALL academic_history_assert_column_v1('students', 'id', 'int', 'NO', NULL);
    CALL academic_history_assert_column_v1('students', 'student_id', 'varchar(50)', 'YES', NULL);
    CALL academic_history_assert_column_v1('students', 'academic_year', 'varchar(20)', 'YES', NULL);
    CALL academic_history_assert_column_v1('students', 'class_id', 'int', 'YES', NULL);
    CALL academic_history_assert_column_v1('students', 'section_id', 'int', 'YES', NULL);
    CALL academic_history_assert_column_v1('students', 'roll_no', 'int', 'YES', NULL);
    CALL academic_history_assert_column_v1('students', 'registration_no', 'varchar(50)', 'YES', NULL);
    CALL academic_history_assert_column_v1('students', 'admission_date', 'date', 'YES', NULL);
    CALL academic_history_assert_column_v1('students', 'promoted_date', 'date', 'YES', NULL);
    CALL academic_history_assert_column_v1('students', 'status', 'varchar(10)', 'YES', NULL);
    CALL academic_history_assert_column_v1('students', 'custom_class_fee', 'decimal(10,2)', 'NO', NULL);
    CALL academic_history_assert_column_v1('students', 'updated_at', 'timestamp', 'NO', NULL);
    CALL academic_history_assert_column_v1('classes', 'id', 'int', 'NO', NULL);
    CALL academic_history_assert_column_v1('sections', 'id', 'int', 'NO', NULL);
    CALL academic_history_assert_column_v1('sections', 'class_id', 'int', 'NO', NULL);
    CALL academic_history_assert_index_v1('students', 'PRIMARY', 'id', 1);
    CALL academic_history_assert_index_v1('classes', 'PRIMARY', 'id', 1);
    CALL academic_history_assert_index_v1('sections', 'PRIMARY', 'id', 1);
    SELECT COUNT(*) INTO v_count FROM (
        SELECT INDEX_NAME FROM information_schema.STATISTICS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'students' AND NON_UNIQUE = 0
           AND INDEX_NAME <> 'unique_roll'
         GROUP BY INDEX_NAME
        HAVING SUM(CASE WHEN COLUMN_NAME = 'roll_no' THEN 1 ELSE 0 END) > 0
           AND SUM(CASE WHEN COLUMN_NAME NOT IN ('class_id', 'section_id', 'roll_no') THEN 1 ELSE 0 END) = 0
    ) AS other_global_roll_indexes;
    IF v_count <> 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Unexpected global roll unique index on students; review client schema before migration.';
    END IF;

    -- Never trust CREATE TABLE IF NOT EXISTS to validate someone else's table.
    SELECT COUNT(*) INTO v_count FROM information_schema.TABLES
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'academic_schema_migrations';
    IF v_count = 0 THEN
        CREATE TABLE academic_schema_migrations (
            migration_key VARCHAR(100) NOT NULL,
            phase VARCHAR(20) NOT NULL,
            source_rows BIGINT UNSIGNED NOT NULL,
            snapshot_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            completed_at TIMESTAMP NULL DEFAULT NULL,
            PRIMARY KEY (migration_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
          COMMENT='school-academic-history-v1:ledger';
    END IF;
    CALL academic_history_assert_column_v1('academic_schema_migrations', 'migration_key', 'varchar(100)', 'NO', 'utf8mb4_general_ci');
    CALL academic_history_assert_column_v1('academic_schema_migrations', 'phase', 'varchar(20)', 'NO', 'utf8mb4_general_ci');
    CALL academic_history_assert_column_v1('academic_schema_migrations', 'source_rows', 'bigint unsigned', 'NO', NULL);
    CALL academic_history_assert_column_v1('academic_schema_migrations', 'snapshot_at', 'timestamp', 'NO', NULL);
    CALL academic_history_assert_column_v1('academic_schema_migrations', 'completed_at', 'timestamp', 'YES', NULL);
    SELECT COUNT(*), MAX(TABLE_COMMENT) INTO v_count, v_table_comment FROM information_schema.TABLES
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'academic_schema_migrations'
       AND ENGINE = 'InnoDB' AND TABLE_TYPE = 'BASE TABLE';
    IF v_count <> 1 OR v_table_comment <> 'school-academic-history-v1:ledger' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Conflicting academic_schema_migrations table; do not replace it.';
    END IF;
    SELECT COUNT(*) INTO v_count FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'academic_schema_migrations';
    IF v_count <> 5 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Unexpected migration ledger columns; review partial schema.';
    END IF;
    CALL academic_history_assert_index_v1('academic_schema_migrations', 'PRIMARY', 'migration_key', 1);
    SELECT COUNT(DISTINCT INDEX_NAME) INTO v_count FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'academic_schema_migrations';
    IF v_count <> 1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Unexpected migration ledger indexes; review partial schema.';
    END IF;
    SELECT COUNT(*) INTO v_count FROM information_schema.REFERENTIAL_CONSTRAINTS
     WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = 'academic_schema_migrations';
    IF v_count <> 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Migration ledger must have no foreign keys.';
    END IF;
    SELECT MAX(phase), COALESCE(MAX(source_rows), 0) INTO v_phase, v_saved_rows
      FROM academic_schema_migrations WHERE migration_key = v_version;
    IF v_phase IS NOT NULL AND v_phase NOT IN ('snapshot', 'backfilled', 'complete') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Unknown academic migration checkpoint; manual review required.';
    END IF;

    -- Data checks happen before adding or changing application schema.
    -- On a completed rerun, live values may have legitimately evolved.
    IF v_phase IS NULL THEN
        SELECT COUNT(*) INTO v_count FROM students AS s
          LEFT JOIN classes AS c ON c.id = s.class_id
          LEFT JOIN sections AS sec ON sec.id = s.section_id
         WHERE (s.class_id IS NOT NULL AND (c.id IS NULL OR s.class_id <= 0))
            OR (s.section_id IS NOT NULL AND
                (sec.id IS NULL OR s.section_id <= 0 OR s.class_id IS NULL OR sec.class_id <> s.class_id));
        IF v_count <> 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Preflight: orphan/mismatched/nonpositive class or section IDs. Source unchanged; review affected rows.';
        END IF;
        SELECT COUNT(*) INTO v_count FROM (
            SELECT s.academic_year, s.class_id, COALESCE(s.section_id, 0) AS section_scope, s.roll_no
              FROM students AS s
             WHERE s.academic_year IS NOT NULL AND CHAR_LENGTH(s.academic_year) = 4 AND s.academic_year REGEXP '^[0-9]{4}$' AND s.academic_year BETWEEN '2000' AND '2200'
               AND s.class_id IS NOT NULL AND s.roll_no IS NOT NULL
             GROUP BY s.academic_year, s.class_id, COALESCE(s.section_id, 0), s.roll_no
            HAVING COUNT(*) > 1
        ) AS conflicting_rolls;
        IF v_count <> 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Preflight: duplicate year/class/section/roll. Resolve explicitly; migration will not drop or renumber students.';
        END IF;
    END IF;

    -- Stored procedures use their CREATE-time sql_mode. Change it INSIDE this
    -- routine, before ALTER/INSERT, rather than changing the caller before CALL.
    -- @@sql_mode expands TRADITIONAL into its component modes; remove the alias
    -- as well so SET cannot re-enable the two zero-date restrictions. Keep its
    -- expanded strict/other component modes and every unrelated setting.
    SET v_copy_sql_mode = TRIM(BOTH ',' FROM REPLACE(REPLACE(REPLACE(
        CONCAT(',', v_original_sql_mode, ','), ',NO_ZERO_DATE,', ','),
        ',NO_ZERO_IN_DATE,', ','), ',TRADITIONAL,', ','));
    IF v_copy_sql_mode <> v_original_sql_mode THEN
        SET v_sql_mode_changed = 1;
        BEGIN
            -- MySQL 3135 warns about the deprecated strict/zero-mode combination.
            -- Its handler is scoped to SET only: data/DDL warnings still abort.
            DECLARE CONTINUE HANDLER FOR 3135 BEGIN END;
            SET SESSION sql_mode = v_copy_sql_mode;
        END;
    END IF;
    IF FIND_IN_SET('NO_ZERO_DATE', @@SESSION.sql_mode) > 0
       OR FIND_IN_SET('NO_ZERO_IN_DATE', @@SESSION.sql_mode) > 0
       OR (FIND_IN_SET('STRICT_TRANS_TABLES', v_original_sql_mode) > 0
           AND FIND_IN_SET('STRICT_TRANS_TABLES', @@SESSION.sql_mode) = 0)
       OR (FIND_IN_SET('STRICT_ALL_TABLES', v_original_sql_mode) > 0
           AND FIND_IN_SET('STRICT_ALL_TABLES', @@SESSION.sql_mode) = 0) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot preserve legacy dates with the required migration SQL mode; source unchanged.';
    END IF;

    SELECT COUNT(*) INTO v_count FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'students' AND COLUMN_NAME = 'first_admission_date';
    IF v_count = 0 THEN
        IF v_phase IS NOT NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'First-admission column missing after checkpoint; restore/review instead of recreating it.';
        END IF;
        ALTER TABLE students ADD COLUMN first_admission_date DATE NULL DEFAULT NULL;
    END IF;
    CALL academic_history_assert_column_v1('students', 'first_admission_date', 'date', 'YES', NULL);
    SELECT COUNT(*) INTO v_count FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'school_settings' AND COLUMN_NAME = 'current_academic_year';
    IF v_count = 0 THEN
        IF v_phase IS NOT NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Current-academic-year column missing after checkpoint; restore/review instead of recreating it.';
        END IF;
        ALTER TABLE school_settings ADD COLUMN current_academic_year VARCHAR(20)
            CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL;
    END IF;
    CALL academic_history_assert_column_v1('school_settings', 'current_academic_year', 'varchar(20)', 'YES', 'utf8mb4_general_ci');
    SELECT COUNT(*) INTO v_count FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'exams' AND COLUMN_NAME = 'academic_year';
    IF v_count = 0 THEN
        IF v_phase IS NOT NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Exam-academic-year column missing after checkpoint; restore/review instead of recreating it.';
        END IF;
        ALTER TABLE exams ADD COLUMN academic_year VARCHAR(20)
            CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL;
    END IF;
    CALL academic_history_assert_column_v1('exams', 'academic_year', 'varchar(20)', 'YES', 'utf8mb4_general_ci');

    SELECT COUNT(*) INTO v_count FROM information_schema.TABLES
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'student_academic_legacy_snapshot';
    IF v_count = 0 THEN
        IF v_phase IS NOT NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Migration snapshot is missing after a checkpoint. Restore/review; never recapture current students.';
        END IF;
        CREATE TABLE student_academic_legacy_snapshot (
            student_row_id INT NOT NULL,
            student_id VARCHAR(50) NULL DEFAULT NULL,
            academic_year VARCHAR(20) NULL DEFAULT NULL,
            class_id INT NULL DEFAULT NULL,
            section_id INT NULL DEFAULT NULL,
            roll_no INT NULL DEFAULT NULL,
            registration_no VARCHAR(50) NULL DEFAULT NULL,
            admission_date DATE NULL DEFAULT NULL,
            promoted_date DATE NULL DEFAULT NULL,
            status VARCHAR(10) NULL DEFAULT 'Active',
            custom_class_fee DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            source_updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            captured_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (student_row_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
          COMMENT='school-academic-history-v1:immutable-legacy-snapshot';
    END IF;
    CALL academic_history_assert_column_v1('student_academic_legacy_snapshot', 'student_row_id', 'int', 'NO', NULL);
    CALL academic_history_assert_column_v1('student_academic_legacy_snapshot', 'student_id', 'varchar(50)', 'YES', 'utf8mb4_general_ci');
    CALL academic_history_assert_column_v1('student_academic_legacy_snapshot', 'academic_year', 'varchar(20)', 'YES', 'utf8mb4_general_ci');
    CALL academic_history_assert_column_v1('student_academic_legacy_snapshot', 'class_id', 'int', 'YES', NULL);
    CALL academic_history_assert_column_v1('student_academic_legacy_snapshot', 'section_id', 'int', 'YES', NULL);
    CALL academic_history_assert_column_v1('student_academic_legacy_snapshot', 'roll_no', 'int', 'YES', NULL);
    CALL academic_history_assert_column_v1('student_academic_legacy_snapshot', 'registration_no', 'varchar(50)', 'YES', 'utf8mb4_general_ci');
    CALL academic_history_assert_column_v1('student_academic_legacy_snapshot', 'admission_date', 'date', 'YES', NULL);
    CALL academic_history_assert_column_v1('student_academic_legacy_snapshot', 'promoted_date', 'date', 'YES', NULL);
    CALL academic_history_assert_column_v1('student_academic_legacy_snapshot', 'status', 'varchar(10)', 'YES', 'utf8mb4_general_ci');
    CALL academic_history_assert_column_v1('student_academic_legacy_snapshot', 'custom_class_fee', 'decimal(10,2)', 'NO', NULL);
    CALL academic_history_assert_column_v1('student_academic_legacy_snapshot', 'source_updated_at', 'timestamp', 'NO', NULL);
    CALL academic_history_assert_column_v1('student_academic_legacy_snapshot', 'captured_at', 'timestamp', 'NO', NULL);
    SELECT COUNT(*), MAX(TABLE_COMMENT) INTO v_count, v_table_comment FROM information_schema.TABLES
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'student_academic_legacy_snapshot'
       AND ENGINE = 'InnoDB' AND TABLE_TYPE = 'BASE TABLE';
    IF v_count <> 1 OR v_table_comment <> 'school-academic-history-v1:immutable-legacy-snapshot' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Conflicting legacy snapshot table; do not replace it.';
    END IF;
    SELECT COUNT(*) INTO v_count FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'student_academic_legacy_snapshot';
    IF v_count <> 13 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Unexpected snapshot columns; review partial schema.';
    END IF;
    CALL academic_history_assert_index_v1('student_academic_legacy_snapshot', 'PRIMARY', 'student_row_id', 1);
    SELECT COUNT(DISTINCT INDEX_NAME) INTO v_count FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'student_academic_legacy_snapshot';
    IF v_count <> 1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Unexpected snapshot indexes; do not impose uniqueness on legacy values.';
    END IF;
    SELECT COUNT(*) INTO v_count FROM information_schema.REFERENTIAL_CONSTRAINTS
     WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = 'student_academic_legacy_snapshot';
    IF v_count <> 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Snapshot must have no foreign keys; historical copies must not cascade or disappear.';
    END IF;

    SELECT COUNT(*) INTO v_count FROM information_schema.TABLES
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'student_academic_records';
    IF v_count = 0 THEN
        IF v_phase IN ('backfilled', 'complete') THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Academic records missing after backfill. Restore/review; automatic recreation refused.';
        END IF;
        CREATE TABLE student_academic_records (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            student_row_id INT NOT NULL,
            academic_year VARCHAR(20) NULL DEFAULT NULL,
            class_id INT NULL DEFAULT NULL,
            section_id INT NULL DEFAULT NULL,
            roll_no INT NULL DEFAULT NULL,
            registration_no VARCHAR(50) NULL DEFAULT NULL,
            admission_date DATE NULL DEFAULT NULL,
            promoted_date DATE NULL DEFAULT NULL,
            status VARCHAR(10) NULL DEFAULT 'Active',
            custom_class_fee DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            section_scope INT GENERATED ALWAYS AS (COALESCE(section_id, 0)) STORED,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_student_academic_year (student_row_id, academic_year),
            UNIQUE KEY uq_academic_roll (academic_year, class_id, section_scope, roll_no),
            KEY idx_academic_class (class_id),
            KEY idx_academic_section (section_id),
            KEY idx_academic_registration (academic_year, registration_no),
            KEY idx_academic_year_status (academic_year, status),
            CONSTRAINT fk_academic_student_row FOREIGN KEY (student_row_id) REFERENCES students (id)
                ON DELETE RESTRICT ON UPDATE RESTRICT,
            CONSTRAINT fk_academic_class FOREIGN KEY (class_id) REFERENCES classes (id)
                ON DELETE RESTRICT ON UPDATE RESTRICT,
            CONSTRAINT fk_academic_section FOREIGN KEY (section_id) REFERENCES sections (id)
                ON DELETE RESTRICT ON UPDATE RESTRICT
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
          COMMENT='school-academic-history-v1:records';
    END IF;
    CALL academic_history_assert_column_v1('student_academic_records', 'id', 'bigint unsigned', 'NO', NULL);
    CALL academic_history_assert_column_v1('student_academic_records', 'student_row_id', 'int', 'NO', NULL);
    CALL academic_history_assert_column_v1('student_academic_records', 'academic_year', 'varchar(20)', 'YES', 'utf8mb4_general_ci');
    CALL academic_history_assert_column_v1('student_academic_records', 'class_id', 'int', 'YES', NULL);
    CALL academic_history_assert_column_v1('student_academic_records', 'section_id', 'int', 'YES', NULL);
    CALL academic_history_assert_column_v1('student_academic_records', 'roll_no', 'int', 'YES', NULL);
    CALL academic_history_assert_column_v1('student_academic_records', 'registration_no', 'varchar(50)', 'YES', 'utf8mb4_general_ci');
    CALL academic_history_assert_column_v1('student_academic_records', 'admission_date', 'date', 'YES', NULL);
    CALL academic_history_assert_column_v1('student_academic_records', 'promoted_date', 'date', 'YES', NULL);
    CALL academic_history_assert_column_v1('student_academic_records', 'status', 'varchar(10)', 'YES', 'utf8mb4_general_ci');
    CALL academic_history_assert_column_v1('student_academic_records', 'custom_class_fee', 'decimal(10,2)', 'NO', NULL);
    CALL academic_history_assert_column_v1('student_academic_records', 'section_scope', 'int', 'YES', NULL);
    CALL academic_history_assert_column_v1('student_academic_records', 'created_at', 'timestamp', 'NO', NULL);
    CALL academic_history_assert_column_v1('student_academic_records', 'updated_at', 'timestamp', 'NO', NULL);
    SELECT COUNT(*), MAX(TABLE_COMMENT) INTO v_count, v_table_comment FROM information_schema.TABLES
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'student_academic_records'
       AND ENGINE = 'InnoDB' AND TABLE_TYPE = 'BASE TABLE';
    IF v_count <> 1 OR v_table_comment <> 'school-academic-history-v1:records' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Conflicting student_academic_records table; do not replace it.';
    END IF;
    SELECT COUNT(*) INTO v_count FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'student_academic_records';
    IF v_count <> 14 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Unexpected academic record columns; review partial schema.';
    END IF;
    SELECT GENERATION_EXPRESSION INTO v_expression FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'student_academic_records' AND COLUMN_NAME = 'section_scope'
       AND EXTRA LIKE '%STORED GENERATED%';
    SET v_expression = REPLACE(REPLACE(REPLACE(REPLACE(LOWER(COALESCE(v_expression, '')), '`', ''), ' ', ''), '(', ''), ')', '');
    IF v_expression <> 'coalescesection_id,0' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'History section_scope must be STORED generated COALESCE(section_id,0); conflicting schema.';
    END IF;
    SELECT COUNT(*) INTO v_count FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'student_academic_records'
       AND COLUMN_NAME = 'id' AND EXTRA LIKE '%auto_increment%';
    IF v_count <> 1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Academic record id must be AUTO_INCREMENT.';
    END IF;
    CALL academic_history_assert_index_v1('student_academic_records', 'PRIMARY', 'id', 1);
    CALL academic_history_assert_index_v1('student_academic_records', 'uq_student_academic_year', 'student_row_id,academic_year', 1);
    CALL academic_history_assert_index_v1('student_academic_records', 'uq_academic_roll', 'academic_year,class_id,section_scope,roll_no', 1);
    CALL academic_history_assert_index_v1('student_academic_records', 'idx_academic_class', 'class_id', 0);
    CALL academic_history_assert_index_v1('student_academic_records', 'idx_academic_section', 'section_id', 0);
    CALL academic_history_assert_index_v1('student_academic_records', 'idx_academic_registration', 'academic_year,registration_no', 0);
    CALL academic_history_assert_index_v1('student_academic_records', 'idx_academic_year_status', 'academic_year,status', 0);
    CALL academic_history_assert_fk_v1('fk_academic_student_row', 'student_row_id', 'students', 'id');
    CALL academic_history_assert_fk_v1('fk_academic_class', 'class_id', 'classes', 'id');
    CALL academic_history_assert_fk_v1('fk_academic_section', 'section_id', 'sections', 'id');
    SELECT COUNT(*) INTO v_count FROM information_schema.REFERENTIAL_CONSTRAINTS
     WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = 'student_academic_records';
    IF v_count <> 3 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Unexpected extra academic record foreign keys; review partial schema.';
    END IF;
    SELECT COUNT(DISTINCT INDEX_NAME) INTO v_count FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'student_academic_records';
    IF v_count <> 7 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Unexpected extra academic record indexes; do not accept unreviewed uniqueness rules.';
    END IF;

    -- Completed reruns validate structure but NEVER compare/reseed evolved data.
    IF v_phase = 'complete' THEN
        CALL academic_history_assert_index_v1('students', 'idx_students_academic_class', 'class_id', 0);
        SELECT COUNT(*) INTO v_count FROM information_schema.STATISTICS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'students' AND INDEX_NAME = 'unique_roll';
        IF v_count <> 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Legacy global roll index reappeared after migration completion; review deployment.';
        END IF;
        SELECT COUNT(*) INTO v_count FROM student_academic_legacy_snapshot;
        IF v_count <> v_saved_rows THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Immutable snapshot row count changed after completion; investigate instead of recapturing.';
        END IF;
        IF v_sql_mode_changed = 1 THEN
            BEGIN
                DECLARE CONTINUE HANDLER FOR 3135 BEGIN END;
                SET SESSION sql_mode = v_original_sql_mode;
            END;
            SET v_sql_mode_changed = 0;
        END IF;
        DO RELEASE_LOCK(v_lock_name);
        SET v_lock = 0;
        SELECT v_version AS migration_key, 'already_complete' AS migration_status,
               v_saved_rows AS original_snapshot_rows;
        LEAVE migration;
    END IF;

    -- Snapshot and its checkpoint commit together. Never amend or append to a
    -- saved baseline when resuming, even if students have changed since then.
    IF v_phase IS NULL THEN
        START TRANSACTION;
        SELECT COUNT(*) INTO v_count FROM student_academic_legacy_snapshot;
        IF v_count <> 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Snapshot rows exist without a checkpoint; manual review required, never overwrite them.';
        END IF;
        SELECT COUNT(*) INTO v_count FROM student_academic_records;
        IF v_count <> 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Academic rows exist without a migration checkpoint; automatic merge refused.';
        END IF;
        SELECT COUNT(*) INTO v_source_rows FROM students;
        INSERT INTO student_academic_legacy_snapshot
            (student_row_id, student_id, academic_year, class_id, section_id, roll_no, registration_no,
             admission_date, promoted_date, status, custom_class_fee, source_updated_at)
        SELECT id, student_id, academic_year, class_id, section_id, roll_no, registration_no,
               admission_date, promoted_date, status, custom_class_fee, updated_at
          FROM students ORDER BY id;
        SELECT COUNT(*) INTO v_count FROM student_academic_legacy_snapshot;
        IF v_count <> v_source_rows THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Snapshot coverage mismatch; transaction rolled back, original rows preserved.';
        END IF;
        INSERT INTO academic_schema_migrations (migration_key, phase, source_rows)
        VALUES (v_version, 'snapshot', v_source_rows);
        COMMIT;
        SET v_phase = 'snapshot';
        SET v_saved_rows = v_source_rows;
    END IF;

    -- Detect accidental writes during a partial deployment. Binary comparison
    -- also detects changes only in case or trailing spaces in raw string values.
    SELECT COUNT(*) INTO v_count FROM student_academic_legacy_snapshot;
    IF v_count <> v_saved_rows THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Snapshot coverage differs from checkpoint; manual review required.';
    END IF;
    SELECT COUNT(*) INTO v_count FROM students;
    IF v_count <> v_saved_rows THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Students changed since snapshot. Keep maintenance mode on; review before resuming.';
    END IF;
    SELECT COUNT(*) INTO v_count
      FROM student_academic_legacy_snapshot AS l LEFT JOIN students AS s ON s.id = l.student_row_id
     WHERE s.id IS NULL OR NOT (BINARY s.student_id <=> BINARY l.student_id)
        OR NOT (BINARY s.academic_year <=> BINARY l.academic_year)
        OR NOT (s.class_id <=> l.class_id) OR NOT (s.section_id <=> l.section_id)
        OR NOT (s.roll_no <=> l.roll_no) OR NOT (BINARY s.registration_no <=> BINARY l.registration_no)
        OR NOT (s.admission_date <=> l.admission_date) OR NOT (s.promoted_date <=> l.promoted_date)
        OR NOT (BINARY s.status <=> BINARY l.status) OR NOT (s.custom_class_fee <=> l.custom_class_fee)
        OR NOT (s.updated_at <=> l.source_updated_at);
    IF v_count <> 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Students no longer match the immutable snapshot. No automatic overwrite/reseed is permitted.';
    END IF;

    IF v_phase = 'snapshot' THEN
        START TRANSACTION;
        SELECT COUNT(*) INTO v_count FROM student_academic_records;
        IF v_count <> 0 THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'History rows exist before backfill checkpoint. Review; do not delete or INSERT IGNORE.';
        END IF;
        INSERT INTO student_academic_records
            (student_row_id, academic_year, class_id, section_id, roll_no, registration_no,
             admission_date, promoted_date, status, custom_class_fee)
        SELECT l.student_row_id,
               CASE WHEN l.academic_year IS NOT NULL AND CHAR_LENGTH(l.academic_year) = 4 AND l.academic_year REGEXP '^[0-9]{4}$' AND l.academic_year BETWEEN '2000' AND '2200' THEN l.academic_year ELSE NULL END,
               l.class_id, l.section_id, l.roll_no, l.registration_no,
               l.admission_date, l.promoted_date, l.status, l.custom_class_fee
          FROM student_academic_legacy_snapshot AS l ORDER BY l.student_row_id;
        SELECT COUNT(*) INTO v_count FROM student_academic_records;
        IF v_count <> v_saved_rows THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Backfill coverage mismatch; transaction rolled back, snapshot and original data preserved.';
        END IF;
        UPDATE academic_schema_migrations SET phase = 'backfilled' WHERE migration_key = v_version AND phase = 'snapshot';
        COMMIT;
        SET v_phase = 'backfilled';
    END IF;

    -- Coverage + null-safe value comparison, never just a row-count assertion.
    SELECT COUNT(*) INTO v_count FROM student_academic_records;
    IF v_count <> v_saved_rows THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Backfilled history changed before migration completion; manual review required.';
    END IF;
    SELECT COUNT(*) INTO v_count
      FROM student_academic_legacy_snapshot AS l
      LEFT JOIN student_academic_records AS a ON a.student_row_id = l.student_row_id
     WHERE a.id IS NULL
        OR NOT (a.academic_year <=> CASE WHEN l.academic_year IS NOT NULL AND CHAR_LENGTH(l.academic_year) = 4 AND l.academic_year REGEXP '^[0-9]{4}$' AND l.academic_year BETWEEN '2000' AND '2200' THEN l.academic_year ELSE NULL END)
        OR NOT (a.class_id <=> l.class_id) OR NOT (a.section_id <=> l.section_id)
        OR NOT (a.roll_no <=> l.roll_no) OR NOT (BINARY a.registration_no <=> BINARY l.registration_no)
        OR NOT (a.admission_date <=> l.admission_date) OR NOT (a.promoted_date <=> l.promoted_date)
        OR NOT (BINARY a.status <=> BINARY l.status) OR NOT (a.custom_class_fee <=> l.custom_class_fee);
    IF v_count <> 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Backfill values differ from snapshot; no completion marker written.';
    END IF;
    SELECT COUNT(*) INTO v_count FROM (
        SELECT student_row_id FROM student_academic_records GROUP BY student_row_id HAVING COUNT(*) <> 1
    ) AS duplicate_backfill;
    IF v_count <> 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Expected exactly one baseline academic record for every legacy student.';
    END IF;

    -- Preserve the class FK's supporting index before removing old roll scope.
    SELECT COUNT(*) INTO v_count FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'students' AND INDEX_NAME = 'idx_students_academic_class';
    IF v_count = 0 THEN
        ALTER TABLE students ADD KEY idx_students_academic_class (class_id);
    END IF;
    CALL academic_history_assert_index_v1('students', 'idx_students_academic_class', 'class_id', 0);
    SELECT COUNT(*) INTO v_count FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'students' AND INDEX_NAME = 'unique_roll';
    IF v_count <> 0 THEN
        CALL academic_history_assert_index_v1('students', 'unique_roll', 'class_id,section_id,roll_no', 1);
        ALTER TABLE students DROP INDEX unique_roll;
    END IF;
    -- student_academic_records owns roll uniqueness; the materialized students
    -- compatibility cache must not impose a second global uniqueness rule.
    -- Existing student_id and banglar_shiksha_code uniqueness remains untouched.

    START TRANSACTION;
    UPDATE academic_schema_migrations SET phase = 'complete', completed_at = CURRENT_TIMESTAMP
     WHERE migration_key = v_version AND phase = 'backfilled';
    COMMIT;
    IF v_sql_mode_changed = 1 THEN
        BEGIN
            DECLARE CONTINUE HANDLER FOR 3135 BEGIN END;
            SET SESSION sql_mode = v_original_sql_mode;
        END;
        SET v_sql_mode_changed = 0;
    END IF;
    DO RELEASE_LOCK(v_lock_name);
    SET v_lock = 0;
    SELECT v_version AS migration_key, 'complete' AS migration_status,
           v_saved_rows AS preserved_student_rows,
           (SELECT COUNT(*) FROM student_academic_records WHERE academic_year IS NULL) AS unresolved_year_records;
END$$

CALL academic_history_migrate_v1()$$

DROP PROCEDURE IF EXISTS academic_history_migrate_v1$$
DROP PROCEDURE IF EXISTS academic_history_assert_fk_v1$$
DROP PROCEDURE IF EXISTS academic_history_assert_index_v1$$
DROP PROCEDURE IF EXISTS academic_history_assert_column_v1$$

DELIMITER ;

-- Successful deployment requires phase='complete' for this exact version.
-- No current year, exam year, or first-admission date is inferred or activated.
SELECT migration_key, phase, source_rows, snapshot_at, completed_at
  FROM academic_schema_migrations
 WHERE migration_key = '20260921_01_student_academic_history';

-- BEGIN approved legacy year 2026 follow-up
-- User-approved correction: unresolved PRE-UPGRADE enrollments belong to 2026.
-- Separate version allows this to run after an already-completed v1 migration.
-- Original snapshot, verified years, new students and financial rows are retained.
DELIMITER $$

DROP PROCEDURE IF EXISTS academic_history_legacy_year_2026_v2$$
CREATE PROCEDURE academic_history_legacy_year_2026_v2()
SQL SECURITY INVOKER
correction: BEGIN
    DECLARE v_version VARCHAR(100) DEFAULT '20260927_02_legacy_year_2026';
    DECLARE v_phase VARCHAR(20);
    DECLARE v_count BIGINT DEFAULT 0;
    DECLARE v_target_rows BIGINT UNSIGNED DEFAULT 0;
    DECLARE v_temp_created TINYINT DEFAULT 0;
    DECLARE v_settings_id INT DEFAULT NULL;
    DECLARE v_current_year VARCHAR(20) DEFAULT NULL;
    DECLARE v_lock_name VARCHAR(64);
    DECLARE v_lock INT DEFAULT 0;
    DECLARE v_original_sql_mode TEXT DEFAULT NULL;
    DECLARE v_copy_sql_mode TEXT;
    DECLARE v_sql_mode_changed TINYINT DEFAULT 0;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        IF v_sql_mode_changed = 1 THEN
            BEGIN
                DECLARE CONTINUE HANDLER FOR 3135 BEGIN END;
                SET SESSION sql_mode = v_original_sql_mode;
            END;
        END IF;
        IF v_temp_created = 1 THEN
            DROP TEMPORARY TABLE academic_legacy_year_targets_v2;
            SET v_temp_created = 0;
        END IF;
        IF v_lock = 1 THEN DO RELEASE_LOCK(v_lock_name); END IF;
        RESIGNAL;
    END;
    DECLARE EXIT HANDLER FOR SQLWARNING
    BEGIN
        ROLLBACK;
        IF v_sql_mode_changed = 1 THEN
            BEGIN
                DECLARE CONTINUE HANDLER FOR 3135 BEGIN END;
                SET SESSION sql_mode = v_original_sql_mode;
            END;
        END IF;
        IF v_temp_created = 1 THEN
            DROP TEMPORARY TABLE academic_legacy_year_targets_v2;
            SET v_temp_created = 0;
        END IF;
        IF v_lock = 1 THEN DO RELEASE_LOCK(v_lock_name); END IF;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Legacy year correction stopped on SQL warning; all correction writes rolled back.';
    END;

    SET v_original_sql_mode = @@SESSION.sql_mode;
    IF DATABASE() IS NULL OR @@foreign_key_checks <> 1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Legacy year correction requires the selected school database and enabled foreign keys.';
    END IF;
    SET v_lock_name = CONCAT('school-academic-v1:', LEFT(SHA2(DATABASE(), 256), 32));
    SET v_lock = GET_LOCK(v_lock_name, 0);
    IF NOT (v_lock <=> 1) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Another academic migration holds the database migration lock.';
    END IF;
    SELECT COUNT(*) INTO v_count FROM academic_schema_migrations
     WHERE migration_key = '20260921_01_student_academic_history' AND phase = 'complete';
    IF v_count <> 1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Complete the academic history schema migration before applying the legacy 2026 correction.';
    END IF;
    SELECT MAX(phase) INTO v_phase FROM academic_schema_migrations WHERE migration_key = v_version;
    IF v_phase = 'complete' THEN
        DO RELEASE_LOCK(v_lock_name);
        SET v_lock = 0;
        SELECT v_version AS migration_key, 'already_complete' AS migration_status;
        LEAVE correction;
    END IF;
    IF v_phase IS NOT NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Unexpected legacy-year correction checkpoint; inspect it without overwriting.';
    END IF;

    -- Use a fresh import connection. Do not issue a missing-table DROP that
    -- could produce a diagnostic before the temporary table has been created.
    CREATE TEMPORARY TABLE academic_legacy_year_targets_v2 (
        academic_record_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
        student_row_id INT NOT NULL,
        projected_record_id BIGINT UNSIGNED NULL,
        UNIQUE KEY uq_legacy_year_target_student (student_row_id)
    ) ENGINE=InnoDB;
    SET v_temp_created = 1;

    START TRANSACTION;
    -- Share the application's academic-writer row lock during the correction.
    BEGIN
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_settings_id = NULL;
        SELECT id, current_academic_year INTO v_settings_id, v_current_year
          FROM school_settings ORDER BY id LIMIT 1 FOR UPDATE;
    END;
    IF CHAR_LENGTH(v_current_year) = 0 THEN SET v_current_year = NULL; END IF;
    IF v_current_year IS NOT NULL THEN
        SET v_current_year = TRIM(v_current_year);
        IF CHAR_LENGTH(v_current_year) <> 4 OR v_current_year NOT REGEXP '^[0-9]{4}$'
           OR v_current_year NOT BETWEEN '2000' AND '2200' THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Review the configured current academic year before applying the legacy correction.';
        END IF;
    END IF;

    -- Only still-unresolved records of students captured in the old snapshot.
    -- An operator's already-resolved year is not overwritten on a later import.
    SELECT COUNT(*) INTO v_count FROM (
        SELECT a.student_row_id
          FROM student_academic_records a
          JOIN student_academic_legacy_snapshot l ON l.student_row_id = a.student_row_id
         WHERE a.academic_year IS NULL AND (l.academic_year IS NULL OR NOT (
             CHAR_LENGTH(l.academic_year) = 4 AND l.academic_year REGEXP '^[0-9]{4}$'
             AND l.academic_year BETWEEN '2000' AND '2200'))
         GROUP BY a.student_row_id HAVING COUNT(*) > 1
    ) AS ambiguous_legacy_rows;
    IF v_count <> 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Multiple unresolved records exist for a legacy student; no records were merged or removed.';
    END IF;
    INSERT INTO academic_legacy_year_targets_v2 (academic_record_id, student_row_id)
    SELECT a.id, a.student_row_id FROM student_academic_records a
      JOIN student_academic_legacy_snapshot l ON l.student_row_id = a.student_row_id
     WHERE a.academic_year IS NULL AND (l.academic_year IS NULL OR NOT (
         CHAR_LENGTH(l.academic_year) = 4 AND l.academic_year REGEXP '^[0-9]{4}$'
         AND l.academic_year BETWEEN '2000' AND '2200'));
    SELECT COUNT(*) INTO v_target_rows FROM academic_legacy_year_targets_v2;
    SELECT COUNT(*) INTO v_count FROM academic_legacy_year_targets_v2 t
      JOIN student_academic_records a ON a.student_row_id = t.student_row_id AND a.academic_year = '2026';
    IF v_count <> 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A legacy student already has a 2026 enrollment; review both records before resolving the unknown year.';
    END IF;
    SELECT COUNT(*) INTO v_count FROM (
        SELECT a.class_id, COALESCE(a.section_id, 0), a.roll_no
          FROM student_academic_records a
          LEFT JOIN academic_legacy_year_targets_v2 t ON t.academic_record_id = a.id
         WHERE (a.academic_year = '2026' OR t.academic_record_id IS NOT NULL)
           AND a.class_id IS NOT NULL AND a.roll_no IS NOT NULL
         GROUP BY a.class_id, COALESCE(a.section_id, 0), a.roll_no HAVING COUNT(*) > 1
    ) AS conflicting_2026_rolls;
    IF v_count <> 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Assigning legacy years to 2026 would duplicate a class/section/roll; no rows were changed.';
    END IF;

    -- Do not overwrite cache-only edits made by old code after schema migration.
    -- Every affected profile must still be represented by a canonical record;
    -- a raw unknown master year may match its NULL-year legacy baseline.
    SELECT COUNT(*) INTO v_count FROM academic_legacy_year_targets_v2 t
      JOIN students s ON s.id = t.student_row_id
     WHERE NOT EXISTS (
        SELECT 1 FROM student_academic_records a WHERE a.student_row_id = s.id
          AND ((BINARY a.academic_year <=> BINARY s.academic_year) OR (a.id = t.academic_record_id AND (
              s.academic_year IS NULL OR NOT (CHAR_LENGTH(s.academic_year) = 4
              AND s.academic_year REGEXP '^[0-9]{4}$' AND s.academic_year BETWEEN '2000' AND '2200'))))
          AND (a.class_id <=> s.class_id) AND (a.section_id <=> s.section_id)
          AND (a.roll_no <=> s.roll_no) AND (BINARY a.registration_no <=> BINARY s.registration_no)
          AND (a.admission_date <=> s.admission_date) AND (a.promoted_date <=> s.promoted_date)
          AND (a.custom_class_fee <=> s.custom_class_fee)
          AND ((BINARY a.status <=> BINARY s.status)
               OR (BINARY LOWER(a.status) = BINARY 'active' AND BINARY s.status IN (BINARY 'Upcoming', BINARY 'Unassigned')))
     );
    IF v_count <> 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A legacy profile has edits missing from academic history; review before the 2026 correction.';
    END IF;

    -- Permit only exact copies of existing zero dates when refreshing the cache.
    -- No new date is invented; retain strictness and restore the procedure mode.
    SET v_copy_sql_mode = TRIM(BOTH ',' FROM REPLACE(REPLACE(REPLACE(
        CONCAT(',', v_original_sql_mode, ','), ',NO_ZERO_DATE,', ','),
        ',NO_ZERO_IN_DATE,', ','), ',TRADITIONAL,', ','));
    IF v_copy_sql_mode <> v_original_sql_mode THEN
        SET v_sql_mode_changed = 1;
        BEGIN
            DECLARE CONTINUE HANDLER FOR 3135 BEGIN END;
            SET SESSION sql_mode = v_copy_sql_mode;
        END;
    END IF;
    IF FIND_IN_SET('NO_ZERO_DATE', @@SESSION.sql_mode) > 0
       OR FIND_IN_SET('NO_ZERO_IN_DATE', @@SESSION.sql_mode) > 0
       OR (FIND_IN_SET('STRICT_TRANS_TABLES', v_original_sql_mode) > 0
           AND FIND_IN_SET('STRICT_TRANS_TABLES', @@SESSION.sql_mode) = 0)
       OR (FIND_IN_SET('STRICT_ALL_TABLES', v_original_sql_mode) > 0
           AND FIND_IN_SET('STRICT_ALL_TABLES', @@SESSION.sql_mode) = 0) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot preserve legacy dates under the required correction SQL mode.';
    END IF;
    UPDATE student_academic_records a JOIN academic_legacy_year_targets_v2 t ON t.academic_record_id = a.id
       SET a.academic_year = '2026'
     WHERE a.academic_year IS NULL;
    IF ROW_COUNT() <> v_target_rows THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Legacy year correction coverage changed; all correction writes rolled back.';
    END IF;

    -- Match configured academicProjection: current enrollment, next active enrollment,
    -- latest past enrollment, then earliest known enrollment. With no configured
    -- school year, retain a known cached year. For the original unknown cache,
    -- the user's explicit correction establishes its 2026 baseline first.
    UPDATE academic_legacy_year_targets_v2 t JOIN students s ON s.id = t.student_row_id
       SET t.projected_record_id = CASE WHEN v_current_year IS NULL THEN COALESCE(
           (SELECT a.id FROM student_academic_records a WHERE a.student_row_id = t.student_row_id
             AND BINARY a.academic_year = BINARY s.academic_year ORDER BY a.id LIMIT 1), t.academic_record_id)
       ELSE COALESCE(
           (SELECT a.id FROM student_academic_records a WHERE a.student_row_id = t.student_row_id
             AND a.academic_year = v_current_year ORDER BY a.id LIMIT 1),
           (SELECT a.id FROM student_academic_records a WHERE a.student_row_id = t.student_row_id
             AND a.academic_year > v_current_year AND BINARY LOWER(a.status) = BINARY 'active' ORDER BY a.academic_year, a.id LIMIT 1),
           (SELECT a.id FROM student_academic_records a WHERE a.student_row_id = t.student_row_id
             AND a.academic_year < v_current_year ORDER BY a.academic_year DESC, a.id DESC LIMIT 1),
           (SELECT a.id FROM student_academic_records a WHERE a.student_row_id = t.student_row_id
             AND a.academic_year IS NOT NULL ORDER BY a.academic_year, a.id LIMIT 1)) END;
    SELECT COUNT(*) INTO v_count FROM academic_legacy_year_targets_v2 WHERE projected_record_id IS NULL;
    IF v_count <> 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Could not select an enrollment for a corrected legacy profile; transaction rolled back.';
    END IF;
    UPDATE students s
      JOIN academic_legacy_year_targets_v2 t ON t.student_row_id = s.id
      JOIN student_academic_records a ON a.id = t.projected_record_id AND a.student_row_id = s.id
       SET s.academic_year = a.academic_year, s.class_id = a.class_id, s.section_id = a.section_id,
           s.roll_no = a.roll_no, s.registration_no = a.registration_no,
           s.admission_date = a.admission_date, s.promoted_date = a.promoted_date,
           s.custom_class_fee = a.custom_class_fee,
           s.status = CASE WHEN v_current_year IS NOT NULL AND BINARY LOWER(a.status) = BINARY 'active' THEN
               CASE WHEN a.academic_year > v_current_year THEN 'Upcoming'
                    WHEN a.academic_year < v_current_year THEN 'Unassigned' ELSE a.status END
               ELSE a.status END;
    -- Compare the refreshed cache against the chosen canonical enrollment.
    SELECT COUNT(*) INTO v_count FROM academic_legacy_year_targets_v2 t
      JOIN students s ON s.id = t.student_row_id
      JOIN student_academic_records a ON a.id = t.projected_record_id
     WHERE NOT (s.academic_year <=> a.academic_year)
        OR NOT (s.class_id <=> a.class_id) OR NOT (s.section_id <=> a.section_id)
        OR NOT (s.roll_no <=> a.roll_no) OR NOT (BINARY s.registration_no <=> BINARY a.registration_no)
        OR NOT (s.admission_date <=> a.admission_date) OR NOT (s.promoted_date <=> a.promoted_date)
        OR NOT (s.custom_class_fee <=> a.custom_class_fee)
        OR NOT (BINARY s.status <=> BINARY (CASE WHEN v_current_year IS NOT NULL AND BINARY LOWER(a.status) = BINARY 'active' THEN
            CASE WHEN a.academic_year > v_current_year THEN 'Upcoming'
                 WHEN a.academic_year < v_current_year THEN 'Unassigned' ELSE a.status END ELSE a.status END));
    IF v_count <> 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Corrected profiles differ from canonical records; all correction writes rolled back.';
    END IF;
    INSERT INTO academic_schema_migrations (migration_key, phase, source_rows, completed_at)
    VALUES (v_version, 'complete', v_target_rows, CURRENT_TIMESTAMP);
    IF v_sql_mode_changed = 1 THEN
        BEGIN
            DECLARE CONTINUE HANDLER FOR 3135 BEGIN END;
            SET SESSION sql_mode = v_original_sql_mode;
        END;
        SET v_sql_mode_changed = 0;
    END IF;
    COMMIT;
    DROP TEMPORARY TABLE academic_legacy_year_targets_v2;
    SET v_temp_created = 0;
    DO RELEASE_LOCK(v_lock_name);
    SET v_lock = 0;
    SELECT v_version AS migration_key, 'complete' AS migration_status,
           v_target_rows AS legacy_records_assigned_to_2026;
END$$

CALL academic_history_legacy_year_2026_v2()$$
DROP PROCEDURE academic_history_legacy_year_2026_v2$$
DELIMITER ;
SELECT migration_key, phase, source_rows, completed_at FROM academic_schema_migrations
 WHERE migration_key = '20260927_02_legacy_year_2026';
-- END approved legacy year 2026 follow-up


-- BEGIN admission enquiry year/photo follow-up (20260927_03)
-- MANUAL EXECUTION ONLY. Apply before deploying the updated enquiry form.
-- This block may also be run by itself on an already upgraded installation.
-- Adds nullable fields without assigning guessed years/photos to older enquiries.
-- Widens the enquiry PIN field to allow a six-digit PIN; no existing value changes.
-- Rerunnable after partial DDL completion. Stop application writes while applying.
DELIMITER $$
DROP PROCEDURE IF EXISTS admission_enquiry_year_photo_v3$$
CREATE PROCEDURE admission_enquiry_year_photo_v3()
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.TABLES
                   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'admission_enquiries') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Admission enquiries table is missing; select the correct database.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
                   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'admission_enquiries' AND COLUMN_NAME = 'academic_year') THEN
        ALTER TABLE admission_enquiries ADD COLUMN academic_year VARCHAR(20) NULL DEFAULT NULL;
    ELSEIF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
                      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'admission_enquiries' AND COLUMN_NAME = 'academic_year'
                        AND DATA_TYPE = 'varchar' AND CHARACTER_MAXIMUM_LENGTH >= 20 AND IS_NULLABLE = 'YES') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Review the existing admission_enquiries.academic_year column; it was not changed.';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
                   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'admission_enquiries' AND COLUMN_NAME = 'student_image') THEN
        ALTER TABLE admission_enquiries ADD COLUMN student_image VARCHAR(255) NULL DEFAULT NULL;
    ELSEIF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
                      WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'admission_enquiries' AND COLUMN_NAME = 'student_image'
                        AND DATA_TYPE = 'varchar' AND CHARACTER_MAXIMUM_LENGTH >= 255 AND IS_NULLABLE = 'YES') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Review the existing admission_enquiries.student_image column; it was not changed.';
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.COLUMNS
               WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'admission_enquiries' AND COLUMN_NAME = 'pin_code'
                 AND DATA_TYPE = 'varchar' AND CHARACTER_MAXIMUM_LENGTH < 10) THEN
        ALTER TABLE admission_enquiries MODIFY COLUMN pin_code VARCHAR(10)
            CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL, ALGORITHM=INPLACE;
    END IF;
    IF EXISTS (SELECT 1 FROM information_schema.TABLES
               WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'academic_schema_migrations') THEN
        INSERT INTO academic_schema_migrations (migration_key, phase, source_rows, completed_at)
        SELECT '20260927_03_admission_enquiry', 'complete', COUNT(*), CURRENT_TIMESTAMP FROM admission_enquiries
        ON DUPLICATE KEY UPDATE phase = 'complete', completed_at = COALESCE(completed_at, CURRENT_TIMESTAMP);
    END IF;
    SELECT '20260927_03_admission_enquiry' AS migration_key, 'complete' AS migration_status;
END$$
CALL admission_enquiry_year_photo_v3()$$
DROP PROCEDURE admission_enquiry_year_photo_v3$$
DELIMITER ;
-- END admission enquiry year/photo follow-up
