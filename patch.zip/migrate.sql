-- Native parent-app monthly/admission fee payments.
-- Review and run manually before deploying the new fee-payment API.
-- Existing fee, receipt, and payment-history tables are unchanged.
CREATE TABLE IF NOT EXISTS online_fee_payment_orders (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    student_id VARCHAR(100) NOT NULL,
    parent_phone VARCHAR(30) NOT NULL,
    fee_type VARCHAR(20) NOT NULL,
    fee_id BIGINT UNSIGNED NOT NULL,
    fee_snapshot LONGTEXT NOT NULL,
    fee_paise BIGINT UNSIGNED NOT NULL,
    gateway_charge_paise BIGINT UNSIGNED NOT NULL,
    gst_paise BIGINT UNSIGNED NOT NULL,
    total_paise BIGINT UNSIGNED NOT NULL,
    gateway_percentage DECIMAL(10,4) NOT NULL,
    gst_percentage DECIMAL(10,4) NOT NULL,
    razorpay_order_id VARCHAR(100) NOT NULL,
    razorpay_payment_id VARCHAR(100) DEFAULT NULL,
    payment_status VARCHAR(20) NOT NULL DEFAULT 'pending',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_fee_razorpay_order (razorpay_order_id),
    UNIQUE KEY uq_fee_razorpay_payment (razorpay_payment_id),
    KEY idx_fee_pending (student_id, fee_type, fee_id, payment_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Online Store orders: preserve the product subtotal and checkout charge snapshot.
-- Run this ALTER once. If the native-fee migration was already applied, run only
-- this new section. Do not backfill/reprice existing orders: NULL subtotal means
-- their original total is still the product amount, with no added charges.
ALTER TABLE inventory_orders
    ADD COLUMN subtotal_paise BIGINT UNSIGNED DEFAULT NULL,
    ADD COLUMN gateway_charge_paise BIGINT UNSIGNED NOT NULL DEFAULT 0,
    ADD COLUMN gst_paise BIGINT UNSIGNED NOT NULL DEFAULT 0,
    ADD COLUMN gateway_percentage DECIMAL(16,8) NOT NULL DEFAULT 0,
    ADD COLUMN gst_percentage DECIMAL(16,8) NOT NULL DEFAULT 0;
