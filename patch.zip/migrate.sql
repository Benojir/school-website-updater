-- 1. Make parent_id nullable so the old OTP login works without error.
-- (This is the fix that was applied directly to your local database)
ALTER TABLE `parent_auth_sessions` MODIFY `parent_id` INT NULL;

-- 2. Fix the missing default values for created_at and expires_at 
ALTER TABLE `parent_auth_sessions` MODIFY `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `parent_auth_sessions` MODIFY `expires_at` DATETIME NULL;

-- 2. Optional: Since you mentioned you will be removing parent accounts very soon, 
-- you can run the following commands when you are ready to completely remove the logic:

-- Drop the parent_id column from the sessions table
-- ALTER TABLE `parent_auth_sessions` DROP COLUMN `parent_id`;

-- Drop the parent_accounts table entirely
-- DROP TABLE IF EXISTS `parent_accounts`;
