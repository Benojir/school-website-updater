-- Migration: Rename student_attendance_app_link to teacher_app_link in apps_link JSON
UPDATE `school_information` 
SET `apps_link` = REPLACE(`apps_link`, 'student_attendance_app_link', 'teacher_app_link') 
WHERE `apps_link` LIKE '%student_attendance_app_link%';
