ALTER TABLE `school_information`
  ADD COLUMN `headmaster_name` VARCHAR(100) NULL AFTER `principal_email`,
  ADD COLUMN `headmaster_phone` VARCHAR(20) NULL AFTER `headmaster_name`,
  ADD COLUMN `headmaster_email` VARCHAR(100) NULL AFTER `headmaster_phone`;
