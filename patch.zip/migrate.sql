-- Migration: Add Trust Registration Number and School Registration Number to school_information table
ALTER TABLE `school_information`
ADD COLUMN `trust_registration_number` VARCHAR(255) NULL DEFAULT NULL AFTER `foundation_name`,
ADD COLUMN `school_registration_number` VARCHAR(255) NULL DEFAULT NULL AFTER `trust_registration_number`;
