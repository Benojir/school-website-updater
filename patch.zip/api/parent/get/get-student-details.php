<?php
// Set header to return JSON
header('Content-Type: application/json');

include_once("../../../includes/config.php");
include_once("../../../includes/permission-check.php");
include_once("../../../includes/db.php"); // Assuming your PDO is here

// --- Response Object ---
$response = [
    'success' => false,
    'message' => 'An error occurred.',
    'data' => null
];

// --- Input Validation ---
if (!isset($_GET['student_id'])) {
    $response['message'] = 'Student ID not provided.';
    echo json_encode($response);
    exit;
}
$student_id = $_GET['student_id'];

// --- Permission Check ---
$is_admin = isLoggedIn() && (hasPermission(PERM_MANAGE_EXAMS) || hasPermission(PERM_MANAGE_STUDENTS) || hasPermission(PERM_MANAGE_FEES));
$is_parent = isParentAuthenticated() && hasParentAccessPermission($student_id);

if (!$is_admin && !$is_parent) {
    $response['message'] = 'You do not have permission to view this information.';
    echo json_encode($response);
    exit;
}

try {
    // --- Data Fetching ---
    $data = [];

    // Get student details
    $stmt = $pdo->prepare("
        SELECT s.*, c.class_name, sc.section_name
        FROM students s
        LEFT JOIN classes c ON s.class_id = c.id
        LEFT JOIN sections sc ON s.section_id = sc.id
        WHERE s.student_id = :student_id
    ");
    $stmt->execute([':student_id' => $student_id]);
    $data['student'] = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$data['student']) {
        $response['message'] = 'Student not found.';
        echo json_encode($response);
        exit;
    }

    // Get all monthly fees (paid and unpaid) in one go
    $stmt_unpaid_monthly = $pdo->prepare("SELECT * FROM student_unpaid_fees WHERE student_id = ? ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC");
    $stmt_unpaid_monthly->execute([$student_id]);
    $data['fees']['monthly']['unpaid'] = $stmt_unpaid_monthly->fetchAll(PDO::FETCH_ASSOC);

    $stmt_paid_monthly = $pdo->prepare("SELECT * FROM student_full_paid_fees WHERE student_id = ? ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC");
    $stmt_paid_monthly->execute([$student_id]);
    $data['fees']['monthly']['paid'] = $stmt_paid_monthly->fetchAll(PDO::FETCH_ASSOC);

    // Get all admission fees (paid and unpaid)
    $stmt_unpaid_admission = $pdo->prepare("SELECT * FROM admission_unpaid_fees WHERE student_id = ? ORDER BY academic_year ASC");
    $stmt_unpaid_admission->execute([$student_id]);
    $data['fees']['admission']['unpaid'] = $stmt_unpaid_admission->fetchAll(PDO::FETCH_ASSOC);

    $stmt_paid_admission = $pdo->prepare("SELECT * FROM admission_full_paid_fees WHERE student_id = ? ORDER BY academic_year ASC");
    $stmt_paid_admission->execute([$student_id]);
    $data['fees']['admission']['paid'] = $stmt_paid_admission->fetchAll(PDO::FETCH_ASSOC);
    // NOTE: Partial payments can also be fetched more efficiently, but for simplicity, we'll keep the logic similar.
    // For a real-world high-performance app, you'd use JOINs or IN clauses.

    // Get Wallet Info
    $wallet_stmt = $pdo->prepare("SELECT balance FROM student_wallet WHERE student_id = ?");
    $wallet_stmt->execute([$student_id]);
    $wallet = $wallet_stmt->fetch(PDO::FETCH_ASSOC);
    $data['wallet']['balance'] = $wallet ? (float)$wallet['balance'] : 0;

    $trans_stmt = $pdo->prepare("SELECT * FROM wallet_transactions WHERE student_id = ? ORDER BY created_at DESC LIMIT 10");
    $trans_stmt->execute([$student_id]);
    $data['wallet']['transactions'] = $trans_stmt->fetchAll(PDO::FETCH_ASSOC);

    // --- Calculations ---
    $total_unpaid = 0;
    foreach ($data['fees']['monthly']['unpaid'] as $fee) {
        $total_unpaid += $fee['unpaid_amount'];
    }
    foreach ($data['fees']['admission']['unpaid'] as $fee) {
        $total_unpaid += $fee['unpaid_amount'];
    }
    $data['fees']['summary']['total_unpaid'] = $total_unpaid;
    $all_fees_paid = ($total_unpaid <= 0);

    // --- Permissions Logic ---
    $perm_stmt = $pdo->prepare("SELECT * FROM student_permissions WHERE student_id = ?");
    $perm_stmt->execute([$student_id]);
    $permissions = $perm_stmt->fetch(PDO::FETCH_ASSOC);

    $data['permissions']['can_download_admit'] = $all_fees_paid;
    $data['permissions']['can_download_marksheet'] = $all_fees_paid;
    $data['permissions']['admit_override_active'] = false;
    $data['permissions']['marksheet_override_active'] = false;

    if ($permissions) {
        if ($permissions['override_admit_check']) {
            $data['permissions']['can_download_admit'] = (bool)$permissions['allow_admit_card'];
            $data['permissions']['admit_override_active'] = true;
        }
        if ($permissions['override_marksheet_check']) {
            $data['permissions']['can_download_marksheet'] = (bool)$permissions['allow_marksheet'];
            $data['permissions']['marksheet_override_active'] = true;
        }
    }

    // --- Final Response ---
    $response['success'] = true;
    $response['message'] = 'Data fetched successfully.';
    $response['data'] = $data;
    echo json_encode($response);
} catch (PDOException $e) {
    $response['message'] = 'Database Error: ' . $e->getMessage();
    echo json_encode($response);
    exit;
}
