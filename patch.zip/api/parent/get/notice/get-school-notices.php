<?php
include_once(__DIR__ . "/../../../../includes/config.php");

header('Content-Type: application/json');

try {
    // Get optional parameters for filtering
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
    $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
    $sort = isset($_GET['sort']) && in_array(strtolower($_GET['sort']), ['asc', 'desc']) 
             ? strtoupper($_GET['sort']) 
             : 'DESC';
    
    // Prepare and execute query
    $stmt = $pdo->prepare("
        SELECT 
            id,
            title,
            content,
            notice_date,
            created_at,
            updated_at
        FROM notices
        ORDER BY notice_date $sort, created_at $sort
        LIMIT :limit OFFSET :offset
    ");
    
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    
    $notices = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total count for pagination info
    $totalStmt = $pdo->query("SELECT COUNT(*) as total FROM notices");
    $total = $totalStmt->fetchColumn();
    
    // Format dates for better readability
    foreach ($notices as &$notice) {
        $notice['notice_date_formatted'] = date('d M Y', strtotime($notice['notice_date']));
        $notice['created_at_formatted'] = date('d M Y H:i', strtotime($notice['created_at']));
        $notice['updated_at_formatted'] = date('d M Y H:i', strtotime($notice['updated_at']));
    }
    
    // Return response
    echo json_encode([
        'success' => true,
        'data' => $notices,
        'meta' => [
            'total' => $total,
            'limit' => $limit,
            'offset' => $offset,
            'sort' => $sort
        ]
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}