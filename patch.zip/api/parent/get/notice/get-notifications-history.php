<?php
include_once(__DIR__ . "/../../../../includes/parent/parent-auth-check.php");

header('Content-Type: application/json');

$authData = authenticateApiRequest($pdo);
$phoneNumber = $authData['phone_number'];

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$resultsPerPage = isset($_GET['results_per_page']) ? (int)$_GET['results_per_page'] : 50;
$offset = ($page - 1) * $resultsPerPage;

// --- Step 1: Get all students for this parent in one query ---
// We create a map of [student_id => student_name] to use later.
// This is our *first* and only query for student data.
$sql = "SELECT student_id, name FROM students WHERE phone_number = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$phoneNumber]);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

$studentMap = [];
foreach ($students as $student) {
    // Store the formatted name directly
    $studentMap[$student['student_id']] = ucwords(strtolower($student['name']));
}
$parentStudentIds = array_keys($studentMap); // All student IDs for this parent

// If the parent has no students, return an empty array immediately.
if (count($parentStudentIds) === 0) {
    echo json_encode(['success' => true, 'data' => []], JSON_PRETTY_PRINT);
    exit;
}

// --- Step 2: Build one single query for all notifications ---
// We build a dynamic WHERE clause like: (FIND_IN_SET(?, student_ids) OR FIND_IN_SET(?, student_ids) ...)
$sqlWhere = implode(' OR ', array_fill(0, count($parentStudentIds), 'FIND_IN_SET(?, student_ids)'));

// The parameters for execute() will be the student IDs, followed by limit and offset
$params = $parentStudentIds;
$params[] = $resultsPerPage;
$params[] = $offset;

// This is our *second* and final query.
// It gets all notifications for *any* of the parent's students,
// sorted by date, with pagination applied correctly.
$sql = "SELECT 
            id, 
            notification_title, 
            notification_body, 
            created_at,
            student_ids AS all_recipient_ids 
        FROM mobile_notification_logs 
        WHERE ($sqlWhere)
        ORDER BY created_at DESC 
        LIMIT ? OFFSET ?";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

// --- Step 3: Process the results in PHP (no more DB queries) ---
$finalOutput = [];
foreach ($notifications as $notification) {

    // Format the created_at timestamp
    $notification['created_at'] = date('d M Y, h:i A', strtotime($notification['created_at']));

    // Get the full list of recipients for this one notification
    $allRecipientIds = explode(',', $notification['all_recipient_ids']);

    // Find the intersection: which of *this parent's students* are in the recipient list?
    $relevantStudentIds = array_intersect($allRecipientIds, $parentStudentIds);

    // Use our $studentMap to get the names for these relevant IDs
    $relevantStudentNames = [];
    foreach ($relevantStudentIds as $id) {
        if (isset($studentMap[$id])) {
            $relevantStudentNames[] = $studentMap[$id];
        }
    }

    // Add the parent-specific student lists to the final object
    $notification['student_ids'] = implode(',', $relevantStudentIds);
    $notification['student_names'] = implode(',', $relevantStudentNames);

    // Clean up the temporary field
    unset($notification['all_recipient_ids']);

    $finalOutput[] = $notification;
}

// --- Step 4: Return the final JSON ---
echo json_encode([
    'success' => true,
    'data' => $finalOutput
]);