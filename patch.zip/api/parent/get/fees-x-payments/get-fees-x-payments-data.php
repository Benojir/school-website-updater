<?php
include_once(__DIR__ . "/../../../../includes/db.php");

header('Content-Type: application/json');

// 1. GET AND VALIDATE PARAMETERS
$student_id = $_REQUEST['student_id'] ?? null;
$result_per_page = (int)($_REQUEST['result_per_page'] ?? 20);
$page = (int)($_REQUEST['page'] ?? 1);

if (empty($student_id)) {
    echo json_encode([
        "success" => false,
        "message" => "Missing required parameter: student_id."
    ]);
    exit();
}

if ($result_per_page <= 0 || $page <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid pagination parameters. 'page' and 'result_per_page' must be greater than 0."
    ]);
    exit();
}

// Calculate offset
$offset = ($page - 1) * $result_per_page;

// Initialize response containers
$response_data = [];
$grand_total_unpaid = 0;

try {

    // ----------------------------------------------------------------------
    // SECTION 1: MONTHLY FEES
    // ----------------------------------------------------------------------

    $monthly_total_unpaid = 0;

    // --- Monthly Unpaid Fees (with Pagination) ---
    $unpaid_count_stmt = $pdo->prepare("SELECT COUNT(*) FROM student_unpaid_fees WHERE student_id = ?");
    $unpaid_count_stmt->execute([$student_id]);
    $total_unpaid_records = (int)$unpaid_count_stmt->fetchColumn();
    $total_unpaid_pages = $total_unpaid_records > 0 ? ceil($total_unpaid_records / $result_per_page) : 1;

    $unpaid_stmt = $pdo->prepare("
        SELECT * FROM student_unpaid_fees 
        WHERE student_id = :student_id
        ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC 
        LIMIT :limit OFFSET :offset
    ");
    $unpaid_stmt->bindValue(':student_id', $student_id);
    $unpaid_stmt->bindValue(':limit', $result_per_page, PDO::PARAM_INT);
    $unpaid_stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $unpaid_stmt->execute();
    $unpaid_fees = $unpaid_stmt->fetchAll(PDO::FETCH_ASSOC);
    $unpaid_ids = array_column($unpaid_fees, 'id');

    // Fetch partial payments in a single query (N+1 Fix)
    $monthly_unpaid_payments_map = [];
    if (!empty($unpaid_ids)) {
        $stmt = $pdo->prepare("
            SELECT * FROM student_partial_payments 
            WHERE unpaid_fees_id IN (" . implode(',', array_fill(0, count($unpaid_ids), '?')) . ")
            ORDER BY created_at ASC
        ");
        $stmt->execute($unpaid_ids);
        $all_partial_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($all_partial_payments as $payment) {
            $monthly_unpaid_payments_map[$payment['unpaid_fees_id']][] = $payment;
        }
    }

    foreach ($unpaid_fees as &$unpaid_fee) {
        $monthly_total_unpaid += $unpaid_fee['unpaid_amount'];
        $unpaid_fee['partial_payments'] = $monthly_unpaid_payments_map[$unpaid_fee['id']] ?? [];
    }
    unset($unpaid_fee); // Unset reference
    $grand_total_unpaid += $monthly_total_unpaid; // Add to grand total

    // --- Monthly Paid Fees (with Pagination) ---
    $paid_count_stmt = $pdo->prepare("SELECT COUNT(*) FROM student_full_paid_fees WHERE student_id = ?");
    $paid_count_stmt->execute([$student_id]);
    $total_paid_records = (int)$paid_count_stmt->fetchColumn();
    $total_paid_pages = $total_paid_records > 0 ? ceil($total_paid_records / $result_per_page) : 1;

    $paid_stmt = $pdo->prepare("
        SELECT * FROM student_full_paid_fees 
        WHERE student_id = :student_id
        ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC 
        LIMIT :limit OFFSET :offset
    ");
    $paid_stmt->bindValue(':student_id', $student_id);
    $paid_stmt->bindValue(':limit', $result_per_page, PDO::PARAM_INT);
    $paid_stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $paid_stmt->execute();
    $paid_fees = $paid_stmt->fetchAll(PDO::FETCH_ASSOC);
    $paid_ids = array_column($paid_fees, 'id');

    // Fetch partial payments in a single query (N+1 Fix)
    $monthly_paid_payments_map = [];
    if (!empty($paid_ids)) {
        $stmt = $pdo->prepare("
            SELECT * FROM student_partial_payments 
            WHERE full_paid_fees_id IN (" . implode(',', array_fill(0, count($paid_ids), '?')) . ")
            ORDER BY created_at ASC
        ");
        $stmt->execute($paid_ids);
        $all_partial_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($all_partial_payments as $payment) {
            $monthly_paid_payments_map[$payment['full_paid_fees_id']][] = $payment;
        }
    }

    foreach ($paid_fees as &$paid_fee) {
        $paid_fee['partial_payments'] = $monthly_paid_payments_map[$paid_fee['id']] ?? [];
    }
    unset($paid_fee); // Unset reference

    // --- Monthly Payments History (with Pagination) ---
    $payment_count_stmt = $pdo->prepare("SELECT COUNT(*) as total FROM student_payment_history WHERE student_id = ?");
    $payment_count_stmt->execute([$student_id]);
    $total_payments_records = $payment_count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
    $total_payments_pages = ceil($total_payments_records / $result_per_page);

    // Get paginated data from the correct table
    $stmt = $pdo->prepare("
        SELECT * FROM student_payment_history 
        WHERE student_id = ?
        ORDER BY payment_date DESC, updated_at DESC
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$student_id, $result_per_page, $offset]);
    $monthly_fees_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Add to main response
    $response_data['monthly_fees'] = [
        'total_unpaid_amount' => $monthly_total_unpaid,
        'unpaid_fees' => [
            'data' => $unpaid_fees,
            'pagination' => [
                'total_records' => $total_unpaid_records,
                'total_pages' => $total_unpaid_pages,
                'current_page' => $page,
                'per_page' => $result_per_page
            ]
        ],
        'paid_fees' => [
            'data' => $paid_fees,
            'pagination' => [
                'total_records' => $total_paid_records,
                'total_pages' => $total_paid_pages,
                'current_page' => $page,
                'per_page' => $result_per_page
            ]
        ],
        'payments_history' => [
            'data' => $monthly_fees_payments,
            'pagination' => [
                'total_records' => $total_payments_records,
                'total_pages' => $total_payments_pages,
                'current_page' => $page,
                'per_page' => $result_per_page
            ]
        ]
    ];


    // ----------------------------------------------------------------------
    // SECTION 2: ADMISSION FEES
    // ----------------------------------------------------------------------
    
    $admission_total_unpaid = 0;

    // --- Admission Unpaid Fees (with Pagination) ---
    $unpaid_count_stmt = $pdo->prepare("SELECT COUNT(*) FROM admission_unpaid_fees WHERE student_id = ?");
    $unpaid_count_stmt->execute([$student_id]);
    $total_unpaid_records = (int)$unpaid_count_stmt->fetchColumn();
    $total_unpaid_pages = $total_unpaid_records > 0 ? ceil($total_unpaid_records / $result_per_page) : 1;

    $unpaid_stmt = $pdo->prepare("
        SELECT auf.*, c.class_name 
        FROM admission_unpaid_fees AS auf
        LEFT JOIN classes AS c ON auf.class_id = c.id
        WHERE auf.student_id = :student_id
        ORDER BY auf.academic_year ASC
        LIMIT :limit OFFSET :offset;
    ");
    $unpaid_stmt->bindValue(':student_id', $student_id);
    $unpaid_stmt->bindValue(':limit', $result_per_page, PDO::PARAM_INT);
    $unpaid_stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $unpaid_stmt->execute();
    $unpaid_fees = $unpaid_stmt->fetchAll(PDO::FETCH_ASSOC);
    $unpaid_ids = array_column($unpaid_fees, 'id');

    // Fetch partial payments in a single query (N+1 Fix)
    $admission_unpaid_payments_map = [];
    if (!empty($unpaid_ids)) {
        $stmt = $pdo->prepare("
            SELECT * FROM admission_partial_fees_payments 
            WHERE unpaid_admission_fees_id IN (" . implode(',', array_fill(0, count($unpaid_ids), '?')) . ")
            ORDER BY created_at ASC
        ");
        $stmt->execute($unpaid_ids);
        $all_partial_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($all_partial_payments as $payment) {
            $admission_unpaid_payments_map[$payment['unpaid_admission_fees_id']][] = $payment;
        }
    }

    foreach ($unpaid_fees as &$unpaid_fee) {
        $admission_total_unpaid += $unpaid_fee['unpaid_amount'];
        $unpaid_fee['partial_payments'] = $admission_unpaid_payments_map[$unpaid_fee['id']] ?? [];
    }
    unset($unpaid_fee); // Unset reference
    $grand_total_unpaid += $admission_total_unpaid; // Add to grand total

    // --- Admission Paid Fees (with Pagination) ---
    $paid_count_stmt = $pdo->prepare("SELECT COUNT(*) FROM admission_full_paid_fees WHERE student_id = ?");
    $paid_count_stmt->execute([$student_id]);
    $total_paid_records = (int)$paid_count_stmt->fetchColumn();
    $total_paid_pages = $total_paid_records > 0 ? ceil($total_paid_records / $result_per_page) : 1;

    $paid_stmt = $pdo->prepare("
        SELECT afpf.*, c.class_name 
        FROM admission_full_paid_fees AS afpf
        LEFT JOIN classes AS c ON afpf.class_id = c.id
        WHERE afpf.student_id = :student_id
        ORDER BY afpf.academic_year ASC
        LIMIT :limit OFFSET :offset;
    ");
    $paid_stmt->bindValue(':student_id', $student_id);
    $paid_stmt->bindValue(':limit', $result_per_page, PDO::PARAM_INT);
    $paid_stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $paid_stmt->execute();
    $paid_fees = $paid_stmt->fetchAll(PDO::FETCH_ASSOC);
    $paid_ids = array_column($paid_fees, 'id');

    // Fetch partial payments in a single query (N+1 Fix)
    $admission_paid_payments_map = [];
    if (!empty($paid_ids)) {
        $stmt = $pdo->prepare("
            SELECT * FROM admission_partial_fees_payments 
            WHERE full_paid_admission_fees_id IN (" . implode(',', array_fill(0, count($paid_ids), '?')) . ")
            ORDER BY created_at ASC
        ");
        $stmt->execute($paid_ids);
        $all_partial_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($all_partial_payments as $payment) {
            $admission_paid_payments_map[$payment['full_paid_admission_fees_id']][] = $payment;
        }
    }

    foreach ($paid_fees as &$paid_fee) {
        $paid_fee['partial_payments'] = $admission_paid_payments_map[$paid_fee['id']] ?? [];
    }
    unset($paid_fee); // Unset reference

    // --- Admission Payments History (with Pagination) ---
    $payment_count_stmt = $pdo->prepare("SELECT COUNT(*) as total FROM admission_fees_payment_history WHERE student_id = ?");
    $payment_count_stmt->execute([$student_id]);
    $total_payments_records = $payment_count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
    $total_payments_pages = ceil($total_payments_records / $result_per_page);

    // Get paginated data from the correct table
    $stmt = $pdo->prepare("
        SELECT * FROM admission_fees_payment_history 
        WHERE student_id = ?
        ORDER BY payment_date DESC, updated_at DESC
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$student_id, $result_per_page, $offset]);
    $admission_fees_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Add to main response
    $response_data['admission_fees'] = [
        'total_unpaid_amount' => $admission_total_unpaid,
        'unpaid_fees' => [
            'data' => $unpaid_fees,
            'pagination' => [
                'total_records' => $total_unpaid_records,
                'total_pages' => $total_unpaid_pages,
                'current_page' => $page,
                'per_page' => $result_per_page
            ]
        ],
        'paid_fees' => [
            'data' => $paid_fees,
            'pagination' => [
                'total_records' => $total_paid_records,
                'total_pages' => $total_paid_pages,
                'current_page' => $page,
                'per_page' => $result_per_page
            ]
        ],
        'payments_history' => [
            'data' => $admission_fees_payments,
            'pagination' => [
                'total_records' => $total_payments_records,
                'total_pages' => $total_payments_pages,
                'current_page' => $page,
                'per_page' => $result_per_page
            ]
        ]
    ];


    // ----------------------------------------------------------------------
    // SECTION 3: ADDITIONAL FEES
    // ----------------------------------------------------------------------

    $count_sql = "SELECT COUNT(*) FROM additional_fees_data WHERE student_id = ?";
    $count_stmt = $pdo->prepare($count_sql);
    $count_stmt->execute([$student_id]);
    $total_records = (int)$count_stmt->fetchColumn();
    $total_pages = $total_records > 0 ? ceil($total_records / $result_per_page) : 1;

    $sql = "SELECT 
                afd.additional_fee_status, afd.additional_fee_due_date, 
                afd.additional_fee_paid_date, afd.additional_fee_setup_id,
                cwaf.amount, cwaf.fee_type, 
                c.class_name 
            FROM additional_fees_data AS afd
            LEFT JOIN classes AS c ON c.id = afd.class_id 
            LEFT JOIN class_wise_additional_fees AS cwaf ON cwaf.id = afd.additional_fee_setup_id
            WHERE afd.student_id = ? 
            LIMIT ? OFFSET ?";
    
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(1, $student_id);
    $stmt->bindValue(2, $result_per_page, PDO::PARAM_INT);
    $stmt->bindValue(3, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $additional_fees = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $unpaid_additional_fees = [];
    $paid_additional_fees = [];

    foreach ($additional_fees as $fee) {
        if ($fee['additional_fee_status'] === 'unpaid') {
            $unpaid_additional_fees[] = $fee;
            $grand_total_unpaid += $fee['amount'];
        } else {
            $paid_additional_fees[] = $fee;
        }
    }

    // Add to main response
    $response_data['additional_fees'] = [
        'unpaid_fees' => $unpaid_additional_fees,
        'paid_fees' => $paid_additional_fees,
        'all_fees' => $additional_fees,
        'pagination' => [
            'total_records' => $total_records,
            'total_pages' => $total_pages,
            'current_page' => $page,
            'per_page' => $result_per_page
        ]
    ];


    // ----------------------------------------------------------------------
    // FINAL JSON RESPONSE
    // ----------------------------------------------------------------------
    
    echo json_encode([
        "success" => true,
        "message" => "Student's fee data retrieved successfully.",
        "data" => $response_data,
        "totals" => [
            "grand_total_unpaid_amount" => $grand_total_unpaid
        ]
    ]);

} catch (Exception $e) {
    // Send a 500 status code for server errors
    http_response_code(500); 
    echo json_encode([
        "success" => false,
        "message" => "An internal server error occurred.",
        "error" => $e->getMessage() // Only for development! Remove in production.
    ]);
}

?>