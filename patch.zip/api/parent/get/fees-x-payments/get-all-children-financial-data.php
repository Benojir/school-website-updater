<?php
include_once(__DIR__ . "/../../../../includes/parent/parent-auth-check.php");

header('Content-Type: application/json');

try {
    $authData = authenticateApiRequest($pdo);

    $parent_phone = $authData['phone_number'];

    // --- Get list of children ---
    $sql = "
        SELECT 
            students.student_id,
            students.name AS student_name,
            students.student_image,
            students.roll_no,
            students.father_name,
            students.mother_name,
            classes.class_name,
            sections.section_name
        FROM 
            students
        LEFT JOIN 
            classes ON students.class_id = classes.id
        LEFT JOIN 
            sections ON students.section_id = sections.id
        WHERE 
            students.phone_number = :phone_number
        ORDER BY
            students.name ASC
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':phone_number', $parent_phone);
    $stmt->execute();
    $children = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$children) {
        echo json_encode([
            'success' => false,
            'message' => 'No children found for this account.'
        ]);
        exit;
    }

    $children_financial_data = [];

    // --- Loop through each child and get their financial summary ---
    foreach ($children as $child) {
        $student_id = $child['student_id'];
        $child_summary = ['student_details' => $child];
        $student_grand_total_unpaid = 0;

        // 1. Get Wallet Balance (from get-student-wallet-data.php logic)
        $wallet_stmt = $pdo->prepare("SELECT * FROM student_wallet WHERE student_id = :student_id");
        $wallet_stmt->execute([':student_id' => $student_id]);
        $wallet = $wallet_stmt->fetch(PDO::FETCH_ASSOC);
        
        $child_summary['wallet'] = $wallet ? $wallet : [
            "student_id" => $student_id,
            "balance" => "0.00", // Default if no wallet exists
            "updated_at" => null
        ];

        // 2. Get Monthly Fees Unpaid Total (from get-fees-x-payments-data.php logic)
        $mf_stmt = $pdo->prepare("SELECT SUM(unpaid_amount) AS total FROM student_unpaid_fees WHERE student_id = ?");
        $mf_stmt->execute([$student_id]);
        $monthly_total_unpaid = (float)$mf_stmt->fetchColumn();
        $student_grand_total_unpaid += $monthly_total_unpaid;
        $child_summary['monthly_fees_unpaid_total'] = $monthly_total_unpaid;
        
        // 3. Get Admission Fees Unpaid Total (from get-fees-x-payments-data.php logic)
        $af_stmt = $pdo->prepare("SELECT SUM(unpaid_amount) AS total FROM admission_unpaid_fees WHERE student_id = ?");
        $af_stmt->execute([$student_id]);
        $admission_total_unpaid = (float)$af_stmt->fetchColumn();
        $student_grand_total_unpaid += $admission_total_unpaid;
        $child_summary['admission_fees_unpaid_total'] = $admission_total_unpaid;
        
        // 4. Get Additional Fees Unpaid Total (from get-fees-x-payments-data.php logic)
        // Note: Assuming 'unpaid' is the correct status string.
        $adf_stmt = $pdo->prepare("
            SELECT SUM(cwaf.amount) 
            FROM additional_fees_data AS afd
            JOIN class_wise_additional_fees AS cwaf ON cwaf.id = afd.additional_fee_setup_id
            WHERE afd.student_id = ? AND afd.additional_fee_status = 'unpaid'
        ");
        $adf_stmt->execute([$student_id]);
        $additional_total_unpaid = (float)$adf_stmt->fetchColumn();
        $student_grand_total_unpaid += $additional_total_unpaid;
        $child_summary['additional_fees_unpaid_total'] = $additional_total_unpaid;

        // 5. Set Grand Total for this child
        $child_summary['total_unpaid_amount'] = $student_grand_total_unpaid;
        
        // Add this child's summary to the main array
        $children_financial_data[] = $child_summary;
    }
    
    // --- FINAL JSON RESPONSE ---
    echo json_encode([
        'success' => true,
        'data' => $children_financial_data
    ]);

} catch (PDOException $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['success' => false, 'message' => 'A database error occurred. ' . $e->getMessage()]);

} catch (Exception $e) {
    // Catch any other unexpected errors
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'An unexpected error occurred. ' . $e->getMessage()]);
}

?>