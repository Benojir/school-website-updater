<?php
include_once(__DIR__ . "/../../../../includes/parent/auth/parent-auth-check.php");

header('Content-Type: application/json');

$authData = authenticateApiRequest($pdo);

if (!$authData) {
    echo json_encode([
        'success' => false,
        'message' => 'Authentication failed. Invalid token.'
    ]);
    exit;
}

$student_id = $_REQUEST['student_id'] ?? null;
$result_per_page = (int)($_REQUEST['results_per_page'] ?? 20);
$page = (int)($_REQUEST['page'] ?? 1);
$fees_type = $_REQUEST['type'] ?? '';

if (empty($student_id)) {
    echo json_encode([
        "success" => false,
        "message" => "Missing required parameter: student_id."
    ]);
    exit();
}

if ($result_per_page <= 0 || $page <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid pagination parameters. 'page' and 'result_per_page' must be greater than 0."
    ]);
    exit();
}

if ($fees_type !== 'unpaid' && $fees_type !== 'paid' && $fees_type !== 'all_fees') {
    echo json_encode([
        "success" => false,
        "message" => "Invalid fees type."
    ]);
    exit();
}

// Calculate offset
$offset = ($page - 1) * $result_per_page;

try {
    $count_sql = "SELECT COUNT(*) FROM additional_fees_data WHERE student_id = ?";
    $count_stmt = $pdo->prepare($count_sql);
    $count_stmt->execute([$student_id]);
    $total_records = (int)$count_stmt->fetchColumn();
    $total_pages = $total_records > 0 ? ceil($total_records / $result_per_page) : 1;

    $sql = "SELECT 
                afd.additional_fee_status, afd.additional_fee_due_date, 
                afd.additional_fee_paid_date, afd.additional_fee_setup_id,
                cwaf.amount, cwaf.fee_type, 
                c.class_name 
            FROM additional_fees_data AS afd
            LEFT JOIN classes AS c ON c.id = afd.class_id 
            LEFT JOIN class_wise_additional_fees AS cwaf ON cwaf.id = afd.additional_fee_setup_id
            WHERE afd.student_id = ? 
            LIMIT ? OFFSET ?";

    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(1, $student_id);
    $stmt->bindValue(2, $result_per_page, PDO::PARAM_INT);
    $stmt->bindValue(3, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $additional_fees = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $unpaid_additional_fees = [];
    $paid_additional_fees = [];

    foreach ($additional_fees as $fee) {
        if ($fee['additional_fee_status'] === 'unpaid') {
            $unpaid_additional_fees[] = $fee;
        } else {
            $paid_additional_fees[] = $fee;
        }
    }

    $type_map = [
        'unpaid' => $unpaid_additional_fees ?? [],
        'paid' => $paid_additional_fees ?? [],
        'all_fees' => $additional_fees ?? []
    ];

    if (isset($type_map[$fees_type])) {
        echo json_encode([
            "success" => true,
            "data" => [
                "results" => $type_map[$fees_type],
                "pagination" => [
                    "current_page" => $page,
                    "results_per_page" => $result_per_page,
                    "total_pages" => $total_pages,
                    "total_records" => $total_records
                ]
            ]
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Invalid fees type requested."
        ]);
    }
} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "A database error occurred."
    ]);
    exit();
}
