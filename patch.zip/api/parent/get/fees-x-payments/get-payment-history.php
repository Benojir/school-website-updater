<?php
// This file can be used for student or parent dashboards
include_once(__DIR__ . "/../../../../includes/config.php");

header('Content-Type: application/json');

$student_id = $_REQUEST['student_id'] ?? null;
$page = (int) ($_REQUEST['page'] ?? 1);
$per_page = (int) ($_REQUEST['per_page'] ?? 20);
$type = $_REQUEST['type'] ?? null;

if (!$student_id || $page < 1 || $per_page < 1 || !$type) {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
    exit;
}

$offset = ($page - 1) * $per_page;

// Whitelist the 'type' parameter to prevent SQL injection
$allowed_types = ['monthly', 'admission'];

if (!in_array($type, $allowed_types)) {
    echo json_encode(['success' => false, 'message' => 'Invalid payment type specified.']);
    exit;
}

// Determine the table name based on the 'type'
$table_name = ($type == 'monthly') 
    ? 'student_payment_history' 
    : 'admission_fees_payment_history';

try {
    // Get total count from the correct table
    $count_stmt = $pdo->prepare("SELECT COUNT(*) as total FROM $table_name WHERE student_id = ?");
    $count_stmt->execute([$student_id]);
    $total = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
    $total_pages = ceil($total / $per_page);

    // Get paginated data from the correct table
    $stmt = $pdo->prepare("
        SELECT * FROM $table_name 
        WHERE student_id = ?
        ORDER BY payment_date DESC, updated_at DESC
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$student_id, $per_page, $offset]);
    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'data' => $payments,
        'current_page' => $page,
        'total_pages' => $total_pages,
        'total_items' => $total,
        'type' => $type // You can return the type for convenience
    ]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}