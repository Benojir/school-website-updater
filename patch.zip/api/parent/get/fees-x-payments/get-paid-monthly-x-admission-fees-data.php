<?php
include_once(__DIR__ . "/../../../../includes/parent/auth/parent-auth-check.php");

header('Content-Type: application/json');

$authData = authenticateApiRequest($pdo);

if (!$authData) {
    echo json_encode([
        'success' => false,
        'message' => 'Authentication failed. Invalid token.'
    ]);
    exit;
}

$student_id = $_REQUEST['student_id'] ?? null;
$result_per_page = (int)($_REQUEST['results_per_page'] ?? 20);
$page = (int)($_REQUEST['page'] ?? 1);
$fees_type = $_REQUEST['type'] ?? 'monthly';

if (empty($student_id)) {
    echo json_encode([
        "success" => false,
        "message" => "Missing required parameter: student_id."
    ]);
    exit();
}

if ($result_per_page <= 0 || $page <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid pagination parameters. 'page' and 'result_per_page' must be greater than 0."
    ]);
    exit();
}

// Calculate offset
$offset = ($page - 1) * $result_per_page;

try {

    $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM student_full_paid_fees WHERE student_id = ?");

    if ($fees_type == "admission") {
        $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM admission_full_paid_fees WHERE student_id = ?");
    }

    $count_stmt->execute([$student_id]);
    $total_records = (int)$count_stmt->fetchColumn();
    $total_pages = $total_records > 0 ? ceil($total_records / $result_per_page) : 1;

    $paid_stmt = $pdo->prepare("
        SELECT * FROM student_full_paid_fees 
        WHERE student_id = :student_id
        ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC 
        LIMIT :limit OFFSET :offset
    ");

    if ($fees_type == "admission") {
        $paid_stmt = $pdo->prepare("
            SELECT afpf.*, c.class_name 
            FROM admission_full_paid_fees AS afpf
            LEFT JOIN classes AS c ON afpf.class_id = c.id
            WHERE afpf.student_id = :student_id
            ORDER BY afpf.academic_year ASC
            LIMIT :limit OFFSET :offset;
        ");
    }

    $paid_stmt->bindValue(':student_id', $student_id);
    $paid_stmt->bindValue(':limit', $result_per_page, PDO::PARAM_INT);
    $paid_stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $paid_stmt->execute();
    $paid_fees = $paid_stmt->fetchAll(PDO::FETCH_ASSOC);
    $paid_ids = array_column($paid_fees, 'id');

    // Fetch partial payments in a single query (N+1 Fix)
    $paid_payments_map = [];

    if (!empty($paid_ids)) {

        $stmt = $pdo->prepare("
            SELECT * FROM student_partial_payments 
            WHERE full_paid_fees_id IN (" . implode(',', array_fill(0, count($paid_ids), '?')) . ")
            ORDER BY created_at ASC
        ");

        if ($fees_type == "admission") {
            $stmt = $pdo->prepare("
                SELECT * FROM admission_partial_fees_payments 
                WHERE full_paid_admission_fees_id IN (" . implode(',', array_fill(0, count($paid_ids), '?')) . ")
                ORDER BY created_at ASC
            ");
        }

        $stmt->execute($paid_ids);
        $all_partial_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($all_partial_payments as $payment) {
            if ($fees_type == "admission") {
                $paid_payments_map[$payment['full_paid_admission_fees_id']][] = $payment;
            } else {
                $paid_payments_map[$payment['full_paid_fees_id']][] = $payment;
            }
        }
    }

    foreach ($paid_fees as &$paid_fee) {
        $paid_fee['partial_payments'] = $paid_payments_map[$paid_fee['id']] ?? [];
    }
    unset($paid_fee); // Unset reference

    echo json_encode([
        "success" => true,
        "data" => [
            "results" => $paid_fees,
            "pagination" => [
                "current_page" => $page,
                "results_per_page" => $result_per_page,
                "total_pages" => $total_pages,
                "total_records" => $total_records
            ]
        ]
    ]);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "An error occurred while fetching paid fees data.",
        "error" => $e->getMessage()
    ]);
    exit();
}