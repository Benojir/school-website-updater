<?php
include_once(__DIR__ . "/../../../../includes/db.php");

header('Content-Type: application/json');

// 1. GET AND CAST PARAMETERS
// Cast pagination parameters to integers for safety
$student_id = $_REQUEST['student_id'] ?? null;
$result_per_page = (int)($_REQUEST['result_per_page'] ?? 20);
$page = (int)($_REQUEST['page'] ?? 1);

// 2. FIX: VALIDATE PARAMETERS
// Only student_id is required. The others have safe defaults.
if (empty($student_id)) {
    echo json_encode([
        "success" => false,
        "message" => "Missing required parameter: student_id."
    ]);
    exit();
}

// Add validation for sensible pagination values
if ($result_per_page <= 0 || $page <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid pagination parameters. 'page' and 'result_per_page' must be greater than 0."
    ]);
    exit();
}

try {
    // 3. ENHANCEMENT: GET TOTAL COUNT FOR PAGINATION
    // This query finds the total number of records for this student
    $count_sql = "SELECT COUNT(*) FROM additional_fees_data WHERE student_id = ?";
    $count_stmt = $pdo->prepare($count_sql);
    $count_stmt->execute([$student_id]);
    $total_records = (int)$count_stmt->fetchColumn();

    // Calculate total pages
    $total_pages = $total_records > 0 ? ceil($total_records / $result_per_page) : 1;

    // 4. GET PAGINATED DATA
    $sql = "SELECT 
                afd.additional_fee_status, afd.additional_fee_due_date, 
                afd.additional_fee_paid_date, afd.additional_fee_setup_id,
                cwaf.amount, cwaf.fee_type, 
                c.class_name 
            FROM additional_fees_data AS afd
            LEFT JOIN classes AS c ON c.id = afd.class_id 
            LEFT JOIN class_wise_additional_fees AS cwaf ON cwaf.id = afd.additional_fee_setup_id
            WHERE afd.student_id = ? 
            LIMIT ? OFFSET ?";
    
    // Calculate offset
    $offset = ($page - 1) * $result_per_page;
    
    $stmt = $pdo->prepare($sql);

    // 5. FIX: BIND PARAMETERS CORRECTLY
    // Use bindValue with PDO::PARAM_INT for LIMIT and OFFSET
    $stmt->bindValue(1, $student_id);
    $stmt->bindValue(2, $result_per_page, PDO::PARAM_INT);
    $stmt->bindValue(3, $offset, PDO::PARAM_INT);
    
    $stmt->execute();
    $additional_fees_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 6. IMPROVED JSON RESPONSE
    // Include pagination metadata in the response
    echo json_encode([
        "success" => true,
        "message" => "Additional fees history retrieved successfully.",
        "pagination" => [
            "total_records" => $total_records,
            "total_pages" => $total_pages,
            "current_page" => $page,
            "per_page" => $result_per_page
        ],
        "data" => $additional_fees_data
    ]);

} catch (Exception $e) {
    // Send a 500 status code for server errors
    http_response_code(500); 
    echo json_encode([
        "success" => false,
        "message" => $e->getMessage()
    ]);
}