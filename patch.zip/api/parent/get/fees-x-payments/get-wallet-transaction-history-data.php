<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/parent/auth/parent-auth-check.php");

header('Content-Type: application/json');

// Check permission
if (isAnyAdminLoggedIn()) {
    if (!hasPermission(PERM_MANAGE_FEES)) {
        echo json_encode(['success' => false, 'message' => 'Permission denied']);
        exit();
    }
} else {
    $parentAuth = authenticateApiRequest($pdo);

    if (!$parentAuth) {
        echo json_encode([
            'success' => false,
            'message' => 'Authentication failed. Invalid token.'
        ]);
        exit;
    }
}


$student_id = $_REQUEST['student_id'] ?? null;
$result_per_page = (int)($_REQUEST['results_per_page'] ?? 20);
$page = (int)($_REQUEST['page'] ?? 1);

if (empty($student_id)) {
    echo json_encode([
        "success" => false,
        "message" => "Missing required parameter: student_id."
    ]);
    exit();
}

if ($result_per_page <= 0 || $page <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid pagination parameters. 'page' and 'result_per_page' must be greater than 0."
    ]);
    exit();
}

// Calculate offset
$offset = ($page - 1) * $result_per_page;

try {

    $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM wallet_transactions WHERE student_id = :student_id");
    $count_stmt->execute([':student_id' => $student_id]);
    $total_records = (int)$count_stmt->fetchColumn();
    $total_pages = $total_records > 0 ? ceil($total_records / $result_per_page) : 1;

    // Get wallet transactions (paginated)
    $stmt = $pdo->prepare("
        SELECT * FROM wallet_transactions 
        WHERE student_id = :student_id
        ORDER BY created_at DESC
        LIMIT :limit OFFSET :offset
    ");
    // Bind parameters for safety
    $stmt->bindValue(':student_id', $student_id, PDO::PARAM_STR);
    $stmt->bindValue(':limit', $result_per_page, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();

    $wallet_transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "success" => true,
        "data" => [
            "results" => $wallet_transactions,
            "pagination" => [
                "current_page" => $page,
                "results_per_page" => $result_per_page,
                "total_pages" => $total_pages,
                "total_records" => $total_records
            ]
        ]
    ]);
} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "An error occurred while fetching unpaid fees data.",
        "error" => $e->getMessage()
    ]);
    exit();
}
