<?php
include_once(__DIR__ . "/../../../../includes/parent/parent-auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

// Set header at the very top to ensure it's sent
header('Content-Type: application/json');

// --- BEST PRACTICE: Wrap database logic in try...catch ---
try {
    $student_id = $_REQUEST['student_id'] ?? null;
    $result_per_page = (int)($_REQUEST['result_per_page'] ?? 20); // Use 20 as default
    $page = (int)($_REQUEST['page'] ?? 1);

    if (empty($student_id)) {
        echo json_encode([
            "success" => false,
            "message" => "Missing required parameter: student_id."
        ]);
        exit();
    }

    if ($result_per_page <= 0 || $page <= 0) {
        echo json_encode([
            "success" => false,
            "message" => "Invalid pagination parameters. 'page' and 'result_per_page' must be greater than 0."
        ]);
        exit();
    }

    // Calculate offset
    $offset = ($page - 1) * $result_per_page;

    $hasPermissionAccessToStudent = true;

    // Check admin permission + parent permission
    if (isLoggedIn()) { // Check any admin logged in
        if (!hasPermission(PERM_MANAGE_EXAMS) && !hasPermission(PERM_MANAGE_STUDENTS) && !hasPermission(PERM_MANAGE_FEES)) {
            $hasPermissionAccessToStudent = false;
        }
    } else {
        $parentAuthData = authenticateWebPageRequest($pdo); // If not logged in any parent then it will redirect to parent login
        if (!hasParentAccessToStudent($parentAuthData['parent_id'], $student_id)) {
            $hasPermissionAccessToStudent = false;
        }
    }

    // Response permission denied
    if (!$hasPermissionAccessToStudent) {
        exit(json_encode(['success' => false, 'message' => 'You do not have permission to access this student data.']));
    }

    // --------------------------------------Main Code Here -------------------------------------- //

    // Fetch student details to verify student exists
    $stmt = $pdo->prepare("
        SELECT 
            students.student_id,
            students.name AS student_name,
            classes.class_name,
            sections.section_name
        FROM 
            students
        JOIN 
            classes ON students.class_id = classes.id
        LEFT JOIN 
            sections ON students.section_id = sections.id
        WHERE students.student_id = :student_id
    ");
    $stmt->execute([':student_id' => $student_id]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        exit(json_encode(['success' => false, 'message' => 'Student not found.']));
    }

    // Get wallet balance
    $stmt = $pdo->prepare("SELECT * FROM student_wallet WHERE student_id = :student_id");
    $stmt->execute([':student_id' => $student_id]);
    $wallet = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($wallet === false) {
        $wallet = [];
    }

    // --- PAGINATION: Get total count ---
    $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM wallet_transactions WHERE student_id = :student_id");
    $count_stmt->execute([':student_id' => $student_id]);
    $total_records = (int)$count_stmt->fetchColumn();
    $total_pages = $total_records > 0 ? ceil($total_records / $result_per_page) : 1;

    // Get wallet transactions (paginated)
    $stmt = $pdo->prepare("
        SELECT * FROM wallet_transactions 
        WHERE student_id = :student_id
        ORDER BY created_at DESC
        LIMIT :limit OFFSET :offset
    ");
    // Bind parameters for safety
    $stmt->bindValue(':student_id', $student_id, PDO::PARAM_STR);
    $stmt->bindValue(':limit', $result_per_page, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    
    $wallet_transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'student' => $student,
        'wallet' => $wallet,
        'wallet_transactions' => $wallet_transactions,
        'pagination' => [ // Add pagination block
            'current_page' => $page,
            'total_pages' => $total_pages,
            'total_items' => $total_records
        ]
    ]);

} catch (PDOException $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['success' => false, 'message' => 'A database error occurred. ' . $e->getMessage()]);

} catch (Exception $e) {
    // Catch any other unexpected errors
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'An unexpected error occurred. ' . $e->getMessage()]);
}

?>