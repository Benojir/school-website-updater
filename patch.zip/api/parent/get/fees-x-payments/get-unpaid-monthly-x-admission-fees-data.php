<?php
include_once(__DIR__ . "/../../../../includes/parent/auth/parent-auth-check.php");

header('Content-Type: application/json');

$authData = authenticateApiRequest($pdo);

if (!$authData) {
    echo json_encode([
        'success' => false,
        'message' => 'Authentication failed. Invalid token.'
    ]);
    exit;
}

$student_id = $_REQUEST['student_id'] ?? null;
$result_per_page = (int)($_REQUEST['results_per_page'] ?? 20);
$page = (int)($_REQUEST['page'] ?? 1);
$fees_type = $_REQUEST['type'] ?? 'monthly';

if (empty($student_id)) {
    echo json_encode([
        "success" => false,
        "message" => "Missing required parameter: student_id."
    ]);
    exit();
}

if ($result_per_page <= 0 || $page <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid pagination parameters. 'page' and 'result_per_page' must be greater than 0."
    ]);
    exit();
}

// Calculate offset
$offset = ($page - 1) * $result_per_page;

try {

    $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM student_unpaid_fees WHERE student_id = ?");

    if ($fees_type == "admission") {
        $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM admission_unpaid_fees WHERE student_id = ?");
    }

    $count_stmt->execute([$student_id]);
    $total_records = (int)$count_stmt->fetchColumn();
    $total_pages = $total_records > 0 ? ceil($total_records / $result_per_page) : 1;

    $unpaid_stmt = $pdo->prepare("
        SELECT * FROM student_unpaid_fees 
        WHERE student_id = :student_id
        ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC 
        LIMIT :limit OFFSET :offset
    ");

    if ($fees_type == "admission") {
        $unpaid_stmt = $pdo->prepare("
            SELECT auf.*, c.class_name 
            FROM admission_unpaid_fees AS auf
            LEFT JOIN classes AS c ON auf.class_id = c.id
            WHERE auf.student_id = :student_id
            ORDER BY auf.academic_year ASC
            LIMIT :limit OFFSET :offset;
        ");
    }

    $unpaid_stmt->bindValue(':student_id', $student_id);
    $unpaid_stmt->bindValue(':limit', $result_per_page, PDO::PARAM_INT);
    $unpaid_stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $unpaid_stmt->execute();
    $unpaid_fees = $unpaid_stmt->fetchAll(PDO::FETCH_ASSOC);
    $unpaid_ids = array_column($unpaid_fees, 'id');

    // Fetch partial payments in a single query (N+1 Fix)
    $unpaid_payments_map = [];

    if (!empty($unpaid_ids)) {

        $stmt = $pdo->prepare("
            SELECT * FROM student_partial_payments 
            WHERE unpaid_fees_id IN (" . implode(',', array_fill(0, count($unpaid_ids), '?')) . ")
            ORDER BY created_at ASC
        ");

        if ($fees_type == "admission") {
            $stmt = $pdo->prepare("
                SELECT * FROM admission_partial_fees_payments 
                WHERE unpaid_admission_fees_id IN (" . implode(',', array_fill(0, count($unpaid_ids), '?')) . ")
                ORDER BY created_at ASC
            ");
        }

        $stmt->execute($unpaid_ids);

        $all_partial_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($all_partial_payments as $payment) {
            if ($fees_type == "admission") {
                $unpaid_payments_map[$payment['unpaid_admission_fees_id']][] = $payment;
            } else {
                $unpaid_payments_map[$payment['unpaid_fees_id']][] = $payment;
            }
        }
    }

    foreach ($unpaid_fees as &$unpaid_fee) {
        $unpaid_fee['partial_payments'] = $unpaid_payments_map[$unpaid_fee['id']] ?? [];
    }

    unset($unpaid_fee); // Unset reference

    echo json_encode([
        "success" => true,
        "data" => [
            "results" => $unpaid_fees,
            "pagination" => [
                "current_page" => $page,
                "result_per_page" => $result_per_page,
                "total_pages" => $total_pages,
                "total_records" => $total_records
            ]
        ]
    ]);
} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "A database error occurred."
    ]);
    exit();
}