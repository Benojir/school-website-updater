<?php
include_once(__DIR__ . "/../../../../includes/parent/auth/parent-auth-check.php");
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

$student_id = $_REQUEST['student_id'] ?? null;

if (!$student_id) {
    die(json_encode(['success' => false, 'message' => 'Student ID not provided.']));
}

$hasPermissionAccessToStudent = true;

// Check admin permission + parent permission
if (isAnyAdminLoggedIn()) { // Check any admin logged in
    if (!hasPermission(PERM_MANAGE_EXAMS) && !hasPermission(PERM_MANAGE_STUDENTS) && !hasPermission(PERM_MANAGE_FEES)) {
        $hasPermissionAccessToStudent = false;
    }
} else {
    $parentAuthData = authenticateWebPageRequest($pdo); // If not logged in any parent then it will redirect to parent login
    if (!hasParentAccessToStudent($parentAuthData['parent_id'], $student_id)) {
        $hasPermissionAccessToStudent = false;
    }
}

// Response permission denied
if (!$hasPermissionAccessToStudent) {
    die(json_encode(['success' => false, 'message' => 'You do not have permission to access this student data.']));
}

// Fetch student details
$stmt = $pdo->prepare("
    SELECT students.*, classes.class_name, sections.section_name
    FROM students
    LEFT JOIN classes ON students.class_id = classes.id
    LEFT JOIN sections ON students.section_id = sections.id
    WHERE students.student_id = :student_id
");

$stmt->execute([':student_id' => $student_id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    die(json_encode(['success' => false, 'message' => 'Student not found.']));
}

$driver_id = $student['driver_id'];
$driving_route_id = $student['driving_route_id'];

if ($driver_id) {
    $driver_stmt = $pdo->prepare("SELECT * FROM drivers WHERE id = :driver_id");
    $driver_stmt->execute([':driver_id' => $driver_id]);
    $driver = $driver_stmt->fetch(PDO::FETCH_ASSOC);
    $student['driver_details'] = $driver ?: null;
} else {
    $student['driver_details'] = null;
}

if ($driving_route_id) {
    $route_stmt = $pdo->prepare("SELECT * FROM driving_routes WHERE id = :route_id");
    $route_stmt->execute([':route_id' => $driving_route_id]);
    $route = $route_stmt->fetch(PDO::FETCH_ASSOC);
    $student['driving_route_details'] = $route ?: null;
} else {
    $student['driving_route_details'] = null;
}

echo json_encode(['success' => true, 'data' => $student]);