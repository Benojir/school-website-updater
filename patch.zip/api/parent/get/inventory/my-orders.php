<?php
require_once __DIR__ . '/../../../../includes/inventory/store-api.php';
$parent = authenticateApiRequest($pdo);
try {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') { http_response_code(405); header('Allow: GET'); echo json_encode(['success'=>false, 'message'=>'Use GET.']); exit; }
    $data = (new InventoryOrderService($pdo))->getParentOrders($parent['phone_number']);
    echo json_encode(['success'=>true, 'data'=>$data, 'store_open'=>storeOpen(), 'allow_online_payment'=>storeOnlineEnabled()], JSON_THROW_ON_ERROR);
} catch (Throwable $e) { storeError($e); }
