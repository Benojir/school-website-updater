<?php
require_once __DIR__ . '/../../../../includes/parent/auth/parent-auth-check.php';
require_once __DIR__ . '/../../../../includes/auth-check.php';
require_once __DIR__ . '/../../../../includes/inventory/student-inventory-service.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        http_response_code(405);
        header('Allow: GET');
        echo json_encode(['success' => false, 'message' => 'This account is read-only. Use GET.']);
        exit;
    }
    $studentId = inventoryText($_GET['student_id'] ?? '', 50, 'student ID', true);
    if (isAnyAdminLoggedIn()) {
        $allowed = hasPermission(PERM_MANAGE_INVENTORY);
    } else {
        $parent = getAuthenticatedParent($pdo);
        if (!$parent) {
            http_response_code(401);
            echo json_encode(['success' => false, 'message' => 'Please sign in again to view this inventory account.']);
            exit;
        }
        $allowed = hasParentAccessToStudent($parent['phone_number'], $studentId);
    }
    if (!$allowed) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'You do not have permission to view this inventory account.']);
        exit;
    }
    $service = new StudentInventoryService($pdo);
    $action = $_GET['action'] ?? 'history';
    $data = match ($action) {
        'history' => $service->history($studentId, $_GET),
        'detail' => $service->detail($studentId, inventoryInteger($_GET['id'] ?? 0, 'Bill', 1, PHP_INT_MAX)),
        default => throw new InvalidArgumentException('Unknown inventory view.')
    };
    if ($data === null) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'This inventory entry is not available.']);
        exit;
    }
    $data['currency'] = $currency_symbol;
    echo json_encode(['success' => true, 'data' => $data], JSON_THROW_ON_ERROR);
} catch (InvalidArgumentException $e) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} catch (Throwable $e) {
    error_log('Student inventory: ' . $e->getMessage());
    $missing = $e instanceof PDOException && $e->getCode() === '42S02';
    http_response_code($missing ? 503 : 500);
    echo json_encode(['success' => false, 'message' => $missing
        ? 'The school store account is not available yet. Please contact the school.'
        : 'Unable to load this inventory account. Please try again later.']);
}
