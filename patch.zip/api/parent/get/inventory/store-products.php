<?php
require_once __DIR__ . '/../../../../includes/inventory/store-api.php';
$parent = authenticateApiRequest($pdo);
try {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') { http_response_code(405); header('Allow: GET'); echo json_encode(['success'=>false, 'message'=>'Use GET.']); exit; }
    $data = (new InventoryOrderService($pdo, null, null, storeOpen()))->getStoreProducts($_GET);
    $data['currency'] = $currency_symbol;
    $data['school_name'] = $school_name;
    $data['allow_online_payment'] = storeOnlineEnabled();
    $data['razorpay_key_id'] = storeOnlineEnabled() ? $websiteConfig['razorpay_key_id'] : '';
    $charges = storeOnlineEnabled() ? schoolPaymentCharges(100, $websiteConfig['razorpay_charge_percentage'] ?? 0, $websiteConfig['gst_on_razorpay_charge'] ?? 0)
        : ['gateway_percentage'=>0, 'gst_percentage'=>0];
    $data['payment_charges'] = array_intersect_key($charges, array_flip(['gateway_percentage', 'gst_percentage']));
    echo json_encode(['success'=>true, 'data'=>$data], JSON_THROW_ON_ERROR);
} catch (Throwable $e) { storeError($e); }
