<?php
include_once __DIR__ . '/../../../../includes/config.php';

// আপনার টেলিগ্রাম বট টোকেনটি এখানে দিন বা config.php থেকে কল করুন
$botToken = $websiteConfig['telegram_bot_token'] ?? ''; 
$file_id = $_REQUEST['file_id'] ?? null;

if (!$file_id) {
    http_response_code(400);
    exit('file_id is required');
}

// টেলিগ্রাম API থেকে ফাইলের পাথ বের করা
$apiUrl = "https://api.telegram.org/bot{$botToken}/getFile?file_id={$file_id}";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

if ($response) {
    $data = json_decode($response, true);
    if (isset($data['result']['file_path'])) {
        $filePath = $data['result']['file_path'];
        $fileUrl = "https://api.telegram.org/file/bot{$botToken}/{$filePath}";
        
        // সরাসরি ফাইলের লিংকে রিডাইরেক্ট করে দিন
        header("Location: " . $fileUrl);
        exit;
    }
}

// ফাইল না পেলে 404 এরর
http_response_code(404);
exit('File not found');
?>