<?php
header('Content-Type: application/json; charset=utf-8');
include_once __DIR__ . '/../../../../includes/config.php';
require_once __DIR__ . '/../../../../includes/teacher/homework-posts.php';

$section_id = $_REQUEST['section_id'] ?? null;
$page = max(1, (int)($_REQUEST['page'] ?? 1));
$limit = max(1, min(50, (int)($_REQUEST['limit'] ?? 15)));
$before = isset($_REQUEST['before_id']) ? max(0, (int)$_REQUEST['before_id']) : null;
$after = isset($_REQUEST['after_id']) ? max(0, (int)$_REQUEST['after_id']) : null;

if (!$section_id) {
    echo json_encode(['success' => false, 'message' => 'section_id is required']);
    exit;
}

$offset = ($before !== null || $after !== null) ? 0 : ($page - 1) * $limit;
$cursorClause = $after !== null ? 'HAVING MAX(sh.id) > :cursor' : ($before !== null ? 'HAVING MAX(sh.id) < :cursor' : '');
$order = $after !== null ? 'ASC' : 'DESC';

try {
    // JOIN করে ইউনিক পোস্টগুলো বের করা
    $groupQuery = "
        SELECT COALESCE(sh.media_group_id, sh.id) AS post_key, MAX(sh.created_at) as post_date, MAX(sh.id) AS post_cursor
        FROM student_homeworks sh
        JOIN homework_section_map hsm ON sh.id = hsm.homework_id
        WHERE hsm.section_id = :section_id 
          AND sh.status = 'active' 
          AND sh.created_at >= DATE_SUB(NOW(), INTERVAL 1 YEAR)
        GROUP BY post_key
        $cursorClause
        ORDER BY post_cursor $order
        LIMIT :limit OFFSET :offset
    ";
    
    $groupStmt = $pdo->prepare($groupQuery);
    $groupStmt->bindValue(':section_id', $section_id, PDO::PARAM_INT);
    $groupStmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $groupStmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    if ($before !== null || $after !== null) $groupStmt->bindValue(':cursor', $after ?? $before, PDO::PARAM_INT);
    $groupStmt->execute();
    
    $groupResults = $groupStmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($groupResults)) {
        echo json_encode(['success' => true, 'page' => $page, 'has_more' => false, 'data' => [], 'upload_limits' => homeworkUploadLimits()]);
        exit;
    }

    $postKeys = array_column($groupResults, 'post_key');
    $inQuery = implode(',', array_fill(0, count($postKeys), '?'));
    
    // JOIN করে মূল ডেটা ফেচ করা
    $dataQuery = "
        SELECT sh.* FROM student_homeworks sh
        JOIN homework_section_map hsm ON sh.id = hsm.homework_id
        WHERE hsm.section_id = ? 
          AND sh.status = 'active' 
          AND COALESCE(sh.media_group_id, sh.id) IN ($inQuery)
        ORDER BY sh.id ASC
    ";
    
    $dataStmt = $pdo->prepare($dataQuery);
    $params = array_merge([$section_id], $postKeys);
    $dataStmt->execute($params);
    $rows = $dataStmt->fetchAll(PDO::FETCH_ASSOC);

    $posts = homeworkPostsFromRows($rows);
    $final_data = [];
    foreach ($groupResults as $group) {
        $key = (string)$group['post_key'];
        if (isset($posts[$key])) $final_data[] = $posts[$key];
    }
    $cursors = array_column($groupResults, 'post_cursor');

    echo json_encode([
        'success' => true,
        'page' => $page,
        'has_more' => count($groupResults) === $limit,
        'data' => $final_data,
        'next_cursor' => (int)end($cursors),
        'latest_cursor' => (int)max($cursors),
        'upload_limits' => homeworkUploadLimits()
    ]);

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
