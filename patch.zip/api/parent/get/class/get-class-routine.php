<?php
include_once(__DIR__ . "/../../../../includes/config.php");

header('Content-Type: application/json');

// Authenticate the request if needed (commented out as per your previous pattern)
// $parent = authenticateMobileRequest($pdo);

try {
    // Get optional parameters
    $classId = isset($_GET['class_id']) ? (int)$_GET['class_id'] : null;
    $sectionId = isset($_GET['section_id']) ? (int)$_GET['section_id'] : null;
    $dayName = isset($_GET['day']) ? strtolower(trim($_GET['day'])) : null;

    // Validate day name if provided
    if ($dayName && !in_array($dayName, ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'])) {
        throw new Exception("Invalid day name. Must be a weekday (Monday-Sunday)");
    }

    // Build base query with joins
    $query = "
        SELECT 
            cr.id,
            cr.day_name,
            cr.room_number,
            cr.start_time,
            cr.end_time,
            c.id AS class_id,
            c.class_name,
            s.id AS section_id,
            s.section_name,
            sub.id AS subject_id,
            sub.subject_name,
            sub.subject_type,
            t.id AS teacher_id,
            t.teacher_id AS teacher_code,
            t.name AS teacher_name,
            t.teacher_image
        FROM class_routines cr
        JOIN classes c ON cr.class_id = c.id
        JOIN sections s ON cr.section_id = s.id
        JOIN subjects sub ON cr.subject_id = sub.id
        LEFT JOIN teachers t ON cr.teacher_id = t.id
        WHERE 1=1
    ";

    $params = [];

    // Add filters
    if ($classId) {
        $query .= " AND cr.class_id = ?";
        $params[] = $classId;
    }

    if ($sectionId) {
        $query .= " AND cr.section_id = ?";
        $params[] = $sectionId;
    }

    if ($dayName) {
        $query .= " AND LOWER(cr.day_name) = ?";
        $params[] = $dayName;
    }

    // Add sorting
    $query .= " ORDER BY 
        FIELD(cr.day_name, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'),
        cr.start_time";

    // Prepare and execute query
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $routines = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Format the response
    $formattedRoutines = [];
    foreach ($routines as $routine) {
        // Format teacher data if exists
        $teacher = null;
        if ($routine['teacher_id']) {
            $teacher = [
                'id' => $routine['teacher_id'],
                'teacher_id' => $routine['teacher_code'],
                'name' => $routine['teacher_name'],
                'image' => $routine['teacher_image'] ?: 'default_teacher_dp.jpg'
            ];
        }

        $formattedRoutines[] = [
            'id' => $routine['id'],
            'day' => ucfirst($routine['day_name']),
            'start_time' => substr($routine['start_time'], 0, 5), // HH:MM format
            'end_time' => substr($routine['end_time'], 0, 5),     // HH:MM format
            'room_number' => $routine['room_number'],
            'class' => [
                'id' => $routine['class_id'],
                'name' => $routine['class_name']
            ],
            'section' => [
                'id' => $routine['section_id'],
                'name' => $routine['section_name']
            ],
            'subject' => [
                'id' => $routine['subject_id'],
                'name' => $routine['subject_name'],
                'type' => $routine['subject_type']
            ],
            'teacher' => $teacher
        ];
    }

    // Group by day for better organization
    $groupedByDay = [];
    foreach ($formattedRoutines as $routine) {
        $groupedByDay[$routine['day']][] = $routine;
    }

    // Return response
    echo json_encode([
        'success' => true,
        'data' => $groupedByDay,
        'meta' => [
            'total' => count($routines),
            'filters' => [
                'class_id' => $classId,
                'section_id' => $sectionId,
                'day' => $dayName
            ]
        ]
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}