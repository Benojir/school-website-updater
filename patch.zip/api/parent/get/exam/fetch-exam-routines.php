<?php
include_once(__DIR__ . "/../../../../includes/config.php");

header('Content-Type: application/json');

$class_id = $_REQUEST['class_id'] ?? '';

if (empty($class_id)) {
    echo json_encode(['success' => false, 'message' => 'Class ID is required']);
    exit;
}

// First get all active exams
$stmt = $pdo->prepare("SELECT * FROM exams WHERE status = 'active' ORDER BY exam_date DESC");
$stmt->execute();
$exams = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$exams) {
    echo json_encode(['success' => false, 'message' => 'No active exams found']);
    exit;
}

$exam_routines = [];

foreach ($exams as $exam) {
    // Fetch exam routine
    $stmt = $pdo->prepare("
        SELECT exam_routines.*, subjects.subject_name 
        FROM exam_routines 
        JOIN subjects ON exam_routines.subject_id = subjects.id
        WHERE exam_routines.exam_id = ? AND exam_routines.class_id = ?
    ");
    $stmt->execute([$exam['id'], $class_id]);
    $routines = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $exam_routines[] = [
        'class_id' => (int) $class_id,
        'exam_id' => $exam['id'],
        'exam_name' => $exam['exam_name'],
        'exam_date' => $exam['exam_date'],
        'routines' => $routines
    ];
}

echo json_encode(['success' => true, 'message' => 'Routines fetched successfully', "data" => $exam_routines]);
exit;