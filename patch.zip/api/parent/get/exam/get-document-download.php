<?php
require_once __DIR__ . '/../../../../includes/parent/auth/parent-auth-check.php';
require_once __DIR__ . '/../../../../includes/exam-document-access.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$auth = authenticateApiRequest($pdo);
try {
    $type = $_GET['type'] ?? '';
    if (!is_string($type) || !in_array($type, ['admit', 'marksheet'], true)) throw new InvalidArgumentException('Choose an admit card or marksheet.');
    $request = examDocumentRequest($type, $_GET);
    $url = examDocumentIssueLink($pdo, $request, $auth, BASE_URL);
    echo json_encode(['success' => true, 'data' => ['download_url' => $url]]);
} catch (InvalidArgumentException | ExamDocumentDenied $error) {
    http_response_code($error instanceof ExamDocumentDenied ? ($error->getCode() ?: 403) : 422);
    echo json_encode(['success' => false, 'message' => $error->getMessage()]);
} catch (Throwable $error) {
    error_log('Parent document link: ' . $error->getMessage());
    http_response_code(503);
    echo json_encode(['success' => false, 'message' => 'Document downloads are temporarily unavailable. Please try again later.']);
}
