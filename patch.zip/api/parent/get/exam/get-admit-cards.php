<?php
include_once(__DIR__ . "/../../../../includes/parent/auth/parent-auth-check.php");

header('Content-Type: application/json');

// Authenticate the parent first
$auth = authenticateApiRequest($pdo);

$studentId = sanitize_input($_REQUEST['student_id'] ?? '');

// Validate student_id parameter
if (empty($studentId)) {
    echo json_encode(['success' => false, 'message' => 'Student ID is required']);
    exit;
}

// Check if parent has permission to access this student
if (!hasParentAccessToStudent($auth['phone_number'], $studentId)) {
    echo json_encode(['success' => false, 'message' => 'You do not have permission to access this student']);
    exit;
}

// Get student data with current class information
$student = getStudentInfo($pdo, $studentId);

if (!$student) {
    echo json_encode(['success' => false, 'message' => 'Student not found']);
    exit;
}

// Get all released admit cards for the student's current class
$admitCards = getStudentAdmitCards($student['class_id'], $studentId);

// Return the data
echo json_encode([
    'success' => true,
    'data' => [
        'student_info' => $student,
        'admit_cards' => $admitCards,
        'download_permissions' => getDownloadPermissions($studentId, areAllFeesPaid($studentId))
    ]
]);

/**
 * Get all released admit cards for a student's class
 */
function getStudentAdmitCards(int $classId, string $studentId)
{
    global $pdo;

    $stmt = $pdo->prepare("SELECT ea.id, e.exam_name, e.exam_date, ea.release_date, ea.status,
                          CONCAT('/api/download/download-admit-card.php?admit_id=', ea.id, '&student_id=', ?) as download_url
                          FROM exam_admit_releases ea
                          JOIN exams e ON ea.exam_id = e.id
                          WHERE ea.class_id = ? 
                          AND ea.status = 'released'
                          ORDER BY e.exam_date DESC");
    $stmt->execute([$studentId, $classId]);

    $admitCards = $stmt->fetchAll();

    // Format dates and add additional fields
    foreach ($admitCards as &$card) {
        $card['exam_date_formatted'] = date('d M Y', strtotime($card['exam_date']));
        $card['release_date_formatted'] = date('d M Y', strtotime($card['release_date']));
    }

    return $admitCards;
}

/**
 * Check if all fees are paid for a student
 */
function areAllFeesPaid(string $studentId)
{
    global $pdo;

    $stmt = $pdo->prepare("SELECT id FROM student_unpaid_fees WHERE student_id = ? AND unpaid_amount > 0 LIMIT 1");
    $stmt->execute([$studentId]);
    $monthlyFee = $stmt->fetch();

    $stmt = $pdo->prepare("SELECT id FROM admission_unpaid_fees WHERE student_id = ? AND unpaid_amount > 0 LIMIT 1");
    $stmt->execute([$studentId]);
    $admissionFee = $stmt->fetch();

    $stmt = $pdo->prepare("SELECT id FROM additional_fees_data WHERE student_id = ? AND additional_fee_status = 'unpaid' LIMIT 1");
    $stmt->execute([$studentId]);
    $additionalFees = $stmt->fetch();

    return !$monthlyFee && !$admissionFee && !$additionalFees;
}

/**
 * Check if student can download admit card
 */
function canDownloadAdmitCard(string $studentId)
{
    global $pdo;

    // First check if there's an override permission
    $stmt = $pdo->prepare("SELECT override_admit_check, allow_admit_card 
                          FROM student_download_permissions 
                          WHERE student_id = ?");
    $stmt->execute([$studentId]);
    $permission = $stmt->fetch();

    if ($permission && $permission['override_admit_check']) {
        return (bool)$permission['allow_admit_card'];
    }

    // If no override, check if all fees are paid
    return areAllFeesPaid($studentId);
}

/**
 * Get download permissions (same as in get-student-data.php)
 */
function getDownloadPermissions(string $studentId, bool $allFeesPaid)
{
    global $pdo;

    $permissions = [
        'can_download_admit' => $allFeesPaid,
        'can_download_marksheet' => $allFeesPaid,
        'has_override' => false
    ];

    // Check if there are any permission overrides
    $stmt = $pdo->prepare("SELECT 
                          override_admit_check,
                          allow_admit_card,
                          override_marksheet_check,
                          allow_marksheet
                          FROM student_download_permissions
                          WHERE student_id = ?");
    $stmt->execute([$studentId]);
    $permissionData = $stmt->fetch();

    if ($permissionData) {
        // Check admit card override
        if ($permissionData['override_admit_check']) {
            $permissions['can_download_admit'] = $permissionData['allow_admit_card'];
            $permissions['has_override'] = true;
        }

        // Check marksheet override
        if ($permissionData['override_marksheet_check']) {
            $permissions['can_download_marksheet'] = $permissionData['allow_marksheet'];
            $permissions['has_override'] = true;
        }
    }

    return $permissions;
}
