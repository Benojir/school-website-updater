<?php
require_once __DIR__ . '/../../../../includes/parent/auth/parent-auth-check.php';
require_once __DIR__ . '/../../../../includes/exam-document-access.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

// Authenticate the parent first
$auth = authenticateApiRequest($pdo);
$studentId = $_GET['student_id'] ?? '';
if (!is_string($studentId) || trim($studentId) === '') {
    exit(json_encode(['success' => false, 'message' => 'Student ID is required']));
}
$studentId = trim($studentId);
if (!hasParentAccessToStudent($auth['phone_number'], $studentId)) {
    http_response_code(403);
    exit(json_encode(['success' => false, 'message' => 'You do not have permission to access this student']));
}
$student = getStudentInfo($pdo, $studentId);
if (!$student) exit(json_encode(['success' => false, 'message' => 'Student not found']));
try {
    $admitCards = getStudentAdmitCards((int) $student['id'], $studentId);
    echo json_encode(['success' => true, 'data' => [
        'student_info' => schoolPhotoWithUrls($student), 'admit_cards' => $admitCards,
        'download_permissions' => examDocumentPermissions($pdo, $studentId)
    ]]);
} catch (Throwable $error) {
    error_log('Parent admit cards: ' . $error->getMessage());
    http_response_code(503);
    echo json_encode(['success' => false, 'message' => 'Admit cards are temporarily unavailable. Please try again later.']);
}

/** Preserve historical class matching; a scheduled release becomes visible only when due. */
function getStudentAdmitCards(int $studentRowId, string $studentId): array
{
    global $pdo;
    $stmt = $pdo->prepare("SELECT ea.id, e.exam_name, e.exam_date, ea.release_date, ea.status,
                          CONCAT('/api/download/download-admit-card.php?admit_id=', ea.id, '&student_ids=', ?) AS download_url
                          FROM exam_admit_releases ea
                          JOIN exams e ON ea.exam_id = e.id
                          WHERE EXISTS (
                              SELECT 1 FROM student_academic_records ar
                              WHERE ar.student_row_id = ?
                                AND ar.academic_year = e.academic_year
                                AND ar.class_id = ea.class_id
                          )
                          AND ea.status = 'released'
                          AND ea.release_date <= ?
                          ORDER BY e.exam_date DESC");
    $stmt->execute([$studentId, $studentRowId, date('Y-m-d H:i:s')]);
    $cards = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($cards as &$card) {
        $card['exam_date_formatted'] = date('d M Y', strtotime($card['exam_date']));
        $card['release_date_formatted'] = date('d M Y', strtotime($card['release_date']));
    }
    unset($card);
    return $cards;
}
