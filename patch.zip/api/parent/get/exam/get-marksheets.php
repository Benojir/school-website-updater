<?php
include_once(__DIR__ . "/../../../../includes/parent/auth/parent-auth-check.php");

header('Content-Type: application/json');

// Authenticate the parent first
$parent = authenticateApiRequest($pdo);

$studentId = sanitize_input($_REQUEST['student_id'] ?? null);

// Validate student_id parameter
if (empty($studentId)) {
    echo json_encode(['success' => false, 'message' => 'Student ID is required']);
    exit;
}

// Check if parent has permission to access this student
if (!hasParentAccessToStudent($parent['parent_id'], $studentId)) {
    echo json_encode(['success' => false, 'message' => 'You do not have permission to access this student']);
    exit;
}

// Get student data with current class information
$student = getStudentInfo($pdo, $studentId);
if (!$student) {
    echo json_encode(['success' => false, 'message' => 'Student not found']);
    exit;
}


// Get all marksheets for the student
$marksheets = getStudentMarksheets($studentId);

// Return the data
echo json_encode([
    'success' => true,
    'data' => [
        'student_info' => [
            'student_id' => $student['student_id'],
            'name' => $student['name'],
            'class_name' => $student['class_name'],
            'section_name' => $student['section_name'],
            'roll_no' => $student['roll_no'],
            'student_image' => $student['student_image']
        ],
        'marksheets' => $marksheets
    ]
]);


/**
 * Get all marksheets for a student with optional filtering
 */
function getStudentMarksheets($studentId) {
    global $pdo;
    
    $sql = "SELECT r.id, r.student_id, r.exam_id, 
    r.class_id, r.percentage, r.percentage_without_minor, 
    r.grade, r.grade_without_minor, r.obtained_marks, 
    r.obtained_minor_marks, r.total_marks, r.total_minor_marks,
    e.exam_name, e.exam_date, c.class_name
    FROM results r
    JOIN exams e ON r.exam_id = e.id
    JOIN classes c ON r.class_id = c.id
    WHERE r.student_id = ?
    ORDER BY e.exam_date DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$studentId]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch marksheet settings
    $stmt = $pdo->prepare("SELECT * FROM settings_marksheet LIMIT 1");
    $stmt->execute();
    $marksheet_settings = $stmt->fetch(PDO::FETCH_ASSOC);

    $marksheets = [];
    foreach ($results as $result) {

        $grade = $result['grade'];
        $percentage = $result['percentage'];
        $obtained_marks = $result['obtained_marks'];
        $total_marks = $result['total_marks'];
        
        if (!$marksheet_settings['include_minor_subjects_marks']) {
            $grade = $result['grade_without_minor'];
            $percentage = $result['percentage_without_minor'];
            $obtained_marks = $result['obtained_marks'] - $result['obtained_minor_marks'];
            $total_marks = $result['total_marks'] - $result['total_minor_marks'];
        }

        $marksheets[] = [
            'student_id' => $result['student_id'],
            'result_id' => $result['id'],
            'exam_id' => $result['exam_id'],
            'exam_name' => $result['exam_name'],
            'exam_date' => $result['exam_date'],
            'class_id' => $result['class_id'],
            'class_name' => $result['class_name'],
            'percentage' => $percentage,
            'grade' => $grade,
            'obtained_marks' => $obtained_marks,
            'total_marks' => $total_marks
        ];
    }

    return $marksheets;
}