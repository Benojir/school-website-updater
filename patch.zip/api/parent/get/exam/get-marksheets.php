<?php
include_once(__DIR__ . "/../../../../includes/parent/auth/parent-auth-check.php");

header('Content-Type: application/json');

// Authenticate the parent first
$parent = authenticateApiRequest($pdo);

// Validate student_id parameter
if (empty($_GET['student_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Student ID is required']);
    exit;
}

$studentId = sanitize_input($_GET['student_id']);

// Check if parent has permission to access this student
if (!hasParentAccessToStudent($parent['parent_id'], $studentId)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'You do not have permission to access this student']);
    exit;
}

// Get student data with current class information
$student = getStudentWithClassInfo($studentId);
if (!$student) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Student not found']);
    exit;
}

// Process filter parameters
$classFilter = $_GET['class_filter'] ?? '';
$sortBy = $_GET['sort_by'] ?? 'date_desc';

// Get all marksheets for the student
$marksheets = getStudentMarksheets($studentId, $classFilter, $sortBy);

// Get available classes for filtering
$availableClasses = getAvailableClassesForStudent($studentId);

// Return the data
echo json_encode([
    'success' => true,
    'data' => [
        'student_info' => [
            'student_id' => $student['student_id'],
            'name' => $student['name'],
            'class_name' => $student['class_name'],
            'section_name' => $student['section_name'],
            'roll_no' => $student['roll_no'],
            'student_image' => $student['student_image']
        ],
        'available_classes' => $availableClasses,
        'marksheets' => $marksheets,
        'download_permissions' => getDownloadPermissions($studentId, areAllFeesPaid($studentId)),
        'filters' => [
            'current_class_filter' => $classFilter,
            'current_sort_by' => $sortBy
        ]
    ]
]);

/**
 * Get student data with class information
 */
function getStudentWithClassInfo($studentId) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT s.student_id, s.name, s.roll_no, s.student_image, 
                          c.class_name, sec.section_name, s.class_id
                          FROM students s 
                          JOIN classes c ON s.class_id = c.id 
                          JOIN sections sec ON s.section_id = sec.id 
                          WHERE s.student_id = ?");
    $stmt->execute([$studentId]);
    return $stmt->fetch();
}

/**
 * Get all classes the student has results for
 */
function getAvailableClassesForStudent($studentId) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT DISTINCT c.id, c.class_name 
                          FROM results r 
                          JOIN classes c ON r.class_id = c.id 
                          WHERE r.student_id = ? 
                          ORDER BY c.class_name");
    $stmt->execute([$studentId]);
    return $stmt->fetchAll();
}

/**
 * Get all marksheets for a student with optional filtering
 */
function getStudentMarksheets($studentId, $classFilter, $sortBy) {
    global $pdo;
    
    // Build base query
    $query = "
        SELECT r.*, e.exam_name, e.exam_date, c.class_name,
               CONCAT('/download-marksheet.php?result_id=', r.id) as download_url
        FROM results r
        JOIN exams e ON r.exam_id = e.id
        JOIN classes c ON r.class_id = c.id
        INNER JOIN exam_marksheet_releases emr 
            ON emr.exam_id = r.exam_id AND emr.class_id = r.class_id
        WHERE r.student_id = ?
    ";
    
    $params = [$studentId];
    
    // Add class filter if selected
    if (!empty($classFilter)) {
        $query .= " AND r.class_id = ?";
        $params[] = $classFilter;
    }
    
    // Add sorting
    switch ($sortBy) {
        case 'date_asc':
            $query .= " ORDER BY e.exam_date ASC";
            break;
        case 'percentage_desc':
            $query .= " ORDER BY r.percentage DESC";
            break;
        case 'percentage_asc':
            $query .= " ORDER BY r.percentage ASC";
            break;
        default: // date_desc
            $query .= " ORDER BY e.exam_date DESC";
    }
    
    // Execute query
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $marksheets = $stmt->fetchAll();
    
    // Format data for mobile response
    foreach ($marksheets as &$marksheet) {
        $marksheet['exam_date_formatted'] = date('d M Y', strtotime($marksheet['exam_date']));
        $marksheet['grade_class'] = 'grade-' . str_replace('+', 'plus', $marksheet['grade']);
        $marksheet['can_download'] = canDownloadMarksheet($studentId);
    }
    
    return $marksheets;
}

/**
 * Check if all fees are paid for a student
 */
function areAllFeesPaid($studentId) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT SUM(unpaid_amount) as total_unpaid 
                          FROM student_unpaid_fees 
                          WHERE student_id = ?");
    $stmt->execute([$studentId]);
    $result = $stmt->fetch();
    
    return ($result && $result['total_unpaid'] <= 0);
}

/**
 * Check if student can download marksheet
 */
function canDownloadMarksheet($studentId) {
    global $pdo;
    
    // First check if there's an override permission
    $stmt = $pdo->prepare("SELECT override_marksheet_check, allow_marksheet 
                          FROM student_download_permissions 
                          WHERE student_id = ?");
    $stmt->execute([$studentId]);
    $permission = $stmt->fetch();
    
    if ($permission && $permission['override_marksheet_check']) {
        return (bool)$permission['allow_marksheet'];
    }
    
    // If no override, check if all fees are paid
    return areAllFeesPaid($studentId);
}

/**
 * Get download permissions (same as in get-student-data.php)
 */
function getDownloadPermissions($studentId, $allFeesPaid) {
    global $pdo;
    
    $permissions = [
        'can_download_admit' => $allFeesPaid,
        'can_download_marksheet' => $allFeesPaid,
        'has_override' => false
    ];
    
    // Check if there are any permission overrides
    $stmt = $pdo->prepare("SELECT 
                          override_admit_check,
                          allow_admit_card,
                          override_marksheet_check,
                          allow_marksheet
                          FROM student_download_permissions
                          WHERE student_id = ?");
    $stmt->execute([$studentId]);
    $permissionData = $stmt->fetch();
    
    if ($permissionData) {
        // Check admit card override
        if ($permissionData['override_admit_check']) {
            $permissions['can_download_admit'] = $permissionData['allow_admit_card'];
            $permissions['has_override'] = true;
        }
        
        // Check marksheet override
        if ($permissionData['override_marksheet_check']) {
            $permissions['can_download_marksheet'] = $permissionData['allow_marksheet'];
            $permissions['has_override'] = true;
        }
    }
    
    return $permissions;
}