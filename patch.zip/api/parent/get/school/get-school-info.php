<?php
include_once(__DIR__ . "/../../../../includes/config.php");

header('Content-Type: application/json');

try {
    // Get total students
    $stmt = $pdo->query("SELECT COUNT(*) AS students FROM students WHERE status = 'Active'");
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $totalStudents = $row['students'];

    // Get classes with fees
    $stmt = $pdo->prepare("
        SELECT class_wise_monthly_fees.amount, classes.class_name
        FROM class_wise_monthly_fees
        LEFT JOIN classes ON classes.id = class_wise_monthly_fees.class_id;
    ");
    $stmt->execute();
    $class_wise_fees = $stmt->fetchAll();
    $total_classes = count($class_wise_fees);

    // Get subjects information
    $stmt = $pdo->prepare("SELECT * FROM subjects  ORDER BY class_id ASC");
    $stmt->execute();
    $subjects = $stmt->fetchAll();

    $classes = [];

    foreach ($subjects as $subject) {
        $class_name = $subject['class'];
        if (!isset($classes[$class_name])) {
            $classes[$class_name] = [];
        }
        $classes[$class_name][] = $subject['subject_name'];
    }

    // Get active exams
    $stmt = $pdo->prepare("SELECT * FROM exams WHERE status = 'active'");
    $stmt->execute();
    $exams = $stmt->fetchAll();

    // Get teachers
    $stmt = $pdo->prepare("SELECT * FROM teachers WHERE status = 'active'");
    $stmt->execute();
    $teachers = $stmt->fetchAll();
    $total_teachers = count($teachers);

    // Get latest school notice
    $stmt = $pdo->prepare("SELECT * FROM notices ORDER BY notice_date DESC, created_at DESC LIMIT 1");
    $stmt->execute();
    $latestNotice = $stmt->fetch(PDO::FETCH_ASSOC);

    // Important links
    $admission_link = $schoolInfo['school_website_address'] . '/enquiries/form/admission-enquiry.php';
    $teacher_application_link = $schoolInfo['school_website_address'] . '/enquiries/form/teacher-application.php';
    $user_password_reset_link = $schoolInfo['school_website_address'] . '/parent/login/forgot-password.php';
    $user_new_registration_link = $schoolInfo['school_website_address'] . '/parent/login/parent-auth.php';

    $structuredData = [
        'basic_info' => [
            'school_name' => $schoolInfo['name'],
            'school_address' => $schoolInfo['address'],
            'school_phone' => $schoolInfo['phone'],
            'school_email' => $schoolInfo['email'],
            'principal' => [
                'name' => $schoolInfo['principal_name'],
                'phone' => $schoolInfo['principal_phone'],
                'email' => $schoolInfo['principal_email']
            ],
            'school_website' => $schoolInfo['school_website_address'],
            'school_established_year' => $schoolInfo['established_year'],
            'school_description' => $schoolInfo['description'],
            'school_social_links' => [
                'google_map' => $schoolInfo['google_map_link'],
                'facebook' => $schoolInfo['facebook'],
                'instagram' => $schoolInfo['instagram'],
                'whatsapp' => $schoolInfo['whatsapp'],
                'youtube' => $schoolInfo['youtube']
            ],
            'admission_open' => $websiteConfig['admission_open'],
            'teacher_recruitment_open' => $websiteConfig['teacher_application']
        ],
        'classes' => array_map(function ($class) {
            return [
                'name' => $class['class_name'],
                'monthly_fee' => $class['amount']
            ];
        }, $class_wise_fees),
        'subjects_by_class' => $classes,
        'exams' => array_map(function ($exam) {
            return [
                'name' => $exam['exam_name'],
                'date' => $exam['exam_date']
            ];
        }, $exams),
        'teachers' => array_map(function ($teacher) {
            return [
                'name' => $teacher['name'],
                'email' => $teacher['email'],
                'phone' => $teacher['phone'],
                'specialization' => $teacher['subject_specialization']
            ];
        }, $teachers),
        'totals' => [
            'students' => $totalStudents,
            'classes' => $total_classes,
            'subjects' => count($subjects),
            'teachers' => $total_teachers
        ],
        'important_links' => [
            'admission' => $admission_link,
            'teacher_application' => $teacher_application_link,
            'password_reset' => $user_password_reset_link,
            'new_registration' => $user_new_registration_link
        ],
        'latest_notice' => $latestNotice,
        'developer' => [
            'name' => 'Nur Alam',
            'phone' => '+918348313317'
        ]
    ];

    // Convert the array to pretty JSON for the prompt
    $structuredDataJson = json_encode($structuredData, JSON_PRETTY_PRINT);

    $chatbot_prompt = <<<PROMPT
You are a helpful school information chatbot called Dahuk AI.

**Instructions:**
- ONLY answer questions about this school.
- If asked anything unrelated, politely decline.
- Use only the data provided below. Do not make up information.

**School Data:**
$structuredDataJson

PROMPT;


    echo json_encode([
        'success' => true,
        'message' => 'School information retrieved successfully.',
        'data' => [
            'school_information' => $schoolInfo,
            'chatbot_prompt' => $chatbot_prompt
        ]
    ]);
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
