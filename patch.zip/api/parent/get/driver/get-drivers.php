<?php
include_once(__DIR__ . "/../../../../includes/parent/auth/parent-auth-check.php");

header('Content-Type: application/json');

$authData = authenticateApiRequest($pdo);
$phone = $authData['phone_number'];
// $phone = '9083156928';

// Fetch all drivers and driving route ids
$stmt = $pdo->prepare("
    SELECT DISTINCT driver_id
    FROM students
    WHERE
        (phone_number = ? OR alternate_phone_number = ?)
        AND driver_id IS NOT NULL
        AND driver_id != ''
");
$stmt->execute([$phone, $phone]);
$drivers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch driver data
$driverData = [];
foreach ($drivers as $driver) {
    $stmt = $pdo->prepare('SELECT * FROM drivers WHERE id = ? AND status = "active"');
    $stmt->execute([$driver['driver_id']]);
    $driver_data = $stmt->fetch();

    if ($driver_data) {
        $driverData[] = $driver_data;
    }
}

// Return the data
echo json_encode([
    'success' => true,
    'data' => $driverData
]);