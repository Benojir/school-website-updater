<?php
include_once(__DIR__ . "/../../../../includes/parent/auth/parent-auth-check.php");

header('Content-Type: application/json');

$authData = authenticateApiRequest($pdo);
$phone = $authData['phone_number'];
// $phone = '9083156928';

// Fetch all drivers and driving route ids
$stmt = $pdo->prepare("
    SELECT DISTINCT driver_id
    FROM students
    WHERE
        (phone_number = ? OR alternate_phone_number = ?)
        AND driver_id IS NOT NULL
        AND driver_id != ''
");
$stmt->execute([$phone, $phone]);
$drivers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch driver data
// Only the columns a parent's app actually needs. The drivers table also holds
// bank/PAN/Aadhaar details, the driver's own family contacts and document URLs -
// none of that should ever be sent to a parent.
$driverData = [];
foreach ($drivers as $driver) {
    $stmt = $pdo->prepare('
        SELECT id, name, phone, email, serial_number, vehicle_number, route_ids, driver_image, status
        FROM drivers
        WHERE id = ? AND status = "active"
    ');
    $stmt->execute([$driver['driver_id']]);
    $driver_data = $stmt->fetch();

    if ($driver_data) {
        $driverData[] = $driver_data;
    }
}

// Return the data
echo json_encode([
    'success' => true,
    'data' => $driverData
]);