<?php
include_once(__DIR__ . "/../../../includes/config.php");

header('Content-Type: application/json');

// Validate request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Validate required fields
$requiredFields = ['phone', 'password', 'device_id'];
foreach ($requiredFields as $field) {
    if (empty($_POST[$field])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => "Field $field is required"]);
        exit;
    }
}

$phone = sanitize_input($_POST['phone']);
$password = $_POST['password'];
$deviceId = sanitize_input($_POST['device_id']);
$deviceName = sanitize_input($_POST['device_name'] ?? 'Unknown Device');
$fcmToken = sanitize_input($_POST['fcm_token'] ?? null);

// Validate phone number format
if (!isValidPhoneNumber($phone)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Phone number is invalid. Do not add country code.']);
    exit;
}

// Check if parent exists
$stmt = $pdo->prepare("SELECT id, phone_number, password_hash, student_ids FROM parent_accounts WHERE phone_number = ?");
$stmt->execute([$phone]);
$parent = $stmt->fetch();

if (!$parent) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Invalid phone number or password']);
    exit;
}

// Verify password
if (!password_verify($password, $parent['password_hash'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Invalid phone number or password']);
    exit;
}

// Before generating a new token, invalidate any existing sessions for this device
$stmt = $pdo->prepare("DELETE FROM parent_auth_sessions WHERE device_id = ?");
$stmt->execute([$deviceId]);

// Generate new token
$token = bin2hex(random_bytes(32));
$tokenHash = hash('sha256', $token);
$expiry = date('Y-m-d H:i:s', strtotime('+30 days'));

// Store mobile session
$stmt = $pdo->prepare(
    "INSERT INTO parent_auth_sessions 
        (parent_id, token_hash, device_id, device_name, fcm_token, expires_at, session_source) 
     VALUES (?, ?, ?, ?, ?, ?, 'mobile')" // Added 'mobile'
);
$stmt->execute([
    $parent['id'],
    $tokenHash,
    $deviceId,
    $deviceName,
    $fcmToken,
    $expiry
]);

// Prepare response
$response = [
    'success' => true,
    'message' => 'Mobile login successful',
    'data' => [
        'parent_id' => $parent['id'],
        'phone_number' => $parent['phone_number'],
        'token' => $token,
        'expires_at' => $expiry
    ]
];

echo json_encode($response);