<?php
include_once(__DIR__ . "/../../../includes/parent/auth/parent-auth-check.php");

header('Content-Type: application/json');

// Use the new helper function from auth-check.php
$authData = authenticateApiRequest($pdo); 

if (!$authData) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Delete the session from the NEW table
$stmt = $pdo->prepare("DELETE FROM parent_auth_sessions WHERE id = ?");
$logout = $stmt->execute([$authData['session_id']]);

if (!$logout) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Logout failed. Please try again.']);
    exit;
}

// Delete rows associated with this mobile device
$stmt = $pdo->prepare("DELETE FROM parent_auth_sessions WHERE device_id = ?");
$stmt->execute([$authData['device_id']]);

echo json_encode(['success' => true, 'message' => 'Logout successful']);