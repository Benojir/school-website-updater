<?php
include_once(__DIR__ . "/../../../includes/config.php");

header('Content-Type: application/json');

// 1. Delete the session from the database (if it exists)
if (!empty($_COOKIE['auth_token'])) {
    $token = $_COOKIE['auth_token'];
    $tokenHash = hash('sha256', $token);
    
    // Use the new table name
    $stmt = $pdo->prepare("DELETE FROM parent_auth_sessions WHERE token_hash = ?");
    $stmt->execute([$tokenHash]);
}

// 2. Expire the cookie by setting its expiry date to the past
setcookie('auth_token', '', [
    'expires' => time() - 3600, // 1 hour ago
    'path' => '/',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

// 3. Clear any old session data just in case
if (session_status() == PHP_SESSION_ACTIVE) {
    session_destroy();
}

// 4. Response logout success
echo json_encode(['success' => true, 'message' => 'Logged out successfully']);
exit();