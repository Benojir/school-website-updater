<?php
include_once(__DIR__ . "/../../../includes/config.php");
include_once(__DIR__ . "/../../../includes/otp-sending-helper.php");

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(['success' => false, 'message' => 'Invalid request method']));
}

$phone = sanitize_input($_POST['phone']);
$purpose = sanitize_input($_POST['purpose']);

// Validate inputs
if (empty($phone) || empty($purpose)) {
    die(json_encode(['success' => false, 'message' => 'Phone number and purpose are required']));
}

// Check if phone number is valid based on purpose
if ($purpose === 'signup') {
    $stmt = $pdo->prepare("SELECT student_id FROM students WHERE phone_number = ?");
    $stmt->execute([$phone]);
    if (!$stmt->fetch()) {
        die(json_encode(['success' => false, 'message' => 'This phone number is not registered with any student']));
    }
} else {
    $stmt = $pdo->prepare("SELECT id FROM parent_accounts WHERE phone_number = ?");
    $stmt->execute([$phone]);
    if (!$stmt->fetch()) {
        die(json_encode(['success' => false, 'message' => 'No account found with this phone number']));
    }
}

// Generate new OTP
$otp = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

// Store new OTP in database
$stmt = $pdo->prepare("INSERT INTO otp_verification (phone_number, otp, expiry, purpose) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE), ?)");
$stmt->execute([$phone, $otp, $expiry, $purpose]);

// Send the OTP here
$result = sendOTP($websiteConfig, $phone, $otp);

if (!$result['success']) {
    sendErrorResponse($result['message']);
}
sendSuccessResponse($result['message']);