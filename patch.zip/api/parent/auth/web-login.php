<?php
include_once(__DIR__ . "/../../../includes/config.php");
// No need for auth-check.php, this is a public endpoint

define('AUTH_TOKEN_DURATION_DAYS', 30); // For "Remember Me"
define('SESSION_DURATION_DAYS', 1);    // For a standard session

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(['success' => false, 'message' => 'Invalid request method']));
}

$phone = sanitize_input($_POST['phone']);
$password = $_POST['password'];
$rememberMe = isset($_POST['remember_me']) ? true : false;

// Validate inputs
if (empty($phone) || empty($password)) {
    die(json_encode(['success' => false, 'message' => 'Phone number and password are required']));
}
if (!isValidPhoneNumber($phone)) {
    die(json_encode(['success' => false, 'message' => 'Phone number is invalid. Do not add country code.']));
}

// Check if parent exists
$stmt = $pdo->prepare("SELECT * FROM parent_accounts WHERE phone_number = ?");
$stmt->execute([$phone]);
$parent = $stmt->fetch();

// Verify password
if (!$parent || !password_verify($password, $parent['password_hash'])) {
    die(json_encode(['success' => false, 'message' => 'Invalid phone number or password']));
}

// --- NEW TOKEN LOGIC (Replaces SESSION logic) ---

// 1. Generate a new, secure token
$token = bin2hex(random_bytes(32));
$tokenHash = hash('sha256', $token);

$durationDays = $rememberMe ? AUTH_TOKEN_DURATION_DAYS : SESSION_DURATION_DAYS;
$expiry = date('Y-m-d H:i:s', strtotime("+$durationDays days"));
$cookieExpiryTime = $rememberMe ? (time() + (86400 * $durationDays)) : 0; // 0 = session cookie

// 2. Get web-specific device info
$deviceId = sanitize_input($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown Web');
$deviceName = 'Web Browser';

// 3. Store the session in the *same* database table as mobile
$stmt = $pdo->prepare(
    "INSERT INTO parent_auth_sessions 
        (parent_id, token_hash, device_id, device_name, fcm_token, expires_at, session_source) 
     VALUES (?, ?, ?, ?, ?, ?, 'web')"
);
$stmt->execute([
    $parent['id'],
    $tokenHash,
    $deviceId,
    $deviceName,
    null, // No FCM token for web
    $expiry
]);

// 4. Set the token in a secure, HttpOnly cookie
setcookie('parent_auth_token', $token, [
    'expires' => $cookieExpiryTime,
    'path' => '/',
    'secure' => true,   // Set to true for HTTPS
    'httponly' => true, // Crucial: Prevents JavaScript access
    'samesite' => 'Strict' // Best for security
]);

// 5. Remove any old session data (just in case)
if (session_status() == PHP_SESSION_ACTIVE) {
    session_unset();
    session_destroy();
}

echo json_encode(['success' => true, 'message' => 'Login successful']);