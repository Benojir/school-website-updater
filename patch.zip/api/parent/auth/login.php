<?php
include_once(__DIR__ . "/../../../includes/config.php");
include_once(__DIR__ . "/../../../includes/otp-sending-helper.php");

header('Content-Type: application/json');

// Validate request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$phone = sanitize_input($_POST['phone'] ?? null);

if (!$phone) {
    echo json_encode(['success' => false, 'message' => 'Phone number is required']);
    exit;
}

// Validate phone number format
if (!isValidPhoneNumber($phone)) {
    echo json_encode(['success' => false, 'message' => 'Phone number is invalid. Do not add country code.']);
    exit;
}

// Check if the phone number is associated with any active student
$stmt = $pdo->prepare("SELECT student_id FROM students WHERE (phone_number = ? OR alternate_phone_number = ?) AND status = 'active' LIMIT 1");
$stmt->execute([$phone, $phone]);
$student = $stmt->fetch();

if (!$student) {
    echo json_encode(['success' => false, 'message' => 'Phone number is not associated with any active student']);
    exit;
}

// Delete all expired stored OTPs for optimazation
$stmt = $pdo->prepare("DELETE FROM otp_verification WHERE expiry < NOW()");
$stmt->execute();

// Send otp to the phone number
$otp = generateOTP(6);
$result = sendOTP($phone, $otp);

if ($result['success']) {
    // Store OTP in database
    $stmt = $pdo->prepare("INSERT INTO otp_verification (phone_number, otp, expiry, purpose) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE), ?)");
    $stmt->execute([$phone, $otp, 'login']);
    echo json_encode(['success' => true, 'message' => 'OTP sent successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'OTP could not be sent. Please try again later.']);
}