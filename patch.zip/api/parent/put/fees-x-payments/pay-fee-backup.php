<?php
include_once(__DIR__ . "/../../../../includes/config.php");

if (!isset($_REQUEST['id']) || empty($_REQUEST['id']) || !is_numeric($_REQUEST['id']) 
    || !isset($_REQUEST['type']) || empty($_REQUEST['type'])) {
    die('Invalid request');
}

$unpaid_fee_id = trim($_REQUEST['id']);
$fee_type = trim($_REQUEST['type']);

if (!in_array($fee_type, ['admission-fee', 'monthly-fee'])) {
    die('Invalid payment request.');
}

if ($fee_type == "admission-fee") {
    header('Location: ../../../../payment/before-fees-payment.php?id=' . $unpaid_fee_id . "&type=admission-fee");
    exit;
}

/**
 * This system will first pay the fees from 
 * the wallet balance 
 * if balance is greater than unpaid fee
 */

// Fetch unpaid data
$stmt = $pdo->prepare("SELECT * FROM student_unpaid_fees WHERE id = ?");
$stmt->execute([$unpaid_fee_id]);
$unpaid_fee_data = $stmt->fetch(PDO::FETCH_ASSOC);

if (empty($unpaid_fee_data)) {
    die('<center><h1">No unpaid fees found.</h1></center>');
}

$unpaid_amount = $unpaid_fee_data['unpaid_amount'];

$student_id = $unpaid_fee_data['student_id'];

// Fetch wallet balance
$stmt = $pdo->prepare("SELECT * FROM student_wallet WHERE student_id = ?");
$stmt->execute([$student_id]);
$wallet_data = $stmt->fetch(PDO::FETCH_ASSOC);

$balance = 0;

if (!empty($wallet_data)) {
    $balance = $wallet_data['balance'];
}

// Declare arrays
$partial_payment_ids_backup = [];
$full_paid_payment_ids = [];
$unpaid_fee_rows_backup = [];

// Compaire wallet balance and unpaid fee
if ($balance >= $unpaid_amount) {
    try {
        $pdo->beginTransaction();
        $unpaid_fee_rows_backup[] = $unpaid_fee_data; // backup unpaid fee row

        $unpaid_fee_id = $unpaid_fee_data['id'];
        $month_year = $unpaid_fee_data['month_year'];
        $actual_amount = $unpaid_fee_data['actual_amount'];
        $remark = $unpaid_fee_data['remark'];
        $discount_amount = $unpaid_fee_data['discount_amount'];
        $unpaid_amount = $unpaid_fee_data['unpaid_amount'];
        $payment_date = date("Y-m-d");

        $paid_amount = $unpaid_amount;

        // Insert into full_paid_fees table
        $stmt = $pdo->prepare("
                    INSERT INTO student_full_paid_fees
                    (
                    student_id, 
                    month_year, 
                    actual_amount, 
                    discount_amount, 
                    total_paid_amount, 
                    last_paid_amount, 
                    remark, 
                    created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
                ");
        $stmt->execute([$student_id, $month_year, $actual_amount, $discount_amount, ($actual_amount - $discount_amount), $paid_amount, $remark]);
        $full_paid_fees_id = $pdo->lastInsertId();

        $full_paid_payment_ids[] = $full_paid_fees_id;

        // Insert partial payment record
        $partial_remark = "₹" . $paid_amount . "/- has been used for fee payment " . $month_year . " from wallet balance ₹" . $balance . "/- (" . $payment_date . ")";
        $payment_history_remarks[] = "₹" . $paid_amount . " used for payment " . $month_year;

        $stmt = $pdo->prepare("
                    INSERT INTO student_partial_payments
                    (
                    student_id, 
                    month_year, 
                    unpaid_fees_id, 
                    full_paid_fees_id, 
                    partial_paid_amount, 
                    method, 
                    remark,
                    created_at
                    ) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");

        $stmt->execute([$student_id, $month_year, $unpaid_fee_id, $full_paid_fees_id, $paid_amount, 'cash', $partial_remark, $payment_date]);

        $partial_payment_ids_backup[] = $pdo->lastInsertId();

        // Update partial payments table for inserting full paid fees id  
        $stmt = $pdo->prepare("UPDATE student_partial_payments SET full_paid_fees_id = ? WHERE unpaid_fees_id = ?");
        $stmt->execute([$full_paid_fees_id, $unpaid_fee_id]);

        // Delete unpaid fees table data
        $stmt = $pdo->prepare("DELETE FROM student_unpaid_fees WHERE id = ?");
        $stmt->execute([$unpaid_fee_id]);

        // Update the student wallet (deduct)
        $wallet_id = $wallet_data['id'];
        $new_balance = $balance - $unpaid_amount; // new wallet balance
        $stmt = $pdo->prepare("UPDATE student_wallet SET balance = ? WHERE id = ?");
        $stmt->execute([$new_balance, $wallet_id]);

        // Insert transaction record
        $transaction_id = uniqid('tran');
        $stmt = $pdo->prepare("
                    INSERT INTO wallet_transactions
                    (wallet_id, student_id, amount, transaction_type, transaction_id, description) 
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
        $stmt->execute([
            $wallet_id,
            $student_id,
            $paid_amount, // The amount being deducted now
            'deduct',
            $transaction_id,
            'Deducted from wallet for fees payment'
        ]);

        // Add remark
        $payment_history_remarks[] = "₹" . $unpaid_amount . " deducted from wallet";

        // Insert payment history
        $payment_history_remark = implode(' & ', $payment_history_remarks);

        $stmt = $pdo->prepare("
            INSERT INTO student_payment_history
            (
            student_id, 
            payment_amount, 
            payment_date, 
            remark, 
            full_paid_payment_ids, 
            partial_payment_ids_backup,
            wallet_affected_balance,
            wallet_transaction_id,
            unpaid_fee_rows_backup,
            method
            ) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $student_id,
            $unpaid_amount,
            $payment_date,
            $payment_history_remark,
            json_encode($full_paid_payment_ids),
            json_encode($partial_payment_ids_backup),
            $paid_amount,
            $transaction_id,
            json_encode($unpaid_fee_rows_backup),
            'wallet'
        ]);

        $pdo->commit(); // ✅ All good

        $_SESSION['amount'] = $unpaid_amount;
        header('Location: ../../../../payment/payment-success.php');
    } catch (Exception $e) {
        $pdo->rollBack(); // ❌ Rollback on any failure

        $_SESSION['amount'] = $unpaid_amount;
        $_SESSION['reason'] = "Payment failed: " . $e->getMessage();
        header('Location: ../../../../payment/payment-failed.php');
    }
} else {
    header('Location: ../../../../payment/before-fees-payment.php?id=' . $unpaid_fee_id . "&type=monthly-fee");
}
