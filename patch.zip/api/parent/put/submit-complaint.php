<?php
ini_set('max_execution_time', '300'); // ৫ মিনিট
ini_set('memory_limit', '256M'); 
set_time_limit(300);

include_once __DIR__ . '/../../../includes/parent/auth/parent-auth-check.php';

$auth = authenticateApiRequest($pdo);

if (!$auth['success']) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized: Invalid or expired token']);
    exit;
}

/** @var array $websiteConfig
 * @var array $schoolInfo
 */
$telegram_bot_token = $websiteConfig['telegram_bot_token'] ?? '';
$feedback_tg_chat_id = $schoolInfo['feedback_tg_chat_id'] ?? '';

if (empty($telegram_bot_token) || empty($feedback_tg_chat_id)) {
    echo json_encode(['success' => false, 'message' => 'Telegram bot token or chat ID not configured']);
    exit;
}

$parent_phone = $auth['phone_number'];

$stmt = $pdo->prepare("SELECT name, phone_number, alternate_phone_number, father_name, mother_name FROM students WHERE phone_number = ? OR alternate_phone_number = ? LIMIT 1");
$stmt->execute([$parent_phone, $parent_phone]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    echo json_encode(['success' => false, 'message' => 'Parent not found']);
    exit;
}

$father_name = $student['father_name'];
$mother_name = $student['mother_name'];
$father_phone = $student['phone_number'];
$mother_phone = $student['alternate_phone_number'];
$student_name = $student['name'];

$message = $_POST['message'] ?? '';

if (empty($message)) {
    echo json_encode(['success' => false, 'message' => 'Message is required']);
    exit;
}

$telegramText = "🚨 <b>New complain or feedback</b>\n\n";
$telegramText .= "👤 <b>Student's Name:</b> " . safe_htmlspecialchars($student_name) . "\n";
$telegramText .= "👨 <b>Father's Name:</b> " . safe_htmlspecialchars($father_name) . " <i>(" . safe_htmlspecialchars($father_phone) . ")</i>\n";
$telegramText .= "👩 <b>Mother's Name:</b> " . safe_htmlspecialchars($mother_name) . " <i>(" . safe_htmlspecialchars($mother_phone) . ")</i>\n\n";
$telegramText .= "📝 <b>Message:</b>\n" . safe_htmlspecialchars($message);

$telegramApiUrl = "https://api.telegram.org/bot{$telegram_bot_token}/";

$hasFile = isset($_FILES['attachment_file']) && $_FILES['attachment_file']['error'] === UPLOAD_ERR_OK;

if ($hasFile) {
    $fileTmpPath = $_FILES['attachment_file']['tmp_name'];
    $originalFileName = $_FILES['attachment_file']['name']; // ইউজারের আপলোড করা আসল ফাইলের নাম
    
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $fileMimeType = finfo_file($finfo, $fileTmpPath);
    finfo_close($finfo);

    $allowedMediaTypes = [
        // Images
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',

        // Video
        'video/mp4' => 'mp4',
        'video/webm' => 'webm',
        'video/x-matroska' => 'mkv',
        'video/3gpp' => '3gp',       
        'video/mp2t' => 'ts',        
        'video/quicktime' => 'mov',
        'video/x-msvideo' => 'avi',
        
        // Audio
        'audio/mpeg' => 'mp3',
        'audio/mp4' => 'm4a',
        'audio/x-wav' => 'wav',
        'audio/wav' => 'wav',
        'audio/ogg' => 'ogg',
        'audio/flac' => 'flac',      
        'audio/aac' => 'aac',        
        'audio/amr' => 'amr',        
        'audio/midi' => 'mid'
    ];

    // ডিফল্ট মান (যদি অন্য কোনো ফাইল হয়)
    $endpoint = 'sendDocument';
    $fileParam = 'document';
    $finalFileName = $originalFileName; // অন্য ফাইল হলে আগের নামটাই থাকবে

    // যদি ফাইলটি আমাদের চেনা ইমেজ/ভিডিও/অডিও হয়
    if (array_key_exists($fileMimeType, $allowedMediaTypes)) {
        $extension = $allowedMediaTypes[$fileMimeType];
        $finalFileName = uniqid('media_', true) . '.' . $extension; // নতুন নাম এবং এক্সটেনশন তৈরি

        if (strpos($fileMimeType, 'image/') === 0) {
            $endpoint = 'sendPhoto';
            $fileParam = 'photo';
        } elseif (strpos($fileMimeType, 'video/') === 0) {
            $endpoint = 'sendVideo';
            $fileParam = 'video';
        } else {
            $endpoint = 'sendAudio';
            $fileParam = 'audio';
        }
    }

    $postFields = [
        'chat_id' => $feedback_tg_chat_id,
        'parse_mode' => 'HTML',
        $fileParam => new CURLFile($fileTmpPath, $fileMimeType, $finalFileName)
    ];

    if (mb_strlen($telegramText) > 1024) {
        sendToTelegram($telegramApiUrl . 'sendMessage', [
            'chat_id' => $feedback_tg_chat_id,
            'text' => $telegramText,
            'parse_mode' => 'HTML'
        ]);
        $response = sendToTelegram($telegramApiUrl . $endpoint, $postFields);
    } else {
        $postFields['caption'] = $telegramText;
        $response = sendToTelegram($telegramApiUrl . $endpoint, $postFields);
    }

} else {
    $postFields = [
        'chat_id' => $feedback_tg_chat_id,
        'text' => $telegramText,
        'parse_mode' => 'HTML'
    ];
    $response = sendToTelegram($telegramApiUrl . 'sendMessage', $postFields);
}

if ($response && isset($response['ok']) && $response['ok']) {
    echo json_encode(['success' => true, 'message' => 'Complaint successfully sent']);
} else {
    fopen('complaint-response.json', 'w') && file_put_contents('complaint-response.json', json_encode($response));
    echo json_encode(['success' => false, 'message' => 'Failed to forward complaint to Telegram', 'error_details' => $response]);
}

function sendToTelegram($url, $postFields) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $result = curl_exec($ch);
    curl_close($ch);
    
    return json_decode($result, true);
}
?>