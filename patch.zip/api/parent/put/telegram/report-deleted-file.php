<?php
header('Content-Type: application/json; charset=utf-8');
include_once(__DIR__ . "/../../../../includes/parent/auth/parent-auth-check.php");

$authData = authenticateApiRequest($pdo);

$file_id = $_REQUEST['file_id'] ?? '';

if(empty($file_id)) {
    echo json_encode(['success' => false, 'message' => 'Missing file_id']);
    exit;
}

try {
    // ডাটাবেসে ফাইলটির স্ট্যাটাস inactive করে দিন
    $stmt = $pdo->prepare("UPDATE student_homeworks SET status = 'deleted' WHERE file_id = ?");
    $stmt->execute([$file_id]);
    
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false]);
}
?>