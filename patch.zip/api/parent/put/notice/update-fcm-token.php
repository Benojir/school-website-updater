<?php
include_once(__DIR__ . "/../../../../includes/config.php");

header('Content-Type: application/json');

$fcmToken = trim($_POST['fcm_token'] ?? "");
$deviceId = trim($_POST['device_id'] ?? "");

if (empty($fcmToken) || empty($deviceId)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'FCM token and device ID are required.'
    ]);
    exit;
}

try {
    $stmt = $pdo->prepare("
        UPDATE parent_auth_sessions
        SET fcm_token = ?
        WHERE device_id = ?
    ");

    $stmt->execute([$fcmToken, $deviceId]);

    if ($stmt->rowCount() === 0) {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'message' => 'Device not found.'
        ]);
        exit;
    }

    echo json_encode([
        'success' => true,
        'message' => 'FCM token updated successfully.'
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Internal server error.'
    ]);
}