<?php
include_once(__DIR__ . "/../../../../includes/config.php");

header('Content-Type: application/json');

$fcmToken = trim($_POST['fcm_token'] ?? "");
$appVersion = trim($_POST['app_version'] ?? "");
$deviceId = trim($_POST['device_id'] ?? "");

if ($fcmToken === "" || $deviceId === "") {
    echo json_encode([
        'success' => false,
        'message' => 'FCM token and device ID are required.'
    ]);
    exit;
}

try {
    $stmt = $pdo->prepare("
        UPDATE parent_auth_sessions
        SET fcm_token = ?, app_version = ?
        WHERE device_id = ?
    ");

    $stmt->execute([$fcmToken, $appVersion, $deviceId]);

    if ($stmt->rowCount() === 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Device not found.'
        ]);
        exit;
    }

    echo json_encode([
        'success' => true,
        'message' => 'FCM token updated successfully.'
    ]);

} catch (Throwable $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Internal server error.'
    ]);
}