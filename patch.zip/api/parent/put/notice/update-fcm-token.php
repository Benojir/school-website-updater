<?php
include_once(__DIR__ . "/../../../../includes/config.php");

header('Content-Type: application/json');

if (!isset($_REQUEST['fcm_token']) || !isset($_REQUEST['device_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'FCM token and device ID are required']);
    exit;
}

$fcmToken = $_REQUEST['fcm_token'];
$deviceId = $_REQUEST['device_id'];

if (empty($fcmToken) || empty($deviceId)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'FCM token and device ID cannot be empty']);
    exit;
}

try {
    // Save the FCM token and device ID to the database
    $stmt = $pdo->prepare("UPDATE parent_auth_sessions SET fcm_token = ? WHERE device_id = ?");
    $stmt->execute([$fcmToken, $deviceId]);

    echo json_encode(['success' => true, 'message' => 'FCM token updated successfully']);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Internal server error: ' . $e->getMessage()]);
}