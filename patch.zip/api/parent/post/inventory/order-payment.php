<?php
require_once __DIR__ . '/../../../../includes/inventory/store-api.php';
$parent = authenticateApiRequest($pdo);
try {
    $input = storeInput();
    $service = new InventoryOrderService($pdo, null, storeGateway(), storeOpen());
    $number = inventoryText($input['order_number'] ?? '', 50, 'order number', true);
    $action = $input['action'] ?? 'check';
    if ($action === 'resume') {
        $data = $service->resumePayment($number, $parent['phone_number'], storeOnlineEnabled());
    } elseif ($action === 'check') {
        $order = $service->reconcile($service->parentOrder($number, $parent['phone_number']));
        $data = ['payment_status'=>$order['payment_status'], 'order_status'=>$order['order_status'], 'order_number'=>$number];
    } else throw new InvalidArgumentException('Unknown payment action.');
    echo json_encode(['success'=>true, 'data'=>$data], JSON_THROW_ON_ERROR);
} catch (Throwable $e) { storeError($e); }
