<?php
require_once __DIR__ . '/../../../../includes/inventory/store-api.php';
$parent = authenticateApiRequest($pdo);
try {
    $input = storeInput();
    $service = new InventoryOrderService($pdo, null, storeGateway());
    $data = $service->verifyRazorpayPayment(
        inventoryText($input['order_number'] ?? '', 50, 'order number', true), $parent['phone_number'],
        inventoryText($input['razorpay_order_id'] ?? '', 100, 'payment order', true),
        inventoryText($input['razorpay_payment_id'] ?? '', 100, 'payment reference', true),
        inventoryText($input['razorpay_signature'] ?? '', 64, 'payment signature', true)
    );
    echo json_encode(['success'=>true, 'data'=>$data], JSON_THROW_ON_ERROR);
} catch (Throwable $e) { storeError($e); }