<?php
require_once __DIR__ . '/../../../../includes/inventory/store-api.php';
$parent = authenticateApiRequest($pdo);
try {
    $input = storeInput();
    $method = inventoryText($input['payment_method'] ?? 'pay_at_school', 20, 'payment method');
    if ($method === 'online' && !storeOnlineEnabled()) throw new InvalidArgumentException('Online payments are unavailable. Choose Pay at School.');
    $service = new InventoryOrderService($pdo, null, $method === 'online' ? storeGateway() : null);
    $data = $service->createOrder(
        inventoryText($input['student_id'] ?? '', 50, 'student ID', true), $parent['phone_number'],
        $input['items'] ?? [], $method, inventoryText($input['note'] ?? '', 500, 'note'), storeRequestKey($input['request_key'] ?? ''),
        inventoryInteger($input['expected_total_paise'] ?? 0, 'Order total', 1, 9999999999)
    );
    echo json_encode(['success'=>true, 'data'=>$data], JSON_THROW_ON_ERROR);
} catch (Throwable $e) { storeError($e); }
