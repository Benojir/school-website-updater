<?php
require_once __DIR__ . '/../../../../includes/parent/auth/parent-auth-check.php';
require_once __DIR__ . '/../../../../includes/parent/financial/fee-payment-service.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    echo json_encode(['success' => false, 'message' => 'Use POST.']);
    exit;
}
// This native-app endpoint requires a bearer token, excluding cookie-only/CSRF requests.
$headers = array_change_key_case(getallheaders(), CASE_LOWER);
if (!str_starts_with($headers['authentication'] ?? '', 'Bearer ')) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Open the parent app to pay this fee.']);
    exit;
}
$parent = authenticateApiRequest($pdo);
try {
    $raw = file_get_contents('php://input', false, null, 0, 8193);
    if (strlen($raw) > 8192) throw new InvalidArgumentException('Request is too large.');
    $input = json_decode($raw, true, 16, JSON_THROW_ON_ERROR);
    if (!is_array($input)) throw new InvalidArgumentException('Invalid request.');
    $config = $websiteConfig + ['school_name' => $schoolInfo['name'] ?? 'School'];
    $service = new FeePaymentService($pdo, new FeePaymentGateway($config['razorpay_key_id'] ?? '', $config['razorpay_key_secret'] ?? ''),
        $config, (int)($schoolSettings['allow_online_payment'] ?? 0) === 1);
    $action = $input['action'] ?? '';
    if ($action === 'quote' || $action === 'start') {
        $student = $input['student_id'] ?? '';
        $type = $input['type'] ?? '';
        $id = filter_var($input['fee_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if (!is_string($student) || $student === '' || strlen($student) > 100 || !is_string($type) || !$id) throw new InvalidArgumentException('Invalid fee details.');
        if ($action === 'quote') $data = $service->quote($student, $parent['phone_number'], $type, $id);
        else {
            $fee = filter_var($input['expected_fee_paise'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            $total = filter_var($input['expected_total_paise'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            if (!$fee || !$total) throw new InvalidArgumentException('Review the payment total first.');
            $data = $service->start($student, $parent['phone_number'], $type, $id, $fee, $total);
        }
    } elseif ($action === 'check' || $action === 'verify') {
        $order = $input['razorpay_order_id'] ?? '';
        $payment = $action === 'verify' ? ($input['razorpay_payment_id'] ?? '') : null;
        $signature = $action === 'verify' ? ($input['razorpay_signature'] ?? '') : null;
        if (!is_string($order) || ($action === 'verify' && (!is_string($payment) || !is_string($signature)))) throw new InvalidArgumentException('Invalid payment details.');
        $data = $service->check($order, $parent['phone_number'], $payment, $signature);
    } else throw new InvalidArgumentException('Unknown payment action.');
    echo json_encode(['success' => true, 'data' => $data], JSON_THROW_ON_ERROR);
} catch (Throwable $e) {
    $invalid = $e instanceof InvalidArgumentException || $e instanceof JsonException || $e instanceof Razorpay\Api\Errors\SignatureVerificationError;
    http_response_code($invalid ? 422 : 500);
    if (!$invalid) error_log('Parent fee payment: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => $invalid ? ($e instanceof InvalidArgumentException ? $e->getMessage() : 'Invalid payment request or signature.')
        : 'Unable to confirm payment. Reopen this fee and check payment before paying again.']);
}
