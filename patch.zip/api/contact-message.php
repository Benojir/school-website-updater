<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/contact-message-service.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function contactMessageResponse(int $status, bool $success, string $message): never
{
    http_response_code($status);
    exit(json_encode(['success' => $success, 'message' => $message]));
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    contactMessageResponse(405, false, 'Please submit the contact form.');
}
if (!contactMessageCsrfValid($_SESSION['contact_message_csrf'] ?? null, $_POST['csrf_token'] ?? null)) {
    contactMessageResponse(403, false, 'Your session expired. Reload the page before sending.');
}
if (empty($websiteConfig['captcha_site_key']) || empty($websiteConfig['captcha_secret_key'])) {
    contactMessageResponse(503, false, 'Messaging is temporarily unavailable. Please contact the school by phone.');
}
// Keep the session lock until storage completes to reject simultaneous duplicate requests.
if (time() - ($_SESSION['contact_message_last_sent'] ?? 0) < 60) {
    header('Retry-After: 60');
    contactMessageResponse(429, false, 'Please wait one minute before sending another message.');
}
try {
    submitContactMessage($pdo, $_POST, $websiteConfig['captcha_secret_key'], (string) parse_url(BASE_URL, PHP_URL_HOST));
    $_SESSION['contact_message_last_sent'] = time();
    contactMessageResponse(200, true, 'Your message has been sent to the school. Thank you!');
} catch (InvalidArgumentException | ContactMessageCaptchaException $error) {
    contactMessageResponse(422, false, $error->getMessage());
} catch (Throwable $error) {
    error_log('Contact message submission: ' . $error->getMessage());
    contactMessageResponse(503, false, 'Your message could not be saved. Please try again later or phone the school.');
}
