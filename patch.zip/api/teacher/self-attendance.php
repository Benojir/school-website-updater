<?php
require_once __DIR__ . '/../../includes/teacher/auth/teacher-auth-check.php';
require_once __DIR__ . '/../../includes/teacher/staff-attendance-service.php';
header('Content-Type: application/json');
header('Cache-Control: no-store');
try {
    // Header authentication only: cross-site cookie requests cannot mark attendance.
    if(!preg_match('/^Bearer\s+\S+$/iD', $_SERVER['HTTP_AUTHENTICATION']??$_SERVER['HTTP_AUTHORIZATION']??'')) throw new StaffAttendanceDenied('Use the Teacher App for attendance and salary.');
    $auth=authenticateApiRequest($pdo);
    $service=new StaffAttendanceService($pdo);
    if($_SERVER['REQUEST_METHOD']==='GET') {
        if (($_GET['view']??'')==='reminder') {
            $data=$service->teacherReminderContext((int)$auth['teacher_id']);
        } else {
            $month=staffMonth($_GET['month']??substr($service->today(),0,7));
            $data=$service->teacherContext((int)$auth['teacher_id'],$month);
        }
        $data['currency_symbol']=$currency_symbol ?? '₹';
    } elseif($_SERVER['REQUEST_METHOD']==='POST') {
        $raw=$_POST['data']??'';
        if(!is_string($raw) || strlen($raw)>2900000) throw new InvalidArgumentException('Capture request is too large.');
        $input=json_decode($raw,true,32,JSON_THROW_ON_ERROR);
        if(!is_array($input)) throw new InvalidArgumentException('Invalid request.');
        if(($input['action']??'')==='begin') $data=$service->begin($auth,$input);
        elseif(($input['action']??'')==='finish') {
            require_once __DIR__ . '/../../includes/imgbb-upload.php';
            // Release PHP's session lock during remote uploads.
            if(session_status()===PHP_SESSION_ACTIVE) session_write_close();
            $data=$service->finish($auth,$input);
        } else throw new InvalidArgumentException('Invalid attendance action.');
    } else { http_response_code(405); header('Allow: GET, POST'); exit(json_encode(['success'=>false,'message'=>'Use GET or POST.'])); }
    echo json_encode(['success'=>true,'data'=>$data,'message'=>'Saved. Selfie attendance requires administrator review.']);
} catch(StaffAttendanceDenied $e) {
    http_response_code(403); echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
} catch(StaffAttendanceConflict $e) {
    http_response_code(409); echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
} catch(InvalidArgumentException|JsonException $e) {
    http_response_code(422); echo json_encode(['success'=>false,'message'=>$e instanceof JsonException?'Invalid request data.':$e->getMessage()]);
} catch(Throwable $e) {
    error_log('Staff attendance: '.$e->getMessage());
    http_response_code(503); echo json_encode(['success'=>false,'message'=>'Attendance could not be completed. Reload to check whether it was saved; contact the school if needed. The attendance migration and ImgBB configuration must be ready.']);
}
