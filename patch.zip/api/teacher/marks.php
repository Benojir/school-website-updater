<?php
require_once __DIR__ . '/../../includes/teacher/auth/teacher-auth-check.php';
require_once __DIR__ . '/../../includes/teacher/teacher-marks-service.php';
header('Content-Type: application/json');
$auth = authenticateApiRequest($pdo);
try {
    $method = $_SERVER['REQUEST_METHOD'];
    if (!in_array($method, ['GET', 'POST'], true)) {
        http_response_code(405);
        exit(json_encode(['success'=>false, 'message'=>'Use GET or POST.']));
    }
    $input = $method === 'POST' ? json_decode(is_string($_POST['data'] ?? null) ? $_POST['data'] : '', true) : $_GET;
    if (!is_array($input)) throw new InvalidArgumentException('Invalid mark entry request.');
    $section = academicPositiveId($input['section_id'] ?? null, 'Section') ?? 0;
    $exam = academicPositiveId($input['exam_id'] ?? null, 'Exam') ?? 0;
    $subject = academicPositiveId($input['subject_id'] ?? null, 'Subject') ?? 0;
    if (!$section) throw new InvalidArgumentException('Select a section first.');
    $service = new TeacherMarksService($pdo, (int)$auth['teacher_id']);
    if ($method === 'POST') {
        if (!$exam || !$subject) throw new InvalidArgumentException('Select an exam and subject.');
        $count = $service->save($section, $exam, $subject, $input);
        echo json_encode(['success'=>true, 'message'=>"Marks saved for $count student(s)."]);
    } else {
        $data = $service->context($section, $exam);
        if ($exam && !$data['routine_error'] && $subject) $data['students'] = $service->students($data, $subject);
        echo json_encode(['success'=>true, 'data'=>$data]);
    }
} catch (TeacherMarksDenied $e) {
    http_response_code(403);
    echo json_encode(['success'=>false, 'message'=>$e->getMessage()]);
} catch (TeacherAcademicYearRequired|InvalidArgumentException $e) {
    http_response_code(422);
    echo json_encode(['success'=>false, 'message'=>$e->getMessage()]);
} catch (Throwable $e) {
    error_log('Teacher marks: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success'=>false, 'message'=>'Unable to process marks. Ask the administrator to complete the academic/mark-entry migration and retry.']);
}
