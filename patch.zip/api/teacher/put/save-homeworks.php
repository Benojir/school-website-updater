<?php
// ১. স্ক্রিপ্ট এক্সিকিউশন টাইম এবং মেমরি লিমিট বাড়িয়ে দেওয়া হলো
ini_set('max_execution_time', '0'); // 0 মানে কোনো লিমিট নেই
ini_set('max_input_time', '0');
ini_set('memory_limit', '-1'); // -1 মানে আনলিমিটেড মেমরি (প্রয়োজনে '512M' দিতে পারেন)
set_time_limit(0);

include_once __DIR__ . '/../../../includes/config.php'; // কনফিগ পাথ
require_once __DIR__ . '/../../../includes/teacher/homework-posts.php';
header('Content-Type: application/json; charset=utf-8');

$botToken = $websiteConfig['telegram_bot_token'] ?? '';
$chatId = $websiteConfig['file_storage_channel_id'] ?? '';

$section_id = $_POST['section_id'] ?? null;
$text = $_POST['text'] ?? '';
$type = $_POST['type'] ?? 'text';

if (!$section_id) {
    echo json_encode(["status" => "error", "message" => "Section ID is missing"]);
    exit;
}

if (!$botToken || !$chatId) {
    echo json_encode(["status" => "error", "message" => "Telegram bot token or chat ID is missing"]);
    exit;
}

// Reject unreadable/oversized photos before contacting Telegram. This also
// catches PHP upload_max_filesize errors instead of reporting a fake success.
$uploads = [];
if (in_array($type, ['album', 'document_album'], true)) {
    $files = $_FILES['files'] ?? [];
    foreach (($files['name'] ?? []) as $i => $name) {
        $uploads[] = ['name' => $name, 'tmp_name' => $files['tmp_name'][$i] ?? '',
            'error' => $files['error'][$i] ?? UPLOAD_ERR_NO_FILE, 'size' => $files['size'][$i] ?? 0,
            'type' => $files['type'][$i] ?? ''];
    }
    if (count($uploads) < 2 || count($uploads) > 10) {
        http_response_code(422);
        exit(json_encode(['status' => 'error', 'message' => 'Choose 2 to 10 files for an album.']));
    }
} elseif ($type !== 'text') $uploads[] = $_FILES['file'] ?? [];
foreach ($uploads as $file) {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'] ?? '')) {
        http_response_code(422);
        exit(json_encode(['status' => 'error', 'message' => 'The file did not reach the school server. Choose a smaller file or ask the administrator to check PHP upload limits.']));
    }
    if ($type === 'photo' || ($type === 'album' && !str_starts_with($file['type'], 'video/'))) {
        $dimensions = @getimagesize($file['tmp_name']);
        $error = homeworkPhotoError((int)filesize($file['tmp_name']), (int)($dimensions[0] ?? 0), (int)($dimensions[1] ?? 0));
        if ($error !== null) {
            http_response_code(422);
            exit(json_encode(['status' => 'error', 'message' => $error]));
        }
    }
}

$url = "https://api.telegram.org/bot{$botToken}/";
$postFields = ['chat_id' => $chatId];

// ১. টেলিগ্রামের জন্য ডেটা প্রস্তুত করা
if ($type === 'album' || $type === 'document_album') {
    $url .= "sendMediaGroup";
    $mediaArray = [];
    
    $fileCount = count($_FILES['files']['name']);
    for ($i = 0; $i < $fileCount; $i++) {
        $tmpName = $_FILES['files']['tmp_name'][$i];
        $name = $_FILES['files']['name'][$i];
        $mime = $_FILES['files']['type'][$i];
        
        $cFile = new CURLFile($tmpName, $mime, $name);
        $postFields["file_$i"] = $cFile; // ফাইলগুলোকে আলাদা ফর্ম ডেটা হিসেবে যোগ করা
        
        $mediaType = 'document';
        if ($type === 'album') {
            $mediaType = (strpos($mime, 'video') !== false) ? 'video' : 'photo';
        }
        
        $mediaItem = [
            'type' => $mediaType,
            'media' => "attach://file_$i" // টেলিগ্রামের attach:// সিনট্যাক্স
        ];
        
        // শুধু প্রথম ফাইলে ক্যাপশন দেওয়া
        if ($i === 0 && !empty($text)) {
            $mediaItem['caption'] = $text;
        }
        
        $mediaArray[] = $mediaItem;
    }
    
    $postFields['media'] = json_encode($mediaArray);

} elseif ($type === 'text') {
    $url .= "sendMessage";
    $postFields['text'] = $text;
} else {
    // সিগেল ফাইল (আগের লজিক)
    $fileTmpPath = $_FILES['file']['tmp_name'];
    $fileName = $_FILES['file']['name'];
    $fileMime = $_FILES['file']['type'];
    
    $cFile = new CURLFile($fileTmpPath, $fileMime, $fileName);
    
    if ($type === 'photo') {
        $url .= "sendPhoto";
        $postFields['photo'] = $cFile;
    } elseif ($type === 'video') {
        $url .= "sendVideo";
        $postFields['video'] = $cFile;
    } elseif ($type === 'voice') {
        $url .= "sendVoice";
        $postFields['voice'] = $cFile;
    } else {
        $url .= "sendDocument";
        $postFields['document'] = $cFile;
    }
    
    if (!empty($text)) {
        $postFields['caption'] = $text;
    }
}

// ২. cURL দিয়ে টেলিগ্রামে পাঠানো
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// ২.৫ cURL-এর টাইমআউট লিমিট বাড়িয়ে দেওয়া হলো
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60); // সার্ভারে কানেক্ট করার জন্য সর্বোচ্চ ৬০ সেকেন্ড
curl_setopt($ch, CURLOPT_TIMEOUT, 3600); // সম্পূর্ণ আপলোড প্রসেসের জন্য সর্বোচ্চ ১ ঘণ্টা (৩৬০০ সেকেন্ড)

$response = curl_exec($ch);
curl_close($ch);

$tgData = json_decode($response, true);

// ৩. টেলিগ্রামে সফলভাবে গেলে ডেটাবেসে সেভ করা
if (isset($tgData['ok']) && $tgData['ok'] === true) {
    
    $messages = isset($tgData['result']['message_id']) ? [$tgData['result']] : $tgData['result'];

    $pdo->beginTransaction(); 

    try {
        $insertStmt = $pdo->prepare("
            INSERT INTO student_homeworks 
            (message_id, media_group_id, message_text, file_id, file_type, file_name, file_size, file_width, file_height, thumb_id, thumb_width, thumb_height) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $mapStmt = $pdo->prepare("INSERT INTO homework_section_map (homework_id, section_id) VALUES (?, ?)");
        $savedIds = [];

        foreach ($messages as $post) {
            $message_id = $post['message_id'];
            $media_group_id = $post['media_group_id'] ?? null;
            $current_text = $post['text'] ?? $post['caption'] ?? ''; 

            $file_id = null; $file_type = 'text'; $file_name = null; $file_size = 0;
            $file_width = null; $file_height = null; $thumb_id = null; $thumb_width = null; $thumb_height = null;

            if (isset($post['photo'])) {
                $photo = end($post['photo']); 
                $file_id = $photo['file_id']; $file_type = 'photo'; $file_size = $photo['file_size'] ?? 0;
                $file_width = $photo['width'] ?? null; $file_height = $photo['height'] ?? null;
                $thumb = $post['photo'][0]; $thumb_id = $thumb['file_id'];
                $thumb_width = $thumb['width'] ?? null; $thumb_height = $thumb['height'] ?? null;
            } elseif (isset($post['video'])) {
                $video = $post['video']; $file_id = $video['file_id']; $file_type = 'video';
                $file_name = $video['file_name'] ?? 'Unknown Video'; $file_size = $video['file_size'] ?? 0;
                $file_width = $video['width'] ?? null; $file_height = $video['height'] ?? null;
                $thumbData = $video['thumbnail'] ?? $video['thumb'] ?? null;
                if ($thumbData) {
                    $thumb_id = $thumbData['file_id']; $thumb_width = $thumbData['width'] ?? null; $thumb_height = $thumbData['height'] ?? null;
                }
            } elseif (isset($post['voice'])) {
                $file_id = $post['voice']['file_id']; $file_type = 'voice';
                $file_name = $post['voice']['file_name'] ?? 'Voice Message'; $file_size = $post['voice']['file_size'] ?? 0;
            } elseif (isset($post['document'])) {
                $document = $post['document']; $file_id = $document['file_id']; $file_type = 'document';
                $file_name = $document['file_name'] ?? 'Unknown Document'; $file_size = $document['file_size'] ?? 0;
                $thumbData = $document['thumbnail'] ?? $document['thumb'] ?? null;
                if ($thumbData) {
                    $thumb_id = $thumbData['file_id']; $thumb_width = $thumbData['width'] ?? null; $thumb_height = $thumbData['height'] ?? null;
                }
            }

            $insertStmt->execute([
                $message_id, $media_group_id, $current_text, $file_id, $file_type, $file_name, 
                $file_size, $file_width, $file_height, $thumb_id, $thumb_width, $thumb_height
            ]);
            
            $homework_id = $pdo->lastInsertId();
            $savedIds[] = $homework_id;

            $mapStmt->execute([$homework_id, $section_id]);
        }

        $placeholders = implode(',', array_fill(0, count($savedIds), '?'));
        $savedStmt = $pdo->prepare("SELECT * FROM student_homeworks WHERE id IN ($placeholders) ORDER BY id ASC");
        $savedStmt->execute($savedIds);
        $savedPosts = array_values(homeworkPostsFromRows($savedStmt->fetchAll(PDO::FETCH_ASSOC)));
        $pdo->commit();
        echo json_encode(['status' => 'success', 'message' => 'Saved successfully',
            'posts' => $savedPosts]);

    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        echo json_encode(["status" => "error", "message" => "Database Error", "details" => $e->getMessage()]);
    }

} else {
    echo json_encode(['status' => 'error', 'message' => $tgData['description'] ?? 'Telegram upload failed. Please retry.', 'details' => $tgData]);
}
?>
