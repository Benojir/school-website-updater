<?php
include_once(__DIR__ . "/../../../../includes/teacher/auth/teacher-auth-check.php");

header('Content-Type: application/json');

$auth = authenticateApiRequest($pdo);

if (!$auth) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized: Invalid or expired token']);
    exit;
}

$data = $_REQUEST['data'] ?? null;

if (empty($data)) {
    echo json_encode(['success' => false, 'message' => 'Missing required parameters']);
    exit;
}

$requestData = json_decode($data, true);

// Array হিসেবে ডাটা আসছে কিনা চেক করা
if (!isset($requestData['attendance_list']) || !is_array($requestData['attendance_list'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid data format']);
    exit;
}

$attendanceList = $requestData['attendance_list'];
$teacher_id = $auth['teacher_id'];

try {
    $processedStudentIDs = array();
    // Database Transaction শুরু
    $pdo->beginTransaction();

    $deleteStmt = $pdo->prepare("DELETE FROM student_attendance WHERE student_id = ? AND date = ?");
    $insertStmt = $pdo->prepare("INSERT INTO student_attendance(student_id, class_id, section_id, status, date, time, processed_by_teacher) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $checkLeaveStmt = $pdo->prepare("SELECT id, status FROM student_attendance WHERE student_id = ? AND date = ? ORDER BY id ASC LIMIT 1");

    foreach ($attendanceList as $record) {
        $student_id = $record['student_id'];
        $date = $record['date'];
        $time = $record['time'];
        $status = $record['status'];
        $class_id = $record['class_id'];
        $section_id = $record['section_id'];

        if (!in_array($status, ['present', 'absent', 'leave'])) {
            continue; // ইনভ্যালিড ডাটা স্কিপ করবে
        }

        if ($status == 'absent' || $status == 'present') {
            $deleteStmt->execute([$student_id, $date]);
            $insertStmt->execute([$student_id, $class_id, $section_id, $status, $date, $time, $teacher_id]);
            
            if ($status == 'present') {
                $processedStudentIDs[] = $student_id;
            }
        } 
        else if ($status == 'leave') {
            $checkLeaveStmt->execute([$student_id, $date]);
            $existingRecord = $checkLeaveStmt->fetch(PDO::FETCH_ASSOC);

            if ($existingRecord && $existingRecord['status'] == 'present') {
                $insertStmt->execute([$student_id, $class_id, $section_id, $status, $date, $time, $teacher_id]);
            }
        }
    }

    // সব ঠিক থাকলে Commit
    $pdo->commit();

    $fcmTokens = getFCMTokensFromDatabase($pdo, $processedStudentIDs);

    $title = 'Your child attended class';
    $body = 'Your child has attended class at ' . $date . ' at ' . $time;
    $data = ['title' => $title, 'message' => $body];

    sendFirebaseNotification($pdo, $processedStudentIDs, $fcmTokens, $title, $body, $data, false);

    echo json_encode(['success' => true, 'message' => 'Bulk attendance processed successfully']);

} catch (Exception $e) {
    // কোনো সমস্যা হলে Rollback
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>