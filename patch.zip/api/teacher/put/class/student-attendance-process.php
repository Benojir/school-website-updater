<?php
include_once(__DIR__ . "/../../../../includes/teacher/auth/teacher-auth-check.php");
require_once __DIR__ . '/../../../../includes/teacher/teacher-academic-context.php';

header('Content-Type: application/json');

$auth = authenticateApiRequest($pdo);

if (!$auth) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized: Invalid or expired token']);
    exit;
}

$data = $_REQUEST['data'] ?? null;

if (empty($data)) {
    echo json_encode(['success' => false, 'message' => 'Missing required parameters']);
    exit;
}

$requestData = json_decode($data, true);

// Array হিসেবে ডাটা আসছে কিনা চেক করা
if (empty($requestData['attendance_list']) || !is_array($requestData['attendance_list'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid data format']);
    exit;
}

$attendanceList = $requestData['attendance_list'];
$teacher_id = $auth['teacher_id'];

try {
    teacherRequireAcademicYear($pdo);
    $teacherStmt = $pdo->prepare('SELECT assigned_sections FROM teachers WHERE id = ?');
    $teacherStmt->execute([$teacher_id]);
    $assignedSections = array_map('intval', json_decode($teacherStmt->fetchColumn() ?: '[]', true) ?: []);
    $snapshotStmt = $pdo->prepare('SELECT class_id, section_id FROM student_attendance WHERE student_id = ? AND date = ? ORDER BY id LIMIT 1');
    $processedStudentIDs = array();
    // Database Transaction শুরু
    $pdo->beginTransaction();

    $deleteStmt = $pdo->prepare("DELETE FROM student_attendance WHERE student_id = ? AND date = ?");
    $insertStmt = $pdo->prepare("INSERT INTO student_attendance(student_id, class_id, section_id, status, date, time, processed_by_teacher) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $checkLeaveStmt = $pdo->prepare("SELECT id, status FROM student_attendance WHERE student_id = ? AND date = ? ORDER BY id ASC LIMIT 1");

    foreach ($attendanceList as $record) {
        $student_id = $record['student_id'];
        $date = teacherAttendanceDate($record['date'] ?? null);
        $time = $record['time'];
        $status = $record['status'];
        $year = academicYearForDate($pdo, (string)$date);
        $snapshotStmt->execute([$student_id, $date]);
        $snapshot = $snapshotStmt->fetch(PDO::FETCH_ASSOC);
        $enrollment = $snapshot ?: academicGetStudent($pdo, (string)$student_id, $year);
        if (!$enrollment || (!$snapshot && strcasecmp((string)$enrollment['status'], 'Active') !== 0)) {
            throw new InvalidArgumentException('No eligible student enrollment for this attendance date.');
        }
        $class_id = $enrollment['class_id'];
        $section_id = (int)$enrollment['section_id'];
        if (!in_array($section_id, $assignedSections, true)) {
            throw new InvalidArgumentException('The student section for this date is not assigned to you.');
        }

        if (!in_array($status, ['present', 'absent', 'leave'])) {
            continue; // ইনভ্যালিড ডাটা স্কিপ করবে
        }

        if ($section_id == 0) {
            $section_id = null;
        }

        if ($status == 'absent' || $status == 'present') {
            $deleteStmt->execute([$student_id, $date]);
            $insertStmt->execute([$student_id, $class_id, $section_id, $status, $date, $time, $teacher_id]);
            
            if ($status == 'present') {
                $processedStudentIDs[] = $student_id;
            }
        } 
        else if ($status == 'leave') {
            $checkLeaveStmt->execute([$student_id, $date]);
            $existingRecord = $checkLeaveStmt->fetch(PDO::FETCH_ASSOC);

            if ($existingRecord && $existingRecord['status'] == 'present') {
                $insertStmt->execute([$student_id, $class_id, $section_id, $status, $date, $time, $teacher_id]);
            }
        }
    }

    // সব ঠিক থাকলে Commit
    $pdo->commit();

    // Attendance is already committed. A notification failure must not report
    // that saving attendance failed or prompt the teacher to submit it again.
    if ($processedStudentIDs) {
        try {
            $fcmTokens = getFCMTokensFromDatabase($pdo, $processedStudentIDs);
            $title = 'Your child attended class';
            $body = 'Your child has attended class at ' . $date . ' at ' . $time;
            $data = ['title' => $title, 'message' => $body];
            sendFirebaseNotification($pdo, $processedStudentIDs, $fcmTokens, $title, $body, $data, false);
        } catch (Throwable $notificationError) {
            error_log('Teacher attendance saved; parent notification failed: ' . $notificationError->getMessage());
        }
    }

    echo json_encode(['success' => true, 'message' => 'Bulk attendance processed successfully']);

} catch (TeacherAcademicYearRequired $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['success' => false, 'error_code' => 'ACADEMIC_YEAR_REQUIRED', 'message' => $e->getMessage()]);
} catch (Throwable $e) {
    // কোনো সমস্যা হলে Rollback
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
