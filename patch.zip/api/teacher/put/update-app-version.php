<?php
include_once(__DIR__ . "/../../../includes/config.php");

header('Content-Type: application/json');

$appVersion = trim($_POST['app_version'] ?? "");
$deviceId = trim($_POST['device_id'] ?? "");

if (empty($deviceId) || empty($appVersion)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'App version name and device ID are required.'
    ]);
    exit;
}

try {
    $stmt = $pdo->prepare("
        UPDATE teacher_auth_sessions
        SET app_version = ?
        WHERE device_id = ?
    ");

    $stmt->execute([$appVersion, $deviceId]);

    if ($stmt->rowCount() === 0) {
        http_response_code(404);
        echo json_encode([
            'success' => false,
            'message' => 'Device not found.'
        ]);
        exit;
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'App version updated successfully.'
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Internal server error.'
    ]);
}