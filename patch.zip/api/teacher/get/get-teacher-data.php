<?php
include_once(__DIR__ . "/../../../includes/teacher/auth/teacher-auth-check.php");

header('Content-Type: application/json');

$auth = authenticateApiRequest($pdo);

$teacher_id = $auth['teacher_id'];

$stmt = $pdo->prepare("SELECT * FROM teachers WHERE id = ?");
$stmt->execute([$teacher_id]);
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$teacher) {
    echo json_encode(['success' => false, 'message' => 'Teacher not found']);
    exit;
}

/** this api will return teacher's info, last 20 school notices, latest notification sent to teacher (only one),
 * assigned sections info (no required get-assigned-sections.php api)
 */

// Fetch last latest school notices
$stmt = $pdo->prepare("SELECT * FROM notices ORDER BY notice_date DESC LIMIT 20");
$stmt->execute();
$schoolNotices = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($schoolNotices as &$notice) {
    $notice['notice_date'] = date('d-m-Y', strtotime($notice['notice_date']));
}

// Fetch latest notification sent to teacher
// $stmt = $pdo->prepare("SELECT * FROM notifications WHERE teacher_id = ? ORDER BY id DESC LIMIT 1");
// $stmt->execute([$teacher_id]);
// $latestNotification = $stmt->fetch(PDO::FETCH_ASSOC);

// Assigned sections
$assignedSections = json_decode($teacher['assigned_sections'] ?? '[]', true);

$sectionsData = array();

foreach ($assignedSections as $section) {
    $stmt = $pdo->prepare("SELECT * FROM sections WHERE id = ?");
    $stmt->execute([$section]);
    $sectionData = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($sectionData) {
        $classId = $sectionData['class_id'];
        $sectionName = $sectionData['section_name'];

        $stmt = $pdo->prepare("SELECT * FROM classes WHERE id = ?");
        $stmt->execute([$classId]);
        $classData = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($classData) {
            $className = $classData['class_name'];

            $sectionsData[] = [
                'class_id' => $classId,
                'class_name' => $className,
                'section_id' => $section,
                'section_name' => $sectionName
            ];
        }
    }
}

// Sort data by class id
usort($sectionsData, function ($a, $b) {
    return $a['class_id'] - $b['class_id'];
});

echo json_encode([
    'success' => true,
    'data' => [
        'teacher' => $teacher,
        'school_notices' => $schoolNotices,
        // 'latest_notification' => $latestNotification,
        'assigned_sections' => $sectionsData
    ]
]);