<?php
include_once(__DIR__ . "/../../../includes/teacher/auth/teacher-auth-check.php");

header('Content-Type: application/json');

$sectionId = $_REQUEST['section_id'] ?? null;
try {
    $auth = authenticateApiRequest($pdo);
    $currentAcademicYear = academicRequireCurrentYear($pdo);
    $assigned = $pdo->prepare('SELECT assigned_sections FROM teachers WHERE id = ?');
    $assigned->execute([$auth['teacher_id']]);
    $sections = array_map('intval', json_decode($assigned->fetchColumn() ?: '[]', true) ?: []);
    if (!in_array((int)$sectionId, $sections, true)) throw new InvalidArgumentException('This section is not assigned to you.');
} catch (Exception $e) {
    http_response_code(422);
    exit(json_encode(['success' => false, 'message' => $e->getMessage()]));
}

if (!$sectionId) {
    echo json_encode(['success' => false, 'message' => 'Section ID is required']);
    exit;
}

// Fetch students data
$stmt = $pdo->prepare("SELECT * FROM students WHERE section_id = ? AND status = 'Active' AND academic_year = ? ORDER BY roll_no ASC");
$stmt->execute([$sectionId, $currentAcademicYear]);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch today's attendance data
$stmt = $pdo->prepare("SELECT student_id, status FROM student_attendance WHERE date = CURDATE() AND section_id = ?");
$stmt->execute([$sectionId]);
$attendances = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($students as &$student) {
    $student['attendance'] = null;
    foreach ($attendances as $attendance) {
        if ($student['student_id'] === $attendance['student_id']) {
            $student['attendance'] = $attendance['status'];
            break;
        }
    }
}

$total_presented_today = 0;
foreach ($attendances as $attendance) {
    if ($attendance['status'] === 'present') {
        $total_presented_today++;
    }
}

$total_absent_today = 0;
foreach ($attendances as $attendance) {
    if ($attendance['status'] === 'absent') {
        $total_absent_today++;
    }
}

echo json_encode([
    'success' => true,
    'message' => 'Students and attendance data fetched successfully',
    'data' => [
        'students' => $students,
        'total_students' => count($students),
        'total_present' => $total_presented_today,
        'total_absent' => $total_absent_today
    ]
]);
