<?php
include_once(__DIR__ . "/../../../includes/config.php");

header('Content-Type: application/json');

$sectionId = $_REQUEST['section_id'] ?? null;

if (!$sectionId) {
    echo json_encode(['success' => false, 'message' => 'Section ID is required']);
    exit;
}

// Fetch students data
$stmt = $pdo->prepare("SELECT * FROM students WHERE section_id = ? AND status = 'Active' ORDER BY roll_no ASC");
$stmt->execute([$sectionId]);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch today's attendance data
$stmt = $pdo->prepare("SELECT student_id, status FROM student_attendance WHERE date = CURDATE() AND section_id = ?");
$stmt->execute([$sectionId]);
$attendances = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($students as &$student) {
    $student['attendance'] = null;
    foreach ($attendances as $attendance) {
        if ($student['student_id'] === $attendance['student_id']) {
            $student['attendance'] = $attendance['status'];
            break;
        }
    }
}

$total_presented_today = 0;
foreach ($attendances as $attendance) {
    if ($attendance['status'] === 'present') {
        $total_presented_today++;
    }
}

$total_absent_today = 0;
foreach ($attendances as $attendance) {
    if ($attendance['status'] === 'absent') {
        $total_absent_today++;
    }
}

echo json_encode([
    'success' => true,
    'message' => 'Students and attendance data fetched successfully',
    'data' => [
        'students' => $students,
        'total_students' => count($students),
        'total_present' => $total_presented_today,
        'total_absent' => $total_absent_today
    ]
]);
