<?php
include_once(__DIR__ . "/../../../includes/teacher/auth/teacher-auth-check.php");
require_once __DIR__ . '/../../../includes/teacher/teacher-academic-context.php';
require_once __DIR__ . '/../../../includes/teacher/student-attendance-history.php';

header('Content-Type: application/json');

$sectionId = $_REQUEST['section_id'] ?? null;
try {
    $auth = authenticateApiRequest($pdo);
    $currentAcademicYear = teacherRequireAcademicYear($pdo);
    $assigned = $pdo->prepare('SELECT assigned_sections FROM teachers WHERE id = ?');
    $assigned->execute([$auth['teacher_id']]);
    $sections = array_map('intval', json_decode($assigned->fetchColumn() ?: '[]', true) ?: []);
    if (!in_array((int)$sectionId, $sections, true)) throw new InvalidArgumentException('This section is not assigned to you.');
} catch (TeacherAcademicYearRequired $e) {
    exit(json_encode(['success' => false, 'error_code' => 'ACADEMIC_YEAR_REQUIRED', 'message' => $e->getMessage()]));
} catch (Exception $e) {
    http_response_code(422);
    exit(json_encode(['success' => false, 'message' => $e->getMessage()]));
}

if (!$sectionId) {
    echo json_encode(['success' => false, 'message' => 'Section ID is required']);
    exit;
}

// Fetch students data
$stmt = $pdo->prepare("SELECT * FROM students WHERE section_id = ? AND status = 'Active' AND academic_year = ? ORDER BY roll_no ASC");
$stmt->execute([$sectionId, $currentAcademicYear]);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

// The school's configured timezone defines today and the previous two calendar
// days. Fetch the entire section in one query, rather than one per student.
$today = new DateTimeImmutable('today');
$stmt = $pdo->prepare("SELECT student_id, status, date FROM student_attendance WHERE section_id = ? AND date BETWEEN ? AND ? ORDER BY date ASC, id ASC");
$stmt->execute([$sectionId, $today->modify('-2 days')->format('Y-m-d'), $today->format('Y-m-d')]);
$attendances = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    'success' => true,
    'message' => 'Students and attendance data fetched successfully',
    'data' => teacherStudentAttendanceSummary($students, $attendances, $today->format('Y-m-d'))
]);
