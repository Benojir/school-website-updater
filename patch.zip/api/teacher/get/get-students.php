<?php
include_once(__DIR__ . "/../../../includes/teacher/auth/teacher-auth-check.php");

header('Content-Type: application/json');

try {
    $auth = authenticateApiRequest($pdo);
    $teacher_id = $auth['teacher_id'];

    // ১. শিক্ষকের নির্দিষ্ট সেকশন ফেচ করা
    $stmt = $pdo->prepare("SELECT assigned_sections, can_view_parent_contacts FROM teachers WHERE id = ?");
    $stmt->execute([$teacher_id]);
    $teacher = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$teacher) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Teacher not found']);
        exit;
    }

    $canViewParentContacts = !empty($teacher['can_view_parent_contacts']);
    $assignedSections = json_decode($teacher['assigned_sections'] ?? '[]', true);

    // সেকশন তালিকা ফাঁকা থাকলে সরাসরি খালি রেসপন্স দেওয়া
    if (empty($assignedSections) || !is_array($assignedSections)) {
        echo json_encode([
            'success' => true,
            'message' => 'No assigned sections found',
            'can_view_parent_contacts' => (int) $canViewParentContacts,
            'students' => []
        ]);
        exit;
    }

    // ২. N+1 কুয়েরি এড়াতে SQL IN() ক্লজ তৈরি
    $placeholders = implode(',', array_fill(0, count($assignedSections), '?'));

    $sql = "
        SELECT DISTINCT s.*, c.class_name, sec.section_name 
        FROM students s
        JOIN classes c ON s.class_id = c.id
        JOIN sections sec ON s.section_id = sec.id
        WHERE s.section_id IN ($placeholders) AND s.status = 'Active'
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($assignedSections);
    $studentsData = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Teachers without the parent-contact permission get the same payload shape, with the
    // contact fields blanked out rather than removed, so existing clients don't break.
    if (!$canViewParentContacts) {
        foreach ($studentsData as &$student) {
            $student['phone_number'] = null;            // father's phone
            $student['alternate_phone_number'] = null;  // mother's phone
            $student['email'] = null;
        }
        unset($student);
    }

    echo json_encode([
        'success' => true,
        'message' => 'Students fetched successfully',
        'can_view_parent_contacts' => (int) $canViewParentContacts,
        'students' => $studentsData
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred while fetching students'
    ]);
}