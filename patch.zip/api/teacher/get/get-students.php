<?php
include_once(__DIR__ . "/../../../includes/teacher/auth/teacher-auth-check.php");

header('Content-Type: application/json');

try {
    $auth = authenticateApiRequest($pdo);
    $teacher_id = $auth['teacher_id'];

    // ১. শিক্ষকের নির্দিষ্ট সেকশন ও পারমিশনগুলো ফেচ করা
    $stmt = $pdo->prepare("SELECT assigned_sections, can_view_parent_contacts, can_view_student_financial_report FROM teachers WHERE id = ?");
    $stmt->execute([$teacher_id]);
    $teacher = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$teacher) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Teacher not found']);
        exit;
    }

    $canViewParentContacts = !empty($teacher['can_view_parent_contacts']);
    // The column is NOT NULL DEFAULT 0, so a missing value reads as denied.
    $canViewStudentFinancialReport = !empty($teacher['can_view_student_financial_report']);
    $assignedSections = json_decode($teacher['assigned_sections'] ?? '[]', true);

    // সেকশন তালিকা ফাঁকা থাকলে সরাসরি খালি রেসপন্স দেওয়া
    if (empty($assignedSections) || !is_array($assignedSections)) {
        echo json_encode([
            'success' => true,
            'message' => 'No assigned sections found',
            'can_view_parent_contacts' => (int) $canViewParentContacts,
            'can_view_student_financial_report' => (int) $canViewStudentFinancialReport,
            'students' => []
        ]);
        exit;
    }

    // ২. N+1 কুয়েরি এড়াতে SQL IN() ক্লজ তৈরি
    $placeholders = implode(',', array_fill(0, count($assignedSections), '?'));

    $sql = "
        SELECT DISTINCT s.*, c.class_name, sec.section_name
        FROM students s
        JOIN classes c ON s.class_id = c.id
        JOIN sections sec ON s.section_id = sec.id
        WHERE s.section_id IN ($placeholders) AND s.status = 'Active'
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($assignedSections);
    $studentsData = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Teachers without the parent-contact permission get the same payload shape, with the
    // contact fields blanked out rather than removed, so existing clients don't break.
    if (!$canViewParentContacts) {
        foreach ($studentsData as &$student) {
            $student['phone_number'] = null;            // father's phone
            $student['alternate_phone_number'] = null;  // mother's phone
            $student['email'] = null;
        }
        unset($student);
    }

    // -------------------------------------------------------------
    // ৩. Pending fees (batched, same approach as the admin students list)
    //
    // Every student always carries the same set of fee keys so the app can bind them
    // unconditionally. Teachers without the permission get them as null, and the fee
    // queries are skipped entirely rather than computed and thrown away.
    // -------------------------------------------------------------
    $student_unpaid_monthly_totals = [];
    $student_unpaid_admission_totals = [];
    $student_unpaid_additional_totals = [];
    $student_unpaid_months = [];

    if ($canViewStudentFinancialReport && !empty($studentsData)) {
        $student_ids = array_column($studentsData, 'student_id');
        $in_query = implode(',', array_fill(0, count($student_ids), '?'));

        // Unpaid monthly fees (month_year is stored as e.g. "January 2026")
        $unpaid_stmt = $pdo->prepare("
            SELECT student_id, month_year, unpaid_amount
            FROM student_unpaid_fees
            WHERE student_id IN ($in_query)
            ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC
        ");
        $unpaid_stmt->execute($student_ids);
        while ($row = $unpaid_stmt->fetch(PDO::FETCH_ASSOC)) {
            $sid = $row['student_id'];
            $student_unpaid_months[$sid][] = $row['month_year'];
            $student_unpaid_monthly_totals[$sid] = ($student_unpaid_monthly_totals[$sid] ?? 0) + (float)$row['unpaid_amount'];
        }

        // Unpaid admission fees
        $admission_stmt = $pdo->prepare("
            SELECT student_id, unpaid_amount
            FROM admission_unpaid_fees
            WHERE student_id IN ($in_query)
        ");
        $admission_stmt->execute($student_ids);
        while ($row = $admission_stmt->fetch(PDO::FETCH_ASSOC)) {
            $sid = $row['student_id'];
            $student_unpaid_admission_totals[$sid] = ($student_unpaid_admission_totals[$sid] ?? 0) + (float)$row['unpaid_amount'];
        }

        // Unpaid additional fees. The amount lives on the setup row
        // (class_wise_additional_fees), not on the per-student row, so it has to be joined in.
        $additional_stmt = $pdo->prepare("
            SELECT afd.student_id, cwaf.amount
            FROM additional_fees_data afd
            JOIN class_wise_additional_fees cwaf ON cwaf.id = afd.additional_fee_setup_id
            WHERE afd.student_id IN ($in_query) AND afd.additional_fee_status = 'unpaid'
        ");
        $additional_stmt->execute($student_ids);
        while ($row = $additional_stmt->fetch(PDO::FETCH_ASSOC)) {
            $sid = $row['student_id'];
            $student_unpaid_additional_totals[$sid] = ($student_unpaid_additional_totals[$sid] ?? 0) + (float)$row['amount'];
        }
    }

    foreach ($studentsData as &$student) {
        if (!$canViewStudentFinancialReport) {
            $student['total_monthly_pending_fees'] = null;
            $student['total_admission_pending_fees'] = null;
            $student['total_additional_pending_fees'] = null;
            $student['total_pending_fees'] = null;
            $student['due_months'] = null;
            continue;
        }

        $sid = $student['student_id'];

        $student['total_monthly_pending_fees'] = $student_unpaid_monthly_totals[$sid] ?? 0;
        $student['total_admission_pending_fees'] = $student_unpaid_admission_totals[$sid] ?? 0;
        $student['total_additional_pending_fees'] = $student_unpaid_additional_totals[$sid] ?? 0;
        $student['total_pending_fees'] = $student['total_monthly_pending_fees']
                                        + $student['total_admission_pending_fees']
                                        + $student['total_additional_pending_fees'];

        // Due months as a compact range, e.g. "January 2026 - March 2026"
        $student['due_months'] = "";
        if (isset($student_unpaid_months[$sid])) {
            $months = $student_unpaid_months[$sid];
            $student['due_months'] = count($months) == 1 ? $months[0] : $months[0] . ' - ' . end($months);
        }
    }
    unset($student);

    unset($student_unpaid_monthly_totals, $student_unpaid_admission_totals, $student_unpaid_additional_totals, $student_unpaid_months);

    echo json_encode([
        'success' => true,
        'message' => 'Students fetched successfully',
        'can_view_parent_contacts' => (int) $canViewParentContacts,
        'can_view_student_financial_report' => (int) $canViewStudentFinancialReport,
        'students' => $studentsData
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred while fetching students'
    ]);
}
