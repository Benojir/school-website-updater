<?php
include_once(__DIR__ . "/../../../includes/teacher/auth/teacher-auth-check.php");

header('Content-Type: application/json');

try {
    $auth = authenticateApiRequest($pdo);
    $teacher_id = $auth['teacher_id'];

    // ১. শিক্ষকের নির্দিষ্ট সেকশন ফেচ করা
    $stmt = $pdo->prepare("SELECT assigned_sections FROM teachers WHERE id = ?");
    $stmt->execute([$teacher_id]);
    $teacher = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$teacher) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Teacher not found']);
        exit;
    }

    $assignedSections = json_decode($teacher['assigned_sections'] ?? '[]', true);

    // সেকশন তালিকা ফাঁকা থাকলে সরাসরি খালি রেসপন্স দেওয়া
    if (empty($assignedSections) || !is_array($assignedSections)) {
        echo json_encode([
            'success' => true,
            'message' => 'No assigned sections found',
            'students' => []
        ]);
        exit;
    }

    // ২. N+1 কুয়েরি এড়াতে SQL IN() ক্লজ তৈরি
    $placeholders = implode(',', array_fill(0, count($assignedSections), '?'));

    $sql = "
        SELECT DISTINCT s.*, c.class_name, sec.section_name 
        FROM students s
        JOIN classes c ON s.class_id = c.id
        JOIN sections sec ON s.section_id = sec.id
        WHERE s.section_id IN ($placeholders) AND s.status = 'Active'
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($assignedSections);
    $studentsData = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'message' => 'Students fetched successfully',
        'students' => $studentsData
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred while fetching students'
    ]);
}