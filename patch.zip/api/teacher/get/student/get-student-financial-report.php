<?php
/**
 * Per-student fee dues and payment history for the Teacher App's Student Profile screen.
 *
 * Two independent gates are enforced here:
 *   1. teachers.can_view_student_financial_report must be on.
 *   2. The student must sit in one of the teacher's assigned sections, so a teacher
 *      cannot read an arbitrary student by guessing a student_id.
 *
 * Money buckets mirror the admin students list (students-list-api.php):
 *   monthly    -> student_unpaid_fees.unpaid_amount
 *   admission  -> admission_unpaid_fees.unpaid_amount
 *   additional -> class_wise_additional_fees.amount for unpaid additional_fees_data rows
 *
 * Failures other than a genuinely invalid token deliberately answer with HTTP 200 and
 * success=false. The app's ApiRequestHelper.fetchData() treats ANY non-200 status as an
 * expired session and signs the teacher out, so a "permission denied" answer must not
 * carry a 403 - only authenticateApiRequest()'s own 401 should end the session.
 */

include_once(__DIR__ . "/../../../../includes/teacher/auth/teacher-auth-check.php");

header('Content-Type: application/json');

// Payment history is display-only in the app, so it is capped rather than paginated.
const PAYMENT_HISTORY_LIMIT = 100;

try {
    $auth = authenticateApiRequest($pdo);
    $teacher_id = $auth['teacher_id'];

    $student_id = trim($_REQUEST['student_id'] ?? '');

    if ($student_id === '') {
        echo json_encode([
            'success' => false,
            'message' => 'Missing required parameter: student_id.'
        ]);
        exit;
    }

    // ---------------------------------------------------------------------
    // GATE 1: permission flag (NOT NULL DEFAULT 0, so missing reads as denied)
    // ---------------------------------------------------------------------
    $stmt = $pdo->prepare("SELECT assigned_sections, can_view_student_financial_report FROM teachers WHERE id = ?");
    $stmt->execute([$teacher_id]);
    $teacher = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$teacher) {
        echo json_encode(['success' => false, 'message' => 'Teacher not found']);
        exit;
    }

    if (empty($teacher['can_view_student_financial_report'])) {
        echo json_encode([
            'success' => false,
            'permission_denied' => true,
            'can_view_student_financial_report' => 0,
            'message' => "You do not have permission to view students' financial report."
        ]);
        exit;
    }

    // ---------------------------------------------------------------------
    // GATE 2: the student must be in one of this teacher's assigned sections
    // ---------------------------------------------------------------------
    $assignedSections = json_decode($teacher['assigned_sections'] ?? '[]', true);

    if (empty($assignedSections) || !is_array($assignedSections)) {
        echo json_encode([
            'success' => false,
            'permission_denied' => true,
            'message' => 'No assigned sections found.'
        ]);
        exit;
    }

    $assignedSections = array_map('intval', $assignedSections);
    $placeholders = implode(',', array_fill(0, count($assignedSections), '?'));

    $stmt = $pdo->prepare("
        SELECT s.student_id, s.name, s.class_id
        FROM students s
        WHERE s.student_id = ? AND s.section_id IN ($placeholders)
    ");
    $stmt->execute(array_merge([$student_id], $assignedSections));
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        echo json_encode([
            'success' => false,
            'permission_denied' => true,
            'message' => 'This student is not in any of your assigned sections.'
        ]);
        exit;
    }

    // ---------------------------------------------------------------------
    // MONTHLY DUES
    // month_year is stored as e.g. "January 2026", so it is ordered by parsing it
    // back into a date - the same expression the parent dashboard API uses.
    // ---------------------------------------------------------------------
    $stmt = $pdo->prepare("
        SELECT month_year, actual_amount, discount_amount, unpaid_amount, remark
        FROM student_unpaid_fees
        WHERE student_id = ?
        ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC
    ");
    $stmt->execute([$student_id]);
    $monthly_rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $monthly_dues = [];
    $monthly_due_total = 0;

    foreach ($monthly_rows as $row) {
        $monthly_due_total += (float)$row['unpaid_amount'];
        $monthly_dues[] = [
            'month_year' => $row['month_year'],
            'actual_amount' => (float)$row['actual_amount'],
            'discount_amount' => (float)$row['discount_amount'],
            'unpaid_amount' => (float)$row['unpaid_amount'],
            'remark' => $row['remark'],
        ];
    }

    // ---------------------------------------------------------------------
    // ADMISSION DUES
    // ---------------------------------------------------------------------
    $stmt = $pdo->prepare("
        SELECT auf.academic_year, auf.actual_amount, auf.discount_amount, auf.unpaid_amount, auf.remark, c.class_name
        FROM admission_unpaid_fees auf
        LEFT JOIN classes c ON c.id = auf.class_id
        WHERE auf.student_id = ?
        ORDER BY auf.academic_year ASC
    ");
    $stmt->execute([$student_id]);
    $admission_rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $admission_dues = [];
    $admission_due_total = 0;

    foreach ($admission_rows as $row) {
        $admission_due_total += (float)$row['unpaid_amount'];
        $admission_dues[] = [
            'academic_year' => $row['academic_year'],
            'class_name' => $row['class_name'],
            'actual_amount' => (float)$row['actual_amount'],
            'discount_amount' => (float)$row['discount_amount'],
            'unpaid_amount' => (float)$row['unpaid_amount'],
            'remark' => $row['remark'],
        ];
    }

    // ---------------------------------------------------------------------
    // ADDITIONAL FEE DUES
    // ---------------------------------------------------------------------
    $stmt = $pdo->prepare("
        SELECT cwaf.fee_type, cwaf.amount, afd.additional_fee_due_date, c.class_name
        FROM additional_fees_data afd
        JOIN class_wise_additional_fees cwaf ON cwaf.id = afd.additional_fee_setup_id
        LEFT JOIN classes c ON c.id = afd.class_id
        WHERE afd.student_id = ? AND afd.additional_fee_status = 'unpaid'
        ORDER BY cwaf.fee_type ASC
    ");
    $stmt->execute([$student_id]);
    $additional_rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $additional_dues = [];
    $additional_due_total = 0;

    foreach ($additional_rows as $row) {
        $additional_due_total += (float)$row['amount'];
        $additional_dues[] = [
            'fee_type' => $row['fee_type'],
            'class_name' => $row['class_name'],
            'amount' => (float)$row['amount'],
            'due_date' => $row['additional_fee_due_date'],
        ];
    }

    // ---------------------------------------------------------------------
    // PAYMENT HISTORY (monthly + admission, newest first)
    // ---------------------------------------------------------------------
    $stmt = $pdo->prepare("
        SELECT 'monthly' AS type, payment_date, payment_amount, method, remark, updated_at
        FROM student_payment_history
        WHERE student_id = ?
        UNION ALL
        SELECT 'admission' AS type, payment_date, payment_amount, method, remark, updated_at
        FROM admission_fees_payment_history
        WHERE student_id = ?
        ORDER BY payment_date DESC, updated_at DESC
        LIMIT " . PAYMENT_HISTORY_LIMIT
    );
    $stmt->execute([$student_id, $student_id]);
    $history_rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $payment_history = [];

    foreach ($history_rows as $row) {
        $payment_history[] = [
            'type' => $row['type'],
            'payment_date' => $row['payment_date'],
            'payment_amount' => (float)$row['payment_amount'],
            'method' => $row['method'],
            'remark' => $row['remark'],
        ];
    }

    // total_paid is the lifetime figure, so it is summed over the full history
    // rather than over the capped rows returned above.
    $stmt = $pdo->prepare("
        SELECT
            COALESCE((SELECT SUM(payment_amount) FROM student_payment_history WHERE student_id = ?), 0)
          + COALESCE((SELECT SUM(payment_amount) FROM admission_fees_payment_history WHERE student_id = ?), 0)
        AS total_paid
    ");
    $stmt->execute([$student_id, $student_id]);
    $total_paid = (float)$stmt->fetchColumn();

    echo json_encode([
        'success' => true,
        'message' => 'Financial report fetched successfully',
        'can_view_student_financial_report' => 1,
        'student_id' => $student['student_id'],
        'totals' => [
            'total_due' => $monthly_due_total + $admission_due_total + $additional_due_total,
            'monthly_due' => $monthly_due_total,
            'admission_due' => $admission_due_total,
            'additional_due' => $additional_due_total,
            'total_paid' => $total_paid,
        ],
        'monthly_dues' => $monthly_dues,
        'admission_dues' => $admission_dues,
        'additional_dues' => $additional_dues,
        'payment_history' => $payment_history,
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred while fetching the financial report'
    ]);
}
