<?php
include_once(__DIR__ . "/../../../../includes/config.php");

header('Content-Type: application/json');

$sectionId = $_REQUEST['section_id'] ?? null;

if (!$sectionId) {
    echo json_encode(['success' => false, 'message' => 'Section ID is required']);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM students WHERE section_id = ? AND status = 'Active' ORDER BY roll_no ASC");
$stmt->execute([$sectionId]);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['success' => true, 'data' => $students]);