<?php
include_once(__DIR__ . "/../../../../includes/config.php");

header('Content-Type: application/json');

$teacherId = $_REQUEST['teacher_id'] ?? null;

if (!$teacherId) {
    echo json_encode(['success' => false, 'message' => 'Teacher ID is required']);
    exit;
}

$stmt = $pdo->prepare("SELECT assigned_sections FROM teachers WHERE id = ?");
$stmt->execute([$teacherId]);
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$teacher) {
    echo json_encode(['success' => false, 'message' => 'Teacher not found']);
    exit;
}

$assignedSections = json_decode($teacher['assigned_sections'] ?? '[]', true);

$data = array();

foreach ($assignedSections as $section) {
    $stmt = $pdo->prepare("SELECT * FROM sections WHERE id = ?");
    $stmt->execute([$section]);
    $sectionData = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($sectionData) {
        $classId = $sectionData['class_id'];
        $sectionName = $sectionData['section_name'];

        $stmt = $pdo->prepare("SELECT * FROM classes WHERE id = ?");
        $stmt->execute([$classId]);
        $classData = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($classData) {
            $className = $classData['class_name'];

            $data[] = [
                'class_id' => $classId,
                'class_name' => $className,
                'section_id' => $section,
                'section_name' => $sectionName
            ];
        }
    }
}

// Sort data by class id
usort($data, function ($a, $b) {
    return $a['class_id'] - $b['class_id'];
});

echo json_encode(['success' => true, 'data' => $data]);