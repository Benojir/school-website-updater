<?php
include_once(__DIR__ . "/../../../includes/config.php");

header('Content-Type: application/json');

// Validate request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$loginData = $_POST['login_data'] ?? null;
$ipAddress = getUserPublicIP();

if (!$loginData) {
    echo json_encode(['success' => false, 'message' => 'Invalid login data']);
    exit;
}

$loginData = json_decode($loginData, true);

$phone = sanitize_input($loginData['phone'] ?? '');
$password = $loginData['password'] ?? '';
$deviceId = sanitize_input($loginData['deviceId'] ?? '');
$deviceName = sanitize_input($loginData['deviceName'] ?? 'Unknown Device');

// Validate phone number format
if (!isValidPhoneNumber($phone)) {
    echo json_encode(['success' => false, 'message' => 'Phone number is invalid. Tip: Do not add country code.']);
    exit;
}

// Check if teacher account exists
$stmt = $pdo->prepare("SELECT * FROM teacher_accounts WHERE phone_number = ?");
$stmt->execute([$phone]);
$teacher_account = $stmt->fetch(PDO::FETCH_ASSOC) ?? null;

if (!$teacher_account) {
    echo json_encode(['success' => false, 'message' => 'Invalid phone number or password']);
    exit;
}

$teacher_account_id = $teacher_account['id'];
$teacher_id = $teacher_account['teacher_id'];

// Verify password
if (!password_verify($password, $teacher_account['password_hash'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid phone number or password']);
    exit;
}

// Fetch teacher details
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE id = ?");
$stmt->execute([$teacher_id]);
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$teacher) {
    echo json_encode(['success' => false, 'message' => 'Teacher not found']);
    exit;
}

// Check if teacher is active
if ($teacher['status'] !== 'active') {
    echo json_encode(['success' => false, 'message' => 'Teacher is not active']);
    exit;
}


$assigned_sections = json_decode($teacher['assigned_sections'] ?? '[]', true);

// Before generating a new token, invalidate any existing sessions for this device
$stmt = $pdo->prepare("DELETE FROM teacher_auth_sessions WHERE device_id = ?");
$stmt->execute([$deviceId]);

// Generate new token
$token = bin2hex(random_bytes(32));
$tokenHash = hash('sha256', $token);
$expiry = date('Y-m-d H:i:s', strtotime('+30 days'));

// Store session
$stmt = $pdo->prepare(
    "INSERT INTO teacher_auth_sessions 
        (teacher_account_id, teacher_id, token_hash, device_id, device_name, session_source, ip_address, expires_at) 
     VALUES (?, ?, ?, ?, ?, 'mobile', ?, ?)"
);
$stmt->execute([
    $teacher_account_id,
    $teacher_id,
    $tokenHash,
    $deviceId,
    $deviceName,
    $ipAddress,
    $expiry
]);

// Prepare response
$response = [
    'success' => true,
    'message' => 'Mobile login successful',
    'data' => [
        'teacher_id' => $teacher_id,
        'phone_number' => $teacher_account['phone_number'],
        'assigned_sections' => $assigned_sections,
        'token' => $token,
        'expires_at' => $expiry
    ]
];

echo json_encode($response);