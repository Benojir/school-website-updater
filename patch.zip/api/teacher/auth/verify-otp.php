<?php
include_once(__DIR__ . "/../../../includes/config.php");
include_once(__DIR__ . "/../../../includes/functions.php");

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(['success' => false, 'message' => 'Invalid request method']));
}

$phone = sanitize_input($_POST['phone'] ?? '');
$otp = sanitize_input($_POST['otp'] ?? '');
$purpose = sanitize_input($_POST['purpose'] ?? '');
$data = $_POST['data'] ?? '';

// Validate inputs
if (empty($phone)) {
    die(json_encode(['success' => false, 'message' => 'Phone number is required']));
}

if (empty($otp)) {
    die(json_encode(['success' => false, 'message' => 'OTP is required']));
}

if (empty($purpose)) {
    die(json_encode(['success' => false, 'message' => 'Purpose is required']));
}

// Verify OTP
$stmt = $pdo->prepare("SELECT * FROM otp_verification WHERE phone_number = ? AND otp = ? AND purpose = ? AND expiry > NOW() AND verified = 0");
$stmt->execute([$phone, $otp, $purpose]);
$otpRecord = $stmt->fetch();

if (!$otpRecord) {
    die(json_encode(['success' => false, 'message' => 'Invalid or expired OTP']));
}

// Mark OTP as verified
$stmt = $pdo->prepare("UPDATE otp_verification SET verified = 1 WHERE id = ?");
$stmt->execute([$otpRecord['id']]);

if ($purpose === 'login') {
    $data = json_decode($data, true);

    $device_id = $data['device_id'];
    $fcm_token = $data['fcm_token'];
    $device_name = $data['device_name'];
    $app_version = $data['app_version'] ?? null;
    $session_source = 'mobile';
    $ip_address = getUserPublicIP();
    $token = generateToken();
    $tokenHash = hash('sha256', $token);

    // First delete old session from this mobile
    $stmt = $pdo->prepare("DELETE FROM teacher_auth_sessions WHERE device_id = ?");
    $stmt->execute([$device_id]);

    // Fetch the teacher ids associated with this phone number
    $stmt = $pdo->prepare("SELECT id FROM teachers WHERE phone = ? AND status = 'active' LIMIT 1");
    $stmt->execute([$phone]);
    $teacher = $stmt->fetch();

    if (!$teacher) {
        die(json_encode(['success' => false, 'message' => 'Teacher not found']));
    }

    $teacher_id = $teacher['id'];

    // Delete all sessions that last activity was more than 90 days ago
    $stmt = $pdo->prepare("DELETE FROM teacher_auth_sessions WHERE last_activity < NOW() - INTERVAL 90 DAY");
    @$stmt->execute();

    // Insert the session
    $stmt = $pdo->prepare("INSERT INTO teacher_auth_sessions (teacher_id, token_hash, device_id, device_name, fcm_token, session_source, ip_address, app_version, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    $insert = $stmt->execute([$teacher_id , $tokenHash, $device_id, $device_name, $fcm_token, $session_source, $ip_address, $app_version]);

    if ($insert) {
        // Return success
        $response = [
            'success' => true,
            'message' => 'OTP verified successfully!',
            'token' => $token,
            'teacher_id' => $teacher_id,
            'phone' => $phone
        ];

        echo json_encode($response);
    } else {
        // Return error
        echo json_encode(['success' => false, 'message' => 'Failed to insert session']);
    }

} else {
    // For password reset, just return success - the actual password reset happens in reset-password.php
    echo json_encode(['success' => true, 'message' => 'OTP verified successfully!']);
}