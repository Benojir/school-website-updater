<?php
include_once(__DIR__ . "/../../../includes/teacher/auth/teacher-auth-check.php");

header('Content-Type: application/json');

// Use the new helper function from auth-check.php
$authData = authenticateApiRequest($pdo); 

if (!$authData) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Delete the session from the NEW table
$stmt = $pdo->prepare("DELETE FROM teacher_auth_sessions WHERE id = ?");
$logout = $stmt->execute([$authData['session_id']]);

if (!$logout) {
    echo json_encode(['success' => false, 'message' => 'Logout failed. Please try again.']);
    exit;
}

// Delete rows associated with this mobile device
$stmt = $pdo->prepare("DELETE FROM teacher_auth_sessions WHERE device_id = ?");
$stmt->execute([$authData['device_id']]);

echo json_encode(['success' => true, 'message' => 'Logout successful']);