<?php
include_once(__DIR__ . "/../../../includes/config.php");
include_once(__DIR__ . "/../../../includes/otp-sending-helper.php");

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(['success' => false, 'message' => 'Invalid request method']));
}

$phone = sanitize_input($_POST['phone']);

// Validate input
if (empty($phone)) {
    die(json_encode(['success' => false, 'message' => 'Phone number is required']));
}

// Check if phone number is registered with any teacher
$stmt = $pdo->prepare("SELECT id FROM teachers WHERE phone = ?");
$stmt->execute([$phone]);
$teachers = $stmt->fetchAll();

if (empty($teachers)) {
    die(json_encode(['success' => false, 'message' => 'This phone number is not registered with any teacher']));
}

// Check if teacher account exists
$stmt = $pdo->prepare("SELECT id FROM teacher_accounts WHERE phone_number = ?");
$stmt->execute([$phone]);
if (!$stmt->fetch()) {
    die(json_encode(['success' => false, 'message' => 'No account found with this phone number']));
}

// Generate OTP
$otp = generateOTP(6);

// Delete all expired stored OTPs for optimazation
$stmt = $pdo->prepare("DELETE FROM otp_verification WHERE expiry < NOW()");
$stmt->execute();

// Store OTP in database
$stmt = $pdo->prepare("INSERT INTO otp_verification (phone_number, otp, expiry, purpose) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE), 'password_reset')");
$stmt->execute([$phone, $otp]);

// Send the OTP here
$result = sendOTP($websiteConfig, $phone, $otp);

echo json_encode($result);
exit;