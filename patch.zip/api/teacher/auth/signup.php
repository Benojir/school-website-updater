<?php
include_once(__DIR__ . "/../../../includes/config.php");
include_once(__DIR__ . "/../../../includes/otp-sending-helper.php");

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(['success' => false, 'message' => 'Invalid request method']));
}

$phone = sanitize_input($_POST['phone'] ?? '');
$password = $_POST['password'] ?? '';

// Validate inputs
if (empty($phone) || empty($password)) {
    die(json_encode(['success' => false, 'message' => 'Phone number and password are required']));
}

// Check password length
if (strlen($password) < 6) {
    die(json_encode(['success' => false, 'message' => 'Password lenth minimum 6 characters required.']));
}

// Check if phone number is registered with any teacher
$stmt = $pdo->prepare("SELECT id FROM teachers WHERE phone = ? AND status = 'active' LIMIT 1");
$stmt->execute([$phone]);
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);

$teacher_id = $teacher['id'] ?? null;

if (!$teacher_id) {
    die(json_encode(['success' => false, 'message' => 'This phone number is not registered with any teacher']));
}

// Check if teacher account already exists
$stmt = $pdo->prepare("SELECT id FROM teacher_accounts WHERE phone_number = ? OR teacher_id = ? LIMIT 1");
$stmt->execute([$phone, $teacher_id]);
if ($stmt->fetch()) {
    die(json_encode(['success' => false, 'message' => 'An account already exists with this phone number or teacher id']));
}

// Generate OTP (in a real app, you would send this via Firebase)
$otp = generateOTP(6);

// Delete all expired stored OTPs for optimazation
$stmt = $pdo->prepare("DELETE FROM otp_verification WHERE expiry < NOW()");
$stmt->execute();

// Store OTP in database
$stmt = $pdo->prepare("INSERT INTO otp_verification (phone_number, otp, expiry, purpose) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE), ?)");
$stmt->execute([$phone, $otp, 'signup']);

// Send the OTP here
$result = sendOTP($phone, $otp);

if (!$result['success']) {
    sendErrorResponse($result['message']);
}
sendSuccessResponse($result['message']);