<?php
include_once(__DIR__ . "/../../../includes/config.php");

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(['success' => false, 'message' => 'Invalid request method']));
}

$phone = sanitize_input($_POST['phone'] ?? '');
$password = $_POST['password'] ?? '';
$purpose = strtolower(sanitize_input($_POST['purpose'] ?? ''));
$otp = sanitize_input($_POST['otp'] ?? '');

if (empty($phone)) {
    die(json_encode(['success' => false, 'message' => 'Phone number is required']));
}
if (empty($otp)) {
    die(json_encode(['success' => false, 'message' => 'OTP is required']));
}
if (empty($purpose)) {
    die(json_encode(['success' => false, 'message' => 'Purpose is required']));
}
if (empty($password)) {
    die(json_encode(['success' => false, 'message' => 'Password is required']));
}

// Verify OTP
$stmt = $pdo->prepare("SELECT * FROM otp_verification WHERE phone_number = ? AND otp = ? AND purpose = ? AND expiry > NOW() AND verified = 0");
$stmt->execute([$phone, $otp, $purpose]);
$otpRecord = $stmt->fetch();

if (!$otpRecord) {
    die(json_encode(['success' => false, 'message' => 'Invalid or expired OTP']));
}

// Mark OTP as verified
$stmt = $pdo->prepare("UPDATE otp_verification SET verified = 1 WHERE id = ?");
$stmt->execute([$otpRecord['id']]);

// Get the teacher id
$stmt = $pdo->prepare("SELECT id FROM teachers WHERE phone = ? AND status = 'active' LIMIT 1");
$stmt->execute([$phone]);
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);
$teacher_id = $teacher['id'] ?? null;

if (!$teacher_id) {
    die(json_encode(['success' => false, 'message' => 'Teacher not found']));
}

// Hash the password
$passwordHash = password_hash($password, PASSWORD_DEFAULT);

if ($purpose === 'signup') {
    // Create teacher account
    $stmt = $pdo->prepare("INSERT INTO teacher_accounts (teacher_id, phone_number, password_hash) VALUES (?, ?, ?)");
    $stmt->execute([$teacher_id, $phone, $passwordHash]);

    echo json_encode(['success' => true, 'message' => 'Account created successfully!']);

} elseif ($purpose === 'password_reset') {
    $stmt = $pdo->prepare("UPDATE teacher_accounts SET password_hash = ? WHERE phone_number = ? AND teacher_id = ?");
    $stmt->execute([$passwordHash, $phone, $teacher_id]);

    echo json_encode(['success' => true, 'message' => 'Password updated successfully!']);

} else {
    // For password reset, just return success - the actual password reset happens in reset-password.php
    echo json_encode(['success' => true, 'message' => 'OTP verified successfully!']);
}
