<?php
include_once __DIR__ . '/../../includes/config.php';

$content = file_get_contents("php://input");
file_put_contents(__DIR__ . '/homework-hook.log', $content);
$update = json_decode($content, true);

$is_edit = isset($update['edited_channel_post']);
$post = $is_edit ? $update['edited_channel_post'] : ($update['channel_post'] ?? null);

if ($post) {
    $chat_id = $post['chat']['id'];
    $message_id = $post['message_id'];
    $text = $post['text'] ?? $post['caption'] ?? '';
    $media_group_id = $post['media_group_id'] ?? null;

    $file_id = null; $file_type = 'text'; $file_name = null; $file_size = null;
    $file_width = null; $file_height = null; $thumb_id = null; $thumb_width = null; $thumb_height = null;

    // ফাইল এক্সট্রাকশন লজিক আগের মতোই থাকবে
    if (isset($post['photo'])) {
        $photo = end($post['photo']); 
        $file_id = $photo['file_id']; $file_type = 'photo'; $file_size = $photo['file_size'] ?? 0;
        $file_width = $photo['width'] ?? null; $file_height = $photo['height'] ?? null;
        $thumb = $post['photo'][0]; $thumb_id = $thumb['file_id'];
        $thumb_width = $thumb['width'] ?? null; $thumb_height = $thumb['height'] ?? null;
    } elseif (isset($post['video'])) {
        $video = $post['video']; $file_id = $video['file_id']; $file_type = 'video';
        $file_name = $video['file_name'] ?? 'Unknown Video'; $file_size = $video['file_size'] ?? 0;
        $file_width = $video['width'] ?? null; $file_height = $video['height'] ?? null;
        $thumbData = $video['thumbnail'] ?? $video['thumb'] ?? null;
        if ($thumbData) {
            $thumb_id = $thumbData['file_id']; $thumb_width = $thumbData['width'] ?? null; $thumb_height = $thumbData['height'] ?? null;
        }
    } elseif (isset($post['voice'])) {
        $file_id = $post['voice']['file_id']; $file_type = 'voice';
        $file_name = $post['voice']['file_name'] ?? 'Voice Message'; $file_size = $post['voice']['file_size'] ?? 0;
    } elseif (isset($post['audio'])) {
        $file_id = $post['audio']['file_id']; $file_type = 'audio'; 
        $file_name = $post['audio']['file_name'] ?? 'Unknown Audio'; $file_size = $post['audio']['file_size'] ?? 0;
    } elseif (isset($post['document'])) {
        $document = $post['document']; $file_id = $document['file_id']; $file_type = 'document';
        $file_name = $document['file_name'] ?? 'Unknown Document'; $file_size = $document['file_size'] ?? 0;
        $thumbData = $document['thumbnail'] ?? $document['thumb'] ?? null;
        if ($thumbData) {
            $thumb_id = $thumbData['file_id']; $thumb_width = $thumbData['width'] ?? null; $thumb_height = $thumbData['height'] ?? null;
        }
    }

    $file_size = (float) ($file_size ?? 0);
    if (($file_size / 1048576) > 20.0) exit;

    if ($is_edit) {
        // ১. এডিট হলে শুধুমাত্র মূল টেবিলটি একবার আপডেট হবে (ম্যাপিং টেবিল আপডেট করার দরকার নেই)
        $updateStmt = $pdo->prepare("
            UPDATE student_homeworks 
            SET message_text = ?, file_id = ?, file_type = ?, file_name = ?, file_size = ?, 
                file_width = ?, file_height = ?, thumb_id = ?, thumb_width = ?, thumb_height = ? 
            WHERE message_id = ?
        ");
        $updateStmt->execute([
            $text, $file_id, $file_type, $file_name, $file_size,
            $file_width, $file_height, $thumb_id, $thumb_width, $thumb_height, $message_id
        ]);
    } else {
        // ২. নতুন পোস্ট হলে মূল টেবিলে একবার ইনসার্ট হবে
        $insertStmt = $pdo->prepare("
            INSERT INTO student_homeworks 
            (message_id, media_group_id, message_text, file_id, file_type, file_name, file_size, file_width, file_height, thumb_id, thumb_width, thumb_height) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $insertStmt->execute([
            $message_id, $media_group_id, $text, $file_id, $file_type, $file_name, 
            $file_size, $file_width, $file_height, $thumb_id, $thumb_width, $thumb_height
        ]);
        
        // সদ্য ইনসার্ট হওয়া রো এর ID বের করা
        $homework_id = $pdo->lastInsertId();

        // chat_id দিয়ে সবগুলো section_id বের করা
        $stmt = $pdo->prepare("SELECT id FROM sections WHERE telegram_chat_id = ?");
        $stmt->execute([$chat_id]);
        $sections = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // ৩. ম্যাপিং টেবিলে শুধু homework_id এবং section_id ইনসার্ট করা
        if ($sections && count($sections) > 0) {
            $mapStmt = $pdo->prepare("INSERT INTO homework_section_map (homework_id, section_id) VALUES (?, ?)");
            foreach ($sections as $section) {
                $mapStmt->execute([$homework_id, $section['id']]);
            }
        }
    }
}
?>