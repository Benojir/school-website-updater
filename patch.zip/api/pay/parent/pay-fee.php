<?php
$studentId = $_REQUEST['student_id'] ?? null;
$feeId = $_REQUEST['id'] ?? null;
$type = $_REQUEST['type'] ?? null;

if (!$studentId || !$feeId || !$type) {
    http_response_code(400);
    echo "<center><h3 style='color:red;'>Invalid request. Missing parameters.</h3></center>";
    exit;
}

if ($type === 'unpaid_monthly_fees' || $type === 'unpaid_admission_fees') {
    header("Location: pay-monthly-x-admission-fee.php?id=$feeId&student_id=$studentId&type=$type");
    exit;
}

if ($type === 'unpaid_additional_fees') {
    header("Location: pay-additional-fee.php?id=$feeId&student_id=$studentId&type=$type");
    exit;
}