<?php
require_once __DIR__ . '/../../../includes/config.php';
require_once __DIR__ . '/../../../includes/parent/financial/fee-payment-service.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); header('Allow: POST'); exit; }
$raw = file_get_contents('php://input', false, null, 0, 262145);
$secret = $websiteConfig['razorpay_webhook_secret'] ?? '';
$signature = $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'] ?? '';
if ($secret === '' || strlen($raw) > 262144 || !hash_equals(hash_hmac('sha256', $raw, $secret), $signature)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid webhook signature.']);
    exit;
}
try {
    $data = json_decode($raw, true, 64, JSON_THROW_ON_ERROR);
    if (in_array($data['event'] ?? '', ['payment.captured', 'order.paid'], true)) {
        $id = $data['payload']['payment']['entity']['order_id'] ?? $data['payload']['order']['entity']['id'] ?? '';
        if (is_string($id) && preg_match('/^order_[a-zA-Z0-9]+$/D', $id)) {
            $service = new FeePaymentService($pdo, new FeePaymentGateway($websiteConfig['razorpay_key_id'] ?? '', $websiteConfig['razorpay_key_secret'] ?? ''),
                $websiteConfig, (int)($schoolSettings['allow_online_payment'] ?? 0) === 1);
            $order = $service->order($id);
            // Ignore unrelated orders. Fetch current provider state instead of trusting a delayed event.
            if ($order) $service->reconcile($order);
        }
    }
    echo json_encode(['success' => true]);
} catch (Throwable $e) {
    error_log('Fee payment webhook: ' . $e->getMessage());
    http_response_code(500); // Razorpay retries; settlement is idempotent.
    echo json_encode(['success' => false, 'message' => 'Please retry this event.']);
}
