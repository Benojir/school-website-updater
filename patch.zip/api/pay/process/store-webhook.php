<?php
require_once __DIR__ . '/../../../includes/config.php';
require_once __DIR__ . '/../../../includes/inventory/inventory-order-service.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); header('Allow: POST'); exit; }
$raw = file_get_contents('php://input', false, null, 0, 262145);
$secret = $websiteConfig['razorpay_webhook_secret'] ?? '';
$signature = $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'] ?? '';
if ($secret === '' || strlen($raw) > 262144 || !hash_equals(hash_hmac('sha256', $raw, $secret), $signature)) {
    http_response_code(400);
    echo json_encode(['success'=>false, 'message'=>'Invalid webhook signature.']);
    exit;
}
try {
    $data = json_decode($raw, true, 64, JSON_THROW_ON_ERROR);
    $event = $data['event'] ?? '';
    $gateway = new StoreGateway($websiteConfig['razorpay_key_id'] ?? '', $websiteConfig['razorpay_key_secret'] ?? '');
    $service = new InventoryOrderService($pdo, null, $gateway);
    if (in_array($event, ['payment.captured', 'order.paid'], true)) {
        // Fetch current state so a delayed captured event cannot overwrite a subsequent refund.
        $id = $data['payload']['payment']['entity']['id'] ?? '';
        $service->applyProviderPayment($gateway->payment($id));
    } elseif ($event === 'refund.processed') {
        $id = $data['payload']['refund']['entity']['payment_id'] ?? '';
        $service->applyProviderPayment($gateway->payment($id));
    }
    echo json_encode(['success'=>true]);
} catch (Throwable $e) {
    error_log('Store webhook: ' . $e->getMessage());
    http_response_code(500); // Razorpay retries; all updates are idempotent.
    echo json_encode(['success'=>false, 'message'=>'Please retry this event.']);
}
