<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Payment Cancelled</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #fff8f8;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }

    .cancel-container {
      background: #fff;
      padding: 40px;
      max-width: 500px;
      width: 100%;
      box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
      border-radius: 10px;
      text-align: center;
      border-top: 5px solid #dc3545;
    }

    .cancel-icon {
      font-size: 60px;
      color: #dc3545;
      margin-bottom: 20px;
    }

    .cancel-container h1 {
      font-size: 28px;
      margin-bottom: 10px;
      color: #333;
    }

    .cancel-container p {
      font-size: 16px;
      color: #666;
      margin-bottom: 20px;
    }

    .cancel-container .details {
      background: #f9d6d5;
      padding: 15px;
      border-radius: 8px;
      text-align: left;
      font-size: 14px;
      margin-bottom: 20px;
    }

    .cancel-container .details strong {
      display: inline-block;
      width: 130px;
      color: #333;
    }

    .cancel-container a.button {
      display: inline-block;
      padding: 12px 25px;
      background-color: #dc3545;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      transition: background-color 0.3s;
    }

    .cancel-container a.button:hover {
      background-color: #c82333;
    }

    @media (max-width: 600px) {
      .cancel-container {
        padding: 30px 20px;
      }
    }
  </style>
</head>

<body>

  <div class="cancel-container">
    <div class="cancel-icon">❌</div>
    <h1>Payment Failed</h1>
    <p>Your payment was not completed. If this was a mistake, you can try again.</p>

    <div class="details">
      <p><strong>Status:</strong> Failed</p>
      <p><strong>Date:</strong> <?= date('F j, Y') ?></p>
      <?php if (isset($_SESSION['amount'])): ?>
        <p><strong>Amount:</strong> ₹<?= $_SESSION['amount'] ?></p>
      <?php endif; ?>
      <?php if (isset($_SESSION['reason'])): ?>
        <p><strong>Reason:</strong> ₹<?= $_SESSION['reason'] ?></p>
      <?php endif; ?>
    </div>

    <a href="#" onclick="closeCurrentTab()" class="button">Close</a>
  </div>

  <script>
    function closeCurrentTab() {
      window.location.replace("/");
    }
  </script>

</body>

</html>