<?php
/** @var PDO $pdo */
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$auto_request_monthly_fees_day = sanitize_input($_POST['auto_request_monthly_fees_day'] ?? '28');

if (!is_numeric($auto_request_monthly_fees_day) || $auto_request_monthly_fees_day < 1 || $auto_request_monthly_fees_day > 28) {
    echo json_encode(['success' => false, 'message' => 'Auto request monthly fees day must be between 1 and 28']);
    exit();
}

// School feature settings stored as JSON
$settings = [
    'admission_open' => isset($_POST['admission_open_checkbox']) ? 1 : 0,
    'teacher_application' => isset($_POST['teacher_application']) ? 1 : 0,
    'total_student_show' => isset($_POST['total_students_checkbox']) ? 1 : 0,
    'admin_login_option_show' => isset($_POST['admin_login_option_show']) ? 1 : 0,
    'show_teachers_on_front_page' => isset($_POST['show_teachers_on_front_page']) ? 1 : 0,
    'allow_online_payment' => isset($_POST['allow_online_payment']) ? 1 : 0,
    'auto_request_monthly_fees' => isset($_POST['auto_request_monthly_fees']) ? 1 : 0,
    'need_security_pin_for_payment_entry' => isset($_POST['need_security_pin_for_payment_entry']) ? 1 : 0,
    'hide_fees_structure_from_website' => isset($_POST['hide_fees_structure_from_website']) ? 1 : 0
];

$data = [
    'auto_request_monthly_fees_day' => $auto_request_monthly_fees_day,
    'settings' => json_encode($settings)
];

try {
    // Check if a school settings row already exists
    $stmt = $pdo->query("SELECT id FROM school_settings LIMIT 1");
    $existingRow = $stmt->fetch();

    if ($existingRow) {
        // Update existing record
        $sql = "UPDATE school_settings SET
            auto_request_monthly_fees_day = :auto_request_monthly_fees_day,
            settings = :settings
            WHERE id = :id";

        $data['id'] = $existingRow['id'];
    } else {
        // Insert new record
        $sql = "INSERT INTO school_settings
            (auto_request_monthly_fees_day, settings)
            VALUES
            (:auto_request_monthly_fees_day, :settings)";
    }

    $stmt = $pdo->prepare($sql);
    $success = $stmt->execute($data);

    if ($success) {
        echo json_encode([
            'success' => true,
            'message' => 'School settings saved successfully'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to save school settings']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
