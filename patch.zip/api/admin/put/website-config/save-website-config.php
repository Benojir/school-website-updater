<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

// Validate all required fields
$requiredFields = [
    'super_admin_email', 
    'student_id_prefix', 
    'imgbb_api_key', 
    'firebase_config', 
    'fbase_service_account_key', 
    'captcha_site_key', 
    'captcha_secret_key', 
    'otp_gateway', 
    'razorpay_key_id', 
    'razorpay_key_secret', 
    'razorpay_charge_percentage', 
    'gst_on_razorpay_charge', 
    'smtp_server', 
    'smtp_username', 
    'smtp_password'
];

foreach ($requiredFields as $field) {
    if (empty($_POST[$field])) {
        echo json_encode(['success' => false, 'message' => "All fields are required"]);
        exit();
    }
}

if (!is_numeric($_POST['razorpay_charge_percentage']) || !is_numeric($_POST['gst_on_razorpay_charge'])) {
    echo json_encode(['success' => false, 'message' => "Razorpay charge or gst must be a numerical value"]);
    exit();
}

// Additional website configs
$additional_website_configs = [
    'admission_open' => isset($_POST['admission_open_checkbox']) ? 1 : 0,
    'teacher_application' => isset($_POST['teacher_application']) ? 1 : 0,
    'total_student_show' => isset($_POST['total_students_checkbox']) ? 1 : 0,
    'admin_login_option_show' => isset($_POST['admin_login_option_show']) ? 1 : 0,
    'show_teachers_on_front_page' => isset($_POST['show_teachers_on_front_page']) ? 1 : 0,
    'allow_online_payment' => isset($_POST['allow_online_payment']) ? 1 : 0,
    'auto_request_monthly_fees' => isset($_POST['auto_request_monthly_fees']) ? 1 : 0,
    'need_security_pin_for_payment_entry' => isset($_POST['need_security_pin_for_payment_entry']) ? 1 : 0,
    'hide_fees_structure_from_website' => isset($_POST['hide_fees_structure_from_website']) ? 1 : 0
];

// Build the data array
$data = [
    'super_admin_email' => strtolower(sanitize_input($_POST['super_admin_email'])),
    'student_id_prefix' => strtoupper(sanitize_input($_POST['student_id_prefix'])),
    'imgbb_api_key' => sanitize_input($_POST['imgbb_api_key']),
    'telegram_bot_token' => sanitize_input($_POST['telegram_bot_token'] ?? null),
    'file_storage_channel_id' => sanitize_input($_POST['file_storage_channel_id'] ?? null),
    'firebase_config' => $_POST['firebase_config'] ?? null,
    'fbase_service_account_key' => $_POST['fbase_service_account_key'] ?? null,
    'captcha_site_key' => sanitize_input($_POST['captcha_site_key']),
    'captcha_secret_key' => sanitize_input($_POST['captcha_secret_key']),
    'otp_messages_gateway' => sanitize_input($_POST['otp_gateway']),
    'razorpay_key_id' => sanitize_input($_POST['razorpay_key_id']),
    'razorpay_key_secret' => sanitize_input($_POST['razorpay_key_secret']),
    'razorpay_webhook_secret' => sanitize_input($_POST['razorpay_webhook_secret']),
    'razorpay_charge_percentage' => sanitize_input($_POST['razorpay_charge_percentage']),
    'gst_on_razorpay_charge' => sanitize_input($_POST['gst_on_razorpay_charge']),
    'smtp_server' => sanitize_input($_POST['smtp_server']),
    'smtp_username' => sanitize_input($_POST['smtp_username']),
    'smtp_password' => sanitize_input($_POST['smtp_password']),
    'currency_symbol' => sanitize_input($_POST['currency_symbol']),
    'timezone' => sanitize_input($_POST['timezone']),
    'auto_request_monthly_fees_day' => sanitize_input($_POST['auto_request_monthly_fees_day'] ?? '28'),
    'additional_settings' => json_encode($additional_website_configs)
];


try {
    // Check if school info already exists
    $stmt = $pdo->query("SELECT id FROM website_config LIMIT 1");
    $existingInfo = $stmt->fetch();

    if ($existingInfo) {
        // Update existing record
        $sql = "UPDATE website_config SET 
            super_admin_email = :super_admin_email,
            student_id_prefix = :student_id_prefix,
            imgbb_api_key = :imgbb_api_key,
            telegram_bot_token = :telegram_bot_token,
            file_storage_channel_id = :file_storage_channel_id,
            firebase_config = :firebase_config,
            fbase_service_account_key = :fbase_service_account_key,
            captcha_site_key = :captcha_site_key,
            captcha_secret_key = :captcha_secret_key,
            otp_messages_gateway = :otp_messages_gateway,
            razorpay_key_id = :razorpay_key_id,
            razorpay_key_secret = :razorpay_key_secret,
            razorpay_webhook_secret = :razorpay_webhook_secret,
            razorpay_charge_percentage = :razorpay_charge_percentage,
            gst_on_razorpay_charge = :gst_on_razorpay_charge,
            smtp_server = :smtp_server,
            smtp_username = :smtp_username,
            smtp_password = :smtp_password,
            currency_symbol = :currency_symbol,
            timezone = :timezone,
            auto_request_monthly_fees_day = :auto_request_monthly_fees_day,
            additional_settings = :additional_settings
            WHERE id = :id";
        
        $data['id'] = $existingInfo['id'];
    } else {
        // Insert new record
        $sql = "INSERT INTO website_config 
            (super_admin_email, 
            student_id_prefix, 
            imgbb_api_key, 
            telegram_bot_token, 
            file_storage_channel_id,
            firebase_config,
            fbase_service_account_key,
            captcha_site_key, 
            captcha_secret_key, 
            otp_messages_gateway, 
            razorpay_key_id, 
            razorpay_key_secret, 
            razorpay_webhook_secret, 
            razorpay_charge_percentage, 
            gst_on_razorpay_charge, 
            smtp_server, 
            smtp_username, 
            smtp_password, 
            currency_symbol,
            timezone, 
            auto_request_monthly_fees_day, 
            additional_settings)
            VALUES 
            (:super_admin_email, 
            :student_id_prefix, 
            :imgbb_api_key, 
            :telegram_bot_token,
            :file_storage_channel_id, 
            :firebase_config,
            :fbase_service_account_key,
            :captcha_site_key, 
            :captcha_secret_key, 
            :otp_messages_gateway, 
            :razorpay_key_id, 
            :razorpay_key_secret, 
            :razorpay_webhook_secret, 
            :razorpay_charge_percentage, 
            :gst_on_razorpay_charge, 
            :smtp_server, 
            :smtp_username, 
            :smtp_password, 
            :currency_symbol,
            :timezone, 
            :auto_request_monthly_fees_day, 
            :additional_settings)";
    }

    $stmt = $pdo->prepare($sql);
    $success = $stmt->execute($data);

    // Update users table to update the superadmin email id
    $stmt = $pdo->prepare("UPDATE users SET email = ? WHERE id = 2");
    $success2 = $stmt->execute([$data['super_admin_email']]);

    if ($success && $success2) {
        echo json_encode([
            'success' => true, 
            'message' => 'Website settings saved successfully'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to save website settings']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>