<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'You do not have permission to perform this action.']);
    exit;
}

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}

try {
    // Sanitize and collect data from the POST request
    $design = $_POST['admissionFormDesignSelector'] ?? 'design-1';
    $primary_color = $_POST['theme_color_primary'] ?? '#0b8800ff';
    $secondary_color = $_POST['theme_color_secondary'] ?? '#085e00ff';
    $dark_color = $_POST['theme_color_dark'] ?? '#272727ff';
    $light_color = $_POST['theme_color_light'] ?? '#f2f7ffff';
    $bg_color = $_POST['background_color'] ?? '#f2f7ffff';
    $school_name_color = $_POST['school_name_color'] ?? '#0b8800ff';
    $school_address_color = $_POST['school_address_text_color'] ?? '#190088ff';

    // Handle checkboxes: They are only present in $_POST if checked.
    // The value will be 1 if the checkbox is checked, otherwise 0.
    $fast_generation = isset($_POST['fast_generation']) ? 1 : 0;

    // Prepare SQL statement to update the single row in the settings table
    $sql = "UPDATE settings_admission_form SET 
                admission_form_design = :design,
                primary_theme_color = :primary_color,
                secondary_theme_color = :secondary_color,
                dark_theme_color = :dark_color,
                light_theme_color = :light_color,
                background_color = :bg_color,
                school_name_text_color = :school_name_color,
                school_address_text_color = :school_address_color,
                fast_generation = :fast_generation";

    $stmt = $pdo->prepare($sql);

    // Bind parameters to the prepared statement
    $stmt->bindParam(':design', $design, PDO::PARAM_STR);
    $stmt->bindParam(':primary_color', $primary_color, PDO::PARAM_STR);
    $stmt->bindParam(':secondary_color', $secondary_color, PDO::PARAM_STR);
    $stmt->bindParam(':dark_color', $dark_color, PDO::PARAM_STR);
    $stmt->bindParam(':light_color', $light_color, PDO::PARAM_STR);
    $stmt->bindParam(':bg_color', $bg_color, PDO::PARAM_STR);
    $stmt->bindParam(':school_name_color', $school_name_color, PDO::PARAM_STR);
    $stmt->bindParam(':school_address_color', $school_address_color, PDO::PARAM_STR);
    $stmt->bindParam(':fast_generation', $fast_generation, PDO::PARAM_INT);

    // Execute the query and send a response
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Settings updated successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to save settings. Please try again.']);
    }

} catch (PDOException $e) {
    // Handle any database connection or query errors
    // For debugging, you can use $e->getMessage(), but for production, a generic message is safer.
    error_log('Settings save error: ' . $e->getMessage()); // Log error
    echo json_encode(['success' => false, 'message' => 'A database error occurred.']);
}

?>