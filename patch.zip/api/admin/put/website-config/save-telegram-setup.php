<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// শুধুমাত্র সুপার এডমিন কিনা তা যাচাই করা
if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied!']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $chat_ids = isset($_POST['chat_ids']) && is_array($_POST['chat_ids']) ? $_POST['chat_ids'] : [];

        // ডাটাবেস ট্রানজেকশন শুরু
        $pdo->beginTransaction();

        // আপডেট কুয়েরি প্রস্তুত করা
        $stmt = $pdo->prepare("UPDATE sections SET telegram_chat_id = :chat_id WHERE id = :id");

        foreach ($chat_ids as $section_id => $chat_id) {
            // chat_id ফাঁকা থাকলে null সেভ হবে
            $clean_chat_id = isset($chat_id) && trim($chat_id) !== '' ? trim($chat_id) : null;
            
            $stmt->execute([
                ':chat_id'   => $clean_chat_id,
                ':id'        => $section_id
            ]);
        }

        // সব ঠিক থাকলে ডাটাবেসে সেভ করা হবে
        $pdo->commit();

        echo json_encode(['success' => true, 'message' => 'Settings saved successfully']);
        
    } catch (PDOException $e) {
        // কোনো ত্রুটি হলে রোলব্যাক করা হবে
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>