<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

// Validate input
if (!isset($_POST['idCardStyle']) || empty($_POST['idCardStyle'])) {
    echo json_encode(['success' => false, 'message' => 'No template selected']);
    exit();
}

$idCardStyle = basename($_POST['idCardStyle']); // Sanitize filename

// Verify template exists
if (!file_exists( __DIR__ . "/../../../../assets/img/id-preview/" . $idCardStyle)) {
    echo json_encode(['success' => false, 'message' => 'Selected template does not exist']);
    exit();
}

try {
    // Check if school info exists
    $stmt = $pdo->query("SELECT id FROM website_config LIMIT 1");
    $existingInfo = $stmt->fetch();

    if ($existingInfo) {
        // Update existing record
        $sql = "UPDATE website_config SET id_card_style = ? WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $success = $stmt->execute([$idCardStyle, $existingInfo['id']]);
    } else {
        // Insert new record
        $sql = "INSERT INTO website_config (id_card_style) VALUES (?)";
        $stmt = $pdo->prepare($sql);
        $success = $stmt->execute([$idCardStyle]);
    }

    if ($success) {
        echo json_encode([
            'success' => true,
            'message' => 'ID card style updated successfully'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update ID card style']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>