<?php
// Audience is selected only by this server-side entry point.
define('ID_CARD_AUDIENCE', 'driver');
require __DIR__ . '/save-student-id-card-design.php';
