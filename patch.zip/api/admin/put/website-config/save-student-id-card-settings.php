<?php
// save-student-id-card-settings.php

// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

try {
    // 1. Collect and Sanitize Inputs
    $layout = filter_input(INPUT_POST, 'id_design_layout', FILTER_SANITIZE_SPECIAL_CHARS);
    $school_address = filter_input(INPUT_POST, 'school_address_on_card', FILTER_SANITIZE_SPECIAL_CHARS);
    $school_contacts = filter_input(INPUT_POST, 'school_contacts_on_card', FILTER_SANITIZE_SPECIAL_CHARS);

    // Collect Colors
    $colors = [
        'school_name' => $_POST['color_school_name'] ?? '#FFFFFF',
        'school_address' => $_POST['color_school_address'] ?? '#FFFFFF',
        'school_contacts' => $_POST['color_school_contacts'] ?? '#FFFFFF',
        'student_name' => $_POST['color_student_name'] ?? '#FFFFFF',
        'details_title' => $_POST['color_details_title'] ?? '#0B3C5D',
        'details_data' => $_POST['color_details_data'] ?? '#333333',
        'student_address_title' => $_POST['color_student_address_title'] ?? '#FFFFFF',
        'student_address_data' => $_POST['color_student_address_data'] ?? '#FFFFFF',
    ];
    $colors_json = json_encode($colors);

    // 2. Handle Image Upload (If exists)
    if (isset($_FILES['id_card_bg_image']) && $_FILES['id_card_bg_image']['error'] === UPLOAD_ERR_OK) {
        
        $file = $_FILES['id_card_bg_image'];
        $maxSize = 5 * 1024 * 1024; // 5MB

        // A. Size Check
        if ($file['size'] > $maxSize) {
            throw new Exception("Image size exceeds 5MB limit.");
        }

        // B. Integrity and Type Check
        $imageInfo = getimagesize($file['tmp_name']);
        if ($imageInfo === false) {
            throw new Exception("Uploaded file is not a valid image.");
        }

        // C. Ratio Check (11:17 for 55mm:85mm)
        $width = $imageInfo[0];
        $height = $imageInfo[1];
        
        // Target ratio 11/17 approx 0.647
        $targetRatio = 11 / 17; 
        $currentRatio = $width / $height;
        
        // Allow small tolerance (e.g., 0.02)
        if (abs($currentRatio - $targetRatio) > 0.02) {
            throw new Exception("Image dimensions do not match the 55mm x 85mm (11:17) ratio. Please crop your image.");
        }

        // D. Prepare Directory
        $image_upload_dir = __DIR__ . "/../../../../uploads/school/student-id-cards-bg/";
        if (!file_exists($image_upload_dir)) {
            mkdir($image_upload_dir, 0777, true);
        }

        // E. Convert to JPG and Save
        // We save it as the template name (e.g., design-1.jpg)
        $targetFile = $image_upload_dir . $layout . ".jpg";
        
        $srcImage = null;
        switch ($imageInfo[2]) {
            case IMAGETYPE_JPEG:
                $srcImage = imagecreatefromjpeg($file['tmp_name']);
                break;
            case IMAGETYPE_PNG:
                $srcImage = imagecreatefrompng($file['tmp_name']);
                break;
            case IMAGETYPE_WEBP:
                $srcImage = imagecreatefromwebp($file['tmp_name']);
                break;
            default:
                throw new Exception("Unsupported image format. Please upload JPG, PNG, or WebP.");
        }

        if (!$srcImage) {
            throw new Exception("Failed to process image data.");
        }

        // Save as JPG with 90% quality
        if (!imagejpeg($srcImage, $targetFile, 90)) {
            // No explicit destroy needed, but we can unset if we want to be explicit before exception
            unset($srcImage); 
            throw new Exception("Failed to save the image to server.");
        }
        
        // No imagedestroy() needed here; PHP 8+ GC handles the GdImage object
    }

    // 3. Database Operation
    // Check if record exists
    $stmt = $pdo->query("SELECT id FROM student_id_card_settings LIMIT 1");
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row) {
        // Update
        $updateSql = "UPDATE student_id_card_settings SET 
            template = :template, 
            school_address = :addr, 
            school_contacts = :contacts, 
            colors = :colors 
            WHERE id = :id";
        $stmt = $pdo->prepare($updateSql);
        $stmt->execute([
            ':template' => $layout,
            ':addr' => $school_address,
            ':contacts' => $school_contacts,
            ':colors' => $colors_json,
            ':id' => $row['id']
        ]);
    } else {
        // Insert
        $insertSql = "INSERT INTO student_id_card_settings (template, school_address, school_contacts, colors) 
            VALUES (:template, :addr, :contacts, :colors)";
        $stmt = $pdo->prepare($insertSql);
        $stmt->execute([
            ':template' => $layout,
            ':addr' => $school_address,
            ':contacts' => $school_contacts,
            ':colors' => $colors_json
        ]);
    }

    echo json_encode(['success' => true, 'message' => 'Settings saved successfully.']);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>