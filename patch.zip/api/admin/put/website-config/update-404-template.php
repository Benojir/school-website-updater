<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is superadmin
if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['404_template'])) {
    try {
        // Validate input
        $template = trim($_POST['404_template']);
        if (empty($template)) {
            throw new Exception('Please select a template');
        }
        
        // Verify template exists
        $templateFile =  __DIR__ . "/../../../../assets/templates/404-pages-templates/{$template}.php";
        if (!file_exists($templateFile)) {
            throw new Exception('Selected template does not exist');
        }
        
        // Update database
        $stmt = $pdo->prepare("UPDATE website_config SET 404_template = ? WHERE id = 1");
        $stmt->execute([$template]);
        
        echo json_encode([
            'success' => true,
            'message' => 'Page template updated successfully!'
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request'
    ]);
}