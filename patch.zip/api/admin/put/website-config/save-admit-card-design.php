<?php
define('ID_CARD_AUDIENCE', 'admit');
require __DIR__ . '/save-student-id-card-design.php';
