<?php
require_once __DIR__ . '/../../../../includes/auth-check.php';
require_once __DIR__ . '/../../../../includes/r2-settings.php';
header('Content-Type: application/json');
try {
    schoolR2RequireConfigRequest();
    schoolR2TestConfig(schoolR2SubmittedConfig($_POST, $websiteConfig ?: []));
    echo json_encode(['success' => true, 'message' => 'R2 upload, read and delete succeeded.']);
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
