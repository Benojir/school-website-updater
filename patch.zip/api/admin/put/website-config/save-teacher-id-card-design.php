<?php
// Trusted server-side audience: no request parameter can select another library.
define('ID_CARD_AUDIENCE', 'teacher');
require __DIR__ . '/save-student-id-card-design.php';
