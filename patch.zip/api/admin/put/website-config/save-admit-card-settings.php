<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");

// Response array
$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Collect form data
        $admit_card_design = $_POST['admit_card_design'] ?? 'design-1';
        $school_address    = $_POST['school_address'] ?? '';
        $school_contact    = $_POST['school_contact'] ?? '';
        $instructions      = $_POST['admit_instructions'] ?? ''; 

        // --- Background Image Upload Logic ---
        if (isset($_FILES['background_image']) && $_FILES['background_image']['error'] === UPLOAD_ERR_OK) {
            $tmp_name = $_FILES['background_image']['tmp_name'];
            $file_size = $_FILES['background_image']['size'];
            $max_size = 2 * 1024 * 1024; // 2 MB limit

            // Size validation
            if ($file_size > $max_size) {
                throw new Exception("Image size must not exceed 2 MB.");
            }

            // Image file validation
            if (!isValidImageFile($tmp_name)) {
                throw new Exception("Invalid file format! Please upload a valid image file.");
            }

            // Create folder path
            $upload_dir = __DIR__ . "/../../../../uploads/school/admit-card-bg/";
            
            // Create folder if not exists
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            $target_file = $upload_dir . "admit-card-bg.jpg";

            // Move file to target directory
            if (!move_uploaded_file($tmp_name, $target_file)) {
                throw new Exception("Failed to upload background image.");
            }
        }
        // --- Background Image Upload Logic Ends ---

        // Create colors array and convert to JSON
        $colors = [
            'primary'        => $_POST['theme_color_primary'] ?? '#3a4a6d',
            'dark'           => $_POST['theme_color_dark'] ?? '#2b3a5a',
            'light'          => $_POST['theme_color_light'] ?? '#F0F5FF',
            'background'     => $_POST['background_color'] ?? '#FFFFFF',
            'school_name'    => $_POST['school_name_color'] ?? '#EFF0F2',
            'school_address' => $_POST['school_address_color'] ?? '#333333'
        ];
        
        $colors_json = json_encode($colors);

        // Database transaction start
        $pdo->beginTransaction();

        // 1. Reset table (Using DELETE instead of TRUNCATE to avoid implicit commit)
        $pdo->exec("DELETE FROM settings_admit_card");

        // 2. Insert new data
        $stmt = $pdo->prepare("INSERT INTO settings_admit_card 
            (admit_card_design, colors, school_address, school_contact, instructions) 
            VALUES (:admit_card_design, :colors, :school_address, :school_contact, :instructions)");

        $stmt->execute([
            ':admit_card_design' => $admit_card_design,
            ':colors'            => $colors_json,
            ':school_address'    => $school_address,
            ':school_contact'    => $school_contact,
            ':instructions'      => $instructions
        ]);

        // Save transaction
        $pdo->commit();

        $response['success'] = true;
        $response['message'] = 'Admit card settings saved successfully!';

    } catch (Exception $e) {
        // Rollback on error
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $response['message'] = $e->getMessage();
    }
} else {
    $response['message'] = 'Invalid Request Method.';
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>