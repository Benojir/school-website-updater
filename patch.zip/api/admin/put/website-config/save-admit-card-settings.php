<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");
require_once __DIR__ . '/../../../../includes/id-card-template-security.php';
header('Content-Type: application/json');

if (!hasPermission(PERM_MANAGE_EXAMS)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

// Response array
$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $csrf = $_POST['csrf_token'] ?? '';
        if (!is_string($csrf) || !hash_equals(idCardTemplateCsrfToken('admit-settings'), $csrf)) {
            http_response_code(403);
            throw new InvalidArgumentException('Your form expired. Refresh the page before saving.');
        }
        // Collect form data
        $admit_card_design = $_POST['admit_card_design'] ?? 'design-1';
        $default_renderer = $_POST['default_renderer'] ?? 'classic';
        if (!in_array($admit_card_design, ['design-1', 'design-2'], true)
            || !in_array($default_renderer, ['classic', 'builder'], true)) {
            throw new InvalidArgumentException('Choose a valid admit card design and download method.');
        }
        $school_address    = $_POST['school_address'] ?? '';
        $school_contact    = $_POST['school_contact'] ?? '';
        $instructions      = $_POST['admit_instructions'] ?? ''; 

        // --- Background Image Upload Logic ---
        if (isset($_FILES['background_image']) && $_FILES['background_image']['error'] === UPLOAD_ERR_OK) {
            $tmp_name = $_FILES['background_image']['tmp_name'];
            $file_size = $_FILES['background_image']['size'];
            $max_size = 2 * 1024 * 1024; // 2 MB limit

            // Size validation
            if ($file_size > $max_size) {
                throw new Exception("Image size must not exceed 2 MB.");
            }

            // Image file validation
            if (!isValidImageFile($tmp_name)) {
                throw new Exception("Invalid file format! Please upload a valid image file.");
            }

            // Create folder path
            $upload_dir = __DIR__ . "/../../../../uploads/school/admit-card-bg/";
            
            // Create folder if not exists
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            $target_file = $upload_dir . "admit-card-bg.jpg";

            // Move file to target directory
            if (!move_uploaded_file($tmp_name, $target_file)) {
                throw new Exception("Failed to upload background image.");
            }
        }
        // --- Background Image Upload Logic Ends ---

        // Create colors array and convert to JSON
        $colors = [
            'primary'        => $_POST['theme_color_primary'] ?? '#3a4a6d',
            'dark'           => $_POST['theme_color_dark'] ?? '#2b3a5a',
            'light'          => $_POST['theme_color_light'] ?? '#F0F5FF',
            'background'     => $_POST['background_color'] ?? '#FFFFFF',
            'school_name'    => $_POST['school_name_color'] ?? '#EFF0F2',
            'school_address' => $_POST['school_address_color'] ?? '#333333'
        ];
        
        $colors_json = json_encode($colors);

        // Database transaction start
        $pdo->beginTransaction();

        if ($default_renderer === 'builder') {
            $active = $pdo->query('SELECT id FROM admit_card_templates WHERE is_active = 1 ORDER BY id LIMIT 1 FOR UPDATE')->fetch(PDO::FETCH_ASSOC);
            if (!$active) throw new InvalidArgumentException('Save a design in the Admit Card Builder and choose “Use for printing” first.');
        }

        // 1. Reset table (Using DELETE instead of TRUNCATE to avoid implicit commit)
        $pdo->exec("DELETE FROM settings_admit_card");

        // 2. Insert new data
        $stmt = $pdo->prepare("INSERT INTO settings_admit_card 
            (admit_card_design, default_renderer, colors, school_address, school_contact, instructions)
            VALUES (:admit_card_design, :default_renderer, :colors, :school_address, :school_contact, :instructions)");

        $stmt->execute([
            ':admit_card_design' => $admit_card_design,
            ':default_renderer' => $default_renderer,
            ':colors'            => $colors_json,
            ':school_address'    => $school_address,
            ':school_contact'    => $school_contact,
            ':instructions'      => $instructions
        ]);

        // Save transaction
        $pdo->commit();

        $response['success'] = true;
        $response['message'] = 'Admit card settings saved successfully!';

    } catch (Exception $e) {
        // Rollback on error
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $response['message'] = $e instanceof PDOException
            ? 'Could not save admit card settings. Ensure the admit card migration in migrate.sql has been manually applied, then try again.'
            : $e->getMessage();
    }
} else {
    $response['message'] = 'Invalid Request Method.';
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
