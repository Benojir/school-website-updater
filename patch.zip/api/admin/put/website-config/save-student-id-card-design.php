<?php
/**
 * save-student-id-card-design.php
 * -----------------------------------------------------------------
 * Saves the design JSON from Fabric.js's canvas.toJSON() into the DB.
 * This endpoint receives a raw JSON body (sent via fetch()), not $_POST —
 * so it needs to be read from php://input.
 *
 * A card can be single-sided or double-sided:
 *  - design_json       = the FRONT side (always required)
 *  - back_design_json  = the BACK side (only used when has_back = 1)
 *
 * Card size lives in canvas_width/canvas_height (pixels). The builder works at
 * a fixed 10 px per mm, so the physical size in millimetres is simply px / 10 —
 * there's deliberately no separate mm column to drift out of sync with these.
 */
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Card size guard rails, in pixels (the builder's scale is 10 px per mm, so
// this is 20mm–300mm per side). Keeps a typo in the mm input from producing a
// multi-thousand-pixel canvas that would hang the browser at render time.
const CARD_MIN_PX = 200;
const CARD_MAX_PX = 3000;

if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

try {
    // 1. Read and decode the raw JSON body
    $raw = file_get_contents('php://input');
    $payload = json_decode($raw, true);

    if (json_last_error() !== JSON_ERROR_NONE || !is_array($payload)) {
        throw new Exception('Invalid JSON payload.');
    }

    $template_name = $payload['template_name'] ?? 'design-1';
    $canvas_width  = (int)($payload['canvas_width'] ?? 550);
    $canvas_height = (int)($payload['canvas_height'] ?? 850);
    $design_json   = $payload['design_json'] ?? null;
    $has_back      = !empty($payload['has_back']) ? 1 : 0;
    $back_design_json = $payload['back_design_json'] ?? null;

    if (!$design_json || empty($design_json['objects'])) {
        throw new Exception('Front side is empty — please add at least one element.');
    }

    // A card marked double-sided must actually have a back design, otherwise
    // the batch generator would print blank white backs for every student.
    if ($has_back && (!$back_design_json || empty($back_design_json['objects']))) {
        throw new Exception('Back side is empty — add at least one element to it, or switch Sides back to "Front only".');
    }

    // 2. Sanity check: keep template_name injection-proof (it's also used in file/directory names)
    if (!preg_match('/^[a-zA-Z0-9\-_]+$/', $template_name)) {
        throw new Exception('Invalid template name.');
    }

    // 3. Card size sanity check
    if (
        $canvas_width < CARD_MIN_PX || $canvas_width > CARD_MAX_PX ||
        $canvas_height < CARD_MIN_PX || $canvas_height > CARD_MAX_PX
    ) {
        throw new Exception(sprintf(
            'Card size must be between %.0fmm and %.0fmm on each side.',
            CARD_MIN_PX / 10,
            CARD_MAX_PX / 10
        ));
    }

    // 4. Re-encode and store (compact form). The back design is kept even when
    // has_back = 0, so toggling Sides off and on again doesn't lose the work —
    // has_back alone decides whether it gets printed.
    $design_json_str = json_encode($design_json);
    $back_design_json_str = (is_array($back_design_json) && !empty($back_design_json['objects']))
        ? json_encode($back_design_json)
        : null;

    // 5. Upsert — only one active row is kept per template name for a school
    $stmt = $pdo->prepare("SELECT id FROM student_id_card_templates WHERE template_name = :name LIMIT 1");
    $stmt->execute([':name' => $template_name]);
    $existing = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing) {
        $stmt = $pdo->prepare("UPDATE student_id_card_templates
            SET design_json = :design, back_design_json = :back_design, has_back = :has_back,
                canvas_width = :w, canvas_height = :h, updated_at = NOW()
            WHERE id = :id");
        $stmt->execute([
            ':design' => $design_json_str,
            ':back_design' => $back_design_json_str,
            ':has_back' => $has_back,
            ':w' => $canvas_width,
            ':h' => $canvas_height,
            ':id' => $existing['id']
        ]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO student_id_card_templates
            (template_name, design_json, back_design_json, has_back, canvas_width, canvas_height, is_active, created_at)
            VALUES (:name, :design, :back_design, :has_back, :w, :h, 1, NOW())");
        $stmt->execute([
            ':name' => $template_name,
            ':design' => $design_json_str,
            ':back_design' => $back_design_json_str,
            ':has_back' => $has_back,
            ':w' => $canvas_width,
            ':h' => $canvas_height
        ]);
    }

    echo json_encode(['success' => true, 'message' => 'Design saved successfully.']);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

/*
-------------------------------------------------------------------
Suggested table structure:

CREATE TABLE student_id_card_templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    template_name VARCHAR(100) NOT NULL UNIQUE,
    design_json LONGTEXT NOT NULL,      -- FRONT side: result of fabric canvas.toJSON()
    has_back TINYINT(1) NOT NULL DEFAULT 0,
    back_design_json LONGTEXT NULL,     -- BACK side: same format, only printed when has_back = 1
    canvas_width INT NOT NULL DEFAULT 550,   -- px; physical mm = px / 10
    canvas_height INT NOT NULL DEFAULT 850,  -- px; physical mm = px / 10
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL
);
-------------------------------------------------------------------
*/