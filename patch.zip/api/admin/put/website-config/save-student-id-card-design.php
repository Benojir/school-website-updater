<?php
/**
 * save-student-id-card-design.php
 * -----------------------------------------------------------------
 * Saves the design JSON from Fabric.js's canvas.toJSON() into the DB.
 * This endpoint receives a raw JSON body (sent via fetch()), not $_POST —
 * so it needs to be read from php://input.
 */
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

try {
    // 1. Read and decode the raw JSON body
    $raw = file_get_contents('php://input');
    $payload = json_decode($raw, true);

    if (json_last_error() !== JSON_ERROR_NONE || !is_array($payload)) {
        throw new Exception('Invalid JSON payload.');
    }

    $template_name = $payload['template_name'] ?? 'design-1';
    $canvas_width  = (int)($payload['canvas_width'] ?? 550);
    $canvas_height = (int)($payload['canvas_height'] ?? 850);
    $design_json   = $payload['design_json'] ?? null;

    if (!$design_json || empty($design_json['objects'])) {
        throw new Exception('Design is empty — please add at least one element.');
    }

    // 2. Sanity check: keep template_name injection-proof (it's also used in file/directory names)
    if (!preg_match('/^[a-zA-Z0-9\-_]+$/', $template_name)) {
        throw new Exception('Invalid template name.');
    }

    // 3. Re-encode and store (compact form)
    $design_json_str = json_encode($design_json);

    // 4. Upsert — only one active row is kept per template name for a school
    $stmt = $pdo->prepare("SELECT id FROM student_id_card_templates WHERE template_name = :name LIMIT 1");
    $stmt->execute([':name' => $template_name]);
    $existing = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existing) {
        $stmt = $pdo->prepare("UPDATE student_id_card_templates
            SET design_json = :design, canvas_width = :w, canvas_height = :h, updated_at = NOW()
            WHERE id = :id");
        $stmt->execute([
            ':design' => $design_json_str,
            ':w' => $canvas_width,
            ':h' => $canvas_height,
            ':id' => $existing['id']
        ]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO student_id_card_templates
            (template_name, design_json, canvas_width, canvas_height, is_active, created_at)
            VALUES (:name, :design, :w, :h, 1, NOW())");
        $stmt->execute([
            ':name' => $template_name,
            ':design' => $design_json_str,
            ':w' => $canvas_width,
            ':h' => $canvas_height
        ]);
    }

    echo json_encode(['success' => true, 'message' => 'Design saved successfully.']);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

/*
-------------------------------------------------------------------
Suggested table structure:

CREATE TABLE student_id_card_templates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    template_name VARCHAR(100) NOT NULL UNIQUE,
    design_json LONGTEXT NOT NULL,      -- result of fabric canvas.toJSON()
    canvas_width INT NOT NULL DEFAULT 550,
    canvas_height INT NOT NULL DEFAULT 850,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL
);
-------------------------------------------------------------------
*/