<?php
// Named templates for the Fabric editor. GET reads; JSON POST saves or activates.
include_once(__DIR__ . '/../../../../includes/auth-check.php');
require_once(__DIR__ . '/../../../../includes/id-card-template-security.php');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
const CARD_MIN_PX = 200;
const CARD_MAX_PX = 3000;
$is_teacher_id_card = defined('ID_CARD_AUDIENCE') && ID_CARD_AUDIENCE === 'teacher';
$is_driver_id_card = defined('ID_CARD_AUDIENCE') && ID_CARD_AUDIENCE === 'driver';
$csrfAudience = $is_driver_id_card ? 'driver' : ($is_teacher_id_card ? 'teacher' : 'student');
define('ID_CARD_TEMPLATE_TABLE', $csrfAudience . '_id_card_templates');
if (!hasPermission(PERM_MANAGE_ID_CARDS) || ($is_teacher_id_card && !hasPermission(PERM_MANAGE_TEACHERS)) || ($is_driver_id_card && !hasPermission(PERM_MANAGE_TRANSPORT))) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}
function idCardTemplateList($pdo): array
{
    return $pdo->query('SELECT id, template_name, is_active FROM ' . ID_CARD_TEMPLATE_TABLE . ' ORDER BY template_name, id')->fetchAll(PDO::FETCH_ASSOC);
}
$errorCode = null;
try {
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if ($method === 'GET') {
        if (($_GET['action'] ?? '') === 'csrf') {
            echo json_encode(['success' => true, 'csrf_token' => idCardTemplateCsrfToken($csrfAudience)]);
            exit;
        }
        $id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);
        if ($id === false || $id < 0) throw new InvalidArgumentException('Invalid template ID.');
        $template = null;
        if ($id) {
            $stmt = $pdo->prepare('SELECT * FROM ' . ID_CARD_TEMPLATE_TABLE . ' WHERE id = :id');
            $stmt->execute([':id' => $id]);
            $template = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$template) throw new InvalidArgumentException('Template no longer exists.');
            $template['design_json'] = json_decode($template['design_json'], true, 512, JSON_THROW_ON_ERROR);
            $template['back_design_json'] = $template['back_design_json'] ? json_decode($template['back_design_json'], true, 512, JSON_THROW_ON_ERROR) : null;
        }
        echo json_encode(['success' => true, 'templates' => idCardTemplateList($pdo), 'template' => $template]);
        exit;
    }
    if ($method !== 'POST') {
        http_response_code(405);
        header('Allow: GET, POST');
        throw new RuntimeException('Method not allowed.');
    }
    if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== 0) throw new InvalidArgumentException('A JSON request is required.');
    $payload = json_decode(file_get_contents('php://input'), true, 512, JSON_THROW_ON_ERROR);
    if (!is_array($payload)) throw new InvalidArgumentException('Invalid JSON payload.');
    // JSON fallback also handles hosts/proxies that strip custom request headers.
    $csrf = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($payload['csrf_token'] ?? '');
    if (!is_string($csrf) || !hash_equals(idCardTemplateCsrfToken($csrfAudience), $csrf)) {
        http_response_code(403);
        $errorCode = 'csrf_expired';
        throw new RuntimeException('Your form expired. Refresh the page before saving.');
    }
    $action = $payload['action'] ?? 'save';
    if (!in_array($action, ['save', 'activate'], true)) throw new InvalidArgumentException('Invalid action.');
    $id = filter_var($payload['template_id'] ?? 0, FILTER_VALIDATE_INT);
    if ($id === false || $id < 0 || ($action === 'activate' && !$id)) throw new InvalidArgumentException('Invalid template ID.');
    if ($action === 'save') {
        $name = $payload['template_name'] ?? '';
        if (!is_string($name)) throw new InvalidArgumentException('A template name is required.');
        $name = trim($name);
        // Display labels, never paths: Bengali and spaces are accepted.
        if ($name === '' || !preg_match('/^[^\\p{C}]{1,100}$/u', $name)) throw new InvalidArgumentException('Enter a template name of 1–100 characters.');
        $width = filter_var($payload['canvas_width'] ?? 550, FILTER_VALIDATE_INT);
        $height = filter_var($payload['canvas_height'] ?? 850, FILTER_VALIDATE_INT);
        if ($width < CARD_MIN_PX || $width > CARD_MAX_PX || $height < CARD_MIN_PX || $height > CARD_MAX_PX) throw new InvalidArgumentException('Card size must be between 20mm and 300mm on each side.');
        $front = $payload['design_json'] ?? null;
        $back = $payload['back_design_json'] ?? null;
        $hasBack = !empty($payload['has_back']) ? 1 : 0;
        if (!is_array($front) || !isset($front['objects']) || !is_array($front['objects']) || !$front['objects']) throw new InvalidArgumentException('Front side is empty — add at least one element.');
        if ($back !== null && (!is_array($back) || !isset($back['objects']) || !is_array($back['objects']))) throw new InvalidArgumentException('Invalid back design.');
        if ($hasBack && empty($back['objects'])) throw new InvalidArgumentException('Back side is empty.');
        $frontJson = json_encode($front, JSON_THROW_ON_ERROR);
        $backJson = !empty($back['objects']) ? json_encode($back, JSON_THROW_ON_ERROR) : null;
    }
    $pdo->beginTransaction();
    // Serialize library changes so saving and activation cannot interleave.
    $rows = $pdo->query('SELECT id, is_active FROM ' . ID_CARD_TEMPLATE_TABLE . ' ORDER BY id FOR UPDATE')->fetchAll(PDO::FETCH_ASSOC);
    $ids = array_map('intval', array_column($rows, 'id'));
    if ($id && !in_array($id, $ids, true)) throw new InvalidArgumentException('Template no longer exists.');
    $activeRows = array_values(array_filter($rows, static fn($row) => !empty($row['is_active'])));
    $activeId = $activeRows ? (int)$activeRows[0]['id'] : 0;
    if ($action === 'activate') {
        $activeId = $id;
    } else {
        $stmt = $pdo->prepare('SELECT id FROM ' . ID_CARD_TEMPLATE_TABLE . ' WHERE template_name = :name AND id <> :id LIMIT 1');
        $stmt->execute([':name' => $name, ':id' => $id]);
        if ($stmt->fetch(PDO::FETCH_ASSOC)) throw new InvalidArgumentException('That name is already used. Choose another name or open that template to edit it.');
        $params = [':name' => $name, ':design' => $frontJson, ':back_design' => $backJson, ':has_back' => $hasBack, ':w' => $width, ':h' => $height];
        if ($id) {
            $stmt = $pdo->prepare('UPDATE ' . ID_CARD_TEMPLATE_TABLE . ' SET template_name = :name, design_json = :design,
                back_design_json = :back_design, has_back = :has_back, canvas_width = :w, canvas_height = :h, updated_at = NOW() WHERE id = :id');
            $params[':id'] = $id;
        } else {
            $stmt = $pdo->prepare('INSERT INTO ' . ID_CARD_TEMPLATE_TABLE . '
                (template_name, design_json, back_design_json, has_back, canvas_width, canvas_height, is_active, created_at)
                VALUES (:name, :design, :back_design, :has_back, :w, :h, 0, NOW())');
        }
        $stmt->execute($params);
        if (!$id) $id = (int)$pdo->lastInsertId();
        if (!$activeId) $activeId = $id;
    }
    // One active template; also normalizes libraries saved by the old endpoint.
    $stmt = $pdo->prepare('UPDATE ' . ID_CARD_TEMPLATE_TABLE . ' SET is_active = CASE WHEN id = :id THEN 1 ELSE 0 END');
    $stmt->execute([':id' => $activeId]);
    $templates = idCardTemplateList($pdo);
    $pdo->commit();
    echo json_encode(['success' => true, 'message' => $action === 'activate' ? 'Template selected for printing.' : 'Template saved successfully.',
        'template_id' => $id, 'templates' => $templates]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    if ($e instanceof PDOException) {
        http_response_code(500);
        $message = 'Could not save the template. Please retry; template names must be unique.';
    } else {
        if (http_response_code() < 400) http_response_code(400);
        $message = $e instanceof JsonException ? 'Invalid design JSON.' : $e->getMessage();
    }
    echo json_encode(['success' => false, 'message' => $message, 'code' => $errorCode]);
}
