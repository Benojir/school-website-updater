<?php
define('ID_CARD_AUDIENCE', 'admission');
require __DIR__ . '/save-student-id-card-design.php';
