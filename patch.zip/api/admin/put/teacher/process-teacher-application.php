<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");
include_once(__DIR__ . "/../../../../includes/phpmailer.php");

header('Content-Type: application/json');

// Check permission
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

// Validate input parameters
if (
    !isset($_REQUEST['application_id'], $_REQUEST['action']) ||
    empty(trim($_REQUEST['application_id'])) ||
    empty(trim($_REQUEST['action']))
) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid request. Required parameters missing.']);
    exit;
}

$application_id = trim($_REQUEST['application_id']);
$action = strtolower(trim($_REQUEST['action']));
$allowed_actions = ['delete', 'reject', 'approve'];

// Validate action
if (!in_array($action, $allowed_actions)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid action specified.']);
    exit;
}

$table = "teacher_applications";

try {
    // Fetch application details
    $stmt = $pdo->prepare("SELECT * FROM `$table` WHERE id = ?");
    $stmt->execute([$application_id]);
    $application = $stmt->fetch(PDO::FETCH_ASSOC);

    // Validate application exists
    if (!$application) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Teacher application not found.']);
        exit;
    }

    // Handle different actions
    switch ($action) {
        case 'delete':
            handleDelete($pdo, $table, $application_id);
            break;
        case 'reject':
            handleReject($pdo, $table, $application_id, $application);
            break;
        case 'approve':
            handleApprove($pdo, $table, $application_id, $application);
            break;
    }
} catch (PDOException $e) {
    error_log("Database error in teacher application handler: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error occurred.']);
} catch (Exception $e) {
    error_log("General error in teacher application handler: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'An unexpected error occurred.']);
}

/**
 * Handle delete action
 */
function handleDelete($pdo, $table, $application_id)
{
    // CLean image from storage
    $stmt = $pdo->prepare("SELECT applicant_image FROM `$table` WHERE id = ?");
    $stmt->execute([$application_id]);
    $imageRow = $stmt->fetch(PDO::FETCH_ASSOC);
    $imageName = $imageRow['applicant_image'] ?? null;

    if ($imageName !== null && $imageName !== 'default_teacher_dp.jpg') {
        $imagePath =  __DIR__ . '/../../../../uploads/teachers/' . $imageName;
        if (file_exists($imagePath)) {
            @unlink($imagePath);
        }
    }

    $stmt = $pdo->prepare("DELETE FROM `$table` WHERE id = ?");

    if ($stmt->execute([$application_id])) {
        echo json_encode(['success' => true, 'message' => 'Application deleted successfully.']);
    } else {
        throw new Exception('Failed to delete application');
    }
}

/**
 * Handle reject action
 */
function handleReject($pdo, $table, $application_id, $application)
{
    global $school_name;

    // CLean image from storage
    $stmt = $pdo->prepare("SELECT applicant_image FROM `$table` WHERE id = ?");
    $stmt->execute([$application_id]);
    $imageRow = $stmt->fetch(PDO::FETCH_ASSOC);
    $imageName = $imageRow['applicant_image'] ?? null;

    if ($imageName !== null && $imageName !== 'default_teacher_dp.jpg') {
        $imagePath =  __DIR__ . '/../../../../uploads/teachers/' . $imageName;
        if (file_exists($imagePath)) {
            @unlink($imagePath);
        }
    }

    // Send rejection email
    sendRejectionEmail($application, $school_name);

    // Delete application after sending email
    $stmt = $pdo->prepare("DELETE FROM `$table` WHERE id = ?");

    if ($stmt->execute([$application_id])) {
        echo json_encode(['success' => true, 'message' => 'Application rejected and notification sent successfully.']);
    } else {
        throw new Exception('Failed to reject application');
    }
}

/**
 * Handle approve action
 */
function handleApprove($pdo, $table, $application_id, $application)
{
    global $school_name;

    // Begin transaction
    $pdo->beginTransaction();

    try {
        // Generate unique teacher ID
        $teacher_id = generateUniqueTeacherId($pdo);

        // Insert into teachers table
        $sql = "INSERT INTO teachers (
            teacher_id, name, email, phone, address, 
            qualification, subject_specialization, joining_date,
            teacher_image, application_date, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, CURDATE(), ?, ?, 'active')";

        $values = [
            $teacher_id,
            $application['name'],
            $application['email'],
            $application['phone_number'],
            $application['address'],
            $application['qualification'],
            $application['specialization'],
            $application['applicant_image'],
            $application['application_date']
        ];

        $stmt = $pdo->prepare($sql);
        $stmt->execute($values);

        // Delete from applications table
        $deleteStmt = $pdo->prepare("DELETE FROM `$table` WHERE id = ?");
        $deleteStmt->execute([$application_id]);

        // Commit transaction
        $pdo->commit();

        // Send approval email
        sendApprovalEmail($application, $teacher_id, $school_name);

        echo json_encode([
            'success' => true,
            'message' => 'Application approved successfully. Teacher added and notification sent.',
            'teacher_id' => $teacher_id
        ]);
    } catch (Exception $e) {
        // Rollback transaction on error
        $pdo->rollback();
        throw $e;
    }
}

/**
 * Generate unique teacher ID
 */
function generateUniqueTeacherId($pdo)
{
    $prefix = "TCH";
    $maxAttempts = 10;

    for ($i = 0; $i < $maxAttempts; $i++) {
        $randomNumber = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
        $teacher_id = $prefix . $randomNumber;

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM teachers WHERE teacher_id = ?");
        $stmt->execute([$teacher_id]);

        if ($stmt->fetchColumn() == 0) {
            return $teacher_id;
        }
    }

    throw new Exception("Failed to generate unique teacher ID after $maxAttempts attempts");
}

/**
 * Send rejection email
 */
function sendRejectionEmail($application, $school_name)
{
    $recipientName = safe_htmlspecialchars($application['name']);
    $recipientEmail = $application['email'];
    $senderName = $school_name;
    $subject = 'Teaching Application Status - ' . $school_name;

    $htmlBody = generateRejectionEmailHTML($recipientName, $school_name, $senderName);
    $altBody = generateRejectionEmailText($recipientName, $school_name, $senderName);

    sendMail($senderName, $recipientEmail, $recipientName, $subject, $htmlBody, $altBody);
}

/**
 * Send approval email
 */
function sendApprovalEmail($application, $teacher_id, $school_name)
{
    $recipientName = safe_htmlspecialchars($application['name']);
    $recipientEmail = $application['email'];
    $senderName = $school_name;
    $subject = 'Application Approved - Welcome to ' . $school_name;

    $htmlBody = generateApprovalEmailHTML($recipientName, $teacher_id, $school_name, $senderName);
    $altBody = generateApprovalEmailText($recipientName, $teacher_id, $school_name, $senderName);

    sendMail($senderName, $recipientEmail, $recipientName, $subject, $htmlBody, $altBody);
}

/**
 * Generate rejection email HTML
 */
function generateRejectionEmailHTML($recipientName, $school_name, $senderName)
{
    return '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Teaching Application Status</title>
    </head>
    <body style="font-family: Arial, sans-serif; background-color: #f8f9fa; color: #333; padding: 20px; margin: 0;">
        <div style="max-width: 600px; margin: auto; background-color: #fff; border-left: 6px solid #dc3545; box-shadow: 0 4px 6px rgba(0,0,0,0.1); border-radius: 8px; overflow: hidden;">
            <div style="background-color: #dc3545; color: white; padding: 20px; text-align: center;">
                <h2 style="margin: 0; font-size: 24px;">Application Status Update</h2>
            </div>
            <div style="padding: 30px; line-height: 1.6;">
                <p style="margin-bottom: 20px;">Dear <strong>' . $recipientName . '</strong>,</p>
                
                <p style="margin-bottom: 20px;">Thank you for your interest in joining the teaching staff at <strong>' . safe_htmlspecialchars($school_name) . '</strong>.</p>
                
                <p style="margin-bottom: 20px;">After careful consideration of your application, we regret to inform you that we are unable to offer you a teaching position at this time.</p>
                
                <p style="margin-bottom: 20px;">This decision was made based on our current staffing needs and the qualifications of all applicants. We appreciate the time and effort you put into your application.</p>
                
                <p style="margin-bottom: 20px;">We encourage you to apply for future openings that may better match your qualifications and experience.</p>
                
                <p style="margin-bottom: 30px;">We wish you all the best in your professional endeavors.</p>
                
                <p style="margin-bottom: 5px;">Sincerely,</p>
                <p style="margin-bottom: 0;"><strong>' . safe_htmlspecialchars($senderName) . ' Hiring Committee</strong></p>
            </div>
            <div style="background-color: #f8d7da; text-align: center; padding: 15px; font-size: 12px; color: #721c24;">
                This is an automated message. Please do not reply directly to this email.
            </div>
        </div>
    </body>
    </html>';
}

/**
 * Generate approval email HTML
 */
function generateApprovalEmailHTML($recipientName, $teacher_id, $school_name, $senderName)
{
    return '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Teaching Application Approved</title>
    </head>
    <body style="font-family: Arial, sans-serif; background-color: #f8f9fa; color: #333; padding: 20px; margin: 0;">
        <div style="max-width: 600px; margin: auto; background-color: #fff; border-left: 6px solid #28a745; box-shadow: 0 4px 6px rgba(0,0,0,0.1); border-radius: 8px; overflow: hidden;">
            <div style="background-color: #28a745; color: white; padding: 20px; text-align: center;">
                <h2 style="margin: 0; font-size: 24px;">🎉 Congratulations! Application Approved</h2>
            </div>
            <div style="padding: 30px; line-height: 1.6;">
                <p style="margin-bottom: 20px;">Dear <strong>' . $recipientName . '</strong>,</p>
                
                <p style="margin-bottom: 20px;">We are pleased to inform you that your application to join the teaching staff at <strong>' . safe_htmlspecialchars($school_name) . '</strong> has been <strong style="color: #28a745;">APPROVED</strong>!</p>
                
                <div style="background-color: #d4edda; padding: 20px; border-radius: 6px; margin: 20px 0; border: 1px solid #c3e6cb;">
                    <p style="margin: 0; font-size: 16px;"><strong>Your Teacher ID: ' . safe_htmlspecialchars($teacher_id) . '</strong></p>
                </div>
                
                <p style="margin-bottom: 20px;">Welcome to our teaching team! We are excited to have you join our faculty.</p>
                
                <p style="margin-bottom: 20px;"><strong>Next Steps:</strong></p>
                <ol style="margin-bottom: 20px; padding-left: 20px;">
                    <li style="margin-bottom: 10px;">Please save your Teacher ID for future reference</li>
                    <li style="margin-bottom: 10px;">Complete the onboarding process by visiting our administration office</li>
                    <li style="margin-bottom: 10px;">Submit any remaining documentation if required</li>
                    <li style="margin-bottom: 10px;">Attend the faculty orientation (details will follow)</li>
                </ol>
                
                <p style="margin-bottom: 20px;">If you have any questions or need assistance, please contact our administration office.</p>
                
                <p style="margin-bottom: 30px;">Once again, congratulations and welcome to <strong>' . safe_htmlspecialchars($school_name) . '</strong>!</p>
                
                <p style="margin-bottom: 5px;">Best regards,</p>
                <p style="margin-bottom: 0;"><strong>' . safe_htmlspecialchars($senderName) . ' Hiring Committee</strong></p>
            </div>
            <div style="background-color: #d1ecf1; text-align: center; padding: 15px; font-size: 12px; color: #0c5460;">
                This is an automated message. Please do not reply directly to this email.
            </div>
        </div>
    </body>
    </html>';
}

/**
 * Generate rejection email plain text
 */
function generateRejectionEmailText($recipientName, $school_name, $senderName)
{
    return "Dear $recipientName,

Thank you for your interest in joining the teaching staff at $school_name.

After careful consideration of your application, we regret to inform you that we are unable to offer you a teaching position at this time.

This decision was made based on our current staffing needs and the qualifications of all applicants. We appreciate the time and effort you put into your application.

We encourage you to apply for future openings that may better match your qualifications.

We wish you all the best in your professional endeavors.

Sincerely,
$senderName Hiring Committee

---
This is an automated message. Please do not reply directly to this email.";
}

/**
 * Generate approval email plain text
 */
function generateApprovalEmailText($recipientName, $teacher_id, $school_name, $senderName)
{
    return "Dear $recipientName,

Congratulations! Your application to join the teaching staff at $school_name has been APPROVED!

Your Teacher ID: $teacher_id

Welcome to our teaching team! We are excited to have you join our faculty.

Next Steps:
1. Save your Teacher ID for future reference
2. Complete the onboarding process by visiting our administration office  
3. Submit any remaining documentation if required
4. Attend the faculty orientation (details will follow)

If you have any questions, please contact our administration office.

Welcome to $school_name!

Best regards,
$senderName Hiring Committee

---
This is an automated message. Please do not reply directly to this email.";
}
