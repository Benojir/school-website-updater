<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/phpmailer.php");

header('Content-Type: application/json');

// Check permission
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

// Validate input parameters
if (
    !isset($_REQUEST['application_id'], $_REQUEST['action']) ||
    empty(trim($_REQUEST['application_id'])) ||
    empty(trim($_REQUEST['action']))
) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid request. Required parameters missing.']);
    exit;
}

$application_id = (int) trim($_REQUEST['application_id']);
$action = strtolower(trim($_REQUEST['action']));
$allowed_actions = ['delete', 'reject', 'approve', 'archive'];

// Validate action
if (!in_array($action, $allowed_actions)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid action specified.']);
    exit;
}

// Applications live in the teachers table; only these statuses are applications.
// Guarding on them keeps this endpoint from touching real staff records.
$application_statuses = ['pending', 'reject', 'archive'];

try {
    // Fetch application details
    $stmt = $pdo->prepare("SELECT * FROM teachers WHERE id = ?");
    $stmt->execute([$application_id]);
    $application = $stmt->fetch(PDO::FETCH_ASSOC);

    // Validate application exists
    if (!$application) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Teacher application not found.']);
        exit;
    }

    if (!in_array($application['status'], $application_statuses, true)) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'This record is an active staff member, not an application. Manage it from the Teachers list instead.'
        ]);
        exit;
    }

    // Handle different actions
    switch ($action) {
        case 'delete':
            handleDelete($pdo, $application_id, $application);
            break;
        case 'reject':
            handleReject($pdo, $application_id, $application);
            break;
        case 'archive':
            handleArchive($pdo, $application_id);
            break;
        case 'approve':
            handleApprove($pdo, $application_id, $application);
            break;
    }
} catch (PDOException $e) {
    error_log("Database error in teacher application handler: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error occurred.']);
} catch (Exception $e) {
    error_log("General error in teacher application handler: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'An unexpected error occurred.']);
}

/**
 * Handle delete action - removes the record for good
 */
function handleDelete($pdo, $application_id, $application)
{
    // Clean the profile photo from storage. Documents live on ImgBB and are not
    // deletable here, because only their public URL is stored.
    $imageName = $application['teacher_image'] ?? null;

    if ($imageName !== null && $imageName !== 'default_teacher_dp.jpg') {
        $imagePath = __DIR__ . '/../../../../uploads/teachers/' . $imageName;
        if (file_exists($imagePath)) {
            @unlink($imagePath);
        }
    }

    $stmt = $pdo->prepare("DELETE FROM teachers WHERE id = ?");

    if ($stmt->execute([$application_id])) {
        echo json_encode(['success' => true, 'message' => 'Application deleted successfully.']);
    } else {
        throw new Exception('Failed to delete application');
    }
}

/**
 * Handle reject action - keeps the record so the decision stays on file
 */
function handleReject($pdo, $application_id, $application)
{
    global $school_name;

    $stmt = $pdo->prepare("UPDATE teachers SET status = 'reject' WHERE id = ?");

    if (!$stmt->execute([$application_id])) {
        throw new Exception('Failed to reject application');
    }

    // Notify the applicant only when this is a fresh decision
    if ($application['status'] !== 'reject') {
        try {
            sendRejectionEmail($application, $school_name);
        } catch (Exception $e) {
            error_log("Failed to send rejection email: " . $e->getMessage());
        }
    }

    echo json_encode(['success' => true, 'message' => 'Application rejected and notification sent successfully.']);
}

/**
 * Handle archive action - parks the application out of the pending list
 */
function handleArchive($pdo, $application_id)
{
    $stmt = $pdo->prepare("UPDATE teachers SET status = 'archive' WHERE id = ?");

    if ($stmt->execute([$application_id])) {
        echo json_encode(['success' => true, 'message' => 'Application archived successfully.']);
    } else {
        throw new Exception('Failed to archive application');
    }
}

/**
 * Handle approve action - promotes the application to an active teacher
 */
function handleApprove($pdo, $application_id, $application)
{
    global $school_name;

    // The applicant never sets a joining date, so default it to today while
    // leaving an admin-entered date untouched.
    $stmt = $pdo->prepare("
        UPDATE teachers
        SET status = 'active', joining_date = COALESCE(joining_date, CURDATE())
        WHERE id = ?
    ");

    if (!$stmt->execute([$application_id])) {
        throw new Exception('Failed to approve application');
    }

    // Send approval email
    try {
        sendApprovalEmail($application, $application_id, $school_name);
    } catch (Exception $e) {
        error_log("Failed to send approval email: " . $e->getMessage());
    }

    echo json_encode([
        'success' => true,
        'message' => 'Application approved successfully. Teacher activated and notification sent.',
        'teacher_id' => $application_id
    ]);
}

/**
 * Send rejection email
 */
function sendRejectionEmail($application, $school_name)
{
    $recipientName = safe_htmlspecialchars($application['name']);
    $recipientEmail = $application['email'];
    $senderName = $school_name;
    $subject = 'Teaching Application Status - ' . $school_name;

    $htmlBody = generateRejectionEmailHTML($recipientName, $school_name, $senderName);
    $altBody = generateRejectionEmailText($recipientName, $school_name, $senderName);

    sendMail($senderName, $recipientEmail, $recipientName, $subject, $htmlBody, $altBody);
}

/**
 * Send approval email
 */
function sendApprovalEmail($application, $teacher_id, $school_name)
{
    $recipientName = safe_htmlspecialchars($application['name']);
    $recipientEmail = $application['email'];
    $senderName = $school_name;
    $subject = 'Application Approved - Welcome to ' . $school_name;

    $htmlBody = generateApprovalEmailHTML($recipientName, $teacher_id, $school_name, $senderName);
    $altBody = generateApprovalEmailText($recipientName, $teacher_id, $school_name, $senderName);

    sendMail($senderName, $recipientEmail, $recipientName, $subject, $htmlBody, $altBody);
}

/**
 * Generate rejection email HTML
 */
function generateRejectionEmailHTML($recipientName, $school_name, $senderName)
{
    return '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Teaching Application Status</title>
    </head>
    <body style="font-family: Arial, sans-serif; background-color: #f8f9fa; color: #333; padding: 20px; margin: 0;">
        <div style="max-width: 600px; margin: auto; background-color: #fff; border-left: 6px solid #dc3545; box-shadow: 0 4px 6px rgba(0,0,0,0.1); border-radius: 8px; overflow: hidden;">
            <div style="background-color: #dc3545; color: white; padding: 20px; text-align: center;">
                <h2 style="margin: 0; font-size: 24px;">Application Status Update</h2>
            </div>
            <div style="padding: 30px; line-height: 1.6;">
                <p style="margin-bottom: 20px;">Dear <strong>' . $recipientName . '</strong>,</p>

                <p style="margin-bottom: 20px;">Thank you for your interest in joining the teaching staff at <strong>' . safe_htmlspecialchars($school_name) . '</strong>.</p>

                <p style="margin-bottom: 20px;">After careful consideration of your application, we regret to inform you that we are unable to offer you a teaching position at this time.</p>

                <p style="margin-bottom: 20px;">This decision was made based on our current staffing needs and the qualifications of all applicants. We appreciate the time and effort you put into your application.</p>

                <p style="margin-bottom: 20px;">We encourage you to apply for future openings that may better match your qualifications and experience.</p>

                <p style="margin-bottom: 30px;">We wish you all the best in your professional endeavors.</p>

                <p style="margin-bottom: 5px;">Sincerely,</p>
                <p style="margin-bottom: 0;"><strong>' . safe_htmlspecialchars($senderName) . ' Hiring Committee</strong></p>
            </div>
            <div style="background-color: #f8d7da; text-align: center; padding: 15px; font-size: 12px; color: #721c24;">
                This is an automated message. Please do not reply directly to this email.
            </div>
        </div>
    </body>
    </html>';
}

/**
 * Generate approval email HTML
 */
function generateApprovalEmailHTML($recipientName, $teacher_id, $school_name, $senderName)
{
    return '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Teaching Application Approved</title>
    </head>
    <body style="font-family: Arial, sans-serif; background-color: #f8f9fa; color: #333; padding: 20px; margin: 0;">
        <div style="max-width: 600px; margin: auto; background-color: #fff; border-left: 6px solid #28a745; box-shadow: 0 4px 6px rgba(0,0,0,0.1); border-radius: 8px; overflow: hidden;">
            <div style="background-color: #28a745; color: white; padding: 20px; text-align: center;">
                <h2 style="margin: 0; font-size: 24px;">🎉 Congratulations! Application Approved</h2>
            </div>
            <div style="padding: 30px; line-height: 1.6;">
                <p style="margin-bottom: 20px;">Dear <strong>' . $recipientName . '</strong>,</p>

                <p style="margin-bottom: 20px;">We are pleased to inform you that your application to join the teaching staff at <strong>' . safe_htmlspecialchars($school_name) . '</strong> has been <strong style="color: #28a745;">APPROVED</strong>!</p>

                <div style="background-color: #d4edda; padding: 20px; border-radius: 6px; margin: 20px 0; border: 1px solid #c3e6cb;">
                    <p style="margin: 0; font-size: 16px;"><strong>Your Teacher ID: ' . safe_htmlspecialchars($teacher_id) . '</strong></p>
                </div>

                <p style="margin-bottom: 20px;">Welcome to our teaching team! We are excited to have you join our faculty.</p>

                <p style="margin-bottom: 20px;"><strong>Next Steps:</strong></p>
                <ol style="margin-bottom: 20px; padding-left: 20px;">
                    <li style="margin-bottom: 10px;">Please save your Teacher ID for future reference</li>
                    <li style="margin-bottom: 10px;">Complete the onboarding process by visiting our administration office</li>
                    <li style="margin-bottom: 10px;">Submit any remaining documentation if required</li>
                    <li style="margin-bottom: 10px;">Attend the faculty orientation (details will follow)</li>
                </ol>

                <p style="margin-bottom: 20px;">If you have any questions or need assistance, please contact our administration office.</p>

                <p style="margin-bottom: 30px;">Once again, congratulations and welcome to <strong>' . safe_htmlspecialchars($school_name) . '</strong>!</p>

                <p style="margin-bottom: 5px;">Best regards,</p>
                <p style="margin-bottom: 0;"><strong>' . safe_htmlspecialchars($senderName) . ' Hiring Committee</strong></p>
            </div>
            <div style="background-color: #d1ecf1; text-align: center; padding: 15px; font-size: 12px; color: #0c5460;">
                This is an automated message. Please do not reply directly to this email.
            </div>
        </div>
    </body>
    </html>';
}

/**
 * Generate rejection email plain text
 */
function generateRejectionEmailText($recipientName, $school_name, $senderName)
{
    return "Dear $recipientName,

Thank you for your interest in joining the teaching staff at $school_name.

After careful consideration of your application, we regret to inform you that we are unable to offer you a teaching position at this time.

This decision was made based on our current staffing needs and the qualifications of all applicants. We appreciate the time and effort you put into your application.

We encourage you to apply for future openings that may better match your qualifications.

We wish you all the best in your professional endeavors.

Sincerely,
$senderName Hiring Committee

---
This is an automated message. Please do not reply directly to this email.";
}

/**
 * Generate approval email plain text
 */
function generateApprovalEmailText($recipientName, $teacher_id, $school_name, $senderName)
{
    return "Dear $recipientName,

Congratulations! Your application to join the teaching staff at $school_name has been APPROVED!

Your Teacher ID: $teacher_id

Welcome to our teaching team! We are excited to have you join our faculty.

Next Steps:
1. Save your Teacher ID for future reference
2. Complete the onboarding process by visiting our administration office
3. Submit any remaining documentation if required
4. Attend the faculty orientation (details will follow)

If you have any questions, please contact our administration office.

Welcome to $school_name!

Best regards,
$senderName Hiring Committee

---
This is an automated message. Please do not reply directly to this email.";
}
