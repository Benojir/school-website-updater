<?php
ob_start();
include_once(__DIR__ . "/../../../../includes/auth-check.php");

// Needed for uploadDocumentToImgBB()
include_once(__DIR__ . "/../../../../includes/imgbb-upload.php");

header('Content-Type: application/json');

if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    function clean($data) {
        return safe_htmlspecialchars(trim($data));
    }

    function saveBase64Image($base64_string, $upload_dir, $prefix = 'tch_') {
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
        if (preg_match('/^data:image\/(\w+);base64,/', $base64_string, $type)) {
            $data = substr($base64_string, strpos($base64_string, ',') + 1);
            $type = strtolower($type[1]);
            if (!in_array($type, ['jpg', 'jpeg', 'png'])) return false;
            $data = base64_decode($data);
            if ($data === false || strlen($data) > 2 * 1024 * 1024) return false;
        } else {
            return false;
        }
        $file_name = uniqid($prefix) . '.' . $type;
        $file_path = $upload_dir . $file_name;
        if (file_put_contents($file_path, $data)) {
            if (!getimagesize($file_path)) {
                unlink($file_path);
                return false;
            }
            return $file_name;
        }
        return false;
    }

    if (empty($_POST['id'])) {
        throw new Exception("Teacher ID is required");
    }

    $teacher_id = (int)$_POST['id'];
    $updateFields = [];
    $params = [':id' => $teacher_id];

    // Allowed status / gender values
    $allowed_status = ['active', 'inactive'];
    $allowed_gender = ['Male', 'Female', 'Other'];

    // Fields that must never be empty if they're included in the request
    $required_fields = ['name', 'email', 'phone', 'joining_date', 'date_of_birth', 'gender', 'status'];

    // Fields that are always upper-cased before validation/storage
    $uppercase_fields = ['pan_number', 'ifsc_code', 'voter_epic_number'];

    // Identity/bank fields that must be unique across teachers when provided
    $unique_fields = ['aadhaar_number', 'pan_number', 'voter_epic_number'];

    // Yes/No columns. These are NOT NULL in the schema, so an empty value falls back to 0
    // instead of being written as NULL by the generic writer below.
    $boolean_fields = ['show_on_website', 'share_phone_with_chatbot', 'can_view_parent_contacts', 'can_view_student_financial_report'];

    // Define editable fields, grouped to mirror add-teacher.php
    $field_map = [
        // Personal
        'name' => 'string',
        'email' => 'email',
        'phone' => 'string',
        'date_of_birth' => 'string',
        'gender' => 'string',
        'blood_group' => 'string',
        'caste_category' => 'string',
        'religion' => 'string',
        'nationality' => 'string',
        'aadhaar_number' => 'string',
        'monthly_salary' => 'string',
        // Family
        'father_name' => 'string',
        'father_phone' => 'string',
        'mother_name' => 'string',
        'mother_phone' => 'string',
        // Professional
        'position_in_school' => 'string',
        'subject_specialization' => 'string',
        'qualification' => 'string',
        'joining_date' => 'string',
        'status' => 'string',
        // Website & Access
        'show_on_website' => 'string',
        'share_phone_with_chatbot' => 'string',
        'display_priority' => 'string',
        'can_view_parent_contacts' => 'string',
        'can_view_student_financial_report' => 'string',
        // Bank
        'pan_number' => 'string',
        'voter_epic_number' => 'string',
        'bank_name' => 'string',
        'bank_branch' => 'string',
        'ifsc_code' => 'string',
        'account_number' => 'string',
        // Address
        'village' => 'string',
        'post_office' => 'string',
        'police_station' => 'string',
        'district' => 'string',
        'pincode' => 'string',
    ];

    foreach ($field_map as $field_name => $type) {
        if (isset($_POST[$field_name])) {
            $value = trim($_POST[$field_name]);

            // Required fields cannot be cleared
            if (in_array($field_name, $required_fields) && $value === '') {
                throw new Exception(ucfirst(str_replace('_', ' ', $field_name)) . " cannot be empty.");
            }

            // Normalize case for identity/bank codes before any validation
            if (in_array($field_name, $uppercase_fields) && $value !== '') {
                $value = strtoupper($value);
            }

            if ($field_name === 'email' && $value !== '') {
                if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    throw new Exception("Invalid email address format");
                }
                // Check uniqueness against other teachers
                $checkEmail = $pdo->prepare("SELECT COUNT(*) FROM teachers WHERE email = ? AND id != ?");
                $checkEmail->execute([$value, $teacher_id]);
                if ($checkEmail->fetchColumn() > 0) {
                    throw new Exception("Email already exists for another teacher");
                }
            }

            if ($field_name === 'phone' && $value !== '' && function_exists('isValidPhoneNumber') && !isValidPhoneNumber($value)) {
                throw new Exception("Invalid phone number");
            }

            if (in_array($field_name, ['father_phone', 'mother_phone']) && $value !== '' && function_exists('isValidPhoneNumber') && !isValidPhoneNumber($value)) {
                $who = $field_name === 'father_phone' ? "Father's" : "Mother's";
                throw new Exception("Invalid {$who} phone number");
            }

            if ($field_name === 'gender' && $value !== '' && !in_array($value, $allowed_gender)) {
                throw new Exception("Invalid gender value selected");
            }

            if ($field_name === 'status' && $value !== '' && !in_array($value, $allowed_status)) {
                throw new Exception("Invalid status value selected");
            }

            if ($field_name === 'pan_number' && $value !== '' && !preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/', $value)) {
                throw new Exception('Invalid PAN number format');
            }

            if ($field_name === 'ifsc_code' && $value !== '' && !preg_match('/^[A-Z]{4}0[A-Z0-9]{6}$/', $value)) {
                throw new Exception('Invalid IFSC code format');
            }

            if ($field_name === 'voter_epic_number' && $value !== '' && !preg_match('/^[A-Z]{3}[0-9]{7}$/', $value)) {
                throw new Exception('Invalid Voter EPIC number format');
            }

            if (in_array($field_name, $boolean_fields) && $value !== '' && !in_array($value, ['0', '1'], true)) {
                $label = ucwords(str_replace('_', ' ', $field_name));
                throw new Exception("Invalid value for {$label} - it must be Yes or No.");
            }

            // Optional, but must be a positive whole number when given
            if ($field_name === 'display_priority' && $value !== '' && (!ctype_digit($value) || (int)$value < 1)) {
                throw new Exception('Display priority must be a positive whole number.');
            }

            // Aadhaar / PAN / Voter EPIC must stay unique across teachers when provided
            if (in_array($field_name, $unique_fields) && $value !== '') {
                $checkUnique = $pdo->prepare("SELECT COUNT(*) FROM teachers WHERE {$field_name} = ? AND id != ?");
                $checkUnique->execute([$value, $teacher_id]);
                if ($checkUnique->fetchColumn() > 0) {
                    $label = ucwords(str_replace('_', ' ', $field_name));
                    throw new Exception("This {$label} is already registered with another teacher");
                }
            }

            $updateFields[] = "{$field_name} = :{$field_name}";

            if (in_array($field_name, $boolean_fields)) {
                // NOT NULL column - never write NULL here
                $params[":{$field_name}"] = ($value === '') ? 0 : (int)$value;
            } else {
                $params[":{$field_name}"] = ($value === '') ? null : clean($value);
            }
        }
    }

    // --- Assigned Sections Logic ---
    if (isset($_POST['assigned_sections'])) {
        $sections_decoded = json_decode($_POST['assigned_sections'], true);
        if (is_array($sections_decoded)) {
            // Map to integers for safety before encoding
            $sections_mapped = array_map('intval', $sections_decoded);
            $updateFields[] = "assigned_sections = :assigned_sections";
            $params[':assigned_sections'] = json_encode($sections_mapped);
        } else {
            // Handle clearing all sections
            $updateFields[] = "assigned_sections = :assigned_sections";
            $params[':assigned_sections'] = json_encode([]);
        }
    }

    // --- Address Construction Logic ---
    $address_components = ['village', 'post_office', 'police_station', 'district', 'pincode'];
    $address_changed = false;
    foreach ($address_components as $component) {
        if (isset($_POST[$component])) {
            $address_changed = true;
            break;
        }
    }

    if ($address_changed) {
        // Fetch current full address components for the teacher
        $stmt_address = $pdo->prepare("SELECT village, post_office, police_station, district, pincode FROM teachers WHERE id = :id");
        $stmt_address->execute([':id' => $teacher_id]);
        $current_address = $stmt_address->fetch(PDO::FETCH_ASSOC);

        if ($current_address) {
            $village = isset($_POST['village']) ? clean(trim($_POST['village'])) : $current_address['village'];
            $post_office = isset($_POST['post_office']) ? clean(trim($_POST['post_office'])) : $current_address['post_office'];
            $police_station = isset($_POST['police_station']) ? clean(trim($_POST['police_station'])) : $current_address['police_station'];
            $district = isset($_POST['district']) ? clean(trim($_POST['district'])) : $current_address['district'];
            $pincode = isset($_POST['pincode']) ? clean(trim($_POST['pincode'])) : $current_address['pincode'];

            // Build full address string
            $address_parts = array_filter([$village, $post_office, $police_station, $district, $pincode]);
            $full_address = implode(', ', $address_parts);

            $updateFields[] = "address = :address";
            $params[':address'] = ($full_address === '') ? null : $full_address;
        }
    }

    // Handle Image Upload
    if (!empty($_POST['cropped_image_data'])) {
        $upload_dir = __DIR__ . '/../../../../uploads/teachers/';
        $cropped_image = saveBase64Image($_POST['cropped_image_data'], $upload_dir);

        if ($cropped_image) {
            $current_image = isset($_POST['current_image']) ? trim($_POST['current_image']) : null;
            // Unlink old image if it's not the default
            if ($current_image && $current_image !== 'default_teacher_dp.jpg' && file_exists($upload_dir . $current_image)) {
                unlink($upload_dir . $current_image);
            }
            $updateFields[] = "teacher_image = :teacher_image";
            $params[':teacher_image'] = $cropped_image;
            $response['new_image'] = $cropped_image;
        } else {
            throw new Exception("Failed to save cropped image.");
        }
    }

    // --- Documents Logic ---
    // teachers.documents holds a JSON list of {document_name, document_url}. The page sends the
    // full list that should be kept in documents_existing (covering renames and removals), plus
    // optional document_name[] / document_file[] pairs for documents being added now.
    $has_new_document_files = !empty($_FILES['document_file']['name']) && is_array($_FILES['document_file']['name']);

    if (isset($_POST['documents_existing']) || $has_new_document_files) {
        // Current stored state. Needed as the fallback list, and to tell whether the document
        // count is actually growing - teachers saved before the cap existed may already exceed it.
        $stmt_docs = $pdo->prepare("SELECT documents FROM teachers WHERE id = :id");
        $stmt_docs->execute([':id' => $teacher_id]);
        $stored_documents = json_decode($stmt_docs->fetchColumn() ?: '[]', true);

        if (!is_array($stored_documents)) {
            $stored_documents = [];
        }

        $documents = [];

        if (isset($_POST['documents_existing'])) {
            $existing_documents = json_decode($_POST['documents_existing'], true);

            if (!is_array($existing_documents)) {
                throw new Exception("Invalid documents data received.");
            }

            foreach ($existing_documents as $existing_document) {
                $doc_name = isset($existing_document['document_name']) ? clean(trim($existing_document['document_name'])) : '';
                $doc_url = isset($existing_document['document_url']) ? trim($existing_document['document_url']) : '';

                if ($doc_name === '' || $doc_url === '') {
                    throw new Exception("Every document must have a name and an uploaded file.");
                }

                if (!filter_var($doc_url, FILTER_VALIDATE_URL)) {
                    throw new Exception("Invalid document URL received.");
                }

                $documents[] = ['document_name' => $doc_name, 'document_url' => $doc_url];
            }
        } else {
            // Only new files were sent, so keep whatever is already stored and append to it
            $documents = $stored_documents;
        }

        if ($has_new_document_files) {
            $docNames = $_POST['document_name'] ?? [];
            $docFiles = $_FILES['document_file'];
            $totalDocs = count($docFiles['name']);

            // Reject an over-limit request before any ImgBB upload happens, otherwise
            // the images that did upload would be orphaned when this throws.
            $filledSlots = 0;
            for ($i = 0; $i < $totalDocs; $i++) {
                if ($docFiles['error'][$i] !== UPLOAD_ERR_NO_FILE) {
                    $filledSlots++;
                }
            }

            if (count($documents) + $filledSlots > MAX_TEACHER_DOCUMENTS) {
                throw new Exception('A teacher can have a maximum of ' . MAX_TEACHER_DOCUMENTS . ' documents.');
            }

            // Teacher's name is used as part of the ImgBB caption
            $stmt_teacher_name = $pdo->prepare("SELECT name FROM teachers WHERE id = :id");
            $stmt_teacher_name->execute([':id' => $teacher_id]);
            $teacher_name = $stmt_teacher_name->fetchColumn() ?: "ID {$teacher_id}";

            for ($i = 0; $i < $totalDocs; $i++) {
                // Skip empty slots (row added but nothing selected)
                if ($docFiles['error'][$i] === UPLOAD_ERR_NO_FILE) {
                    continue;
                }

                $doc_name = isset($docNames[$i]) ? clean(trim($docNames[$i])) : '';
                if ($doc_name === '') {
                    throw new Exception("Every uploaded document must have a name.");
                }

                // Rebuild a single-file $_FILES-style array for this index
                $singleFile = [
                    'name'     => $docFiles['name'][$i],
                    'type'     => $docFiles['type'][$i],
                    'tmp_name' => $docFiles['tmp_name'][$i],
                    'error'    => $docFiles['error'][$i],
                    'size'     => $docFiles['size'][$i],
                ];

                $documents[] = [
                    'document_name' => $doc_name,
                    'document_url'  => uploadDocumentToImgBB($singleFile, $doc_name . ' - ' . $teacher_name),
                ];
            }
        }

        // The cap applies to growth only: a teacher who already exceeds it (saved before the cap
        // existed) can still have documents renamed or removed, just not added.
        if (count($documents) > MAX_TEACHER_DOCUMENTS && count($documents) > count($stored_documents)) {
            throw new Exception('A teacher can have a maximum of ' . MAX_TEACHER_DOCUMENTS . ' documents.');
        }

        $updateFields[] = "documents = :documents";
        $params[':documents'] = !empty($documents) ? json_encode($documents) : null;
        $response['documents'] = $documents;
    }

    if (!empty($updateFields)) {
        $sql = "UPDATE teachers SET " . implode(', ', array_unique($updateFields)) . " WHERE id = :id";
        $stmt = $pdo->prepare($sql);

        if ($stmt->execute($params)) {
            $response['success'] = true;
            $response['message'] = "Teacher updated successfully";
        } else {
            throw new Exception("Failed to update teacher record.");
        }
    } else {
        $response['success'] = true;
        $response['message'] = "No changes were detected";
    }

} catch (PDOException $e) {
    $response['message'] = "Database error: " . $e->getMessage();
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

ob_end_clean();
echo json_encode($response);
exit();
?>