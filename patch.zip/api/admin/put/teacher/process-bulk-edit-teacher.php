<?php
ob_start();
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    function clean($data) {
        return safe_htmlspecialchars(trim($data));
    }

    function saveBase64Image($base64_string, $upload_dir, $prefix = 'tch_') {
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
        if (preg_match('/^data:image\/(\w+);base64,/', $base64_string, $type)) {
            $data = substr($base64_string, strpos($base64_string, ',') + 1);
            $type = strtolower($type[1]);
            if (!in_array($type, ['jpg', 'jpeg', 'png'])) return false;
            $data = base64_decode($data);
            if ($data === false || strlen($data) > 2 * 1024 * 1024) return false;
        } else {
            return false;
        }
        $file_name = uniqid($prefix) . '.' . $type;
        $file_path = $upload_dir . $file_name;
        if (file_put_contents($file_path, $data)) {
            if (!getimagesize($file_path)) {
                unlink($file_path);
                return false;
            }
            return $file_name;
        }
        return false;
    }

    if (empty($_POST['id'])) {
        throw new Exception("Teacher ID is required");
    }

    $teacher_id = (int)$_POST['id'];
    $updateFields = [];
    $params = [':id' => $teacher_id];

    // Allowed status
    $allowed_status = ['active', 'inactive'];

    // Define editable fields (Added aadhaar_number and monthly_salary)
    $field_map = [
        'name' => 'string',
        'email' => 'email',
        'phone' => 'string',
        'position_in_school' => 'string',
        'subject_specialization' => 'string',
        'qualification' => 'string',
        'joining_date' => 'string',
        'status' => 'string',
        'village' => 'string',
        'post_office' => 'string',
        'police_station' => 'string',
        'district' => 'string',
        'pincode' => 'string',
        'aadhaar_number' => 'string',
        'monthly_salary' => 'string',
    ];

    foreach ($field_map as $field_name => $type) {
        if (isset($_POST[$field_name])) {
            $value = trim($_POST[$field_name]);

            // Validations
            if (in_array($field_name, ['name', 'email', 'phone', 'joining_date']) && empty($value)) {
                throw new Exception(ucfirst(str_replace('_', ' ', $field_name)) . " cannot be empty.");
            }

            if ($field_name === 'email' && $value !== '') {
                if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    throw new Exception("Invalid email address format");
                }
                // Check uniqueness against other teachers
                $checkEmail = $pdo->prepare("SELECT COUNT(*) FROM teachers WHERE email = ? AND id != ?");
                $checkEmail->execute([$value, $teacher_id]);
                if ($checkEmail->fetchColumn() > 0) {
                    throw new Exception("Email already exists for another teacher");
                }
            }

            if ($field_name === 'status' && $value !== '' && !in_array($value, $allowed_status)) {
                throw new Exception("Invalid status value selected");
            }

            $updateFields[] = "{$field_name} = :{$field_name}";
            $params[":{$field_name}"] = ($value === '') ? null : clean($value);
        }
    }

    // --- Assigned Sections Logic ---
    if (isset($_POST['assigned_sections'])) {
        $sections_decoded = json_decode($_POST['assigned_sections'], true);
        if (is_array($sections_decoded)) {
            // Map to integers for safety before encoding
            $sections_mapped = array_map('intval', $sections_decoded);
            $updateFields[] = "assigned_sections = :assigned_sections";
            $params[':assigned_sections'] = json_encode($sections_mapped);
        } else {
            // Handle clearing all sections
            $updateFields[] = "assigned_sections = :assigned_sections";
            $params[':assigned_sections'] = json_encode([]);
        }
    }

    // --- Address Construction Logic ---
    $address_components = ['village', 'post_office', 'police_station', 'district', 'pincode'];
    $address_changed = false;
    foreach ($address_components as $component) {
        if (isset($_POST[$component])) {
            $address_changed = true;
            break;
        }
    }

    if ($address_changed) {
        // Fetch current full address components for the teacher
        $stmt_address = $pdo->prepare("SELECT village, post_office, police_station, district, pincode FROM teachers WHERE id = :id");
        $stmt_address->execute([':id' => $teacher_id]);
        $current_address = $stmt_address->fetch(PDO::FETCH_ASSOC);

        if ($current_address) {
            $village = isset($_POST['village']) ? clean(trim($_POST['village'])) : $current_address['village'];
            $post_office = isset($_POST['post_office']) ? clean(trim($_POST['post_office'])) : $current_address['post_office'];
            $police_station = isset($_POST['police_station']) ? clean(trim($_POST['police_station'])) : $current_address['police_station'];
            $district = isset($_POST['district']) ? clean(trim($_POST['district'])) : $current_address['district'];
            $pincode = isset($_POST['pincode']) ? clean(trim($_POST['pincode'])) : $current_address['pincode'];

            // Build full address string
            $address_parts = array_filter([$village, $post_office, $police_station, $district, $pincode]);
            $full_address = implode(', ', $address_parts);

            $updateFields[] = "address = :address";
            $params[':address'] = ($full_address === '') ? null : $full_address;
        }
    }

    // Handle Image Upload
    if (!empty($_POST['cropped_image_data'])) {
        $upload_dir = __DIR__ . '/../../../../uploads/teachers/';
        $cropped_image = saveBase64Image($_POST['cropped_image_data'], $upload_dir);

        if ($cropped_image) {
            $current_image = isset($_POST['current_image']) ? trim($_POST['current_image']) : null;
            // Unlink old image if it's not the default
            if ($current_image && $current_image !== 'default_teacher_dp.jpg' && file_exists($upload_dir . $current_image)) {
                unlink($upload_dir . $current_image);
            }
            $updateFields[] = "teacher_image = :teacher_image";
            $params[':teacher_image'] = $cropped_image;
            $response['new_image'] = $cropped_image;
        } else {
            throw new Exception("Failed to save cropped image.");
        }
    }

    if (!empty($updateFields)) {
        $sql = "UPDATE teachers SET " . implode(', ', array_unique($updateFields)) . " WHERE id = :id";
        $stmt = $pdo->prepare($sql);

        if ($stmt->execute($params)) {
            $response['success'] = true;
            $response['message'] = "Teacher updated successfully";
        } else {
            throw new Exception("Failed to update teacher record.");
        }
    } else {
        $response['success'] = true;
        $response['message'] = "No changes were detected";
    }

} catch (PDOException $e) {
    $response['message'] = "Database error: " . $e->getMessage();
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

ob_end_clean();
echo json_encode($response);
exit();
?>