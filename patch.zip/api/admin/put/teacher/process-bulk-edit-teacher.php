<?php
ob_start();
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    function clean($data) {
        return safe_htmlspecialchars(trim($data));
    }

    function saveBase64Image($base64_string, $upload_dir, $prefix = 'tch_') {
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
        if (preg_match('/^data:image\/(\w+);base64,/', $base64_string, $type)) {
            $data = substr($base64_string, strpos($base64_string, ',') + 1);
            $type = strtolower($type[1]);
            if (!in_array($type, ['jpg', 'jpeg', 'png'])) return false;
            $data = base64_decode($data);
            if ($data === false || strlen($data) > 2 * 1024 * 1024) return false;
        } else {
            return false;
        }
        $file_name = uniqid($prefix) . '.' . $type;
        $file_path = $upload_dir . $file_name;
        if (file_put_contents($file_path, $data)) {
            if (!getimagesize($file_path)) {
                unlink($file_path);
                return false;
            }
            return $file_name;
        }
        return false;
    }

    if (empty($_POST['id'])) {
        throw new Exception("Teacher ID is required");
    }

    $teacher_id = (int)$_POST['id'];
    $updateFields = [];
    $params = [':id' => $teacher_id];

    // Allowed status / gender values
    $allowed_status = ['active', 'inactive'];
    $allowed_gender = ['Male', 'Female', 'Other'];

    // Fields that must never be empty if they're included in the request
    $required_fields = ['name', 'email', 'phone', 'joining_date', 'date_of_birth', 'gender', 'status'];

    // Fields that are always upper-cased before validation/storage
    $uppercase_fields = ['pan_number', 'ifsc_code', 'voter_epic_number'];

    // Identity/bank fields that must be unique across teachers when provided
    $unique_fields = ['aadhaar_number', 'pan_number', 'voter_epic_number'];

    // Define editable fields, grouped to mirror add-teacher.php
    $field_map = [
        // Personal
        'name' => 'string',
        'email' => 'email',
        'phone' => 'string',
        'date_of_birth' => 'string',
        'gender' => 'string',
        'blood_group' => 'string',
        'caste_category' => 'string',
        'religion' => 'string',
        'nationality' => 'string',
        'aadhaar_number' => 'string',
        'monthly_salary' => 'string',
        // Family
        'father_name' => 'string',
        'father_phone' => 'string',
        'mother_name' => 'string',
        'mother_phone' => 'string',
        // Professional
        'position_in_school' => 'string',
        'subject_specialization' => 'string',
        'qualification' => 'string',
        'joining_date' => 'string',
        'status' => 'string',
        // Bank
        'pan_number' => 'string',
        'voter_epic_number' => 'string',
        'bank_name' => 'string',
        'bank_branch' => 'string',
        'ifsc_code' => 'string',
        'account_number' => 'string',
        // Address
        'village' => 'string',
        'post_office' => 'string',
        'police_station' => 'string',
        'district' => 'string',
        'pincode' => 'string',
    ];

    foreach ($field_map as $field_name => $type) {
        if (isset($_POST[$field_name])) {
            $value = trim($_POST[$field_name]);

            // Required fields cannot be cleared
            if (in_array($field_name, $required_fields) && $value === '') {
                throw new Exception(ucfirst(str_replace('_', ' ', $field_name)) . " cannot be empty.");
            }

            // Normalize case for identity/bank codes before any validation
            if (in_array($field_name, $uppercase_fields) && $value !== '') {
                $value = strtoupper($value);
            }

            if ($field_name === 'email' && $value !== '') {
                if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    throw new Exception("Invalid email address format");
                }
                // Check uniqueness against other teachers
                $checkEmail = $pdo->prepare("SELECT COUNT(*) FROM teachers WHERE email = ? AND id != ?");
                $checkEmail->execute([$value, $teacher_id]);
                if ($checkEmail->fetchColumn() > 0) {
                    throw new Exception("Email already exists for another teacher");
                }
            }

            if ($field_name === 'phone' && $value !== '' && function_exists('isValidPhoneNumber') && !isValidPhoneNumber($value)) {
                throw new Exception("Invalid phone number");
            }

            if (in_array($field_name, ['father_phone', 'mother_phone']) && $value !== '' && function_exists('isValidPhoneNumber') && !isValidPhoneNumber($value)) {
                $who = $field_name === 'father_phone' ? "Father's" : "Mother's";
                throw new Exception("Invalid {$who} phone number");
            }

            if ($field_name === 'gender' && $value !== '' && !in_array($value, $allowed_gender)) {
                throw new Exception("Invalid gender value selected");
            }

            if ($field_name === 'status' && $value !== '' && !in_array($value, $allowed_status)) {
                throw new Exception("Invalid status value selected");
            }

            if ($field_name === 'pan_number' && $value !== '' && !preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/', $value)) {
                throw new Exception('Invalid PAN number format');
            }

            if ($field_name === 'ifsc_code' && $value !== '' && !preg_match('/^[A-Z]{4}0[A-Z0-9]{6}$/', $value)) {
                throw new Exception('Invalid IFSC code format');
            }

            if ($field_name === 'voter_epic_number' && $value !== '' && !preg_match('/^[A-Z]{3}[0-9]{7}$/', $value)) {
                throw new Exception('Invalid Voter EPIC number format');
            }

            // Aadhaar / PAN / Voter EPIC must stay unique across teachers when provided
            if (in_array($field_name, $unique_fields) && $value !== '') {
                $checkUnique = $pdo->prepare("SELECT COUNT(*) FROM teachers WHERE {$field_name} = ? AND id != ?");
                $checkUnique->execute([$value, $teacher_id]);
                if ($checkUnique->fetchColumn() > 0) {
                    $label = ucwords(str_replace('_', ' ', $field_name));
                    throw new Exception("This {$label} is already registered with another teacher");
                }
            }

            $updateFields[] = "{$field_name} = :{$field_name}";
            $params[":{$field_name}"] = ($value === '') ? null : clean($value);
        }
    }

    // --- Assigned Sections Logic ---
    if (isset($_POST['assigned_sections'])) {
        $sections_decoded = json_decode($_POST['assigned_sections'], true);
        if (is_array($sections_decoded)) {
            // Map to integers for safety before encoding
            $sections_mapped = array_map('intval', $sections_decoded);
            $updateFields[] = "assigned_sections = :assigned_sections";
            $params[':assigned_sections'] = json_encode($sections_mapped);
        } else {
            // Handle clearing all sections
            $updateFields[] = "assigned_sections = :assigned_sections";
            $params[':assigned_sections'] = json_encode([]);
        }
    }

    // --- Address Construction Logic ---
    $address_components = ['village', 'post_office', 'police_station', 'district', 'pincode'];
    $address_changed = false;
    foreach ($address_components as $component) {
        if (isset($_POST[$component])) {
            $address_changed = true;
            break;
        }
    }

    if ($address_changed) {
        // Fetch current full address components for the teacher
        $stmt_address = $pdo->prepare("SELECT village, post_office, police_station, district, pincode FROM teachers WHERE id = :id");
        $stmt_address->execute([':id' => $teacher_id]);
        $current_address = $stmt_address->fetch(PDO::FETCH_ASSOC);

        if ($current_address) {
            $village = isset($_POST['village']) ? clean(trim($_POST['village'])) : $current_address['village'];
            $post_office = isset($_POST['post_office']) ? clean(trim($_POST['post_office'])) : $current_address['post_office'];
            $police_station = isset($_POST['police_station']) ? clean(trim($_POST['police_station'])) : $current_address['police_station'];
            $district = isset($_POST['district']) ? clean(trim($_POST['district'])) : $current_address['district'];
            $pincode = isset($_POST['pincode']) ? clean(trim($_POST['pincode'])) : $current_address['pincode'];

            // Build full address string
            $address_parts = array_filter([$village, $post_office, $police_station, $district, $pincode]);
            $full_address = implode(', ', $address_parts);

            $updateFields[] = "address = :address";
            $params[':address'] = ($full_address === '') ? null : $full_address;
        }
    }

    // Handle Image Upload
    if (!empty($_POST['cropped_image_data'])) {
        $upload_dir = __DIR__ . '/../../../../uploads/teachers/';
        $cropped_image = saveBase64Image($_POST['cropped_image_data'], $upload_dir);

        if ($cropped_image) {
            $current_image = isset($_POST['current_image']) ? trim($_POST['current_image']) : null;
            // Unlink old image if it's not the default
            if ($current_image && $current_image !== 'default_teacher_dp.jpg' && file_exists($upload_dir . $current_image)) {
                unlink($upload_dir . $current_image);
            }
            $updateFields[] = "teacher_image = :teacher_image";
            $params[':teacher_image'] = $cropped_image;
            $response['new_image'] = $cropped_image;
        } else {
            throw new Exception("Failed to save cropped image.");
        }
    }

    if (!empty($updateFields)) {
        $sql = "UPDATE teachers SET " . implode(', ', array_unique($updateFields)) . " WHERE id = :id";
        $stmt = $pdo->prepare($sql);

        if ($stmt->execute($params)) {
            $response['success'] = true;
            $response['message'] = "Teacher updated successfully";
        } else {
            throw new Exception("Failed to update teacher record.");
        }
    } else {
        $response['success'] = true;
        $response['message'] = "No changes were detected";
    }

} catch (PDOException $e) {
    $response['message'] = "Database error: " . $e->getMessage();
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

ob_end_clean();
echo json_encode($response);
exit();
?>