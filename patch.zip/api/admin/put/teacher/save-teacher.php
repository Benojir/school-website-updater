<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to manage teachers
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = sanitize_input($_POST['name']);
        $email = sanitize_input($_POST['email']);
        $phone = sanitize_input($_POST['phone']);
        $position_in_school = sanitize_input($_POST['position_in_school'] ?? '');
        $village = sanitize_input($_POST['village'] ?? '');
        $post_office = sanitize_input($_POST['post_office'] ?? '');
        $police_station = sanitize_input($_POST['police_station'] ?? '');
        $district = sanitize_input($_POST['district'] ?? '');
        $pincode = sanitize_input($_POST['pincode'] ?? '');
        $qualification = sanitize_input($_POST['qualification'] ?? '');
        $subject_specialization = sanitize_input($_POST['subject_specialization'] ?? '');
        $joining_date = sanitize_input($_POST['joining_date']);
        $status = sanitize_input($_POST['status']);
        
        // --- NEW FIELDS ---
        $aadhaar_number = sanitize_input($_POST['aadhaar_card'] ?? '');
        $monthly_salary = sanitize_input($_POST['salary'] ?? '');
        
        // Process assigned_sections into JSON format
        $allow_sections = isset($_POST['allow_sections']) && is_array($_POST['allow_sections']) ? $_POST['allow_sections'] : [];
        // Map to integers for safety before encoding
        $allow_sections = array_map('intval', $allow_sections);
        $assigned_sections = json_encode($allow_sections);
        // ------------------

        // Building full address
        $address = "{$village}, {$post_office}, {$police_station}, {$district}, {$pincode}";

        $temp_address_var = trim(str_replace(",", "", $address));

        if (empty($temp_address_var)) {
            $address = null;
        }

        // Validate required fields
        if (empty($name) || empty($email) || empty($phone) || empty($joining_date)) {
            throw new Exception('All required fields must be filled');
        }

        // Capitalize the first letter of each word in name
        $name = ucwords(strtolower($name));

        // Validate email and phone
        if (!isValidEmail($email)) {
            throw new Exception('Invalid email id');
        }
        if (!isValidPhoneNumber($phone)) {
            throw new Exception('Invalid phone number');
        }

        // Check if email already exists
        $checkDuplicate = $pdo->prepare("SELECT id FROM teachers WHERE email = ? OR phone = ?");
        $checkDuplicate->execute([$email, $phone]);
        if ($checkDuplicate->rowCount() > 0) {
            throw new Exception('Email or phone number already exists');
        }

        // Handle image upload if exists
        $photo = 'default_teacher_dp.jpg';

        if (!empty($_FILES['cropped_image']['tmp_name']) || !empty($_FILES['original_image']['tmp_name'])) {
            $imageFile = !empty($_FILES['cropped_image']['tmp_name'])
                ? $_FILES['cropped_image']['tmp_name']
                : $_FILES['original_image']['tmp_name'];

            if (!isValidImageFile($imageFile)) {
                throw new Exception('You\'re trying to upload an invalid or currupted image.');
            }

            $photo = uniqid('tch_');

            $imageInfo = @getimagesize($imageFile);

            if ($imageInfo['mime'] === 'image/jpeg') {
                $photo .= ".jpg";
            } else {
                $photo .= ".png";
            }

            $destination =  __DIR__ . '/../../../../uploads/teachers/' . $photo;

            if (!move_uploaded_file($imageFile, $destination)) {
                throw new Exception('Failed to upload image.');
            }
        }

        // Insert new teacher (Updated with new columns and placeholders)
        $stmt = $pdo->prepare("
            INSERT INTO 
            teachers(name, email, phone, 
            position_in_school, village, 
            post_office, police_station, 
            district, pincode, address, 
            qualification, subject_specialization, 
            joining_date, teacher_image, status,
            aadhaar_number, monthly_salary, assigned_sections) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $name,
            $email,
            $phone,
            $position_in_school,
            $village,
            $post_office,
            $police_station,
            $district,
            $pincode,
            $address,
            $qualification,
            $subject_specialization,
            $joining_date,
            $photo,
            $status,
            $aadhaar_number,
            $monthly_salary,
            $assigned_sections
        ]);

        $response['success'] = true;
        $response['message'] = 'Teacher added successfully';
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);