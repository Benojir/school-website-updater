<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to manage teachers
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $address = trim($_POST['address'] ?? '');
        $qualification = trim($_POST['qualification'] ?? '');
        $subject_specialization = trim($_POST['subject_specialization'] ?? '');
        $joining_date = trim($_POST['joining_date']);
        $status = trim($_POST['status']);

        // Validate required fields
        if (empty($name) || empty($email) || empty($phone) || empty($joining_date)) {
            throw new Exception('All required fields must be filled');
        }

        // Capitalize the first letter of each word in name
        $name = ucwords(strtolower($name));

        // Validate email and phone
        if (!isValidEmail($email)) {
            throw new Exception('Invalid email id');
        }
        if (!isValidPhoneNumber($phone)) {
            throw new Exception('Invalid phone number');
        }

        // Check if email already exists
        $checkDuplicate = $pdo->prepare("SELECT id FROM teachers WHERE email = ? OR phone = ?");
        $checkDuplicate->execute([$email, $phone]);
        if ($checkDuplicate->rowCount() > 0) {
            throw new Exception('Email or phone number already exists');
        }

        // Handle image upload if exists
        $photo = 'default_teacher_dp.jpg';

        if (!empty($_FILES['cropped_image']['tmp_name']) || !empty($_FILES['original_image']['tmp_name'])) {
            $imageFile = !empty($_FILES['cropped_image']['tmp_name'])
                ? $_FILES['cropped_image']['tmp_name']
                : $_FILES['original_image']['tmp_name'];

            if (!isValidateImageFile($imageFile)) {
                throw new Exception('You\'re trying to upload an invalid or currupted image.');
            }

            $photo = uniqid('tch_');

            $imageInfo = @getimagesize($imageFile);

            if ($imageInfo['mime'] === 'image/jpeg') {
                $photo .= ".jpg";
            } else {
                $photo .= ".png";
            }

            $destination =  __DIR__ . '/../../../../uploads/teachers/' . $photo;

            if (!move_uploaded_file($imageFile, $destination)) {
                throw new Exception('Failed to upload image.');
            }
        }

        // Insert new teacher
        $stmt = $pdo->prepare("
            INSERT INTO teachers (
                name, email, phone, address, 
                qualification, subject_specialization, 
                joining_date, status, teacher_image
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $name,
            $email,
            $phone,
            $address,
            $qualification,
            $subject_specialization,
            $joining_date,
            $status,
            $photo
        ]);

        $response['success'] = true;
        $response['message'] = 'Teacher added successfully';
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
