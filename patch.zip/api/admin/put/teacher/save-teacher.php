<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

// Needed for uploadDocumentToImgBB()
// Adjust this path if imgbb-upload.php lives somewhere else in your project.
include_once(__DIR__ . "/../../../../includes/imgbb-upload.php");

header('Content-Type: application/json');

// Check if user has permission to manage teachers
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = sanitize_input($_POST['name']);
        $email = sanitize_input($_POST['email']);
        $phone = sanitize_input($_POST['phone']);
        $position_in_school = sanitize_input($_POST['position_in_school'] ?? '');
        $village = sanitize_input($_POST['village'] ?? '');
        $post_office = sanitize_input($_POST['post_office'] ?? '');
        $police_station = sanitize_input($_POST['police_station'] ?? '');
        $district = sanitize_input($_POST['district'] ?? '');
        $pincode = sanitize_input($_POST['pincode'] ?? '');
        $qualification = sanitize_input($_POST['qualification'] ?? '');
        $subject_specialization = sanitize_input($_POST['subject_specialization'] ?? '');
        $joining_date = sanitize_input($_POST['joining_date']);
        $status = sanitize_input($_POST['status']);

        $aadhaar_number = sanitize_input($_POST['aadhaar_card'] ?? '');
        $monthly_salary = (float) sanitize_input($_POST['salary'] ?? '');

        // --- NEW PERSONAL / FAMILY FIELDS ---
        $date_of_birth = sanitize_input($_POST['date_of_birth'] ?? '');
        $gender = sanitize_input($_POST['gender'] ?? '');
        $blood_group = sanitize_input($_POST['blood_group'] ?? '');
        $caste_category = sanitize_input($_POST['caste_category'] ?? '');
        $religion = sanitize_input($_POST['religion'] ?? '');
        $nationality = sanitize_input($_POST['nationality'] ?? 'Indian');

        $father_name = sanitize_input($_POST['father_name'] ?? '');
        $father_phone = sanitize_input($_POST['father_phone'] ?? '');
        $mother_name = sanitize_input($_POST['mother_name'] ?? '');
        $mother_phone = sanitize_input($_POST['mother_phone'] ?? '');

        // --- NEW BANK FIELDS ---
        $pan_number = strtoupper(sanitize_input($_POST['pan_number'] ?? '') ?? '');
        $voter_epic_number = strtoupper(sanitize_input($_POST['voter_epic_number'] ?? '') ?? '');
        $bank_name = sanitize_input($_POST['bank_name'] ?? '');
        $bank_branch = sanitize_input($_POST['bank_branch'] ?? '');
        $ifsc_code = strtoupper(sanitize_input($_POST['ifsc_code'] ?? '') ?? '');
        $account_number = sanitize_input($_POST['account_number'] ?? '');

        // Empty-string optional fields should be stored as NULL, not ''
        $blood_group = $blood_group !== '' ? $blood_group : null;
        $caste_category = $caste_category !== '' ? $caste_category : null;

        // Uniqueness-sensitive identity fields: store as NULL when blank so the
        // DB's unique index doesn't treat multiple blanks as duplicates.
        $aadhaar_number = $aadhaar_number !== '' ? $aadhaar_number : null;
        $pan_number = $pan_number !== '' ? $pan_number : null;
        $voter_epic_number = $voter_epic_number !== '' ? $voter_epic_number : null;

        // Process assigned_sections into JSON format
        $allow_sections = isset($_POST['allow_sections']) && is_array($_POST['allow_sections']) ? $_POST['allow_sections'] : [];
        $allow_sections = array_map('intval', $allow_sections);
        $assigned_sections = json_encode($allow_sections);

        // Building full address
        $address = "{$village}, {$post_office}, {$police_station}, {$district}, {$pincode}";
        $temp_address_var = trim(str_replace(",", "", $address));
        if (empty($temp_address_var)) {
            $address = null;
        }

        // Validate required fields
        if (empty($name) || empty($email) || empty($phone) || empty($joining_date) || empty($date_of_birth) || empty($gender)) {
            throw new Exception('All required fields must be filled');
        }

        // Capitalize the first letter of each word in name
        $name = ucwords(strtolower($name));

        // Validate email and phone
        if (!isValidEmail($email)) {
            throw new Exception('Invalid email id');
        }
        if (!isValidPhoneNumber($phone)) {
            throw new Exception('Invalid phone number');
        }

        // Basic format checks for the new optional fields (only if the admin filled them in)
        if (!empty($pan_number) && !preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/', $pan_number)) {
            throw new Exception('Invalid PAN number format');
        }
        if (!empty($ifsc_code) && !preg_match('/^[A-Z]{4}0[A-Z0-9]{6}$/', $ifsc_code)) {
            throw new Exception('Invalid IFSC code format');
        }
        if (!empty($voter_epic_number) && !preg_match('/^[A-Z]{3}[0-9]{7}$/', $voter_epic_number)) {
            throw new Exception('Invalid Voter EPIC number format');
        }
        if (!empty($father_phone) && !isValidPhoneNumber($father_phone)) {
            throw new Exception('Invalid father\'s phone number');
        }
        if (!empty($mother_phone) && !isValidPhoneNumber($mother_phone)) {
            throw new Exception('Invalid mother\'s phone number');
        }

        // Check if email already exists
        $checkDuplicate = $pdo->prepare("SELECT id FROM teachers WHERE email = ? OR phone = ?");
        $checkDuplicate->execute([$email, $phone]);
        if ($checkDuplicate->rowCount() > 0) {
            throw new Exception('Email or phone number already exists');
        }

        // Aadhaar / PAN / Voter EPIC must be unique, but only when provided
        if (!empty($aadhaar_number)) {
            $checkAadhaar = $pdo->prepare("SELECT id FROM teachers WHERE aadhaar_number = ?");
            $checkAadhaar->execute([$aadhaar_number]);
            if ($checkAadhaar->rowCount() > 0) {
                throw new Exception('This Aadhaar number is already registered with another teacher');
            }
        }
        if (!empty($pan_number)) {
            $checkPan = $pdo->prepare("SELECT id FROM teachers WHERE pan_number = ?");
            $checkPan->execute([$pan_number]);
            if ($checkPan->rowCount() > 0) {
                throw new Exception('This PAN number is already registered with another teacher');
            }
        }
        if (!empty($voter_epic_number)) {
            $checkEpic = $pdo->prepare("SELECT id FROM teachers WHERE voter_epic_number = ?");
            $checkEpic->execute([$voter_epic_number]);
            if ($checkEpic->rowCount() > 0) {
                throw new Exception('This Voter EPIC number is already registered with another teacher');
            }
        }

        // Handle image upload if exists
        $photo = 'default_teacher_dp.jpg';

        if (!empty($_FILES['cropped_image']['tmp_name']) || !empty($_FILES['original_image']['tmp_name'])) {
            $imageFile = !empty($_FILES['cropped_image']['tmp_name'])
                ? $_FILES['cropped_image']['tmp_name']
                : $_FILES['original_image']['tmp_name'];

            if (!isValidImageFile($imageFile)) {
                throw new Exception('You\'re trying to upload an invalid or currupted image.');
            }

            $photo = uniqid('tch_');
            $imageInfo = @getimagesize($imageFile);

            if ($imageInfo['mime'] === 'image/jpeg') {
                $photo .= ".jpg";
            } else {
                $photo .= ".png";
            }

            $destination = __DIR__ . '/../../../../uploads/teachers/' . $photo;

            if (!move_uploaded_file($imageFile, $destination)) {
                throw new Exception('Failed to upload image.');
            }
        }

        // --- NEW: Handle dynamic document uploads (ImgBB) ---
        // Expects two parallel arrays from the form:
        //   document_name[]  -> text label the admin typed (e.g. "PAN Card")
        //   document_file[]  -> the corresponding uploaded image
        $documents = [];

        if (!empty($_FILES['document_file']['name']) && is_array($_FILES['document_file']['name'])) {
            $docNames = $_POST['document_name'] ?? [];
            $docFiles = $_FILES['document_file'];
            $totalDocs = count($docFiles['name']);

            for ($i = 0; $i < $totalDocs; $i++) {
                // Skip empty slots (row added but nothing selected)
                if ($docFiles['error'][$i] === UPLOAD_ERR_NO_FILE) {
                    continue;
                }

                $docName = isset($docNames[$i]) ? sanitize_input($docNames[$i]) : '';
                if (empty($docName)) {
                    throw new Exception('Every uploaded document must have a name.');
                }

                // Rebuild a single-file $_FILES-style array for this index
                $singleFile = [
                    'name'     => $docFiles['name'][$i],
                    'type'     => $docFiles['type'][$i],
                    'tmp_name' => $docFiles['tmp_name'][$i],
                    'error'    => $docFiles['error'][$i],
                    'size'     => $docFiles['size'][$i],
                ];

                // Uploads to ImgBB and returns the direct image URL (throws on failure)
                $docUrl = uploadDocumentToImgBB($singleFile, $docName . ' - ' . $name);

                $documents[] = [
                    'document_name' => $docName,
                    'document_url'  => $docUrl,
                ];
            }
        }

        $documentsJson = !empty($documents) ? json_encode($documents) : null;

        // Insert new teacher (Updated with all new columns and placeholders)
        $stmt = $pdo->prepare("
            INSERT INTO 
            teachers(name, email, phone, 
            position_in_school, village, 
            post_office, police_station, 
            district, pincode, address, 
            qualification, subject_specialization, 
            joining_date, teacher_image, status,
            aadhaar_number, monthly_salary, assigned_sections,
            date_of_birth, gender, blood_group, caste_category, religion, nationality,
            father_name, father_phone, mother_name, mother_phone,
            pan_number, voter_epic_number, bank_name, bank_branch, ifsc_code, account_number,
            documents, application_date) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $name,
            $email,
            $phone,
            $position_in_school,
            $village,
            $post_office,
            $police_station,
            $district,
            $pincode,
            $address,
            $qualification,
            $subject_specialization,
            $joining_date,
            $photo,
            $status,
            $aadhaar_number,
            $monthly_salary,
            $assigned_sections,
            $date_of_birth,
            $gender,
            $blood_group,
            $caste_category,
            $religion,
            $nationality,
            $father_name,
            $father_phone,
            $mother_name,
            $mother_phone,
            $pan_number,
            $voter_epic_number,
            $bank_name,
            $bank_branch,
            $ifsc_code,
            $account_number,
            $documentsJson,
            $joining_date // application_date mirrors joining_date
        ]);

        $response['success'] = true;
        $response['message'] = 'Teacher added successfully';
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);