<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

// Check if user has permission to manage teachers
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = (int)$_POST['id'];
        $teacher_id = trim($_POST['teacher_id']);
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $address = trim($_POST['address'] ?? '');
        $qualification = trim($_POST['qualification'] ?? '');
        $subject_specialization = trim($_POST['subject_specialization'] ?? '');
        $joining_date = trim($_POST['joining_date']);
        $status = trim($_POST['status']);
        $remove_photo = isset($_POST['remove_photo']) && $_POST['remove_photo'] == 'on';

        // Validate required fields
        if (empty($teacher_id) || empty($name) || empty($email) || empty($phone) || empty($joining_date)) {
            throw new Exception('All required fields must be filled');
        }

        // Capitalize the first letter of each word in name
        $name = ucwords(strtolower($name));

        // Check if email already exists for another teacher
        $checkEmail = $pdo->prepare("SELECT id FROM teachers WHERE email = ? AND id != ?");
        $checkEmail->execute([$email, $id]);
        if ($checkEmail->rowCount() > 0) {
            throw new Exception('Email already exists for another teacher');
        }

        // Check if teacher ID already exists for another teacher
        $checkTeacherId = $pdo->prepare("SELECT id FROM teachers WHERE teacher_id = ? AND id != ?");
        $checkTeacherId->execute([$teacher_id, $id]);
        if ($checkTeacherId->rowCount() > 0) {
            throw new Exception('Teacher ID already exists for another teacher');
        }

        // Get current image info
        $currentPhoto = $pdo->prepare("SELECT teacher_image FROM teachers WHERE id = ?");
        $currentPhoto->execute([$id]);
        $currentPhotoData = $currentPhoto->fetch(PDO::FETCH_ASSOC);

        // Handle image upload/removal
        $photo = $currentPhotoData['teacher_image'];

        if ($remove_photo) {
            // Delete the existing photo file if it's not the default image
            if ($photo && $photo !== 'default_teacher_dp.jpg' && file_exists( __DIR__ . '/../../../../uploads/teachers/' . $photo)) {
                unlink( __DIR__ . '/../../../../uploads/teachers/' . $photo);
            }
            // Remove current photo
            $photo = 'default_teacher_dp.jpg';
        } elseif (!empty($_FILES['cropped_image']['tmp_name']) || !empty($_FILES['original_image']['tmp_name'])) {
            // Upload new image
            $imageFile = !empty($_FILES['cropped_image']['tmp_name'])
                ? $_FILES['cropped_image']['tmp_name']
                : $_FILES['original_image']['tmp_name'];

            if (!isValidateImageFile($imageFile)) {
                throw new Exception('You\'re trying to upload an unsupported format or currupted image.');
            }

            $photo = uniqid('tch_');

            $imageInfo = @getimagesize($imageFile);

            if ($imageInfo['mime'] === 'image/jpeg') {
                $photo .= ".jpg";
            } else {
                $photo .= ".png";
            }

            $destination =  __DIR__ . '/../../../../uploads/teachers/' . $photo;

            if (!move_uploaded_file($imageFile, $destination)) {
                throw new Exception('Failed to upload image.');
            }
        }

        // Update teacher
        $stmt = $pdo->prepare("
            UPDATE teachers SET
                teacher_id = ?,
                name = ?,
                email = ?,
                phone = ?,
                address = ?,
                qualification = ?,
                subject_specialization = ?,
                joining_date = ?,
                status = ?,
                teacher_image = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $teacher_id,
            $name,
            $email,
            $phone,
            $address,
            $qualification,
            $subject_specialization,
            $joining_date,
            $status,
            $photo,
            $id
        ]);

        $response['success'] = true;
        $response['message'] = 'Teacher updated successfully';
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
