<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

// Check if user has permission to manage teachers
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = (int)$_POST['id'];
        $status = trim($_POST['status']);

        if (!in_array($status, ['active', 'inactive'])) {
            throw new Exception('Invalid status value');
        }

        $stmt = $pdo->prepare("UPDATE teachers SET status = ? WHERE id = ?");
        $stmt->execute([$status, $id]);

        $response['success'] = true;
        $response['message'] = 'Teacher status updated successfully';
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);