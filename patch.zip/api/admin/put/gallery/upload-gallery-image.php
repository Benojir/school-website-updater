<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/imgbb-upload.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!hasPermission(PERM_MANAGE_SCHOOL_GALLERY)) {
    echo json_encode(['success' => false, 'message' => 'You do not have permission to manage photos from the gallery.']);
    exit();
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    // Check if files are uploaded
    if (!isset($_FILES['photos']) || empty($_FILES['photos']['name'][0])) {
        throw new Exception('No files uploaded or upload error');
    }

    $caption = $_POST['caption'] ?? '';
    $event_date = $_POST['event_date'] ?? date('Y-m-d');
    
    $success_count = 0;
    $errors = [];
    $total_files = count($_FILES['photos']['name']);

    // Loop through each uploaded file
    for ($i = 0; $i < $total_files; $i++) {
        if ($_FILES['photos']['error'][$i] === UPLOAD_ERR_OK) {
            $tmp_name = $_FILES['photos']['tmp_name'][$i];
            
            // Upload to ImgBB
            $upload_result = uploadToImgBB($tmp_name, $caption);
            
            if ($upload_result['success']) {
                // Insert into Database
                $stmt = $pdo->prepare("INSERT INTO gallery (photo_url, thumbnail_url, delete_url, caption, event_date) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([
                    $upload_result['url'],
                    $upload_result['thumbnail_url'],
                    $upload_result['delete_url'],
                    $caption,
                    $event_date
                ]);
                $success_count++;
            } else {
                $errors[] = "File: " . $_FILES['photos']['name'][$i] . " upload failed.";
            }
        } else {
            $errors[] = "Error with file: " . $_FILES['photos']['name'][$i];
        }
    }

    // Check if at least one file was successful
    if ($success_count > 0) {
        $message = $success_count . ' photos uploaded successfully!';
        if (count($errors) > 0) {
            $message .= ' (' . count($errors) . ' failed)';
        }
        
        echo json_encode([
            'success' => true,
            'message' => $message
        ]);
    } else {
        throw new Exception('Failed to upload any photos. ' . implode(', ', $errors));
    }

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>