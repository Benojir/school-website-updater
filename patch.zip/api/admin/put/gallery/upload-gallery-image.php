<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/imgbb-upload.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!hasPermission(PERM_MANAGE_SCHOOL_GALLERY)) {
    echo json_encode(['success' => false, 'message' => 'You do not have permission to manage photos from the gallery.']);
    exit();
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    if (!isset($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('No file uploaded or upload error');
    }

    $caption = $_POST['caption'] ?? '';
    $event_date = $_POST['event_date'] ?? date('Y-m-d');

    $upload_result = uploadToImgBB($_FILES['photo']['tmp_name'], $caption);
    
    if (!$upload_result['success']) {
        throw new Exception($upload_result['error'] ?? 'Image upload failed');
    }

    $stmt = $pdo->prepare("INSERT INTO gallery (photo_url, thumbnail_url, delete_url, caption, event_date) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([
        $upload_result['url'],
        $upload_result['thumbnail_url'],
        $upload_result['delete_url'],
        $caption,
        $event_date
    ]);

    echo json_encode([
        'success' => true,
        'message' => 'Photo uploaded successfully'
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>