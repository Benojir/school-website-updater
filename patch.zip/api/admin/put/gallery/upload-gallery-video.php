<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!hasPermission(PERM_MANAGE_SCHOOL_GALLERY)) {
    echo json_encode(['success' => false, 'message' => 'You do not have permission to manage photos from the gallery.']);
    exit();
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }


    $video_link = $_POST['video_link'] ?? '';
    $caption = safe_htmlspecialchars(trim($_POST['caption'])) ?? '';
    $event_date = safe_htmlspecialchars(trim($_POST['event_date'])) ?? date('Y-m-d');

    if (empty($video_link) || empty($caption) || empty($event_date)) {
        throw new Exception('All fields are required');
    }

    $video_id = getYouTubeVideoId($video_link);

    if (!$video_id) {
        throw new Exception('Invalid YouTube video link');
    }

    $stmt = $pdo->prepare("INSERT INTO gallery_videos (video_yt_id, video_title, event_date) VALUES (?, ?, ?)");
    $stmt->execute([
        $video_id,
        $caption,
        $event_date
    ]);

    echo json_encode([
        'success' => true,
        'message' => 'Video saved successfully'
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

// Function to extract YouTube video ID from a URL
function getYouTubeVideoId($url) {
    // Parse the URL
    $parsedUrl = parse_url($url);

    // Check host to make sure it's a YouTube URL
    if (!isset($parsedUrl['host'])) {
        return false;
    }

    $host = strtolower($parsedUrl['host']);
    $validHosts = ['youtube.com', 'www.youtube.com', 'm.youtube.com', 'youtu.be'];

    if (!in_array($host, $validHosts)) {
        return false;
    }

    // Handle different URL formats
    if (strpos($host, 'youtu.be') !== false) {
        // Short URL, e.g. https://youtu.be/VIDEO_ID
        return ltrim($parsedUrl['path'], '/');
    }

    if (!isset($parsedUrl['path'])) {
        return false;
    }

    if (strpos($parsedUrl['path'], '/watch') === 0 && isset($parsedUrl['query'])) {
        parse_str($parsedUrl['query'], $queryParams);
        if (isset($queryParams['v'])) {
            return $queryParams['v'];
        }
    }

    // For /embed/VIDEO_ID or /v/VIDEO_ID
    if (preg_match('#^/(embed|v)/([^/?&]+)#', $parsedUrl['path'], $matches)) {
        return $matches[2];
    }

    return false; // Not a valid YouTube video URL
}

?>