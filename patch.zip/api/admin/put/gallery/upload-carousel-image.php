<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");
include_once(__DIR__ . "/../../../../includes/imgbb-upload.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['user']['role'] !== 'superadmin') {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

// Check if file was uploaded
if (!isset($_FILES['carouselImage']) || $_FILES['carouselImage']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'message' => 'No file uploaded or upload error']);
    exit();
}

// Check image count
$stmt = $pdo->query("SELECT COUNT(*) FROM carousel_images");
$imageCount = $stmt->fetchColumn();
$maxImages = 10;

if ($imageCount >= $maxImages) {
    echo json_encode(['success' => false, 'message' => "Maximum $maxImages images allowed. Please delete some images first."]);
    exit();
}

// Validate file type
$allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
if (!in_array($_FILES['carouselImage']['type'], $allowedTypes)) {
    echo json_encode(['success' => false, 'message' => 'Only JPG, PNG and GIF images are allowed']);
    exit();
}

// Check file size (5MB max)
if ($_FILES['carouselImage']['size'] > 5 * 1024 * 1024) {
    echo json_encode(['success' => false, 'message' => 'Image file must be less than 5MB']);
    exit();
}

// Check image ratio (will be done client-side, but can add server-side check if needed)

// Upload to ImgBB
$uploadResult = uploadToImgBB($_FILES['carouselImage']['tmp_name'], $_POST['caption'] ?? '');

if (!$uploadResult['success']) {
    echo json_encode(['success' => false, 'message' => $uploadResult['error']]);
    exit();
}

// Save to database
try {
    $stmt = $pdo->prepare("INSERT INTO carousel_images (image_url, thumbnail_url, caption) VALUES (?, ?, ?)");
    $success = $stmt->execute([
        $uploadResult['url'],
        $uploadResult['thumbnail_url'],
        $_POST['caption'] ?? null
    ]);

    if ($success) {
        echo json_encode([
            'success' => true,
            'message' => 'Image uploaded successfully'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to save image to database']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>