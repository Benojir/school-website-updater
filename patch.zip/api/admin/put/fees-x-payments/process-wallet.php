<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'error' => true
    ]);
    die();
}

// Validate required fields in one check
$requiredFields = ['student_ids', 'wallet_action', 'wallet_amount'];
foreach ($requiredFields as $field) {
    if (empty($_POST[$field] ?? null)) {
        http_response_code(400);
        exit(json_encode([
            'success' => false,
            'message' => 'Required fields are missing.',
            'error' => true
        ]));
    }
}

// Validate and sanitize input
$studentIds = array_filter(explode(',', $_POST['student_ids']));
$walletAction = $_POST['wallet_action'];
$amount = (float)$_POST['wallet_amount'];

// Validate wallet action
if (!in_array($walletAction, ['add_funds', 'deduct_funds'])) {
    http_response_code(400);
    exit(json_encode([
        'success' => false,
        'message' => 'Invalid wallet action.',
        'error' => true
    ]));
}

// Validate amount
if ($amount <= 0) {
    http_response_code(400);
    exit(json_encode([
        'success' => false,
        'message' => 'Amount must be positive.',
        'error' => true
    ]));
}


$totalNotEffectedStudents = 0;
$pdo->beginTransaction();

try {
    foreach ($studentIds as $studentId) {
        // Get wallet information for each student
        $stmt = $pdo->prepare("SELECT * FROM student_wallet WHERE student_id = ? LIMIT 1");
        $stmt->execute([$studentId]);
        $walletInfo = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$walletInfo) {
            if ($walletAction === 'add_funds') {
                $initialBalance = $amount; // Set initial balance to the amount being added
            } else {
                $initialBalance = 0; // Set initial balance to 0 if deducting funds
                $totalNotEffectedStudents++;
            }
            $stmt = $pdo->prepare("INSERT INTO student_wallet (student_id, balance) VALUES (?, ?)");
            $stmt->execute([$studentId, $initialBalance]);

            if ($walletAction == 'add_funds' && $initialBalance > 0) {
                $walletId = $pdo->lastInsertId();
                $transaction_id = uniqid('txn_', true); // Generate a unique transaction ID
                $stmt = $pdo->prepare("INSERT INTO wallet_transactions (wallet_id, student_id, amount, transaction_type, transaction_id, description) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$walletId, $studentId, $amount, 'deposit', $transaction_id, 'Created wallet and added funds']);
            }

            continue;
        }

        $walletBalance = $walletInfo['balance'];
        $walletId = $walletInfo['id'];
        $transaction_id = uniqid('txn_', true); // Generate a unique transaction ID
        $transaction_type = $walletAction === 'add_funds' ? 'deposit' : 'withdrawal';
        $transaction_description = $walletAction === 'add_funds' ? 'Added funds to wallet' : 'Withdrew funds from wallet';

        // Update the wallet balance
        if ($walletAction === 'add_funds') {
            $newBalance = $walletBalance + $amount;
        } else {
            $newBalance = $walletBalance - $amount;
            if ($newBalance < 0) {
                // If the new balance is negative, skip this student
                $totalNotEffectedStudents++;
                continue;
            }
        }

        $stmt = $pdo->prepare("UPDATE student_wallet SET balance = ? WHERE id = ?");
        $stmt->execute([$newBalance, $walletId]);

        // Record the transaction
        $stmt = $pdo->prepare("INSERT INTO wallet_transactions (wallet_id, student_id, amount, transaction_type, transaction_id, description) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$walletId, $studentId, $amount, $transaction_type, $transaction_id, $transaction_description]);
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Wallet updated successfully.',
        'not_effected_students' => $totalNotEffectedStudents,
        'error' => false
    ]);

} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    exit(json_encode([
        'success' => false,
        'message' => 'An error occurred while processing the wallet update: ' . $e->getMessage(),
        'error' => true
    ]));
}