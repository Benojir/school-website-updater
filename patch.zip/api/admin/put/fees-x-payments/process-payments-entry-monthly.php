<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'error' => true
    ]);
    die();
}

// Check for required fields
$required = ['student_ids', 'amount', 'payment_date'];
foreach ($required as $field) {
    if (empty($_POST[$field])) {
        echo json_encode([
            'success' => false,
            'message' => 'All fields are required',
            'field' => $field
        ]);
        exit;
    }
}

try {
    $student_ids_string = sanitize_input($_POST['student_ids']);
    $provided_payment_amount = sanitize_input($_POST['amount']);
    $payment_date = sanitize_input($_POST['payment_date']);

    // Get Student IDs Array
    $studentIDs = explode(',', $student_ids_string);

    if (count($studentIDs) <= 0) {
        throw new Exception('Invalid student ids');
    }

    foreach ($studentIDs as $student_id) {
        $payment_amount = $provided_payment_amount;
        // Fetch student info
        $stmt = $pdo->prepare("SELECT * FROM students WHERE student_id = ?");
        $stmt->execute([$student_id]);

        $student_info = $stmt->fetch(PDO::FETCH_ASSOC);

        // Skip if not found or student has left
        if (!$student_info || strtolower($student_info['status']) === 'left' || strtolower($student_info['status']) === 'alumni') {
            continue;
        }

        $payment_history_remarks = [];
        $partial_payment_ids_backup = [];
        $full_paid_payment_ids = [];
        $unpaid_fee_rows_backup = [];

        // ---------------------------------------------------------
        // PART 1: CLEAR EXISTING UNPAID FEES
        // ---------------------------------------------------------
        
        $stmt = $pdo->prepare("SELECT * FROM student_unpaid_fees WHERE student_id = ? ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC");
        $stmt->execute([$student_id]);
        $unpaid_fees_data = $stmt->fetchAll();

        foreach ($unpaid_fees_data as $unpaid_fee_data) {
            // Backup the EXISTING state before modification
            $unpaid_fee_rows_backup[] = $unpaid_fee_data;

            $unpaid_fee_id = $unpaid_fee_data['id'];
            $month_year = $unpaid_fee_data['month_year'];
            $actual_amount = $unpaid_fee_data['actual_amount'];
            $remark = $unpaid_fee_data['remark'];
            $discount_amount = $unpaid_fee_data['discount_amount'];
            $unpaid_amount = $unpaid_fee_data['unpaid_amount'];

            if ($payment_amount <= 0) break;

            if ($payment_amount < $unpaid_amount) { 
                // --- Partial Payment for Existing Fee ---
                $unpaid_amount = $unpaid_amount - $payment_amount;

                $stmt = $pdo->prepare("UPDATE student_unpaid_fees SET unpaid_amount = ? WHERE id = ?");
                $stmt->execute([$unpaid_amount, $unpaid_fee_id]);

                $partial_remark = $websiteConfig['currency_symbol'] . $payment_amount . "/- has been used for fee payment " . $month_year . " from payment amount " . $websiteConfig['currency_symbol'] . $provided_payment_amount . "/- (" . $payment_date . ")";
                $payment_history_remarks[] = $websiteConfig['currency_symbol'] . $payment_amount . " used for payment " . $month_year;

                $stmt = $pdo->prepare("INSERT INTO student_partial_payments (student_id, month_year, unpaid_fees_id, partial_paid_amount, method, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$student_id, $month_year, $unpaid_fee_id, $payment_amount, 'cash', $partial_remark, $payment_date]);

                $partial_payment_ids_backup[] = $pdo->lastInsertId();
                $payment_amount = 0;
                break;
            } else {
                // --- Full Payment for Existing Fee ---
                $paid_amount = $unpaid_amount;

                $stmt = $pdo->prepare("INSERT INTO student_full_paid_fees (student_id, month_year, actual_amount, discount_amount, total_paid_amount, last_paid_amount, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
                $stmt->execute([$student_id, $month_year, $actual_amount, $discount_amount, ($actual_amount - $discount_amount), $paid_amount, $remark]);
                $full_paid_fees_id = $pdo->lastInsertId();

                $full_paid_payment_ids[] = $full_paid_fees_id;

                $partial_remark = $websiteConfig['currency_symbol'] . $paid_amount . "/- has been used for fee payment " . $month_year . " from payment amount " . $websiteConfig['currency_symbol'] . $provided_payment_amount . "/- (" . $payment_date . ")";
                $payment_history_remarks[] = $websiteConfig['currency_symbol'] . $paid_amount . " used for payment " . $month_year;

                $stmt = $pdo->prepare("INSERT INTO student_partial_payments (student_id, month_year, unpaid_fees_id, full_paid_fees_id, partial_paid_amount, method, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$student_id, $month_year, $unpaid_fee_id, $full_paid_fees_id, $paid_amount, 'cash', $partial_remark, $payment_date]);

                $partial_payment_ids_backup[] = $pdo->lastInsertId();

                $stmt = $pdo->prepare("UPDATE student_partial_payments SET full_paid_fees_id = ? WHERE unpaid_fees_id = ?");
                $stmt->execute([$full_paid_fees_id, $unpaid_fee_id]);

                $stmt = $pdo->prepare("DELETE FROM student_unpaid_fees WHERE id = ?");
                $stmt->execute([$unpaid_fee_id]);

                $payment_amount -= $unpaid_amount;
            }
        }

        // ---------------------------------------------------------
        // PART 2: ADVANCE PAYMENT (AUTO-ENTRY LOGIC)
        // ---------------------------------------------------------
        
        $transaction_id = NULL;
        $wallet_deposit_amount = 0;

        if ($payment_amount > 0) {
            
            // 1. Calculate Monthly Fee Structure for this Student
            $car_fee = $student_info['car_fee'] ?? 0;
            $hostel_fee = $student_info['hostel_fee'] ?? 0;
            $custom_class_fee = $student_info['custom_class_fee'] ?? 0;
            $class_id = $student_info['class_id'];
            
            $stmt = $pdo->prepare("SELECT amount FROM class_wise_monthly_fees WHERE class_id = ?");
            $stmt->execute([$class_id]);
            $class_fee_row = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($class_fee_row) {
                $class_fee = $custom_class_fee > 0 ? $custom_class_fee : $class_fee_row['amount'];
                
                $gen_remark = "Monthly fee";
                $includes = [];
                if ($custom_class_fee > 0) $includes[] = 'custom class fee';
                if ($car_fee > 0) $includes[] = 'car';
                if ($hostel_fee > 0) $includes[] = 'hostel';
                if ($includes) $gen_remark .= ' (included ' . implode(' and ', $includes) . ' fees)';
                $gen_remark .= " [Auto-generated]";

                $monthly_total_fee = ($class_fee + $car_fee + $hostel_fee);

                // 2. Find the Last Recorded Month
                $last_month_timestamp = 0;

                $stmt = $pdo->prepare("SELECT month_year FROM student_unpaid_fees WHERE student_id = ?");
                $stmt->execute([$student_id]);
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $ts = strtotime($row['month_year']);
                    if ($ts > $last_month_timestamp) $last_month_timestamp = $ts;
                }

                $stmt = $pdo->prepare("SELECT month_year FROM student_full_paid_fees WHERE student_id = ?");
                $stmt->execute([$student_id]);
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $ts = strtotime($row['month_year']);
                    if ($ts > $last_month_timestamp) $last_month_timestamp = $ts;
                }

                if ($last_month_timestamp == 0) {
                    $current_cursor_date = strtotime(date('F Y')); 
                } else {
                    $current_cursor_date = strtotime('+1 month', $last_month_timestamp);
                }

                // 3. Loop to create entries
                while ($payment_amount > 0) {
                    $target_month_year = date('F Y', $current_cursor_date);
                    $target_month_name = date('F', $current_cursor_date);

                    // === ACADEMIC YEAR CHECK ===
                    if ($target_month_name === 'January') {
                        break;
                    }
                    
                    // === CREATE VIRTUAL BACKUP FOR REVERSAL ===
                    // We construct a row that looks like the fee was generated but NOT paid yet.
                    // When history is deleted, the system will delete the current record and INSERT this.
                    // This ensures the invoice remains open if the payment is cancelled.
                    $virtual_backup = [
                        'student_id' => $student_id,
                        'month_year' => $target_month_year,
                        'actual_amount' => $monthly_total_fee,
                        'unpaid_amount' => $monthly_total_fee, // Full amount unpaid
                        'discount_amount' => 0,
                        'remark' => $gen_remark
                    ];
                    $unpaid_fee_rows_backup[] = $virtual_backup;

                    if ($payment_amount >= $monthly_total_fee) {
                        // === CASE A: FULL PAYMENT ===
                        $stmt = $pdo->prepare("
                            INSERT INTO student_full_paid_fees
                            (student_id, month_year, actual_amount, discount_amount, total_paid_amount, last_paid_amount, remark, created_at)
                            VALUES (?, ?, ?, 0, ?, ?, ?, NOW())
                        ");
                        $stmt->execute([$student_id, $target_month_year, $monthly_total_fee, $monthly_total_fee, $monthly_total_fee, $gen_remark]);
                        $new_full_id = $pdo->lastInsertId();
                        $full_paid_payment_ids[] = $new_full_id;

                        $partial_remark = $websiteConfig['currency_symbol'] . $monthly_total_fee . " (Advance) for " . $target_month_year;
                        $payment_history_remarks[] = $partial_remark;

                        $stmt = $pdo->prepare("INSERT INTO student_partial_payments (student_id, month_year, full_paid_fees_id, partial_paid_amount, method, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$student_id, $target_month_year, $new_full_id, $monthly_total_fee, 'cash', $partial_remark, $payment_date]);
                        $partial_payment_ids_backup[] = $pdo->lastInsertId();

                        $payment_amount -= $monthly_total_fee;

                    } else {
                        // === CASE B: PARTIAL PAYMENT ===
                        $unpaid_balance = $monthly_total_fee - $payment_amount;

                        $stmt = $pdo->prepare("
                            INSERT INTO student_unpaid_fees
                            (student_id, month_year, actual_amount, unpaid_amount, discount_amount, remark, created_at) 
                            VALUES (?, ?, ?, ?, 0, ?, NOW())
                        ");
                        $stmt->execute([$student_id, $target_month_year, $monthly_total_fee, $unpaid_balance, $gen_remark]);
                        $new_unpaid_id = $pdo->lastInsertId();
                        
                        // NOTE: We do NOT add the fetch() result to backup here anymore, 
                        // because we added the $virtual_backup above.

                        $partial_remark = $websiteConfig['currency_symbol'] . $payment_amount . " (Advance Partial) for " . $target_month_year;
                        $payment_history_remarks[] = $partial_remark;

                        $stmt = $pdo->prepare("INSERT INTO student_partial_payments (student_id, month_year, unpaid_fees_id, partial_paid_amount, method, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$student_id, $target_month_year, $new_unpaid_id, $payment_amount, 'cash', $partial_remark, $payment_date]);
                        $partial_payment_ids_backup[] = $pdo->lastInsertId();

                        $payment_amount = 0; 
                    }

                    // Move to next month
                    $current_cursor_date = strtotime('+1 month', $current_cursor_date);
                }
            }
        }

        // ---------------------------------------------------------
        // PART 3: WALLET DEPOSIT
        // ---------------------------------------------------------
        
        if ($payment_amount > 0) {
            $wallet_deposit_amount = $payment_amount;
            
            $stmt = $pdo->prepare("SELECT * FROM student_wallet WHERE student_id = ?");
            $stmt->execute([$student_id]);
            $student_wallet = $stmt->fetch(PDO::FETCH_ASSOC);

            $wallet_id = null;
            $transaction_type = 'deposit';
            $transaction_id = uniqid('tran');
            $description = 'Credited to wallet (Excess Payment / Next Academic Year)';

            try {
                if (!$student_wallet) {
                    $stmt = $pdo->prepare("INSERT INTO student_wallet(student_id, balance) VALUES (?, ?)");
                    $stmt->execute([$student_id, $wallet_deposit_amount]);
                    $wallet_id = $pdo->lastInsertId();
                } else {
                    $wallet_id = $student_wallet['id'];
                    $new_balance = $student_wallet['balance'] + $wallet_deposit_amount;
                    $stmt = $pdo->prepare("UPDATE student_wallet SET balance = ? WHERE id = ?");
                    $stmt->execute([$new_balance, $wallet_id]);
                }

                $stmt = $pdo->prepare("
                    INSERT INTO wallet_transactions
                    (wallet_id, student_id, amount, transaction_type, transaction_id, description) 
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$wallet_id, $student_id, $wallet_deposit_amount, $transaction_type, $transaction_id, $description]);

                $payment_history_remarks[] = $websiteConfig['currency_symbol'] . $wallet_deposit_amount . " credited to wallet";
            } catch (Exception $e) {
                // Log error
            }
        }

        // Insert payment history
        $payment_history_remark = implode(' & ', $payment_history_remarks);

        $stmt = $pdo->prepare("
            INSERT INTO student_payment_history
            (
            student_id, 
            payment_amount, 
            payment_date, 
            remark, 
            full_paid_payment_ids, 
            partial_payment_ids_backup,
            wallet_affected_balance,
            wallet_transaction_id,
            unpaid_fee_rows_backup
            ) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $student_id,
            $provided_payment_amount,
            $payment_date,
            $payment_history_remark,
            json_encode($full_paid_payment_ids),
            json_encode($partial_payment_ids_backup),
            $wallet_deposit_amount,
            $transaction_id,
            json_encode($unpaid_fee_rows_backup)
        ]);
    }

    echo json_encode([
        'success' => true,
        'message' => 'Payment updated successfully.'
    ]);

    try {
        // Get FCM tokens for all processed students
        $fcmTokens = getFCMTokensFromDatabase($pdo, $studentIDs);
        if ($fcmTokens) {
            $notificationTitle = 'Payment Update';
            $notificationBody = 'Your payment has been processed successfully.';
            $data = [
                'title' => $notificationTitle,
                'message' => $notificationBody
            ];
            sendFirebaseNotification($pdo, $studentIDs, $fcmTokens, $notificationTitle, $notificationBody, $data);
        }
    } catch (Exception $e) {
        // Log the error if needed
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}