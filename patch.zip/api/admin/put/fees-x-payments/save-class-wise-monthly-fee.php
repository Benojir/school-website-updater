<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // class_id will come as an array
        $class_ids = isset($_POST['class_id']) ? $_POST['class_id'] : [];
        $amount = isset($_POST['amount']) ? trim($_POST['amount']) : 0;

        // Validate inputs
        if (empty($amount) || empty($class_ids) || !is_array($class_ids)) {
            throw new Exception('Please fill in all fields and select at least one class.');
        }

        $success_count = 0;
        $error_messages = [];

        // Begin transaction
        $pdo->beginTransaction();

        foreach ($class_ids as $class_id) {
            $class_id = (int)$class_id;

            // Get class name
            $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
            $stmt->execute([$class_id]);
            $class = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$class) {
                $error_messages[] = "Invalid class ID: $class_id";
                continue; 
            }

            $class_name = $class['class_name'];

            // Check for duplicate entry
            $check = $pdo->prepare("SELECT id FROM class_wise_monthly_fees WHERE class_id = ?");
            $check->execute([$class_id]);

            if ($check->rowCount() > 0) {
                $error_messages[] = "Fee already exists for $class_name.";
                continue;
            }

            // Insert new fee
            $insert = $pdo->prepare("INSERT INTO class_wise_monthly_fees (class_id, amount) VALUES (?, ?)");
            if ($insert->execute([$class_id, $amount])) {
                $success_count++;
            } else {
                $error_messages[] = "Failed to add fee for $class_name.";
            }
        }

        // If at least one insertion was successful
        if ($success_count > 0) {
            $pdo->commit();
            $response['success'] = true;
            $msg = "$success_count class fee(s) added successfully.";
            
            // Append error messages if some classes failed
            if (!empty($error_messages)) {
                $msg .= " However, some issues occurred: " . implode(" | ", $error_messages);
            }
            $response['message'] = $msg;
        } else {
            $pdo->rollBack();
            throw new Exception(implode("<br>", $error_messages));
        }

    } else {
        throw new Exception('Invalid request method.');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);