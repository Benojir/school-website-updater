<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        $class_id = isset($_POST['class_id']) ? (int)$_POST['class_id'] : 0;
        $amount = isset($_POST['amount']) ? trim(safe_htmlspecialchars($_POST['amount'])) : 0;
        $school_fee_type = isset($_POST['fee_type']) ? ucwords(trim(safe_htmlspecialchars($_POST['fee_type']))) : '';

        // Validate inputs
        if (empty($amount) || empty($class_id) || empty($school_fee_type)) {
            throw new Exception('Please fill in all fields');
        }

        $table_name = "class_wise_additional_fees";

        // Check valid class
        $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
        $stmt->execute([$class_id]);
        $class = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$class) {
            throw new Exception('Invalid class selected');
        }

        // Insert new subject
        $insert = $pdo->prepare("INSERT INTO `{$table_name}` (class_id, amount, fee_type) VALUES (?, ?, ?)");
        if ($insert->execute([$class_id, $amount, $school_fee_type])) {
            $response['success'] = true;
            $response['message'] = "Additional fee added successfully!";
        } else {
            throw new Exception('Failed to add additional fee into database');
        }
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
