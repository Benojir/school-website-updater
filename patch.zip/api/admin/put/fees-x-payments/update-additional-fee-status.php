<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$additional_fee_id = $_POST['additional_fee_id'] ?? null;
$new_status = $_POST['new_status'] ?? null;
$student_id = $_POST['student_id'] ?? null;

if (!$additional_fee_id || !$new_status || !$student_id) {
    echo json_encode(array(
        "success" => false,
        "message" => "Missing required parameters.",
        "error" => "Missing parameters: additional_fee_id, new_status, student_id"
    ));
    exit();
}

if ($new_status != "paid" && $new_status != "unpaid") {
    echo json_encode(array(
        "success" => false,
        "message" => "Invalid status.",
        "error" => "Status must be 'paid' or 'unpaid' but got $new_status."
    ));
    exit();
}

$date_column = "additional_fee_paid_date";
if ($new_status == "unpaid") {
    $date_column = "additional_fee_due_date";
}

try {
    $today_date = date("Y-m-d");
    $sql = "UPDATE additional_fees_data SET additional_fee_status = :new_status, $date_column = NOW() WHERE additional_fee_setup_id = :additional_fee_id AND student_id = :student_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array(
        ":new_status" => $new_status,
        ":additional_fee_id" => $additional_fee_id,
        ":student_id" => $student_id
    ));

    if ($stmt->rowCount() == 0) {
        echo json_encode(array(
            "success" => false, 
            "message" => "No additional fee found with the given ID and student ID.",
            "error" => "Student ID: $student_id, Additional Fee ID: $additional_fee_id New Status: $new_status"
        ));
        exit();
    }
    echo json_encode(array("success" => true, "message" => "Additional fee status updated successfully."));
} catch (Exception $e) {
    echo json_encode(array(
        "success" => false, 
        "message" => "Error updating additional fee status.",
        "error" => $e->getMessage()
    ));
    exit();
}