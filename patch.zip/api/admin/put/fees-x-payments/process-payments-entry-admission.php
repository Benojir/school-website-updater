<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/financial/fun-admission-payments-entry.php");

header('Content-Type: application/json');

// Check if user has permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode(['success' => false, 'message' => 'You do not have permission.', 'error' => true]);
    die();
}

$adminAuthData = getAuthenticatedAdmin($pdo);
$adminUserId = $adminAuthData['user_id'];

// Sanitize and retrieve POST data
$rawInput = file_get_contents("php://input");
parse_str($rawInput, $params);

if (isset($params['students_data'])) {
    $students_data = json_decode($params['students_data'], true);

    if (json_last_error() === JSON_ERROR_NONE) {

        $errors = [];
        $skips = [];
        $successes = [];

        foreach ($students_data as $data) {

            $student_id = isset($data['studentId']) ? trim($data['studentId']) : null;
            $student_name = isset($data['studentName']) ? trim($data['studentName']) : 'Unknown';
            $amount = $data['paymentAmount'] ?? null;
            $payment_date = $data['paymentDate'] ?? null;

            if (!$student_id || !$amount || !$payment_date) {
                $errors[] = "Missing required data for student: $student_name (ID: $student_id)";
                continue;
            }

            if (!is_numeric($amount) || $amount < 0) {
                $errors[] = "Invalid payment amount for student: $student_name (ID: $student_id)";
                continue;
            }

            try {
                $result = processSingleStudentAdmissionPayment($pdo, $student_id, $amount, $payment_date, $adminUserId);

                if ($result['success']) {
                    $successes[] = [
                        'student_name' => $student_name,
                        'message' => 'Successfully proccessed.',
                        'payment_amount' => $amount,
                        'wallet_credit' => $result['wallet_credit']
                    ];
                } else {
                    $skips[] = [
                        'student_name' => $student_name,
                        'reason' => $result['message']
                    ];
                }

            } catch (\Exception $e) {
                $errors[] = $e->getMessage();
            }
        }

        $build_response = [
            'success' => true,
            'message' => 'Admission payments entry processed successfully.',
            'errors' => $errors,
            'skips' => $skips,
            'successes' => $successes
        ];

        echo json_encode($build_response);
        
    } else {
        echo json_encode(["success" => false, "message" => "Invalid JSON format"]);
    }

} else {
    echo json_encode(["success" => false, "message" => "No data received"]);
}

?>