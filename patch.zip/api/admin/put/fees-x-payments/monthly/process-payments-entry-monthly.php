<?php
include_once(__DIR__ . "/../../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../../includes/financial/fun-monthly-payments-entry.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'error' => true
    ]);
    die();
}

$adminAuthData = getAuthenticatedAdmin($pdo);
$adminId = $adminAuthData['user_id'];

$students_payment_data = $_REQUEST['students_payment_data'] ?? [];

if (empty($students_payment_data)) {
    echo json_encode([
        'success' => false,
        'message' => 'No student payment data provided.'
    ]);
    die();
}

try {

    $payments_data = json_decode($students_payment_data, true);

    $studentIDs = [];
    $success_processed = [];
    $failed_processed = [];
    $payment_history_ids = [];

    foreach ($payments_data as $data) {
        $student_name = $data['student_name'];
        $student_id = $data['student_id'];
        $payment_amount = $data['payment_amount'];
        $payment_date = $data['payment_date'];

        if (!is_numeric($payment_amount) || $payment_amount < 0) {
            $failed_processed[] = [
                'student_name' => $student_name,
                'message' => 'Invalid payment amount',
                'payment_amount' => $payment_amount,
                'wallet_credit' => 0
            ];
            continue;
        }

        $result = processSingleStudentPayment($pdo, $student_id, $payment_amount, $payment_date, $adminId);

        if ($result['success']) {
            $success_processed[] = [
                'student_name' => $student_name,
                'message' => $result['message'],
                'payment_amount' => $payment_amount,
                'wallet_credit' => $result['wallet_credited']
            ];

            $studentIDs[] = $student_id;
            $payment_history_ids[] = $result['payment_history_id'];
        } else {
            $failed_processed[] = [
                'student_name' => $student_name,
                'message' => $result['message'],
                'payment_amount' => $payment_amount,
                'wallet_credit' => $result['wallet_credited']
            ];
        }
    }

    try {
        // Get FCM tokens for all processed students
        $fcmTokens = getFCMTokensFromDatabase($pdo, $studentIDs);
        if ($fcmTokens && !empty($studentIDs)) {
            $notificationTitle = 'Payment Update';
            $notificationBody = 'Your payment has been processed successfully.';
            $data = [
                'title' => $notificationTitle,
                'message' => $notificationBody
            ];
            sendFirebaseNotification($pdo, $studentIDs, $fcmTokens, $notificationTitle, $notificationBody, $data);
        }
    } catch (Exception $e) {
        // Log the error if needed
    }

    echo json_encode([
        'success' => true,
        'message' => 'Payments processed successfully.',
        'success_processed' => $success_processed,
        'failed_processed' => $failed_processed,
        'payment_history_ids' => $payment_history_ids
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error processing payments: ' . $e->getMessage()
    ]);
}
