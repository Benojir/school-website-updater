<?php
/** @var PDO $pdo
 * @var array $additional_website_configs
 * @var array $websiteConfig
 */
// NOTE: Ensure auth-check.php allows CLI/Cron execution. 
// Standard session checks will fail in a cron context unless handled.
include_once __DIR__ . "/../../../../../includes/auth-check.php";
include_once __DIR__ . "/../../../../../includes/phpmailer.php";

header('Content-Type: application/json');

if ($additional_website_configs['auto_request_monthly_fees'] !== 1) {
    echo json_encode(['success' => false, 'message' => 'Auto Request Monthly Fees is disabled.']);
    exit();
}

if (date('j') !== $websiteConfig['auto_request_monthly_fees_day']) {
    echo json_encode(['success' => false, 'message' => 'Auto Request Monthly Fees is not scheduled for today.']);
    exit();
}

// Ensure currency_symbol is set if not coming from auth-check.php
$currency_symbol = $currency_symbol ?? '₹'; 

// Build the Email Meta
$senderName = 'Automated Fee Requester';
$recipientAddress = $schoolInfo['email'] ?? 'mr.nuralam.com@gmail.com'; // Fallback added
$recipientName = $schoolInfo['principal_name'] ?? 'Principal';
$subject = 'Monthly Fee Generation Report - ' . date("F Y");

$results = [];
$processedCount = 0;
$skippedCount = 0;
$processedStudentIds = [];

$month_year = date("F Y");

try {
    // OPTIMIZATION: Fetch all valid student data in one go to prevent N+1 queries
    $stmt = $pdo->prepare("
        SELECT s.*, c.class_name 
        FROM students s 
        JOIN classes c ON s.class_id = c.id 
        WHERE LOWER(s.status) NOT IN ('left', 'alumni')
    ");
    $stmt->execute();
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($students as $student_info) {
        $student_id = $student_info['student_id'];
        $pdo->beginTransaction();

        try {
            $car_fee = $student_info['car_fee'] ?? 0;
            $hostel_fee = $student_info['hostel_fee'] ?? 0;
            $coaching_fee = $student_info['coaching_fee'] ?? 0; // Added Coaching Fee
            $tiffin_fee = $student_info['tiffin_fee'] ?? 0;     // Added Tiffin Fee
            $custom_class_fee = $student_info['custom_class_fee'] ?? 0;
            $class_id = $student_info['class_id'];
            $class_name = $student_info['class_name'];
            
            // FIX: Initialize discount (modify if you have a default discount column)
            $discount = $student_info['monthly_discount'] ?? 0; 
            
            $remark = $class_name . " monthly fees";

            if ($discount > 0) {
                $remark .= ' with ' . $currency_symbol . $discount . ' discount applied ';
            }

            // Fetch class-wise fee
            $stmtClass = $pdo->prepare("SELECT amount FROM class_wise_monthly_fees WHERE class_id = ?");
            $stmtClass->execute([$class_id]);
            $class_fee_row = $stmtClass->fetch(PDO::FETCH_ASSOC);

            if (!$class_fee_row && $custom_class_fee <= 0) {
                $results[] = [
                    'student_id' => $student_id,
                    'name' => $student_info['name'],
                    'success' => false,
                    'message' => 'Class monthly fee not setup.',
                    'action' => 'skipped'
                ];
                $skippedCount++;
                $pdo->rollBack(); 
                continue;
            }

            $class_fee = $custom_class_fee > 0 ? $custom_class_fee : $class_fee_row['amount'];

            // Build remark based on fees
            $includes = [];
            if ($custom_class_fee > 0) $includes[] = 'custom class (' . $currency_symbol . $custom_class_fee . ')';
            if ($car_fee > 0) $includes[] = 'car (' . $currency_symbol . $car_fee . ')';
            if ($hostel_fee > 0) $includes[] = 'hostel (' . $currency_symbol . $hostel_fee . ')';
            if ($coaching_fee > 0) $includes[] = 'coaching (' . $currency_symbol . $coaching_fee . ')'; // Added Coaching Fee
            if ($tiffin_fee > 0) $includes[] = 'tiffin (' . $currency_symbol . $tiffin_fee . ')';       // Added Tiffin Fee

            if (!empty($includes)) {
                $remark .= ' [included ' . implode(' and ', $includes) . ' fees]';
            }

            // Calculate total fees
            $actual_fees = ($class_fee + $car_fee + $hostel_fee + $coaching_fee + $tiffin_fee);
            $offer_fee = $actual_fees - $discount;

            if ($discount > 0 && $actual_fees <= $discount) {
                $results[] = [
                    'student_id' => $student_id,
                    'name' => $student_info['name'],
                    'success' => false,
                    'message' => "Discount exceeds total fees.",
                    'action' => 'skipped'
                ];
                $skippedCount++;
                $pdo->rollBack(); 
                continue;
            }

            // Check if this month's fee already exists in full_paid_fees
            $stmtPaid = $pdo->prepare("SELECT id FROM student_full_paid_fees WHERE student_id = ? AND month_year = ?");
            $stmtPaid->execute([$student_id, $month_year]);
            if ($stmtPaid->fetch()) {
                $results[] = [
                    'student_id' => $student_id,
                    'name' => $student_info['name'],
                    'success' => false,
                    'message' => "Already marked as fully paid.",
                    'action' => 'skipped'
                ];
                $skippedCount++;
                $pdo->rollBack(); 
                continue;
            }

            // Check for existing unpaid fee for this month
            $stmtUnpaid = $pdo->prepare("SELECT id FROM student_unpaid_fees WHERE student_id = ? AND month_year = ? LIMIT 1");
            $stmtUnpaid->execute([$student_id, $month_year]);
            
            if ($stmtUnpaid->fetch()) {
                $results[] = [
                    'student_id' => $student_id,
                    'name' => $student_info['name'],
                    'success' => false,
                    'message' => "Unpaid fee record already exists.",
                    'action' => 'skipped'
                ];
                $skippedCount++;
                $pdo->rollBack();
                continue;
            } else {
                // Insert new record
                $insertStmt = $pdo->prepare("
                        INSERT INTO student_unpaid_fees
                        (student_id, month_year, actual_amount, unpaid_amount, discount_amount, remark, created_at) 
                        VALUES (?, ?, ?, ?, ?, ?, NOW())
                    ");
                $insertStmt->execute([
                    $student_id,
                    $month_year,
                    $actual_fees,
                    $offer_fee,
                    $discount,
                    $remark
                ]);

                $action = 'created';
                $processedStudentIds[] = $student_id;
            }

            $results[] = [
                'student_id' => $student_id,
                'name' => $student_info['name'],
                'success' => true,
                'message' => "Generated successfully.",
                'action' => $action
            ];

            $pdo->commit();
            $processedCount++; 
            
        } catch (Exception $e) {
            $pdo->rollBack();
            $results[] = [
                'student_id' => $student_id,
                'name' => $student_info['name'] ?? 'Unknown',
                'success' => false,
                'message' => "DB Error: " . $e->getMessage(),
                'action' => 'error'
            ];
            $skippedCount++;
        }
    }

    // Send Firebase Notifications
    if (count($processedStudentIds) > 0) {
        $fcmTokens = getFCMTokensFromDatabase($pdo, $processedStudentIds);
        if ($fcmTokens) {
            $notificationTitle = 'Payment Reminder';
            $notificationBody = "Your monthly fee for $month_year has been generated. Please check your account.";
            $data = ['title' => $notificationTitle, 'message' => $notificationBody];
            try {
                sendFirebaseNotification($pdo, $processedStudentIds, $fcmTokens, $notificationTitle, $notificationBody, $data);
            } catch (Exception $e) {
                // Ignore notification failure so cron doesn't crash
            }
        }
    }

} catch (Exception $e) {
    $results[] = ['name' => 'SYSTEM SCRIPT ERROR', 'student_id' => 'N/A', 'success' => false, 'action' => 'FATAL', 'message' => $e->getMessage()];
}

// -----------------------------------------------------
// BUILD HTML EMAIL REPORT (Using Inline CSS for Email)
// -----------------------------------------------------
$totalStudents = $processedCount + $skippedCount;

$htmlBody = "
<div style='font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; color: #333;'>
    <h2 style='color: #0d6efd; border-bottom: 2px solid #eee; padding-bottom: 10px;'>Automated Fee Generation Report</h2>
    <p><strong>Month/Year:</strong> {$month_year}</p>
    
    <div style='background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin-bottom: 20px; display: flex; gap: 20px;'>
        <div style='background: #fff; padding: 10px 20px; border: 1px solid #ddd; border-radius: 5px;'><strong>Total:</strong> {$totalStudents}</div>
        <div style='background: #e6f8ec; padding: 10px 20px; border: 1px solid #c3e6cb; border-radius: 5px; color: #155724;'><strong>Processed:</strong> {$processedCount}</div>
        <div style='background: #fdf3f4; padding: 10px 20px; border: 1px solid #f5c6cb; border-radius: 5px; color: #721c24;'><strong>Skipped:</strong> {$skippedCount}</div>
    </div>

    <table style='width: 100%; border-collapse: collapse; font-size: 14px;'>
        <thead>
            <tr style='background-color: #343a40; color: #fff; text-align: left;'>
                <th style='padding: 10px; border: 1px solid #ddd;'>Student Details</th>
                <th style='padding: 10px; border: 1px solid #ddd;'>Status</th>
                <th style='padding: 10px; border: 1px solid #ddd;'>Remarks</th>
            </tr>
        </thead>
        <tbody>";

if (!empty($results)) {
    foreach ($results as $res) {
        $statusColor = $res['success'] ? '#28a745' : '#dc3545';
        $statusBg = $res['success'] ? '#ffffff' : '#fdf3f4';
        $actionText = strtoupper($res['action']);

        $htmlBody .= "
            <tr style='background-color: {$statusBg};'>
                <td style='padding: 10px; border: 1px solid #ddd;'>
                    <strong>{$res['name']}</strong><br>
                    <span style='color: #666; font-size: 12px;'>ID: {$res['student_id']}</span>
                </td>
                <td style='padding: 10px; border: 1px solid #ddd; color: {$statusColor}; font-weight: bold;'>
                    {$actionText}
                </td>
                <td style='padding: 10px; border: 1px solid #ddd; color: #555;'>
                    {$res['message']}
                </td>
            </tr>";
    }
} else {
    $htmlBody .= "<tr><td colspan='3' style='padding: 15px; text-align: center; border: 1px solid #ddd;'>No students found to process.</td></tr>";
}

$htmlBody .= "
        </tbody>
    </table>
    <p style='margin-top: 20px; font-size: 12px; color: #888; text-align: center;'>This is an automated message from your School Management System.</p>
</div>";

// Plain text alternative for email clients that block HTML
$altBody = "Automated Fee Report for $month_year\n";
$altBody .= "Total: $totalStudents | Processed: $processedCount | Skipped: $skippedCount\n";
$altBody .= "Check your admin dashboard for more details.";

// Send the Email
sendMail($senderName, $recipientAddress, $recipientName, $subject, $htmlBody, $altBody);

// Output JSON for the cron log (optional, but good for tracking script execution)
echo json_encode([
    'success' => true,
    'month' => $month_year,
    'total' => $totalStudents,
    'processed' => $processedCount,
    'skipped' => $skippedCount,
    'email_sent_to' => $recipientAddress
]);