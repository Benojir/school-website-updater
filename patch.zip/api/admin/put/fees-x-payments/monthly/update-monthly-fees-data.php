<?php
/** @var PDO $pdo 
 * @var string $currency_symbol
*/
include_once __DIR__ . "/../../../../../includes/auth-check.php";

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_FEES)) {
    die(json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]));
}

$financialData = $_POST['financialData'] ?? null;

if (empty($financialData)) {
    die(json_encode([
        'success' => false,
        'message' => 'No data provided.'
    ]));
}

$data = json_decode($financialData, true);

try {
    $student_id = $data['studentId'];
    $class_fee = $data['classFee'] ?? 0;
    $custom_class_fee = $data['customClassFee'] ?? 0;
    $car_fee = $data['carFee'] ?? 0;
    $hostel_fee = $data['hostelFee'] ?? 0;
    $selected_months = $data['selectedMonths'] ?? [];
    $permanent_change = $data['permanentChange'] ?? false;

    $monthly_fee = ($custom_class_fee > 0 ? $custom_class_fee : $class_fee) + $car_fee + $hostel_fee;

    $response = [
        "success" => true,
        "message" => "Monthly fees updated successfully.",
        'permanently_changed' => $permanent_change,
        'skipped_months' => [],
        'updated_months' => []
    ];

    if ($permanent_change) {
        $stmt = $pdo->prepare("UPDATE students SET custom_class_fee = :custom_class_fee, car_fee = :car_fee, hostel_fee = :hostel_fee WHERE student_id = :student_id");
        $stmt->execute([
            ':custom_class_fee' => $custom_class_fee,
            ':car_fee' => $car_fee,
            ':hostel_fee' => $hostel_fee,
            ':student_id' => $student_id
        ]);
    }

    if (count($selected_months) > 0) {
        foreach ($selected_months as $month_year) {
            $stmt = $pdo->prepare("SELECT * FROM student_unpaid_fees WHERE student_id = :student_id AND month_year = :month_year");
            $stmt->execute([
                ':student_id' => $student_id,
                ':month_year' => $month_year
            ]);

            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$result) {
                $response['skipped_months'][] = [
                    'month_year' => $month_year,
                    'reason' => 'No record found for this month.'
                ];
                continue;
            }

            if ($result) {
                $actual_amount = $result['actual_amount'];
                $pending_amount = $result['unpaid_amount'];
                $discount_amount = $result['discount_amount'];
                $offer_amount = $actual_amount - $discount_amount;
                $total_partial_payment = $offer_amount - $pending_amount;

                if ($monthly_fee <= 0) {
                    $response['skipped_months'][] = [
                        'month_year' => $month_year,
                        'reason' => 'New monthly fee is less than or equal to 0.'
                    ];
                    continue;
                }

                if ($monthly_fee == $actual_amount) {
                    $response['skipped_months'][] = [
                        'month_year' => $month_year,
                        'reason' => 'New monthly fee is equal to the old monthly amount. Skipping.'
                    ];
                    continue;
                }

                if ($monthly_fee <= $total_partial_payment) {
                    $response['skipped_months'][] = [
                        'month_year' => $month_year,
                        'reason' => 'New monthly fee is less than or equal to the total partial payment.'
                    ];
                    continue;
                }

                $new_offer_amount = $monthly_fee - $discount_amount;
                $new_pending_amount = $new_offer_amount - $total_partial_payment;

                if ($new_pending_amount <= 0) {
                    $response['skipped_months'][] = [
                        'month_year' => $month_year,
                        'reason' => 'New pending amount is less than or equal to 0.'
                    ];
                    continue;
                }

                if ($new_offer_amount <= 0) {
                    $response['skipped_months'][] = [
                        'month_year' => $month_year,
                        'reason' => 'New offer amount is less than or equal to 0.'
                    ];
                    continue;
                }

                $stmt = $pdo->prepare("UPDATE student_unpaid_fees SET actual_amount = :actual_amount, unpaid_amount = :unpaid_amount WHERE student_id = :student_id AND month_year = :month_year");
                $stmt->execute([
                    ':actual_amount' => $monthly_fee,
                    ':unpaid_amount' => $new_pending_amount,
                    ':student_id' => $student_id,
                    ':month_year' => $month_year
                ]);

                $response['updated_months'][] = [
                    'month_year' => $month_year,
                    'actual_amount' => $monthly_fee,
                    'unpaid_amount' => $new_pending_amount
                ];
            }
        }
    }

    echo json_encode($response);
    exit();
    
} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "An error occurred. Error: " . $e->getMessage()
    ]);
    exit();
}