<?php
/** @var PDO $pdo 
 * @var string $currency_symbol
*/
include_once __DIR__ . "/../../../../../includes/auth-check.php";

require_once __DIR__ . '/../../../../../includes/academic/academic-context.php';

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_FEES)) {
    die(json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]));
}

// Check for required fields
$studentsFeeData = $_POST['studentsFeeData'] ?? null;

$studentsFeeData = json_decode($studentsFeeData, true);

if (empty($studentsFeeData) || !is_array($studentsFeeData)) {
    die(json_encode([
        'success' => false,
        'message' => 'No data provided.'
    ]));
}

try {
    $results = [];
    $processedCount = 0;
    $skippedCount = 0;
    $last_proccessed_sid = null;
    $processedStudentIds = [];

    foreach ($studentsFeeData as $feeData) {
        // FIX 1: Match the JS key 'studentId'
        $student_id = $feeData['studentId'] ?? null; 
        
        // FIX 2: Ensure it's an array to prevent foreach fatal errors
        $month_year_array = isset($feeData['monthYear']) && is_array($feeData['monthYear']) ? $feeData['monthYear'] : [];

        if (!$student_id || empty($month_year_array)) {
            $results[] = [
                'student_id' => $student_id,
                'month_year' => '',
                'name' => $feeData['studentName'] ?? null,
                'success' => false,
                'message' => 'Missing required parameters. Entry skipped. Months: ' . implode(', ', $month_year_array) . 'Student ID: ' . $student_id,
                'action' => 'skipped'
            ];
            $skippedCount++;
            continue; // Skip if no student ID or no months selected
        }

        foreach ($month_year_array as $month_year) {
            // Start transaction for each student/month combination
            $pdo->beginTransaction();

            try {
                // Fetch student info
                $billingYear = academicBillingYear((string)$month_year);
                if (!empty($feeData['academicYear']) && academicNormalizeYear($feeData['academicYear']) !== $billingYear) {
                    throw new InvalidArgumentException('Select billing months from the academic year displayed on this form.');
                }
                academicRequireCurrentYear($pdo);
                $student_info = academicGetStudent($pdo, $student_id, $billingYear);
                
                // FIX 5: Safely get the name for error reporting
                $student_name = $student_info ? $student_info['name'] : "ID: $student_id";

                // Skip if not found or student has left
                if (!$student_info || strtolower($student_info['status']) === 'left' || strtolower($student_info['status']) === 'alumni') {
                    $results[] = [
                        'student_id' => $student_id,
                        'month_year' => $month_year,
                        'name' => $student_name,
                        'success' => false,
                        'message' => 'No eligible enrollment exists for this billing year. Entry (' . $month_year . ') skipped.',
                        'action' => 'skipped'
                    ];
                    $skippedCount++;
                    $pdo->rollBack(); // Use rollback since we aren't saving anything
                    continue;
                }

                $carFee = $feeData['carFee'] ?? 0;
                $hostelFee = $feeData['hostelFee'] ?? 0;
                $coachingFee = $feeData['coachingFee'] ?? 0; // Added Coaching Fee
                $tiffinFee = $feeData['tiffinFee'] ?? 0;     // Added Tiffin Fee
                $offerFee = $feeData['offerAmount'] ?? 0;
                $actualFee = $feeData['actualFee'] ?? 0;
                $discount = $feeData['discountAmount'] ?? 0;

                // Check if the fee data is valid and numeric
                if (!is_numeric($carFee) || !is_numeric($hostelFee) || !is_numeric($coachingFee) || !is_numeric($tiffinFee) || !is_numeric($offerFee) || !is_numeric($actualFee) || !is_numeric($discount)) {
                    $results[] = [
                        'student_id' => $student_id,
                        'month_year' => $month_year,
                        'name' => $student_name,
                        'success' => false,
                        'message' => 'Invalid fee data. Entry (' . $month_year . ') skipped because of invalid amount.',
                        'action' => 'skipped'
                    ];
                    $skippedCount++;
                    $pdo->rollBack();
                    continue;
                }

                // Fetch class-wise fee
                // FIX 3: Consistent variable naming
                $class_id = $student_info['class_id']; 
                $class_name = $student_info['class_name'];
                // Amounts on this form are explicitly reviewed by the admin. Do not
                // reconstruct historical or future fees from today's class tariff.

                $remark = "Class " . $class_name . " monthly fees";

                if ($discount > 0) {
                    $remark .= ' with ' . $currency_symbol . $discount . ' discount applied';
                }

                // Build remark based on fees
                $includes = [];
                if ($carFee > 0) $includes[] = 'car (' . $currency_symbol . $carFee . ')';
                if ($hostelFee > 0) $includes[] = 'hostel (' . $currency_symbol . $hostelFee . ')';
                if ($coachingFee > 0) $includes[] = 'coaching (' . $currency_symbol . $coachingFee . ')'; // Added Coaching Fee
                if ($tiffinFee > 0) $includes[] = 'tiffin (' . $currency_symbol . $tiffinFee . ')';       // Added Tiffin Fee

                if (!empty($includes)) {
                    $remark .= ' (included ' . implode(' and ', $includes) . ' fees)';
                }

                // Calculate total fees
                // FIX 4: Corrected variable name from $actual_fees to $actualFee
                if ($discount > 0 && $actualFee <= $discount) {
                    $results[] = [
                        'student_id' => $student_id,
                        'month_year' => $month_year,
                        'name' => $student_name,
                        'success' => false,
                        'message' => "Discount of $discount exceeds or equals the total fees of $actualFee. Entry ($month_year) skipped.",
                        'action' => 'skipped'
                    ];
                    $skippedCount++;
                    $pdo->rollBack();
                    continue;
                }

                // Check if actual fee or offer fee less than or equal 0
                if ($actualFee <= 0 || $offerFee <= 0) {
                    $results[] = [
                        'student_id' => $student_id,
                        'month_year' => $month_year,
                        'name' => $student_name,
                        'success' => false,
                        'message' => "Actual fee or offer fee is less than or equal to 0. Entry ($month_year) skipped.",
                        'action' => 'skipped'
                    ];
                    $skippedCount++;
                    $pdo->rollBack();
                    continue;
                }

                // Check if this month's fee already exists in full_paid_fees
                $stmt = $pdo->prepare("SELECT id FROM student_full_paid_fees WHERE student_id = ? AND month_year = ?");
                $stmt->execute([$student_id, $month_year]);
                if ($stmt->fetch()) {
                    $results[] = [
                        'student_id' => $student_id,
                        'month_year' => $month_year,
                        'name' => $student_name,
                        'success' => false,
                        'message' => "Fee for $month_year already marked as fully paid",
                        'action' => 'skipped'
                    ];
                    $skippedCount++;
                    $pdo->rollBack();
                    continue;
                }

                // Check for existing unpaid fee for this month
                $stmt = $pdo->prepare("SELECT * FROM student_unpaid_fees WHERE student_id = ? AND month_year = ? LIMIT 1");
                $stmt->execute([$student_id, $month_year]);
                $existing_fee = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($existing_fee) {
                    // Fetch the partial payments for this month
                    $stmt = $pdo->prepare("SELECT * FROM student_partial_payments WHERE student_id = ? AND month_year = ?");
                    $stmt->execute([$student_id, $month_year]);
                    $partial_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    $total_partial_payments = 0;
                    foreach ($partial_payments as $partial_payment) {
                        $total_partial_payments += $partial_payment['partial_paid_amount'];
                    }

                    $pending_amount = $offerFee - $total_partial_payments;

                    if ($pending_amount <= 0) {
                        $results[] = [
                            'student_id' => $student_id,
                            'month_year' => $month_year,
                            'name' => $student_name,
                            'success' => false,
                            'message' => "Unpaid fee request for $month_year has been skipped because total partial payments ($total_partial_payments) exceed the remaining amount ($pending_amount).",
                            'action' => 'skipped'
                        ];
                        $skippedCount++;
                        $pdo->rollBack();
                        continue;
                    }

                    // If existing unpaid fee found, check if it's the same amount
                    if ($existing_fee['unpaid_amount'] == $pending_amount && $existing_fee['discount_amount'] == $discount && $existing_fee['actual_amount'] == $actualFee) {
                        $results[] = [
                            'student_id' => $student_id,
                            'month_year' => $month_year,
                            'name' => $student_name,
                            'success' => false,
                            'message' => "Unpaid fee for $month_year already exists with same amount",
                            'action' => 'skipped'
                        ];
                        $skippedCount++;
                        $pdo->rollBack();
                        continue;
                    }

                    // Update existing record
                    $updateStmt = $pdo->prepare("
                        UPDATE student_unpaid_fees 
                        SET actual_amount = ?, unpaid_amount = ?, discount_amount = ?, remark = ? 
                        WHERE id = ?
                    ");
                    $updateStmt->execute([
                        $actualFee,
                        $pending_amount,
                        $discount,
                        $remark,
                        $existing_fee['id']
                    ]);

                    $action = 'updated';
                } else {
                    // Insert new record
                    $insertStmt = $pdo->prepare("
                        INSERT INTO student_unpaid_fees
                        (student_id, month_year, actual_amount, unpaid_amount, discount_amount, remark, created_at) 
                        VALUES (?, ?, ?, ?, ?, ?, NOW())
                    ");
                    $insertStmt->execute([
                        $student_id,
                        $month_year,
                        $actualFee,
                        $offerFee,
                        $discount,
                        $remark
                    ]);

                    $action = 'created';
                }

                // If we got here successfully, add the student ID to processed list and commit
                $processedStudentIds[] = $student_id;
                $results[] = [
                    'student_id' => $student_id,
                    'month_year' => $month_year,
                    'name' => $student_name,
                    'success' => true,
                    'message' => "Fee record {$action} successfully for {$month_year}",
                    'action' => $action,
                    'amount' => $offerFee
                ];

                $pdo->commit();
                $processedCount++;
                
            } catch (Exception $e) {
                $pdo->rollBack();
                throw $e; // This will be caught by the outer try-catch block
            }
        }
        $last_proccessed_sid = $student_id;
    }

    $processedStudentIds = array_unique($processedStudentIds); // Remove duplicates

    // Send Firebase Notifications
    if (!empty($processedStudentIds)) {
        $fcmTokens = getFCMTokensFromDatabase($pdo, $processedStudentIds);
        if ($fcmTokens) {
            $notificationTitle = 'Payment Reminder';
            $notificationBody = 'Your monthly fee record has been updated successfully. Please check your account for details.';
            $data = [
                'title' => $notificationTitle,
                'message' => $notificationBody
            ];
            try {
                sendFirebaseNotification($pdo, $processedStudentIds, $fcmTokens, $notificationTitle, $notificationBody, $data);
            } catch (Exception $e) {
                // error_log("Failed to send notification: " . $e->getMessage());
            }
        }
    }

    echo json_encode([
        'success' => true,
        'message' => "Processed {$processedCount} records, skipped {$skippedCount} records",
        'total_records' => $processedCount + $skippedCount,
        'processed' => $processedCount,
        'skipped' => $skippedCount,
        'results' => $results
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'A database error occurred: ' . $e->getMessage(),
        'processed_up_to' => $last_proccessed_sid
    ]);
}