<?php
require_once __DIR__ . '/../../../../../includes/auth-check.php';
require_once __DIR__ . '/../../../../../includes/financial/monthly-fee-ledger.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); header('Allow: POST'); exit; }
if (!hasPermission(PERM_MANAGE_FEES) || !hasPermission(PERM_CAN_SEE_FINANCIAL_REPORT)) {
    http_response_code(403); echo json_encode(['success' => false, 'message' => 'Permission denied']); exit;
}
if (!is_string($_POST['csrf'] ?? null) || empty($_SESSION['monthly_category_csrf'])
    || !hash_equals($_SESSION['monthly_category_csrf'], $_POST['csrf'])) {
    http_response_code(403); echo json_encode(['success' => false, 'message' => 'Refresh the report before submitting.']); exit;
}
$admin = getAuthenticatedAdmin($pdo);
try {
    $id = filter_var($_POST['fee_id'] ?? '', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if (!$id) throw new InvalidArgumentException('Select a valid unpaid bill.');
    $stmt = $pdo->prepare('SELECT * FROM student_unpaid_fees WHERE id = ?'); $stmt->execute([$id]);
    $fee = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$fee) throw new DomainException('Unpaid bill no longer exists.');
    $remaining = json_decode($_POST['components'] ?? '', true, 16, JSON_THROW_ON_ERROR);
    if (!is_array($remaining)) throw new InvalidArgumentException('Enter the remaining component amounts.');
    $pdo->beginTransaction();
    $lock = $pdo->prepare('SELECT student_id FROM students WHERE student_id = ? FOR UPDATE'); $lock->execute([$fee['student_id']]);
    $lock = $pdo->prepare('SELECT * FROM student_unpaid_fees WHERE id = ? AND student_id = ? FOR UPDATE');
    $lock->execute([$id, $fee['student_id']]); $fee = $lock->fetch(PDO::FETCH_ASSOC);
    if (!$fee) throw new DomainException('The bill changed. Reload the report.');
    (new MonthlyFeeLedger($pdo))->verifyRemaining($fee, $remaining, (int)$admin['user_id']);
    $pdo->commit();
    echo json_encode(['success' => true, 'message' => 'Remaining due verified. Historical payments and totals were preserved.']);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
