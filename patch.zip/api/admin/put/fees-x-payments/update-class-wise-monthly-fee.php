<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");
header('Content-Type: application/json');

if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = isset($_POST['fee_id']) ? (int)$_POST['fee_id'] : 0;
        $class_id = isset($_POST['class_id']) ? (int)$_POST['class_id'] : 0;
        $amount = isset($_POST['amount']) ? trim($_POST['amount']) : 0;

        if (empty($amount) || empty($class_id) || empty($id)) {
            throw new Exception('Please fill in all fields');
        }

        if (!is_numeric($amount)) {
            throw new Exception('Fee amount must be numeric value.');
        }

        // ডেটা আপডেট করা
        $update = $pdo->prepare("UPDATE class_wise_monthly_fees SET class_id = ?, amount = ? WHERE id = ?");
        if ($update->execute([$class_id, $amount, $id])) {
            $response['success'] = true;
            $response['message'] = 'Class fee updated successfully!';
        } else {
            throw new Exception('Failed to update class fee in database');
        }
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);