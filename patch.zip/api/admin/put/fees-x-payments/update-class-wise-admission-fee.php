<?php
include_once(__DIR__ . '/../../../../includes/auth-check.php');
header('Content-Type: application/json');

if (!isSuperAdmin()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}
if (!is_string($_POST['csrf'] ?? null) || empty($_SESSION['admission_fee_edit_csrf'])
    || !hash_equals($_SESSION['admission_fee_edit_csrf'], $_POST['csrf'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Please reload the page and try again.']);
    exit;
}

try {
    $id = filter_var($_POST['fee_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $classId = filter_var($_POST['class_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $type = $_POST['admission_type'] ?? '';
    $tables = ['new-admission' => 'class_wise_new_admission_fees', 're-admission' => 'class_wise_re_admission_fees'];
    if (!is_string($type) || !isset($tables[$type])) {
        throw new InvalidArgumentException('Invalid admission type.');
    }
    if (!$id || !$classId) {
        throw new InvalidArgumentException('Please select a valid fee and class.');
    }
    $amount = is_string($_POST['amount'] ?? null) ? trim($_POST['amount']) : '';
    if (!preg_match('/^\d{1,8}(?:\.\d{1,2})?$/D', $amount) || (float)$amount <= 0) {
        throw new InvalidArgumentException('Enter an amount greater than zero, up to 99999999.99, with at most two decimal places.');
    }
    $table = $tables[$type];
    $pdo->beginTransaction();
    $stmt = $pdo->prepare("SELECT id FROM `$table` WHERE id = ? FOR UPDATE");
    $stmt->execute([$id]);
    if (!$stmt->fetchColumn()) {
        throw new InvalidArgumentException('Admission fee not found. Please refresh the list.');
    }
    $stmt = $pdo->prepare('SELECT id FROM classes WHERE id = ?');
    $stmt->execute([$classId]);
    if (!$stmt->fetchColumn()) {
        throw new InvalidArgumentException('Invalid class selected.');
    }
    $stmt = $pdo->prepare("SELECT id FROM `$table` WHERE class_id = ? AND id <> ?");
    $stmt->execute([$classId, $id]);
    if ($stmt->fetchColumn()) {
        throw new InvalidArgumentException('This class already has a fee for this admission type. Edit that fee instead.');
    }
    // Only the setup row changes; previously issued student bills keep their amounts.
    $stmt = $pdo->prepare("UPDATE `$table` SET class_id = ?, amount = ? WHERE id = ?");
    if (!$stmt->execute([$classId, $amount, $id])) {
        throw new RuntimeException('Admission fee update failed.');
    }
    $pdo->commit();
    echo json_encode(['success' => true, 'message' => 'Admission fee updated successfully!']);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    if ($e instanceof InvalidArgumentException) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    } else {
        error_log('Admission fee setup update: ' . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Unable to update the admission fee. Please try again.']);
    }
}
