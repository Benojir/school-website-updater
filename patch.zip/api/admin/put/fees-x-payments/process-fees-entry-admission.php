<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");
include_once(__DIR__ . "/../../../../includes/financial/fun-admission-fees-entry.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'error' => true
    ]);
    die();
}

// Check for required fields
$required = ['studentIDs', 'academic_year', 'admission_fees_type'];
foreach ($required as $field) {
    if (empty($_POST[$field])) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'All fields are required',
            'field' => $field
        ]);
        exit;
    }
}

$student_ids_with_comma = sanitize_input($_POST['studentIDs']);
$admission_fees_type = sanitize_input($_POST['admission_fees_type']);
$academic_year = sanitize_input($_POST['academic_year']);
$admission_class_id = isset($_POST['admission_class']) ? sanitize_input($_POST['admission_class']) : null;
$discount = isset($_POST['discount']) ? sanitize_input($_POST['discount']) : 0;
$is_re_admission = false;

// Validating admission fees type
if ($admission_fees_type == 're-admission-fees') {
    $is_re_admission = true;
}

// Process admission fees entry
$response = fun_admission_fees_entry(
    $pdo, 
    $student_ids_with_comma,
    $academic_year,
    $admission_class_id,
    $discount,
    $is_re_admission
);

// Set HTTP status code based on success
if (!$response['success'] && isset($response['error'])) {
    http_response_code(400); // Bad Request for general errors
}

// Echo the final JSON response
echo json_encode($response);