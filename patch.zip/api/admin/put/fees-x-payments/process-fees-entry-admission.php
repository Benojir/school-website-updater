<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/financial/fun-admission-fees-entry.php");

// Sanitize and retrieve POST data
$rawInput = file_get_contents("php://input");

parse_str($rawInput, $params);

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
    ]);
    die();
}

if (isset($params['students_data'])) {
    $students_data = json_decode($params['students_data'], true);

    if (json_last_error() === JSON_ERROR_NONE) {

        $errors = [];
        $skips = [];
        $successes = [];

        foreach ($students_data as $data) {

            $student_id = isset($data['student_id']) ? trim($data['student_id']) : null;
            $student_name = isset($data['student_name']) ? trim($data['student_name']) : 'Unknown';
            $academic_year = isset($data['academic_year']) ? (int) trim($data['academic_year']) : null;
            $fees_type = isset($data['fees_type']) ? trim($data['fees_type']) : null;
            $admission_class_id = isset($data['admission_class_id']) ? (int) trim($data['admission_class_id']) : null;
            $discount = isset($data['discount']) ? trim($data['discount']) : 0;

            $is_re_admission = ($fees_type === 're-admission-fees');

            if (!$student_id || !$academic_year || !$fees_type || !$admission_class_id) {
                $errors[] = "Missing required data for student: $student_name (ID: $student_id)";
                continue;
            }

            if (!is_numeric($discount) || $discount < 0) {
                $errors[] = "Invalid discount amount for student: $student_name (ID: $student_id)";
                continue;
            }

            if ($admission_class_id <= 0) {
                $errors[] = "Invalid admission class ID for student: $student_name (ID: $student_id)";
                continue;
            }

            if ($academic_year < 2000 || $academic_year > 2200) {
                $errors[] = "Invalid academic year for student: $student_name (ID: $student_id)";
                continue;
            }

            $response = fun_admission_fees_entry(
                $pdo,
                $student_id,
                $academic_year,
                $admission_class_id,
                $discount,
                $is_re_admission
            );

            if ($response['success']) {

                if ($response['skipped'] > 0) {
                    $skips[] = [
                        'student_name' => $student_name,
                        'reason' => $response['results'][0]['message']
                    ];
                } else {
                    $successes[] = [
                        'student_name' => $student_name,
                        'message' => 'Successfully proccessed.'
                    ];
                }
            } else {
                if (isset($response['message'])) {
                    $errors[] = "Error for student: $student_name (ID: $student_id) - " . $response['message'];
                } else {
                    $errors[] = "Unknown error for student: $student_name (ID: $student_id)";
                }
            }
        }

        $build_response = [
            'success' => true,
            'message' => 'Admission fees entry processed successfully.',
            'errors' => $errors,
            'skips' => $skips,
            'successes' => $successes
        ];

        echo json_encode($build_response);
    } else {
        echo json_encode(["success" => false, "message" => "Invalid JSON format"]);
    }
} else {
    echo json_encode(["success" => false, "message" => "No data received"]);
}
