<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['user']['role'] !== 'superadmin') {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        $class_id = isset($_POST['class_id']) ? (int)$_POST['class_id'] : 0;
        $amount = isset($_POST['amount']) ? trim($_POST['amount']) : 0;
        $admission_type = isset($_POST['admission_type']) ? trim($_POST['admission_type']) : '';

        $allowed_admission_type = ['new-admission', 're-admission'];

        if (!in_array($admission_type, $allowed_admission_type, true)) {
            // ❌ Invalid admission type or empty/null admission type
            throw new Exception('Invalid admission type');
        }

        // Validate inputs
        if (empty($amount) || empty($class_id)) {
            throw new Exception('Please fill in all fields');
        }

        $table_name = "class_wise_new_admission_fees";

        if ($admission_type == $allowed_admission_type[1]) {
            $table_name = "class_wise_re_admission_fees";
        }

        // Get class name
        $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
        $stmt->execute([$class_id]);
        $class = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$class) {
            throw new Exception('Invalid class selected');
        }

        $class_name = $class['class_name'];

        // Check for duplicate entry
        $check = $pdo->prepare("SELECT id FROM `{$table_name}` WHERE class_id = ?");
        $check->execute([$class_id]);

        if ($check->rowCount() > 0) {
            throw new Exception('Admission fee already exist. If you want to update it then first delete the admission fee.');
        }

        // Insert new subject
        $insert = $pdo->prepare("INSERT INTO `{$table_name}` (class_id, amount) VALUES (?, ?)");
        if ($insert->execute([$class_id, $amount])) {
            $response['success'] = true;
            $response['message'] = "Admission fee added successfully in {$admission_type} fees";
        } else {
            throw new Exception('Failed to add admission fee into database');
        }
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);