<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$additional_fees_setup_id = $_POST['additional_fees_setup_id'] ?? null;
$additional_fee_status = $_POST['additional_fee_status'] ?? null;
$student_ids = $_POST['student_ids'] ?? null;

$table_name = 'additional_fees_data';

/**
 * Normalise a date coming from the form.
 *
 * The modal always posts both date fields, so the one that doesn't match the
 * chosen status arrives as an empty string. A DATE column rejects '' outright
 * (MySQL error 1292), so it has to be converted to NULL.
 *
 * @return string|null|false  'Y-m-d' string, NULL when blank, FALSE when invalid
 */
function normalizeDateInput($value)
{
    $value = trim((string) ($value ?? ''));

    if ($value === '') {
        return null;
    }

    $parsed = DateTime::createFromFormat('Y-m-d', $value);

    if (!$parsed || $parsed->format('Y-m-d') !== $value) {
        return false;
    }

    return $value;
}

$additional_fee_paid_date = normalizeDateInput($_POST['additional_fee_paid_date'] ?? null);
$additional_fee_due_date = normalizeDateInput($_POST['additional_fee_due_date'] ?? null);

if ($additional_fee_paid_date === false || $additional_fee_due_date === false) {
    echo json_encode(['success' => false, 'message' => 'Invalid date format. Please pick the date again.']);
    exit();
}

// Validate input
if (!$additional_fees_setup_id || !$additional_fee_status || !$student_ids) {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit();
}

// Create array of student IDs
$student_ids = array_values(array_filter(array_map('trim', explode(',', $student_ids))));

// Validate status values
if ($additional_fee_status !== 'paid' && $additional_fee_status !== 'unpaid' && $additional_fee_status !== 'delete') {
    echo json_encode(['success' => false, 'message' => 'Invalid status value']);
    exit();
}

// Check valid payment date if status is paid
if ($additional_fee_status === 'paid') {
    if (empty($additional_fee_paid_date)) {
        echo json_encode(['success' => false, 'message' => 'Paid date is required']);
        exit();
    }
}

// Check valid due date if status is unpaid
if ($additional_fee_status === 'unpaid') {
    if (empty($additional_fee_due_date)) {
        echo json_encode(['success' => false, 'message' => 'Due date is required']);
        exit();
    }
}

// Required minimum 1 student ID
if (count($student_ids) < 1) {
    echo json_encode(['success' => false, 'message' => 'At least one student ID is required']);
    exit();
}

// Only the date matching the status is meaningful: a fee marked unpaid has no
// payment date, so any previously stored one is cleared.
if ($additional_fee_status === 'unpaid') {
    $additional_fee_paid_date = null;
}

// Columns to write when updating an existing row. Marking a fee paid without
// supplying a due date leaves the stored due date untouched rather than wiping it.
$update_set_parts = ['additional_fee_status = ?'];
$update_set_params = [$additional_fee_status];

if ($additional_fee_status === 'paid') {
    $update_set_parts[] = 'additional_fee_paid_date = ?';
    $update_set_params[] = $additional_fee_paid_date;

    if ($additional_fee_due_date !== null) {
        $update_set_parts[] = 'additional_fee_due_date = ?';
        $update_set_params[] = $additional_fee_due_date;
    }
} elseif ($additional_fee_status === 'unpaid') {
    $update_set_parts[] = 'additional_fee_due_date = ?';
    $update_set_params[] = $additional_fee_due_date;
    $update_set_parts[] = 'additional_fee_paid_date = ?';
    $update_set_params[] = $additional_fee_paid_date;
}

$class_id = null;

$skippedStudents = [];
$processedStudents = [];

// This endpoint is called over AJAX with dataType 'json', so a DB failure has to
// come back as JSON - an uncaught PDOException would print an HTML fatal error
// that the caller can't parse.
try {
    foreach ($student_ids as $student_id) {

        // Existing charges retain their original class and remain collectible after promotion.
        $existingStmt = $pdo->prepare('SELECT class_id FROM additional_fees_data WHERE additional_fee_setup_id = ? AND student_id = ?');
        $existingStmt->execute([$additional_fees_setup_id, $student_id]);
        $existingCharge = $existingStmt->fetch(PDO::FETCH_ASSOC);
        if ($existingCharge) {
            $class_id = $existingCharge['class_id'];
        } else {
            $year = academicRequestedYear($_POST) ?? academicRequireCurrentYear($pdo);
            $enrollment = academicGetStudent($pdo, $student_id, $year);
            if (!$enrollment) {
                $skippedStudents[] = ['student_id' => $student_id, 'reason' => 'No enrollment for selected academic year'];
                continue;
            }
            $class_id = $enrollment['class_id'];
            $setupStmt = $pdo->prepare('SELECT class_id FROM class_wise_additional_fees WHERE id = ?');
            $setupStmt->execute([$additional_fees_setup_id]);
            if ((int)$setupStmt->fetchColumn() !== (int)$class_id) {
                $skippedStudents[] = ['student_id' => $student_id, 'reason' => 'Fee setup does not belong to the selected year class'];
                continue;
            }
        }

        // Proecess the next steps now.

        if ($additional_fee_status === 'delete') {
            $sql = "DELETE FROM $table_name WHERE additional_fee_setup_id = ? AND student_id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$additional_fees_setup_id, $student_id]);

            if ($stmt->rowCount() > 0) {
                // ✅ Row was deleted
                $processedStudents[] = $student_id;
            } else {
                // ⚠️ No matching row found
                // Maybe already deleted or invalid IDs
                $skippedStudents[] = ['student_id' => $student_id, 'reason' => 'No matching row found'];
            }
        } else if ($additional_fee_status === 'paid' || $additional_fee_status === 'unpaid') {
            // First check if the record exists or not
            $sql = "SELECT * FROM $table_name WHERE additional_fee_setup_id = ? AND student_id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$additional_fees_setup_id, $student_id]);

            if ($stmt->rowCount() > 0) {
                // ✅ Record exists, update it
                $sql = "UPDATE $table_name SET " . implode(', ', $update_set_parts) . " WHERE additional_fee_setup_id = ? AND student_id = ?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute(array_merge($update_set_params, [$additional_fees_setup_id, $student_id]));

                $processedStudents[] = $student_id;
            } else {
                // ❌ Record does not exist, insert a new one
                $sql = "INSERT INTO additional_fees_data(student_id, class_id, additional_fee_setup_id, additional_fee_status, additional_fee_due_date, additional_fee_paid_date) VALUES (?, ?, ?, ?, ?, ?)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([$student_id, $class_id, $additional_fees_setup_id, $additional_fee_status, $additional_fee_due_date, $additional_fee_paid_date]);

                if ($stmt->rowCount() > 0) {
                    // ✅ Row was inserted
                    $processedStudents[] = $student_id;
                } else {
                    // ⚠️ No matching row found
                    // Maybe already deleted or invalid IDs
                    $skippedStudents[] = ['student_id' => $student_id, 'reason' => 'Something went wrong while inserting data'];
                }
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid additional fee status']);
            exit();
        }
    }
} catch (Exception $e) {
    error_log("Database error in additional fees entry: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Database error while saving the additional fee: ' . $e->getMessage()
    ]);
    exit();
}

echo json_encode([
    'success' => true, 
    'message' => 'Additional fee entry processed successfully', 
    'processedStudents' => $processedStudents, 
    'skippedStudents' => $skippedStudents
]);
