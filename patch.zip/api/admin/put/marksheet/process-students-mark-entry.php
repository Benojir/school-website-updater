<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission
if (!hasPermission(PERM_MANAGE_RESULTS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Helper function to get Grade Info
function getGradeInfo($percentage) {
    if ($percentage === null) return ['grade' => 'N/A', 'remarks' => 'N/A'];
    return ['grade' => calculateGrade($percentage), 'remarks' => getRemarksByGrade(calculateGrade($percentage))];
}

$exam_id = $_POST['exam_id'] ?? '';
$class_id = $_POST['class_id'] ?? '';
$students = $_POST['students'] ?? [];
$subjects = $_POST['subjects'] ?? [];
$absent = $_POST['absent'] ?? [];
$exclude = $_POST['exclude'] ?? [];
$minor_subject = $_POST['minor_subject'] ?? [];

if (empty($exam_id) || empty($class_id) || empty($students) || empty($subjects)) {
    echo json_encode(['success' => false, 'message' => 'Required fields are missing']);
    exit;
}

try {
    $pdo->beginTransaction();

    $success_count = 0;
    $error_messages = [];

    foreach ($students as $student_id => $student_data) {

        // Fetch the student section id
        $stmt = $pdo->prepare("SELECT section_id FROM students WHERE student_id = ?");
        $stmt->execute([$student_id]);
        $student_section_id = $stmt->fetchColumn();

        // Get existing results to identify first exam
        $stmt = $pdo->prepare("SELECT id, exam_id FROM results WHERE class_id = ? AND student_id = ? ORDER BY exam_id ASC");
        $stmt->execute([$class_id, $student_id]);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $first_exam_id = null;
        $first_result_id = null;
        if ($results) {
            $first_exam_id = $results[0]['exam_id'];
            $first_result_id = $results[0]['id'];
        }

        $is_updating_first_exam = ($first_exam_id !== null && $first_exam_id == $exam_id);

        // Check for existing result for THIS exam
        $stmt = $pdo->prepare("SELECT id FROM results WHERE student_id = ? AND exam_id = ?");
        $stmt->execute([$student_id, $exam_id]);
        $existing_result = $stmt->fetch();

        // ## SECTION 1: PROCESS CURRENT EXAM ##

        $total_marks = 0;
        $obtained_marks = 0;
        $total_minor_marks = 0;
        $obtained_minor_marks = 0;
        $subjects_data = []; 

        foreach ($student_data['subjects'] as $subject_id => $marks) {
            $is_absent = isset($absent[$student_id][$subject_id]) ? 1 : 0;
            $is_excluded = isset($exclude[$student_id][$subject_id]) ? 1 : 0;
            $is_minor = $minor_subject[$student_id][$subject_id] ?? 0;

            // Enforce exclusion from first exam
            if ($first_result_id && $first_exam_id != $exam_id) {
                $stmt_check = $pdo->prepare("SELECT is_excluded FROM subject_marks WHERE result_id = ? AND subject_id = ?");
                $stmt_check->execute([$first_result_id, $subject_id]);
                $first_subject_mark = $stmt_check->fetch(PDO::FETCH_ASSOC);
                if ($first_subject_mark) {
                    $is_excluded = $first_subject_mark['is_excluded'];
                }
            }

            $theory_marks_val = (float)($marks['theory_marks'] ?? 0);
            $practical_marks_val = (float)($marks['practical_marks'] ?? 0);
            $obtained = $theory_marks_val + $practical_marks_val;
            $total = (float)$marks['total_marks'];

            if ($is_absent || $is_excluded) {
                $theory_marks_val = 0; $practical_marks_val = 0; $obtained = 0;
            }

            if ($obtained > $total) {
                $error_messages[] = "Obtained marks > total for {$subjects[$subject_id]['subject_name']} ({$student_data['name']})";
                continue 2; 
            }

            if (!$is_excluded) {
                $total_marks += $total;
                $obtained_marks += $obtained;
                
                if ($is_minor) {
                    $total_minor_marks += $total;
                    $obtained_minor_marks += $obtained;
                }
            }

            // Subject Grade
            $sub_pct = ($total > 0) ? ($obtained / $total) * 100 : 0;
            $grade_info = getGradeInfo($sub_pct);

            $subjects_data[] = [
                'subject_id' => $subject_id,
                'theory_marks' => $theory_marks_val,
                'practical_marks' => $practical_marks_val,
                'total_marks' => $total,
                'obtained_marks' => $obtained,
                'grade' => $grade_info['grade'],
                'remarks' => $grade_info['remarks'],
                'absent' => $is_absent,
                'excluded' => $is_excluded
            ];
        }

        // 1. Overall Calculations
        $percentage = ($total_marks > 0) ? ($obtained_marks / $total_marks) * 100 : 0;
        $grade_info = getGradeInfo($percentage);

        // 2. Without Minor Calculations
        $major_total = $total_marks - $total_minor_marks;
        $major_obtained = $obtained_marks - $obtained_minor_marks;
        
        $percentage_without_minor = ($major_total > 0) ? ($major_obtained / $major_total) * 100 : 0;
        $grade_info_no_minor = getGradeInfo($percentage_without_minor);

        // DB Insert/Update
        if ($existing_result) {
            $result_id = $existing_result['id'];
            $stmt_update = $pdo->prepare("
                UPDATE results SET 
                section_id = ?, total_marks = ?, obtained_marks = ?, percentage = ?, grade = ?, remarks = ?, 
                total_minor_marks = ?, obtained_minor_marks = ?, percentage_without_minor = ?, grade_without_minor = ?, remarks_without_minor = ?, 
                updated_at = NOW() WHERE id = ?
            ");
            $stmt_update->execute([
                $student_section_id, $total_marks, $obtained_marks, $percentage, $grade_info['grade'], $grade_info['remarks'],
                $total_minor_marks, $obtained_minor_marks, $percentage_without_minor, $grade_info_no_minor['grade'], $grade_info_no_minor['remarks'],
                $result_id
            ]);
            $pdo->prepare("DELETE FROM subject_marks WHERE result_id = ?")->execute([$result_id]);
        } else {
            $stmt_insert = $pdo->prepare("
                INSERT INTO results 
                (student_id, 
                exam_id, 
                class_id, 
                section_id, 
                total_marks, 
                obtained_marks, 
                percentage, 
                grade, 
                remarks,
                total_minor_marks, 
                obtained_minor_marks, 
                percentage_without_minor, 
                grade_without_minor, 
                remarks_without_minor) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt_insert->execute([
                $student_id, $exam_id, $class_id, $student_section_id,
                $total_marks, $obtained_marks, $percentage, $grade_info['grade'], $grade_info['remarks'],
                $total_minor_marks, $obtained_minor_marks, $percentage_without_minor, $grade_info_no_minor['grade'], $grade_info_no_minor['remarks']
            ]);
            $result_id = $pdo->lastInsertId();
        }

        foreach ($subjects_data as $sub) {
            $stmt_sm = $pdo->prepare("INSERT INTO subject_marks (result_id, subject_id, theory_marks, practical_marks, total_marks, obtained_marks, grade, remarks, is_absent, is_excluded) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt_sm->execute([$result_id, $sub['subject_id'], $sub['theory_marks'], $sub['practical_marks'], $sub['total_marks'], $sub['obtained_marks'], $sub['grade'], $sub['remarks'], $sub['absent'], $sub['excluded']]);
        }


        // ## SECTION 2: TRIGGER CASCADING UPDATE ##
        // Now accurately recalculates Minor/Major splits for subsequent exams
        if ($is_updating_first_exam) {
            
            // Phase 1: Propagate 'is_excluded'
            foreach ($subjects_data as $sub) {
                $stmt_propagate = $pdo->prepare("
                    UPDATE subject_marks sm
                    JOIN results r ON sm.result_id = r.id
                    SET sm.is_excluded = ?
                    WHERE r.student_id = ? AND sm.subject_id = ? AND r.exam_id > ?
                ");
                $stmt_propagate->execute([$sub['excluded'], $student_id, $sub['subject_id'], $first_exam_id]);
            }

            // Phase 2: Recalculate Totals (Including Minor Logic)
            $stmt_subsequent = $pdo->prepare("SELECT id FROM results WHERE student_id = ? AND exam_id > ?");
            $stmt_subsequent->execute([$student_id, $first_exam_id]);
            $subsequent_results = $stmt_subsequent->fetchAll(PDO::FETCH_ASSOC);

            foreach ($subsequent_results as $res) {
                $r_id = $res['id'];

                // JOIN subjects table to check subject_type for stored marks
                $stmt_marks = $pdo->prepare("
                    SELECT sm.total_marks, sm.obtained_marks, sm.is_excluded, s.subject_type 
                    FROM subject_marks sm
                    JOIN subjects s ON sm.subject_id = s.id
                    WHERE sm.result_id = ?
                ");
                $stmt_marks->execute([$r_id]);
                $all_marks = $stmt_marks->fetchAll(PDO::FETCH_ASSOC);

                $new_total = 0; $new_obtained = 0;
                $new_minor_total = 0; $new_minor_obtained = 0;

                foreach ($all_marks as $m) {
                    if ($m['is_excluded'] != 1) {
                        $new_total += (float)$m['total_marks'];
                        $new_obtained += (float)$m['obtained_marks'];

                        // Check if Minor
                        if (strtolower($m['subject_type']) === 'minor') {
                            $new_minor_total += (float)$m['total_marks'];
                            $new_minor_obtained += (float)$m['obtained_marks'];
                        }
                    }
                }

                // 1. New Overall
                $new_pct = ($new_total > 0) ? ($new_obtained / $new_total) * 100 : 0;
                $new_grade = getGradeInfo($new_pct);

                // 2. New Without Minor
                $new_major_total = $new_total - $new_minor_total;
                $new_major_obtained = $new_obtained - $new_minor_obtained;
                $new_pct_no_minor = ($new_major_total > 0) ? ($new_major_obtained / $new_major_total) * 100 : 0;
                $new_grade_no_minor = getGradeInfo($new_pct_no_minor);

                $stmt_upd = $pdo->prepare("
                    UPDATE results SET 
                    section_id = ?, total_marks = ?, obtained_marks = ?, percentage = ?, grade = ?, remarks = ?,
                    total_minor_marks = ?, obtained_minor_marks = ?, percentage_without_minor = ?, grade_without_minor = ?, remarks_without_minor = ?
                    WHERE id = ?
                ");
                $stmt_upd->execute([
                    $student_section_id, $new_total, $new_obtained, $new_pct, $new_grade['grade'], $new_grade['remarks'],
                    $new_minor_total, $new_minor_obtained, $new_pct_no_minor, $new_grade_no_minor['grade'], $new_grade_no_minor['remarks'],
                    $r_id
                ]);
            }
        }

        $success_count++;
    }

    $pdo->commit();

    // Response generation
    $message = "Saved results for $success_count student(s).";
    if (!empty($error_messages)) {
        $message .= " Errors: " . implode(", ", array_slice($error_messages, 0, 2));
    }
    echo json_encode(['success' => true, 'message' => $message]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>