<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_RESULTS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'errors' => ['You do not have permission to perform this action.']
    ]);
    die();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$exam_id = $_POST['exam_id'] ?? '';
$class_id = $_POST['class_id'] ?? '';
$students = $_POST['students'] ?? [];
$subjects = $_POST['subjects'] ?? [];
$absent = $_POST['absent'] ?? [];
$exclude = $_POST['exclude'] ?? [];

if (empty($exam_id) || empty($class_id) || empty($students) || empty($subjects)) {
    echo json_encode(['success' => false, 'message' => 'Required fields are missing']);
    exit;
}

try {
    $pdo->beginTransaction();

    $success_count = 0;
    $error_messages = [];

    foreach ($students as $student_id => $student_data) {

        // Get all existing results for the student to find their first exam
        $stmt = $pdo->prepare("SELECT id, exam_id FROM results WHERE class_id = ? AND student_id = ? ORDER BY exam_id ASC");
        $stmt->execute([$class_id, $student_id]);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $first_exam_id = null;
        $first_result_id = null;
        if ($results) {
            $first_exam_id = $results[0]['exam_id'];
            $first_result_id = $results[0]['id'];
        }

        // Check if the current operation is an update to the student's very first exam
        $is_updating_first_exam = ($first_exam_id !== null && $first_exam_id == $exam_id);

        // Check if a result already exists for this specific student and exam
        $stmt = $pdo->prepare("SELECT id FROM results WHERE student_id = ? AND exam_id = ?");
        $stmt->execute([$student_id, $exam_id]);
        $existing_result = $stmt->fetch();

        // ## SECTION 1: PROCESS AND SAVE THE CURRENT EXAM'S DATA ##

        $total_marks = 0;
        $obtained_marks = 0;
        $subjects_data = []; // Holds processed data for the current exam

        foreach ($student_data['subjects'] as $subject_id => $marks) {
            $is_absent = isset($absent[$student_id][$subject_id]) ? 1 : 0;
            $is_excluded = isset($exclude[$student_id][$subject_id]) ? 1 : 0;

            // If this is a subsequent exam, enforce the 'excluded' status from the first exam
            if ($first_result_id && $first_exam_id != $exam_id) {
                $stmt_check = $pdo->prepare("SELECT is_excluded FROM subject_marks WHERE result_id = ? AND subject_id = ?");
                $stmt_check->execute([$first_result_id, $subject_id]);
                $first_subject_mark = $stmt_check->fetch(PDO::FETCH_ASSOC);
                if ($first_subject_mark) {
                    $is_excluded = $first_subject_mark['is_excluded'];
                }
            }

            $theory_marks_val = (float)($marks['theory_marks'] ?? 0);
            $practical_marks_val = (float)($marks['practical_marks'] ?? 0);
            $obtained = $theory_marks_val + $practical_marks_val;
            $total = (float)$marks['total_marks'];

            if ($is_absent || $is_excluded) {
                $theory_marks_val = 0;
                $practical_marks_val = 0;
                $obtained = 0;
            }

            if ($obtained > $total) {
                $error_messages[] = "Obtained marks > total for {$subjects[$subject_id]['subject_name']} (Student: {$student_data['name']})";
                continue 2; // Skip this student
            }

            if (!$is_excluded) {
                $total_marks += $total;
                $obtained_marks += $obtained;
            }

            // Calculate subject grade
            $subject_percentage = ($total > 0) ? ($obtained / $total) * 100 : 0;
            $stmt_grade = $pdo->prepare("SELECT grade, remarks FROM grading_system WHERE ? BETWEEN min_percentage AND max_percentage LIMIT 1");
            $stmt_grade->execute([$subject_percentage]);
            $grade_info = $stmt_grade->fetch(PDO::FETCH_ASSOC);

            $subjects_data[] = [
                'subject_id' => $subject_id,
                'theory_marks' => $theory_marks_val,
                'practical_marks' => $practical_marks_val,
                'total_marks' => $total,
                'obtained_marks' => $obtained,
                'grade' => $grade_info['grade'] ?? 'N/A',
                'remarks' => $grade_info['remarks'] ?? 'N/A',
                'absent' => $is_absent,
                'excluded' => $is_excluded
            ];
        }

        // Calculate overall percentage and grade for the current exam
        $percentage = 0;
        if ($total_marks > 0) {
            $percentage = ($obtained_marks / $total_marks) * 100;
        }

        $stmt_grade = $pdo->prepare("SELECT grade, remarks FROM grading_system WHERE ? BETWEEN min_percentage AND max_percentage LIMIT 1");
        $stmt_grade->execute([$percentage]);
        $grade_info = $stmt_grade->fetch(PDO::FETCH_ASSOC);

        $result_id = null;
        if ($existing_result) {
            // UPDATE existing result
            $result_id = $existing_result['id'];
            $stmt_update = $pdo->prepare("UPDATE results SET total_marks = ?, obtained_marks = ?, percentage = ?, grade = ?, remarks = ?, updated_at = NOW() WHERE id = ?");
            $stmt_update->execute([$total_marks, $obtained_marks, $percentage, $grade_info['grade'] ?? 'N/A', $grade_info['remarks'] ?? 'N/A', $result_id]);
            // Delete old subject marks before re-inserting
            $pdo->prepare("DELETE FROM subject_marks WHERE result_id = ?")->execute([$result_id]);
        } else {
            // INSERT new result
            $stmt_insert = $pdo->prepare("INSERT INTO results (student_id, exam_id, class_id, total_marks, obtained_marks, percentage, grade, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt_insert->execute([$student_id, $exam_id, $class_id, $total_marks, $obtained_marks, $percentage, $grade_info['grade'] ?? 'N/A', $grade_info['remarks'] ?? 'N/A']);
            $result_id = $pdo->lastInsertId();
        }

        // Insert fresh subject marks for the current exam
        foreach ($subjects_data as $subject) {
            $stmt_sm = $pdo->prepare("INSERT INTO subject_marks (result_id, subject_id, theory_marks, practical_marks, total_marks, obtained_marks, grade, remarks, is_absent, is_excluded) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt_sm->execute([$result_id, $subject['subject_id'], $subject['theory_marks'], $subject['practical_marks'], $subject['total_marks'], $subject['obtained_marks'], $subject['grade'], $subject['remarks'], $subject['absent'], $subject['excluded']]);
        }


        // ## SECTION 2: TRIGGER CASCADING UPDATE IF THE FIRST EXAM WAS MODIFIED ##
        // This logic is now correctly placed AFTER the current exam is fully processed and saved.
        if ($is_updating_first_exam) {
            
            // Phase 1: Propagate the 'is_excluded' status to all subsequent exams.
            foreach ($subjects_data as $subject) {
                $stmt_propagate = $pdo->prepare(
                   "UPDATE subject_marks sm
                    JOIN results r ON sm.result_id = r.id
                    SET sm.is_excluded = ?
                    WHERE r.student_id = ? AND sm.subject_id = ? AND r.exam_id > ?"
                );
                $stmt_propagate->execute([$subject['excluded'], $student_id, $subject['subject_id'], $first_exam_id]);
            }

            // Phase 2: Recalculate totals for each subsequent exam.
            $stmt_subsequent = $pdo->prepare("SELECT id FROM results WHERE student_id = ? AND exam_id > ?");
            $stmt_subsequent->execute([$student_id, $first_exam_id]);
            $subsequent_results_to_fix = $stmt_subsequent->fetchAll(PDO::FETCH_ASSOC);

            foreach ($subsequent_results_to_fix as $res) {
                $result_id_to_recalculate = $res['id'];

                $stmt_marks = $pdo->prepare("SELECT total_marks, obtained_marks, is_excluded FROM subject_marks WHERE result_id = ?");
                $stmt_marks->execute([$result_id_to_recalculate]);
                $all_subject_marks = $stmt_marks->fetchAll(PDO::FETCH_ASSOC);

                $new_total_marks = 0;
                $new_obtained_marks = 0;

                foreach ($all_subject_marks as $sm) {
                    if ($sm['is_excluded'] != 1) {
                        $new_total_marks += (float)$sm['total_marks'];
                        $new_obtained_marks += (float)$sm['obtained_marks'];
                    }
                }

                $new_percentage = 0;
                if ($new_total_marks > 0) {
                    $new_percentage = ($new_obtained_marks / $new_total_marks) * 100;
                }

                $stmt_grade_recalc = $pdo->prepare("SELECT grade, remarks FROM grading_system WHERE ? BETWEEN min_percentage AND max_percentage LIMIT 1");
                $stmt_grade_recalc->execute([$new_percentage]);
                $new_grade_info = $stmt_grade_recalc->fetch(PDO::FETCH_ASSOC);

                $stmt_update_result = $pdo->prepare("UPDATE results SET total_marks = ?, obtained_marks = ?, percentage = ?, grade = ?, remarks = ? WHERE id = ?");
                $stmt_update_result->execute([$new_total_marks, $new_obtained_marks, $new_percentage, $new_grade_info['grade'] ?? 'N/A', $new_grade_info['remarks'] ?? 'N/A', $result_id_to_recalculate]);
            }
        }

        $success_count++;
    } // End foreach student loop

    $pdo->commit();

    $message = "Successfully processed results for $success_count student(s).";
    if (!empty($error_messages)) {
        $message .= " Errors: " . implode(", ", array_slice($error_messages, 0, 3));
        if (count($error_messages) > 3) {
            $message .= " and " . (count($error_messages) - 3) . " more";
        }
    }

    echo json_encode([
        'success' => true,
        'message' => $message,
        'success_count' => $success_count,
        'error_count' => count($error_messages),
        'errors' => $error_messages
    ]);
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Result Processing Error: " . $e->getMessage()); // Log error for debugging
    echo json_encode(['success' => false, 'message' => 'A database error occurred: ' . $e->getMessage()]);
}

?>