<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_RESULTS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $exam_id = (int)($_POST['exam_id'] ?? 0);
        $release_date = $_POST['release_date'] ?? '';
        $status = $_POST['status'] ?? 'released';

        if ($exam_id <= 0) {
            throw new Exception('Please select a valid exam.');
        }

        if (empty($release_date)) {
            throw new Exception('Please select a release date.');
        }

        // Normalize release_date to valid MySQL DATETIME format (YYYY-MM-DD HH:MM:SS)
        $release_date = str_replace('T', ' ', trim($release_date));
        if (strlen($release_date) === 16) {
            $release_date .= ':00';
        } elseif (strlen($release_date) === 10) {
            $release_date .= ' 00:00:00';
        }

        // class_id now comes as an array from the multi-select (name="class_id[]")
        $class_ids = $_POST['class_id'] ?? [];
        if (!is_array($class_ids)) {
            // Check if raw input contains multiple class_id parameters (fallback if posted without brackets)
            $raw_input = file_get_contents('php://input');
            if (!empty($raw_input)) {
                $raw_params = explode('&', $raw_input);
                $found_ids = [];
                foreach ($raw_params as $param) {
                    $kv = explode('=', $param, 2);
                    if (urldecode($kv[0]) === 'class_id' && isset($kv[1])) {
                        $found_ids[] = urldecode($kv[1]);
                    }
                }
                if (count($found_ids) > 1) {
                    $class_ids = $found_ids;
                } else {
                    $class_ids = [$class_ids];
                }
            } else {
                $class_ids = [$class_ids];
            }
        }

        // Sanitize to unique positive integers
        $class_ids = array_unique(array_map('intval', $class_ids));
        $class_ids = array_filter($class_ids, fn($id) => $id > 0);

        if (empty($class_ids)) {
            throw new Exception('Please select at least one class.');
        }

        $checkStmt = $pdo->prepare("
            SELECT id FROM exam_marksheet_releases 
            WHERE exam_id = ? AND class_id = ?
        ");
        $updateStmt = $pdo->prepare("
            UPDATE exam_marksheet_releases 
            SET release_date = ?, 
                status = ?,
                created_at = CURRENT_TIMESTAMP
            WHERE exam_id = ? AND class_id = ?
        ");
        $insertStmt = $pdo->prepare("
            INSERT INTO exam_marksheet_releases 
            (exam_id, class_id, release_date, status) 
            VALUES (?, ?, ?, ?)
        ");

        $pdo->beginTransaction();

        $insertedCount = 0;
        $updatedCount = 0;

        foreach ($class_ids as $class_id) {
            $checkStmt->execute([$exam_id, $class_id]);

            if ($checkStmt->rowCount() > 0) {
                $updateStmt->execute([$release_date, $status, $exam_id, $class_id]);
                $updatedCount++;
            } else {
                $insertStmt->execute([$exam_id, $class_id, $release_date, $status]);
                $insertedCount++;
            }
        }

        $pdo->commit();

        $parts = [];
        if ($insertedCount > 0) {
            $parts[] = "$insertedCount class(es) released";
        }
        if ($updatedCount > 0) {
            $parts[] = "$updatedCount class(es) updated";
        }
        $response['message'] = 'Marksheet release saved successfully! (' . implode(', ', $parts) . ')';
        $response['success'] = true;
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $response['message'] = $e->getMessage();
}

echo json_encode($response);