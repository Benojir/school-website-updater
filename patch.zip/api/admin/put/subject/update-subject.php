<?php
/** @var PDO $pdo */
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $subject_name = isset($_POST['subject_name']) ? safe_htmlspecialchars($_POST['subject_name']) : '';
        $subject_type = isset($_POST['subject_type']) ? safe_htmlspecialchars($_POST['subject_type']) : '';
        $class_id = isset($_POST['class_id']) ? (int)$_POST['class_id'] : 0;
        $exclude_from_marksheet = isset($_POST['exclude_from_marksheet']) ? 1 : 0;

        // 1. Basic Validation
        if ($id <= 0) {
            throw new Exception('Invalid Subject ID');
        }
        if (empty($subject_name) || empty($subject_type) || $class_id <= 0) {
            throw new Exception('Please fill in all fields');
        }

        // 3. Check if Class Exists & Get Class Name
        $classStmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
        $classStmt->execute([$class_id]);
        $classData = $classStmt->fetch(PDO::FETCH_ASSOC);

        if (!$classData) {
            throw new Exception('Selected class does not exist');
        }

        // 4. Check for Duplicate (Subject Name + Class must be unique, excluding current ID)
        $checkStmt = $pdo->prepare("SELECT id FROM subjects WHERE subject_name = ? AND class_id = ? AND id != ?");
        $checkStmt->execute([$subject_name, $class_id, $id]);

        if ($checkStmt->rowCount() > 0) {
            throw new Exception('This subject already exists for the selected class');
        }

        // 5. Update Database
        $updateStmt = $pdo->prepare("UPDATE subjects SET subject_name = ?, subject_type = ?, class_id = ?, exclude_from_marksheet = ? WHERE id = ?");
        
        if ($updateStmt->execute([$subject_name, $subject_type, $class_id, $exclude_from_marksheet, $id])) {
            $response['success'] = true;
            $response['message'] = 'Subject updated successfully';
        } else {
            throw new Exception('Failed to update subject');
        }

    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>