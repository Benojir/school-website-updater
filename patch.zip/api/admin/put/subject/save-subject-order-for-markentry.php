<?php
// File: ../../api/admin/put/subject/update-subject-order.php
include_once("../../../../includes/auth-check.php");

// Check permission (optional but recommended)
if (!hasPermission(PERM_MANAGE_RESULTS)) { // Or PERM_MANAGE_SUBJECTS
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get the POST data
$subject_order = $_POST['subject_order'] ?? [];

if (empty($subject_order)) {
    echo json_encode(['success' => false, 'message' => 'No data received']);
    exit;
}

try {
    $pdo->beginTransaction();

    // Prepare the update statement
    $stmt = $pdo->prepare("UPDATE subjects SET mark_entry_order_by = ? WHERE id = ?");

    // Loop through the received IDs. The array index determines the order.
    foreach ($subject_order as $index => $subject_id) {
        // $index is 0-based (0, 1, 2...), so we add 1 for the database sort order
        $order = $index + 1;
        $stmt->execute([$order, $subject_id]);
    }

    $pdo->commit();
    echo json_encode(['success' => true, 'message' => 'Subject order saved successfully']);

} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>