<?php
/** @var PDO $pdo */
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = [
    'success' => false, 
    'message' => '',
    'total_skipped_classes' => 0,
    'skipped_classes' => []
];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        $subject_name = isset($_POST['subject_name']) ? safe_htmlspecialchars($_POST['subject_name']) : '';
        $subject_type = isset($_POST['subject_type']) ? safe_htmlspecialchars($_POST['subject_type']) : '';
        $class_id_array = $_POST['class_id'] ?? null;
        $exclude_from_marksheet = isset($_POST['exclude_from_marksheet']) ? 1 : 0;

        // Validate inputs
        if (empty($subject_name) || empty($class_id_array) || empty($subject_type)) {
            throw new Exception('Please fill in all fields');
        }

        if (!is_array($class_id_array)) {
            throw new Exception('Invalid class selected');
        }

        $skipped_classes = [];

        foreach ($class_id_array as $class_id) {

            if (!is_numeric($class_id)) {
                $skipped_classes[] = ['id' => $class_id, 'error' => 'Invalid class ID'];
                continue;
            }

            $class_id = (int)$class_id;

            // Get class name
            $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
            $stmt->execute([$class_id]);
            $class = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$class) {
                $skipped_classes[] = ['id' => $class_id, 'error' => 'Class not found'];
                continue;
            }

            $class_name = $class['class_name'];


            // Check for duplicate subject
            $check = $pdo->prepare("SELECT id FROM subjects WHERE subject_name = ? AND class_id = ?");
            $check->execute([$subject_name, $class_id]);

            if ($check->rowCount() > 0) {
                $skipped_classes[] = ['id' => $class_id, 'error' => 'Subject already exist'];
            }

            // Insert new subject
            $insert = $pdo->prepare("INSERT INTO subjects (subject_name, subject_type, class, class_id, exclude_from_marksheet) VALUES (?, ?, ?, ?, ?)");
            if ($insert->execute([$subject_name, $subject_type, $class_name, $class_id, $exclude_from_marksheet])) {
                $response['success'] = true;
                $response['message'] = 'Subject added successfully';
            } else {
                $skipped_classes[] = ['id' => $class_id, 'error' => 'Failed to add subject into database'];
            }
        }

        $response['total_skipped_classes'] = count($skipped_classes);
        $response['skipped_classes'] = $skipped_classes;
        
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);