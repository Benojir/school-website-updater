<?php
/** @var PDO $pdo */
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['order']) || !is_array($input['order'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid data']);
    exit;
}

try {
    $pdo->beginTransaction();
    $stmt = $pdo->prepare("UPDATE subjects SET marksheet_order_by = :order WHERE id = :id");
    
    foreach ($input['order'] as $index => $subject_id) {
        $stmt->execute([':order' => $index + 1, ':id' => $subject_id]);
    }
    
    $pdo->commit();
    echo json_encode(['success' => true, 'message' => 'Subject order updated successfully']);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Failed to save order']);
}
?>