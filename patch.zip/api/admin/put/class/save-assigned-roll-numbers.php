<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");
header('Content-Type: application/json');
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}
try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') throw new RuntimeException('POST required.');
    $year = academicNormalizeYear($_POST['selected_year'] ?? academicRequireCurrentYear($pdo));
    $class = (int)($_POST['class_id'] ?? 0);
    $section = !empty($_POST['section_id']) ? (int)$_POST['section_id'] : null;
    $rolls = $_POST['roll_numbers'] ?? [];
    if (!is_array($rolls)) throw new RuntimeException('Invalid roll number input.');
    $rolls = array_filter($rolls, fn($value) => $value !== '' && $value !== null);
    if (!$rolls) throw new RuntimeException('No roll numbers were entered.');
    $pdo->beginTransaction();
    academicLockSettings($pdo);
    $batch = [];
    foreach ($rolls as $id => $roll) {
        $student = academicRequireStudentRow($pdo, (string)$id);
        $record = academicGetRecord($pdo, (int)$student['id'], $year);
        if (!$record || (int)$record['class_id'] !== $class || (int)$record['section_id'] !== (int)$section || strcasecmp(trim((string)$record['status']), 'Active') !== 0) {
            throw new RuntimeException('A student is not actively enrolled in the selected year, class and section.');
        }
        $record['roll_no'] = $roll;
        $batch[] = ['student_row_id' => (int)$student['id'], 'record_id' => (int)$record['id'], 'fields' => $record];
    }
    academicSaveRecordsBatch($pdo, $batch);
    $pdo->commit();
    echo json_encode(['success' => true, 'message' => 'Roll numbers assigned for ' . $year . '.']);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
