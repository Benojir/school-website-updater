<?php
/** @var PDO $pdo */
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    die(json_encode(['success' => false, 'message' => 'Permission denied']));
}

// Validate inputs
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['class_id']) || !isset($_POST['section_id']) || !isset($_POST['roll_numbers'])) {
    die(json_encode(['success' => false, 'message' => 'Invalid request']));
}

$class_id = (int)$_POST['class_id'];
$section_id = !empty($_POST['section_id']) ? (int)$_POST['section_id'] : null;
$raw_roll_numbers = $_POST['roll_numbers'];

// 1. Filter out empty values (Flexible Submission Logic)
$roll_numbers = array_filter($raw_roll_numbers, function($value) {
    return $value !== '' && $value !== null;
});

// If no numbers were entered at all, stop here
if (empty($roll_numbers)) {
    die(json_encode(['success' => false, 'message' => 'No roll numbers were entered to save.']));
}

// Verify class
$stmt = $pdo->prepare("SELECT id FROM classes WHERE id = ?");
$stmt->execute([$class_id]);
if (!$stmt->fetch()) {
    die(json_encode(['success' => false, 'message' => 'Invalid class ID']));
}

// Verify section
if ($section_id !== null) {
    $stmt = $pdo->prepare("SELECT id FROM sections WHERE id = ? AND class_id = ?");
    $stmt->execute([$section_id, $class_id]);
    if (!$stmt->fetch()) {
        die(json_encode(['success' => false, 'message' => 'Invalid section ID or section does not belong to class']));
    }
}

try {
    $pdo->beginTransaction();

    foreach ($roll_numbers as $roll_no) {
        if (!is_numeric($roll_no) || $roll_no <= 0) {
            die(json_encode(['success' => false, 'message' => 'Roll numbers must be positive integers']));
        }
    }

    // Validate all roll numbers are unique in this class-section
    $submitted_rolls = array_values($roll_numbers);
    if (count($submitted_rolls) !== count(array_unique($submitted_rolls))) {
        die(json_encode(['success' => false, 'message' => 'Duplicate roll numbers detected in your input']));
    }

    // Check against existing roll numbers in the class-section
    $whereClause = "class_id = ? AND roll_no IS NOT NULL";
    $params = [$class_id];

    if ($section_id !== null) {
        $whereClause .= " AND section_id = ?";
        $params[] = $section_id;
    } else {
        $whereClause .= " AND (section_id IS NULL OR section_id = 0)";
    }

    $stmt = $pdo->prepare("
        SELECT roll_no 
        FROM students 
        WHERE $whereClause
    ");
    $stmt->execute($params);
    $existing_rolls = $stmt->fetchAll(PDO::FETCH_COLUMN);

    $conflicts = array_intersect($submitted_rolls, $existing_rolls);
    if (!empty($conflicts)) {
        die(json_encode([
            'success' => false,
            'message' => 'Roll number conflict with existing students: ' . implode(', ', $conflicts)
        ]));
    }

    // Update roll numbers
    foreach ($roll_numbers as $student_id => $roll_no) {
        $whereClause = "student_id = ? AND class_id = ?";
        $params = [$roll_no, $student_id, $class_id];

        if ($section_id !== null) {
            $whereClause .= " AND section_id = ?";
            $params[] = $section_id;
        } else {
            $whereClause .= " AND (section_id IS NULL OR section_id = 0)";
        }

        $stmt = $pdo->prepare("
            UPDATE students 
            SET roll_no = ?, updated_at = NOW()
            WHERE $whereClause
        ");
        $stmt->execute($params);
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Roll numbers assigned successfully!'
    ]);
} catch (PDOException $e) {
    $pdo->rollBack();
    error_log("Roll number assignment error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
