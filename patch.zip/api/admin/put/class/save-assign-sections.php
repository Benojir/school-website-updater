<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");
header('Content-Type: application/json');
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}
try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') throw new RuntimeException('POST required.');
    $year = academicNormalizeYear($_POST['selected_year'] ?? academicRequireCurrentYear($pdo));
    $class = (int)($_POST['class_id'] ?? 0);
    $sections = $_POST['sections'] ?? [];
    if (!is_array($sections) || !$sections) throw new RuntimeException('No sections selected.');
    $pdo->beginTransaction();
    academicLockSettings($pdo);
    $batch = [];
    foreach ($sections as $rowId => $section) {
        // This existing form sends the numeric students.id, not the public Student ID.
        $studentRowId = academicPositiveId($rowId, 'Student row ID');
        if ($studentRowId === null) throw new InvalidArgumentException('Student row ID is required.');
        $stmt = $pdo->prepare('SELECT id FROM students WHERE id = ?');
        $stmt->execute([$studentRowId]);
        if (!$stmt->fetchColumn()) throw new RuntimeException('Student not found.');
        $record = academicGetRecord($pdo, $studentRowId, $year);
        if (!$record || (int)$record['class_id'] !== $class || strcasecmp(trim((string)$record['status']), 'Active') !== 0) throw new RuntimeException('Student is not actively enrolled in the selected year and class.');
        $record['section_id'] = $section;
        $batch[] = ['student_row_id' => $studentRowId, 'record_id' => (int)$record['id'], 'fields' => $record];
    }
    academicSaveRecordsBatch($pdo, $batch);
    $pdo->commit();
    echo json_encode(['success' => true, 'message' => count($sections) . ' sections assigned for ' . $year . '.']);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
