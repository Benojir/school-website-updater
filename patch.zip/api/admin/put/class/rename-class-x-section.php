<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-type: application/json');

// Check if user is superadmin only
if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = ['success' => false, 'message' => '', 'newName' => 'Error'];

$itemId = isset($_POST['itemId']) ? $_POST['itemId'] : '';
$itemType = isset($_POST['itemType']) ? $_POST['itemType'] : '';
$newName = isset($_POST['newName']) ? sanitize_input($_POST['newName']) : '';

if (empty($itemId) || empty($itemType) || empty($newName)) {
    $response['message'] = 'All fields are required.';
    echo json_encode($response);
    exit;
}

if ($itemType !== "class" && $itemType !== "section") {
    $response['message'] = 'Invalid request.';
    echo json_encode($response);
    exit;
}

$tableName = "";
$columnName = "";

if ($itemType === "class") {
    $tableName = "classes";
    $columnName = "class_name";

    // Check same class or not
    $stmt = $pdo->prepare("SELECT {$columnName} FROM {$tableName} WHERE {$columnName} = :new_name");
    $stmt->execute([':new_name' => $newName]);
    if ($stmt->rowCount() > 0) {
        $response['message'] = 'Same class name is already exist. Try another name.';
        echo json_encode($response);
        exit;
    }
}

if ($itemType === "section") {
    $tableName = "sections";
    $columnName = "section_name";
}

try {
    $stmt = $pdo->prepare("UPDATE {$tableName} SET {$columnName} = :new_name WHERE id = :id");
    if ($stmt->execute([':new_name' => $newName, ':id' => $itemId])) {
        if ($stmt->rowCount() > 0) {
            $response['success'] = true;
            $response['message'] = ucwords($itemType) . " renamed successfully! New name is " . $newName;
            $response['newName'] = $newName;
        } else {
            $response['message'] = "No changes made (same name or invalid ID).";
        }
    }
} catch (PDOException $e) {
    $response['message'] = "Error: " . $e->getMessage();
}


echo json_encode($response);
