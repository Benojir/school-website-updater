<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

// Check admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    die(json_encode(['success' => false, 'message' => 'Permission denied']));
}

// Validate inputs
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['class_id']) || !isset($_POST['sections'])) {
    die(json_encode(['success' => false, 'message' => 'Invalid request']));
}

$class_id = (int)$_POST['class_id'];
$sections = $_POST['sections'];

// Verify class exists
$stmt = $pdo->prepare("SELECT id FROM classes WHERE id = ?");
$stmt->execute([$class_id]);
if (!$stmt->fetch()) {
    die(json_encode(['success' => false, 'message' => 'Invalid class ID']));
}

try {
    $pdo->beginTransaction();

    // Verify all students belong to the class
    $student_ids = array_keys($sections);
    $placeholders = implode(',', array_fill(0, count($student_ids), '?'));
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count 
        FROM students 
        WHERE id IN ($placeholders) AND class_id = ?
    ");
    $params = array_merge($student_ids, [$class_id]);
    $stmt->execute($params);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result['count'] != count($student_ids)) {
        die(json_encode(['success' => false, 'message' => 'Some students do not belong to the specified class']));
    }

    // Verify all section IDs belong to the class
    $unique_section_ids = array_unique(array_values($sections));
    $section_placeholders = implode(',', array_fill(0, count($unique_section_ids), '?'));
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count 
        FROM sections 
        WHERE id IN ($section_placeholders) AND class_id = ?
    ");
    $params = array_merge($unique_section_ids, [$class_id]);
    $stmt->execute($params);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result['count'] != count($unique_section_ids)) {
        die(json_encode(['success' => false, 'message' => 'Some sections do not belong to the specified class']));
    }

    // Update student sections
    foreach ($sections as $student_id => $section_id) {
        $stmt = $pdo->prepare("
            UPDATE students 
            SET section_id = ?, updated_at = NOW()
            WHERE id = ? AND class_id = ?
        ");
        $stmt->execute([$section_id, $student_id, $class_id]);
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => count($sections) . ' students assigned to sections successfully!'
    ]);
} catch (PDOException $e) {
    $pdo->rollBack();
    error_log("Section assignment error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}