<?php
require_once __DIR__ . '/../../../../includes/auth-check.php';
require_once __DIR__ . '/../../../../includes/academic/class-order-service.php';
header('Content-Type: application/json');
header('Cache-Control: no-store');

if (!isSuperAdmin()) {
    http_response_code(403);
    exit(json_encode(['success'=>false,'message'=>'Only the super administrator can arrange classes.']));
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); header('Allow: POST');
    exit(json_encode(['success'=>false,'message'=>'Use POST to save the class order.']));
}
if (empty($_SESSION['class_order_csrf']) || !hash_equals($_SESSION['class_order_csrf'],$_SERVER['HTTP_X_CSRF_TOKEN']??'')) {
    http_response_code(403);
    exit(json_encode(['success'=>false,'message'=>'This page expired. Reload before saving.']));
}
try {
    $input=json_decode(file_get_contents('php://input'),true,32,JSON_THROW_ON_ERROR);
    saveClassOrder($pdo,$input['order']??null);
    echo json_encode(['success'=>true,'message'=>'Class order saved. Class dropdowns will follow this order.']);
} catch (ClassOrderConflict $e) {
    http_response_code(409);
    echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
} catch (InvalidArgumentException|JsonException $e) {
    http_response_code(422);
    echo json_encode(['success'=>false,'message'=>'Invalid class order. Send each class once.']);
} catch (Throwable $e) {
    error_log('Save class order: '.$e->getMessage());
    http_response_code(500);
    echo json_encode(['success'=>false,'message'=>'Class order could not be saved. Reload and try again.']);
}
