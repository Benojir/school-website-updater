<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_CLASS_ROUTINES)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $class_id = $_POST['class_id'] ?? null;
    $section_id = $_POST['section_id'] ?? null;
    // Capture days as an array (expecting day_name[] from frontend)
    $day_names = $_POST['day_name'] ?? []; 
    $start_time = $_POST['start_time'] ?? null;
    $end_time = $_POST['end_time'] ?? null;
    $subject_id = $_POST['subject_id'] ?? null;
    $teacher_id = $_POST['teacher_id'] ?? null;
    $room_number = $_POST['room_number'] ?? null;
    
    // Validate required fields
    // Ensure $day_names is not empty and is an array
    if (!$class_id || !$section_id || empty($day_names) || !is_array($day_names) || !$start_time || !$end_time || !$subject_id) {
        $response['message'] = "Required fields must be filled";
        echo json_encode($response);
        exit;
    }
    
    try {
        $pdo->beginTransaction();
        
        // 1. Prepare Check Conflict Statement (Class/Section Time Slot)
        $check_conflict = $pdo->prepare("SELECT id FROM class_routines 
                                        WHERE class_id = ? AND section_id = ? AND day_name = ? 
                                        AND (
                                            (start_time <= ? AND end_time > ?) OR 
                                            (start_time < ? AND end_time >= ?) OR 
                                            (start_time >= ? AND end_time <= ?)
                                        )");

        // 2. Prepare Teacher Availability Statement
        // Note: Using named placeholders might be clearer, but sticking to positional ? for consistency with previous code
        // We only prepare this if a teacher is assigned, but strictly speaking, we can prepare it once.
        $check_teacher = $pdo->prepare("SELECT cr.id, c.class_name, s.section_name 
                                       FROM class_routines cr
                                       JOIN classes c ON cr.class_id = c.id
                                       JOIN sections s ON cr.section_id = s.id
                                       WHERE cr.teacher_id = ? AND cr.day_name = ? 
                                       AND (
                                           (cr.start_time <= ? AND cr.end_time > ?) OR 
                                           (cr.start_time < ? AND cr.end_time >= ?) OR 
                                           (cr.start_time >= ? AND cr.end_time <= ?)
                                       )");

        // 3. Prepare Insert Statement
        $insert_stmt = $pdo->prepare("INSERT INTO class_routines 
                                  (class_id, section_id, day_name, start_time, end_time, subject_id, teacher_id, room_number) 
                                  VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

        // Iterate through each selected day
        foreach ($day_names as $day) {
            
            // --- A. Check for Section Time Conflict ---
            $check_conflict->execute([
                $class_id, 
                $section_id, 
                $day, 
                $start_time, $start_time,
                $end_time, $end_time,
                $start_time, $end_time
            ]);
            
            if ($check_conflict->rowCount() > 0) {
                // Rollback immediately if any day conflicts
                $pdo->rollBack();
                $response['message'] = "Conflict detected on <strong>$day</strong>: This time slot overlaps with an existing routine.";
                echo json_encode($response);
                exit;
            }

            // --- B. Check Teacher Availability ---
            if ($teacher_id) {
                $check_teacher->execute([
                    $teacher_id, 
                    $day, 
                    $start_time, $start_time,
                    $end_time, $end_time,
                    $start_time, $end_time
                ]);
                
                if ($check_teacher->rowCount() > 0) {
                    $conflict = $check_teacher->fetch();
                    $pdo->rollBack();
                    $response['message'] = "Conflict on <strong>$day</strong>: Teacher is already assigned to <strong>{$conflict['class_name']} - {$conflict['section_name']}</strong>.";
                    echo json_encode($response);
                    exit;
                }
            }
            
            // --- C. Insert Routine for this Day ---
            $insert_stmt->execute([
                $class_id, 
                $section_id, 
                $day, 
                $start_time, 
                $end_time, 
                $subject_id, 
                $teacher_id, 
                $room_number
            ]);
        }

        // If loop completes without errors, commit all changes
        $pdo->commit();
        $response['success'] = true;
        $response['message'] = "Routines added successfully for " . count($day_names) . " day(s)!";

    } catch (PDOException $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $response['message'] = "Database error: " . $e->getMessage();
    }
} else {
    $response['message'] = "Invalid request method";
}

echo json_encode($response);
?>