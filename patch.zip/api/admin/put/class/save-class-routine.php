<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_CLASS_ROUTINES)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $class_id = $_POST['class_id'] ?? null;
    $section_id = $_POST['section_id'] ?? null;
    $day_name = $_POST['day_name'] ?? null;
    $start_time = $_POST['start_time'] ?? null;
    $end_time = $_POST['end_time'] ?? null;
    $subject_id = $_POST['subject_id'] ?? null;
    $teacher_id = $_POST['teacher_id'] ?? null;
    $room_number = $_POST['room_number'] ?? null;
    
    // Validate required fields
    if (!$class_id || !$section_id || !$day_name || !$start_time || !$end_time || !$subject_id) {
        $response['message'] = "Required fields must be filled";
        echo json_encode($response);
        exit;
    }
    
    try {
        $pdo->beginTransaction();
        
        // Check for time conflicts
        $check_conflict = $pdo->prepare("SELECT id FROM class_routines 
                                        WHERE class_id = ? AND section_id = ? AND day_name = ? 
                                        AND (
                                            (start_time <= ? AND end_time > ?) OR 
                                            (start_time < ? AND end_time >= ?) OR 
                                            (start_time >= ? AND end_time <= ?)
                                        )");
        $check_conflict->execute([$class_id, $section_id, $day_name, 
                                $start_time, $start_time,
                                $end_time, $end_time,
                                $start_time, $end_time]);
        
        if ($check_conflict->rowCount() > 0) {
            $response['message'] = "This time slot conflicts with an existing routine";
        } else {
            // Check teacher availability
            if ($teacher_id) {
                $check_teacher = $pdo->prepare("SELECT cr.id, c.class_name, s.section_name 
                                               FROM class_routines cr
                                               JOIN classes c ON cr.class_id = c.id
                                               JOIN sections s ON cr.section_id = s.id
                                               WHERE cr.teacher_id = ? AND cr.day_name = ? 
                                               AND (
                                                   (cr.start_time <= ? AND cr.end_time > ?) OR 
                                                   (cr.start_time < ? AND cr.end_time >= ?) OR 
                                                   (cr.start_time >= ? AND cr.end_time <= ?)
                                               )");
                $check_teacher->execute([$teacher_id, $day_name, 
                                       $start_time, $start_time,
                                       $end_time, $end_time,
                                       $start_time, $end_time]);
                
                if ($check_teacher->rowCount() > 0) {
                    $conflict = $check_teacher->fetch();
                    $response['message'] = "This teacher is already assigned to {$conflict['class_name']} - {$conflict['section_name']} at this time.";
                    echo json_encode($response);
                    exit;
                }
            }
            
            $stmt = $pdo->prepare("INSERT INTO class_routines 
                                  (class_id, section_id, day_name, start_time, end_time, subject_id, teacher_id, room_number) 
                                  VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$class_id, $section_id, $day_name, $start_time, $end_time, $subject_id, $teacher_id, $room_number]);
            $pdo->commit();
            $response['success'] = true;
            $response['message'] = "Routine added successfully!";
        }
    } catch (PDOException $e) {
        $pdo->rollBack();
        $response['message'] = "Database error: " . $e->getMessage();
    }
} else {
    $response['message'] = "Invalid request method";
}

echo json_encode($response);
?>