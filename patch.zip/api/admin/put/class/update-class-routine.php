<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");
header('Content-Type: application/json');

if (!hasPermission(PERM_MANAGE_CLASS_ROUTINES)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    die();
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $routine_id = $_POST['routine_id'] ?? null;
    $class_id   = $_POST['class_id'] ?? null;   // needed for validation
    $section_id = $_POST['section_id'] ?? null; // needed for validation
    $day_name   = $_POST['day_name'] ?? null;
    $start_time = $_POST['start_time'] ?? null;
    $end_time   = $_POST['end_time'] ?? null;
    $subject_id = $_POST['subject_id'] ?? null;
    $teacher_id = $_POST['teacher_id'] ?? null;
    $room_number = $_POST['room_number'] ?? null;

    if (!$routine_id || !$day_name || !$start_time || !$end_time || !$subject_id) {
        echo json_encode(['success' => false, 'message' => 'Required fields missing']);
        exit;
    }

    try {
        // 1. Check for Conflicts (excluding current routine ID)
        $check = $pdo->prepare("SELECT id FROM class_routines 
                                WHERE class_id = ? AND section_id = ? AND day_name = ? AND id != ?
                                AND (
                                    (start_time <= ? AND end_time > ?) OR 
                                    (start_time < ? AND end_time >= ?) OR 
                                    (start_time >= ? AND end_time <= ?)
                                )");
        $check->execute([$class_id, $section_id, $day_name, $routine_id,
                         $start_time, $start_time, $end_time, $end_time, $start_time, $end_time]);

        if ($check->rowCount() > 0) {
            echo json_encode(['success' => false, 'message' => 'Time conflict with another class!']);
            exit;
        }

        // 2. Check Teacher Conflict (excluding current routine ID)
        if ($teacher_id) {
            $t_check = $pdo->prepare("SELECT id FROM class_routines 
                                      WHERE teacher_id = ? AND day_name = ? AND id != ?
                                      AND (
                                          (start_time <= ? AND end_time > ?) OR 
                                          (start_time < ? AND end_time >= ?) OR 
                                          (start_time >= ? AND end_time <= ?)
                                      )");
            $t_check->execute([$teacher_id, $day_name, $routine_id,
                               $start_time, $start_time, $end_time, $end_time, $start_time, $end_time]);

            if ($t_check->rowCount() > 0) {
                echo json_encode(['success' => false, 'message' => 'Teacher is busy at this time!']);
                exit;
            }
        }

        // 3. Update
        $stmt = $pdo->prepare("UPDATE class_routines 
                               SET day_name = ?, start_time = ?, end_time = ?, subject_id = ?, teacher_id = ?, room_number = ?
                               WHERE id = ?");
        $stmt->execute([$day_name, $start_time, $end_time, $subject_id, $teacher_id, $room_number, $routine_id]);

        echo json_encode(['success' => true, 'message' => 'Routine updated successfully']);

    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'DB Error: ' . $e->getMessage()]);
    }
}
?>