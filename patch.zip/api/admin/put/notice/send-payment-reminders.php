<?php
/** @var array $schoolInfo
 ** @var PDO $pdo */

include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

function respond(array $payload): void {
    echo json_encode($payload);
    exit;
}

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_FEES)) {
    respond(['success' => false, 'message' => 'You do not have permission to perform this action.']);
}

// --- Config: move these out of source into your config/env file ---
// require_once __DIR__ . '/../../../../includes/config.php';
// Expected constants: SMS_BRIDGE_URL, SMS_BRIDGE_TOKEN
if (!defined('SMS_BRIDGE_URL') || !defined('SMS_BRIDGE_TOKEN')) {
    // Fallback so this file still runs if you haven't wired config yet.
    // Replace these with your real config include above ASAP - do not ship hardcoded secrets.
    define('SMS_BRIDGE_URL', 'https://schoolsongi.com/sms/message/send.php');
    define('SMS_BRIDGE_TOKEN', 'nuralam543210');
}

$ALLOWED_VIA = ['whatsapp', 'sms'];

$via = $_POST['via'] ?? 'whatsapp';
if (!in_array($via, $ALLOWED_VIA, true)) {
    $via = 'whatsapp';
}

$last_payment_date_raw = $_POST['last_payment_date'] ?? null;
$student_ids_raw = $_POST['student_ids'] ?? null;

if (!$student_ids_raw || !$last_payment_date_raw) {
    respond(['success' => false, 'message' => 'Student IDs and last payment date are required']);
}

// Date validation
$timestamp = strtotime($last_payment_date_raw);
if (!$timestamp) {
    respond(['success' => false, 'message' => 'Invalid last payment date format']);
}
$last_payment_date = date('j M, Y', $timestamp);

// Accept either "1,2,3" (string) or student_ids[] (array) safely.
if (is_array($student_ids_raw)) {
    $student_ids = $student_ids_raw;
} else {
    $student_ids = explode(',', (string)$student_ids_raw);
}

$student_ids = array_values(array_unique(array_filter(array_map('trim', $student_ids), 'strlen')));

if (empty($student_ids)) {
    respond(['success' => false, 'message' => 'At least one valid student ID is required']);
}

$students_data = [];
$total_skipped = 0;

// NOTE: getStudentInfo()/getTotalUnpaidAmount() are called once per student here.
// If your DB layer allows it, replace this loop with a single batched query
// (e.g. getStudentsInfoBulk($pdo, $student_ids) and a single unpaid-amount query
// keyed by student id) to eliminate the N+1 query pattern - that will speed up
// large batches far more than anything on the HTTP side.
foreach ($student_ids as $student_id) {
    $student = getStudentInfo($pdo, $student_id);
    if (!$student) {
        $total_skipped++;
        continue;
    }

    $unpaid_amount = getTotalUnpaidAmount($student_id);

    if ($unpaid_amount <= 0) {
        $total_skipped++;
        continue;
    }

    if (empty($student['phone_number'])) {
        $total_skipped++;
        continue;
    }

    $students_data[] = [
        'id' => $student_id,
        'name' => $student['name'],
        'phone' => $student['phone_number'],
        'unpaid_amount' => $unpaid_amount,
        'last_payment_date' => $last_payment_date,
        'via' => $via,
        'school_name' => $schoolInfo['name'],
        'school_contact_1' => $schoolInfo['phone'],
        'school_contact_2' => $schoolInfo['alternate_phone'] ?? null,
        'school_id' => SCHOOL_ID,
        'token' => SMS_BRIDGE_TOKEN,
    ];
}

if (empty($students_data)) {
    respond(['success' => false, 'message' => 'No students found with unpaid fees', 'skipped_count' => $total_skipped]);
}

// Send to the internal SMS bridge with sane timeouts so a stuck gateway
// can't hang this request forever.
$ch = curl_init(SMS_BRIDGE_URL);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($students_data),
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 5,
    CURLOPT_TIMEOUT => 30,
]);

$response = curl_exec($ch);
$curl_error = curl_error($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($response === false) {
    respond(['success' => false, 'message' => 'cURL Error: ' . $curl_error]);
}

if ($http_code < 200 || $http_code >= 300) {
    respond(['success' => false, 'message' => 'SMS bridge returned HTTP ' . $http_code]);
}

$decoded = json_decode($response, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    respond(['success' => false, 'message' => 'Invalid response from SMS bridge']);
}

// Strip the shared secret token out of anything that gets echoed back to the
// browser - it should never leave the server boundary.
if (isset($decoded['skipped_students']) && is_array($decoded['skipped_students'])) {
    foreach ($decoded['skipped_students'] as &$s) {
        unset($s['token']);
    }
    unset($s);
}

echo json_encode($decoded);