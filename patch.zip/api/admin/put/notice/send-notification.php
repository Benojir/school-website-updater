<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'error' => true
    ]);
    die();
}

// Check if required data is provided
if (
    !isset($_POST['student_ids']) || empty($_POST['student_ids']) ||
    !isset($_POST['notification_title']) || empty($_POST['notification_title']) ||
    !isset($_POST['notification_message']) || empty($_POST['notification_message'])
) {
    echo json_encode([
        'success' => false,
        'message' => 'Required fields are missing.',
        'error' => true
    ]);
    die();
}

$studentIds = sanitize_input($_POST['student_ids'] ?? null);
$notificationTitle = sanitize_input($_POST['notification_title'] ?? null);
$notificationMessage = sanitize_input($_POST['notification_message'] ?? null);

if (empty($studentIds) || empty($notificationTitle) || empty($notificationMessage)) {
    echo json_encode([
        'success' => false,
        'message' => 'All fields are required.',
        'error' => true
    ]);
    die();
}

try {
    // Get form data
    $studentIds = explode(',', $studentIds);

    $deviceTokens = getFCMTokensFromDatabase($pdo, $studentIds);

    // If no device tokens found, return an error
    if (empty($deviceTokens)) {
        echo json_encode([
            'success' => false,
            'message' => 'No device tokens found for the selected students.',
            'error' => true
        ]);
        die();
    }

    $data = [
        'title' => $notificationTitle,
        'message' => $notificationMessage
    ];

    $result = sendFirebaseNotification($pdo, $studentIds, $deviceTokens, $notificationTitle, $notificationMessage, $data);

    if (!$result['success']) {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to send notification: ' . $result['message'],
            'error' => true
        ]);
        die();
    }

    // Deleting older notification logs more than 1.5 years old
    deleteOlderNotificationLogs($pdo, 550);

    // Assuming the notification was sent successfully
    echo json_encode([
        'success' => true,
        'message' => 'Notification sent successfully to ' . count($deviceTokens) . ' devices.',
        'error' => false,
        'sent_count' => count($studentIds)
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred while sending the notification: ' . $e->getMessage(),
        'error' => true
    ]);
}
