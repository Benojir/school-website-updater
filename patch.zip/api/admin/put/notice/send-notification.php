<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'error' => true
    ]);
    die();
}

// Check if required data is provided
if (
    !isset($_POST['student_ids']) || empty($_POST['student_ids']) ||
    !isset($_POST['notification_title']) || empty($_POST['notification_title']) ||
    !isset($_POST['notification_message']) || empty($_POST['notification_message'])
) {
    echo json_encode([
        'success' => false,
        'message' => 'Required fields are missing.',
        'error' => true
    ]);
    die();
}

try {
    // Get form data
    $studentIds = explode(',', $_POST['student_ids']);
    $notificationTitle = $_POST['notification_title'];
    $notificationMessage = $_POST['notification_message'];

    $deviceTokens = [];
    $parent_phone_numbers = [];

    // Process notification sending logic here
    foreach ($studentIds as $studentId) {

        $stmt = $pdo->prepare("SELECT phone_number FROM students WHERE student_id = ? LIMIT 1");
        $stmt->execute([$studentId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $phone_number = $result ? $result['phone_number'] : null;

        if (!empty($phone_number)) {

            if (in_array($phone_number, $parent_phone_numbers)) {
                continue; // Skip if this phone number has already been processed
            }
            $parent_phone_numbers[] = $phone_number;

            $stmt = $pdo->prepare("SELECT id FROM parent_accounts WHERE phone_number = ?");
            $stmt->execute([$phone_number]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $parent_id = $result ? $result['id'] : null;

            if (!empty($parent_id)) {
                $stmt = $pdo->prepare("SELECT fcm_token FROM parent_mobile_sessions WHERE parent_id = ?");
                $stmt->execute([$parent_id]);
                $tokens = $stmt->fetchAll(PDO::FETCH_COLUMN);
                if (!$tokens) {
                    continue; // Skip if no tokens found for this parent
                }
                foreach ($tokens as $token) {
                    $deviceTokens[] = $token; // Return an array of device tokens
                }
            }
        }
    }

    // If no device tokens found, return an error
    if (empty($deviceTokens)) {
        echo json_encode([
            'success' => false,
            'message' => 'No device tokens found for the selected students.',
            'error' => true
        ]);
        die();
    }

    $data = [
        'title' => $notificationTitle,
        'message' => $notificationMessage
    ];

    $result = sendFirebaseNotification($deviceTokens, $notificationTitle, $notificationMessage, $data);

    if (!$result['success']) {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to send notification: ' . $result['message'],
            'error' => true
        ]);
        die();
    }

    // Assuming the notification was sent successfully
    echo json_encode([
        'success' => true,
        'message' => 'Notification sent successfully to ' . count($deviceTokens) . ' devices.',
        'error' => false,
        'sent_count' => count($studentIds)
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred while sending the notification: ' . $e->getMessage(),
        'error' => true
    ]);
}
