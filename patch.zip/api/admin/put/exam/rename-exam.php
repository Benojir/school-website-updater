<?php
/** @var PDO $pdo */
include_once("../../../../includes/auth-check.php");

header('Content-Type: application/json');

// 2. Check Permissions
if (!hasPermission(PERM_MANAGE_EXAMS)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied.']);
    exit;
}

// 3. Validate Request Method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}

// 4. Validate Inputs
$exam_id = isset($_POST['exam_id']) ? intval($_POST['exam_id']) : 0;
$new_name = isset($_POST['new_exam_name']) ? trim($_POST['new_exam_name']) : '';

if ($exam_id <= 0 || empty($new_name)) {
    echo json_encode(['success' => false, 'message' => 'Invalid exam ID or empty name provided.']);
    exit;
}

try {
    // 5. Check if another exam already has this name (Optional but recommended to prevent duplicates)
    $checkStmt = $pdo->prepare("SELECT id FROM exams WHERE exam_name = ? AND id != ? AND status = 'active'");
    $checkStmt->execute([$new_name, $exam_id]);
    $result = $checkStmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        echo json_encode(['success' => false, 'message' => 'An active exam with this name already exists.']);
        exit;
    }

    // 6. Perform the Update
    $stmt = $pdo->prepare("UPDATE exams SET exam_name = ? WHERE id = ?");

    if ($stmt->execute([$new_name, $exam_id])) {
        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Exam renamed successfully.']);
        } else {
            // Query ran, but nothing changed (maybe name was the same or ID not found)
            echo json_encode(['success' => true, 'message' => 'No changes made (name might be the same).']);
        }
    } else {
        throw new Exception("Database execution failed.");
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'An internal error occurred while renaming the exam.']);
}

?>