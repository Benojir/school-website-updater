<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_EXAMS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $exam_id = (int)$_POST['exam_id'];
        $class_id = (int)$_POST['class_id'];
        $release_date = $_POST['release_date'];
        $status = 'released'; // Default status
        
        // Check if release already exists
        $checkStmt = $pdo->prepare("
            SELECT id FROM exam_admit_releases 
            WHERE exam_id = ? AND class_id = ?
        ");
        $checkStmt->execute([$exam_id, $class_id]);
        
        if ($checkStmt->rowCount() > 0) {
            // Update existing
            $stmt = $pdo->prepare("
                UPDATE exam_admit_releases 
                SET release_date = ?, 
                    status = ?,
                    created_at = CURRENT_TIMESTAMP
                WHERE exam_id = ? AND class_id = ?
            ");
            $stmt->execute([$release_date, $status, $exam_id, $class_id]);
            $response['message'] = 'Admit card release updated successfully!';
        } else {
            // Insert new
            $stmt = $pdo->prepare("
                INSERT INTO exam_admit_releases 
                (exam_id, class_id, release_date, status) 
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([$exam_id, $class_id, $release_date, $status]);
            $response['message'] = 'Admit card release created successfully!';
        }
        
        $response['success'] = true;
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);