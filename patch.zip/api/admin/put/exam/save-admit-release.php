<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_EXAMS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $exam_id = (int)$_POST['exam_id'];
        $release_date = $_POST['release_date'];
        $status = 'released'; // Default status

        // class_id now comes as an array from the multi-select (name="class_id[]")
        $class_ids = $_POST['class_id'] ?? [];
        if (!is_array($class_ids)) {
            // Fallback in case a single value is ever posted without brackets
            $class_ids = [$class_ids];
        }
        // Sanitize to unique positive integers
        $class_ids = array_unique(array_map('intval', $class_ids));
        $class_ids = array_filter($class_ids, fn($id) => $id > 0);

        if (empty($class_ids)) {
            throw new Exception('Please select at least one class.');
        }

        $checkStmt = $pdo->prepare("
            SELECT id FROM exam_admit_releases 
            WHERE exam_id = ? AND class_id = ?
        ");
        $updateStmt = $pdo->prepare("
            UPDATE exam_admit_releases 
            SET release_date = ?, 
                status = ?,
                created_at = CURRENT_TIMESTAMP
            WHERE exam_id = ? AND class_id = ?
        ");
        $insertStmt = $pdo->prepare("
            INSERT INTO exam_admit_releases 
            (exam_id, class_id, release_date, status) 
            VALUES (?, ?, ?, ?)
        ");

        $pdo->beginTransaction();

        $insertedCount = 0;
        $updatedCount = 0;

        foreach ($class_ids as $class_id) {
            $checkStmt->execute([$exam_id, $class_id]);

            if ($checkStmt->rowCount() > 0) {
                $updateStmt->execute([$release_date, $status, $exam_id, $class_id]);
                $updatedCount++;
            } else {
                $insertStmt->execute([$exam_id, $class_id, $release_date, $status]);
                $insertedCount++;
            }
        }

        $pdo->commit();

        $parts = [];
        if ($insertedCount > 0) {
            $parts[] = "$insertedCount class(es) released";
        }
        if ($updatedCount > 0) {
            $parts[] = "$updatedCount class(es) updated";
        }
        $response['message'] = 'Admit card release saved successfully! (' . implode(', ', $parts) . ')';
        $response['success'] = true;
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $response['message'] = $e->getMessage();
}

echo json_encode($response);