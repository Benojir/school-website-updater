<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_EXAMS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $exam_name = isset($_POST['exam_name']) ? ucwords(trim($_POST['exam_name'])) : '';
        $exam_date = isset($_POST['exam_date']) ? $_POST['exam_date'] : '';

        // Validate inputs
        if (empty($exam_name) || empty($exam_date)) {
            throw new Exception('Please fill in all fields');
        }

        // Check for duplicate exam
        $checkStmt = $pdo->prepare("SELECT id FROM exams WHERE exam_name = :exam_name AND exam_date = :exam_date");
        $checkStmt->execute([
            ':exam_name' => $exam_name,
            ':exam_date' => $exam_date
        ]);

        if ($checkStmt->rowCount() > 0) {
            throw new Exception('An exam with the same name and date already exists');
        }

        // Insert new exam
        $stmt = $pdo->prepare("INSERT INTO exams (exam_name, exam_date) VALUES (:exam_name, :exam_date)");
        if ($stmt->execute([':exam_name' => $exam_name, ':exam_date' => $exam_date])) {
            $response['success'] = true;
            $response['message'] = 'Exam added successfully';
        } else {
            throw new Exception('Failed to add exam to database');
        }
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);