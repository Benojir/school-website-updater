<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_EXAMS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $exam_id = isset($_POST['exam_id']) ? (int)$_POST['exam_id'] : 0;
        
        if ($exam_id > 0) {
            // Check if exam exists and is active
            $stmt = $pdo->prepare("SELECT id FROM exams WHERE id = ? AND status = 'active'");
            $stmt->execute([$exam_id]);
            
            if ($stmt->rowCount() > 0) {
                // Archive the exam
                $update_stmt = $pdo->prepare("UPDATE exams SET status = 'archived' WHERE id = ?");
                if ($update_stmt->execute([$exam_id])) {
                    $response['success'] = true;
                    $response['message'] = 'Exam archived successfully!';
                } else {
                    throw new Exception('Failed to archive exam');
                }
            } else {
                throw new Exception('Exam not found or already archived');
            }
        } else {
            throw new Exception('Invalid exam ID');
        }
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);