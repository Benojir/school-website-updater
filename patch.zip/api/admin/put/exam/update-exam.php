<?php
/** @var PDO $pdo */
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_EXAMS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    $exam_id   = isset($_POST['exam_id']) ? (int)$_POST['exam_id'] : 0;
    $exam_name = isset($_POST['exam_name']) ? trim($_POST['exam_name']) : '';
    $exam_date = isset($_POST['exam_date']) ? trim($_POST['exam_date']) : '';

    if ($exam_id <= 0) {
        throw new Exception('Invalid exam ID');
    }

    if ($exam_name === '' || $exam_date === '') {
        throw new Exception('Exam name and exam date are both required.');
    }

    // Make sure the given date is a real calendar date in Y-m-d format
    $parsed_date = DateTime::createFromFormat('Y-m-d', $exam_date);
    if (!$parsed_date || $parsed_date->format('Y-m-d') !== $exam_date) {
        throw new Exception('Please provide a valid exam date.');
    }

    // 1. Load the exam that is being edited
    $examStmt = $pdo->prepare("SELECT exam_name, exam_date FROM exams WHERE id = ? AND status = 'active'");
    $examStmt->execute([$exam_id]);
    $exam = $examStmt->fetch();

    if (!$exam) {
        throw new Exception('Exam not found or it is archived.');
    }

    // 2. No other active exam is allowed to use the same name
    $dupStmt = $pdo->prepare("SELECT id FROM exams WHERE exam_name = ? AND id != ? AND status = 'active'");
    $dupStmt->execute([$exam_name, $exam_id]);

    if ($dupStmt->fetch()) {
        throw new Exception('An active exam with this name already exists.');
    }

    // 3. An exam cannot start after a subject that is already scheduled in its routine.
    //    Checked only when the date is actually being changed, so editing just the name
    //    never gets blocked by an already saved routine.
    if ($exam_date !== $exam['exam_date']) {
        // MIN() ignores NULL, so a subject with only a written or only an oral
        // sitting is still counted correctly.
        $routineStmt = $pdo->prepare("
            SELECT MIN(theory_exam_date) AS earliest_theory_date,
                   MIN(practical_exam_date) AS earliest_practical_date
            FROM exam_routines
            WHERE exam_id = ?
        ");
        $routineStmt->execute([$exam_id]);
        $routine = $routineStmt->fetch();

        // Keep only usable dates, then take the first scheduled sitting of this exam
        $routine_dates = array_filter(
            [$routine['earliest_theory_date'], $routine['earliest_practical_date']],
            function ($date) {
                return !empty($date) && $date !== '0000-00-00';
            }
        );

        $earliest_routine_date = !empty($routine_dates) ? min($routine_dates) : null;

        if (!empty($earliest_routine_date) && strtotime($exam_date) > strtotime($earliest_routine_date)) {
            // Send the unchanged date back so the form can be reset to it
            $response['current_exam_date'] = $exam['exam_date'];
            $response['earliest_routine_date'] = $earliest_routine_date;

            throw new Exception(
                'Exam date cannot be changed to ' . formatDate($exam_date) . '. '
                    . 'The routine of this exam already has a subject scheduled on ' . formatDate($earliest_routine_date) . ', '
                    . 'and an exam cannot start after a subject that is already in its routine. '
                    . 'The exam date has been kept as ' . formatDate($exam['exam_date']) . '. '
                    . 'Please pick a date on or before ' . formatDate($earliest_routine_date) . ', or update the exam routine first.'
            );
        }
    }

    // 4. Save the changes
    $updateStmt = $pdo->prepare("UPDATE exams SET exam_name = ?, exam_date = ? WHERE id = ?");
    $updateStmt->execute([$exam_name, $exam_date, $exam_id]);

    $response['success']   = true;
    $response['message']   = $updateStmt->rowCount() > 0
        ? 'Exam updated successfully.'
        : 'No changes were made to the exam.';
    $response['exam_name'] = $exam_name;
    $response['exam_date'] = $exam_date;
} catch (PDOException $e) {
    error_log('update-exam.php failed: ' . $e->getMessage());
    $response['success'] = false;
    $response['message'] = 'An internal error occurred while updating the exam.';
} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
