<?php
/** @var PDO $pdo */
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

if (!hasPermission(PERM_MANAGE_EXAMS)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied.']);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Invalid request method");
    }

    $exam_id = (int)$_POST['exam_id'];
    $class_id = (int)$_POST['class_id'];
    $subjects = $_POST['subjects'] ?? [];

    if (empty($subjects)) {
        throw new Exception("Please add at least one subject to the schedule");
    }

    $pdo->beginTransaction();

    // 1. Get exam base date for validation
    $exam_stmt = $pdo->prepare("SELECT exam_date FROM exams WHERE id = ?");
    $exam_stmt->execute([$exam_id]);
    $exam_data = $exam_stmt->fetch();

    if (!$exam_data) {
        throw new Exception("Invalid exam selected");
    }

    $base_exam_date = $exam_data['exam_date'];

    // 2. Fetch existing scheduled subjects to prevent duplicates
    $existing_stmt = $pdo->prepare("SELECT subject_id FROM exam_routines WHERE exam_id = ? AND class_id = ?");
    $existing_stmt->execute([$exam_id, $class_id]);
    $existing_subjects = $existing_stmt->fetchAll(PDO::FETCH_COLUMN);

    $conflicts = [];
    $processed_subject_ids = []; 
    $valid_batch = []; // This holds data waiting to be inserted

    // Check against Database (Existing Records)
    $overlap_stmt = $pdo->prepare("
        SELECT subject_id FROM exam_routines 
        WHERE exam_id = ? 
        AND class_id = ? 
        AND theory_exam_date = ? 
        AND (
            (theory_start_time < ? AND theory_end_time > ?)
        )
    ");

    $insert_stmt = $pdo->prepare("
        INSERT INTO exam_routines 
        (exam_id, class_id, subject_id, theory_marks, practical_marks, 
         theory_exam_date, theory_start_time, theory_end_time,
         practical_exam_date, practical_start_time, practical_end_time) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");


    // --- PHASE 1: VALIDATION ---
    foreach ($subjects as $subject) {
        $subject_id = (int)$subject['subject_id'];
        $subject_name = htmlspecialchars($subject['subject_name']);
        
        // Data Extraction
        $theory_marks = (float)$subject['theory_marks'];
        $practical_marks = (float)$subject['practical_marks'];
        $theory_date = $subject['theory_exam_date'];
        $theory_start = $subject['theory_start_time'];
        $theory_end = $subject['theory_end_time'];
        
        $prac_date = !empty($subject['practical_exam_date']) ? $subject['practical_exam_date'] : null;
        $prac_start = !empty($subject['practical_start_time']) ? $subject['practical_start_time'] : null;
        $prac_end = !empty($subject['practical_end_time']) ? $subject['practical_end_time'] : null;

        // Basic Validations
        if (empty($subject_id) || empty($theory_date) || empty($theory_start) || empty($theory_end)) {
            $conflicts[] = "Written exam details missing for {$subject_name}";
            continue; 
        }

        if ($practical_marks > 0 && (empty($prac_date) || empty($prac_start) || empty($prac_end))) {
            $conflicts[] = "Oral exam details required for {$subject_name}";
            continue;
        }

        if (strtotime($theory_end) <= strtotime($theory_start)) {
            $conflicts[] = "End time must be after Start time for {$subject_name}";
            continue;
        }

        // Duplicate Check (Database)
        if (in_array($subject_id, $existing_subjects)) {
            $conflicts[] = "{$subject_name} is already scheduled in the system";
            continue;
        }

        // Duplicate Check (Current Batch)
        if (in_array($subject_id, $processed_subject_ids)) {
            $conflicts[] = "Duplicate entry for {$subject_name} in this list";
            continue;
        }

        // ---------------------------------------------------------
        // CONFLICT CHECK 1: Check against DATABASE (Existing Rows)
        // ---------------------------------------------------------
        // Overlap Logic: (StartA < EndB) AND (EndA > StartB)
        $overlap_stmt->execute([
            $exam_id, $class_id, $theory_date, 
            $theory_end, $theory_start
        ]);

        if ($overlap_stmt->rowCount() > 0) {
            $conflicts[] = "Time conflict: {$subject_name} clashes with an existing saved exam on {$theory_date}.";
            continue;
        }

        // ---------------------------------------------------------
        // CONFLICT CHECK 2: Check against CURRENT BATCH (Items in this list)
        // ---------------------------------------------------------
        // We loop through $valid_batch to ensure this new item doesn't clash with 
        // an item we just processed 5 milliseconds ago in this same loop.
        foreach ($valid_batch as $queued_item) {
            // Index 5 = Date, 6 = StartTime, 7 = EndTime (based on the array structure below)
            $queued_date = $queued_item[5];
            $queued_start = $queued_item[6];
            $queued_end = $queued_item[7];

            if ($queued_date === $theory_date) {
                // Check if times overlap
                if ($theory_start < $queued_end && $theory_end > $queued_start) {
                    $conflicts[] = "Conflict inside this list: {$subject_name} overlaps with another subject you are adding on {$theory_date}.";
                    // Break inner loop so we don't report the same error multiple times
                    break; 
                }
            }
        }

        // Only if we survived all checks, add to batch
        if (empty($conflicts)) {
            $valid_batch[] = [
                $exam_id, $class_id, $subject_id, $theory_marks, $practical_marks,
                $theory_date, $theory_start, $theory_end,
                $prac_date, $prac_start, $prac_end
            ];
            $processed_subject_ids[] = $subject_id;
        }
    }

    // --- PHASE 2: DECISION ---
    if (!empty($conflicts)) {
        $pdo->rollBack(); 
        $response['success'] = false;
        $response['message'] = "Save failed due to conflicts:\n- " . implode("\n- ", $conflicts);
        echo json_encode($response);
        exit;
    }

    // --- PHASE 3: EXECUTION ---
    $success_count = 0;
    foreach ($valid_batch as $row) {
        if ($insert_stmt->execute($row)) {
            $success_count++;
        }
    }

    if ($success_count == count($valid_batch)) {
        $pdo->commit();
        $response['success'] = true;
        $response['message'] = "Successfully scheduled all $success_count subjects.";
    } else {
        $pdo->rollBack();
        throw new Exception("Database error occurred while saving subjects.");
    }

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $response['success'] = false;
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>