<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_EXAMS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $exam_id = (int)$_POST['exam_id'];
        $class_id = (int)$_POST['class_id'];
        $subjects = $_POST['subjects'] ?? [];

        if (empty($subjects)) {
            throw new Exception("Please add at least one subject to the schedule");
        }

        $pdo->beginTransaction();

        // Get exam date for validation
        $exam_stmt = $pdo->prepare("SELECT exam_date FROM exams WHERE id = ?");
        $exam_stmt->execute([$exam_id]);
        $exam_data = $exam_stmt->fetch();

        if (!$exam_data) {
            throw new Exception("Invalid exam selected");
        }

        $exam_date = $exam_data['exam_date'];

        // Check for existing routines for this exam and class
        $existing_stmt = $pdo->prepare("
            SELECT subject_id FROM exam_routines 
            WHERE exam_id = ? AND class_id = ?
        ");
        $existing_stmt->execute([$exam_id, $class_id]);
        $existing_subjects = $existing_stmt->fetchAll(PDO::FETCH_COLUMN);

        $conflicts = [];
        $success_count = 0;

        foreach ($subjects as $subject) {
            $subject_id = (int)$subject['subject_id'];
            $theory_marks = (int)$subject['theory_marks'];
            $practical_marks = (int)$subject['practical_marks'];
            $subject_exam_date = $subject['exam_date'];
            $start_time = $subject['start_time'];
            $end_time = $subject['end_time'];
            $room_number = $subject['room_number'];

            // Basic field validation
            if (empty($subject_id) || empty($subject_exam_date) || empty($start_time) || empty($end_time) || empty($room_number)) {
                $conflicts[] = "All fields are required for {$subject['subject_name']}";
                continue;
            }

            if ($theory_marks < 0 || $practical_marks < 0) {
                $conflicts[] = "Marks cannot be negative for {$subject['subject_name']}";
                continue;
            }

            // Validate exam date is not before the exam's date
            if (strtotime($subject_exam_date) < strtotime($exam_date)) {
                $conflicts[] = "Exam date for {$subject['subject_name']} cannot be before the exam start date";
                continue;
            }

            // Validate time
            if (strtotime($end_time) <= strtotime($start_time)) {
                $conflicts[] = "End time must be after start time for {$subject['subject_name']}";
                continue;
            }

            // Check if this subject is already scheduled
            if (in_array($subject_id, $existing_subjects)) {
                $conflicts[] = "{$subject['subject_name']} is already scheduled for this exam";
                continue;
            }

            // Check for time conflict
            $conflict_stmt = $pdo->prepare("
                SELECT er.id, s.subject_name 
                FROM exam_routines er
                JOIN subjects s ON er.subject_id = s.id
                WHERE er.exam_date = ? 
                AND er.room_number = ?
                AND ((er.start_time <= ? AND er.end_time > ?) OR (er.start_time < ? AND er.end_time >= ?))
            ");
            $conflict_stmt->execute([$subject_exam_date, $room_number, $start_time, $start_time, $end_time, $end_time]);
            
            if ($conflict_row = $conflict_stmt->fetch()) {
                $conflicts[] = "Conflict with {$conflict_row['subject_name']} in room {$room_number} at this time";
                continue;
            }

            // Insert routine
            $stmt = $pdo->prepare("
                INSERT INTO exam_routines 
                (exam_id, class_id, subject_id, theory_marks, practical_marks, exam_date, start_time, end_time, room_number) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            if ($stmt->execute([$exam_id, $class_id, $subject_id, $theory_marks, $practical_marks, 
                               $subject_exam_date, $start_time, $end_time, $room_number])) {
                $success_count++;
            } else {
                $conflicts[] = "Error adding {$subject['subject_name']} to schedule";
            }
        }

        if ($success_count > 0) {
            $pdo->commit();
            $message = "Successfully scheduled $success_count subjects";
            
            if (!empty($conflicts)) {
                $message .= ". Issues: " . implode(", ", array_slice($conflicts, 0, 3));
                if (count($conflicts) > 3) {
                    $message .= " and " . (count($conflicts) - 3) . " more";
                }
            }
            
            $response['success'] = true;
            $response['message'] = $message;
        } else {
            $pdo->rollBack();
            $response['message'] = "Failed to schedule any subjects. Issues: " . implode(", ", $conflicts);
        }
    } else {
        throw new Exception("Invalid request method");
    }
} catch (Exception $e) {
    $pdo->rollBack();
    $response['message'] = $e->getMessage();
}

echo json_encode($response);