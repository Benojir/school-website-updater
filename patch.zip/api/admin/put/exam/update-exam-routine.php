<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

if (!hasPermission(PERM_MANAGE_EXAMS)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied.']);
    die();
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Invalid request method");
    }

    $id = (int)$_POST['id'];
    $exam_id = (int)$_POST['exam_id'];
    $class_id = (int)$_POST['class_id'];
    
    // Data Extraction
    $theory_marks = (float)$_POST['theory_marks'];
    $practical_marks = (float)$_POST['practical_marks'];
    $theory_date = $_POST['theory_exam_date'];
    $theory_start = $_POST['theory_start_time'];
    $theory_end = $_POST['theory_end_time'];
    
    $prac_date = !empty($_POST['practical_exam_date']) ? $_POST['practical_exam_date'] : null;
    $prac_start = !empty($_POST['practical_start_time']) ? $_POST['practical_start_time'] : null;
    $prac_end = !empty($_POST['practical_end_time']) ? $_POST['practical_end_time'] : null;

    // --- Validation ---
    if (empty($id) || empty($theory_date) || empty($theory_start) || empty($theory_end)) {
        throw new Exception("Written exam details are incomplete");
    }

    if ($practical_marks > 0 && (empty($prac_date) || empty($prac_start) || empty($prac_end))) {
        throw new Exception("Oral exam details are required because marks are greater than 0");
    }

    if (strtotime($theory_end) <= strtotime($theory_start)) {
        throw new Exception("Written End time must be after Start time");
    }

    // --- Conflict Check ---
    // FIXED: Added 'er.' prefix to exam_id and class_id to resolve ambiguity
    $check_stmt = $pdo->prepare("
        SELECT er.subject_id, s.subject_name 
        FROM exam_routines er
        JOIN subjects s ON er.subject_id = s.id
        WHERE er.exam_id = ? 
        AND er.class_id = ? 
        AND er.theory_exam_date = ? 
        AND (
            (er.theory_start_time < ? AND er.theory_end_time > ?)
        )
        AND er.id != ?
    ");

    $check_stmt->execute([
        $exam_id, $class_id, $theory_date, 
        $theory_end, $theory_start,
        $id
    ]);

    if ($check_stmt->rowCount() > 0) {
        $conflict = $check_stmt->fetch(PDO::FETCH_ASSOC);
        throw new Exception("Time conflict: Overlaps with " . $conflict['subject_name']);
    }

    // --- Update ---
    $update_stmt = $pdo->prepare("
        UPDATE exam_routines SET 
        theory_marks = ?, 
        practical_marks = ?, 
        theory_exam_date = ?, 
        theory_start_time = ?, 
        theory_end_time = ?,
        practical_exam_date = ?, 
        practical_start_time = ?, 
        practical_end_time = ?
        WHERE id = ?
    ");

    $result = $update_stmt->execute([
        $theory_marks, $practical_marks, 
        $theory_date, $theory_start, $theory_end,
        $prac_date, $prac_start, $prac_end,
        $id
    ]);

    if ($result) {
        echo json_encode(['success' => true, 'message' => 'Routine updated successfully']);
    } else {
        throw new Exception("Database update failed");
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>