<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

if (!hasPermission(PERM_MANAGE_EXAMS)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied.']);
    die();
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Invalid request method");
    }

    $id = (int)$_POST['id'];
    $exam_id = (int)$_POST['exam_id'];
    $class_id = (int)$_POST['class_id'];
    
    // Data Extraction
    $theory_marks = (float)$_POST['theory_marks'];
    $practical_marks = (float)$_POST['practical_marks'];
    
    // লজিক: মার্কস ০ হলে শিডিউল null
    $theory_date = ($theory_marks > 0 && !empty($_POST['theory_exam_date'])) ? $_POST['theory_exam_date'] : null;
    $theory_start = ($theory_marks > 0 && !empty($_POST['theory_start_time'])) ? $_POST['theory_start_time'] : null;
    $theory_end = ($theory_marks > 0 && !empty($_POST['theory_end_time'])) ? $_POST['theory_end_time'] : null;

    $prac_date = ($practical_marks > 0 && !empty($_POST['practical_exam_date'])) ? $_POST['practical_exam_date'] : null;
    $prac_start = ($practical_marks > 0 && !empty($_POST['practical_start_time'])) ? $_POST['practical_start_time'] : null;
    $prac_end = ($practical_marks > 0 && !empty($_POST['practical_end_time'])) ? $_POST['practical_end_time'] : null;

    // --- Validation Logic Matching Save Process ---
    $hasTheory = !empty($theory_date) && !empty($theory_start) && !empty($theory_end);
    $hasPractical = !empty($prac_date) && !empty($prac_start) && !empty($prac_end);

    if (empty($id)) {
        throw new Exception("Invalid routine ID");
    }

    // --- Validation Logic Matching Save Process ---
    $hasTheory = !empty($theory_date) && !empty($theory_start) && !empty($theory_end);
    $hasPractical = !empty($prac_date) && !empty($prac_start) && !empty($prac_end);

    if (!$hasTheory && !$hasPractical) {
        throw new Exception("Theory অথবা Practical যেকোনো একটির শিডিউল দিতে হবে");
    }

    // Marks strict validation
    if ($theory_marks > 0 && !$hasTheory) {
        throw new Exception("Written exam details are incomplete based on theory marks");
    }
    if ($practical_marks > 0 && !$hasPractical) {
        throw new Exception("Oral exam details are required because marks are greater than 0");
    }

    // Incomplete details validation
    if ((!empty($theory_date) || !empty($theory_start) || !empty($theory_end)) && !$hasTheory) {
        throw new Exception("Written exam details are incomplete");
    }
    if ((!empty($prac_date) || !empty($prac_start) || !empty($prac_end)) && !$hasPractical) {
        throw new Exception("Oral exam details are incomplete");
    }

    // Time validation
    if ($hasTheory && strtotime($theory_end) <= strtotime($theory_start)) {
        throw new Exception("Written End time must be after Start time");
    }
    if ($hasPractical && strtotime($prac_end) <= strtotime($prac_start)) {
        throw new Exception("Oral End time must be after Start time");
    }

    // --- Conflict Check ---
    // শুধুমাত্র থিওরি শিডিউল থাকলেই ওভারল্যাপ চেক করা হবে
    if ($hasTheory) {
        $check_stmt = $pdo->prepare("
            SELECT er.subject_id, s.subject_name 
            FROM exam_routines er
            JOIN subjects s ON er.subject_id = s.id
            WHERE er.exam_id = ? 
            AND er.class_id = ? 
            AND er.theory_exam_date = ? 
            AND (
                (er.theory_start_time < ? AND er.theory_end_time > ?)
            )
            AND er.id != ?
        ");

        $check_stmt->execute([
            $exam_id, $class_id, $theory_date, 
            $theory_end, $theory_start,
            $id
        ]);

        if ($check_stmt->rowCount() > 0) {
            $conflict = $check_stmt->fetch(PDO::FETCH_ASSOC);
            throw new Exception("Time conflict: Overlaps with " . $conflict['subject_name']);
        }
    }

    // --- Update ---
    $update_stmt = $pdo->prepare("
        UPDATE exam_routines SET 
        theory_marks = ?, 
        practical_marks = ?, 
        theory_exam_date = ?, 
        theory_start_time = ?, 
        theory_end_time = ?,
        practical_exam_date = ?, 
        practical_start_time = ?, 
        practical_end_time = ?
        WHERE id = ?
    ");

    $result = $update_stmt->execute([
        $theory_marks, $practical_marks, 
        $theory_date, $theory_start, $theory_end,
        $prac_date, $prac_start, $prac_end,
        $id
    ]);

    if ($result) {
        echo json_encode(['success' => true, 'message' => 'Routine updated successfully']);
    } else {
        throw new Exception("Database update failed");
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>