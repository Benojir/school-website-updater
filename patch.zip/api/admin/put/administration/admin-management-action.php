<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = ['success' => false, 'message' => 'Invalid request'];

try {
    // Handle GET requests
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // Delete admin
        if (isset($_GET['delete_admin'])) {
            $adminId = (int)$_GET['delete_admin'];

            // Delete the admin user
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND user_role = 'admin'");
            $stmt->execute([$adminId]);

            if ($stmt->rowCount() > 0) {
                $response = ['success' => true, 'message' => 'Admin deleted successfully!'];
            } else {
                $response = ['success' => false, 'message' => 'Cannot delete this admin or admin not found'];
            }
        }
        // Delete role
        elseif (isset($_GET['delete_role'])) {
            $roleId = (int)$_GET['delete_role'];

            $pdo->beginTransaction();

            // Delete users with this role
            $stmt = $pdo->prepare("DELETE FROM users WHERE role_id = ? AND user_role = 'admin'");
            $stmt->execute([$roleId]);

            // Delete the role (permissions will be deleted automatically due to CASCADE)
            $stmt = $pdo->prepare("DELETE FROM admin_roles WHERE id = ?");
            $stmt->execute([$roleId]);

            $pdo->commit();
            $response = ['success' => true, 'message' => 'Role deleted successfully!'];
        }
        // Get admins for table
        elseif (isset($_GET['get_admins'])) {
            $admins = $pdo->query("
                SELECT u.*, r.name as role_name 
                FROM users u
                LEFT JOIN admin_roles r ON u.role_id = r.id
                WHERE u.user_role = 'admin'
            ")->fetchAll();

            $html = '';
            foreach ($admins as $admin) {
                $html .= '<tr data-id="' . $admin['id'] . '">';
                $html .= '<td>' . $admin['id'] . '</td>';
                $html .= '<td>' . safe_htmlspecialchars($admin['full_name']) . '</td>';
                $html .= '<td>' . safe_htmlspecialchars($admin['username']) . '</td>';
                $html .= '<td>' . safe_htmlspecialchars($admin['email']) . '</td>';
                $html .= '<td>' . safe_htmlspecialchars($admin['role_name'] ?? 'No Role') . '</td>';
                $html .= '<td>' . ucfirst($admin['status']) . '</td>';
                $html .= '<td><button class="btn btn-sm btn-danger delete-admin" data-id="' . $admin['id'] . '" data-name="' . safe_htmlspecialchars($admin['full_name']) . '">Delete</button></td>';
                $html .= '</tr>';
            }
            echo $html;
            exit();
        }
        // Get roles for table
        elseif (isset($_GET['get_roles'])) {
            $rolesWithCounts = $pdo->query("
                SELECT r.*, 
                       COUNT(p.id) as permissions_count,
                       COUNT(u.id) as admins_count
                FROM admin_roles r
                LEFT JOIN admin_permissions p ON r.id = p.role_id
                LEFT JOIN users u ON r.id = u.role_id AND u.user_role = 'admin'
                GROUP BY r.id
            ")->fetchAll();

            // Prepare the JSON response
            $response = [];

            foreach ($rolesWithCounts as $role) {
                $response[] = [
                    'id' => $role['id'],
                    'name' => $role['name'],
                    'description' => $role['description'],
                    'permissions_count' => $role['permissions_count'],
                    'admins_count' => $role['admins_count']
                ];
            }

            // Set header to JSON
            header('Content-Type: application/json');
            echo json_encode($response);
            exit();
        }
    }
    // Handle POST requests
    elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Create new role
        if (isset($_POST['create_role'])) {
            $roleName = safe_htmlspecialchars(trim($_POST['role_name']));
            $description = safe_htmlspecialchars(trim($_POST['role_description']));
            $permissions = $_POST['permissions'] ?? [];

            if (empty($roleName)) {
                $response = ['success' => false, 'message' => 'Role name is required'];
            } else {
                $pdo->beginTransaction();

                // Insert the new role
                $stmt = $pdo->prepare("INSERT INTO admin_roles (name, description) VALUES (?, ?)");
                $stmt->execute([$roleName, $description]);
                $roleId = $pdo->lastInsertId();

                // Insert permissions
                if (!empty($permissions)) {
                    $stmt = $pdo->prepare("INSERT INTO admin_permissions (role_id, permission) VALUES (?, ?)");
                    foreach ($permissions as $permission) {
                        $stmt->execute([$roleId, $permission]);
                    }
                }

                $pdo->commit();
                $response = ['success' => true, 'message' => 'Role created successfully!'];
            }
        }
        // Create new admin
        elseif (isset($_POST['create_admin'])) {
            $fullName = safe_htmlspecialchars(trim($_POST['full_name']));
            $username = trim($_POST['username']);
            $password = $_POST['password'];
            $email = safe_htmlspecialchars(trim($_POST['email']));
            $roleId = (int)$_POST['role_id'];

            // Validate inputs
            if (empty($fullName) || empty($username) || empty($password) || empty($email) || empty($roleId)) {
                $response = ['success' => false, 'message' => 'All fields are required'];
            } elseif (strlen($password) < 8) {
                $response = ['success' => false, 'message' => 'Password must be at least 8 characters'];
            } else {
                // Check if username exists
                $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
                $stmt->execute([$username]);

                // Check if email exists
                $stmtEmail = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
                $stmtEmail->execute([$email]);

                if ($stmt->fetch()) {
                    $response = ['success' => false, 'message' => 'Username already exists'];
                } elseif ($stmtEmail->fetch()) {
                    $response = ['success' => false, 'message' => 'Email Id is already assigned with an admin'];
                } else {
                    // Hash password
                    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

                    // Insert new admin
                    $stmt = $pdo->prepare("
                        INSERT INTO users 
                        (full_name, username, password, user_role, role_id, status, email, created_at, updated_at) 
                        VALUES (?, ?, ?, 'admin', ?, 'active', ?, NOW(), NOW())
                    ");
                    $stmt->execute([$fullName, $username, $hashedPassword, $roleId, $email]);

                    $response = ['success' => true, 'message' => 'Admin created successfully!'];
                }
            }
        }
    }
} catch (PDOException $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    $response = ['success' => false, 'message' => 'Database error: ' . $e->getMessage()];
} catch (Exception $e) {
    $response = ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
}

echo json_encode($response);
