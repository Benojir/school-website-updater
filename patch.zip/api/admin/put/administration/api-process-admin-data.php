<?php
// api-process-data.php
include_once(__DIR__ . "/../../../../includes/auth-check.php");

if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$action = $_POST['action'] ?? '';

// 1. Create OR Update Admin
if ($action === 'save_admin') {
    $id = isset($_POST['admin_id']) && !empty($_POST['admin_id']) ? (int)$_POST['admin_id'] : null;
    $fullName = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $roleId = (int)($_POST['role_id'] ?? 0);
    $password = $_POST['password'] ?? '';

    // Validate inputs
    if (empty($fullName) || empty($username) || empty($email) || empty($roleId)) {
        echo json_encode(['success' => false, 'message' => 'All fields are required!']);
        exit();
    }

    // Check if email is valid
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Invalid email format!']);
        exit();
    }

    // Check if role exists
    $stmt = $pdo->prepare("SELECT id FROM admin_roles WHERE id = ?");
    $stmt->execute([$roleId]);
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Invalid role!']);
        exit();
    }

    // Validate username
    if (strlen($username) < 3 || strlen($username) > 25) {
        echo json_encode(['success' => false, 'message' => 'Username must be 3-25 characters long!']);
        exit();
    }

    // Check if username contains spaces
    if (strpos($username, ' ') !== false) {
        echo json_encode(['success' => false, 'message' => 'Username cannot contain spaces!']);
        exit();
    }

    // Validate password
    if (!empty($password) && strlen($password) < 6) {
        echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters long!']);
        exit();
    }

    // Validate full name
    if (strlen($fullName) < 3 || strlen($fullName) > 50) {
        echo json_encode(['success' => false, 'message' => 'Full name must be 3-50 characters long!']);
        exit();
    }

    // Validations
    $checkSql = "SELECT id FROM users WHERE (username = ? OR email = ?)";
    $params = [$username, $email];
    if ($id) {
        $checkSql .= " AND id != ?"; // Exclude current user if editing
        $params[] = $id;
    }

    $stmt = $pdo->prepare($checkSql);
    $stmt->execute($params);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Username or Email already exists!']);
        exit();
    }

    if ($id) {
        // UPDATE Existing Admin
        if (!empty($password)) {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $update = $pdo->prepare("UPDATE users SET full_name=?, username=?, email=?, role_id=?, password=?, updated_at=NOW() WHERE id=?");
            $update->execute([$fullName, $username, $email, $roleId, $hashed, $id]);
        } else {
            $update = $pdo->prepare("UPDATE users SET full_name=?, username=?, email=?, role_id=?, updated_at=NOW() WHERE id=?");
            $update->execute([$fullName, $username, $email, $roleId, $id]);
        }
        echo json_encode(['success' => true, 'message' => 'Admin updated successfully!']);
    } else {
        // CREATE New Admin
        if (empty($password)) {
            echo json_encode(['success' => false, 'message' => 'Password required for new admin']);
            exit;
        }
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $insert = $pdo->prepare("INSERT INTO users (full_name, username, password, user_role, role_id, status, email, created_at, updated_at) VALUES (?, ?, ?, 'admin', ?, 'active', ?, NOW(), NOW())");
        $insert->execute([$fullName, $username, $hashed, $roleId, $email]);
        echo json_encode(['success' => true, 'message' => 'Admin created successfully!']);
    }
    exit();
}

// 2. Create OR Update Role
if ($action === 'save_role') {
    $id = isset($_POST['role_id']) && !empty($_POST['role_id']) ? (int)$_POST['role_id'] : null;
    $name = trim($_POST['role_name']);
    $desc = trim($_POST['role_description']);
    $permissions = $_POST['permissions'] ?? [];

    $pdo->beginTransaction();
    try {
        if ($id) {
            // Update Role
            $stmt = $pdo->prepare("UPDATE admin_roles SET name = ?, description = ? WHERE id = ?");
            $stmt->execute([$name, $desc, $id]);
            // Delete old perms to re-insert new ones
            $pdo->prepare("DELETE FROM admin_permissions WHERE role_id = ?")->execute([$id]);
            $roleId = $id;
            $msg = "Role updated successfully!";
        } else {
            // Create Role
            $stmt = $pdo->prepare("INSERT INTO admin_roles (name, description) VALUES (?, ?)");
            $stmt->execute([$name, $desc]);
            $roleId = $pdo->lastInsertId();
            $msg = "Role created successfully!";
        }

        // Insert Permissions
        if (!empty($permissions)) {
            $pStmt = $pdo->prepare("INSERT INTO admin_permissions (role_id, permission) VALUES (?, ?)");
            foreach ($permissions as $perm) {
                $pStmt->execute([$roleId, $perm]);
            }
        }
        $pdo->commit();
        echo json_encode(['success' => true, 'message' => $msg]);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'Database error']);
    }
    exit();
}
