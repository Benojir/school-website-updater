<?php
require_once("../../../../includes/auth-check.php"); 

header('Content-Type: application/json');

// পারমিশন চেক
if (!hasPermission(PERM_MANAGE_PARENTS)) {
    echo json_encode(['success' => false, 'message' => 'You do not have permission to perform this action.']);
    exit;
}

$session_id = isset($_REQUEST['session_id']) ? intval($_REQUEST['session_id']) : 0;

if ($session_id > 0) {
    // Delete the session from the table
    $stmt = $pdo->prepare("DELETE FROM parent_auth_sessions WHERE id = ?");
    $logout = $stmt->execute([$session_id]);

    if ($logout) {
        echo json_encode(['success' => true, 'message' => 'Logout successful']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Database error during logout']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid Session ID']);
}
?>