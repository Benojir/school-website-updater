<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

$authData = authenticateAdminApiRequest($pdo);

// Check admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    die(json_encode(['success' => false, 'message' => 'Permission denied']));
}

// Validate inputs
$required = ['student_ids', 'current_class_id', 'graduation_date'];
foreach ($required as $field) {
    if (empty($_POST[$field])) {
        die(json_encode(['success' => false, 'message' => "Missing required field: $field"]));
    }
}

$student_ids = explode(',', $_POST['student_ids']);
$student_ids = array_filter(array_map('trim', $student_ids));
$current_class_id = (int)$_POST['current_class_id'];
$graduation_date = $_POST['graduation_date'];
$remarks = $_POST['remarks'] ?? '';

try {
    $pdo->beginTransaction();
    
    // Verify all students are from the final class
    $placeholders = implode(',', array_fill(0, count($student_ids), '?'));
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as student_count
        FROM students s
        JOIN classes c ON s.class_id = c.id
        WHERE s.student_id IN ($placeholders) 
        AND c.is_final_class = 1
    ");
    $stmt->execute($student_ids);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result['student_count'] != count($student_ids)) {
        die(json_encode([
            'success' => false,
            'message' => 'Some students are not in the final class'
        ]));
    }
    
    // Update students' status to Alumni
    $stmt = $pdo->prepare("
        UPDATE students SET 
            roll_no = NULL,
            status = 'Alumni',
            updated_at = NOW()
        WHERE student_id IN ($placeholders)
    ");
    $stmt->execute($student_ids);
    
    // Mark all results as promoted
    $stmt = $pdo->prepare("
        UPDATE results SET 
            is_promoted = 1,
            updated_at = NOW()
        WHERE student_id IN ($placeholders)
    ");
    $stmt->execute($student_ids);
    
    // Log this graduation action
    $created_by = $authData['user_id'] ?? null;
    $stmt = $pdo->prepare("
        INSERT INTO graduation_logs (
            class_id, 
            graduation_date, 
            remarks, 
            graduated_count, 
            created_by
        ) VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $current_class_id,
        $graduation_date,
        $remarks,
        count($student_ids),
        $created_by
    ]);
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Successfully graduated ' . count($student_ids) . ' students'
    ]);
    
} catch (PDOException $e) {
    $pdo->rollBack();
    error_log("Graduation error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}