<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");
header('Content-Type: application/json');
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}
try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') throw new RuntimeException('POST required.');
    $year = academicNormalizeYear($_POST['selected_year'] ?? academicRequireCurrentYear($pdo));
    $ids = array_values(array_unique(array_filter(array_map('trim', explode(',', $_POST['student_ids'] ?? '')))));
    if (!$ids) throw new RuntimeException('Select students to graduate.');
    $graduationDate = academicDate($_POST['graduation_date'] ?? null);
    if ($graduationDate === null) throw new InvalidArgumentException('Graduation date is required.');
    $pdo->beginTransaction();
    academicLockSettings($pdo);
    foreach ($ids as $id) {
        $student = academicRequireStudentRow($pdo, $id);
        $record = academicGetRecord($pdo, (int)$student['id'], $year);
        if (!$record || strcasecmp(trim((string)$record['status']), 'Active') !== 0) throw new RuntimeException('Selected year must contain an active enrollment for every student.');
        $stmt = $pdo->prepare('SELECT is_final_class FROM classes WHERE id = ?');
        $stmt->execute([$record['class_id']]);
        if (!(int)$stmt->fetchColumn()) throw new RuntimeException('Every student must be in the final class for the selected year.');
        academicSetStatus($pdo, $id, 'Alumni', $year, $graduationDate);
        $stmt = $pdo->prepare('UPDATE results SET is_promoted = 1, updated_at = NOW() WHERE student_id = ? AND academic_year = ?');
        $stmt->execute([$id, $year]);
    }
    $pdo->commit();
    echo json_encode(['success' => true, 'message' => count($ids) . ' students graduated. Historical rolls and admission dates are preserved.']);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
