<?php
ob_start();
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    function clean($data)
    {
        return ucwords(safe_htmlspecialchars(trim($data)));
    }

    function saveBase64Image(string $base64_string, string $upload_dir, $prefix = 'stu_')
    {
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
        if (preg_match('/^data:image\/(\w+);base64,/', $base64_string, $type)) {
            $data = substr($base64_string, strpos($base64_string, ',') + 1);
            $type = strtolower($type[1]);
            if (!in_array($type, ['jpg', 'jpeg', 'png', 'gif'])) return false;
            $data = base64_decode($data);
            if ($data === false || strlen($data) > 2 * 1024 * 1024) return false;
        } else {
            return false;
        }
        $file_name = uniqid($prefix) . '.' . $type;
        $file_path = $upload_dir . $file_name;
        if (file_put_contents($file_path, $data)) {
            if (!getimagesize($file_path)) {
                unlink($file_path);
                return false;
            }
            return $file_name;
        }
        return false;
    }

    function isRollNumberUnique(PDO $pdo, $roll_no, $class_id, $section_id, $student_id)
    {
        // Added AND section_id = :section_id
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE roll_no = :roll_no AND class_id = :class_id AND section_id = :section_id AND student_id != :student_id");
        $stmt->execute([
            ':roll_no' => $roll_no,
            ':class_id' => $class_id,
            ':section_id' => $section_id, // Pass section_id
            ':student_id' => $student_id
        ]);
        return $stmt->fetchColumn() == 0;
    }

    function getStudentCurrentSection($pdo, $student_id)
    {
        $stmt = $pdo->prepare("SELECT section_id FROM students WHERE student_id = :student_id");
        $stmt->execute([':student_id' => $student_id]);
        return $stmt->fetchColumn();
    }

    function isRegistrationNoUnique($pdo, $reg_no, $student_id)
    {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE registration_no = :reg_no AND student_id != :student_id");
        $stmt->execute([':reg_no' => $reg_no, ':student_id' => $student_id]);
        return $stmt->fetchColumn() == 0;
    }

    function getStudentClassId($pdo, $student_id)
    {
        $stmt = $pdo->prepare("SELECT class_id FROM students WHERE student_id = :student_id");
        $stmt->execute([':student_id' => $student_id]);
        return $stmt->fetchColumn();
    }

    if (empty($_POST['student_id'])) {
        throw new Exception("Student ID is required");
    }

    $student_id = trim($_POST['student_id']);

    $student_class_id = getStudentClassId($pdo, $student_id);
    if (!$student_class_id) {
        throw new Exception("Student not found");
    }

    $current_class_id = getStudentClassId($pdo, $student_id);
    if (!$current_class_id) throw new Exception("Student not found");

    $current_section_id = getStudentCurrentSection($pdo, $student_id);

    // 2. Determine Effective Class ID (Are we changing the class?)
    $effective_class_id = isset($_POST['class_id']) ? clean(trim($_POST['class_id'])) : $current_class_id;

    // 3. Determine Effective Section ID
    // 1. Determine Effective Class ID
    $effective_class_id = isset($_POST['class_id']) ? clean(trim($_POST['class_id'])) : $current_class_id;

    // 2. Determine Effective Section ID
    if (isset($_POST['section_id'])) {
        // If explicitly sent in POST (even if empty), use it
        $effective_section_id = trim($_POST['section_id']);
    } else {
        // If NOT sent in POST...
        if ($effective_class_id != $current_class_id) {
            // ...but Class changed? Then old section is invalid. Default to NULL.
            $effective_section_id = null;

            // CRITICAL: We must ensure this NULL actually updates in the DB 
            // (Inject into $_POST so the loop below picks it up and sets section_id = NULL)
            $_POST['section_id'] = '';
        } else {
            // Class didn't change? Safe to keep old section.
            $effective_section_id = $current_section_id;
        }
    }

    // Normalize empty strings to null
    if ($effective_section_id === '') $effective_section_id = null;

    // 4. Validate Section vs Class Dependency
    // If a section is selected, we MUST ensure it belongs to the $effective_class_id
    if ($effective_section_id) {
        $secStmt = $pdo->prepare("SELECT COUNT(*) FROM sections WHERE id = ? AND class_id = ?");
        $secStmt->execute([$effective_section_id, $effective_class_id]);
        if ($secStmt->fetchColumn() == 0) {
            throw new Exception("The selected Section does not belong to the selected Class.");
        }
    }

    $updateFields = [];
    $params = [':student_id' => $student_id];

    $allowed_genders = ['Male', 'Female', 'Other'];
    $allowed_religions = ['islam', 'hindu', 'christian', 'buddhist', 'jain', 'sikh', 'parsi', 'judaism', 'bahai', 'atheist', 'agnostic', 'other'];
    $allowed_status = ['Active', 'Left', 'Alumni'];

    // --- START: MODIFIED FIELD MAP ---
    $field_map = [
        'name' => 'string',
        'class_id' => 'int',
        'section_id' => 'int',
        'roll_no' => 'int',
        'phone_number' => 'string',
        'alternate_phone_number' => 'string',
        'blood_group' => 'string',
        'mother_name' => 'string',
        'father_occupation' => 'string',
        'mother_occupation' => 'string',
        'driving_route_id' => 'int',
        'driver_id' => 'int',
        'car_fee' => 'decimal',
        'hostel_fee' => 'decimal',
        'custom_class_fee' => 'decimal',
        'father_name' => 'string',
        'gender' => 'string',
        'religion' => 'string',
        'registration_no' => 'string',
        'email' => 'email',
        'status' => 'string',
        'student_adhaar_no' => 'string',
        'father_adhaar_no' => 'string',
        'mother_adhaar_no' => 'string',
        'village' => 'string',
        'post_office' => 'string',
        'police_station' => 'string',
        'district' => 'string',
        'pin_code' => 'string',
    ];
    // --- END: MODIFIED FIELD MAP ---

    // Determine effective status to clear roll_no if needed
    $effective_status = null;
    if (isset($_POST['status'])) {
        $effective_status = trim($_POST['status']);
    } else {
        $stmt_status = $pdo->prepare("SELECT status FROM students WHERE student_id = :student_id");
        $stmt_status->execute([':student_id' => $student_id]);
        $effective_status = $stmt_status->fetchColumn();
    }

    if ($effective_status === 'Left' || $effective_status === 'Alumni') {
        $_POST['roll_no'] = ''; // This ensures roll_no gets processed and set to NULL
    }

    foreach ($field_map as $field_name => $type) {
        if (isset($_POST[$field_name])) {
            $value = trim($_POST[$field_name]);

            // Validation and special handling
            if ($field_name === 'name' && empty($value)) {
                throw new Exception("Student name cannot be empty.");
            }
            if ($field_name === 'roll_no') {
                // Rule 2: If no section is assigned, Roll No cannot be set
                if ($value !== '' && empty($effective_section_id)) {
                    throw new Exception("Cannot assign Roll Number because this student has no Section.");
                }

                if ($value !== '' && (!is_numeric($value) || $value <= 0)) {
                    throw new Exception("Roll number must be a positive number");
                }

                // Rule 1: Check uniqueness with effective_section_id AND effective_class_id
                // Note: We use $effective_class_id here instead of the old $student_class_id
                if ($value !== '' && !isRollNumberUnique($pdo, $value, $effective_class_id, $effective_section_id, $student_id)) {
                    throw new Exception("Roll number {$value} is already assigned in this section.");
                }
            }
            if ($field_name === 'registration_no' && $value !== '' && !isRegistrationNoUnique($pdo, $value, $student_id)) {
                throw new Exception("Registration number {$value} is already assigned");
            }
            if (($field_name === 'phone_number' || $field_name === 'alternate_phone_number') && $value !== '' && !isValidPhoneNumber($value)) {
                throw new Exception("Invalid phone number format. It should be 10 digits.");
            }
            if ($field_name === 'email' && $value !== '' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                throw new Exception("Invalid email address format");
            }
            if ($field_name === 'gender' && $value !== '' && !in_array($value, $allowed_genders)) {
                throw new Exception("Invalid gender value selected");
            }
            if ($field_name === 'religion' && $value !== '' && !in_array(strtolower($value), $allowed_religions)) {
                throw new Exception("Invalid religion value selected");
            }
            if ($field_name === 'status' && $value !== '' && !in_array($value, $allowed_status)) {
                throw new Exception("Invalid status value selected");
            }
            if (in_array($field_name, ['car_fee', 'hostel_fee', 'custom_class_fee']) && !is_numeric($value)) {
                throw new Exception("$field_name must be a number.");
            }

            // --- START: NEW VALIDATION FOR DRIVING FIELDS ---
            if ($field_name === 'driving_route_id' && !empty($value)) {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM driving_routes WHERE id = ?");
                $stmt->execute([$value]);
                if ($stmt->fetchColumn() == 0) {
                    throw new Exception("Selected driving route does not exist.");
                }
            }
            if ($field_name === 'driver_id' && !empty($value)) {
                // First, check if the route was sent in the current request
                $driving_route_id = $_POST['driving_route_id'] ?? null;

                // If not, fetch the student's existing route from the database
                if (empty($driving_route_id)) {
                    $routeStmt = $pdo->prepare("SELECT driving_route_id FROM students WHERE student_id = ?");
                    $routeStmt->execute([$student_id]);
                    $driving_route_id = $routeStmt->fetchColumn();
                }

                // Now, perform the validation with the correct route ID
                if (empty($driving_route_id)) {
                    throw new Exception("Cannot assign a driver without a driving route.");
                }

                $stmt = $pdo->prepare("SELECT COUNT(*) FROM drivers WHERE id = ? AND route_id = ?");
                $stmt->execute([$value, $driving_route_id]);
                if ($stmt->fetchColumn() == 0) {
                    throw new Exception("Selected driver is not valid for the chosen route.");
                }
            }
            // --- END: NEW VALIDATION ---

            $updateFields[] = "{$field_name} = :{$field_name}";
            if ($field_name === 'name' || $field_name === 'father_name' || $field_name === 'mother_name' || $field_name === 'village' || $field_name === 'post_office' || $field_name === 'police_station' || $field_name === 'district') {
                $params[":{$field_name}"] = ($value === '') ? null : clean($value);
            } else {
                $params[":{$field_name}"] = ($value === '') ? null : $value;
            }

            if ($field_name === 'hostel_fee') {
                $is_hosteler = (!is_null($params[':hostel_fee']) && $params[':hostel_fee'] > 0) ? 1 : 0;
                $updateFields[] = "is_hosteler = :is_hosteler";
                $params[':is_hosteler'] = $is_hosteler;
            }
        }
    }

    // --- START: NEW ADDRESS CONSTRUCTION LOGIC ---
    $address_components = ['village', 'post_office', 'police_station', 'district', 'pin_code'];
    $address_changed = false;
    foreach ($address_components as $component) {
        if (isset($_POST[$component])) {
            $address_changed = true;
            break;
        }
    }

    if ($address_changed) {
        // Fetch the current full address components for the student
        $stmt_address = $pdo->prepare("SELECT village, post_office, police_station, district, pin_code FROM students WHERE student_id = :student_id");
        $stmt_address->execute([':student_id' => $student_id]);
        $current_address = $stmt_address->fetch(PDO::FETCH_ASSOC);

        if ($current_address) {
            // Get submitted values, or use current values as fallback
            $village = isset($_POST['village']) ? clean(trim($_POST['village'])) : $current_address['village'];
            $post_office = isset($_POST['post_office']) ? clean(trim($_POST['post_office'])) : $current_address['post_office'];
            $police_station = isset($_POST['police_station']) ? clean(trim($_POST['police_station'])) : $current_address['police_station'];
            $district = isset($_POST['district']) ? clean(trim($_POST['district'])) : $current_address['district'];
            $pin_code = isset($_POST['pin_code']) ? trim($_POST['pin_code']) : $current_address['pin_code'];

            // Build the full address string, only including non-empty parts
            $address_parts = array_filter([$village, $post_office, $police_station, $district, $pin_code]);
            $full_address = implode(', ', $address_parts);

            // Add the constructed address to the update query
            $updateFields[] = "address = :address";
            $params[':address'] = ($full_address === '') ? null : $full_address;
        }
    }
    // --- END: NEW ADDRESS CONSTRUCTION LOGIC ---

    // Handle image upload
    if (!empty($_POST['cropped_image_data'])) {
        $upload_dir =  __DIR__ . '/../../../../uploads/students/';
        $cropped_image = saveBase64Image($_POST['cropped_image_data'], $upload_dir);

        if ($cropped_image) {
            $current_image = isset($_POST['current_image']) ? trim($_POST['current_image']) : null;
            if ($current_image && $current_image !== 'default_student_dp.jpg' && file_exists($upload_dir . $current_image)) {
                unlink($upload_dir . $current_image);
            }
            $updateFields[] = "student_image = :student_image";
            $params[':student_image'] = $cropped_image;
            $response['new_image'] = $cropped_image;
        } else {
            throw new Exception("Failed to save cropped image.");
        }
    }

    // Final check to prevent updating driver_id if driving_route_id is being set to NULL
    if (isset($params[':driving_route_id']) && is_null($params[':driving_route_id'])) {
        $updateFields[] = "driver_id = :driver_id";
        $params[':driver_id'] = null;
    }


    if (!empty($updateFields)) {
        $updateFields[] = "updated_at = NOW()";
        $sql = "UPDATE students SET " . implode(', ', array_unique($updateFields)) . " WHERE student_id = :student_id";
        $stmt = $pdo->prepare($sql);

        if ($stmt->execute($params)) {
            $response['success'] = true;
            $response['message'] = "Student updated successfully";
        } else {
            throw new Exception("Failed to update student record. SQL Error: " . implode(", ", $stmt->errorInfo()));
        }
    } else {
        $response['success'] = true;
        $response['message'] = "No changes were detected";
    }
} catch (PDOException $e) {
    $response['message'] = "Database error: " . $e->getMessage();
    error_log("PDOException in bulk edit: " . $e->getMessage());
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    error_log("Exception in bulk edit: " . $e->getMessage());
}

ob_end_clean();
echo json_encode($response);
exit();
