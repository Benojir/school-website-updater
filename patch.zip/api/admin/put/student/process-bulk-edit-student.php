<?php
ob_start();
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/imgbb-upload.php");

header('Content-Type: application/json');

if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    function clean(mixed $data)
    {
        return ucwords(safe_htmlspecialchars(trim($data)));
    }

    function saveBase64Image(string $base64_string, string $upload_dir, $prefix = 'stu_')
    {
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
        if (preg_match('/^data:image\/(\w+);base64,/', $base64_string, $type)) {
            $data = substr($base64_string, strpos($base64_string, ',') + 1);
            $type = strtolower($type[1]);
            if (!in_array($type, ['jpg', 'jpeg', 'png', 'gif'])) return false;
            $data = base64_decode($data);
            if ($data === false || strlen($data) > 2 * 1024 * 1024) return false;
        } else {
            return false;
        }
        $file_name = uniqid($prefix) . '.' . $type;
        $file_path = $upload_dir . $file_name;
        if (file_put_contents($file_path, $data)) {
            if (!getimagesize($file_path)) {
                unlink($file_path);
                return false;
            }
            return $file_name;
        }
        return false;
    }

    function isRollNumberUnique(PDO $pdo, mixed $roll_no, int $class_id, mixed $section_id, string $student_id)
    {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE roll_no = :roll_no AND class_id = :class_id AND section_id = :section_id AND student_id != :student_id");
        $stmt->execute([
            ':roll_no' => $roll_no,
            ':class_id' => $class_id,
            ':section_id' => $section_id,
            ':student_id' => $student_id
        ]);
        return $stmt->fetchColumn() == 0;
    }

    function getStudentCurrentSection(PDO $pdo, string $student_id)
    {
        $stmt = $pdo->prepare("SELECT section_id FROM students WHERE student_id = :student_id");
        $stmt->execute([':student_id' => $student_id]);
        return $stmt->fetchColumn();
    }

    function isRegistrationNoUnique(PDO $pdo, string $reg_no, string $student_id)
    {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE registration_no = :reg_no AND student_id != :student_id");
        $stmt->execute([':reg_no' => $reg_no, ':student_id' => $student_id]);
        return $stmt->fetchColumn() == 0;
    }

    function getStudentClassId(PDO $pdo, string $student_id)
    {
        $stmt = $pdo->prepare("SELECT class_id FROM students WHERE student_id = :student_id");
        $stmt->execute([':student_id' => $student_id]);
        return $stmt->fetchColumn();
    }

    if (empty($_POST['student_id'])) {
        throw new Exception("Student ID is required");
    }

    $student_id = trim($_POST['student_id']);

    $current_class_id = getStudentClassId($pdo, $student_id);
    if (!$current_class_id) throw new Exception("Student not found");

    $current_section_id = getStudentCurrentSection($pdo, $student_id);

    // Fetch student's name for use in document upload captions
    $stmt_name = $pdo->prepare("SELECT name FROM students WHERE student_id = :student_id");
    $stmt_name->execute([':student_id' => $student_id]);
    $student_name = $stmt_name->fetchColumn() ?: $student_id;

    $effective_class_id = isset($_POST['class_id']) ? clean(trim($_POST['class_id'])) : $current_class_id;

    if (isset($_POST['section_id'])) {
        $effective_section_id = trim($_POST['section_id']);
    } else {
        if ($effective_class_id != $current_class_id) {
            $effective_section_id = null;
            $_POST['section_id'] = '';
        } else {
            $effective_section_id = $current_section_id;
        }
    }

    if ($effective_section_id === '') $effective_section_id = null;

    if ($effective_section_id) {
        $secStmt = $pdo->prepare("SELECT COUNT(*) FROM sections WHERE id = ? AND class_id = ?");
        $secStmt->execute([$effective_section_id, $effective_class_id]);
        if ($secStmt->fetchColumn() == 0) {
            throw new Exception("The selected Section does not belong to the selected Class.");
        }
    }

    $updateFields = [];
    $params = [':student_id' => $student_id];

    $allowed_genders = ['Male', 'Female', 'Other'];
    $allowed_religions = ['islam', 'hindu', 'christian', 'buddhist', 'jain', 'sikh', 'parsi', 'judaism', 'bahai', 'atheist', 'agnostic', 'other'];
    $allowed_status = ['Active', 'Left', 'Alumni'];

    $field_map = [
        'name' => 'string',
        'class_id' => 'int',
        'section_id' => 'int',
        'roll_no' => 'int',
        'phone_number' => 'string',
        'alternate_phone_number' => 'string',
        'blood_group' => 'string',
        'mother_name' => 'string',
        'father_occupation' => 'string',
        'mother_occupation' => 'string',
        'driving_route_id' => 'int',
        'driver_id' => 'int',
        'car_fee' => 'decimal',
        'hostel_fee' => 'decimal',
        'custom_class_fee' => 'decimal',
        'coaching_fee' => 'decimal', 
        'tiffin_fee' => 'decimal',   
        'father_name' => 'string',
        'gender' => 'string',
        'religion' => 'string',
        'registration_no' => 'string',
        'email' => 'email',
        'status' => 'string',
        'student_adhaar_no' => 'string',
        'father_adhaar_no' => 'string',
        'mother_adhaar_no' => 'string',
        'village' => 'string',
        'post_office' => 'string',
        'police_station' => 'string',
        'district' => 'string',
        'pin_code' => 'string',
        'date_of_birth' => 'string',
        'admission_date' => 'string',
        'academic_year' => 'string',
        'banglar_shiksha_code' => 'string',
        'caste' => 'string',
        'father_annual_income' => 'decimal',
        'mother_annual_income' => 'decimal',
        'bank_name' => 'string',
        'bank_branch_name' => 'string',
        'bank_account_no' => 'string',
        'ifsc_code' => 'string',
        'father_pan_no' => 'string',
        'father_voter_no' => 'string',
        'mother_pan_no' => 'string',
        'mother_voter_no' => 'string'
    ];

    $effective_status = null;
    if (isset($_POST['status'])) {
        $effective_status = trim($_POST['status']);
    } else {
        $stmt_status = $pdo->prepare("SELECT status FROM students WHERE student_id = :student_id");
        $stmt_status->execute([':student_id' => $student_id]);
        $effective_status = $stmt_status->fetchColumn();
    }

    if ($effective_status === 'Left' || $effective_status === 'Alumni') {
        $_POST['roll_no'] = ''; 
    }

    foreach ($field_map as $field_name => $type) {
        if (isset($_POST[$field_name])) {
            $value = trim($_POST[$field_name]);

            if ($field_name === 'name' && empty($value)) {
                throw new Exception("Student name cannot be empty.");
            }
            if ($field_name === 'roll_no') {
                if ($value !== '' && empty($effective_section_id)) {
                    throw new Exception("Cannot assign Roll Number because this student has no Section.");
                }

                if ($value !== '' && (!is_numeric($value) || $value <= 0)) {
                    throw new Exception("Roll number must be a positive number");
                }

                if ($value !== '' && !isRollNumberUnique($pdo, $value, $effective_class_id, $effective_section_id, $student_id)) {
                    throw new Exception("Roll number {$value} is already assigned in this section.");
                }
            }
            if ($field_name === 'registration_no' && $value !== '' && !isRegistrationNoUnique($pdo, $value, $student_id)) {
                throw new Exception("Registration number {$value} is already assigned");
            }
            if (($field_name === 'phone_number' || $field_name === 'alternate_phone_number') && $value !== '' && !isValidPhoneNumber($value)) {
                throw new Exception("Invalid phone number format. It should be 10 digits.");
            }
            if ($field_name === 'email' && $value !== '' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                throw new Exception("Invalid email address format");
            }
            if ($field_name === 'gender' && $value !== '' && !in_array($value, $allowed_genders)) {
                throw new Exception("Invalid gender value selected");
            }
            if ($field_name === 'date_of_birth' && empty($value)) {
                throw new Exception("Date of birth cannot be empty.");
            }
            if ($field_name === 'religion' && $value !== '' && !in_array(strtolower($value), $allowed_religions)) {
                throw new Exception("Invalid religion value selected");
            }
            if ($field_name === 'status' && $value !== '' && !in_array($value, $allowed_status)) {
                throw new Exception("Invalid status value selected");
            }
            // Banglar Shiksha Code Unique Validation
            if ($field_name === 'banglar_shiksha_code' && $value !== '') {
                $stmtCode = $pdo->prepare("SELECT COUNT(*) FROM students WHERE banglar_shiksha_code = :code AND student_id != :student_id");
                $stmtCode->execute([':code' => $value, ':student_id' => $student_id]);
                if ($stmtCode->fetchColumn() > 0) {
                    throw new Exception("Banglar Shiksha Student Code {$value} already exists.");
                }
            }

            // Numeric check for new decimal fields
            if (in_array($field_name, ['car_fee', 'hostel_fee', 'custom_class_fee', 'coaching_fee', 'tiffin_fee', 'father_annual_income', 'mother_annual_income']) && $value !== '' && !is_numeric($value)) {
                throw new Exception("$field_name must be a number.");
            }

            // ---- START: NEW LOGIC FOR CUSTOM CLASS FEE ----
            if ($field_name === 'custom_class_fee' && $value !== '') {
                // স্টুডেন্টের বর্তমান ক্লাসের ডিফল্ট ফি নিয়ে আসা হচ্ছে
                $default_class_fee = getClassFee($effective_class_id);
                
                // যদি ইনপুট করা ফি এবং ডিফল্ট ফি সমান হয়, তাহলে সেটিকে 0 করে দেওয়া হচ্ছে
                if ((float)$value === $default_class_fee) {
                    $value = '0';
                }
            }
            // ---- END: NEW LOGIC FOR CUSTOM CLASS FEE ----

            // --- Updated Driver/Route Validation ---
            if ($field_name === 'driving_route_id' && !empty($value)) {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM driving_routes WHERE id = ?");
                $stmt->execute([$value]);
                if ($stmt->fetchColumn() == 0) {
                    throw new Exception("Selected driving route does not exist.");
                }
            }
            if ($field_name === 'driver_id' && !empty($value)) {
                // Was driving_route_id actually submitted in THIS request (row)?
                // If yes, trust it as-is — even empty means the user explicitly cleared the route,
                // and we should NOT silently fall back to the student's old DB value for it.
                if (array_key_exists('driving_route_id', $_POST)) {
                    $driving_route_id = trim($_POST['driving_route_id']);
                    $driving_route_id = ($driving_route_id === '') ? null : $driving_route_id;
                } else {
                    $routeStmt = $pdo->prepare("SELECT driving_route_id FROM students WHERE student_id = ?");
                    $routeStmt->execute([$student_id]);
                    $driving_route_id = $routeStmt->fetchColumn();
                }

                // Driver must exist and be active either way
                if (!empty($driving_route_id)) {
                    // A route is set (new or existing) — verify this driver is actually on that route
                    $stmt = $pdo->prepare("SELECT route_ids FROM drivers WHERE id = ? AND status = 'active'");
                    $stmt->execute([$value]);
                    $route_ids_json = $stmt->fetchColumn();

                    if ($route_ids_json === false) {
                        throw new Exception("Selected driver does not exist or is not active.");
                    }

                    $driver_route_ids = json_decode($route_ids_json ?? '[]', true);
                    if (!is_array($driver_route_ids) || !in_array($driving_route_id, $driver_route_ids)) {
                        throw new Exception("Selected driver is not valid for the chosen route.");
                    }
                } else {
                    // No route selected (explicitly cleared, or never set) — still allowed,
                    // just confirm the driver itself exists and is active.
                    $stmt = $pdo->prepare("SELECT id FROM drivers WHERE id = ? AND status = 'active'");
                    $stmt->execute([$value]);
                    if ($stmt->fetchColumn() === false) {
                        throw new Exception("Selected driver does not exist or is not active.");
                    }
                }
            }
            // ----------------------------------------

            $updateFields[] = "{$field_name} = :{$field_name}";
            if (in_array($field_name, ['name', 'father_name', 'mother_name', 'village', 'post_office', 'police_station', 'district'])) {
                $params[":{$field_name}"] = ($value === '') ? null : clean($value);
            } else {
                $params[":{$field_name}"] = ($value === '') ? null : $value;
            }

            if ($field_name === 'hostel_fee') {
                $is_hosteler = (!is_null($params[':hostel_fee']) && $params[':hostel_fee'] > 0) ? 1 : 0;
                $updateFields[] = "is_hosteler = :is_hosteler";
                $params[':is_hosteler'] = $is_hosteler;
            }
        }
    }

    $address_components = ['village', 'post_office', 'police_station', 'district', 'pin_code'];
    $address_changed = false;
    foreach ($address_components as $component) {
        if (isset($_POST[$component])) {
            $address_changed = true;
            break;
        }
    }

    if ($address_changed) {
        $stmt_address = $pdo->prepare("SELECT village, post_office, police_station, district, pin_code FROM students WHERE student_id = :student_id");
        $stmt_address->execute([':student_id' => $student_id]);
        $current_address = $stmt_address->fetch(PDO::FETCH_ASSOC);

        if ($current_address) {
            $village = isset($_POST['village']) ? clean(trim($_POST['village'])) : $current_address['village'];
            $post_office = isset($_POST['post_office']) ? clean(trim($_POST['post_office'])) : $current_address['post_office'];
            $police_station = isset($_POST['police_station']) ? clean(trim($_POST['police_station'])) : $current_address['police_station'];
            $district = isset($_POST['district']) ? clean(trim($_POST['district'])) : $current_address['district'];
            $pin_code = isset($_POST['pin_code']) ? trim($_POST['pin_code']) : $current_address['pin_code'];

            $address_parts = array_filter([$village, $post_office, $police_station, $district, $pin_code]);
            $full_address = implode(', ', $address_parts);

            $updateFields[] = "address = :address";
            $params[':address'] = ($full_address === '') ? null : $full_address;
        }
    }

    if (!empty($_POST['cropped_image_data'])) {
        $upload_dir =  __DIR__ . '/../../../../uploads/students/';
        $cropped_image = saveBase64Image($_POST['cropped_image_data'], $upload_dir);

        if ($cropped_image) {
            $current_image = isset($_POST['current_image']) ? trim($_POST['current_image']) : null;
            if ($current_image && $current_image !== 'default_student_dp.jpg' && file_exists($upload_dir . $current_image)) {
                unlink($upload_dir . $current_image);
            }
            $updateFields[] = "student_image = :student_image";
            $params[':student_image'] = $cropped_image;
            $response['new_image'] = $cropped_image;
        } else {
            throw new Exception("Failed to save cropped image.");
        }
    }

    // Father's photo - stored locally, same pattern as student photo
    if (!empty($_POST['cropped_father_image_data'])) {
        $father_upload_dir = __DIR__ . '/../../../../uploads/fathers/';
        $cropped_father_image = saveBase64Image($_POST['cropped_father_image_data'], $father_upload_dir, 'fa_');

        if ($cropped_father_image) {
            $current_father_image = isset($_POST['current_father_image']) ? trim($_POST['current_father_image']) : null;
            if ($current_father_image && file_exists($father_upload_dir . $current_father_image)) {
                unlink($father_upload_dir . $current_father_image);
            }
            $updateFields[] = "father_image = :father_image";
            $params[':father_image'] = $cropped_father_image;
            $response['new_father_image'] = $cropped_father_image;
        } else {
            throw new Exception("Failed to save father's cropped image.");
        }
    }

    // Mother's photo - stored locally, same pattern as student photo
    if (!empty($_POST['cropped_mother_image_data'])) {
        $mother_upload_dir = __DIR__ . '/../../../../uploads/mothers/';
        $cropped_mother_image = saveBase64Image($_POST['cropped_mother_image_data'], $mother_upload_dir, 'mo_');

        if ($cropped_mother_image) {
            $current_mother_image = isset($_POST['current_mother_image']) ? trim($_POST['current_mother_image']) : null;
            if ($current_mother_image && file_exists($mother_upload_dir . $current_mother_image)) {
                unlink($mother_upload_dir . $current_mother_image);
            }
            $updateFields[] = "mother_image = :mother_image";
            $params[':mother_image'] = $cropped_mother_image;
            $response['new_mother_image'] = $cropped_mother_image;
        } else {
            throw new Exception("Failed to save mother's cropped image.");
        }
    }

    // Document images - all uploaded to ImgBB, only the direct link is stored in the DB (optional)
    $document_upload_map = [
        'father_aadhaar_image'          => "Father's Aadhaar Card - {$student_name}",
        'father_voter_image'            => "Father's Voter Card - {$student_name}",
        'father_pan_image'              => "Father's PAN Card - {$student_name}",
        'mother_aadhaar_image'          => "Mother's Aadhaar Card - {$student_name}",
        'mother_voter_image'            => "Mother's Voter Card - {$student_name}",
        'mother_pan_image'              => "Mother's PAN Card - {$student_name}",
        'student_birth_certificate'     => "Birth Certificate - {$student_name}",
        'student_aadhaar_image'         => "Student's Aadhaar Card - {$student_name}",
        'student_transfer_certificate'  => "Transfer Certificate - {$student_name}",
    ];

    foreach ($document_upload_map as $doc_field_name => $caption) {
        if (isset($_FILES[$doc_field_name]) && $_FILES[$doc_field_name]['size'] > 0) {
            try {
                $doc_url = uploadDocumentToImgBB($_FILES[$doc_field_name], $caption);
                $updateFields[] = "{$doc_field_name} = :{$doc_field_name}";
                $params[":{$doc_field_name}"] = $doc_url;
                $response['updated_documents'][$doc_field_name] = $doc_url;
            } catch (Exception $e) {
                throw new Exception(str_replace('_', ' ', ucfirst($doc_field_name)) . " upload failed: " . $e->getMessage());
            }
        }
    }

    if (isset($params[':driving_route_id']) && is_null($params[':driving_route_id'])) {
        // Route was cleared. Only auto-clear driver_id too if the driver field itself
        // wasn't explicitly submitted with a value in this same edit — if the user picked
        // a driver in this request (route left empty), respect that choice as-is.
        if (!isset($params[':driver_id'])) {
            $updateFields[] = "driver_id = :driver_id";
            $params[':driver_id'] = null;
        }
    }

    if (!empty($updateFields)) {
        $updateFields[] = "updated_at = NOW()";
        $sql = "UPDATE students SET " . implode(', ', array_unique($updateFields)) . " WHERE student_id = :student_id";
        $stmt = $pdo->prepare($sql);

        if ($stmt->execute($params)) {
            $response['success'] = true;
            $response['message'] = "Student updated successfully";
        } else {
            throw new Exception("Failed to update student record. SQL Error: " . implode(", ", $stmt->errorInfo()));
        }
    } else {
        $response['success'] = true;
        $response['message'] = "No changes were detected";
    }
} catch (PDOException $e) {
    $response['message'] = "Database error: " . $e->getMessage();
    error_log("PDOException in bulk edit: " . $e->getMessage());
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    error_log("Exception in bulk edit: " . $e->getMessage());
}

ob_end_clean();
echo json_encode($response);
exit();