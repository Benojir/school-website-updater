<?php
/** @var PDO $pdo */
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
require_once(__DIR__ . "/../../../../includes/financial/fun-admission-fees-entry.php");

header('Content-Type: application/json');

$authData = authenticateAdminApiRequest($pdo);

// Check admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    die(json_encode(['success' => false, 'message' => 'Permission denied']));
}

// Validate inputs
$required = ['student_ids', 'current_class_id', 'new_class_id', 'promotion_date', 'roll_number_strategy'];
foreach ($required as $field) {
    if (empty($_POST[$field])) {
        die(json_encode(['success' => false, 'message' => "Missing required field: $field"]));
    }
}

$student_ids = explode(',', $_POST['student_ids']);
$student_ids = array_filter(array_map('trim', $student_ids));
$current_class_id = (int) $_POST['current_class_id'];
$new_class_id = (int) $_POST['new_class_id'];
$new_section_id = !empty($_POST['new_section_id']) ? (int)$_POST['new_section_id'] : NULL;
$academic_year = sanitize_input($_POST['academic_year'] ?? '');
$promotion_date = $_POST['promotion_date'];
$remarks = sanitize_input($_POST['remarks'] ?? '');
$mark_results_promoted = isset($_POST['mark_results_promoted']);
$roll_number_strategy = sanitize_input($_POST['roll_number_strategy'] ?? '');
$auto_include_admission_fee  = isset($_POST['auto_include_admission_fee']);

try {
    $pdo->beginTransaction();

    // Verify all students are from the same class
    $placeholders = implode(',', array_fill(0, count($student_ids), '?'));
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as student_count
        FROM students
        WHERE student_id IN ($placeholders) AND class_id = ?
    ");
    $params = array_merge($student_ids, [$current_class_id]);
    $stmt->execute($params);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result['student_count'] != count($student_ids)) {
        die(json_encode([
            'success' => false,
            'message' => 'Some students are not in the expected class'
        ]));
    }

    // Check if target class is valid
    $stmt = $pdo->prepare("SELECT is_final_class FROM classes WHERE id = ?");
    $stmt->execute([$new_class_id]);
    $target_class = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$target_class) {
        die(json_encode([
            'success' => false,
            'message' => 'Target class does not exist'
        ]));
    }

    // Get current max roll number in target section
    $stmt = $pdo->prepare("
        SELECT COALESCE(MAX(roll_no), 0) as max_roll 
        FROM students 
        WHERE class_id = ? AND section_id = ?
    ");
    $stmt->execute([$new_class_id, $new_section_id]);
    $max_roll = (int) $stmt->fetchColumn();

    // Get students in their current order
    $stmt = $pdo->prepare("
        SELECT student_id, roll_no 
        FROM students 
        WHERE student_id IN ($placeholders)
        ORDER BY roll_no ASC
    ");
    $stmt->execute($student_ids);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get students' latest exam ranks
    $exam_ranks = [];
    if ($roll_number_strategy === 'by_exam_rank') {
        $stmt = $pdo->prepare("
            SELECT r.student_id, MAX(er.theory_exam_date) as latest_exam_date
            FROM results r
            JOIN exam_routines er ON r.exam_id = er.exam_id AND r.class_id = er.class_id
            WHERE r.student_id IN ($placeholders)
            GROUP BY r.student_id
        ");
        $stmt->execute($student_ids);
        $latest_exams = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $ranked_students = [];
        foreach ($latest_exams as $exam) {
            $stmt = $pdo->prepare("
                        SELECT r.student_id, r.obtained_marks
                        FROM results r
                        JOIN exam_routines er ON r.exam_id = er.exam_id AND r.class_id = er.class_id
                        WHERE er.theory_exam_date = ? AND er.class_id = ?
                        ORDER BY r.obtained_marks DESC
                    ");
            $stmt->execute([$exam['latest_exam_date'], $current_class_id]);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Calculate ranks (handling ties)
            $rank = 1;
            $prev_marks = null;
            $same_rank_count = 0;

            foreach ($results as $result) {
                if ($prev_marks !== null && $result['obtained_marks'] < $prev_marks) {
                    $rank += $same_rank_count;
                    $same_rank_count = 1;
                } else if ($prev_marks !== null && $result['obtained_marks'] == $prev_marks) {
                    $same_rank_count++;
                } else {
                    $same_rank_count = 1;
                }

                if (in_array($result['student_id'], $student_ids)) {
                    $ranked_students[$result['student_id']] = $rank;
                }

                $prev_marks = $result['obtained_marks'];
            }
        }

        if (empty($ranked_students)) {
            die(json_encode([
                'success' => false,
                'message' => 'No exam results found for any students to calculate ranks'
            ]));
        }

        // Assign the calculated ranks
        foreach ($ranked_students as $student_id => $rank) {
            $exam_ranks[$student_id] = $rank;
        }
    }

    // Prepare roll numbers based on strategy
    $roll_numbers = [];
    $next_roll = $max_roll + 1;

    foreach ($students as $student) {
        switch ($roll_number_strategy) {
            case 'auto_increment':
                $roll_numbers[$student['student_id']] = $next_roll++;
                break;
            case 'preserve_order':
                $roll_numbers[$student['student_id']] = count($roll_numbers) + 1;
                break;
            case 'keep_existing':
                $roll_numbers[$student['student_id']] = $student['roll_no'];
                break;
            case 'by_exam_rank':
                // Use exam rank if available, otherwise use auto-increment
                $roll_numbers[$student['student_id']] = $exam_ranks[$student['student_id']] ?? $next_roll++;
                break;
            case 'blank':
                $roll_numbers[$student['student_id']] = NULL;
                break;
            default:
                $roll_numbers[$student['student_id']] = $next_roll++;
        }
    }

    // ================== FIXED SECTION START ==================
    // Check for roll number conflicts for strategies that might cause them.
    // This now covers 'keep_existing', 'by_exam_rank', and 'preserve_order'.
    if (in_array($roll_number_strategy, ['keep_existing', 'by_exam_rank', 'preserve_order'])) {
        // Filter out any NULL roll numbers (can happen in by_exam_rank as a fallback)
        $rolls_to_check = array_filter($roll_numbers, fn($val) => $val !== NULL);

        if (!empty($rolls_to_check)) {
            $roll_placeholders = implode(',', array_fill(0, count($rolls_to_check), '?'));
            $stmt = $pdo->prepare("
                SELECT COUNT(*) 
                FROM students 
                WHERE class_id = ? AND section_id = ? AND roll_no IN ($roll_placeholders)
            ");

            $params = array_merge([$new_class_id, $new_section_id], array_values($rolls_to_check));
            $stmt->execute($params);
            $conflicts = $stmt->fetchColumn();

            if ($conflicts > 0) {
                die(json_encode([
                    'success' => false,
                    'message' => 'Roll number conflict detected in the target class. Please choose another strategy (like auto-increment) or assign roll numbers later.'
                ]));
            }
        }
    }
    // =================== FIXED SECTION END ===================

    // In the student update query:
    foreach ($students as $student) {
        $stmt = $pdo->prepare("
            UPDATE students SET 
                class_id = ?, 
                section_id = ?, 
                roll_no = ?, 
                admission_date = ?, 
                promoted_date = ?, 
                academic_year = ?, 
                updated_at = NOW()
            WHERE student_id = ?
        ");

        $params = [
            $new_class_id,
            $new_section_id,
            $roll_numbers[$student['student_id']],
            $promotion_date,
            $promotion_date,
            $academic_year,
            $student['student_id']
        ];

        $stmt->execute($params);
    }

    // Update class_roll_numbers table
    // In the section where you update class_roll_numbers:
    $new_max_roll = max($roll_numbers);
    if ($new_max_roll !== NULL && $new_section_id !== NULL) { // Only update if we have actual roll numbers
        $stmt = $pdo->prepare("
            INSERT INTO class_roll_numbers (class_id, section_id, last_roll_number)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE last_roll_number = GREATEST(COALESCE(last_roll_number, 0), ?)
        ");
        $stmt->execute([
            $new_class_id,
            $new_section_id,
            $new_max_roll,
            $new_max_roll
        ]);
    }

    // Only mark as promoted if moving to higher class
    if ($mark_results_promoted && $new_class_id > $current_class_id) {
        $stmt = $pdo->prepare("
            UPDATE results SET 
                is_promoted = 1,
                updated_at = NOW()
            WHERE student_id IN ($placeholders)
        ");
        $stmt->execute($student_ids);
    }
    // If moving to lower class, mark as not promoted
    elseif ($new_class_id < $current_class_id) {
        $stmt = $pdo->prepare("
            UPDATE results SET 
                is_promoted = 0,
                updated_at = NOW()
            WHERE student_id IN ($placeholders)
        ");
        $stmt->execute($student_ids);
    }

    // Log this promotion action
    $created_by = $authData['user_id'] ?? null;
    $stmt = $pdo->prepare("
        INSERT INTO promotion_logs (
            current_class_id, 
            new_class_id, 
            new_section_id, 
            promotion_date, 
            remarks, 
            promoted_count, 
            created_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $current_class_id,
        $new_class_id,
        $new_section_id,
        $promotion_date,
        $remarks,
        count($student_ids),
        $created_by
    ]);

    // Commit transaction
    $pdo->commit();

    // Prepare final response message
    $response_message = 'Successfully promoted ' . count($student_ids) . ' students.';

    if ($auto_include_admission_fee) {
        // Call admission fees entry function to handle fees for promoted students
        $admission_fee_entry = fun_admission_fees_entry(
            $pdo,
            implode(',', $student_ids),
            $academic_year,
            $new_class_id,
            0,
            true
        );

        // Append admission fee entry result to response message
        if ($admission_fee_entry['success']) {
            $admission_fee_entry_message = "";

            foreach ($admission_fee_entry['results'] as $fee_result) {
                $admission_fee_entry_message .= " " . $fee_result['message'];
            }

            $response_message .= " " . $admission_fee_entry_message;
        } else {
            $response_message .= " However, Admission fee entry failed: " . $admission_fee_entry['message'];
        }
    } else {
        $response_message .= " Admission fee entry is not created as you unchecked the option.";
    }

    echo json_encode([
        'success' => true,
        'message' => $response_message
    ]);
} catch (PDOException $e) {
    $pdo->rollBack();
    error_log("Promotion error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
