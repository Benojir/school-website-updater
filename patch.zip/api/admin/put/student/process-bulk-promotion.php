<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");
header('Content-Type: application/json');
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}
require_once(__DIR__ . "/../../../../includes/financial/fun-admission-fees-entry.php");
try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') throw new RuntimeException('POST required.');
    $sourceYear = academicNormalizeYear($_POST['selected_year'] ?? academicRequireCurrentYear($pdo));
    $targetYear = academicNormalizeYear($_POST['academic_year'] ?? '');
    if ((int)$targetYear <= (int)$sourceYear) throw new RuntimeException('Promotion requires a later academic year. Use academic editing for corrections.');
    $ids = array_values(array_unique(array_filter(array_map('trim', explode(',', $_POST['student_ids'] ?? '')))));
    if (!$ids) throw new RuntimeException('Select students to promote.');
    $currentClass = (int)($_POST['current_class_id'] ?? 0);
    $targetClass = (int)($_POST['new_class_id'] ?? 0);
    $date = academicDate($_POST['promotion_date'] ?? null);
    if ($date === null) throw new InvalidArgumentException('Promotion date is required.');
    $pdo->beginTransaction();
    academicLockSettings($pdo);
    foreach ($ids as $id) {
        $student = academicRequireStudentRow($pdo, $id);
        $record = academicGetRecord($pdo, (int)$student['id'], $sourceYear);
        if (!$record || (int)$record['class_id'] !== $currentClass || strcasecmp(trim((string)$record['status']), 'Active') !== 0) {
            throw new RuntimeException('Every selected student must have an active enrollment in the selected source year and class.');
        }
        academicSaveRecord($pdo, (int)$student['id'], [
            'academic_year' => $targetYear, 'class_id' => $targetClass,
            'section_id' => $_POST['new_section_id'] ?? null, 'roll_no' => null,
            'registration_no' => null, 'admission_date' => $date, 'promoted_date' => $date,
            'status' => 'Active', 'custom_class_fee' => 0,
        ], null, true);
        academicSyncStudent($pdo, (int)$student['id']);
        $stmt = $pdo->prepare('UPDATE results SET is_promoted = ?, updated_at = NOW() WHERE student_id = ? AND class_id = ? AND academic_year = ?');
        $stmt->execute([$targetClass !== $currentClass ? 1 : 0, $id, $currentClass, $sourceYear]);
    }
    $pdo->commit();
    $message = count($ids) . ' enrollment(s) created for ' . $targetYear . '. Previous academic records are preserved.';
    if (isset($_POST['auto_include_admission_fee'])) {
        try {
            $fee = fun_admission_fees_entry($pdo, implode(',', $ids), $targetYear, $targetClass, 0, true);
            $message .= $fee['success'] ? ' Admission fees processed.' : ' Enrollment saved; admission fee processing failed: ' . $fee['message'];
        } catch (Throwable $feeError) {
            $message .= ' Enrollment saved; admission fee processing failed: ' . $feeError->getMessage();
        }
    }
    echo json_encode(['success' => true, 'message' => $message]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
