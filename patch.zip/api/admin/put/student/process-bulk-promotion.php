<?php
/** @var PDO $pdo */
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
require_once(__DIR__ . "/../../../../includes/financial/fun-admission-fees-entry.php");

header('Content-Type: application/json');

$authData = authenticateAdminApiRequest($pdo);

// Check admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    die(json_encode(['success' => false, 'message' => 'Permission denied']));
}

// Validate inputs
$required = ['student_ids', 'current_class_id', 'new_class_id', 'promotion_date'];
foreach ($required as $field) {
    if (empty($_POST[$field])) {
        die(json_encode(['success' => false, 'message' => "Missing required field: $field"]));
    }
}

$student_ids_string = $_POST['student_ids'] ?? '';
$student_ids = !empty($student_ids_string) ? array_map('trim', explode(',', $student_ids_string)) : [];
$student_ids = array_filter(array_map('trim', $student_ids));
$current_class_id = (int) $_POST['current_class_id'];
$new_class_id = (int) $_POST['new_class_id'];
$new_section_id = !empty($_POST['new_section_id']) ? (int)$_POST['new_section_id'] : NULL;
$academic_year = sanitize_input($_POST['academic_year'] ?? '');
$promotion_date = $_POST['promotion_date'];
$remarks = sanitize_input($_POST['remarks'] ?? '');
$auto_include_admission_fee  = isset($_POST['auto_include_admission_fee']);
$mark_results_promoted = true;

try {
    $pdo->beginTransaction();
    $placeholders = implode(',', array_fill(0, count($student_ids), '?'));

    // Check if target class is valid
    $stmt = $pdo->prepare("SELECT is_final_class FROM classes WHERE id = ?");
    $stmt->execute([$new_class_id]);
    $target_class = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$target_class) {
        die(json_encode([
            'success' => false,
            'message' => 'Target class does not exist'
        ]));
    }

    // Get valid students to promote
    $stmt = $pdo->prepare("
        SELECT student_id
        FROM students 
        WHERE student_id IN ($placeholders)
        AND status = 'active'
    ");
    $stmt->execute($student_ids);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($students) === 0) {
        die(json_encode([
            'success' => false,
            'message' => 'No valid active students found for promotion'
        ]));
    }
    
    // In the student update query:
    foreach ($students as $student) {
        $stmt = $pdo->prepare("
            UPDATE students SET 
                class_id = ?, 
                section_id = ?, 
                roll_no = ?, 
                admission_date = ?, 
                promoted_date = ?, 
                academic_year = ?, 
                custom_class_fee = ?, 
                updated_at = NOW()
            WHERE student_id = ?
        ");

        $params = [
            $new_class_id,
            $new_section_id,
            null, // Reset roll number to null for reassignment
            $promotion_date,
            $promotion_date,
            $academic_year,
            0,
            $student['student_id']
        ];

        $stmt->execute($params);
    }

    // Only mark as promoted if moving to higher class
    if ($mark_results_promoted && $new_class_id > $current_class_id) {
        $stmt = $pdo->prepare("
            UPDATE results SET 
                is_promoted = 1,
                updated_at = NOW()
            WHERE student_id IN ($placeholders)
        ");
        $stmt->execute($student_ids);
    }
    // If moving to lower class, mark as not promoted
    elseif ($new_class_id < $current_class_id) {
        $stmt = $pdo->prepare("
            UPDATE results SET 
                is_promoted = 0,
                updated_at = NOW()
            WHERE student_id IN ($placeholders)
        ");
        $stmt->execute($student_ids);
    }

    // Commit transaction
    $pdo->commit();

    // Prepare final response message
    $response_message = 'Successfully promoted ' . count($student_ids) . ' students.';

    if ($auto_include_admission_fee) {
        // Call admission fees entry function to handle fees for promoted students
        $admission_fee_entry = fun_admission_fees_entry(
            $pdo,
            implode(',', $student_ids),
            $academic_year,
            $new_class_id,
            0,
            true
        );

        // Append admission fee entry result to response message
        if ($admission_fee_entry['success']) {
            $admission_fee_entry_message = "";

            foreach ($admission_fee_entry['results'] as $fee_result) {
                $admission_fee_entry_message .= " " . $fee_result['message'];
            }

            $response_message .= " " . $admission_fee_entry_message;
        } else {
            $response_message .= " However, Admission fee entry failed: " . $admission_fee_entry['message'];
        }
    } else {
        $response_message .= " Admission fee entry is not created as you unchecked the option.";
    }

    echo json_encode([
        'success' => true,
        'message' => $response_message
    ]);
} catch (PDOException $e) {
    $pdo->rollBack();
    error_log("Promotion error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
