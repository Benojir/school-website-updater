<?php
require_once __DIR__ . '/../../../../includes/auth-check.php';
require_once __DIR__ . '/../../../../includes/academic/admission-year-correction-service.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: private, no-store');
$actor = authenticateAdminApiRequest($pdo);
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    http_response_code(403); exit(json_encode(['success' => false, 'message' => 'Manage Students permission is required.']));
}
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405); header('Allow: POST'); exit(json_encode(['success' => false, 'message' => 'Use POST for a year correction.']));
}
if (!is_string($_POST['csrf'] ?? null) || empty($_SESSION['admission_year_correction_csrf'])
    || !hash_equals($_SESSION['admission_year_correction_csrf'], $_POST['csrf'])) {
    http_response_code(403); exit(json_encode(['success' => false, 'message' => 'Your form expired. Reload Academic History before continuing.']));
}
try {
    $action = $_POST['action'] ?? null;
    if ($action === 'preview') {
        $plan = admissionYearCorrectionPreview($pdo, $_POST);
        if (array_sum($plan['counts']) && !hasPermission(PERM_MANAGE_FEES)) $plan['blockers'][] = 'An administrator with Manage Fees permission must complete this correction because linked fee/payment records exist.';
        echo json_encode(['success' => true, 'preview_hash' => $plan['preview_hash'], 'counts' => $plan['counts'],
            'blockers' => $plan['blockers'], 'source_year' => $plan['source_year'], 'target_year' => $plan['target_year']]);
    } elseif ($action === 'apply') {
        $result = admissionYearCorrectionApply($pdo, $_POST, $actor, hasPermission(PERM_MANAGE_FEES));
        echo json_encode(['success' => true, 'message' => 'Admission year corrected from ' . $result['source_year'] . ' to ' . $result['target_year'] . '. Student ID, amounts and payment dates were preserved.']);
    } else throw new InvalidArgumentException('Choose preview or apply.');
} catch (AdmissionYearCorrectionConflict $e) {
    http_response_code(409); echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} catch (InvalidArgumentException $e) {
    http_response_code(422); echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} catch (Throwable $e) {
    error_log('Admission year correction: ' . $e->getMessage());
    http_response_code(503); echo json_encode(['success' => false, 'message' => 'Correction could not be completed. Verify that the correction migration has been applied and try again. No partial correction was saved.']);
}
