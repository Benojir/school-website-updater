<?php
/** @var array $websiteConfig */
ob_start();
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/functions.php");
include_once(__DIR__ . "/../../../../includes/financial/fun-admission-fees-entry.php");
include_once(__DIR__ . "/../../../../includes/imgbb-upload.php");

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'errors' => ['You do not have permission to perform this action.']
    ]);
    die();
}

// Add this function for handling base64 images
function saveBase64Image(string $base64_string, string $upload_dir, $prefix = 'stu_')
{
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    // Check if the base64 string is valid
    if (preg_match('/^data:image\/(\w+);base64,/', $base64_string, $type)) {
        $data = substr($base64_string, strpos($base64_string, ',') + 1);
        $type = strtolower($type[1]); // jpg, png, gif

        if (!in_array($type, ['jpg', 'jpeg', 'png', 'gif'])) {
            return false;
        }

        $data = base64_decode($data);
        if ($data === false) {
            return false;
        }
    } else {
        return false;
    }

    $file_name = uniqid($prefix) . '.' . $type;
    $file_path = $upload_dir . $file_name;

    if (file_put_contents($file_path, $data)) {
        // Verify the saved file is a valid image
        if (!getimagesize($file_path)) {
            unlink($file_path);
            return false;
        }
        return $file_name;
    }

    return false;
}

// Function to save base64 image
// Enhanced function to validate and save images
function saveUploadedImage(mixed $file, string $upload_dir, $prefix = 'stu_')
{
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    // Get file info
    $file_name = basename($file['name']);
    $file_tmp = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];

    // Check for upload errors
    if ($file_error !== UPLOAD_ERR_OK) {
        throw new Exception("File upload error: " . $file_error);
    }

    // Get real file extension and MIME type
    $file_info = new finfo(FILEINFO_MIME_TYPE);
    $mime_type = $file_info->file($file_tmp);

    // Allowed MIME types and corresponding extensions
    $allowed_mimes = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png'
    ];

    // Verify MIME type is allowed
    if (!array_key_exists($mime_type, $allowed_mimes)) {
        throw new Exception("Invalid file type. Only JPG and PNG images are allowed.");
    }

    // Get correct extension based on MIME type
    $file_ext = $allowed_mimes[$mime_type];

    // Check for double extensions (e.g., malicious.php.jpg)
    $path_info = pathinfo($file_name);
    if (preg_match('/\.(php|phtml|html|htm|js|exe|dll|bat|sh)$/i', $path_info['filename'])) {
        throw new Exception("Invalid filename. Potentially dangerous file extension detected.");
    }

    // Verify image content
    if (!getimagesize($file_tmp)) {
        throw new Exception("Uploaded file is not a valid image.");
    }

    // Check file size (2MB max)
    $max_size = 2 * 1024 * 1024;
    if ($file_size > $max_size) {
        throw new Exception("Image size must be less than 2MB.");
    }

    // Generate unique filename with correct extension
    $new_file_name = uniqid($prefix) . '.' . $file_ext;
    $destination = $upload_dir . $new_file_name;

    // Sanitize destination path to prevent directory traversal
    // $destination = str_replace(['../', '..\\'], '', $destination);

    // Move the file using streams for additional security
    $src = fopen($file_tmp, 'rb');
    $dst = fopen($destination, 'wb');

    if (!$src || !$dst) {
        throw new Exception("Failed to process uploaded file.");
    }

    while (!feof($src)) {
        fwrite($dst, fread($src, 8192));
    }

    fclose($src);
    fclose($dst);

    // Verify the moved file is still a valid image
    if (!getimagesize($destination)) {
        unlink($destination);
        throw new Exception("Uploaded file became invalid after moving.");
    }

    return $new_file_name;
}

$response = [
    'success' => false,
    'message' => '',
    'errors' => []
];

$upload_dir = __DIR__ . '/../../../../uploads/students/';
$father_upload_dir = __DIR__ . '/../../../../uploads/fathers/';
$mother_upload_dir = __DIR__ . '/../../../../uploads/mothers/';

try {
    // Sanitize POST input
    $student_id                  = generateUniqueStudentId($pdo, $websiteConfig['student_id_prefix']); // Generate unique student ID
    $admission_type              = sanitize_input($_POST['admission_type'] ?? null);
    $name                        = sanitize_input($_POST['name'] ?? null);
    $father_name                 = sanitize_input($_POST['father_name'] ?? null);
    $mother_name                 = sanitize_input($_POST['mother_name'] ?? null);
    $father_occupation           = sanitize_input($_POST['father_occupation'] ?? null);
    $mother_occupation           = sanitize_input($_POST['mother_occupation'] ?? null);
    $email                       = sanitize_input($_POST['email'] ?? null);
    $religion                    = sanitize_input($_POST['religion'] ?? null);
    $registration_no             = sanitize_input($_POST['registration_no'] ?? null);
    $class_id                    = sanitize_input($_POST['class_id'] ?? null);
    $section_id                  = sanitize_input($_POST['section_id'] ?? null);
    $roll_no                     = sanitize_input($_POST['roll_no'] ?? null);
    $phone_number                = sanitize_input($_POST['phone_number'] ?? null);
    $alternate_phone_number      = sanitize_input($_POST['alternate_phone_number'] ?? null);
    $admission_date              = sanitize_input($_POST['admission_date'] ?? null);
    $academic_year               = sanitize_input($_POST['academic_year'] ?? null);
    $gender                      = sanitize_input($_POST['gender'] ?? null);
    $date_of_birth               = sanitize_input($_POST['date_of_birth'] ?? null);
    $status                      = 'Active'; // Default status for new students
    $blood_group                 = sanitize_input($_POST['blood_group'] ?? null);
    $is_hosteler                 = isset($_POST['is_hosteler']) ? (int)$_POST['is_hosteler'] : 0;
    $hostel_fee                  = (float)($_POST['hostel_fee'] ?? 0);
    $driver_id                   = sanitize_input($_POST['driver_id'] ?? null);
    $driving_route_id            = sanitize_input($_POST['driving_route'] ?? null);
    $car_fee                     = (float)($_POST['car_fee'] ?? 0);
    $coaching_fee                = (float)($_POST['coaching_fee'] ?? 0);
    $tiffin_fee                  = (float)($_POST['tiffin_fee'] ?? 0);
    $custom_class_fee            = (float)($_POST['custom_class_fee'] ?? 0);
    $admission_fee_discount      = (float)($_POST['admission_fee_discount'] ?? 0);
    $auto_include_admission_fee  = isset($_POST['auto_include_admission_fee']);
    $village                     = sanitize_input($_POST['village'] ?? null);
    $post_office                 = sanitize_input($_POST['post_office'] ?? null);
    $police_station              = sanitize_input($_POST['police_station'] ?? null);
    $district                    = sanitize_input($_POST['district'] ?? null);
    $pin_code                    = sanitize_input($_POST['pin_code'] ?? null);
    $student_adhaar_no           = sanitize_input($_POST['student_adhaar'] ?? null);
    $father_adhaar_no            = sanitize_input($_POST['father_adhaar'] ?? null);
    $mother_adhaar_no            = sanitize_input($_POST['mother_adhaar'] ?? null);
    $father_pan_no               = sanitize_input($_POST['father_pan_no'] ?? null);
    $father_voter_no             = sanitize_input($_POST['father_voter_no'] ?? null);
    $mother_pan_no               = sanitize_input($_POST['mother_pan_no'] ?? null);
    $mother_voter_no             = sanitize_input($_POST['mother_voter_no'] ?? null);
    $banglar_shiksha_code        = sanitize_input($_POST['banglar_shiksha_code'] ?? null);
    $caste                       = sanitize_input($_POST['caste'] ?? null);
    $father_annual_income        = sanitize_input($_POST['father_annual_income'] ?? null);
    $mother_annual_income        = sanitize_input($_POST['mother_annual_income'] ?? null);
    $bank_name                   = sanitize_input($_POST['bank_name'] ?? null);
    $bank_branch_name            = sanitize_input($_POST['bank_branch_name'] ?? null); // New Field
    $bank_account_no             = sanitize_input($_POST['bank_account_no'] ?? null);
    $ifsc_code                   = sanitize_input($_POST['ifsc_code'] ?? null);
    
    // Building full address
    $address = "{$village}, {$post_office}, {$police_station}, {$district}, {$pin_code}";
    $temp_address_var = trim(str_replace(",", "", $address));
    if (empty($temp_address_var)) {
        $address = null;
    }

    // Banglar Shiksha Code Unique Validation
    if (!empty($banglar_shiksha_code)) {
        $checkCode = $pdo->prepare("SELECT COUNT(*) FROM students WHERE banglar_shiksha_code = :code");
        $checkCode->execute([':code' => $banglar_shiksha_code]);
        if ($checkCode->fetchColumn() > 0) {
            throw new Exception("Banglar Shiksha Student Code already exists in the system.");
        }
    }

    // Validating inputs
    if ($car_fee < 0) {
        throw new Exception("Car fee cannot be negative.");
    } 
    
    if ($hostel_fee < 0) {
        throw new Exception("Hostel fee cannot be negative.");
    }

    if ($custom_class_fee < 0) {
        throw new Exception("Custom class fee cannot be negative.");
    }

    if ($coaching_fee < 0) {
        throw new Exception("Coaching fee cannot be negative.");
    }

    if ($tiffin_fee < 0) {
        throw new Exception("Tiffin fee cannot be negative.");
    }

    if ($admission_fee_discount < 0) {
        throw new Exception("Admission fee discount cannot be negative.");
    }

    if ($car_fee == 0) {
        $driver_id = null;
        $driving_route_id = null;
    }

    // Validate required fields
    $required_fields = [
        'admission_type',
        'name',
        'father_name',
        'class_id',
        'phone_number',
        'admission_date',
        'academic_year',
        'gender',
        'date_of_birth',
    ];

    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            throw new Exception("All required fields must be filled.");
        }
    }

    // Declaring default $is_re_admission
    $is_re_admission = false;

    // Validate admission type
    if ($admission_type === "re-admission") {
        $is_re_admission = true;
    }

    /** @var PDO $pdo */
    // Validate driving route and driver id
    if (!empty($driving_route_id)) {
        if (is_numeric($driving_route_id)) {
            // Check if driving route exists
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM driving_routes WHERE id = ?");
            $stmt->execute([$driving_route_id]);
            if ($stmt->fetchColumn() == 0) {
                throw new Exception("Selected driving route does not exist.");
            }
        } else {
            throw new Exception("Invalid driving route selected.");
        }
    }

    if (!empty($driver_id)) {
        if (is_numeric($driver_id)) {
            $stmt = $pdo->prepare("SELECT route_ids FROM drivers WHERE id = ? AND status = 'active'");
            $stmt->execute([$driver_id]);
            if ($stmt->rowCount() == 0) {
                throw new Exception("Selected driver does not exist or is not active.");
            }

            $driver_route_ids = $stmt->fetchColumn();

            if (!empty($driver_route_ids)) {
                if (!in_array($driving_route_id, json_decode($driver_route_ids ?? '[]', true))) {
                    throw new Exception("Selected driver is not assigned to the selected driving route.");
                }
            }
        } else {
            throw new Exception("Invalid driver selected.");
        }
    }

    // Validate phone number
    if (!isValidPhoneNumber($phone_number)) {
        throw new Exception("Invalid phone number format. It should be 10 digits.");
    }

    // Validate alternate phone number
    if (!empty($alternate_phone_number)) {
        if (!isValidPhoneNumber($alternate_phone_number)) {
            throw new Exception("Invalid alternate phone number format. It should be 10 digits.");
        }
    }

    // Then modify the image handling section like this:
    $image_path = "default_student_dp.jpg"; // Default image

    // Handle image upload - prioritize cropped image if available
    if (!empty($_POST['cropped_image_data'])) {
        // Use the new base64 function for cropped images
        $cropped_image = saveBase64Image($_POST['cropped_image_data'], $upload_dir);

        if ($cropped_image) {
            $image_path = $cropped_image;
        } else {
            throw new Exception("Failed to save cropped image.");
        }
    }
    // Fall back to regular file upload if no cropped image available
    elseif (isset($_FILES['student_image']) && $_FILES['student_image']['size'] > 0) {
        try {
            $image_path = saveUploadedImage($_FILES['student_image'], $upload_dir);

            // Additional ratio check for non-cropped images
            $image_full_path = $upload_dir . $image_path;
            list($width, $height) = getimagesize($image_full_path);

            $ratio = getRatioArray($width, $height);
            if ($ratio === null) {
                unlink($image_full_path);
                throw new Exception("Invalid image dimensions.");
            }

            $width_ratio = $ratio[0];
            $height_ratio = $ratio[1];

            if ($width_ratio !== 5 || $height_ratio !== 6) {
                unlink($image_full_path);
                throw new Exception("Image must be in a 5:6 ratio. Current ratio: {$width_ratio}:{$height_ratio}");
            }
        } catch (Exception $e) {
            throw new Exception("Image upload failed: " . $e->getMessage());
        }
    }

    // Father's photo - stored locally, same as student photo (optional)
    // Handle image upload - prioritize cropped image if available
    $father_image_path = null;
    if (!empty($_POST['cropped_father_image_data'])) {
        $cropped_father_image = saveBase64Image($_POST['cropped_father_image_data'], $father_upload_dir, 'fa_');

        if ($cropped_father_image) {
            $father_image_path = $cropped_father_image;
        } else {
            throw new Exception("Failed to save father's cropped image.");
        }
    }
    // Fall back to regular file upload if no cropped image available
    elseif (isset($_FILES['father_image']) && $_FILES['father_image']['size'] > 0) {
        try {
            $father_image_path = saveUploadedImage($_FILES['father_image'], $father_upload_dir, 'fa_');
        } catch (Exception $e) {
            throw new Exception("Father's photo upload failed: " . $e->getMessage());
        }
    }

    // Mother's photo - stored locally, same as student photo (optional)
    // Handle image upload - prioritize cropped image if available
    $mother_image_path = null;
    if (!empty($_POST['cropped_mother_image_data'])) {
        $cropped_mother_image = saveBase64Image($_POST['cropped_mother_image_data'], $mother_upload_dir, 'mo_');

        if ($cropped_mother_image) {
            $mother_image_path = $cropped_mother_image;
        } else {
            throw new Exception("Failed to save mother's cropped image.");
        }
    }
    // Fall back to regular file upload if no cropped image available
    elseif (isset($_FILES['mother_image']) && $_FILES['mother_image']['size'] > 0) {
        try {
            $mother_image_path = saveUploadedImage($_FILES['mother_image'], $mother_upload_dir, 'mo_');
        } catch (Exception $e) {
            throw new Exception("Mother's photo upload failed: " . $e->getMessage());
        }
    }

    // Document images - all uploaded to ImgBB, only the direct link is stored in the database (optional)
    // Results are collected in $document_urls[field_name] and read out below when building the INSERT.
    $document_upload_map = [
        'father_aadhaar_image'          => "Father's Aadhaar Card - {$name}",
        'father_voter_image'            => "Father's Voter Card - {$name}",
        'father_pan_image'              => "Father's PAN Card - {$name}",
        'mother_aadhaar_image'          => "Mother's Aadhaar Card - {$name}",
        'mother_voter_image'            => "Mother's Voter Card - {$name}",
        'mother_pan_image'              => "Mother's PAN Card - {$name}",
        'student_birth_certificate'     => "Birth Certificate - {$name}",
        'student_aadhaar_image'         => "Student's Aadhaar Card - {$name}",
        'student_transfer_certificate'  => "Transfer Certificate - {$name}",
    ];

    $document_urls = array_fill_keys(array_keys($document_upload_map), null);

    foreach ($document_upload_map as $field_name => $caption) {
        if (isset($_FILES[$field_name]) && $_FILES[$field_name]['size'] > 0) {
            try {
                $document_urls[$field_name] = uploadDocumentToImgBB($_FILES[$field_name], $caption);
            } catch (Exception $e) {
                throw new Exception(str_replace('_', ' ', ucfirst($field_name)) . " upload failed: " . $e->getMessage());
            }
        }
    }

    // Check for duplicate student entry
    $checkID = $pdo->prepare("SELECT COUNT(*) FROM students WHERE name = :name AND class_id = :class_id AND father_name = :father_name");
    $checkID->execute([':name' => $name, ':class_id' => $class_id, ':father_name' => $father_name]);
    if ($checkID->fetchColumn() > 0) {
        throw new Exception("Student already exists.");
    }

    // Check for duplicate roll number in same class/section
    $checkRoll = $pdo->prepare("SELECT COUNT(*) FROM students WHERE class_id = :class_id AND roll_no = :roll_no AND section_id = :section_id");
    $checkRoll->execute([
        ':class_id'   => $class_id,
        ':roll_no' => $roll_no,
        ':section_id' => $section_id
    ]);
    if ($checkRoll->fetchColumn() > 0) {
        throw new Exception("Roll number already assigned in this class and section.");
    }

    // Check primary number and alternate number if same
    if ($phone_number == $alternate_phone_number) {
        throw new Exception("Primary phone number and alternate phone number must be different. You can leave blank the alternate phone number field.");
    }

    // Insert new student with additional fields
    $stmt = $pdo->prepare("
        INSERT INTO students (
            student_id, name, father_name, mother_name, father_occupation, mother_occupation,
            address, student_image, class_id, section_id, roll_no, phone_number, alternate_phone_number, email, religion, registration_no,
            admission_date, academic_year, gender, date_of_birth, status, blood_group, is_hosteler, driving_route_id, driver_id, car_fee, hostel_fee, coaching_fee, tiffin_fee, custom_class_fee,
            village, post_office, police_station, district, pin_code, student_adhaar_no, father_adhaar_no, mother_adhaar_no,
            banglar_shiksha_code, caste, father_annual_income, mother_annual_income, bank_name, bank_branch_name, bank_account_no, ifsc_code,
            father_pan_no, father_voter_no, mother_pan_no, mother_voter_no, father_image, mother_image,
            father_aadhaar_image, father_voter_image, father_pan_image,
            mother_aadhaar_image, mother_voter_image, mother_pan_image,
            student_birth_certificate, student_aadhaar_image, student_transfer_certificate
        ) VALUES (
            :student_id, :name, :father_name, :mother_name, :father_occupation, :mother_occupation,
            :address, :student_image, :class_id, :section, :roll_no, :phone_number, :alternate_phone_number, :email, :religion, :registration_no,
            :admission_date, :academic_year, :gender, :date_of_birth, :status, :blood_group, :is_hosteler, :driving_route_id, :driver_id, :car_fee, :hostel_fee, :coaching_fee, :tiffin_fee, :custom_class_fee,
            :village, :post_office, :police_station, :district, :pin_code, :student_adhaar_no, :father_adhaar_no, :mother_adhaar_no,
            :banglar_shiksha_code, :caste, :father_annual_income, :mother_annual_income, :bank_name, :bank_branch_name, :bank_account_no, :ifsc_code,
            :father_pan_no, :father_voter_no, :mother_pan_no, :mother_voter_no, :father_image, :mother_image,
            :father_aadhaar_image, :father_voter_image, :father_pan_image,
            :mother_aadhaar_image, :mother_voter_image, :mother_pan_image,
            :student_birth_certificate, :student_aadhaar_image, :student_transfer_certificate
        )
    ");

    $stmt->execute([
        ':student_id'                  => $student_id,
        ':name'                        => $name,
        ':father_name'                 => $father_name,
        ':mother_name'                 => $mother_name,
        ':father_occupation'           => $father_occupation,
        ':mother_occupation'           => $mother_occupation,
        ':address'                     => $address,
        ':student_image'               => $image_path,
        ':class_id'                    => $class_id,
        ':section'                     => $section_id,
        ':roll_no'                     => $roll_no,
        ':phone_number'                => $phone_number,
        ':alternate_phone_number'      => $alternate_phone_number,
        ':email'                       => $email,
        ':religion'                    => $religion,
        ':registration_no'             => $registration_no,
        ':admission_date'              => $admission_date,
        ':academic_year'               => $academic_year,
        ':gender'                      => $gender,
        ':date_of_birth'               => $date_of_birth,
        ':status'                      => $status,
        ':blood_group'                 => $blood_group,
        ':is_hosteler'                 => $is_hosteler,
        ':driving_route_id'            => $driving_route_id,
        ':driver_id'                   => $driver_id,
        ':car_fee'                     => $car_fee,
        ':hostel_fee'                  => $hostel_fee,
        ':coaching_fee'                => $coaching_fee,
        ':tiffin_fee'                  => $tiffin_fee,
        ':custom_class_fee'            => $custom_class_fee,
        ':village'                     => $village,
        ':post_office'                 => $post_office,
        ':police_station'              => $police_station,
        ':district'                    => $district,
        ':pin_code'                    => $pin_code,
        ':student_adhaar_no'           => $student_adhaar_no,
        ':father_adhaar_no'            => $father_adhaar_no,
        ':mother_adhaar_no'            => $mother_adhaar_no,
        ':banglar_shiksha_code'        => $banglar_shiksha_code,
        ':caste'                       => $caste,
        ':father_annual_income'        => $father_annual_income,
        ':mother_annual_income'        => $mother_annual_income,
        ':bank_name'                   => $bank_name,
        ':bank_branch_name'            => $bank_branch_name,
        ':bank_account_no'             => $bank_account_no,
        ':ifsc_code'                   => $ifsc_code,
        ':father_pan_no'               => $father_pan_no,
        ':father_voter_no'             => $father_voter_no,
        ':mother_pan_no'               => $mother_pan_no,
        ':mother_voter_no'             => $mother_voter_no,
        ':father_image'                => $father_image_path,
        ':mother_image'                => $mother_image_path,
        ':father_aadhaar_image'        => $document_urls['father_aadhaar_image'],
        ':father_voter_image'          => $document_urls['father_voter_image'],
        ':father_pan_image'            => $document_urls['father_pan_image'],
        ':mother_aadhaar_image'        => $document_urls['mother_aadhaar_image'],
        ':mother_voter_image'          => $document_urls['mother_voter_image'],
        ':mother_pan_image'            => $document_urls['mother_pan_image'],
        ':student_birth_certificate'   => $document_urls['student_birth_certificate'],
        ':student_aadhaar_image'       => $document_urls['student_aadhaar_image'],
        ':student_transfer_certificate' => $document_urls['student_transfer_certificate']
    ]);

    $response['success'] = true;
    $response['message'] = "Student added successfully!";

    if ($auto_include_admission_fee) {
        // Insert admission fee record if applicable
        $admission_fee_entry = fun_admission_fees_entry(
            $pdo,
            $student_id,
            $academic_year,
            $class_id,
            $admission_fee_discount,
            $is_re_admission
        );

        if ($admission_fee_entry['success']) {
            $response['message'] .= " Also Admission fee entry created.";
        } else {
            $response['message'] .= " However, Admission fee entry failed: " . $admission_fee_entry['message'];
        }
    } else {
         $response['message'] .= " Admission fee entry is not created as you unchecked the option.";
    }

} catch (PDOException $e) {
    http_response_code(500);
    $response['message'] = "Database error: " . $e->getMessage();
    // error_log("PDOException: " . $e->getMessage());
} catch (Exception $e) {
    http_response_code(400);
    $response['message'] = $e->getMessage();
}

// Clean any output buffers
while (ob_get_level()) {
    ob_end_clean();
}

// Ensure only JSON is output
header('Content-Type: application/json');
echo json_encode($response);
exit();