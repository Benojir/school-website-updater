<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/phpmailer.php");
include_once(__DIR__ . "/../../../../includes/financial/fun-admission-fees-entry.php");

require_once __DIR__ . '/../../../../includes/academic/admission-enquiry-service.php';

header('Content-Type: application/json');

$log_directory = __DIR__ . "/../../../../assets/logs";

// Check permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

// Validate input parameters
if (!isset($_REQUEST['enquiry_id'], $_REQUEST['action']) || 
    empty(trim($_REQUEST['enquiry_id'])) || 
    empty(trim($_REQUEST['action']))) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid request. Required parameters missing.']);
    exit;
}

$enquiry_id = trim($_REQUEST['enquiry_id']);
$academic_year = sanitize_input($_REQUEST['academic_year'] ?? '');
$action = strtolower(trim($_REQUEST['action']));
$allowed_actions = ['delete', 'reject', 'approve'];

// Validate action
if (!in_array($action, $allowed_actions)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid action specified.']);
    exit;
}

// Validate academic year
if (!empty($academic_year)) {
    if (!isIntegerLike($academic_year)) {
        echo json_encode(['success' => false, 'message' => 'Invalid academic year input.']);
        exit;
    }
}

$table = "admission_enquiries";

try {
    // Fetch enquiry details
    $stmt = $pdo->prepare("SELECT * FROM `$table` WHERE id = ?");
    $stmt->execute([$enquiry_id]);
    $enquiry = $stmt->fetch(PDO::FETCH_ASSOC);

    // Validate enquiry exists
    if (!$enquiry) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Admission enquiry not found.']);
        exit;
    }

    // Handle different actions
    switch ($action) {
        case 'delete':
            handleDelete($pdo, $table, $enquiry_id);
            break;
        case 'reject':
            handleReject($pdo, $table, $enquiry_id, $enquiry);
            break;
        case 'approve':
            handleApprove($pdo, $table, $enquiry_id, $enquiry, $academic_year);
            break;
    }

} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    if (is_dir($log_directory)) {
        file_put_contents(
            $log_directory . '/admission_enquiry_process_errors.txt',
            "Database error in enquiry handler: " . $e->getMessage()
        );
    }
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error occurred.']);
} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    if (is_dir($log_directory)) {
        file_put_contents(
            $log_directory . '/admission_enquiry_process_errors.txt',
            "General error in enquiry handler: " . $e->getMessage()
        );
    }
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

/**
 * Handle delete action
 */
function deletePendingEnquiry(PDO $pdo, $enquiry_id): array {
    $pdo->beginTransaction();
    try {
        // Serialize against approval so an approved student's photo is never removed.
        $lock = $pdo->prepare('SELECT * FROM admission_enquiries WHERE id = ? FOR UPDATE');
        $lock->execute([$enquiry_id]);
        $enquiry = $lock->fetch(PDO::FETCH_ASSOC);
        if (!$enquiry) throw new RuntimeException('This enquiry has already been processed.');
        $stmt = $pdo->prepare('DELETE FROM admission_enquiries WHERE id = ?');
        $stmt->execute([$enquiry_id]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
    admissionEnquiryRemovePhoto($enquiry['student_image'] ?? null);
    return $enquiry;
}

function handleDelete($pdo, $table, $enquiry_id) {
    deletePendingEnquiry($pdo, $enquiry_id);
    echo json_encode(['success' => true, 'message' => 'Enquiry deleted successfully.']);
}

function handleReject($pdo, $table, $enquiry_id, $enquiry) {
    global $school_name;
    $enquiry = deletePendingEnquiry($pdo, $enquiry_id);
    $message = 'Enquiry rejected successfully.';
    try {
        if (sendRejectionEmail($enquiry, $school_name)) $message .= ' Email notification sent.';
    } catch (Throwable $e) {
        $message .= ' The email notification could not be sent.';
    }
    echo json_encode(['success' => true, 'message' => $message]);
}

/**
 * Handle approve action
 */
function handleApprove($pdo, $table, $enquiry_id, $enquiry, $academic_year) {
    global $school_name, $websiteConfig;
    academicRequireCurrentYear($pdo);

    // Begin transaction
    $pdo->beginTransaction();
    academicLockSettings($pdo);
    
    try {
        $lock = $pdo->prepare("SELECT * FROM admission_enquiries WHERE id = ? FOR UPDATE");
        $lock->execute([$enquiry_id]);
        $enquiry = $lock->fetch(PDO::FETCH_ASSOC);
        if (!$enquiry) throw new RuntimeException('This enquiry has already been processed.');
        $academic_year = admissionEnquiryApprovalYear($enquiry, $academic_year);
        // Generate unique student ID
        $student_id = generateUniqueStudentId($pdo, $websiteConfig['student_id_prefix']);
        
        // Insert into students table
        $sql = "INSERT INTO students (
            student_id, 
            name, 
            gender, 
            date_of_birth, 
            blood_group, 
            phone_number, 
            alternate_phone_number, 
            email, 
            address, 
            father_name, 
            mother_name, 
            father_occupation, 
            mother_occupation, 
            class_id, 
            religion,
            student_adhaar_no,
            village,
            post_office,
            police_station,
            district,
            pin_code,
            father_adhaar_no,
            mother_adhaar_no,
            academic_year,
            student_image,
            admission_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        
        $values = [
            $student_id,
            $enquiry['name'],
            $enquiry['gender'],
            $enquiry['date_of_birth'],
            $enquiry['blood_group'],
            $enquiry['phone_number'],
            $enquiry['alternate_phone_number'],
            $enquiry['email'],
            $enquiry['address'],
            $enquiry['father_name'],
            $enquiry['mother_name'],
            $enquiry['father_occupation'],
            $enquiry['mother_occupation'],
            $enquiry['class_id'],
            $enquiry['religion'],
            $enquiry['student_adhaar_no'],
            $enquiry['village'],
            $enquiry['post_office'],
            $enquiry['police_station'],
            $enquiry['district'],
            $enquiry['pin_code'],
            $enquiry['father_adhaar_no'],
            $enquiry['mother_adhaar_no'],
            $academic_year,
            ($enquiry['student_image'] ?? null) ?: 'default_student_dp.jpg'
        ];
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($values);
        
        academicCaptureNewStudent($pdo, (int)$pdo->lastInsertId(), [
            'academic_year' => $academic_year, 'class_id' => $enquiry['class_id'],
            'section_id' => null, 'roll_no' => null, 'registration_no' => null,
            'admission_date' => date('Y-m-d'), 'status' => 'Active', 'custom_class_fee' => 0,
        ]);

        // Delete from enquiries table
        $deleteStmt = $pdo->prepare("DELETE FROM `$table` WHERE id = ?");
        $deleteStmt->execute([$enquiry_id]);
        
        // Commit transaction
        $pdo->commit();

        $response_message = "Application approved successfully. Student added.";

        // Insert admission fee record if applicable
        try {
            $admission_fee_entry = fun_admission_fees_entry(
            $pdo, 
            $student_id, 
            $academic_year, 
            $enquiry['class_id'], 
            0
        );
        } catch (Throwable $feeError) {
            $admission_fee_entry = ['success' => false, 'message' => $feeError->getMessage()];
        }

        // Append admission fee entry result to response message
        if ($admission_fee_entry['success']) {
            $admission_fee_entry_message = "";

            foreach ($admission_fee_entry['results'] as $fee_result) {
                $admission_fee_entry_message .= " " . $fee_result['message'];
            }

            $response_message .= " " . $admission_fee_entry_message;
        } else {
            $response_message .= " However, Admission fee entry failed: " . $admission_fee_entry['message'];
        }
        
        // Send approval email
        try {
            sendApprovalEmail($enquiry, $student_id, $school_name);
        } catch (Throwable $notificationError) {
            $response_message .= ' Admission saved; approval notification could not be sent.';
        }
        
        echo json_encode([
            'success' => true, 
            'message' => $response_message,
            'student_id' => $student_id
        ]);
        
    } catch (Exception $e) {
        // Rollback transaction on error
        if ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}

/**
 * Send rejection email
 */
function sendRejectionEmail($enquiry, $school_name) {
    if (empty($enquiry['email'])) return false;
    $recipientName = safe_htmlspecialchars($enquiry['name']);
    $recipientEmail = $enquiry['email'];
    $senderName = $school_name;
    $subject = 'Admission Application Status - ' . $school_name;
    
    $htmlBody = generateRejectionEmailHTML($recipientName, $school_name, $senderName);
    $altBody = generateRejectionEmailText($recipientName, $school_name, $senderName);
    
    $sent = sendMail($senderName, $recipientEmail, $recipientName, $subject, $htmlBody, $altBody);
    if (!is_array($sent) || empty($sent['success'])) throw new RuntimeException('Email notification could not be sent.');
    return true;
}

/**
 * Send approval email
 */
function sendApprovalEmail($enquiry, $student_id, $school_name) {
    if (empty($enquiry['email'])) return false;
    $recipientName = safe_htmlspecialchars($enquiry['name']);
    $recipientEmail = $enquiry['email'];
    $senderName = $school_name;
    $subject = 'Admission Approved - Welcome to ' . $school_name;
    
    $htmlBody = generateApprovalEmailHTML($recipientName, $student_id, $school_name, $senderName);
    $altBody = generateApprovalEmailText($recipientName, $student_id, $school_name, $senderName);
    
    $sent = sendMail($senderName, $recipientEmail, $recipientName, $subject, $htmlBody, $altBody);
    if (!is_array($sent) || empty($sent['success'])) throw new RuntimeException('Email notification could not be sent.');
    return true;
}

/**
 * Generate rejection email HTML
 */
function generateRejectionEmailHTML($recipientName, $school_name, $senderName) {
    return '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admission Application Status</title>
    </head>
    <body style="font-family: Arial, sans-serif; background-color: #f8f9fa; color: #333; padding: 20px; margin: 0;">
        <div style="max-width: 600px; margin: auto; background-color: #fff; border-left: 6px solid #dc3545; box-shadow: 0 4px 6px rgba(0,0,0,0.1); border-radius: 8px; overflow: hidden;">
            <div style="background-color: #dc3545; color: white; padding: 20px; text-align: center;">
                <h2 style="margin: 0; font-size: 24px;">Application Status Update</h2>
            </div>
            <div style="padding: 30px; line-height: 1.6;">
                <p style="margin-bottom: 20px;">Dear <strong>' . $recipientName . '</strong>,</p>
                
                <p style="margin-bottom: 20px;">Thank you for your interest in seeking admission at <strong>' . safe_htmlspecialchars($school_name) . '</strong>.</p>
                
                <p style="margin-bottom: 20px;">After careful evaluation of your application, we regret to inform you that we are unable to offer you admission at this time.</p>
                
                <p style="margin-bottom: 20px;">This decision was made based on our current admission criteria and capacity constraints. We understand this may be disappointing, and we encourage you to consider applying again in future admission cycles.</p>
                
                <p style="margin-bottom: 20px;">If you have any questions regarding this decision or would like feedback on your application, please feel free to contact our admissions office.</p>
                
                <p style="margin-bottom: 30px;">We wish you all the best in your academic pursuits and future endeavors.</p>
                
                <p style="margin-bottom: 5px;">Warm regards,</p>
                <p style="margin-bottom: 0;"><strong>' . safe_htmlspecialchars($senderName) . ' Admissions Office</strong></p>
            </div>
            <div style="background-color: #f8d7da; text-align: center; padding: 15px; font-size: 12px; color: #721c24;">
                This is an automated message. Please do not reply directly to this email.
            </div>
        </div>
    </body>
    </html>';
}

/**
 * Generate approval email HTML
 */
function generateApprovalEmailHTML($recipientName, $student_id, $school_name, $senderName) {
    return '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admission Approved</title>
    </head>
    <body style="font-family: Arial, sans-serif; background-color: #f8f9fa; color: #333; padding: 20px; margin: 0;">
        <div style="max-width: 600px; margin: auto; background-color: #fff; border-left: 6px solid #28a745; box-shadow: 0 4px 6px rgba(0,0,0,0.1); border-radius: 8px; overflow: hidden;">
            <div style="background-color: #28a745; color: white; padding: 20px; text-align: center;">
                <h2 style="margin: 0; font-size: 24px;">🎉 Congratulations! Admission Approved</h2>
            </div>
            <div style="padding: 30px; line-height: 1.6;">
                <p style="margin-bottom: 20px;">Dear <strong>' . $recipientName . '</strong>,</p>
                
                <p style="margin-bottom: 20px;">We are delighted to inform you that your application for admission to <strong>' . safe_htmlspecialchars($school_name) . '</strong> has been <strong style="color: #28a745;">APPROVED</strong>!</p>
                
                <div style="background-color: #d4edda; padding: 20px; border-radius: 6px; margin: 20px 0; border: 1px solid #c3e6cb;">
                    <p style="margin: 0; font-size: 16px;"><strong>Your Student ID: ' . safe_htmlspecialchars($student_id) . '</strong></p>
                </div>
                
                <p style="margin-bottom: 20px;">Welcome to our school community! We are excited to have you join us on this educational journey.</p>
                
                <p style="margin-bottom: 20px;"><strong>Next Steps:</strong></p>
                <ol style="margin-bottom: 20px; padding-left: 20px;">
                    <li style="margin-bottom: 10px;">Please save your Student ID for future reference</li>
                    <li style="margin-bottom: 10px;">Complete the enrollment process by visiting our admissions office</li>
                    <li style="margin-bottom: 10px;">Submit any remaining documentation if required</li>
                    <li style="margin-bottom: 10px;">Attend the orientation session (details will follow)</li>
                </ol>
                
                <p style="margin-bottom: 20px;">If you have any questions or need assistance with the enrollment process, please contact our admissions office.</p>
                
                <p style="margin-bottom: 30px;">Once again, congratulations and welcome to <strong>' . safe_htmlspecialchars($school_name) . '</strong>!</p>
                
                <p style="margin-bottom: 5px;">Best regards,</p>
                <p style="margin-bottom: 0;"><strong>' . safe_htmlspecialchars($senderName) . ' Admissions Office</strong></p>
            </div>
            <div style="background-color: #d1ecf1; text-align: center; padding: 15px; font-size: 12px; color: #0c5460;">
                This is an automated message. Please do not reply directly to this email.
            </div>
        </div>
    </body>
    </html>';
}

/**
 * Generate rejection email plain text
 */
function generateRejectionEmailText($recipientName, $school_name, $senderName) {
    return "Dear $recipientName,

Thank you for your interest in seeking admission at $school_name.

After careful evaluation of your application, we regret to inform you that we are unable to offer you admission at this time.

This decision was made based on our current admission criteria and capacity constraints. We encourage you to consider applying again in future admission cycles.

If you have any questions regarding this decision, please contact our admissions office.

We wish you all the best in your academic pursuits.

Warm regards,
$senderName Admissions Office

---
This is an automated message. Please do not reply directly to this email.";
}

/**
 * Generate approval email plain text
 */
function generateApprovalEmailText($recipientName, $student_id, $school_name, $senderName) {
    return "Dear $recipientName,

Congratulations! Your application for admission to $school_name has been APPROVED!

Your Student ID: $student_id

Welcome to our school community! We are excited to have you join us.

Next Steps:
1. Save your Student ID for future reference
2. Complete the enrollment process by visiting our admissions office  
3. Submit any remaining documentation if required
4. Attend the orientation session (details will follow)

If you have any questions, please contact our admissions office.

Welcome to $school_name!

Best regards,
$senderName Admissions Office

---
This is an automated message. Please do not reply directly to this email.";
}
?>