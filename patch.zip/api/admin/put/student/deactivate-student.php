<?php
/** @var PDO $pdo  */
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to delete students
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to deactivate students.'
    ]);
    die();
}

try {
    // Only accept POST requests
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Method Not Allowed');
    }

    // Check if student_ids are provided
    // We check $_POST directly for 'student_ids'
    $raw_ids = $_POST['student_ids'] ?? '';

    if (empty($raw_ids)) {
        throw new Exception('No student IDs provided');
    }

    // Sanitize and convert comma-separated string to array
    // Example input: "101, 102, 105" -> ['101', '102', '105']
    $student_ids = array_filter(array_map('trim', explode(',', $raw_ids)));

    if (empty($student_ids)) {
        throw new Exception('Invalid student IDs format');
    }

    // Begin transaction for bulk update
    $pdo->beginTransaction();

    // Prepare the statement ONCE outside the loop for performance
    $deactiveStmt = $pdo->prepare("UPDATE `students` SET roll_no = NULL, status = 'Left' WHERE student_id = ?");

    $updated_count = 0;

    foreach ($student_ids as $student_id) {
        // execute update for this specific ID
        $deactiveStmt->execute([$student_id]);
        
        // Add to count if a row was actually modified
        $updated_count += $deactiveStmt->rowCount();
    }

    // Commit the transaction
    $pdo->commit();

    // Check if any students were actually deactivated
    if ($updated_count === 0) {
        echo json_encode([
            'success' => true, // Still true because no error occurred
            'message' => 'No matching students found to deactivate.',
            'count' => 0
        ]);
    } else {
        echo json_encode([
            'success' => true,
            'message' => "Successfully deactivated $updated_count student(s).",
            'count' => $updated_count
        ]);
    }

} catch (PDOException $e) {
    // Roll back transaction on database error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    // Roll back if other logical errors occur inside transaction
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}