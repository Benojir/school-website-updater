<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");
header('Content-Type: application/json');
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}
try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') throw new RuntimeException('POST required.');
    $year = academicNormalizeYear($_POST['selected_year'] ?? academicRequireCurrentYear($pdo));
    $ids = array_values(array_unique(array_filter(array_map('trim', explode(',', $_POST['student_ids'] ?? '')))));
    if (!$ids) throw new RuntimeException('Select students first.');
    $pdo->beginTransaction();
    academicLockSettings($pdo);
    foreach ($ids as $id) academicSetStatus($pdo, $id, 'Left', $year);
    $pdo->commit();
    echo json_encode(['success' => true, 'count' => count($ids), 'message' => count($ids) . ' enrollment(s) updated for ' . $year . '. Historical roll numbers are preserved.']);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
