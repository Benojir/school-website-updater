<?php
require_once __DIR__ . '/../../../../includes/auth-check.php';
require_once __DIR__ . '/../../../../includes/academic/admission-enquiry-edit-service.php';
header('Content-Type: application/json');

if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Permission denied.']);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    echo json_encode(['success' => false, 'message' => 'Use POST to save an application.']);
    exit;
}
if (!is_string($_POST['csrf'] ?? null) || empty($_SESSION['admission_enquiry_edit_csrf'])
    || !hash_equals($_SESSION['admission_enquiry_edit_csrf'], $_POST['csrf'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Your session has expired. Reload this page and try again.']);
    exit;
}
try {
    $updated = admissionEnquiryUpdate($pdo, $_POST, $_FILES['student_image'] ?? null);
    try {
        $photoUrl = schoolPhotoUrl('students', $updated['student_image']);
    } catch (Throwable $e) {
        // The edit is committed; a CDN lookup error should not report it as failed.
        $photoUrl = schoolPhotoGatewayUrl('students', $updated['student_image'] ?: schoolPhotoCategories()['students'][2]);
    }
    echo json_encode(['success' => true, 'message' => 'Application updated successfully. It is still pending approval.',
        'original_version' => admissionEnquiryVersion($updated), 'photo_url' => $photoUrl,
        'has_photo' => !empty($updated['student_image'])]);
} catch (AdmissionEnquiryEditConflict $e) {
    http_response_code(409);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} catch (InvalidArgumentException $e) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} catch (Throwable $e) {
    error_log('Admission enquiry edit failed: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'The application could not be saved. Please try again.']);
}
