<?php
ob_start();
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/functions.php");
include_once(__DIR__ . "/../../../../includes/financial/fun-admission-fees-entry.php");

header('Content-Type: application/json');

if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    die();
}

$upload_dir = __DIR__ . '/../../../../uploads/students/';

$response = ['success' => false, 'message' => ''];

try {
    // Sanitize function
    function clean($data)
    {
        return safe_htmlspecialchars(trim($data));
    }

    // Function to save base64 image
    function saveBase64Image($base64_string, $upload_dir, $prefix = 'stu_')
    {
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        if (preg_match('/^data:image\/(\w+);base64,/', $base64_string, $type)) {
            $data = substr($base64_string, strpos($base64_string, ',') + 1);
            $type = strtolower($type[1]); // jpg, png, gif

            if (!in_array($type, ['jpg', 'jpeg', 'png', 'gif'])) {
                return false;
            }

            $data = base64_decode($data);
            if ($data === false) {
                return false;
            }
        } else {
            return false;
        }

        $file_name = uniqid($prefix) . '.' . $type;
        $file_path = $upload_dir . $file_name;

        if (file_put_contents($file_path, $data)) {
            // Verify the saved file is a valid image
            if (!getimagesize($file_path)) {
                unlink($file_path);
                return false;
            }
            return $file_name;
        }

        return false;
    }

    // Function to save uploaded image
    function saveUploadedImage($file, $upload_dir, $prefix = 'stu_')
    {
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        $file_tmp = $file['tmp_name'];
        $file_name = basename($file['name']);
        $file_size = $file['size'];
        $file_error = $file['error'];

        if ($file_error !== UPLOAD_ERR_OK) {
            throw new Exception("File upload error");
        }

        $file_info = new finfo(FILEINFO_MIME_TYPE);
        $mime_type = $file_info->file($file_tmp);

        $allowed_mimes = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png'
        ];

        if (!array_key_exists($mime_type, $allowed_mimes)) {
            throw new Exception("Invalid file type. Only JPG and PNG allowed.");
        }

        $file_ext = $allowed_mimes[$mime_type];

        $path_info = pathinfo($file_name);
        if (preg_match('/\.(php|phtml|html|htm|js|exe|dll|bat|sh)$/i', $path_info['filename'])) {
            throw new Exception("Invalid filename. Dangerous extension detected.");
        }

        if (!getimagesize($file_tmp)) {
            throw new Exception("Uploaded file is not a valid image.");
        }

        $max_size = 2 * 1024 * 1024;
        if ($file_size > $max_size) {
            throw new Exception("Image size must be less than 2MB.");
        }

        $new_file_name = uniqid($prefix) . '.' . $file_ext;
        $destination = $upload_dir . $new_file_name;
        // $destination = str_replace(['../', '..\\'], '', $destination);

        $src = fopen($file_tmp, 'rb');
        $dst = fopen($destination, 'wb');

        if (!$src || !$dst) {
            throw new Exception("Invalid image dimension or invalid image type. {$destination}");
        }

        while (!feof($src)) {
            fwrite($dst, fread($src, 8192));
        }

        fclose($src);
        fclose($dst);

        if (!getimagesize($destination)) {
            unlink($destination);
            throw new Exception("Uploaded file became invalid after moving.");
        }

        return $new_file_name;
    }

    // Validate required fields
    $required = [
        'student_id',
        'name',
        'father_name',
        'class_id',
        'section_id',
        'phone_number',
        'admission_date',
        'academic_year',
        'gender',
        'date_of_birth',
        'status'
    ];

    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            throw new Exception("All required fields must be filled");
        }
    }

    // Sanitize inputs
    $student_id                   = clean($_POST['student_id']);
    $name                         = clean($_POST['name']);
    $father_name                  = clean($_POST['father_name']);
    $mother_name                  = clean($_POST['mother_name'] ?? '');
    $father_occupation            = clean($_POST['father_occupation'] ?? '');
    $mother_occupation            = clean($_POST['mother_occupation'] ?? '');
    $class_id                     = (int)$_POST['class_id'];
    $section_id                   = (int)$_POST['section_id'];
    $roll_no                      = $_POST['roll_no'] ?? null;
    $phone_number                 = clean($_POST['phone_number']);
    $alternate_phone_number       = clean($_POST['alternate_phone_number']);
    $email                        = sanitize_input($_POST['email']);
    $religion                     = sanitize_input($_POST['religion']);
    $registration_no              = sanitize_input($_POST['registration_no']);
    $admission_date               = $_POST['admission_date'];
    $academic_year                = clean($_POST['academic_year']);
    $gender                       = clean($_POST['gender']);
    $date_of_birth                = $_POST['date_of_birth'];
    $status                       = clean($_POST['status']);
    $blood_group                  = clean($_POST['blood_group'] ?? '');
    $is_hosteler                  = isset($_POST['is_hosteler']) ? (int)$_POST['is_hosteler'] : 0;
    $driving_route_id             = clean($_POST['driving_route'] ?? '');
    $hostel_fee                   = clean($_POST['hostel_fee'] ?? 0);
    $car_fee                      = clean($_POST['car_fee'] ?? 0);
    $driver_id                    = clean($_POST['driver_id'] ?? '');
    $custom_class_fee             = clean($_POST['custom_class_fee'] ?? 0);
    $current_image                = $_POST['current_image'] ?? '';
    $village                      = clean($_POST['village'] ?? '');
    $post_office                  = clean($_POST['post_office'] ?? '');
    $police_station               = clean($_POST['police_station'] ?? '');
    $district                     = clean($_POST['district'] ?? '');
    $pin_code                     = clean($_POST['pin_code'] ?? '');
    $student_adhaar_no            = clean($_POST['student_adhaar'] ?? '');
    $father_adhaar_no             = clean($_POST['father_adhaar'] ?? '');
    $mother_adhaar_no             = clean($_POST['mother_adhaar'] ?? '');
    
    // Building full address
    $address = "{$village}, {$post_office}, {$police_station}, {$district}, {$pin_code}";

    $temp_address_var = trim(str_replace(",", "", $address));

    if (empty($temp_address_var)) {
        $address = null;
    }

    // if student left school then release roll number
    if (strtolower($status) == 'left') {
        $roll_no = null;
    }

    if (!empty($roll_no) && !is_numeric($roll_no)) {
        throw new Exception("Roll number must be numeric.");
    }

    // Validate driving route and driver id
    if (!empty($driving_route_id)) {
        if (is_numeric($driving_route_id)) {
            // Check if driving route exists
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM driving_routes WHERE id = ?");
            $stmt->execute([$driving_route_id]);
            if ($stmt->fetchColumn() == 0) {
                throw new Exception("Selected driving route does not exist.");
            }
        } else {
            throw new Exception("Invalid driving route selected.");
        }
    }

    if (!empty($driver_id)) {
        if (is_numeric($driver_id)) {
            // Check if driver exists and is associated with the selected route
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM drivers WHERE id = ? AND route_id = ?");
            $stmt->execute([$driver_id, $driving_route_id]);
            if ($stmt->fetchColumn() == 0) {
                throw new Exception("Selected driver does not exist or is not associated with the selected route.");
            }
        } else {
            throw new Exception("Invalid driver selected.");
        }
    }

    // Validate phone number
    if (!isValidPhoneNumber($phone_number)) {
        throw new Exception("Invalid phone number format. It should be 10 digits.");
    }

    // Validate alternate phone number
    if (!empty($alternate_phone_number)) {
        if (!isValidPhoneNumber($alternate_phone_number)) {
            throw new Exception("Invalid alternate phone number format. It should be 10 digits.");
        }
    }

    $student_image = $current_image;

    // Handle image upload - prioritize cropped image if available
    if (!empty($_POST['cropped_image_data'])) {

        $cropped_image = saveBase64Image($_POST['cropped_image_data'], $upload_dir);

        if ($cropped_image) {
            // Delete old image if exists and not default
            if (
                !empty($student_image) && $student_image !== 'default_student_dp.jpg' &&
                file_exists($upload_dir . $student_image)
            ) {
                unlink($upload_dir . $student_image);
            }
            $student_image = $cropped_image;
        } else {
            throw new Exception("Failed to save cropped image.");
        }
    }
    // Handle regular file upload
    elseif (isset($_FILES['student_image']) && $_FILES['student_image']['size'] > 0) {
        
        $new_image = saveUploadedImage($_FILES['student_image'], $upload_dir);

        // Additional ratio check for non-cropped images
        $image_full_path = $upload_dir . $new_image;
        list($width, $height) = getimagesize($image_full_path);

        $ratio = getRatioArray($width, $height);
        if ($ratio === null) {
            unlink($image_full_path);
            throw new Exception("Invalid image dimensions.");
        }

        $width_ratio = $ratio[0];
        $height_ratio = $ratio[1];

        if ($width_ratio !== 5 || $height_ratio !== 6) {
            unlink($image_full_path);
            throw new Exception("Image must be in a 5:6 ratio. Current ratio: {$width_ratio}:{$height_ratio}");
        }

        // Delete old image if exists and not default
        if (
            !empty($student_image) && $student_image !== 'default_student_dp.jpg' &&
            file_exists($upload_dir . $student_image)
        ) {
            unlink($upload_dir . $student_image);
        }
        $student_image = $new_image;
    }

    // Check for duplicate roll number
    $checkStmt = $pdo->prepare("
        SELECT COUNT(*) FROM students 
        WHERE class_id = :class_id 
        AND section_id = :section_id 
        AND roll_no = :roll_no
        AND student_id != :student_id
    ");
    $checkStmt->execute([
        ':class_id' => $class_id,
        ':section_id' => $section_id,
        ':roll_no' => $roll_no,
        ':student_id' => $student_id
    ]);

    if ($checkStmt->fetchColumn() > 0) {
        throw new Exception("Roll number already exists in this class and section");
    }

    // Update student record
    $stmt = $pdo->prepare("
        UPDATE students SET 
            name = :name,
            father_name = :father_name,
            mother_name = :mother_name,
            father_occupation = :father_occupation,
            mother_occupation = :mother_occupation,
            address = :address,
            class_id = :class_id,
            section_id = :section_id,
            roll_no = :roll_no,
            phone_number = :phone_number,
            alternate_phone_number = :alternate_phone_number,
            email = :email,
            religion = :religion,
            registration_no = :registration_no,
            admission_date = :admission_date,
            academic_year = :academic_year,
            gender = :gender,
            date_of_birth = :date_of_birth,
            status = :status,
            student_image = :student_image,
            blood_group = :blood_group,
            is_hosteler = :is_hosteler,
            driving_route_id = :driving_route_id,
            hostel_fee = :hostel_fee,
            car_fee = :car_fee,
            driver_id = :driver_id,
            custom_class_fee = :custom_class_fee,
            village = :village,
            post_office = :post_office,
            police_station = :police_station,
            district = :district,
            pin_code = :pin_code,
            student_adhaar_no = :student_adhaar_no,
            father_adhaar_no = :father_adhaar_no,
            mother_adhaar_no = :mother_adhaar_no,
            updated_at = NOW()
        WHERE student_id = :student_id
    ");

    $stmt->execute([
        ':name' => $name,
        ':father_name' => $father_name,
        ':mother_name' => $mother_name,
        ':father_occupation' => $father_occupation,
        ':mother_occupation' => $mother_occupation,
        ':address' => $address,
        ':class_id' => $class_id,
        ':section_id' => $section_id,
        ':roll_no' => $roll_no,
        ':phone_number' => $phone_number,
        ':alternate_phone_number' => $alternate_phone_number,
        ':email' => $email,
        ':religion' => $religion,
        ':registration_no' => $registration_no,
        ':admission_date' => $admission_date,
        ':academic_year' => $academic_year,
        ':gender' => $gender,
        ':date_of_birth' => $date_of_birth,
        ':status' => $status,
        ':student_image' => $student_image,
        ':blood_group' => $blood_group,
        ':is_hosteler' => $is_hosteler,
        ':driving_route_id' => $driving_route_id,
        ':hostel_fee' => $hostel_fee,
        ':car_fee' => $car_fee,
        ':driver_id' => $driver_id,
        ':custom_class_fee' => $custom_class_fee,
        ':village' => $village,
        ':post_office' => $post_office,
        ':police_station' => $police_station,
        ':district'  => $district,
        ':pin_code' => $pin_code,
        ':student_adhaar_no' => $student_adhaar_no,
        ':father_adhaar_no' => $father_adhaar_no,
        ':mother_adhaar_no' => $mother_adhaar_no,
        ':student_id' => $student_id
    ]);

    $response['success'] = true;
    $response['message'] = "Student updated successfully!";

    // Insert admission fee record if applicable
    $admission_fee_entry = fun_admission_fees_entry(
        $pdo, 
        $student_id, 
        $academic_year, 
        $class_id, 
        0
    );

    // Append admission fee entry result to response message
    if ($admission_fee_entry['success']) {
        $admission_fee_entry_message = "";

        foreach ($admission_fee_entry['results'] as $fee_result) {
            $admission_fee_entry_message .= " " . $fee_result['message'];
        }

        $response['message'] .= " " . $admission_fee_entry_message;
    } else {
        $response['message'] .= " However, Admission fee entry failed: " . $admission_fee_entry['message'];
    }

} catch (PDOException $e) {
    $response['message'] = "Database error: " . $e->getMessage();
    error_log("PDOException: " . $e->getMessage());
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

ob_end_clean();
echo json_encode($response);
exit();
