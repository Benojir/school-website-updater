<?php
/** @var PDO $pdo */
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check authentication
$auth = authenticateAdminApiRequest($pdo);

// Check student attendance permission
if (!hasPermission(PERM_MANAGE_STUDENTS_ATTENDANCE)) {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to manage student attendance.'
    ]);
    exit;
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Method Not Allowed. POST request required.');
    }

    // Read payload from JSON body or POST variables
    $rawInput = file_get_contents('php://input');
    $inputData = json_decode($rawInput, true);

    if (empty($inputData) && !empty($_POST)) {
        $inputData = $_POST;
    }

    if (empty($inputData)) {
        throw new Exception('No data received or invalid request format.');
    }

    $action = trim($inputData['action'] ?? '');
    if (!in_array($action, ['present', 'absent', 'leave'], true)) {
        throw new Exception('Invalid attendance action specified.');
    }

    // Parse student IDs
    $rawStudentIds = $inputData['student_ids'] ?? [];
    if (is_string($rawStudentIds)) {
        $studentIds = array_filter(array_map('trim', explode(',', $rawStudentIds)));
    } elseif (is_array($rawStudentIds)) {
        $studentIds = array_filter(array_map('trim', $rawStudentIds));
    } else {
        $studentIds = [];
    }

    if (empty($studentIds)) {
        throw new Exception('Please select at least one student.');
    }

    // Parse dates
    $dates = [];
    if (!empty($inputData['dates']) && is_array($inputData['dates'])) {
        foreach ($inputData['dates'] as $d) {
            $dClean = trim($d);
            if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $dClean)) {
                $dates[] = $dClean;
            }
        }
    } elseif (!empty($inputData['datetimes']) && is_array($inputData['datetimes'])) {
        foreach ($inputData['datetimes'] as $dt) {
            $dtClean = trim($dt);
            $extractedDate = substr($dtClean, 0, 10);
            if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $extractedDate)) {
                $dates[] = $extractedDate;
            }
        }
    } elseif (!empty($inputData['date']) && is_string($inputData['date'])) {
        $dClean = trim($inputData['date']);
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $dClean)) {
            $dates[] = $dClean;
        }
    }

    $dates = array_unique($dates);

    if (empty($dates)) {
        throw new Exception('Please select at least one valid date for attendance.');
    }

    // Parse & format time
    $rawTime = trim($inputData['time'] ?? '');
    if (!empty($rawTime)) {
        // Normalize time (e.g., "09:30" or "09:30:00")
        if (preg_match('/^\d{1,2}:\d{2}(:\d{2})?$/', $rawTime)) {
            $timeFormatted = date('H:i:s', strtotime($rawTime));
        } else {
            $timeFormatted = date('H:i:s');
        }
    } else {
        $timeFormatted = date('H:i:s');
    }

    // Begin database transaction
    $pdo->beginTransaction();

    // Prepare queries
    $studentStmt = $pdo->prepare("
        SELECT s.student_id, s.name, s.class_id, s.section_id, sec.id as valid_section_id
        FROM students s
        LEFT JOIN sections sec ON s.section_id = sec.id
        WHERE s.student_id = ?
        LIMIT 1
    ");
    $deleteStmt = $pdo->prepare("DELETE FROM student_attendance WHERE student_id = ? AND date = ?");
    $insertStmt = $pdo->prepare("INSERT INTO student_attendance (student_id, class_id, section_id, status, date, time, processed_by_teacher) VALUES (?, ?, ?, ?, ?, ?, NULL)");
    $checkLeaveStmt = $pdo->prepare("SELECT id, status FROM student_attendance WHERE student_id = ? AND date = ? ORDER BY id ASC LIMIT 1");

    // Fetch and validate students info
    $validStudents = [];
    $skippedStudents = [];

    foreach ($studentIds as $stuId) {
        $studentStmt->execute([$stuId]);
        $student = $studentStmt->fetch(PDO::FETCH_ASSOC);

        if (!$student) {
            $skippedStudents[] = [
                'id' => $stuId,
                'name' => 'Unknown',
                'reason' => 'Student record not found'
            ];
            continue;
        }

        $sectionId = !empty($student['section_id']) ? (int)$student['section_id'] : 0;
        $validSectionId = !empty($student['valid_section_id']) ? (int)$student['valid_section_id'] : 0;

        if ($sectionId <= 0 || $validSectionId <= 0) {
            $skippedStudents[] = [
                'id' => $stuId,
                'name' => $student['name'] ?? $stuId,
                'reason' => 'No section assigned (section assignment required)'
            ];
            continue;
        }

        $validStudents[$stuId] = [
            'name' => $student['name'] ?? $stuId,
            'class_id' => !empty($student['class_id']) ? (int)$student['class_id'] : 0,
            'section_id' => $validSectionId
        ];
    }

    if (empty($validStudents)) {
        $skippedCount = count($skippedStudents);
        $reasonMsg = $skippedCount === 1 
            ? "Student '{$skippedStudents[0]['name']}' does not have an assigned section. A section must be assigned before managing attendance." 
            : "None of the selected students have an assigned section. A section must be assigned to students before managing attendance.";
        throw new Exception($reasonMsg);
    }

    $totalDateProcessed = 0;
    $totalUpdatedRecords = 0;
    $totalInsertedRecords = 0;
    $todayDate = date('Y-m-d');
    $processedStudentIDsForNotification = [];
    $skippedLeaveStudents = [];

    foreach ($dates as $date) {
        $totalDateProcessed++;

        foreach ($validStudents as $stuId => $info) {
            $class_id = $info['class_id'];
            $section_id = $info['section_id'];

            if ($action === 'present' || $action === 'absent') {
                // Delete existing attendance on that date for this student
                $deleteStmt->execute([$stuId, $date]);
                $deletedCount = $deleteStmt->rowCount();

                // Insert the new status
                $insertStmt->execute([$stuId, $class_id, $section_id, $action, $date, $timeFormatted]);

                if ($deletedCount > 0) {
                    $totalUpdatedRecords++;
                } else {
                    $totalInsertedRecords++;
                }

                if ($action === 'present' && $date === $todayDate) {
                    $processedStudentIDsForNotification[] = $stuId;
                }
            } elseif ($action === 'leave') {
                // Check if existing record exists on this date
                $checkLeaveStmt->execute([$stuId, $date]);
                $existingRecord = $checkLeaveStmt->fetch(PDO::FETCH_ASSOC);

                if ($existingRecord && $existingRecord['status'] === 'present') {
                    // Student was present earlier, record early leave departure
                    $insertStmt->execute([$stuId, $class_id, $section_id, 'leave', $date, $timeFormatted]);
                    $totalInsertedRecords++;
                } else {
                    // Cannot mark leave without being present first
                    $skippedLeaveStudents[] = [
                        'id' => $stuId,
                        'name' => $info['name'],
                        'date' => date('d M Y', strtotime($date)),
                        'reason' => 'No present record found on this date'
                    ];
                }
            }
        }
    }

    // Commit transaction
    $pdo->commit();

    // Real-time Push Notification for students marked Present today
    if (!empty($processedStudentIDsForNotification)) {
        try {
            $uniquePresentStudentIds = array_unique($processedStudentIDsForNotification);
            $fcmTokens = getFCMTokensFromDatabase($pdo, $uniquePresentStudentIds);

            if (!empty($fcmTokens)) {
                $title = 'Your child attended class';
                $body = 'Your child has attended class on ' . $todayDate . ' at ' . date('h:i A', strtotime($timeFormatted));
                $notifData = ['title' => $title, 'message' => $body];
                sendFirebaseNotification($pdo, $uniquePresentStudentIds, $fcmTokens, $title, $body, $notifData, false);
            }
        } catch (Throwable $notifError) {
            // Push notification failure should not break the attendance submission
        }
    }

    $responseMsg = 'Attendance records processed successfully.';
    
    $totalSkipMessages = [];
    if (!empty($skippedStudents)) {
        $totalSkipMessages[] = count($skippedStudents) . ' student(s) skipped (No section)';
    }
    if (!empty($skippedLeaveStudents)) {
        $totalSkipMessages[] = count($skippedLeaveStudents) . ' leave action(s) skipped (Not present)';
    }

    if (!empty($totalSkipMessages)) {
        $responseMsg .= ' (Note: ' . implode(', ', $totalSkipMessages) . '.)';
    }

    echo json_encode([
        'success' => true,
        'message' => $responseMsg,
        'totalDateProcessed' => $totalDateProcessed,
        'totalStudentsProcessed' => count($validStudents),
        'totalUpdatedRecords' => $totalUpdatedRecords,
        'totalInsertedRecords' => $totalInsertedRecords,
        'totalSkipStudents' => count($skippedStudents) + count($skippedLeaveStudents),
        'skipped_students' => $skippedStudents,
        'skipped_leave_students' => $skippedLeaveStudents
    ]);

} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>
