<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_STUDENTS_ATTENDANCE)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'error' => true
    ]);
    die();
}

$pdo->beginTransaction();

try {
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);

    if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON data: ' . json_last_error_msg());
    }

    if (!$data) {
        throw new Exception('No data received or invalid JSON format');
    }

    // Validate input
    if (empty($data['action']) || empty($data['datetimes'])) {
        throw new Exception('Missing required fields');
    }

    $studentIds = isset($data['student_ids']) ? explode(',', $data['student_ids']) : [];
    $action = $data['action'];
    $datetimes = $data['datetimes'];

    // Validate action
    if (!in_array($action, ['present', 'absent', 'late', 'leave'])) {
        throw new Exception('Invalid action specified');
    }
    // Validate datetimes
    if (!is_array($datetimes) || empty($datetimes)) {
        throw new Exception('Invalid or empty datetimes provided');
    }
    // If student IDs are provided, validate them
    if (!empty($studentIds) && !is_array($studentIds)) {
        throw new Exception('Invalid student IDs provided');
    }

    // Process each datetime
    $totalProcessedDates = 0;
    $totalProcessedStudents = 0;
    $totalSkipDateRecords = 0;
    $totalSkipStudents = 0;
    $totalUpdatedRecords = 0;
    $totalInsertedRecords = 0;

    foreach ($datetimes as $datetime) {

        if (!isValidDate($datetime)) {
            $totalSkipDateRecords++;
            continue; // Skip invalid date
        }

        // Extract date portion only (without time)
        $dateOnly = substr($datetime, 0, 10);

        $totalProcessedDates++;

        foreach ($studentIds as $studentId) {
            if (empty($studentId)) {
                $totalSkipStudents++;
                continue; // Skip empty student ID
            }

            $stmt = $pdo->prepare("SELECT class_id, section_id FROM students WHERE student_id = ?");
            $stmt->execute([$studentId]);
            $student = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$student) {
                $totalSkipStudents++;
                continue; // Skip invalid student ID
            }
            $classId = $student['class_id'];
            $sectionId = $student['section_id'];

            // Check if record exists for this date (date only match)
            $checkStmt = $pdo->prepare("SELECT id FROM attendance WHERE student_id = ? AND DATE(time) = ? LIMIT 1");
            $checkStmt->execute([$studentId, $dateOnly]);
            $existingRecord = $checkStmt->fetch();

            if ($existingRecord) {
                $updateStmt = $pdo->prepare("UPDATE attendance SET status = ?, time = ? WHERE id = ?");
                $updateStmt->execute([$action, $datetime, $existingRecord['id']]);
                $totalUpdatedRecords++;
            } else {
                $insertStmt = $pdo->prepare("INSERT INTO attendance(student_id, class_id, section_id, status, time) VALUES (?, ?, ?, ?, ?)");
                $insertStmt->execute([$studentId, $classId, $sectionId, $action, $datetime]);
                $totalInsertedRecords++;
            }

            $totalProcessedStudents++;
        }
    }

    // Return success response
    echo json_encode([
        'success' => true,
        'message' => 'Attendance records saved successfully',
        'totalDateProcessed' => $totalProcessedDates,
        'totalStudentsProcessed' => $totalProcessedStudents,
        'totalSkipDateRecords' => $totalSkipDateRecords,
        'totalSkipStudents' => $totalSkipStudents,
        'totalUpdatedRecords' => $totalUpdatedRecords,
        'totalInsertedRecords' => $totalInsertedRecords
    ]);

    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

// Function to check if the provided date is valid
function isValidDate($date) {
    try {
        $d = DateTime::createFromFormat('Y-m-d H:i', $date);
        return $d && $d->format('Y-m-d H:i') === $date;
    } catch (Exception $e) {
        return false;
    }
}
