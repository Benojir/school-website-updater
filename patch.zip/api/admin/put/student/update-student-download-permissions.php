<?php
require_once __DIR__ . '/../../../../includes/auth-check.php';
require_once __DIR__ . '/../../../../includes/exam-document-access.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
authenticateAdminApiRequest($pdo);
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    http_response_code(403);
    exit(json_encode(['success' => false, 'message' => 'You do not have permission to manage student download access.']));
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); header('Allow: POST');
    exit(json_encode(['success' => false, 'message' => 'Please use POST to update permissions.']));
}
$csrf = $_POST['csrf_token'] ?? null;
if (!is_string($csrf) || empty($_SESSION['student_download_permissions_csrf'])
    || !hash_equals($_SESSION['student_download_permissions_csrf'], $csrf)) {
    http_response_code(403);
    exit(json_encode(['success' => false, 'message' => 'Your session expired. Reload the student list before saving.']));
}
try {
    $results = examDocumentSavePermissions($pdo, $_POST);
    $count = count($results);
    echo json_encode(['success' => true, 'message' => 'Download permissions saved for ' . $count . ' student(s).',
        'total_students' => $count, 'processed' => $count, 'skipped' => 0, 'results' => $results]);
} catch (InvalidArgumentException $error) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => $error->getMessage()]);
} catch (Throwable $error) {
    error_log('Save student download permissions: ' . $error->getMessage());
    http_response_code(503);
    echo json_encode(['success' => false, 'message' => 'Download permissions could not be saved. Please try again later.']);
}
