<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$uploadDir =  __DIR__ . '/../../../../uploads/school/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

$messages = [];
$successCount = 0;
$hasAttempt = false;

// 1. Process Square Logo
if (isset($_FILES['schoolLogo']) && $_FILES['schoolLogo']['error'] === UPLOAD_ERR_OK) {
    $hasAttempt = true;
    $targetSquareFile = $uploadDir . 'logo-square.png';
    $faviconFile = $uploadDir . 'favicon.png';
    
    $imageFileType = strtolower(pathinfo($_FILES['schoolLogo']['name'], PATHINFO_EXTENSION));
    
    if ($imageFileType != 'png') {
        echo json_encode(['success' => false, 'message' => 'Square Logo: Only PNG files are allowed']);
        exit();
    }
    if ($_FILES['schoolLogo']['size'] > 2 * 1024 * 1024) {
        echo json_encode(['success' => false, 'message' => 'Square Logo: File must be less than 2MB']);
        exit();
    }
    
    list($width, $height) = getimagesize($_FILES['schoolLogo']['tmp_name']);
    if ($width != 512 || $height != 512) {
        echo json_encode(['success' => false, 'message' => 'Square Logo must be exactly 512×512 pixels']);
        exit();
    }

    if (move_uploaded_file($_FILES['schoolLogo']['tmp_name'], $targetSquareFile)) {
        // Create favicon (48x48)
        try {
            $logo = imagecreatefrompng($targetSquareFile);
            $favicon = imagecreatetruecolor(48, 48);
            
            imagealphablending($favicon, false);
            imagesavealpha($favicon, true);
            $transparent = imagecolorallocatealpha($favicon, 0, 0, 0, 127);
            imagefill($favicon, 0, 0, $transparent);
            
            imagecopyresampled($favicon, $logo, 0, 0, 0, 0, 48, 48, $width, $height);
            imagepng($favicon, $faviconFile);
            
            imagedestroy($logo);
            imagedestroy($favicon);
            
            $messages[] = 'Square Logo & Favicon updated';
            $successCount++;
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error creating favicon: ' . $e->getMessage()]);
            exit();
        }
    }
}

// 2. Process Rectangle Logo
if (isset($_FILES['logoRectangle']) && $_FILES['logoRectangle']['error'] === UPLOAD_ERR_OK) {
    $hasAttempt = true;
    $targetRectFile = $uploadDir . 'logo-rectangle.png';
    
    $imageFileType = strtolower(pathinfo($_FILES['logoRectangle']['name'], PATHINFO_EXTENSION));
    
    if ($imageFileType != 'png') {
        echo json_encode(['success' => false, 'message' => 'Rectangle Logo: Only PNG files are allowed']);
        exit();
    }
    if ($_FILES['logoRectangle']['size'] > 2 * 1024 * 1024) {
        echo json_encode(['success' => false, 'message' => 'Rectangle Logo: File must be less than 2MB']);
        exit();
    }
    
    list($width, $height) = getimagesize($_FILES['logoRectangle']['tmp_name']);
    if ($width != 600 || $height != 170) {
        echo json_encode(['success' => false, 'message' => 'Rectangle Logo must be exactly 600×170 pixels']);
        exit();
    }

    if (move_uploaded_file($_FILES['logoRectangle']['tmp_name'], $targetRectFile)) {
        $messages[] = 'Rectangle Logo updated';
        $successCount++;
    } else {
        echo json_encode(['success' => false, 'message' => 'Error uploading rectangle logo file']);
        exit();
    }
}

// Final Response Check
if (!$hasAttempt) {
    echo json_encode(['success' => false, 'message' => 'No files were uploaded']);
    exit();
}

if ($successCount > 0) {
    echo json_encode([
        'success' => true,
        'message' => implode(' and ', $messages) . ' successfully'
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to process uploads']);
}
?>