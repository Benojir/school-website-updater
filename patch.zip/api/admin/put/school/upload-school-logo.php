<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

// Check if file was uploaded
if (!isset($_FILES['schoolLogo']) || $_FILES['schoolLogo']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'message' => 'No file uploaded or upload error']);
    exit();
}

$uploadDir =  __DIR__ . '/../../../../uploads/school/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

$targetFile = $uploadDir . 'logo-square.png';
$faviconFile = $uploadDir . 'favicon.png';

// Check file type
$imageFileType = strtolower(pathinfo($_FILES['schoolLogo']['name'], PATHINFO_EXTENSION));
if ($imageFileType != 'png') {
    echo json_encode(['success' => false, 'message' => 'Only PNG files are allowed']);
    exit();
}

// Check file size (2MB max)
if ($_FILES['schoolLogo']['size'] > 2 * 1024 * 1024) {
    echo json_encode(['success' => false, 'message' => 'Logo file must be less than 2MB']);
    exit();
}

// Check image dimensions (512x512)
list($width, $height) = getimagesize($_FILES['schoolLogo']['tmp_name']);
if ($width != 512 || $height != 512) {
    echo json_encode(['success' => false, 'message' => 'Logo must be exactly 512×512 pixels']);
    exit();
}

// Move uploaded file
if (!move_uploaded_file($_FILES['schoolLogo']['tmp_name'], $targetFile)) {
    echo json_encode(['success' => false, 'message' => 'Error uploading logo file']);
    exit();
}

// Create favicon (48x48)
try {
    $logo = imagecreatefrompng($targetFile);
    $favicon = imagecreatetruecolor(48, 48);
    
    // Preserve transparency
    imagealphablending($favicon, false);
    imagesavealpha($favicon, true);
    $transparent = imagecolorallocatealpha($favicon, 0, 0, 0, 127);
    imagefill($favicon, 0, 0, $transparent);
    
    // Resize
    imagecopyresampled($favicon, $logo, 0, 0, 0, 0, 48, 48, $width, $height);
    
    // Save favicon
    imagepng($favicon, $faviconFile);
    
    // Free memory
    imagedestroy($logo);
    imagedestroy($favicon);
    
    echo json_encode([
        'success' => true,
        'message' => 'Logo and favicon updated successfully'
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error creating favicon: ' . $e->getMessage()
    ]);
}
?>