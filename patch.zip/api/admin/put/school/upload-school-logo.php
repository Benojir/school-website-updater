<?php
include_once(__DIR__ . '/../../../../includes/auth-check.php');
require_once(__DIR__ . '/../../../../includes/school-logo-image.php');
header('Content-Type: application/json');

if (!isSuperAdmin()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Please submit the logo upload form.']);
    exit;
}

try {
    $files = [];
    $messages = [];
    // Validate and encode both images before replacing any existing assets.
    foreach (['schoolLogo' => 'logo-square.png', 'logoRectangle' => 'logo-rectangle.png'] as $field => $filename) {
        if (!isset($_FILES[$field]) || $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        $upload = $_FILES[$field];
        if ($upload['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($upload['tmp_name'])) {
            throw new InvalidArgumentException(schoolLogoRules($field)['label'] . ': Upload failed. Please select the image again (max 2MB).');
        }
        $rawCrop = $_POST[$field . 'Crop'] ?? '';
        $crop = is_string($rawCrop) ? json_decode($rawCrop, true) : null;
        $images = schoolLogoCrop($upload['tmp_name'], $field, $crop);
        $files[$filename] = $images['logo'];
        if (isset($images['favicon'])) {
            $files['favicon.png'] = $images['favicon'];
        }
        $messages[] = $field === 'schoolLogo' ? 'Square logo & favicon' : 'Rectangle logo';
    }
    if (!$files) {
        throw new InvalidArgumentException('Please select and crop at least one logo (max 2MB).');
    }
    $uploadDir = __DIR__ . '/../../../../uploads/school/';
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true)) {
        throw new RuntimeException('Cannot create logo directory.');
    }
    foreach ($files as $filename => $bytes) {
        if (file_put_contents($uploadDir . $filename, $bytes, LOCK_EX) !== strlen($bytes)) {
            throw new RuntimeException('Cannot save logo file.');
        }
    }
    echo json_encode(['success' => true, 'message' => implode(' and ', $messages) . ' updated successfully']);
} catch (InvalidArgumentException $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} catch (Throwable $e) {
    error_log('School logo upload: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Unable to save the logo. Please try again or check the upload folder permissions.']);
}
