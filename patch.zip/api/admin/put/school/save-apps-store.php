<?php
header('Content-Type: application/json');

include_once(__DIR__ . "/../../../../includes/auth-check.php");

// Superadmin চেক
if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit;
}

// POST ডেটা কালেক্ট করা
$parent_app_link = trim($_POST['parent_app_link'] ?? '');
$teacher_app_link = trim($_POST['teacher_app_link'] ?? $_POST['student_attendance_app_link'] ?? '');
$driver_app_link = trim($_POST['driver_app_link'] ?? '');

// বেসিক ভ্যালিডেশন
if (empty($parent_app_link) || empty($teacher_app_link) || empty($driver_app_link)) {
    echo json_encode(['success' => false, 'message' => 'Please provide all app links.']);
    exit;
}

// JSON স্টোর করার জন্য অ্যাসোসিয়েটিভ অ্যারে তৈরি করা
$apps_data = [
    'parent_app_link' => $parent_app_link,
    'teacher_app_link' => $teacher_app_link,
    'driver_app_link' => $driver_app_link
];

// Array কে JSON স্ট্রিং এ রূপান্তর করা (URL-এ যাতে স্ল্যাশ এস্কেপ না হয় সেজন্য JSON_UNESCAPED_SLASHES ব্যবহার করা হয়েছে)
$json_apps_link = json_encode($apps_data, JSON_UNESCAPED_SLASHES);

try {
    // শুধু Update Query চালানো হচ্ছে
    // আপনার যদি মাল্টিপল স্কুল থাকে, তবে WHERE id = :school_id ব্যবহার করতে হবে
    $sql = "UPDATE school_information SET apps_link = :apps_link";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':apps_link', $json_apps_link, PDO::PARAM_STR);

    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'Apps links updated successfully.'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to update apps links.'
        ]);
    }
} catch (PDOException $e) {
    // প্রোডাকশনে এরর মেসেজ হাইড রাখতে চাইলে শুধু 'Database error occurred' দিতে পারেন
    echo json_encode([
        'success' => false,
        'message' => 'Database Error: ' . $e->getMessage()
    ]);
}
