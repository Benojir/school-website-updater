<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['user']['role'] !== 'superadmin') {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

// Validate all required fields
$requiredFields = [
    'name', 
    'address', 
    'phone', 
    'email', 
    'principal_name', 
    'principal_phone', 
    'principal_email',
    'established_year', 
    'school_website_address',
    'google_map_link', 
    'app_download_link',
    'description', 
    'meta_description', 
    'meta_keywords', 
    'facebook', 
    'youtube', 
    'instagram', 
    'whatsapp'
];

foreach ($requiredFields as $field) {
    if (empty($_POST[$field])) {
        echo json_encode(['success' => false, 'message' => "All fields are required"]);
        exit();
    }
}

// Sanitize input
$data = [
    'name' => safe_htmlspecialchars(trim($_POST['name'])),
    'address' => safe_htmlspecialchars(trim($_POST['address'])),
    'phone' => safe_htmlspecialchars(trim($_POST['phone'])),
    'email' => safe_htmlspecialchars(trim($_POST['email'])),
    'principal_name' => safe_htmlspecialchars(trim($_POST['principal_name'])),
    'principal_phone' => safe_htmlspecialchars(trim($_POST['principal_phone'])),
    'principal_email' => safe_htmlspecialchars(trim($_POST['principal_email'])),
    'established_year' => safe_htmlspecialchars(trim($_POST['established_year'])),
    'school_website_address' => safe_htmlspecialchars(trim($_POST['school_website_address'])),
    'google_map_link' => safe_htmlspecialchars(trim($_POST['google_map_link'])),
    'app_download_link' => safe_htmlspecialchars(trim($_POST['app_download_link'])),
    'description' => safe_htmlspecialchars(trim($_POST['description'])),
    'meta_description' => safe_htmlspecialchars(trim($_POST['meta_description'])),
    'meta_keywords' => safe_htmlspecialchars(trim($_POST['meta_keywords'])),
    'facebook' => safe_htmlspecialchars(trim($_POST['facebook'])),
    'youtube' => safe_htmlspecialchars(trim($_POST['youtube'])),
    'instagram' => safe_htmlspecialchars(trim($_POST['instagram'])),
    'whatsapp' => safe_htmlspecialchars(trim($_POST['whatsapp']))
];

// Handle signature upload with enhanced security
$signatureUpdated = false;
if (isset($_FILES['principal_signature']) && $_FILES['principal_signature']['error'] === UPLOAD_ERR_OK) {
    $uploadDir =  __DIR__ . '/../../../../uploads/school/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    $targetFile = $uploadDir . 'principle_sign.png';
    
    // Enhanced security checks
    try {
        // Check if file is actually an image
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($_FILES['principal_signature']['tmp_name']);
        
        // Only allow PNG mime types
        if (!in_array($mime, ['image/png', 'image/x-png'])) {
            throw new Exception('Only PNG files are allowed for signature');
        }
        
        // Check file extension
        $ext = pathinfo($_FILES['principal_signature']['name'], PATHINFO_EXTENSION);
        if (strtolower($ext) !== 'png') {
            throw new Exception('File extension must be .png');
        }
        
        // Check file size (2MB max)
        if ($_FILES['principal_signature']['size'] > 2 * 1024 * 1024) {
            throw new Exception('Signature file must be less than 2MB');
        }
        
        // Verify image dimensions and ratio
        $imageInfo = getimagesize($_FILES['principal_signature']['tmp_name']);
        if ($imageInfo === false) {
            throw new Exception('Invalid image file');
        }
        
        $width = $imageInfo[0];
        $height = $imageInfo[1];
        $ratio = $width / $height;
        
        // Allow small deviation from 2:1 ratio since we'll crop it
        if ($ratio < 1.8 || $ratio > 2.2) {
            throw new Exception('Signature must be close to 2:1 width to height ratio');
        }
        
        // Create image from file
        $image = imagecreatefrompng($_FILES['principal_signature']['tmp_name']);
        if ($image === false) {
            throw new Exception('Failed to process PNG image');
        }
        
        // Calculate crop dimensions for 2:1 ratio
        $targetRatio = 2;
        $newWidth = $width;
        $newHeight = $height;
        
        if ($width / $height > $targetRatio) {
            $newWidth = $height * $targetRatio;
        } else {
            $newHeight = $width / $targetRatio;
        }
        
        $x = ($width - $newWidth) / 2;
        $y = ($height - $newHeight) / 2;
        
        // Create new image with correct ratio
        $croppedImage = imagecrop($image, [
            'x' => $x,
            'y' => $y,
            'width' => $newWidth,
            'height' => $newHeight
        ]);
        
        if ($croppedImage === false) {
            throw new Exception('Failed to crop image to 2:1 ratio');
        }
        
        // Save the cropped image
        if (!imagepng($croppedImage, $targetFile, 9)) { // Maximum compression
            throw new Exception('Failed to save cropped image');
        }
        
        // Free memory
        imagedestroy($image);
        imagedestroy($croppedImage);
        
        $signatureUpdated = true;
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        exit();
    }
}

try {
    // Check if school info already exists
    $stmt = $pdo->query("SELECT id FROM school_information LIMIT 1");
    $existingInfo = $stmt->fetch();

    if ($existingInfo) {
        // Update existing record
        $sql = "UPDATE school_information SET 
            name = :name,
            address = :address,
            phone = :phone,
            email = :email,
            principal_name = :principal_name,
            principal_phone = :principal_phone,
            principal_email = :principal_email,
            established_year = :established_year,
            school_website_address = :school_website_address,
            google_map_link = :google_map_link,
            app_download_link = :app_download_link,
            description = :description,
            meta_description = :meta_description,
            meta_keywords = :meta_keywords,
            facebook = :facebook,
            youtube = :youtube,
            instagram = :instagram,
            whatsapp = :whatsapp
            WHERE id = :id";
        
        $data['id'] = $existingInfo['id'];
    } else {
        // Insert new record
        $sql = "INSERT INTO school_information 
            (name, address, phone, email, principal_name, principal_phone, principal_email,
            established_year, school_website_address, google_map_link, app_download_link, description, meta_description, meta_keywords,
            facebook, youtube, instagram, whatsapp)
            VALUES 
            (:name, :address, :phone, :email, :principal_name, :principal_phone, :principal_email,
            :established_year, :school_website_address, :google_map_link, :app_download_link, :description, :meta_description, :meta_keywords,
            :facebook, :youtube, :instagram, :whatsapp)";
    }

    $stmt = $pdo->prepare($sql);
    $success = $stmt->execute($data);

    if ($success) {
        echo json_encode([
            'success' => true, 
            'message' => 'School information saved successfully',
            'signature_updated' => $signatureUpdated
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to save school information']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>