<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to manage transport
// You might need to define PERM_MANAGE_TRANSPORT in your permission system
if (!hasPermission('PERM_MANAGE_TRANSPORT')) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$driving_route = sanitize_input($_REQUEST['driving_route'] ?? '');

if (empty($driving_route)) {
    echo json_encode([
        'success' => false,
        'message' => 'Please enter a driving route name.'
    ]);
    die();
}

$check = $pdo->prepare("SELECT * FROM driving_routes WHERE route_name = :route_name");
$check->execute(['route_name' => $driving_route]);
if ($check->rowCount() > 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Driving route already exists.'
    ]);
    die();
}

$stmt = $pdo->prepare("INSERT INTO driving_routes (route_name) VALUES (:route_name)");
$stmt->execute(['route_name' => $driving_route]);

echo json_encode([
    'success' => true,
    'message' => 'Driving route added successfully.'
]);