<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

// Set header to JSON.
header('Content-Type: application/json');

// Check for appropriate permissions.
if (!hasPermission('PERM_MANAGE_TRANSPORT')) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        // Sanitize and retrieve POST data.
        $id = (int)$_POST['id'];
        $name = sanitize_input($_POST['name'] ?? '');
        $email = strtolower(sanitize_input($_POST['email'] ?? ''));
        $phone = sanitize_input($_POST['phone'] ?? '');
        $serial_number = sanitize_input($_POST['serial_number'] ?? '');
        $vehicle_number = sanitize_input($_POST['vehicle_number'] ?? '');
        $route_ids = $_POST['routes'] ?? []; // Receiving as Array
        $status = sanitize_input($_POST['status'] ?? '');
        $aadhaar_number = sanitize_input($_POST['aadhaar_number'] ?? '');
        $village = sanitize_input($_POST['village'] ?? '');
        $post_office = sanitize_input($_POST['post_office'] ?? '');
        $police_station = sanitize_input($_POST['police_station'] ?? '');
        $district = sanitize_input($_POST['district'] ?? '');
        $pincode = sanitize_input($_POST['pincode'] ?? '');
        $remove_photo = isset($_POST['remove_photo']) && $_POST['remove_photo'] == 'on';

        // Set optional fields to null if empty
        if (empty($email)) {
            $email = null;
        }
        if (empty($vehicle_number)) {
            $vehicle_number = null;
        }

        // Validate required fields.
        if (empty($name) || empty($phone) || empty($serial_number) || empty($route_ids) || empty($status)) {
            throw new Exception('All * marked fields are mandatory.');
        }

        if (!is_array($route_ids)) {
            throw new Exception('Please select at least one route.');
        }

        // Convert routes array to JSON
        $route_ids_json = json_encode($route_ids);

        // Check for duplicates correctly handling NULLs
        $sql = "SELECT name FROM drivers WHERE (phone = ? OR serial_number = ?";
        $params = [$phone, $serial_number];

        if ($email !== null) {
            $sql .= " OR email = ?";
            $params[] = $email;
        }

        if ($vehicle_number !== null) {
            $sql .= " OR vehicle_number = ?";
            $params[] = strtoupper($vehicle_number);
        }

        $sql .= ") AND id != ? LIMIT 1";
        $params[] = $id;

        $checkDuplicate = $pdo->prepare($sql);
        $checkDuplicate->execute($params);

        if ($checkDuplicate->rowCount() > 0) {
            $duplicate = $checkDuplicate->fetch(PDO::FETCH_ASSOC);
            throw new Exception("Email, Phone Number, Serial Number or Vehicle Number is already in use by {$duplicate['name']}.");
        }

        // Get current photo info to manage file deletion later if needed.
        $stmt = $pdo->prepare("SELECT driver_image FROM drivers WHERE id = ?");
        $stmt->execute([$id]);
        $currentDriver = $stmt->fetch(PDO::FETCH_ASSOC);
        $photo = $currentDriver['driver_image'];

        // Handle image update logic.
        if ($remove_photo) {
            if ($photo && $photo !== 'default_driver_dp.jpg' && file_exists(__DIR__ . '/../../../../uploads/drivers/' . $photo)) {
                unlink(__DIR__ . '/../../../../uploads/drivers/' . $photo);
            }
            $photo = 'default_driver_dp.jpg'; // Set to default image.
        } elseif (!empty($_FILES['cropped_image']['tmp_name'])) {
            $imageFile = $_FILES['cropped_image']['tmp_name'];
            $imageInfo = @getimagesize($imageFile);
            if ($imageInfo === false) {
                throw new Exception('The uploaded file is not a valid image.');
            }

            if (!isValidImageFile($imageFile)) {
                throw new Exception('The uploaded file is not a valid image.');
            }

            $ext = pathinfo($_FILES['cropped_image']['name'], PATHINFO_EXTENSION) ?: 'jpg';
            $photo = uniqid('drv_') . '.' . $ext;
            
            $uploadDir = __DIR__ . '/../../../../uploads/drivers/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            $destination = $uploadDir . $photo;

            if (!move_uploaded_file($imageFile, $destination)) {
                throw new Exception('Failed to upload new image.');
            }
        }

        // Prepare and execute the UPDATE statement.
        $stmt = $pdo->prepare("
            UPDATE drivers SET
                name = ?,
                email = ?,
                phone = ?,
                serial_number = ?,
                vehicle_number = ?,
                route_ids = ?,
                aadhaar_number = ?,
                status = ?,
                village = ?,
                post_office = ?,
                police_station = ?,
                district = ?,
                pincode = ?,
                driver_image = ?
            WHERE id = ?
        ");

        $stmt->execute([
            $name,
            $email,
            $phone,
            $serial_number,
            $vehicle_number,
            $route_ids_json,
            $aadhaar_number,
            $status,
            $village,
            $post_office,
            $police_station,
            $district,
            $pincode,
            $photo,
            $id
        ]);

        $response['success'] = true;
        $response['message'] = 'Driver details updated successfully';
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);