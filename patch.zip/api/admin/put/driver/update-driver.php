<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

// Set header to JSON.
header('Content-Type: application/json');

// Check for appropriate permissions.
if (!hasPermission('PERM_MANAGE_TRANSPORT')) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        // Sanitize and retrieve POST data.
        $id = (int)$_POST['id'];
        $name = sanitize_input($_POST['name'] ?? '');
        $email = sanitize_input($_POST['email'] ?? '');
        $phone = sanitize_input($_POST['phone'] ?? '');
        $serial_number = sanitize_input($_POST['serial_number'] ?? '');
        $vehicle_number = sanitize_input($_POST['vehicle_number'] ?? '');
        $route_id = sanitize_input($_POST['route'] ?? '');
        $status = sanitize_input($_POST['status'] ?? '');
        $aadhaar_number = sanitize_input($_POST['aadhaar_number'] ?? '');
        $village = sanitize_input($_POST['village'] ?? '');
        $post_office = sanitize_input($_POST['post_office'] ?? '');
        $police_station = sanitize_input($_POST['police_station'] ?? '');
        $district = sanitize_input($_POST['district'] ?? '');
        $pincode = sanitize_input($_POST['pincode'] ?? '');
        $remove_photo = isset($_POST['remove_photo']) && $_POST['remove_photo'] == 'on';

        // Validate required fields.
        if (empty($name) || empty($email) || empty($phone) || empty($serial_number) || empty($route_id) || empty($status)) {
            throw new Exception('All * marked fields are mandatory.');
        }

        // Validate route_id is an integer.
        if (!ctype_digit($route_id)) {
            throw new Exception('Invalid route selected.');
        }

        // Format data.
        $name = ucwords(strtolower($name));
        $vehicle_number = strtoupper($vehicle_number);

        // Check for duplicate email, phone, or vehicle number for another driver.
        $checkDuplicate = $pdo->prepare("SELECT id FROM drivers WHERE (email = ? OR phone = ? OR vehicle_number = ?) AND id != ?");
        $checkDuplicate->execute([$email, $phone, $vehicle_number, $id]);
        if ($checkDuplicate->rowCount() > 0) {
            throw new Exception('Email, Phone Number, or Vehicle Number is already in use by another driver.');
        }

        // Get current photo info to manage file deletion later if needed.
        $stmt = $pdo->prepare("SELECT driver_image FROM drivers WHERE id = ?");
        $stmt->execute([$id]);
        $currentDriver = $stmt->fetch(PDO::FETCH_ASSOC);
        $photo = $currentDriver['driver_image'];

        // Handle image update logic.
        if ($remove_photo) {
            if ($photo && $photo !== 'default_driver_dp.jpg' && file_exists(__DIR__ . '/../../../../uploads/drivers/' . $photo)) {
                unlink(__DIR__ . '/../../../../uploads/drivers/' . $photo);
            }
            $photo = 'default_driver_dp.jpg'; // Set to default image.
        } elseif (!empty($_FILES['cropped_image']['tmp_name'])) {
            $imageFile = $_FILES['cropped_image']['tmp_name'];
            $imageInfo = @getimagesize($imageFile);
            if ($imageInfo === false) {
                throw new Exception('The uploaded file is not a valid image.');
            }

            $ext = pathinfo($_FILES['cropped_image']['name'], PATHINFO_EXTENSION) ?: 'jpg';
            $photo = uniqid('drv_') . '.' . $ext;
            $destination =  __DIR__ . '/../../../../uploads/drivers/' . $photo;

            if (!move_uploaded_file($imageFile, $destination)) {
                throw new Exception('Failed to upload new image.');
            }
        }

        // Prepare and execute the UPDATE statement.
        // Prepare the UPDATE statement with the new fields
        $stmt = $pdo->prepare("
            UPDATE drivers SET
                name = ?,
                email = ?,
                phone = ?,
                serial_number = ?,
                vehicle_number = ?,
                route_id = ?,
                aadhaar_number = ?,
                status = ?,
                village = ?,
                post_office = ?,
                police_station = ?,
                district = ?,
                pincode = ?,
                driver_image = ?
            WHERE id = ?
        ");

        // Execute with the corresponding variables in the exact order
        $stmt->execute([
            $name,
            $email,
            $phone,
            $serial_number,
            $vehicle_number,
            $route_id,
            $aadhaar_number,
            $status,
            $village,
            $post_office,
            $police_station,
            $district,
            $pincode,
            $photo,
            $id
        ]);

        $response['success'] = true;
        $response['message'] = 'Driver details updated successfully';
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
