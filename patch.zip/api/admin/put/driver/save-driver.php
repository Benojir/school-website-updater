<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

// Needed for uploadDocumentToImgBB()
include_once(__DIR__ . "/../../../../includes/imgbb-upload.php");

header('Content-Type: application/json');

// Check if user has permission to manage transport
// You might need to define PERM_MANAGE_TRANSPORT in your permission system
if (!hasPermission(PERM_MANAGE_TRANSPORT))  {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        $driver_name = safe_htmlspecialchars(trim($_POST['driver_name'] ?? ''));
        $driver_email = strtolower(safe_htmlspecialchars(trim($_POST['driver_email'] ?? null)));
        $phone_number = safe_htmlspecialchars(trim($_POST['phone_number'] ?? ''));
        $serial_number = (int) safe_htmlspecialchars(trim($_POST['serial_number'] ?? ''));
        $vehicle_number = safe_htmlspecialchars(trim($_POST['vehicle_number'] ?? null));
        $route_ids = $_POST['routes'] ?? '[]';
        $aadhaar_number = safe_htmlspecialchars(trim($_POST['aadhaar_number'] ?? ''));
        $village = safe_htmlspecialchars(trim($_POST['village'] ?? ''));
        $post_office = safe_htmlspecialchars(trim($_POST['post_office'] ?? ''));
        $police_station = safe_htmlspecialchars(trim($_POST['police_station'] ?? ''));
        $district = safe_htmlspecialchars(trim($_POST['district'] ?? ''));
        $pincode = safe_htmlspecialchars(trim($_POST['pincode'] ?? ''));

        // --- FAMILY FIELDS ---
        $father_name = safe_htmlspecialchars(trim($_POST['father_name'] ?? ''));
        $father_phone = safe_htmlspecialchars(trim($_POST['father_phone'] ?? ''));
        $mother_name = safe_htmlspecialchars(trim($_POST['mother_name'] ?? ''));
        $mother_phone = safe_htmlspecialchars(trim($_POST['mother_phone'] ?? ''));

        // --- BANK FIELDS ---
        $pan_number = strtoupper(safe_htmlspecialchars(trim($_POST['pan_number'] ?? '')));
        $voter_epic_number = strtoupper(safe_htmlspecialchars(trim($_POST['voter_epic_number'] ?? '')));
        $bank_name = safe_htmlspecialchars(trim($_POST['bank_name'] ?? ''));
        $bank_branch = safe_htmlspecialchars(trim($_POST['bank_branch'] ?? ''));
        $ifsc_code = strtoupper(safe_htmlspecialchars(trim($_POST['ifsc_code'] ?? '')));
        $account_number = safe_htmlspecialchars(trim($_POST['account_number'] ?? ''));

        // --- ACCESS SWITCH ---
        // Unchecked checkboxes are simply absent from the POST body.
        $can_view_student_financial_report = isset($_POST['can_view_student_financial_report']) ? 1 : 0;

        // Validate required fields
        if (empty($driver_name) || empty($phone_number) || empty($serial_number) || empty($route_ids)) {
            throw new Exception('Red * fields are mandatory.');
        }

        if ($vehicle_number === '') {
            $vehicle_number = null;
        }

        // You should have validation functions for email and phone
        if (!empty($driver_email) && !filter_var($driver_email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception('Invalid email id');
        }

        if (empty($driver_email)) {
            $driver_email = null;
        }

        if (!isValidPhoneNumber($phone_number)) {
            throw new Exception('Invalid phone number');
        }

        // Uniqueness-sensitive identity fields: store as NULL when blank so the
        // DB's unique index doesn't treat multiple blanks as duplicates.
        $aadhaar_number = $aadhaar_number !== '' ? $aadhaar_number : null;
        $pan_number = $pan_number !== '' ? $pan_number : null;
        $voter_epic_number = $voter_epic_number !== '' ? $voter_epic_number : null;

        // Basic format checks for the optional fields (only if the admin filled them in)
        if (!empty($pan_number) && !preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/', $pan_number)) {
            throw new Exception('Invalid PAN number format');
        }
        if (!empty($ifsc_code) && !preg_match('/^[A-Z]{4}0[A-Z0-9]{6}$/', $ifsc_code)) {
            throw new Exception('Invalid IFSC code format');
        }
        if (!empty($voter_epic_number) && !preg_match('/^[A-Z]{3}[0-9]{7}$/', $voter_epic_number)) {
            throw new Exception('Invalid Voter EPIC number format');
        }
        if (!empty($father_phone) && !isValidPhoneNumber($father_phone)) {
            throw new Exception('Invalid father\'s phone number');
        }
        if (!empty($mother_phone) && !isValidPhoneNumber($mother_phone)) {
            throw new Exception('Invalid mother\'s phone number');
        }

        // Check if route_ids are valid
        if (!is_array($route_ids)) {
            throw new Exception('Please select at least one route for the driver.');
        }

        // Check for duplicates
        $sql = "SELECT id FROM drivers WHERE email = ? OR phone = ? OR serial_number = ?";
        $params = [$driver_email, $phone_number, $serial_number];

        if (!empty($vehicle_number)) {
            $sql .= " OR vehicle_number = ?";
            $params[] = strtoupper($vehicle_number);
        }

        $checkDuplicate = $pdo->prepare($sql);
        $checkDuplicate->execute($params);

        if ($checkDuplicate->rowCount() > 0) {
            throw new Exception('Email, Phone Number, Serial Number or Vehicle Number is already in use by another driver.');
        }

        // Aadhaar / PAN / Voter EPIC must be unique, but only when provided
        if (!empty($aadhaar_number)) {
            $checkAadhaar = $pdo->prepare("SELECT id FROM drivers WHERE aadhaar_number = ?");
            $checkAadhaar->execute([$aadhaar_number]);
            if ($checkAadhaar->rowCount() > 0) {
                throw new Exception('This Aadhaar number is already registered with another driver');
            }
        }
        if (!empty($pan_number)) {
            $checkPan = $pdo->prepare("SELECT id FROM drivers WHERE pan_number = ?");
            $checkPan->execute([$pan_number]);
            if ($checkPan->rowCount() > 0) {
                throw new Exception('This PAN number is already registered with another driver');
            }
        }
        if (!empty($voter_epic_number)) {
            $checkEpic = $pdo->prepare("SELECT id FROM drivers WHERE voter_epic_number = ?");
            $checkEpic->execute([$voter_epic_number]);
            if ($checkEpic->rowCount() > 0) {
                throw new Exception('This Voter EPIC number is already registered with another driver');
            }
        }

        // Handle image upload
        $photo = 'default_driver_dp.jpg'; // A default image for drivers

        if (!empty($_FILES['cropped_image']['tmp_name']) || !empty($_FILES['original_image']['tmp_name'])) {
            $imageFile = !empty($_FILES['cropped_image']['tmp_name'])
                ? $_FILES['cropped_image']['tmp_name']
                : $_FILES['original_image']['tmp_name'];

            $imageInfo = @getimagesize($imageFile);
            if ($imageInfo === false) {
                throw new Exception('You are trying to upload an invalid or corrupted image.');
            }

            $photo = uniqid('drv_');

            if ($imageInfo['mime'] === 'image/jpeg') {
                $photo .= ".jpg";
            } else if ($imageInfo['mime'] === 'image/png') {
                $photo .= ".png";
            } else {
                 throw new Exception('Only JPG and PNG images are allowed.');
            }

            // Create drivers directory if it doesn't exist
            $uploadDir =  __DIR__ . '/../../../../uploads/drivers/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            $destination = $uploadDir . $photo;

            if (!move_uploaded_file($imageFile, $destination)) {
                throw new Exception('Failed to upload image.');
            }
        }

        // --- Handle dynamic document uploads (ImgBB) ---
        // Expects two parallel arrays from the form:
        //   document_name[]  -> text label the admin typed (e.g. "Driving Licence")
        //   document_file[]  -> the corresponding uploaded image
        $documents = [];

        if (!empty($_FILES['document_file']['name']) && is_array($_FILES['document_file']['name'])) {
            $docNames = $_POST['document_name'] ?? [];
            $docFiles = $_FILES['document_file'];
            $totalDocs = count($docFiles['name']);

            // Count the slots that actually carry a file and reject an over-limit
            // submission up front, before spending time on any ImgBB upload.
            $filledSlots = 0;
            for ($i = 0; $i < $totalDocs; $i++) {
                if ($docFiles['error'][$i] !== UPLOAD_ERR_NO_FILE) {
                    $filledSlots++;
                }
            }

            if ($filledSlots > MAX_DRIVER_DOCUMENTS) {
                throw new Exception('You can upload a maximum of ' . MAX_DRIVER_DOCUMENTS . ' documents.');
            }

            for ($i = 0; $i < $totalDocs; $i++) {
                // Skip empty slots (row added but nothing selected)
                if ($docFiles['error'][$i] === UPLOAD_ERR_NO_FILE) {
                    continue;
                }

                $docName = isset($docNames[$i]) ? sanitize_input($docNames[$i]) : '';
                if (empty($docName)) {
                    throw new Exception('Every uploaded document must have a name.');
                }

                // Rebuild a single-file $_FILES-style array for this index
                $singleFile = [
                    'name'     => $docFiles['name'][$i],
                    'type'     => $docFiles['type'][$i],
                    'tmp_name' => $docFiles['tmp_name'][$i],
                    'error'    => $docFiles['error'][$i],
                    'size'     => $docFiles['size'][$i],
                ];

                // Uploads to ImgBB and returns the direct image URL (throws on failure)
                $docUrl = uploadDocumentToImgBB($singleFile, $docName . ' - ' . $driver_name);

                $documents[] = [
                    'document_name' => $docName,
                    'document_url'  => $docUrl,
                ];
            }
        }

        $documentsJson = !empty($documents) ? json_encode($documents) : null;

        // Insert new driver into the 'drivers' table
        $stmt = $pdo->prepare("
            INSERT INTO drivers (
                name,
                email,
                phone,
                serial_number,
                vehicle_number,
                route_ids,
                aadhaar_number,
                village,
                post_office,
                police_station,
                district,
                pincode,
                driver_image,
                father_name,
                father_phone,
                mother_name,
                mother_phone,
                pan_number,
                voter_epic_number,
                bank_name,
                bank_branch,
                ifsc_code,
                account_number,
                documents,
                can_view_student_financial_report
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $driver_name,
            $driver_email,
            $phone_number,
            $serial_number,
            $vehicle_number,
            json_encode($route_ids),
            $aadhaar_number,
            $village,
            $post_office,
            $police_station,
            $district,
            $pincode,
            $photo,
            $father_name,
            $father_phone,
            $mother_name,
            $mother_phone,
            $pan_number,
            $voter_epic_number,
            $bank_name,
            $bank_branch,
            $ifsc_code,
            $account_number,
            $documentsJson,
            $can_view_student_financial_report
        ]);

        $response['success'] = true;
        $response['message'] = 'Driver added successfully';
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
