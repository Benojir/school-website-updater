<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to manage transport
// You might need to define PERM_MANAGE_TRANSPORT in your permission system
if (!hasPermission(PERM_MANAGE_TRANSPORT))  {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        $driver_name = safe_htmlspecialchars(trim($_POST['driver_name'] ?? ''));
        $driver_email = strtolower(safe_htmlspecialchars(trim($_POST['driver_email'] ?? null)));
        $phone_number = safe_htmlspecialchars(trim($_POST['phone_number'] ?? ''));
        $serial_number = (int) safe_htmlspecialchars(trim($_POST['serial_number'] ?? ''));
        $vehicle_number = safe_htmlspecialchars(trim($_POST['vehicle_number'] ?? null));
        $route_ids = $_POST['routes'] ?? '[]';
        $aadhaar_number = safe_htmlspecialchars(trim($_POST['aadhaar_number'] ?? ''));
        $village = safe_htmlspecialchars(trim($_POST['village'] ?? ''));
        $post_office = safe_htmlspecialchars(trim($_POST['post_office'] ?? ''));
        $police_station = safe_htmlspecialchars(trim($_POST['police_station'] ?? ''));
        $district = safe_htmlspecialchars(trim($_POST['district'] ?? ''));
        $pincode = safe_htmlspecialchars(trim($_POST['pincode'] ?? ''));

        // Validate required fields
        if (empty($driver_name) || empty($phone_number) || empty($serial_number) || empty($route_ids)) {
            throw new Exception('Red * fields are mandatory.');
        }
        
        if ($vehicle_number === '') {
            $vehicle_number = null;
        }

        // You should have validation functions for email and phone
        if (!empty($driver_email) && !filter_var($driver_email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception('Invalid email id');
        } 
        
        if (empty($driver_email)) {
            $driver_email = null;
        }

        if (!isValidPhoneNumber($phone_number)) {
            throw new Exception('Invalid phone number');
        }

        // Check if route_ids are valid
        if (!is_array($route_ids)) {
            throw new Exception('Please select at least one route for the driver.');
        }

        // Check for duplicates
        $sql = "SELECT id FROM drivers WHERE email = ? OR phone = ? OR serial_number = ?";
        $params = [$driver_email, $phone_number, $serial_number];

        if (!empty($vehicle_number)) {
            $sql .= " OR vehicle_number = ?";
            $params[] = strtoupper($vehicle_number); 
        }

        $checkDuplicate = $pdo->prepare($sql);
        $checkDuplicate->execute($params);

        if ($checkDuplicate->rowCount() > 0) {
            throw new Exception('Email, Phone Number, Serial Number or Vehicle Number is already in use by another driver.');
        }

        // Handle image upload
        $photo = 'default_driver_dp.jpg'; // A default image for drivers

        if (!empty($_FILES['cropped_image']['tmp_name']) || !empty($_FILES['original_image']['tmp_name'])) {
            $imageFile = !empty($_FILES['cropped_image']['tmp_name'])
                ? $_FILES['cropped_image']['tmp_name']
                : $_FILES['original_image']['tmp_name'];

            $imageInfo = @getimagesize($imageFile);
            if ($imageInfo === false) {
                throw new Exception('You are trying to upload an invalid or corrupted image.');
            }

            $photo = uniqid('drv_');

            if ($imageInfo['mime'] === 'image/jpeg') {
                $photo .= ".jpg";
            } else if ($imageInfo['mime'] === 'image/png') {
                $photo .= ".png";
            } else {
                 throw new Exception('Only JPG and PNG images are allowed.');
            }

            // Create drivers directory if it doesn't exist
            $uploadDir =  __DIR__ . '/../../../../uploads/drivers/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            
            $destination = $uploadDir . $photo;

            if (!move_uploaded_file($imageFile, $destination)) {
                throw new Exception('Failed to upload image.');
            }
        }

        // Insert new driver into the 'drivers' table
        $stmt = $pdo->prepare("
            INSERT INTO drivers (
                name, 
                email, 
                phone, 
                serial_number,
                vehicle_number, 
                route_ids, 
                aadhaar_number, 
                village, 
                post_office, 
                police_station, 
                district, 
                pincode,
                driver_image
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $driver_name,
            $driver_email,
            $phone_number,
            $serial_number,
            $vehicle_number,
            json_encode($route_ids),
            $aadhaar_number,
            $village,
            $post_office,
            $police_station,
            $district,
            $pincode,
            $photo
        ]);

        $response['success'] = true;
        $response['message'] = 'Driver added successfully';
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
