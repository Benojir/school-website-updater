<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to manage transport
// You might need to define PERM_MANAGE_TRANSPORT in your permission system
if (!hasPermission(PERM_MANAGE_TRANSPORT))  {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$driving_route = sanitize_input($_REQUEST['driving_route'] ?? '');
$route_id = sanitize_input($_REQUEST['route_id'] ?? '');

if (empty($driving_route) || empty($route_id)) {
    echo json_encode([
        'success' => false,
        'message' => 'Please enter a driving route name.'
    ]);
    die();
}

$check = $pdo->prepare("SELECT * FROM driving_routes WHERE route_name = :route_name AND id != :route_id");
$check->execute(['route_name' => $driving_route, 'route_id' => $route_id]);
if ($check->rowCount() > 0) {
    echo json_encode([
        'success' => false,
        'message' => 'A driving route with the same name already exists.'
    ]);
    die();
}

$update = $pdo->prepare("UPDATE driving_routes SET route_name = :route_name WHERE id = :route_id");
$update->execute(['route_name' => $driving_route, 'route_id' => $route_id]);

echo json_encode([
    'success' => true,
    'message' => 'Driving route updated successfully.'
]);