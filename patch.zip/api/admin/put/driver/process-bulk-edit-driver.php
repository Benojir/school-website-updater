<?php
ob_start();
include_once(__DIR__ . "/../../../../includes/auth-check.php");

// Needed for uploadDocumentToImgBB()
include_once(__DIR__ . "/../../../../includes/imgbb-upload.php");

header('Content-Type: application/json');

if (!hasPermission(PERM_MANAGE_TRANSPORT)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    function clean($data) {
        return safe_htmlspecialchars(trim($data));
    }

    function saveBase64Image($base64_string, $upload_dir, $prefix = 'drv_') {
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
        if (preg_match('/^data:image\/(\w+);base64,/', $base64_string, $type)) {
            $data = substr($base64_string, strpos($base64_string, ',') + 1);
            $type = strtolower($type[1]);
            if (!in_array($type, ['jpg', 'jpeg', 'png'])) return false;
            $data = base64_decode($data);
            if ($data === false || strlen($data) > 2 * 1024 * 1024) return false;
        } else {
            return false;
        }
        $file_name = uniqid($prefix) . '.' . $type;
        $file_path = $upload_dir . $file_name;
        if (file_put_contents($file_path, $data)) {
            if (!getimagesize($file_path)) {
                unlink($file_path);
                return false;
            }
            return $file_name;
        }
        return false;
    }

    if (empty($_POST['id'])) {
        throw new Exception("Driver ID is required");
    }

    $driver_id = (int)$_POST['id'];
    $updateFields = [];
    $params = [':id' => $driver_id];

    // Allowed status values
    $allowed_status = ['active', 'inactive'];

    // Fields that must never be empty if they're included in the request.
    // A driver's email is optional, unlike a teacher's.
    $required_fields = ['name', 'phone', 'serial_number', 'status'];

    // Fields that are always upper-cased before validation/storage
    $uppercase_fields = ['pan_number', 'ifsc_code', 'voter_epic_number'];

    // Fields that must stay unique across drivers when provided. The columns use a
    // case-insensitive collation, so a plain `=` comparison is enough here.
    $unique_fields = ['email', 'phone', 'serial_number', 'vehicle_number', 'aadhaar_number', 'pan_number', 'voter_epic_number'];

    // Yes/No columns. These are NOT NULL in the schema, so an empty value falls back to 0
    // instead of being written as NULL by the generic writer below.
    $boolean_fields = ['can_view_student_financial_report'];

    // Define editable fields, grouped to mirror add-driver.php
    $field_map = [
        // Personal
        'name' => 'string',
        'email' => 'email',
        'phone' => 'string',
        'aadhaar_number' => 'string',
        // Family
        'father_name' => 'string',
        'father_phone' => 'string',
        'mother_name' => 'string',
        'mother_phone' => 'string',
        // Assignment
        'serial_number' => 'string',
        'vehicle_number' => 'string',
        'status' => 'string',
        // Access
        'can_view_student_financial_report' => 'string',
        // Bank
        'pan_number' => 'string',
        'voter_epic_number' => 'string',
        'bank_name' => 'string',
        'bank_branch' => 'string',
        'ifsc_code' => 'string',
        'account_number' => 'string',
        // Address
        'village' => 'string',
        'post_office' => 'string',
        'police_station' => 'string',
        'district' => 'string',
        'pincode' => 'string',
    ];

    foreach ($field_map as $field_name => $type) {
        if (isset($_POST[$field_name])) {
            $value = trim($_POST[$field_name]);

            // Required fields cannot be cleared
            if (in_array($field_name, $required_fields) && $value === '') {
                throw new Exception(ucfirst(str_replace('_', ' ', $field_name)) . " cannot be empty.");
            }

            // Normalize case for identity/bank codes before any validation
            if (in_array($field_name, $uppercase_fields) && $value !== '') {
                $value = strtoupper($value);
            }

            if ($field_name === 'email' && $value !== '' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                throw new Exception("Invalid email address format");
            }

            if ($field_name === 'phone' && $value !== '' && function_exists('isValidPhoneNumber') && !isValidPhoneNumber($value)) {
                throw new Exception("Invalid phone number");
            }

            if (in_array($field_name, ['father_phone', 'mother_phone']) && $value !== '' && function_exists('isValidPhoneNumber') && !isValidPhoneNumber($value)) {
                $who = $field_name === 'father_phone' ? "Father's" : "Mother's";
                throw new Exception("Invalid {$who} phone number");
            }

            if ($field_name === 'status' && $value !== '' && !in_array($value, $allowed_status)) {
                throw new Exception("Invalid status value selected");
            }

            if ($field_name === 'pan_number' && $value !== '' && !preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/', $value)) {
                throw new Exception('Invalid PAN number format');
            }

            if ($field_name === 'ifsc_code' && $value !== '' && !preg_match('/^[A-Z]{4}0[A-Z0-9]{6}$/', $value)) {
                throw new Exception('Invalid IFSC code format');
            }

            if ($field_name === 'voter_epic_number' && $value !== '' && !preg_match('/^[A-Z]{3}[0-9]{7}$/', $value)) {
                throw new Exception('Invalid Voter EPIC number format');
            }

            if (in_array($field_name, $boolean_fields) && $value !== '' && !in_array($value, ['0', '1'], true)) {
                $label = ucwords(str_replace('_', ' ', $field_name));
                throw new Exception("Invalid value for {$label} - it must be Yes or No.");
            }

            // Identity / contact fields must stay unique across drivers when provided
            if (in_array($field_name, $unique_fields) && $value !== '') {
                $checkUnique = $pdo->prepare("SELECT COUNT(*) FROM drivers WHERE {$field_name} = ? AND id != ?");
                $checkUnique->execute([$value, $driver_id]);
                if ($checkUnique->fetchColumn() > 0) {
                    $label = ucwords(str_replace('_', ' ', $field_name));
                    throw new Exception("This {$label} is already in use by another driver");
                }
            }

            $updateFields[] = "{$field_name} = :{$field_name}";

            if (in_array($field_name, $boolean_fields)) {
                // NOT NULL column - never write NULL here
                $params[":{$field_name}"] = ($value === '') ? 0 : (int)$value;
            } else {
                $params[":{$field_name}"] = ($value === '') ? null : clean($value);
            }
        }
    }

    // --- Routes Logic ---
    // drivers.route_ids holds a JSON list of driving_routes ids.
    if (isset($_POST['route_ids'])) {
        $routes_decoded = json_decode($_POST['route_ids'], true);
        if (is_array($routes_decoded)) {
            // Map to integers for safety before encoding
            $routes_mapped = array_map('intval', $routes_decoded);
            $updateFields[] = "route_ids = :route_ids";
            $params[':route_ids'] = json_encode($routes_mapped);
        } else {
            // Handle clearing all routes
            $updateFields[] = "route_ids = :route_ids";
            $params[':route_ids'] = json_encode([]);
        }
    }

    // Handle Image Upload
    if (!empty($_POST['cropped_image_data'])) {
        $upload_dir = __DIR__ . '/../../../../uploads/drivers/';
        $cropped_image = saveBase64Image($_POST['cropped_image_data'], $upload_dir);

        if ($cropped_image) {
            $current_image = isset($_POST['current_image']) ? trim($_POST['current_image']) : null;
            // Unlink old image if it's not the default
            if ($current_image && $current_image !== 'default_driver_dp.jpg' && file_exists($upload_dir . $current_image)) {
                unlink($upload_dir . $current_image);
            }
            $updateFields[] = "driver_image = :driver_image";
            $params[':driver_image'] = $cropped_image;
            $response['new_image'] = $cropped_image;
        } else {
            throw new Exception("Failed to save cropped image.");
        }
    }

    // --- Documents Logic ---
    // drivers.documents holds a JSON list of {document_name, document_url}. The page sends the
    // full list that should be kept in documents_existing (covering renames and removals), plus
    // optional document_name[] / document_file[] pairs for documents being added now.
    $has_new_document_files = !empty($_FILES['document_file']['name']) && is_array($_FILES['document_file']['name']);

    if (isset($_POST['documents_existing']) || $has_new_document_files) {
        // Current stored state. Needed as the fallback list, and to tell whether the document
        // count is actually growing - drivers saved before the cap existed may already exceed it.
        $stmt_docs = $pdo->prepare("SELECT documents FROM drivers WHERE id = :id");
        $stmt_docs->execute([':id' => $driver_id]);
        $stored_documents = json_decode($stmt_docs->fetchColumn() ?: '[]', true);

        if (!is_array($stored_documents)) {
            $stored_documents = [];
        }

        $documents = [];

        if (isset($_POST['documents_existing'])) {
            $existing_documents = json_decode($_POST['documents_existing'], true);

            if (!is_array($existing_documents)) {
                throw new Exception("Invalid documents data received.");
            }

            foreach ($existing_documents as $existing_document) {
                $doc_name = isset($existing_document['document_name']) ? clean(trim($existing_document['document_name'])) : '';
                $doc_url = isset($existing_document['document_url']) ? trim($existing_document['document_url']) : '';

                if ($doc_name === '' || $doc_url === '') {
                    throw new Exception("Every document must have a name and an uploaded file.");
                }

                if (!filter_var($doc_url, FILTER_VALIDATE_URL)) {
                    throw new Exception("Invalid document URL received.");
                }

                $documents[] = ['document_name' => $doc_name, 'document_url' => $doc_url];
            }
        } else {
            // Only new files were sent, so keep whatever is already stored and append to it
            $documents = $stored_documents;
        }

        if ($has_new_document_files) {
            $docNames = $_POST['document_name'] ?? [];
            $docFiles = $_FILES['document_file'];
            $totalDocs = count($docFiles['name']);

            // Reject an over-limit request before any ImgBB upload happens, otherwise
            // the images that did upload would be orphaned when this throws.
            $filledSlots = 0;
            for ($i = 0; $i < $totalDocs; $i++) {
                if ($docFiles['error'][$i] !== UPLOAD_ERR_NO_FILE) {
                    $filledSlots++;
                }
            }

            if (count($documents) + $filledSlots > MAX_DRIVER_DOCUMENTS) {
                throw new Exception('A driver can have a maximum of ' . MAX_DRIVER_DOCUMENTS . ' documents.');
            }

            // Driver's name is used as part of the ImgBB caption
            $stmt_driver_name = $pdo->prepare("SELECT name FROM drivers WHERE id = :id");
            $stmt_driver_name->execute([':id' => $driver_id]);
            $driver_name = $stmt_driver_name->fetchColumn() ?: "ID {$driver_id}";

            for ($i = 0; $i < $totalDocs; $i++) {
                // Skip empty slots (row added but nothing selected)
                if ($docFiles['error'][$i] === UPLOAD_ERR_NO_FILE) {
                    continue;
                }

                $doc_name = isset($docNames[$i]) ? clean(trim($docNames[$i])) : '';
                if ($doc_name === '') {
                    throw new Exception("Every uploaded document must have a name.");
                }

                // Rebuild a single-file $_FILES-style array for this index
                $singleFile = [
                    'name'     => $docFiles['name'][$i],
                    'type'     => $docFiles['type'][$i],
                    'tmp_name' => $docFiles['tmp_name'][$i],
                    'error'    => $docFiles['error'][$i],
                    'size'     => $docFiles['size'][$i],
                ];

                $documents[] = [
                    'document_name' => $doc_name,
                    'document_url'  => uploadDocumentToImgBB($singleFile, $doc_name . ' - ' . $driver_name),
                ];
            }
        }

        // The cap applies to growth only: a driver who already exceeds it (saved before the cap
        // existed) can still have documents renamed or removed, just not added.
        if (count($documents) > MAX_DRIVER_DOCUMENTS && count($documents) > count($stored_documents)) {
            throw new Exception('A driver can have a maximum of ' . MAX_DRIVER_DOCUMENTS . ' documents.');
        }

        $updateFields[] = "documents = :documents";
        $params[':documents'] = !empty($documents) ? json_encode($documents) : null;
        $response['documents'] = $documents;
    }

    if (!empty($updateFields)) {
        $sql = "UPDATE drivers SET " . implode(', ', array_unique($updateFields)) . " WHERE id = :id";
        $stmt = $pdo->prepare($sql);

        if ($stmt->execute($params)) {
            $response['success'] = true;
            $response['message'] = "Driver updated successfully";
        } else {
            throw new Exception("Failed to update driver record.");
        }
    } else {
        $response['success'] = true;
        $response['message'] = "No changes were detected";
    }

} catch (PDOException $e) {
    $response['message'] = "Database error: " . $e->getMessage();
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

ob_end_clean();
echo json_encode($response);
exit();
?>
