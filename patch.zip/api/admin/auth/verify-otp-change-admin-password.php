<?php
require_once __DIR__ . '/../../../includes/config.php';

// Rate limiting
if (!isset($_SESSION['otp_verify_attempts'])) {
    $_SESSION['otp_verify_attempts'] = 0;
    $_SESSION['otp_verify_first_attempt'] = time();
}

// Check if too many attempts in the last 15 minutes
if ($_SESSION['otp_verify_attempts'] >= 5) {
    $time_since_first_attempt = time() - $_SESSION['otp_verify_first_attempt'];
    if ($time_since_first_attempt < 900) { // 15 minutes
        die(json_encode(['success' => false, 'message' => 'Too many failed attempts. Please try again after 15 minutes.']));
    } else {
        // Reset counter after 15 minutes
        $_SESSION['otp_verify_attempts'] = 0;
        $_SESSION['otp_verify_first_attempt'] = time();
    }
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(['success' => false, 'message' => 'Invalid request method']));
}

// Validate required fields first
$usernameOrEmail = sanitize_input($_POST['adminUsername'] ?? '');
$password = sanitize_input($_POST['newPassword'] ?? '');
$otp = sanitize_input($_POST['otp'] ?? '');
$hcaptchaResponse = $_POST['h-captcha-response'] ?? '';

if (empty($usernameOrEmail) || empty($password) || empty($otp) || empty($hcaptchaResponse)) {
    $_SESSION['otp_verify_attempts']++;
    die(json_encode(['success' => false, 'message' => 'All fields including captcha are required']));
}

// hCaptcha verification
$secretKey = $websiteConfig['captcha_secret_key'];

$data = array(
    'secret' => $secretKey,
    'response' => $hcaptchaResponse,
    'remoteip' => $_SERVER['REMOTE_ADDR'] ?? ''
);

$options = array(
    'http' => array(
        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
        'method' => 'POST',
        'content' => http_build_query($data),
        'timeout' => 10
    )
);

$context = stream_context_create($options);
$result = @file_get_contents($captchaVerifyUrl, false, $context);

if ($result === false) {
    $_SESSION['otp_verify_attempts']++;
    die(json_encode(['success' => false, 'message' => 'Unable to verify captcha. Please try again.']));
}

$responseData = json_decode($result);

if (!$responseData || !$responseData->success) {
    $_SESSION['otp_verify_attempts']++;
    $errorMessage = 'Captcha verification failed';
    if ($responseData && isset($responseData->{'error-codes'})) {
        error_log('hCaptcha verification failed: ' . implode(', ', $responseData->{'error-codes'}));
    }
    die(json_encode(['success' => false, 'message' => $errorMessage]));
}

// Validate password strength
if (strlen($password) < 8) {
    $_SESSION['otp_verify_attempts']++;
    die(json_encode(['success' => false, 'message' => 'Password must be at least 8 characters long.']));
}

// Check if password contains at least one uppercase, one lowercase, one number
if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/', $password)) {
    $_SESSION['otp_verify_attempts']++;
    die(json_encode(['success' => false, 'message' => 'Password must contain at least one uppercase letter, one lowercase letter, and one number.']));
}

// Check if OTP session exists and is not expired
if (!isset($_SESSION['admin_password_reset_otp']) || !isset($_SESSION['admin_password_reset_otp_time'])) {
    $_SESSION['otp_verify_attempts']++;
    die(json_encode(['success' => false, 'message' => 'OTP session not found. Please request new OTP.']));
}

// Check OTP expiry (10 minutes)
$otp_age = time() - $_SESSION['admin_password_reset_otp_time'];
if ($otp_age > 600) { // 10 minutes
    unset($_SESSION['admin_password_reset_otp']);
    unset($_SESSION['admin_password_reset_otp_time']);
    unset($_SESSION['admin_password_reset_username']);
    $_SESSION['otp_verify_attempts']++;
    die(json_encode(['success' => false, 'message' => 'OTP expired. Please request new OTP.']));
}

// Verify username matches the one used to generate OTP
if (!isset($_SESSION['admin_password_reset_username']) || 
    $_SESSION['admin_password_reset_username'] !== $usernameOrEmail) {
    $_SESSION['otp_verify_attempts']++;
    die(json_encode(['success' => false, 'message' => 'Invalid session. Please start over.']));
}

try {
    // Verify user exists and get user info
    $stmt = $pdo->prepare("SELECT id, username, email, full_name FROM users WHERE username = ? OR email = ? LIMIT 1");
    $stmt->execute([$usernameOrEmail, $usernameOrEmail]);
    $admin = $stmt->fetch();

    if (!$admin) {
        $_SESSION['otp_verify_attempts']++;
        die(json_encode(['success' => false, 'message' => 'Invalid username or email.']));
    }

    // Verify OTP with timing-safe comparison
    if (!hash_equals($_SESSION['admin_password_reset_otp'], $otp)) {
        $_SESSION['otp_verify_attempts']++;
        die(json_encode(['success' => false, 'message' => 'Invalid OTP.']));
    }

    // Update password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE users SET password = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$hashedPassword, $admin['id']]);

    // Clear OTP session data
    unset($_SESSION['admin_password_reset_otp']);
    unset($_SESSION['admin_password_reset_otp_time']);
    unset($_SESSION['admin_password_reset_username']);
    unset($_SESSION['otp_verify_attempts']);
    unset($_SESSION['otp_verify_first_attempt']);

    // Log the password change
    error_log("Password changed successfully for user: " . $admin['username'] . " (ID: " . $admin['id'] . ") from IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));

    die(json_encode(['success' => true, 'message' => 'Password changed successfully for ' . safe_htmlspecialchars($admin['full_name'])]));

} catch (PDOException $e) {
    error_log('Database error in password reset: ' . $e->getMessage());
    $_SESSION['otp_verify_attempts']++;
    die(json_encode(['success' => false, 'message' => 'Database error occurred. Please try again.']));
}