<?php
require_once __DIR__ . '/../../../includes/auth-check.php';

header('Content-Type: application/json');

$authData = authenticateAdminApiRequest($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit();
}

try {
    $admin_id = $authData['user_id'];
    $currentPassword = $_POST['password'] ?? '';
    $securityPin = $_POST['securityPin'] ?? '';

    // Validate inputs
    if (empty($currentPassword)) {
        throw new Exception('Current password is required');
    }

    if (strlen($securityPin) !== 6) {
        throw new Exception('Security Pin must be 6 digits long');
    }

    // Verify current password
    $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$admin_id]);
    $admin = $stmt->fetch();

    if (!password_verify($currentPassword, $admin['password'])) {
        throw new Exception('Current password is incorrect');
    }

    // Update security pin
    $stmt = $pdo->prepare("UPDATE users SET security_pin = ? WHERE id = ?");
    $stmt->execute([$securityPin, $admin_id]);

    echo json_encode([
        'success' => true,
        'message' => 'Security Pin updated successfully!'
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
