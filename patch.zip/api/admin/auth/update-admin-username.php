<?php
require_once __DIR__ . '/../../../includes/auth-check.php';

header('Content-Type: application/json');

$authData = authenticateAdminApiRequest($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
    exit();
}

try {
    $admin_id = $authData['user_id'];
    $newUsername = trim($_POST['newUsername'] ?? '');
    $confirmPassword = $_POST['confirmPassword'] ?? '';

    // Validate inputs
    if (empty($newUsername) || empty($confirmPassword)) {
        throw new Exception('All fields are required');
    }

    if (strlen($newUsername) < 3 || strlen($newUsername) > 25) {
        throw new Exception('Username must be 3-25 characters long');
    }

    // Verify current password
    $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$admin_id]);
    $admin = $stmt->fetch();

    if (!password_verify($confirmPassword, $admin['password'])) {
        throw new Exception('Current password is incorrect');
    }

    // Check if username already exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
    $stmt->execute([$newUsername, $admin_id]);
    if ($stmt->fetch()) {
        throw new Exception('Username already exists');
    }

    // Update username
    $stmt = $pdo->prepare("UPDATE users SET username = ? WHERE id = ?");
    $stmt->execute([$newUsername, $admin_id]);

    echo json_encode([
        'success' => true,
        'message' => 'Username updated successfully!'
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
