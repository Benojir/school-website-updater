<?php
require_once __DIR__ . '/../../../includes/auth-check.php';

header('Content-Type: application/json');

$authData = authenticateAdminApiRequest($pdo);

$admin_id = $authData['user_id'];
$session_id = $authData['session_id'];

$requested_session_id = $_POST['sessionId'] ?? null;

if (empty($requested_session_id)) {
    echo json_encode(['success' => false, 'message' => 'Session ID is required']);
    exit;
}

if($session_id == $requested_session_id) {
    echo json_encode(['success' => false, 'message' => 'You cannot revoke your own session']);
    exit;
}

try {
    $stmt = $pdo->prepare("DELETE FROM admin_auth_sessions WHERE id = ? AND user_id = ?");
    $stmt->execute([$requested_session_id, $admin_id]);
    echo json_encode(['success' => true, 'message' => 'Session revoked successfully']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'An error occurred while revoking the session: ' . $e->getMessage()]);
    exit;
}