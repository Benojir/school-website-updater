<?php
require_once(__DIR__ . "/../../../includes/config.php");

// Unset all session variables
$_SESSION = array();

// Destroy the session
session_destroy();

// Delete the remember me cookie if it exists
if (isset($_COOKIE['remember_me'])) {
    // Also clear the token from database
    $token = $_COOKIE['remember_me'];
    $pdo->prepare("UPDATE users SET remember_token = NULL, token_expiry = NULL WHERE remember_token = ?")
        ->execute([$token]);
    
    setcookie('remember_me', '', time() - 3600, '/');
}

// Redirect to login page
header("Location: /");
exit();
?>