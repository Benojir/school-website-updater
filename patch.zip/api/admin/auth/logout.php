<?php
require_once(__DIR__ . "/../../../includes/auth-check.php");

// 1. Delete the session from the database (if it exists)
if (!empty($_COOKIE['admin_auth_token'])) {
    $token = $_COOKIE['admin_auth_token'];
    $tokenHash = hash('sha256', $token);
    
    // Use the new table name
    $stmt = $pdo->prepare("DELETE FROM admin_auth_sessions WHERE token_hash = ?");
    $stmt->execute([$tokenHash]);
}

// 2. Expire the cookie by setting its expiry date to the past
setcookie('admin_auth_token', '', [
    'expires' => time() - 3600, // 1 hour ago
    'path' => '/',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

// 3. Clear any old session data just in case
if (session_status() == PHP_SESSION_ACTIVE) {
    session_destroy();
}

// Redirect to login page
// json_encode(['success' => true, 'message' => 'Logged out successfully. Redirecting to login page...']);
 echo '<script>location.replace("../../../management/");</script>';