<?php
require_once __DIR__ . '/../../../includes/auth-check.php';

header('Content-Type: application/json');

$authData = authenticateAdminApiRequest($pdo);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit();
}

try {
    $admin_id = $authData['user_id'];

    $full_name = trim($_POST['adminName'] ?? '');
    $email = strtolower(trim($_POST['loginEmail'] ?? ''));
    $confirm_password = strtolower(trim($_POST['confirmPassword'] ?? ''));

    // Set email empty if user is super admin
    if (isSuperAdmin()) {
        $email = '';
    }

    // Validate inputs
    if (empty($full_name) || empty($confirm_password)) {
        throw new Exception('Admin name and password are required');
    }

    if (strlen($full_name) < 3 || strlen($full_name) > 25) {
        throw new Exception('Admin name must be 3-25 characters long');
    }

    // Verify password
    $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$admin_id]);
    $admin = $stmt->fetch();

    if (!password_verify($confirm_password, $admin['password'])) {
        throw new Exception('Password is incorrect');
    }

    if (!empty($email)) {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception('Invalid email format');
        }

        // Check if email already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$email, $admin_id]);
        if ($stmt->fetch()) {
            throw new Exception('Email already exists');
        }
    }

    $success = false;

    if (!empty($email)) {
        $sql = "UPDATE users SET full_name = ?, email = ? WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $success = $stmt->execute([$full_name, $email, $admin_id]);
    } else {
        $sql = "UPDATE users SET full_name = ? WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $success = $stmt->execute([$full_name, $admin_id]);
    }

    if ($success) {
        setcookie('full_name', $full_name, [
            'expires' => time() + (30 * 24 * 60 * 60),
            'path' => '/',
            'secure' => true,   // Set to true for HTTPS
            'httponly' => true, // Crucial: Prevents JavaScript access
            'samesite' => 'Strict' // Best for security
        ]);

        echo json_encode([
            'success' => true,
            'message' => 'User information updated successfully'
        ]);
    } else {
        throw new Exception('Failed to update user information');
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
