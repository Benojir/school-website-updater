<?php
session_start();
$_SESSION['scripts_version'] = time();

require_once(__DIR__ . "/../../../includes/config.php");
require_once(__DIR__ . "/../../../includes/phpmailer.php");

header('Content-Type: application/json');

// Initialize response
// $response = ['status' => 'error', 'message' => 'Invalid request'];
$response = ['success' => false, 'message' => 'Invalid request'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $rememberMe = isset($_POST['remember']) && $_POST['remember'] === 'on';
    $hcaptcha_response = $_POST['h-captcha-response'] ?? '';
    $user_ip = getUserPublicIP();

    // Validate inputs
    if (empty($username)) {
        $response['message'] = 'Username is required';
    } elseif (empty($password)) {
        $response['message'] = 'Password is required';
    } elseif (empty($hcaptcha_response)) {
        $response['message'] = 'Please complete the captcha verification';
    } else {
        // Verify hCaptcha
        $hcaptcha_secret = $websiteConfig['captcha_secret_key']; // Replace with your actual secret key

        $verify_data = [
            'secret' => $hcaptcha_secret,
            'response' => $hcaptcha_response,
            'remoteip' => $user_ip
        ];

        $verify_response = file_get_contents($captchaVerifyUrl . '?' . http_build_query($verify_data));
        $verify_result = json_decode($verify_response, true);

        if (!$verify_result['success']) {
            $response['message'] = 'Captcha verification failed. Please try again.';
        } else {
            try {
                // Check user in database
                $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? LIMIT 1");
                $stmt->execute([$username]);
                $user = $stmt->fetch();

                if ($user && password_verify($password, $user['password'])) {

                    // Check if user is active
                    if ($user['status'] !== 'active' && $user['user_role'] === 'admin') {
                        $response['message'] = 'Your account is not active. Please contact administrator.';
                    } else {

                        $device_id = 'Web Browser';
                        $device_name = $_SERVER['HTTP_USER_AGENT'];
                        $session_source = 'web';

                        $token = bin2hex(random_bytes(32));
                        $tokenHash = hash('sha256', $token);

                        $durationDays = $rememberMe ? 30 : 1; // 30 days for remember me, 1 day for normal session
                        $expiry = date('Y-m-d H:i:s', strtotime("+$durationDays days"));
                        $cookieExpiryTime = $rememberMe ? (time() + (86400 * $durationDays)) : 0; // 0 = session cookie

                        $sql = "INSERT INTO admin_auth_sessions
                        (user_id, 
                        user_role, 
                        username, 
                        full_name, 
                        token_hash, 
                        device_id,
                        device_name, 
                        session_source, 
                        ip_address, 
                        expires_at, 
                        created_at) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";

                        $stmt = $pdo->prepare($sql);

                        $data = [
                            $user['id'],
                            $user['user_role'],
                            $user['username'],
                            $user['full_name'],
                            $tokenHash,
                            $device_id,
                            $device_name ?? 'Unknown',
                            $session_source,
                            $user_ip,
                            $expiry
                        ];

                        if ($stmt->execute($data)) {

                            setcookie('admin_auth_token', $token, [
                                'expires' => $cookieExpiryTime,
                                'path' => '/',
                                'secure' => true,   // Set to true for HTTPS
                                'httponly' => true, // Crucial: Prevents JavaScript access
                                'samesite' => 'Strict' // Best for security
                            ]);

                            setcookie('full_name', $user['full_name'], [
                                'expires' => $cookieExpiryTime,
                                'path' => '/',
                                'secure' => true,   // Set to true for HTTPS
                                'httponly' => true, // Crucial: Prevents JavaScript access
                                'samesite' => 'Strict' // Best for security
                            ]);

                            // Send new device login details to admin
                            $last_login_ip = isset($_COOKIE['last_login_ip']) ? $_COOKIE['last_login_ip'] : '';

                            if ($last_login_ip != $user_ip) {

                                setcookie('last_login_ip', $user_ip, [
                                    'expires' => $cookieExpiryTime,
                                    'path' => '/',
                                    'secure' => true,   // Set to true for HTTPS
                                    'httponly' => true, // Crucial: Prevents JavaScript access
                                    'samesite' => 'Strict' // Best for security
                                ]);

                                $email_template = __DIR__ . '/../../../assets/templates/email-templates/new-device-login-template.php';

                                if (file_exists($email_template)) {

                                    $email_content = file_get_contents($email_template);

                                    $replace_data = [
                                        '{{user_full_name}}' => $user['full_name'],
                                        '{{login_device_name}}' => $device_name ?? 'Unknown',
                                        '{{login_source}}' => ucwords($session_source),
                                        '{{detected_ip_address}}' => $user_ip,
                                        '{{login_time}}' => date('Y-m-d H:i:s'),
                                        '{{school_name}}' => $school_name,
                                        '{{current_year}}' => date('Y'),
                                        '{{user_profile_url}}' => BASE_URL . '/management/settings/admin-profile.php',
                                        '{{reset_password_url}}' => BASE_URL . '/management/auth/admin-forgot-password.php',
                                        '{{user_email}}' => $user['email']
                                    ];

                                    // Fix: Use $email_content variable instead of $email_template
                                    $email_content = str_replace(array_keys($replace_data), array_values($replace_data), $email_content);

                                    $subject = 'New Device Login Notification';
                                    $alt_body = "New Device Login Detected\n\n" .
                                        "Hello " . $user['full_name'] . ",\n\n" .
                                        "We detected a new sign-in to your account.\n\n" .
                                        "Device: " . ($device_name ?? 'Unknown') . "\n" .
                                        "Source: " . ucwords($session_source) . "\n" .
                                        "IP Address: " . $user_ip . "\n" .
                                        "Time: " . date('Y-m-d H:i:s') . "\n\n" .
                                        "If this wasn't you, please secure your account immediately.\n\n" .
                                        "Best regards,\n" . $school_name . " Security Team";

                                    sendMail($school_name, $user['email'], $user['full_name'], $subject, $email_content, $alt_body);
                                }
                            }

                            $response = [
                                'success' => true,
                                'message' => 'Login successful! Redirecting...'
                            ];
                        } else {
                            $response['message'] = 'Failed to create authentication session. Please try again.';
                        }
                    }
                } else {
                    $response['message'] = 'Invalid username or password';
                }
            } catch (PDOException $e) {
                $response['message'] = 'Database error: ' . $e->getMessage();
            }
        }
    }
}

echo json_encode($response);
