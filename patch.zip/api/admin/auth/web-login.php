<?php

/** @var PDO $pdo
 * @var string $assets_version
 * @var string $captchaVerifyUrl
 * @var array $websiteConfig
 */
session_start();
$_SESSION['assets_version'] = time();

require_once(__DIR__ . "/../../../includes/config.php");
require_once(__DIR__ . "/../../../includes/phpmailer.php");

header('Content-Type: application/json');

// Initialize response
// $response = ['status' => 'error', 'message' => 'Invalid request'];
$response = ['success' => false, 'message' => 'Invalid request'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = 'Invalid request method';
    echo json_encode($response);
    exit();
}

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');
$rememberMe = isset($_POST['remember']) && $_POST['remember'] === 'on';
$hcaptcha_response = $_POST['h-captcha-response'] ?? '';
$user_ip = getUserPublicIP();

// Validate inputs
if (empty($username)) {
    $response['message'] = 'Username is required';
    echo json_encode($response);
    exit;
}

if (empty($password)) {
    $response['message'] = 'Password is required';
    echo json_encode($response);
    exit;
}

if (empty($hcaptcha_response)) {
    $response['message'] = 'Please complete the captcha verification';
    echo json_encode($response);
    exit;
}

// Verify hCaptcha
$hcaptcha_secret = $websiteConfig['captcha_secret_key']; // Replace with your actual secret key

$verify_data = [
    'secret' => $hcaptcha_secret,
    'response' => $hcaptcha_response,
    'remoteip' => $user_ip
];

$verify_response = file_get_contents($captchaVerifyUrl . '?' . http_build_query($verify_data));
$verify_result = json_decode($verify_response, true);

if (!$verify_result['success']) {
    $response['message'] = 'Captcha verification failed. Please try again.';
    echo json_encode($response);
    exit;
}

try {
    // Check user in database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? LIMIT 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if (!$user) {
        $response['message'] = 'Invalid username or password';
        echo json_encode($response);
        exit;
    }

    // Check password
    if (!password_verify($password, $user['password'])) {
        $response['message'] = 'Invalid username or password';
        echo json_encode($response);
        exit;
    }

    // Check if user is active
    if ($user['status'] !== 'active' && $user['user_role'] === 'admin') {
        $response['message'] = 'Your account is not active. Please contact administrator.';
        echo json_encode($response);
        exit;
    }

    $device_id = 'Web Browser (' . $_SERVER['HTTP_USER_AGENT'] . ')';
    $device_name = $_SERVER['HTTP_USER_AGENT'];
    $session_source = 'web';

    $token = generateToken();
    $tokenHash = hash('sha256', $token);

    $durationDays = $rememberMe ? 30 : 1; // 30 days for remember me, 1 day for normal session
    $expiry = date('Y-m-d H:i:s', strtotime("+$durationDays days"));
    $cookieExpiryTime = $rememberMe ? (time() + (86400 * $durationDays)) : 0; // 0 = session cookie

    $stmt = $pdo->prepare(
        "INSERT INTO admin_auth_sessions 
        (user_id, token_hash, device_id, device_name, session_source, ip_address, expires_at, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW())"
    );

    $data = [
        $user['id'],
        $tokenHash,
        $device_id,
        $device_name ?? 'Unknown',
        $session_source,
        $user_ip,
        $expiry
    ];

    if ($stmt->execute($data) === false) {
        $response['message'] = 'Failed to create session';
        echo json_encode($response);
        exit;
    }

    $should_send_email = false;

    $username = $user['username'];
    $hashed_username = strtolower(hash('sha256', $username));

    if (!isset($_COOKIE[$hashed_username]) || $_COOKIE[$hashed_username] !== $hashed_username) {
        $should_send_email = true;

        setcookie($hashed_username, $hashed_username, [
            'expires' => time() + (86400 * 90), // 90 days
            'path' => '/',
            'secure' => true,
            'httponly' => true,
            'samesite' => 'Strict'
        ]);
    }

    setcookie('admin_auth_token', $token, [
        'expires' => $cookieExpiryTime,
        'path' => '/',
        'secure' => true,
        'httponly' => true,
        'samesite' => 'Strict'
    ]);


    if ($should_send_email) {

        $email_template = __DIR__ . '/../../../assets/templates/email-templates/new-device-login-template.php';

        if (file_exists($email_template)) {
            $email_content = file_get_contents($email_template);

            $replace_data = [
                '{{user_full_name}}' => $user['full_name'],
                '{{login_device_name}}' => $device_name ?? 'Unknown',
                '{{login_source}}' => ucwords($session_source),
                '{{detected_ip_address}}' => $user_ip,
                '{{login_time}}' => date('Y-m-d H:i:s'),
                '{{school_name}}' => $school_name,
                '{{current_year}}' => date('Y'),
                '{{user_profile_url}}' => BASE_URL . '/management/settings/admin-profile.php',
                '{{reset_password_url}}' => BASE_URL . '/management/auth/admin-forgot-password.php',
                '{{user_email}}' => $user['email']
            ];

            $email_content = str_replace(array_keys($replace_data), array_values($replace_data), $email_content);

            $subject = 'New Device Login Notification';
            $alt_body = "New Device Login Detected\n\n" .
                "Hello " . $user['full_name'] . ",\n\n" .
                "We detected a new sign-in to your account.\n\n" .
                "Device: " . ($device_name ?? 'Unknown') . "\n" .
                "Source: " . ucwords($session_source) . "\n" .
                "IP Address: " . $user_ip . "\n" .
                "Time: " . date('Y-m-d H:i:s') . "\n\n" .
                "If this wasn't you, please secure your account immediately.\n\n" .
                "Best regards,\n" . $school_name . " Security Team";

            // This will now take its time without keeping the user waiting!
            sendMail($school_name, $user['email'], $user['full_name'], $subject, $email_content, $alt_body);
        }
    }

    $response = ['success' => true];
    $response['message'] = 'Login successful. Redirecting...';
    echo json_encode($response);
    exit;
} catch (Exception $e) {
    $response['message'] = 'Database error: ' . $e->getMessage();
    echo json_encode($response);
    exit;
}