<?php
require_once __DIR__ . '/../../../includes/auth-check.php';

header('Content-Type: application/json');

$authData = authenticateAdminApiRequest($pdo);

$admin_id = $authData['user_id'];
$session_id = $authData['session_id'];

try {
    $stmt = $pdo->prepare("DELETE FROM admin_auth_sessions WHERE id != ? AND user_id = ?");
    $stmt->execute([$session_id, $admin_id]);
    echo json_encode(['success' => true, 'message' => 'Logged out of all devices successfully.']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'An error occurred while revoking the session: ' . $e->getMessage()]);
    exit;
}