<?php
require_once __DIR__ . '/../../../includes/config.php';
require_once __DIR__ . '/../../../includes/phpmailer.php';

// Rate limiting for OTP requests
if (!isset($_SESSION['otp_send_attempts'])) {
    $_SESSION['otp_send_attempts'] = 0;
    $_SESSION['otp_send_first_attempt'] = time();
}

// Check if too many attempts in the last 15 minutes
if ($_SESSION['otp_send_attempts'] >= 3) {
    $time_since_first_attempt = time() - $_SESSION['otp_send_first_attempt'];
    if ($time_since_first_attempt < 900) { // 15 minutes
        die(json_encode(['success' => false, 'message' => 'Too many OTP requests. Please try again after 15 minutes.']));
    } else {
        // Reset counter after 15 minutes
        $_SESSION['otp_send_attempts'] = 0;
        $_SESSION['otp_send_first_attempt'] = time();
    }
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(['success' => false, 'message' => 'Invalid request method']));
}

// Validate required fields first
$usernameOrEmail = sanitize_input($_POST['username'] ?? '');
$hcaptchaResponse = $_POST['h-captcha-response'] ?? '';

if (empty($usernameOrEmail) || empty($hcaptchaResponse)) {
    $_SESSION['otp_send_attempts']++;
    die(json_encode(['success' => false, 'message' => 'Username/email and captcha are required']));
}

// hCaptcha verification
$secretKey = $websiteConfig['captcha_secret_key'];

$data = array(
    'secret' => $secretKey,
    'response' => $hcaptchaResponse,
    'remoteip' => $_SERVER['REMOTE_ADDR'] ?? ''
);

$options = array(
    'http' => array(
        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
        'method' => 'POST',
        'content' => http_build_query($data),
        'timeout' => 10
    )
);

$context = stream_context_create($options);
$result = @file_get_contents($captchaVerifyUrl, false, $context);

if ($result === false) {
    $_SESSION['otp_send_attempts']++;
    die(json_encode(['success' => false, 'message' => 'Unable to verify captcha. Please try again.']));
}

$responseData = json_decode($result);

if (!$responseData || !$responseData->success) {
    $_SESSION['otp_send_attempts']++;
    $errorMessage = 'Captcha verification failed';
    if ($responseData && isset($responseData->{'error-codes'})) {
        error_log('hCaptcha verification failed: ' . implode(', ', $responseData->{'error-codes'}));
    }
    die(json_encode(['success' => false, 'message' => $errorMessage]));
}

try {
    // Check if user exists
    $stmt = $pdo->prepare("SELECT id, username, email, full_name, user_role FROM users WHERE username = ? OR email = ? LIMIT 1");
    $stmt->execute([$usernameOrEmail, $usernameOrEmail]);
    $admin = $stmt->fetch();

    if (!$admin) {
        $_SESSION['otp_send_attempts']++;
        // Use generic message to prevent username enumeration
        die(json_encode(['success' => false, 'message' => 'If this username/email exists, an OTP will be sent to the registered email.']));
    }

    // Generate cryptographically secure OTP
    $otp = generateOTP(6);
    
    // Determine email address based on user role
    $admin_email = "";
    if ($admin['user_role'] == 'superadmin' && $admin['id'] !== 1) {
        $admin_email = $websiteConfig['super_admin_email'];
    } else {
        $admin_email = $admin['email'];
    }

    // Validate email address
    if (empty($admin_email) || !filter_var($admin_email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['otp_send_attempts']++;
        error_log('Invalid email address for user: ' . $admin['username']);
        die(json_encode(['success' => false, 'message' => 'Invalid email configuration. Please contact system administrator.']));
    }

    // Prepare email content
    $senderName = $school_name;
    $recipientAddress = $admin_email;
    $recipientName = $admin['full_name'];
    $subject = 'Admin Password Reset OTP - ' . $school_name;
    
    // Create more professional HTML email template
    $htmlBody = "
    <div style='max-width: 600px; margin: 0 auto; font-family: Arial, sans-serif; line-height: 1.6; color: #333;'>
        <div style='background-color: #f8f9fa; padding: 20px; text-align: center; border-bottom: 3px solid #007bff;'>
            <h2 style='color: #007bff; margin: 0;'>{$school_name}</h2>
            <p style='margin: 5px 0 0 0; color: #666;'>Admin Password Reset</p>
        </div>
        
        <div style='padding: 30px 20px;'>
            <h3 style='color: #333; margin-bottom: 20px;'>Password Reset Request</h3>
            
            <p>Hello <strong>" . safe_htmlspecialchars($admin['full_name']) . "</strong>,</p>
            
            <p>You have requested to reset your admin password. Your username is:</p>
            <div style='background-color: #f8f9fa; padding: 15px; border-left: 4px solid #007bff; margin: 20px 0;'>
                <strong>" . safe_htmlspecialchars($admin['username']) . "</strong>
            </div>
            
            <p>Your One-Time Password (OTP) for resetting your admin password is:</p>
            <div style='background-color: #007bff; color: white; padding: 20px; text-align: center; border-radius: 5px; margin: 20px 0;'>
                <h1 style='margin: 0; font-size: 32px; letter-spacing: 5px;'>{$otp}</h1>
            </div>
            
            <div style='background-color: #fff3cd; border: 1px solid #ffeaa7; border-radius: 5px; padding: 15px; margin: 20px 0;'>
                <h4 style='color: #856404; margin: 0 0 10px 0;'>⚠️ Important Security Information:</h4>
                <ul style='color: #856404; margin: 0; padding-left: 20px;'>
                    <li>This OTP is valid for <strong>10 minutes only</strong></li>
                    <li>Do not share this OTP with anyone</li>
                    <li>If you did not request this password reset, please ignore this email</li>
                    <li>Contact your system administrator if you suspect unauthorized access</li>
                </ul>
            </div>
            
            <p style='color: #666; font-size: 14px; margin-top: 30px;'>
                This email was sent from an automated system. Please do not reply to this email.
            </p>
        </div>
        
        <div style='background-color: #f8f9fa; padding: 15px 20px; text-align: center; border-top: 1px solid #dee2e6;'>
            <p style='margin: 0; color: #666; font-size: 12px;'>
                © " . date('Y') . " {$school_name}. All rights reserved.
            </p>
        </div>
    </div>";
    
    $altBody = "Password Reset OTP for {$school_name}\n\n" .
               "Hello " . $admin['full_name'] . ",\n\n" .
               "Your username: " . $admin['username'] . "\n" .
               "Your OTP for resetting admin password: {$otp}\n\n" .
               "This OTP is valid for 10 minutes only.\n" .
               "Do not share this OTP with anyone.\n\n" .
               "If you did not request this password reset, please ignore this email.";

    // Send email
    $mail = sendMail($senderName, $recipientAddress, $recipientName, $subject, $htmlBody, $altBody);

    if ($mail['success']) {
        // Store OTP in session with timestamp and username
        $_SESSION['admin_password_reset_otp'] = $otp;
        $_SESSION['admin_password_reset_otp_time'] = time();
        $_SESSION['admin_password_reset_username'] = $usernameOrEmail;
        
        // Reset attempt counter on successful send
        $_SESSION['otp_send_attempts'] = 0;
        
        // Log successful OTP send (without logging the actual OTP)
        error_log("Password reset OTP sent successfully for user: " . $admin['username'] . " (ID: " . $admin['id'] . ") from IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));

        echo json_encode([
            'success' => true,
            'message' => 'An OTP has been sent to the registered email address (' . maskEmail($admin_email) . '). Please check your email and enter the OTP to proceed.'
        ]);
        exit();
    } else {
        $_SESSION['otp_send_attempts']++;
        error_log('Failed to send password reset email for user: ' . $admin['username'] . '. Error: ' . $mail['message']);
        echo json_encode([
            'success' => false,
            'message' => 'Failed to send email. Please try again or contact system administrator.'
        ]);
        exit();
    }
    
} catch (PDOException $e) {
    $_SESSION['otp_send_attempts']++;
    error_log('Database error in password reset OTP send: ' . $e->getMessage());
    die(json_encode(['success' => false, 'message' => 'Database error occurred. Please try again.']));
} catch (Exception $e) {
    $_SESSION['otp_send_attempts']++;
    error_log('General error in password reset OTP send: ' . $e->getMessage());
    die(json_encode(['success' => false, 'message' => 'An error occurred. Please try again.']));
}

/**
 * Generate cryptographically secure OTP
 * @param int $length Length of OTP
 * @return string Generated OTP
 */
function generateOTP($length = 6)
{
    $otp = '';
    for ($i = 0; $i < $length; $i++) {
        $otp .= random_int(0, 9);  // cryptographically secure random digit
    }
    return $otp;
}

/**
 * Mask email address for privacy
 * @param string $email Email address to mask
 * @return string Masked email address
 */
function maskEmail($email) {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return '***@***.***';
    }
    
    list($local, $domain) = explode('@', $email);
    $length = strlen($local);

    if ($length <= 2) {
        // e.g., ab@gmail.com → a*@gmail.com
        $maskedLocal = substr($local, 0, 1) . str_repeat('*', $length - 1);
    } elseif ($length <= 4) {
        // e.g., abcd@gmail.com → a**d@gmail.com
        $maskedLocal = substr($local, 0, 1)
                     . str_repeat('*', $length - 2)
                     . substr($local, -1);
    } else {
        // e.g., abcdefgh@gmail.com → ab***gh@gmail.com
        $maskedLocal = substr($local, 0, 2)
                     . str_repeat('*', $length - 4)
                     . substr($local, -2);
    }

    return $maskedLocal . '@' . $domain;
}
?>