<?php
require_once __DIR__ . '/../../includes/auth-check.php';
require_once __DIR__ . '/../../includes/driver/driver-payroll-access.php';
require_once __DIR__ . '/../../includes/driver/driver-payroll-service.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$auth = authenticateAdminApiRequest($pdo);
try {
    if (!canViewDriverPayroll()) throw new DriverPayrollDenied('Transport and financial-report permissions are required.');
    $service = new DriverPayrollService($pdo, (int)$auth['user_id']);
    $method = $_SERVER['REQUEST_METHOD'];
    if ($method === 'GET') {
        $action = $_GET['action'] ?? 'context';
        if ($action === 'context') $data = $service->context() + ['can_manage' => canManageDriverPayroll(), 'currency' => $currency_symbol];
        elseif ($action === 'ledger') $data = $service->ledger($service->id($_GET['driver_id'] ?? null), driverPayrollMonth($_GET['month'] ?? null));
        elseif ($action === 'report') $data = $service->report($_GET['from'] ?? '', $_GET['to'] ?? '', empty($_GET['driver_id']) ? null : $service->id($_GET['driver_id']), empty($_GET['salary_month']) ? null : driverPayrollMonth($_GET['salary_month']), (int)($_GET['page'] ?? 1));
        else throw new InvalidArgumentException('Unknown report.');
    } elseif ($method === 'POST') {
        if (!canManageDriverPayroll()) throw new DriverPayrollDenied('Expense-management permission is also required to record salaries.');
        if (empty($_SESSION['driver_payroll_csrf']) || !hash_equals($_SESSION['driver_payroll_csrf'], $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '')) throw new DriverPayrollDenied('This page expired. Reload before saving.');
        $raw = file_get_contents('php://input');
        if (strlen($raw) > 32768) throw new InvalidArgumentException('Request is too large.');
        $input = json_decode($raw, true, 32, JSON_THROW_ON_ERROR);
        if (!is_array($input) || array_is_list($input)) throw new InvalidArgumentException('Invalid request.');
        $data = $service->write($input);
    } else { http_response_code(405); header('Allow: GET, POST'); exit(json_encode(['success' => false, 'message' => 'Use GET or POST.'])); }
    echo json_encode(['success' => true, 'data' => $data], JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
} catch (DriverPayrollDenied $e) { http_response_code(403); echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} catch (DriverPayrollConflict $e) { http_response_code(409); echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} catch (InvalidArgumentException|JsonException $e) { http_response_code(422); echo json_encode(['success' => false, 'message' => $e instanceof JsonException ? 'Invalid request data.' : $e->getMessage()]);
} catch (Throwable $e) { error_log('Driver payroll: ' . $e->getMessage()); http_response_code(503); echo json_encode(['success' => false, 'message' => 'Driver salary is temporarily unavailable. Reload to check the latest records. If this continues, contact the administrator.']); }
