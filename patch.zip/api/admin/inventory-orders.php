<?php
require_once __DIR__ . '/../../includes/auth-check.php';
require_once __DIR__ . '/../../includes/inventory/inventory-order-service.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$admin = authenticateAdminApiRequest($pdo);
if (!hasPermission(PERM_MANAGE_INVENTORY)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'You do not have permission to manage inventory orders.']);
    exit;
}

$service = new InventoryOrderService($pdo, (int)$admin['user_id'], new StoreGateway($websiteConfig['razorpay_key_id'] ?? '', $websiteConfig['razorpay_key_secret'] ?? ''));

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $action = trim((string)($_GET['action'] ?? 'list'));
        if ($action === 'detail') {
            $orderId = inventoryInteger($_GET['id'] ?? 0, 'Order ID', 1, PHP_INT_MAX);
            $data = $service->getOrderDetail($orderId);
        } elseif ($action === 'list') {
            $data = $service->getAdminOrders($_GET);
        } else throw new InvalidArgumentException('Unknown order view.');
        echo json_encode(['success' => true, 'data' => $data], JSON_THROW_ON_ERROR);
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 131072) {
            throw new InvalidArgumentException('This request is too large.');
        }
        $input = json_decode(file_get_contents('php://input'), true, 64, JSON_THROW_ON_ERROR);
        if (!is_array($input)) {
            throw new InvalidArgumentException('Invalid request.');
        }
        if (!is_string($input['csrf'] ?? null) || empty($_SESSION['inventory_csrf']) || !hash_equals($_SESSION['inventory_csrf'], $input['csrf'])) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'Your session form token expired. Please refresh the page.']);
            exit;
        }

        $orderId = inventoryInteger($input['order_id'] ?? 0, 'Order ID', 1, PHP_INT_MAX);
        $status = inventoryText($input['status'] ?? '', 30, 'status');
        $options = [
            'collect_now' => ($input['collect_now'] ?? false) === true,
            'method' => inventoryText($input['method'] ?? 'cash', 20, 'payment method'),
            'settle_remaining' => ($input['settle_remaining'] ?? false) === true,
            'settlement_reason' => $input['settlement_reason'] ?? ''
        ];
        if (array_key_exists('received_amount', $input)) $options['received_amount'] = $input['received_amount'];

        // Release PHP session lock
        session_write_close();

        if ($status === 'check_payment') {
            $service->reconcile($service->getOrderDetail($orderId));
            $result = ['message'=>'Payment status checked with Razorpay.'];
        } else $result = $service->updateOrderStatus($orderId, $status, $options);
        echo json_encode(['success' => true, 'message' => $result['message'], 'data' => $result], JSON_THROW_ON_ERROR);
    } else {
        http_response_code(405);
        header('Allow: GET, POST');
        echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    }
} catch (InvalidArgumentException | JsonException $e) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} catch (Throwable $e) {
    error_log('Inventory orders: ' . $e->getMessage());
    $missing = $e instanceof PDOException && in_array($e->getCode(), ['42S02', '42S22'], true);
    http_response_code($missing ? 503 : 500);
    echo json_encode(['success' => false, 'message' => $missing ? 'Store orders are not ready. Ask the owner to review the Store migration.' : 'Unable to process this order. Refresh and check its status before retrying.']);
}
