<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_EXAMS)) {
    die("You do not have permission to perform this action.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['exam_id'])) {
    $exam_id = $_POST['exam_id'];

    $stmt = $pdo->prepare("DELETE FROM exams WHERE id = :id AND status = 'archived'");
    
    if ($stmt->execute([':id' => $exam_id])) {
        header("Location: ../../../../management/exam/archived-exams.php?deleted=1");
    } else {
        header("Location: ../../../../management/exam/archived-exams.php?deleted=0");
    }
    exit;
}
?>