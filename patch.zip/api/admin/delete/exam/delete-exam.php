<?php
/** @var PDO $pdo */
include_once("../../../../includes/auth-check.php");
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

if (!hasPermission(PERM_MANAGE_EXAMS)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

$exam_id = $_POST['exam_id'] ?? null;

if (!$exam_id) {
    echo json_encode(['success' => false, 'message' => 'Exam ID is required']);
    exit;
}

try {
    $stmt = $pdo->prepare("DELETE FROM exams WHERE id = :id");
    $stmt->execute([':id' => $exam_id]);

    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Exam deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Exam not found']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error']);
}
?>