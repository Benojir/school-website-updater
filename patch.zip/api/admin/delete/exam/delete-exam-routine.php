<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_EXAMS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        
        if ($id > 0) {
            // Check if routine exists
            $stmt = $pdo->prepare("SELECT id FROM exam_routines WHERE id = ?");
            $stmt->execute([$id]);
            
            if ($stmt->rowCount() > 0) {
                // Delete routine
                $delete_stmt = $pdo->prepare("DELETE FROM exam_routines WHERE id = ?");
                if ($delete_stmt->execute([$id])) {
                    $response['success'] = true;
                    $response['message'] = 'Exam routine deleted successfully!';
                } else {
                    throw new Exception('Failed to delete exam routine');
                }
            } else {
                throw new Exception('Exam routine not found');
            }
        } else {
            throw new Exception('Invalid routine ID');
        }
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);