<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to delete teachers
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to delete teachers.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = filter_var($_POST['id'], FILTER_VALIDATE_INT);
        if (!$id) {
            throw new Exception('Invalid teacher ID.');
        }

        // Check if teacher exists
        $check = $pdo->prepare("SELECT id, teacher_image FROM teachers WHERE id = ?");
        $check->execute([$id]);

        if ($check->rowCount() === 0) {
            throw new Exception('Teacher not found');
        }

        // Clean image from storage
        $teacher = $check->fetch(PDO::FETCH_ASSOC);
        $imageName = $teacher['teacher_image'] ?? null;

        if ($imageName && $imageName !== 'default_teacher_dp.jpg') {
            $imagePath =  __DIR__ . '/../../../../uploads/teachers/' . $imageName;
            if (file_exists($imagePath)) {
                @unlink($imagePath);
            }
        }

        // Delete teacher
        $stmt = $pdo->prepare("DELETE FROM teachers WHERE id = ?");
        $stmt->execute([$id]);

        $response['success'] = true;
        $response['message'] = 'Teacher deleted successfully';
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
