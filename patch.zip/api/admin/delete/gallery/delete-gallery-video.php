<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!hasPermission(PERM_MANAGE_SCHOOL_GALLERY)) {
    echo json_encode(['success' => false, 'message' => 'You do not have permission to manage photos from the gallery.']);
    exit();
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    $id = $_POST['id'] ?? 0;
    
    if (empty($id)) {
        throw new Exception('Invalid video ID');
    }

    // First check if the photo exists
    $stmt = $pdo->prepare("SELECT * FROM gallery_videos WHERE id = ?");
    $stmt->execute([$id]);
    $photo = $stmt->fetch();

    if (!$photo) {
        throw new Exception('Video not found');
    }

    // Delete from database
    $stmt = $pdo->prepare("DELETE FROM gallery_videos WHERE id = ?");
    $stmt->execute([$id]);

    echo json_encode([
        'success' => true,
        'message' => 'Video deleted successfully'
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>