<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!hasPermission(PERM_MANAGE_SCHOOL_GALLERY)) {
    echo json_encode(['success' => false, 'message' => 'You do not have permission to manage photos from the gallery.']);
    exit();
}

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Invalid request method');
    }

    $id = $_POST['id'] ?? 0;
    $delete_url = $_POST['delete_url'] ?? '';
    
    if (empty($id)) {
        throw new Exception('Invalid photo ID');
    }

    // First check if the photo exists
    $stmt = $pdo->prepare("SELECT * FROM gallery WHERE id = ?");
    $stmt->execute([$id]);
    $photo = $stmt->fetch();

    if (!$photo) {
        throw new Exception('Photo not found');
    }

    // Delete from ImgBB first (imgbb deletion not working)
    // if (!empty($photo['delete_url'])) {
    //     $ch = curl_init();
    //     curl_setopt($ch, CURLOPT_URL, $photo['delete_url']);
    //     curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
    //     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    //     $response = curl_exec($ch);
    //     $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    //     curl_close($ch);

    //     if ($httpCode !== 200) {
    //         throw new Exception('Failed to delete image from ImgBB');
    //     }
    // }

    // Delete from database
    $stmt = $pdo->prepare("DELETE FROM gallery WHERE id = ?");
    $stmt->execute([$id]);

    echo json_encode([
        'success' => true,
        'message' => 'Photo deleted successfully'
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>