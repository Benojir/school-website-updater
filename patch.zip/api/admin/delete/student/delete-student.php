<?php
/** @var PDO $pdo  */
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
require_once __DIR__ . '/../../../../includes/student/student-deletion-service.php';

header('Content-Type: application/json');

// Check if user has permission to delete students
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to delete students.'
    ]);
    die();
}

try {
    // Only accept POST requests for security
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Method Not Allowed');
    }

    $raw_ids = $_POST['student_ids'] ?? '';

    if (!is_scalar($raw_ids) || trim((string)$raw_ids) === '') {
        throw new Exception('No student IDs provided');
    }
    $raw_ids = (string)$raw_ids;

    // Sanitize and convert comma-separated string to array
    // Example: "101, 102, 103" -> ['101', '102', '103']
    $student_ids = array_filter(array_map('trim', explode(',', $raw_ids)));

    if (empty($student_ids)) {
        throw new Exception('Invalid student IDs format');
    }

    $result = deleteStudentsCompletely($pdo, $student_ids);
    $deleted_count = $result['deleted_count'];
    $uploadDir = __DIR__ . "/../../../../uploads/students/";

    // Files are removed only after the database transaction has committed.
    foreach ($result['images'] as $image) {
        $filePath = $uploadDir . $image;
        if (is_file($filePath)) @unlink($filePath);
    }

    if ($deleted_count === 0) {
        echo json_encode([
            'success' => true,
            'message' => 'No matching students found to delete.',
            'count' => 0
        ]);
    } else {
        echo json_encode([
            'success' => true,
            'message' => "Permanently deleted $deleted_count student(s) and all linked operational records.",
            'count' => $deleted_count
        ]);
    }

} catch (PDOException $e) {
    // Roll back transaction on database error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Throwable $e) {
    // Roll back generic errors
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
