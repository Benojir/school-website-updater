<?php
/** @var PDO $pdo  */
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to delete students
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to delete students.'
    ]);
    die();
}

try {
    // Only accept POST requests for security
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Method Not Allowed');
    }

    // Check if student_ids provided in REQUEST (covers POST and GET params)
    $raw_ids = $_REQUEST['student_ids'] ?? '';

    if (empty($raw_ids)) {
        throw new Exception('No student IDs provided');
    }

    // Sanitize and convert comma-separated string to array
    // Example: "101, 102, 103" -> ['101', '102', '103']
    $student_ids = array_filter(array_map('trim', explode(',', $raw_ids)));

    if (empty($student_ids)) {
        throw new Exception('Invalid student IDs format');
    }

    // Begin transaction
    $pdo->beginTransaction();

    // Prepare statements ONCE outside the loop for performance
    $selectStmt = $pdo->prepare("SELECT student_image FROM students WHERE student_id = ?");
    $deleteStmt = $pdo->prepare("DELETE FROM students WHERE student_id = ?");

    $deleted_count = 0;
    $uploadDir = __DIR__ . "/../../../../uploads/students/";

    foreach ($student_ids as $student_id) {
        // 1. Fetch the student data first (to get the image filename)
        $selectStmt->execute([$student_id]);
        $student_info = $selectStmt->fetch(PDO::FETCH_ASSOC);

        // If student doesn't exist, skip to next
        if (!$student_info) {
            continue;
        }

        // 2. Delete the image file if it exists and is not the default
        if (!empty($student_info['student_image']) && $student_info['student_image'] !== 'default_student_dp.jpg') {
            $filePath = $uploadDir . $student_info['student_image'];
            if (file_exists($filePath)) {
                // Suppress errors with @ in case of permission issues, so the DB delete still happens
                if(trim(strtolower($student_info['student_image'])) === 'default_student_dp.jpg'){
                    // Do nothing for default image + Double check
                } else {
                    @unlink($filePath);
                }
            }
        }

        // 3. Delete the student record from database
        $deleteStmt->execute([$student_id]);
        $deleted_count += $deleteStmt->rowCount();
    }

    // Commit the transaction
    $pdo->commit();

    if ($deleted_count === 0) {
        echo json_encode([
            'success' => true,
            'message' => 'No matching students found to delete.',
            'count' => 0
        ]);
    } else {
        echo json_encode([
            'success' => true,
            'message' => "Successfully deleted $deleted_count student(s).",
            'count' => $deleted_count
        ]);
    }

} catch (PDOException $e) {
    // Roll back transaction on database error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    // Roll back generic errors
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}