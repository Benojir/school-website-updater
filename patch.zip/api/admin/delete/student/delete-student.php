<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to delete students
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to delete students.'
    ]);
    die();
}

try {
    // Only accept POST requests for security
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Method Not Allowed', 405);
    }

    // Check if student_id is provided
    if (empty($_POST['student_id'])) {
        throw new Exception('Student ID is required', 400);
    }

    $student_id = $_POST['student_id'];

    // Begin transaction in case we need to delete related records
    $pdo->beginTransaction();

    // First check if student exists
    $checkStmt = $pdo->prepare("SELECT * FROM students WHERE student_id = ?");
    $checkStmt->execute([$student_id]);
    $student_info = $checkStmt->fetch(PDO::FETCH_ASSOC);
    
    if ($checkStmt->rowCount() === 0) {
        throw new Exception('Student not found', 404);
    }

    // Delete uploaded files associated with the student
    if($student_info['student_image'] !== 'default_student_dp.jpg') {
        $filePath = __DIR__ . "/../../../../uploads/students/" . $student_info['student_image'];
        if (file_exists($filePath)) {
            unlink($filePath);
        }
    }

    // Delete the student
    $deleteStmt = $pdo->prepare("DELETE FROM students WHERE student_id = ?");
    $deleteStmt->execute([$student_id]);

    // Commit the transaction
    $pdo->commit();

    // Return success response
    echo json_encode([
        'success' => true,
        'message' => 'Student deleted successfully',
        'student_id' => $student_id
    ]);

} catch (PDOException $e) {
    // Roll back transaction on error
    $pdo->rollBack();
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code($e->getCode() ?: 400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}