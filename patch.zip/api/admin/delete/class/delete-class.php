<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['class_id'])) {
    $class_id = $_POST['class_id'];
    
    try {
        // Check if this is the final class
        $stmt = $pdo->prepare("SELECT is_final_class FROM classes WHERE id = :id");
        $stmt->execute([':id' => $class_id]);
        $class = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($class && $class['is_final_class']) {
            $response['message'] = "Cannot delete the final class. Please mark another class as final first.";
            echo json_encode($response);
            exit();
        }
        
        // First delete all sections for this class
        $pdo->prepare("DELETE FROM sections WHERE class_id = :class_id")->execute([':class_id' => $class_id]);
        
        // Then delete the class
        $stmt = $pdo->prepare("DELETE FROM classes WHERE id = :id");
        if ($stmt->execute([':id' => $class_id])) {
            $response['success'] = true;
            $response['message'] = "Class and its sections deleted successfully!";
        }
    } catch (PDOException $e) {
        $response['message'] = "Error: " . $e->getMessage();
    }
} else {
    $response['message'] = "Invalid request";
}

echo json_encode($response);
?>