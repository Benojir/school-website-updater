<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['class_id'])) {
    $class_id = $_POST['class_id'];
    
    try {
        $pdo->beginTransaction();
        academicLockSettings($pdo);
        $history = $pdo->prepare('SELECT COUNT(*) FROM student_academic_records WHERE class_id = ? OR section_id IN (SELECT id FROM sections WHERE class_id = ?)');
        $history->execute([$class_id, $class_id]);
        if ((int)$history->fetchColumn() > 0) throw new RuntimeException('Academic history references this item. Keep it for historical records.');

        // Check if this is the final class
        $stmt = $pdo->prepare("SELECT is_final_class FROM classes WHERE id = :id");
        $stmt->execute([':id' => $class_id]);
        $class = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($class && $class['is_final_class']) {
            $pdo->rollBack();
            $response['message'] = "Cannot delete the final class. Please mark another class as final first.";
            echo json_encode($response);
            exit();
        }
        
        // First delete all sections for this class
        $pdo->prepare("DELETE FROM sections WHERE class_id = :class_id")->execute([':class_id' => $class_id]);
        
        // Then delete the class
        $stmt = $pdo->prepare("DELETE FROM classes WHERE id = :id");
        if ($stmt->execute([':id' => $class_id])) {
            $response['success'] = true;
            $response['message'] = "Class and its sections deleted successfully!";
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $response['message'] = "Error: " . $e->getMessage();
    }
} else {
    $response['message'] = "Invalid request";
}

echo json_encode($response);
?>