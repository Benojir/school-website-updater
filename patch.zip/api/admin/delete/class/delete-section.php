<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['section_id'])) {
    $section_id = $_POST['section_id'];
    
    try {
        $pdo->beginTransaction();
        academicLockSettings($pdo);
        $history = $pdo->prepare('SELECT COUNT(*) FROM student_academic_records WHERE section_id = ?');
        $history->execute([$section_id]);
        if ((int)$history->fetchColumn() > 0) throw new RuntimeException('Academic history references this item. Keep it for historical records.');

        $stmt = $pdo->prepare("DELETE FROM sections WHERE id = :id");
        if ($stmt->execute([':id' => $section_id])) {
            $response['success'] = true;
            $response['message'] = "Section deleted successfully!";
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $response['message'] = "Error: " . $e->getMessage();
    }
} else {
    $response['message'] = "Invalid request";
}

echo json_encode($response);
?>