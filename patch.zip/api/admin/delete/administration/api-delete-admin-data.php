<?php
// api-delete-data.php
include_once(__DIR__ . "/../../../../includes/auth-check.php");

if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

// 1. Delete Admin
if (isset($_POST['delete_admin_id'])) {
    $id = (int)$_POST['delete_admin_id'];
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND user_role = 'admin'");
    $stmt->execute([$id]);
    echo json_encode(['success' => true, 'message' => 'Admin deleted successfully!']);
    exit();
}

// 2. Delete Role
if (isset($_POST['delete_role_id'])) {
    $id = (int)($_POST['delete_role_id'] ?? 0);
    $pdo->beginTransaction();
    // Delete users associated with this role first
    $pdo->prepare("DELETE FROM users WHERE role_id = ? AND user_role = 'admin'")->execute([$id]);
    // Delete permissions (cascade usually handles this, but manual is safer)
    $pdo->prepare("DELETE FROM admin_permissions WHERE role_id = ?")->execute([$id]);
    // Delete role
    $pdo->prepare("DELETE FROM admin_roles WHERE id = ?")->execute([$id]);
    $pdo->commit();
    echo json_encode(['success' => true, 'message' => 'Role and associated admins deleted!']);
    exit();
}
