<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

if (!hasPermission(PERM_MANAGE_TRANSPORT)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['route_id'])) {
    $route_id = $_POST['route_id'];
    
    try {
        // Delete the route
        $stmt = $pdo->prepare("DELETE FROM driving_routes WHERE id = :id");
        if ($stmt->execute([':id' => $route_id])) {

            // Set null to driver_id in drivers table
            $stmt = $pdo->prepare("UPDATE drivers SET route_id = NULL WHERE route_id = :route_id");
            $stmt->execute([':route_id' => $route_id]);

            // Set null to driving_route_id in students table
            $stmt = $pdo->prepare("UPDATE students SET driving_route_id = NULL WHERE driving_route_id = :route_id");
            $stmt->execute([':route_id' => $route_id]);

            $response['success'] = true;
            $response['message'] = "Route deleted successfully.";
        }
    } catch (PDOException $e) {
        $response['message'] = "Error: " . $e->getMessage();
    }
} else {
    $response['message'] = "Invalid request";
}

echo json_encode($response);
?>