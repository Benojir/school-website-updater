<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

// Set header to JSON.
header('Content-Type: application/json');

// Check for permission.
if (!hasPermission('PERM_MANAGE_TRANSPORT')) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = (int)$_POST['id'];

        if ($id <= 0) {
            throw new Exception('Invalid driver ID provided.');
        }
        
        // Optional: Delete the driver's image file from the server.
        // First, get the image filename.
        $stmt = $pdo->prepare("SELECT driver_image FROM drivers WHERE id = ?");
        $stmt->execute([$id]);
        $driver = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($driver) {
            $imageFile = $driver['driver_image'];
            $defaultImages = ['default_driver_dp.jpg', null, ''];
            
            // If the image is not a default one, try to delete it.
            if (!in_array($imageFile, $defaultImages)) {
                $filePath = __DIR__ . '/../../../../uploads/drivers/' . $imageFile;
                if (file_exists($filePath)) {
                    unlink($filePath);
                }
            }
        }

        // Delete the driver record from the database.
        $deleteStmt = $pdo->prepare("DELETE FROM drivers WHERE id = ?");
        $deleteStmt->execute([$id]);

        // Remove driver id from students table and set null when drive delete
        $stmt = $pdo->prepare("UPDATE students SET driver_id = NULL WHERE driver_id = ?");
        $stmt->execute([$id]);

        $response['success'] = true;
        $response['message'] = 'Driver deleted successfully.';
    } else {
        throw new Exception('Invalid request method.');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
