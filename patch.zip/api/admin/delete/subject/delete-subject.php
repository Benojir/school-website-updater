<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        
        if ($id > 0) {
            // Check if subject exists
            $stmt = $pdo->prepare("SELECT id FROM subjects WHERE id = ?");
            $stmt->execute([$id]);
            
            if ($stmt->rowCount() > 0) {
                // Delete subject
                $delete_stmt = $pdo->prepare("DELETE FROM subjects WHERE id = ?");
                if ($delete_stmt->execute([$id])) {
                    $response['success'] = true;
                    $response['message'] = 'Subject deleted successfully!';
                } else {
                    throw new Exception('Failed to delete subject');
                }
            } else {
                throw new Exception('Subject not found');
            }
        } else {
            throw new Exception('Invalid subject ID');
        }
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);