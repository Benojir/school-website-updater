<?php
require_once __DIR__ . '/../../../../includes/auth-check.php';
require_once __DIR__ . '/../../../../includes/financial/fee-payment-reversal-service.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); header('Allow: POST'); exit;
}
if (!hasPermission(PERM_MANAGE_FEES)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Permission denied']); exit;
}
$headers = array_change_key_case(getallheaders(), CASE_LOWER);
$bearer = str_starts_with($headers['authentication'] ?? '', 'Bearer ');
if (!$bearer && (!is_string($_POST['csrf'] ?? null) || empty($_SESSION['fee_reversal_csrf'])
    || !hash_equals($_SESSION['fee_reversal_csrf'], $_POST['csrf']))) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Your form expired. Refresh this page before reversing a payment.']); exit;
}
$admin = getAuthenticatedAdmin($pdo);
$ids = $_POST['payment_ids'] ?? [];
$ids = is_array($ids) ? $ids : [$ids];
$type = (string)($_POST['payment_type'] ?? '');
$configured = !empty($websiteConfig['razorpay_key_id']) && !empty($websiteConfig['razorpay_key_secret']);
$confirm = (string)($_POST['confirm_online_refund'] ?? '') === '1';
session_write_close();
try {
    $result = (new FeePaymentReversalService($pdo, $configured))->reverse($type, $ids, (int)$admin['user_id'], $confirm);
    $refunds = [];
    if ($result['refund_order_ids']) {
        $service = new FeePaymentRefundService($pdo, new FeePaymentGateway($websiteConfig['razorpay_key_id'], $websiteConfig['razorpay_key_secret']));
        foreach ($result['refund_order_ids'] as $id) {
            try {
                $order = $service->process($id, true);
                $refunds[] = ['order_id' => $id, 'payment_status' => $order['payment_status'], 'refund_error' => $order['refund_error'] ?? null];
            } catch (Throwable $e) {
                error_log('Fee refund after reversal: ' . $e->getMessage());
                $refunds[] = ['order_id' => $id, 'payment_status' => 'refund_pending', 'refund_error' => 'Refund status could not be saved. Check Online Refunds before retrying.'];
            }
        }
    }
    $outstanding = count(array_filter($refunds, static fn($r) => $r['payment_status'] !== 'refunded'));
    $message = $result['count'] . ' payment record(s) reversed. Related fees and wallet balances were restored.';
    if ($refunds) $message .= $outstanding ? ' Refunds still need confirmation or attention. Open Online Refunds to check or retry.' : ' Online refunds are confirmed by Razorpay.';
    echo json_encode(['success' => true, 'message' => $message, 'refunds' => $refunds]);
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
