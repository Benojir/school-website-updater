<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// 1. Configuration Array
$tableConfigs = [
    'monthly' => [
        'history_table' => 'student_payment_history',
        'unpaid_table' => 'student_unpaid_fees',
        'partial_table' => 'student_partial_payments',
        'full_paid_table' => 'student_full_paid_fees',
        'unpaid_backup_col' => 'unpaid_fee_rows_backup',
        'partial_backup_col' => 'partial_payment_ids_backup',
        'full_paid_backup_col' => 'full_paid_payment_ids',
        'unpaid_identifier_col' => 'month_year',
        'partial_unpaid_fk' => 'unpaid_fees_id'
    ],
    'admission' => [
        'history_table' => 'admission_fees_payment_history',
        'unpaid_table' => 'admission_unpaid_fees',
        'partial_table' => 'admission_partial_fees_payments',
        'full_paid_table' => 'admission_full_paid_fees',
        'unpaid_backup_col' => 'unpaid_admission_fees_rows_backup',
        'partial_backup_col' => 'partial_payment_ids_backup',
        'full_paid_backup_col' => 'full_paid_admission_payment_ids',
        'unpaid_identifier_col' => 'academic_year',
        'partial_unpaid_fk' => 'unpaid_admission_fees_id'
    ]
];

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

// Who is performing this deletion (stored in the delete log)
$deletingAdmin = getAuthenticatedAdmin($pdo);
$deleted_by = $deletingAdmin['user_id'] ?? null;

// 2. Get and Validate payment_type
if (!isset($_REQUEST['payment_type']) || !array_key_exists($_REQUEST['payment_type'], $tableConfigs)) {
    echo json_encode(['success' => false, 'message' => 'Invalid fee type specified.']);
    exit;
}
$payment_type = $_REQUEST['payment_type'];
$config = $tableConfigs[$payment_type]; // Load the correct configuration

// Validate payment_type
if ($payment_type !== 'admission' && $payment_type !== 'monthly') {
    echo json_encode(['success' => false, 'message' => 'Invalid fees type provided.']);
    exit;
}

if (!isset($_REQUEST['payment_ids']) || empty($_REQUEST['payment_ids'])) {
    echo json_encode(['success' => false, 'message' => 'No payments selected']);
    exit;
}

$payment_ids = is_array($_REQUEST['payment_ids']) ? $_REQUEST['payment_ids'] : [$_REQUEST['payment_ids']];
$payment_ids = array_filter($payment_ids, fn($id) => !empty($id) && is_numeric($id));

if (empty($payment_ids)) {
    echo json_encode(['success' => false, 'message' => 'No valid payment IDs provided']);
    exit;
}

$pdo->beginTransaction();

try {
    // Get all payment details using the config variable
    $placeholders = implode(',', array_fill(0, count($payment_ids), '?'));
    $stmt = $pdo->prepare("SELECT * FROM {$config['history_table']} WHERE id IN ($placeholders) ORDER BY payment_date DESC");
    $stmt->execute($payment_ids);
    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$payments) {
        echo json_encode(['success' => false, 'message' => 'No payments found.']);
        exit;
    }

    foreach ($payments as $payment) {
        $student_id = $payment['student_id'];
        $stmt = $pdo->prepare("SELECT id FROM {$config['history_table']} WHERE student_id = ? ORDER BY id DESC LIMIT 1");
        $stmt->execute([$student_id]);
        $student_last_payment_id = $stmt->fetchColumn();

        if ($student_last_payment_id > $payment['id']) {
            $pdo->rollBack(); // Important to rollback before exiting
            echo json_encode([
                'success' => false,
                'message' => 'This payment cannot be deleted because there are newer payments recorded for this student. Please delete the most recent payments first.'
            ]);
            exit;
        }

        // Restore unpaid fees if they exist (using config variables)
        if (!empty($payment[$config['unpaid_backup_col']])) {
            $unpaid_fees = json_decode($payment[$config['unpaid_backup_col']], true) ?? [];
            foreach ($unpaid_fees as $fee) {
                // 1. Delete currently existing unpaid rows for this period (clean state)
                $stmt = $pdo->prepare("DELETE FROM {$config['unpaid_table']} WHERE {$config['unpaid_identifier_col']} = ? AND student_id = ?");
                $stmt->execute([$fee[$config['unpaid_identifier_col']], $fee['student_id']]);

                // 2. Insert the restored row (from backup)
                if ($payment_type === 'admission') {
                    $stmt = $pdo->prepare("INSERT INTO {$config['unpaid_table']} (student_id, academic_year, class_id, actual_amount, unpaid_amount, discount_amount, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
                    $stmt->execute([$fee['student_id'], $fee['academic_year'], $fee['class_id'], $fee['actual_amount'], $fee['unpaid_amount'], $fee['discount_amount'], $fee['remark']]);
                } else { // Monthly
                    $stmt = $pdo->prepare("INSERT INTO {$config['unpaid_table']} (student_id, month_year, actual_amount, unpaid_amount, discount_amount, remark, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
                    $stmt->execute([$fee['student_id'], $fee['month_year'], $fee['actual_amount'], $fee['unpaid_amount'], $fee['discount_amount'], $fee['remark']]);
                }
                
                $new_unpaid_fee_id = $pdo->lastInsertId();

                // 3. Link old partial payments to this restored ID
                // CHECK: Only do this if the backup HAS an ID (Regular payment). 
                // If it's an Advance Payment (Virtual Backup), 'id' will be missing, so we skip this.
                if (isset($fee['id'])) {
                    $stmt = $pdo->prepare("UPDATE {$config['partial_table']} SET {$config['partial_unpaid_fk']} = ? WHERE {$config['partial_unpaid_fk']} = ?");
                    $stmt->execute([$new_unpaid_fee_id, $fee['id']]);
                }
            }
        }

        // Delete partial payments created by THIS transaction
        if (!empty($payment[$config['partial_backup_col']])) {
            $partial_ids = json_decode($payment[$config['partial_backup_col']], true) ?? [];
            foreach ($partial_ids as $id) {
                $stmt = $pdo->prepare("DELETE FROM {$config['partial_table']} WHERE id = ?");
                $stmt->execute([$id]);
            }
        }

        // Delete full paid fees created by THIS transaction
        if (!empty($payment[$config['full_paid_backup_col']])) {
            $full_paid_ids = json_decode($payment[$config['full_paid_backup_col']], true) ?? [];
            foreach ($full_paid_ids as $id) {
                $stmt = $pdo->prepare("DELETE FROM {$config['full_paid_table']} WHERE id = ?");
                $stmt->execute([$id]);
            }
        }

        // Wallet processing
        $stmt = $pdo->prepare("SELECT * FROM student_wallet WHERE student_id = ? LIMIT 1");
        $stmt->execute([$payment['student_id']]);
        $wallet = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!empty($wallet)) {
            // Revert balance
            // If payment method was wallet: We ADD back to wallet.
            // If payment created wallet credit (wallet_affected_balance > 0): We SUBTRACT from wallet.
            $updated_balance = ($payment['method'] == 'wallet')
                ? $wallet['balance'] + $payment['wallet_affected_balance']
                : $wallet['balance'] - $payment['wallet_affected_balance'];
            
            $stmt = $pdo->prepare("UPDATE student_wallet SET balance = ? WHERE id = ?");
            $stmt->execute([$updated_balance, $wallet['id']]);
        }

        if (!empty($payment['wallet_transaction_id'])) {
            $stmt = $pdo->prepare("DELETE FROM wallet_transactions WHERE transaction_id = ?");
            $stmt->execute([$payment['wallet_transaction_id']]);
        }
    }

    // Store an audit record of every payment that is about to be removed, so the
    // admin can review deleted payments later from the delete log page.
    // Only IDs are stored - the log page joins `students` and `users` for the names.
    $log_stmt = $pdo->prepare("INSERT INTO deleted_payment_logs
        (payment_type, original_payment_id, student_id, payment_amount, payment_date, payment_remark,
         method, wallet_affected_balance, wallet_transaction_id, payment_entry_by,
         payment_recorded_at, payment_snapshot, deleted_by, deleted_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");

    foreach ($payments as $payment) {
        $log_stmt->execute([
            $payment_type,
            $payment['id'],
            $payment['student_id'],
            $payment['payment_amount'],
            $payment['payment_date'],
            $payment['remark'],
            $payment['method'],
            $payment['wallet_affected_balance'],
            $payment['wallet_transaction_id'],
            $payment['entry_by'],
            $payment['updated_at'] ?? null,
            json_encode($payment, JSON_UNESCAPED_UNICODE),
            $deleted_by
        ]);
    }

    // Finally delete the payment history records
    $stmt = $pdo->prepare("DELETE FROM {$config['history_table']} WHERE id IN ($placeholders)");
    $stmt->execute($payment_ids);

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => count($payment_ids) . ' payment records deleted successfully.'
    ]);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}