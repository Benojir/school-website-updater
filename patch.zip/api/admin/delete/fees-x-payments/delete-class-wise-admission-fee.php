<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $admission_type = isset($_POST['admission_type']) ? trim($_POST['admission_type']) : '';

        $allowed_admission_type = ['new-admission', 're-admission'];

        if (!in_array($admission_type, $allowed_admission_type, true)) {
            // ❌ Invalid admission type or empty/null admission type
            throw new Exception('Invalid admission type');
        }

        $table_name = "class_wise_new_admission_fees";

        if ($admission_type == $allowed_admission_type[1]) {
            $table_name = "class_wise_re_admission_fees";
        }
        
        if ($id > 0) {
            // Check if class wise fee exists
            $stmt = $pdo->prepare("SELECT id FROM `{$table_name}` WHERE id = ?");
            $stmt->execute([$id]);
            
            if ($stmt->rowCount() > 0) {
                // Delete class wise fee
                $delete_stmt = $pdo->prepare("DELETE FROM `{$table_name}` WHERE id = ?");
                if ($delete_stmt->execute([$id])) {
                    $response['success'] = true;
                    $response['message'] = "Admission fee deleted successfully from {$admission_type} fees!";
                } else {
                    throw new Exception("Failed to delete admission fee from {$admission_type} fees");
                }
            } else {
                throw new Exception("Admission fee not found in {$admission_type} fees");
            }
        } else {
            throw new Exception("Invalid admission fee ID");
        }
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);