<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$additional_fee_id = $_POST['additional_fee_id'] ?? null;
$student_id = $_POST['student_id'] ?? null;

if (!$additional_fee_id || !$student_id) {
    echo json_encode(array(
        "success" => false,
        "message" => "Missing required parameters.",
        "error" => "Missing parameters: additional_fee_id, student_id"
    ));
    exit();
}

try {
    $sql = "DELETE FROM additional_fees_data WHERE additional_fee_setup_id = ? AND student_id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$additional_fee_id, $student_id]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(array(
            "success" => true,
            "message" => "Additional fee entry deleted successfully."
        ));
    } else {
        echo json_encode(array(
            "success" => false,
            "message" => "No additional fee entry found with the given ID.",
            "error" => "No additional fee entry found with the given ID. Student ID: $student_id, Additional Fee ID: $additional_fee_id"
        ));
    }

    
} catch (Exception $e) {
    echo json_encode(array(
        "success" => false,
        "message" => "An error occurred while deleting the additional fee entry.",
        "error" => $e->getMessage()
    ));
}