<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        
        if ($id > 0) {
            // Check if class wise fee exists
            $stmt = $pdo->prepare("SELECT id FROM class_wise_additional_fees WHERE id = ?");
            $stmt->execute([$id]);
            
            if ($stmt->rowCount() > 0) {
                // Delete class wise fee
                $delete_stmt = $pdo->prepare("DELETE FROM class_wise_additional_fees WHERE id = ?");
                if ($delete_stmt->execute([$id])) {
                    $response['success'] = true;
                    $response['message'] = 'Additional fee setup deleted successfully!';
                } else {
                    throw new Exception('Failed to delete additional fee setup');
                }
            } else {
                throw new Exception('Additional fee setup not found');
            }
        } else {
            throw new Exception('Invalid ID');
        }
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);