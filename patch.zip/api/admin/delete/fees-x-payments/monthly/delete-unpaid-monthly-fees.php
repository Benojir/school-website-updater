<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'error' => true
    ]);
    die();
}

$student_ids = $_REQUEST['student_ids'] ?? null;
$month_year = $_REQUEST['period'] ?? null;

if (!$student_ids || !$month_year) {
    echo json_encode(['success' => false, 'message' => 'Student IDs and month_year are required']);
    exit;
}

if (!is_array($student_ids)) {
    $student_ids = explode(',', $student_ids);
}

$skipped = 0;
$processed = 0;

foreach ($student_ids as $student_id) {
    $student_id = trim($student_id);

    // First fetch unpaid fees for the student
    $stmt = $pdo->prepare("SELECT * FROM student_unpaid_fees WHERE student_id = :student_id AND month_year = :month_year");
    $stmt->execute(['student_id' => $student_id, 'month_year' => $month_year]);
    $unpaid_fees = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$unpaid_fees || count($unpaid_fees) == 0) {
        $skipped++;
        continue;
    }

    foreach ($unpaid_fees as $unpaid_fee) {
        $offer_amount = $unpaid_fee['actual_amount'] - $unpaid_fee['discount_amount'];
        $pending_amount = $unpaid_fee['unpaid_amount'];

        if ($pending_amount == $offer_amount) {
            $stmt = $pdo->prepare("DELETE FROM student_unpaid_fees WHERE id = :id");
            $stmt->execute(['id' => $unpaid_fee['id']]);
            $processed++;
        } else {
            $skipped++;
        }
    }
}

echo json_encode([
    'success' => true,
    'message' => 'Unpaid monthly fees deleted successfully'
]);