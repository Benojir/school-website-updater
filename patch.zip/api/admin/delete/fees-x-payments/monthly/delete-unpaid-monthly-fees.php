<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../../includes/auth-check.php");
require_once __DIR__ . '/../../../../../includes/financial/monthly-fee-ledger.php';

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'error' => true
    ]);
    die();
}

$student_ids = $_REQUEST['student_ids'] ?? null;
$month_year = $_REQUEST['period'] ?? null;

if (!$student_ids || !$month_year) {
    echo json_encode(['success' => false, 'message' => 'Student IDs and month_year are required']);
    exit;
}

if (!is_array($student_ids)) {
    $student_ids = explode(',', $student_ids);
}

$skipped = 0;
$processed = 0;

foreach ($student_ids as $student_id) {
    $student_id = trim($student_id);
    try {
        $pdo->beginTransaction();
        $lock = $pdo->prepare('SELECT student_id FROM students WHERE student_id = ? FOR UPDATE');
        $lock->execute([$student_id]);
        $stmt = $pdo->prepare("SELECT * FROM student_unpaid_fees WHERE student_id = :student_id AND month_year = :month_year FOR UPDATE");
        $stmt->execute(['student_id' => $student_id, 'month_year' => $month_year]);
        $unpaid_fees = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $studentProcessed = 0;
        $studentSkipped = $unpaid_fees ? 0 : 1;
        foreach ($unpaid_fees as $unpaid_fee) {
            $offer_amount = MonthlyFeeLedger::cents($unpaid_fee['actual_amount']) - MonthlyFeeLedger::cents($unpaid_fee['discount_amount']);
            if (MonthlyFeeLedger::cents($unpaid_fee['unpaid_amount']) === $offer_amount) {
                (new MonthlyFeeLedger($pdo))->cancel($unpaid_fee);
                $stmt = $pdo->prepare("DELETE FROM student_unpaid_fees WHERE id = :id");
                $stmt->execute(['id' => $unpaid_fee['id']]);
                $studentProcessed++;
            } else {
                $studentSkipped++;
            }
        }
        $pdo->commit();
        $processed += $studentProcessed;
        $skipped += $studentSkipped;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $skipped++;
    }
}

echo json_encode([
    'success' => true,
    'message' => 'Unpaid monthly fees deletion completed',
    'processed' => $processed,
    'skipped' => $skipped
]);
