<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
require_once __DIR__ . '/../../../../includes/financial/monthly-fee-ledger.php';

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'error' => true
    ]);
    die();
}

$entry_id = $_POST['entry_id'] ?? '';
$fees_type = $_POST['fees_type'] ?? '';

if (empty($entry_id)) {
    echo json_encode(['success' => false, 'message' => 'Unpaid Monthly Fee ID is required']);
    exit;
}

if (!is_numeric($entry_id)) {
    echo json_encode(['success' => false, 'message' => 'Invalid Unpaid Monthly Fee ID']);
    exit;
}

if (empty($fees_type)) {
    echo json_encode(['success' => false, 'message' => 'Fees type is required']);
    exit;
}

if ($fees_type !== 'monthly' && $fees_type !== 'admission') {
    echo json_encode(['success' => false, 'message' => 'Invalid fees type']);
    exit;
}

$table_name = '';

if ($fees_type === 'admission') {
    $table_name = 'admission_unpaid_fees';
} else {
    $table_name = 'student_unpaid_fees';
}

// Fetch the student id and name
$stmt = $pdo->prepare("SELECT student_id FROM $table_name WHERE id = :entry_id");
$stmt->bindParam(':entry_id', $entry_id, PDO::PARAM_INT);
$stmt->execute();
$student_id = $stmt->fetchColumn();

if (!$student_id) {
    echo json_encode(['success' => false, 'message' => "Unpaid $fees_type fee entry not found"]);
    exit;
}

if ($fees_type === 'monthly') {
    try {
        $pdo->beginTransaction();
        $lock = $pdo->prepare('SELECT student_id FROM students WHERE student_id = ? FOR UPDATE');
        $lock->execute([$student_id]);
        $lock = $pdo->prepare('SELECT * FROM student_unpaid_fees WHERE id = ? AND student_id = ? FOR UPDATE');
        $lock->execute([$entry_id, $student_id]);
        $fee = $lock->fetch(PDO::FETCH_ASSOC);
        if (!$fee) throw new DomainException('This bill no longer exists.');
        (new MonthlyFeeLedger($pdo))->cancel($fee);
        $delete = $pdo->prepare('DELETE FROM student_unpaid_fees WHERE id = ?');
        $delete->execute([$entry_id]);
        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Unpaid monthly bill deleted.', 'data' => ['student_id' => $student_id]]);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// Get student name
$stmt = $pdo->prepare("SELECT name FROM students WHERE id = :student_id");
$stmt->bindParam(':student_id', $student_id, PDO::PARAM_INT);
$stmt->execute();
$student_name = $stmt->fetchColumn();


// Prepare and execute the delete statement
$stmt = $pdo->prepare("DELETE FROM $table_name WHERE id = :entry_id");
$stmt->bindParam(':entry_id', $entry_id, PDO::PARAM_INT);

if ($stmt->execute()) {
    echo json_encode([
        'success' => true,
        'message' => "Unpaid $fees_type fee entry deleted successfully",
        'data' => [
            'student_id' => $student_id,
            'student_name' => $student_name
        ]
    ]);
} else {
    echo json_encode(['success' => false, 'message' => "Failed to delete unpaid $fees_type fee entry"]);
}
