<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'error' => true
    ]);
    die();
}

$entry_id = $_POST['entry_id'] ?? '';
$fees_type = $_POST['fees_type'] ?? '';

if (empty($entry_id)) {
    echo json_encode(['success' => false, 'message' => 'Unpaid Monthly Fee ID is required']);
    exit;
}

if (!is_numeric($entry_id)) {
    echo json_encode(['success' => false, 'message' => 'Invalid Unpaid Monthly Fee ID']);
    exit;
}

if (empty($fees_type)) {
    echo json_encode(['success' => false, 'message' => 'Fees type is required']);
    exit;
}

if ($fees_type !== 'monthly' && $fees_type !== 'admission') {
    echo json_encode(['success' => false, 'message' => 'Invalid fees type']);
    exit;
}

$table_name = '';

if ($fees_type === 'admission') {
    $table_name = 'admission_unpaid_fees';
} else {
    $table_name = 'student_unpaid_fees';
}

// Fetch the student id and name
$stmt = $pdo->prepare("SELECT student_id FROM $table_name WHERE id = :entry_id");
$stmt->bindParam(':entry_id', $entry_id, PDO::PARAM_INT);
$stmt->execute();
$student_id = $stmt->fetchColumn();

if (!$student_id) {
    echo json_encode(['success' => false, 'message' => "Unpaid $fees_type fee entry not found"]);
    exit;
}

// Get student name
$stmt = $pdo->prepare("SELECT name FROM students WHERE id = :student_id");
$stmt->bindParam(':student_id', $student_id, PDO::PARAM_INT);
$stmt->execute();
$student_name = $stmt->fetchColumn();


// Prepare and execute the delete statement
$stmt = $pdo->prepare("DELETE FROM $table_name WHERE id = :entry_id");
$stmt->bindParam(':entry_id', $entry_id, PDO::PARAM_INT);

if ($stmt->execute()) {
    echo json_encode([
        'success' => true,
        'message' => "Unpaid $fees_type fee entry deleted successfully",
        'data' => [
            'student_id' => $student_id,
            'student_name' => $student_name
        ]
    ]);
} else {
    echo json_encode(['success' => false, 'message' => "Failed to delete unpaid $fees_type fee entry"]);
}
