<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_RESULTS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    die();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$result_id = $_POST['result_id'] ?? '';
if (empty($result_id)) {
    echo json_encode(['success' => false, 'message' => 'Result ID is required']);
    exit;
}

try {
    $pdo->beginTransaction();
    
    // First delete subject marks
    $stmt = $pdo->prepare("DELETE FROM subject_marks WHERE result_id = ?");
    $stmt->execute([$result_id]);
    
    // Then delete the main result
    $stmt = $pdo->prepare("DELETE FROM results WHERE id = ?");
    $stmt->execute([$result_id]);
    
    $pdo->commit();
    
    echo json_encode(['success' => true, 'message' => 'Result deleted successfully']);
} catch (PDOException $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}