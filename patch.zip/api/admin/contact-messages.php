<?php
require_once __DIR__ . '/../../includes/auth-check.php';
require_once __DIR__ . '/../../includes/contact-message-service.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
authenticateAdminApiRequest($pdo);

function adminContactResponse(int $status, array $data): never
{
    http_response_code($status);
    exit(json_encode($data));
}

if (!hasPermission(PERM_MANAGE_CONTACT_MESSAGES)) {
    adminContactResponse(403, ['success' => false, 'message' => 'You do not have permission to manage contact messages.']);
}
try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $search = contactMessageText($_GET, 'search', 100, false);
        $status = contactMessageText($_GET, 'status', 10, false);
        if (!in_array($status, ['', 'unread', 'read'], true)) {
            throw new InvalidArgumentException('Invalid message status.');
        }
        $page = filter_var($_GET['page'] ?? '1', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($page === false) throw new InvalidArgumentException('Invalid page number.');
        $conditions = [];
        $params = [];
        if ($search !== '') {
            $conditions[] = '(name LIKE ? OR phone LIKE ? OR subject LIKE ? OR message LIKE ?)';
            $params = array_fill(0, 4, '%' . $search . '%');
        }
        if ($status !== '') {
            $conditions[] = 'is_read = ?';
            $params[] = $status === 'read' ? 1 : 0;
        }
        $where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';
        $count = $pdo->prepare('SELECT COUNT(*) FROM contact_messages' . $where);
        $count->execute($params);
        $total = (int) $count->fetchColumn();
        $pages = max(1, (int) ceil($total / 20));
        $page = min($page, $pages);
        $list = $pdo->prepare('SELECT id, name, phone, subject, LEFT(message, 160) AS preview, is_read, created_at, read_at FROM contact_messages'
            . $where . ' ORDER BY created_at DESC, id DESC LIMIT 20 OFFSET ' . (($page - 1) * 20));
        $list->execute($params);
        $summary = $pdo->query('SELECT COUNT(*) AS total, COALESCE(SUM(is_read = 0), 0) AS unread FROM contact_messages')->fetch(PDO::FETCH_ASSOC);
        adminContactResponse(200, ['success' => true, 'messages' => $list->fetchAll(PDO::FETCH_ASSOC),
            'page' => $page, 'pages' => $pages, 'total' => $total, 'summary' => $summary]);
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        header('Allow: GET, POST');
        adminContactResponse(405, ['success' => false, 'message' => 'Unsupported request method.']);
    }
    if (!contactMessageCsrfValid($_SESSION['admin_contact_csrf'] ?? null, $_SERVER['HTTP_X_CSRF_TOKEN'] ?? null)) {
        adminContactResponse(403, ['success' => false, 'message' => 'Your session expired. Reload this page before making changes.']);
    }
    $input = json_decode(file_get_contents('php://input'), true, 8, JSON_THROW_ON_ERROR);
    if (!is_array($input)) throw new InvalidArgumentException('Invalid request.');
    $id = filter_var($input['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $action = $input['action'] ?? '';
    if ($id === false || !in_array($action, ['open', 'read', 'unread', 'delete'], true)) {
        throw new InvalidArgumentException('Invalid message or action.');
    }
    $statement = $pdo->prepare('SELECT * FROM contact_messages WHERE id = ?');
    $statement->execute([$id]);
    $message = $statement->fetch(PDO::FETCH_ASSOC);
    if (!$message) adminContactResponse(404, ['success' => false, 'message' => 'This message no longer exists.']);
    if ($action === 'delete') {
        $statement = $pdo->prepare('DELETE FROM contact_messages WHERE id = ?');
        $statement->execute([$id]);
    } else {
        $read = $action !== 'unread';
        $readAt = $read ? ($message['read_at'] ?? date('Y-m-d H:i:s')) : null;
        $statement = $pdo->prepare('UPDATE contact_messages SET is_read = ?, read_at = ? WHERE id = ?');
        $statement->execute([$read ? 1 : 0, $readAt, $id]);
        $message['is_read'] = $read ? 1 : 0;
        $message['read_at'] = $readAt;
    }
    adminContactResponse(200, ['success' => true, 'message' => $action === 'delete' ? 'Message deleted.' : 'Message status updated.',
        'data' => $action === 'open' ? $message : null]);
} catch (InvalidArgumentException | JsonException $error) {
    adminContactResponse(422, ['success' => false, 'message' => 'Invalid request. Please check the search, message and action.']);
} catch (Throwable $error) {
    error_log('Admin contact messages: ' . $error->getMessage());
    adminContactResponse(503, ['success' => false, 'message' => 'Contact messages are unavailable. Please try again later.']);
}
