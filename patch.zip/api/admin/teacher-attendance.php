<?php
require_once __DIR__ . '/../../includes/auth-check.php';
require_once __DIR__ . '/../../includes/teacher/staff-attendance-service.php';
header('Content-Type: application/json');
header('Cache-Control: no-store');
$auth=authenticateAdminApiRequest($pdo);
try {
    if(!hasPermission(PERM_MANAGE_TEACHERS_ATTENDANCE)) throw new StaffAttendanceDenied('Teacher attendance permission is required.');
    $service=new StaffAttendanceService($pdo,(int)$auth['user_id']);
    $finance=isSuperAdmin();
    if($_SERVER['REQUEST_METHOD']==='GET') {
        if(($_GET['action']??'')==='daily') {
            $data=$service->dailyAttendance(staffDate($_GET['date']??$service->today()));
        } elseif(($_GET['action']??'')==='payments') {
            if(!$finance) throw new StaffAttendanceDenied('Only the super administrator can view salary payments.');
            $data=$service->paymentReport(staffMonth($_GET['month']??null),$_GET['basis']??'salary_month');
        } elseif(($_GET['action']??'')==='settings') {
            if(!$finance) throw new StaffAttendanceDenied('Only the super administrator can view personal settings.');
            $data=$service->teacherSettings($service->id($_GET),staffDate($_GET['date']??$service->today()));
        } elseif(($_GET['action']??'')==='review_queue') {
            $data=$service->reviewQueue(staffMonth($_GET['month']??null));
        } elseif(($_GET['action']??'')==='report') {
            $data=$service->report($service->id($_GET),staffMonth($_GET['month']??null));
            if(!$finance) {
                if(isset($data['attendance_days'])) $data['days']=$data['attendance_days'];
                $data=array_intersect_key($data,array_flip(['month','teacher_id','teacher_name','days','records','events','audit','review_locked']));
                foreach($data['days'] as &$d) foreach(array_keys($d) as $k) if(str_ends_with($k,'_paise') || $k==='divisor') unset($d[$k]);
                unset($d);
                $data['audit']=array_values(array_filter($data['audit'],fn($a)=>in_array($a['action_name'],['attendance_corrected','attendance_reviewed','device_reset'],true)));
            }
        } else { $data=$service->adminContext(); $data['can_manage_payroll']=$finance; if($finance) $data['payroll_modes']=$service->payrollModes(); }
    } elseif($_SERVER['REQUEST_METHOD']==='POST') {
        if(!isset($_SESSION['staff_attendance_csrf']) || !hash_equals($_SESSION['staff_attendance_csrf'],$_SERVER['HTTP_X_CSRF_TOKEN']??'')) throw new StaffAttendanceDenied('This page expired. Reload before saving.');
        $input=json_decode(file_get_contents('php://input'),true,32,JSON_THROW_ON_ERROR);
        if(!is_array($input)) throw new InvalidArgumentException('Invalid request.');
        $action=$input['action']??'';
        if(in_array($action,['policy','teacher_rules','payroll_mode','salary','initial_salary','adjust','finalize','reopen','paid'],true) && !$finance) throw new StaffAttendanceDenied('Only the super administrator can change rules or payroll.');
        switch($action) {
            case 'policy': $service->savePolicy($input); break;
            case 'teacher_rules': $service->saveTeacherRules($input); break;
            case 'calendar': $service->saveCalendar($input); break;
            case 'salary': $service->saveSalary($input); break;
            case 'initial_salary': $service->saveSalary($input,true); break;
            case 'payroll_mode': $service->savePayrollMode($input); break;
            case 'correct': $service->correct($input); break;
            case 'review': $service->review($input); break;
            case 'review_batch': $service->reviewBatch($input); break;
            case 'reset_device': $service->resetDevice($input); break;
            case 'adjust': $service->adjust($input); break;
            case 'finalize': case 'reopen': case 'paid': $service->salaryAction($input); break;
            default: throw new InvalidArgumentException('Invalid action.');
        }
        $data=[];
    } else { http_response_code(405); header('Allow: GET, POST'); exit(json_encode(['success'=>false,'message'=>'Use GET or POST.'])); }
    echo json_encode(['success'=>true,'data'=>$data]);
} catch(StaffAttendanceDenied $e) { http_response_code(403); echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
} catch(StaffAttendanceConflict $e) { http_response_code(409); echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
} catch(InvalidArgumentException|JsonException $e) { http_response_code(422); echo json_encode(['success'=>false,'message'=>$e instanceof JsonException?'Invalid request data.':$e->getMessage()]);
} catch(Throwable $e) { error_log('Staff attendance admin: '.$e->getMessage()); http_response_code(503); echo json_encode(['success'=>false,'message'=>($_GET['action']??'')==='payments'?'Salary payments could not be loaded. Ask the server administrator to check saved payment history.':'Unable to process attendance. Ask the server administrator to review the new staff attendance section of migrate.sql.']); }
