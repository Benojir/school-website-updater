<?php
require_once __DIR__ . '/../../includes/auth-check.php';
require_once __DIR__ . '/../../includes/school/school-expense-service.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$admin = authenticateAdminApiRequest($pdo);
if (!hasPermission(PERM_MANAGE_EXPENSES)) {
    http_response_code(403);
    exit(json_encode(['success' => false, 'message' => 'You do not have permission to manage school expenses.']));
}
$service = new SchoolExpenseService($pdo, (int)$admin['user_id'], $admin['full_name'] ?? 'Administrator', function (string $path): array {
    require_once __DIR__ . '/../../includes/imgbb-upload.php';
    return uploadToImgBB($path, 'School expense bill');
});
try {
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if ($method === 'POST') {
        $csrf = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        if (!is_string($csrf) || empty($_SESSION['school_expenses_csrf']) || !hash_equals($_SESSION['school_expenses_csrf'], $csrf)) {
            http_response_code(403);
            exit(json_encode(['success' => false, 'message' => 'Your form expired. Refresh the page before saving.']));
        }
        if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 6 * 1024 * 1024) throw new InvalidArgumentException('This upload is too large. Choose a bill image up to 5 MB.');
        $file = $_FILES['bill_image'] ?? [];
        if (!is_array($file)) throw new InvalidArgumentException('Invalid bill upload.');
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE && (!is_string($file['tmp_name'] ?? null) || !is_uploaded_file($file['tmp_name']))) {
            throw new InvalidArgumentException('The bill image could not be received. Choose an image up to 5 MB.');
        }
        $receipt = schoolExpenseReceipt($file);
        // Authentication/CSRF have been checked; DB locks protect writes and duplicate requests.
        session_write_close();
        $data = $service->write($_POST, $receipt);
    } elseif ($method === 'GET') {
        $action = $_GET['action'] ?? 'report';
        if (!is_string($action)) throw new InvalidArgumentException('Invalid expense view.');
        if ($action === 'export') {
            $rows = $service->export($_GET); // Validate and prepare before sending a CSV response.
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="school-expenses-' . date('Y-m-d') . '.csv"');
            header('X-Content-Type-Options: nosniff');
            $output = fopen('php://output', 'w');
            fwrite($output, "\xEF\xBB\xBF");
            fputcsv($output, ['Date', 'Category', 'Amount (' . ($currency_symbol ?? 'INR') . ')', 'Paid to / place', 'Note', 'Bill image', 'Recorded by', 'Created at', 'Updated at'], ',', '"', '');
            while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
                $paise = (int)$row['amount_paise'];
                $values = [$row['expense_date'], $row['category_name'], intdiv($paise, 100) . '.' . str_pad((string)($paise % 100), 2, '0', STR_PAD_LEFT),
                    $row['payee'], $row['note'], schoolExpenseBillUrl($row['bill_url']) ?? '', $row['created_by_name'], $row['created_at'], $row['updated_at']];
                fputcsv($output, array_map(fn($value) => schoolExpenseCsvCell((string)$value), $values), ',', '"', '');
            }
            fclose($output);
            exit;
        }
        $data = match ($action) {
            'categories' => ['categories' => $service->categories()],
            'report' => $service->report($_GET),
            'detail' => $service->detail(schoolExpenseInteger($_GET['id'] ?? 0, 'expense')),
            default => throw new InvalidArgumentException('Unknown expense view.')
        };
    } else {
        http_response_code(405);
        header('Allow: GET, POST');
        exit(json_encode(['success' => false, 'message' => 'Use GET or POST.']));
    }
    echo json_encode(['success' => true, 'data' => $data], JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
} catch (SchoolExpenseConflict $error) {
    http_response_code(409);
    echo json_encode(['success' => false, 'message' => $error->getMessage()]);
} catch (SchoolExpenseNotFound $error) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => $error->getMessage()]);
} catch (SchoolExpenseUploadError $error) {
    http_response_code(502);
    echo json_encode(['success' => false, 'message' => $error->getMessage()]);
} catch (InvalidArgumentException | JsonException $error) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => $error instanceof JsonException ? 'Invalid form data. Refresh and try again.' : $error->getMessage()]);
} catch (Throwable $error) {
    error_log('School expenses: ' . $error->getMessage());
    $missing = $error instanceof PDOException && in_array($error->getCode(), ['42S02', '42S22'], true);
    http_response_code($missing ? 503 : 500);
    echo json_encode(['success' => false, 'message' => $missing ? 'School expenses is not ready yet. Contact the school administrator to finish setup.' : 'The request could not be completed. Retry the same form or refresh the list to check the latest records.']);
}
