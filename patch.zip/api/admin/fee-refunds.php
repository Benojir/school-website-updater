<?php
require_once __DIR__ . '/../../includes/auth-check.php';
require_once __DIR__ . '/../../includes/parent/financial/fee-payment-refund-service.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if (!hasPermission(PERM_MANAGE_FEES)) {
    http_response_code(403); echo json_encode(['success' => false, 'message' => 'Permission denied']); exit;
}
try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $type = $_GET['type'] ?? '';
        if (!in_array($type, ['monthly', 'admission'], true)) throw new InvalidArgumentException('Invalid fee type.');
        $stmt = $pdo->prepare("SELECT o.id, o.student_id, s.name AS student_name, o.razorpay_order_id, o.razorpay_payment_id,
            o.razorpay_refund_id, o.refund_amount_paise, o.payment_status, o.refund_error, o.reversed_at
            FROM online_fee_payment_orders o LEFT JOIN students s ON s.student_id = o.student_id
            WHERE o.fee_type = ? AND o.payment_status IN ('refund_pending', 'refund_failed', 'refunded')
            ORDER BY (o.payment_status = 'refunded') ASC, o.reversed_at DESC LIMIT 100");
        $stmt->execute([$type . '-fee']);
        echo json_encode(['success' => true, 'refunds' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!is_string($_POST['csrf'] ?? null) || empty($_SESSION['fee_reversal_csrf']) || !hash_equals($_SESSION['fee_reversal_csrf'], $_POST['csrf'])) {
            http_response_code(403); throw new InvalidArgumentException('Your form expired. Refresh this page.');
        }
        $id = filter_var($_POST['order_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if (!$id) throw new InvalidArgumentException('Invalid reversed order.');
        if (empty($websiteConfig['razorpay_key_id']) || empty($websiteConfig['razorpay_key_secret'])) throw new InvalidArgumentException('Configure Razorpay before checking or retrying refunds.');
        session_write_close();
        $order = (new FeePaymentRefundService($pdo, new FeePaymentGateway($websiteConfig['razorpay_key_id'], $websiteConfig['razorpay_key_secret'])))->process($id, true);
        echo json_encode(['success' => true, 'message' => $order['payment_status'] === 'refunded' ? 'Refund confirmed by Razorpay.'
            : ($order['refund_error'] ?? 'The refund is pending confirmation from Razorpay.'), 'payment_status' => $order['payment_status']]);
    } else {
        http_response_code(405); header('Allow: GET, POST');
    }
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
