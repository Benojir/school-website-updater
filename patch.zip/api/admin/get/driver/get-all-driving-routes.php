<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

try {
    // Get driving routes
    $stmt = $pdo->prepare("SELECT * FROM driving_routes ORDER BY id ASC");
    $stmt->execute();
    $driving_routes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $driving_routes_array = [];

    foreach ($driving_routes as $route) {
        $driving_routes_array[] = array(
            'id' => $route['id'],
            'name' => $route['route_name']
        );
    }
    
    echo json_encode([
        'success' => true,
        'data' => $driving_routes_array
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}