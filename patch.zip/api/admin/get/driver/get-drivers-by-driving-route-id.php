<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

if (isset($_REQUEST['route_id'])) {
    $route_id = $_REQUEST['route_id'];

    // Fetch drivers by driving route ID
    $stmt = $pdo->prepare("SELECT * FROM drivers WHERE route_id = ?");
    $stmt->execute([$route_id]);
    $drivers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($drivers);
}