<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

// Set the response header to indicate that the output is JSON.
header('Content-Type: application/json');

// --- INPUT PARAMETERS ---
// Get pagination, search, and filter parameters from the GET request.
// Provide default values if they are not set.
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$offset = ($page - 1) * $limit;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$status = isset($_GET['status']) ? trim($_GET['status']) : '';

// --- RESPONSE STRUCTURE ---
// Initialize the array that will be sent back as a JSON response.
$response = [
    'drivers' => [],
    'total' => 0
];

try {
    // --- QUERY CONSTRUCTION ---
    
    // Base SQL query to select drivers.
    // SQL_CALC_FOUND_ROWS is a MySQL-specific feature that allows us to get the total number of
    // rows that would have been returned without the LIMIT clause, which is efficient for pagination.
    $sql = "SELECT SQL_CALC_FOUND_ROWS * FROM drivers WHERE 1=1";
    $params = [];
    
    // Add search condition to the query if a search term is provided.
    if (!empty($search)) {
        // The query will search across multiple columns.
        $sql .= " AND (name LIKE ? OR driver_id LIKE ? OR email LIKE ? OR phone LIKE ? OR vehicle_number LIKE ?)";
        $searchParam = "%$search%";
        // Add the search parameter for each placeholder '?'.
        $params = array_merge($params, array_fill(0, 5, $searchParam));
    }
    
    // Add status filter to the query if a status is selected.
    if (!empty($status)) {
        $sql .= " AND status = ?";
        $params[] = $status;
    }
    
    // Add sorting (ORDER BY) and pagination (LIMIT, OFFSET) clauses.
    $sql .= " ORDER BY name ASC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    
    // --- QUERY EXECUTION ---
    
    // Prepare the SQL statement to prevent SQL injection.
    $stmt = $pdo->prepare($sql);
    
    // Execute the prepared statement with the parameters.
    $stmt->execute($params);
    
    // Fetch all matching driver records as an associative array.
    $response['drivers'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get the total number of records found (without the LIMIT clause).
    $totalStmt = $pdo->query("SELECT FOUND_ROWS()");
    $response['total'] = $totalStmt->fetchColumn();

} catch (PDOException $e) {
    // --- ERROR HANDLING ---
    // If a database error occurs, send a 500 server error status code
    // and include the error message in the response for debugging.
    http_response_code(500);
    $response['error'] = 'Database error: ' . $e->getMessage();
}

// --- OUTPUT ---
// Encode the response array as a JSON string and send it to the client.
echo json_encode($response);
