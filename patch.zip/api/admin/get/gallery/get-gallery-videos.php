<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

$search = $_GET['search'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = intval($_GET['per_page'] ?? 12);

try {
    // Base query
    $query = "SELECT * FROM gallery_videos";
    $countQuery = "SELECT COUNT(*) as total FROM gallery_videos";
    $params = [];
    $where = [];
    
    // Search conditions
    if (!empty($search)) {
        $where[] = "(video_title LIKE ? OR event_date LIKE ?)";
        $params = array_merge($params, ["%$search%", "%$search%"]);
    }
    
    // Add WHERE clause if needed
    if (!empty($where)) {
        $query .= " WHERE " . implode(" AND ", $where);
        $countQuery .= " WHERE " . implode(" AND ", $where);
    }
    
    // Get total count
    $stmt = $pdo->prepare($countQuery);
    $stmt->execute($params);
    $totalItems = $stmt->fetch()['total'];
    $totalPages = ceil($totalItems / $perPage);
    
    // Add pagination to main query
    $query .= " ORDER BY event_date DESC, updated_at DESC LIMIT ? OFFSET ?";
    $params[] = $perPage;
    $params[] = ($page - 1) * $perPage;
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $gallery_items = $stmt->fetchAll();

    // Generate HTML for gallery items
    $html = '';
    if (empty($gallery_items)) {
        $html = '<div class="col-12 text-center py-5">No videos found</div>';
    } else {
        foreach ($gallery_items as $item) {
            $html .= '<div class="col-md-4 col-lg-3 mb-3">';
            $html .= '  <div class="card h-100 gallery-card">';
            $html .= '    <div class="card-img-top-container position-relative" style="padding-bottom: 56.25%; height: 0; overflow: hidden;">';
            $html .= '      <iframe frameborder="0" allowfullscreen style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;" src="https://www.youtube.com/embed/'.$item['video_yt_id'].'"></iframe>';
            $html .= '    </div>';
            $html .= '    <div class="card-body">';
            $html .= '      <p class="card-text">' . safe_htmlspecialchars($item['video_title']) . '</p>';
            $html .= '      <p class="text-muted small"><i class="far fa-calendar me-1"></i>' . date('M d, Y', strtotime($item['event_date'])) . '</p>';
            $html .= '    </div>';
            $html .= '    <div class="card-footer bg-transparent">';
            $html .= '      <a href="#" class="btn btn-sm btn-danger delete-video" data-id="' . $item['id'] .'">';
            $html .= '        <i class="fas fa-trash me-1"></i> Delete';
            $html .= '      </a>';
            $html .= '    </div>';
            $html .= '  </div>';
            $html .= '</div>';
        }
    }
    
    // Generate pagination HTML
    $pagination = '';
    if ($totalPages > 1) {
        $pagination .= '<li class="page-item' . ($page <= 1 ? ' disabled' : '') . '">';
        $pagination .= '  <a class="page-link" href="#" data-page="' . ($page - 1) . '" aria-label="Previous">';
        $pagination .= '    <span aria-hidden="true">&laquo;</span>';
        $pagination .= '  </a>';
        $pagination .= '</li>';
        
        $startPage = max(1, $page - 2);
        $endPage = min($totalPages, $page + 2);
        
        if ($startPage > 1) {
            $pagination .= '<li class="page-item"><a class="page-link" href="#" data-page="1">1</a></li>';
            if ($startPage > 2) {
                $pagination .= '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
        }
        
        for ($i = $startPage; $i <= $endPage; $i++) {
            $pagination .= '<li class="page-item' . ($i == $page ? ' active' : '') . '">';
            $pagination .= '  <a class="page-link" href="#" data-page="' . $i . '">' . $i . '</a>';
            $pagination .= '</li>';
        }
        
        if ($endPage < $totalPages) {
            if ($endPage < $totalPages - 1) {
                $pagination .= '<li class="page-item disabled"><span class="page-link">...</span></li>';
            }
            $pagination .= '<li class="page-item"><a class="page-link" href="#" data-page="' . $totalPages . '">' . $totalPages . '</a></li>';
        }
        
        $pagination .= '<li class="page-item' . ($page >= $totalPages ? ' disabled' : '') . '">';
        $pagination .= '  <a class="page-link" href="#" data-page="' . ($page + 1) . '" aria-label="Next">';
        $pagination .= '    <span aria-hidden="true">&raquo;</span>';
        $pagination .= '  </a>';
        $pagination .= '</li>';
    }
    
    echo json_encode([
        'html' => $html,
        'pagination' => $pagination,
        'totalItems' => $totalItems
    ]);
} catch (Exception $e) {
    echo json_encode([
        'html' => '<div class="col-12 text-center py-5 text-danger">Error loading gallery items</div>',
        'pagination' => '',
        'totalItems' => 0
    ]);
}
?>