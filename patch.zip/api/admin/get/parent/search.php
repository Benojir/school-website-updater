<?php
require_once("../../../../includes/auth-check.php"); 
header('Content-Type: application/json');

// পারমিশন চেক (যদি প্রয়োজন হয়)
if (!hasPermission(PERM_MANAGE_PARENTS)) {
    echo json_encode([]);
    exit;
}

$query = isset($_GET['q']) ? trim($_GET['q']) : '';

if (empty($query)) {
    echo json_encode([]);
    exit;
}

$searchParam = '%' . $query . '%';

// প্রথমে সার্চ হওয়া ইউনিক ফোন নম্বরগুলো বের করা
$phoneSql = "
    SELECT DISTINCT pas.phone
    FROM parent_auth_sessions pas
    LEFT JOIN students s 
        ON pas.phone = s.phone_number OR pas.phone = s.alternate_phone_number
    WHERE pas.phone IS NOT NULL AND pas.phone != ''
      AND (
          pas.phone LIKE :q1 OR 
          pas.device_name LIKE :q2 OR 
          s.name LIKE :q3 OR 
          s.father_name LIKE :q4 OR 
          s.mother_name LIKE :q5 OR 
          s.student_id LIKE :q6
      )
    LIMIT 30
";

$phoneStmt = $pdo->prepare($phoneSql);
$phoneStmt->execute([
    ':q1' => $searchParam,
    ':q2' => $searchParam,
    ':q3' => $searchParam,
    ':q4' => $searchParam,
    ':q5' => $searchParam,
    ':q6' => $searchParam
]);
$phones = $phoneStmt->fetchAll(PDO::FETCH_COLUMN);

if (empty($phones)) {
    echo json_encode([]);
    exit;
}

// ফোনগুলোর ফুল ডিটেলস ফেচ করা
$inQuery = implode(',', array_fill(0, count($phones), '?'));
$detailsSql = "
    SELECT 
        pas.id AS session_id,
        pas.phone,
        pas.device_name,
        pas.app_version,
        pas.last_activity,
        pas.ip_address,
        pas.session_source,
        s.student_id,
        s.name AS student_name,
        s.father_name,
        s.mother_name
    FROM parent_auth_sessions pas
    LEFT JOIN students s 
        ON pas.phone = s.phone_number OR pas.phone = s.alternate_phone_number
    WHERE pas.phone IN ($inQuery)
    ORDER BY pas.last_activity DESC
";

$detailsStmt = $pdo->prepare($detailsSql);
$detailsStmt->execute($phones);
$results = $detailsStmt->fetchAll(PDO::FETCH_ASSOC);

$installData = [];

// ডেটা গ্রুপিং
foreach ($results as $row) {
    $phone = $row['phone'];
    
    if (!isset($installData[$phone])) {
        $installData[$phone] = [
            'phone'    => $phone,
            'students' => [],
            'sessions' => []
        ];
    }
    
    // Students Handle
    if (!empty($row['student_id'])) {
        $found = false;
        foreach ($installData[$phone]['students'] as $s) {
            if ($s['id'] === $row['student_id']) { $found = true; break; }
        }
        if (!$found) {
            $installData[$phone]['students'][] = [
                'id'          => $row['student_id'],
                'name'        => $row['student_name'],
                'father_name' => $row['father_name'] ?: 'N/A',
                'mother_name' => $row['mother_name'] ?: 'N/A'
            ];
        }
    }

    // Sessions Handle
    $sessionId = $row['session_id'];
    $foundSession = false;
    foreach ($installData[$phone]['sessions'] as $sess) {
        if ($sess['session_id'] === $sessionId) { $foundSession = true; break; }
    }
    if (!$foundSession) {
        $installData[$phone]['sessions'][] = [
            'session_id'    => $sessionId,
            'device_name'   => $row['device_name'],
            'app_version'   => $row['app_version'] ?: 'N/A',
            'last_activity' => date('d M Y, h:i A', strtotime($row['last_activity'])),
            'ip_address'    => $row['ip_address'] ?: 'N/A',
            'source'        => $row['session_source']
        ];
    }
}

// ইনডেক্স ঠিক করে JSON ফরমেটে রিটার্ন
echo json_encode(array_values($installData));
?>