<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');


// Check admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    die(json_encode(['success' => false, 'message' => 'Permission denied']));
}

try {
    $selected_year = academicNormalizeYear($_REQUEST['selected_year'] ?? academicRequireCurrentYear($pdo));
    $academic_source = academicStudentSourceSql($pdo, $selected_year);
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage(), 'data' => []]);
    exit;
}

// Validate inputs
if (!isset($_REQUEST['first_student_id']) || !isset($_REQUEST['last_student_id']) || !isset($_REQUEST['class_id']) || !isset($_REQUEST['section_id'])) {
    die(json_encode(['success' => false, 'message' => 'Invalid request. Missing parameters.']));
}

$first_student_id = $_REQUEST['first_student_id'] ?? '';
$last_student_id = $_REQUEST['last_student_id'] ?? '';
$class_id = (int)$_REQUEST['class_id'];
$section_id = !empty($_REQUEST['section_id']) ? (int)$_REQUEST['section_id'] : null;

if (empty($first_student_id) || empty($last_student_id)) {
    die(json_encode(['success' => false, 'message' => 'First and last student IDs are required.']));
}

// First find the last exam id from results table
$stmt = $pdo->prepare("SELECT MAX(exam_id) FROM results WHERE academic_year < ? AND student_id IN (?, ?)");
$stmt->execute([$selected_year, $first_student_id, $last_student_id]);
$last_exam_id = $stmt->fetchColumn();

// Handle the case where the table is empty (fetchColumn returns false or null)
if (!$last_exam_id) {
    echo json_encode(['success' => true, 'message' => 'No earlier academic-year results are available. Use manual roll assignment.', 'suggestions' => []]);
    exit;
}

// Find last class id of the first student from results table
$stmt = $pdo->prepare("SELECT class_id FROM results WHERE student_id = ? AND exam_id = ?");
$stmt->execute([$first_student_id, $last_exam_id]);
$last_class_id = $stmt->fetchColumn();

if (!$last_class_id) {
    // If no class found for the first student, try the last student
    $stmt = $pdo->prepare("SELECT class_id FROM results WHERE student_id = ? AND exam_id = ?");
    $stmt->execute([$last_student_id, $last_exam_id]);
    $last_class_id = $stmt->fetchColumn();

    if (!$last_class_id) {
        echo json_encode(['success' => true, 'message' => 'No previous class found for the students.', 'suggestions' => []]);
        exit;
    }
}

// Fetch marksheet settings
$stmt = $pdo->prepare("SELECT * FROM settings_marksheet LIMIT 1");
$stmt->execute();
$marksheet_settings = $stmt->fetch(PDO::FETCH_ASSOC);

// Find the last roll number of the class-section from students table
$stmt = $pdo->prepare("SELECT MAX(roll_no) as max_roll FROM {$academic_source} students WHERE class_id = ?" . ($section_id !== null ? " AND section_id = ?" : ""));
$params = [$class_id];
if ($section_id !== null) {
    $params[] = $section_id;
}
$stmt->execute($params);
$max_roll_row = $stmt->fetch(PDO::FETCH_ASSOC);
$max_roll_number = $max_roll_row ? (int)$max_roll_row['max_roll'] : 0;

// Get all students ids in the current class
$stmt = $pdo->prepare("SELECT student_id FROM {$academic_source} students WHERE class_id = ? AND (roll_no IS NULL OR roll_no = 0 OR roll_no = '') AND status = 'Active'" . ($section_id !== null ? " AND section_id = ?" : " AND section_id IS NULL"));
$params = [$class_id];
if ($section_id !== null) {
    $params[] = $section_id;
}
$stmt->execute($params);
$current_student_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);

// Get top rankers based on last class exam
$rankers = getTopRankersForSingleMarksheet($pdo, $last_class_id, $last_exam_id, $marksheet_settings['include_minor_subjects_marks'], null, 50000);

$filtered_rankers = [];

$suggested_roll = $max_roll_number + 1;
foreach ($rankers as $ranker) {
    if (in_array($ranker['student_id'], $current_student_ids, true)) {
        $filtered_rankers[] = [
            'student_id' => $ranker['student_id'], 'name' => $ranker['name'],
            'suggested_roll_no' => $suggested_roll++,
        ];
    }
}

// Return suggestions
echo json_encode(['success' => true, 'message' => 'Suggestions generated successfully.', 'suggestions' => $filtered_rankers]);
