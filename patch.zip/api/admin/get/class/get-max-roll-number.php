<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    die(json_encode(['success' => false, 'message' => 'Permission denied']));
}

// Validate inputs
if (!isset($_REQUEST['class_id']) || !isset($_REQUEST['section_id'])) {
    die(json_encode(['success' => false, 'message' => 'Invalid request. Missing parameters.']));
}

$class_id = (int)$_REQUEST['class_id'];
$section_id = !empty($_REQUEST['section_id']) ? (int)$_REQUEST['section_id'] : null;

$stmt = $pdo->prepare("SELECT roll_no FROM students WHERE class_id = ?" . ($section_id !== null ? " AND section_id = ?" : ""));
$params = [$class_id];
if ($section_id !== null) {
    $params[] = $section_id;
}
$stmt->execute($params);

$roll_numbers = $stmt->fetchAll(PDO::FETCH_COLUMN);

if ($roll_numbers) {
    $max_roll = max($roll_numbers);
} else {
    $max_roll = 0;
}

echo json_encode(['success' => true, 'max_roll' => $max_roll]);