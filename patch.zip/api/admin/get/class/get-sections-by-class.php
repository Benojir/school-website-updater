<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

$class_id = $_REQUEST['class_id'] ?? 0;

$stmt = $pdo->prepare("SELECT id, section_name FROM sections WHERE class_id = :class_id ORDER BY section_name ASC");
$stmt->execute([':class_id' => $class_id]);
$sections = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($sections);
?>
