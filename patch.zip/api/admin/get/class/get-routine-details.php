<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");
header('Content-Type: application/json');

if (isset($_GET['routine_id'])) {
    $routine_id = (int)$_GET['routine_id'];
    
    $stmt = $pdo->prepare("SELECT * FROM class_routines WHERE id = ?");
    $stmt->execute([$routine_id]);
    $routine = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($routine) {
        echo json_encode(['success' => true, 'data' => $routine]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Routine not found']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid Request']);
}
?>