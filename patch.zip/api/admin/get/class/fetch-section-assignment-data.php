<?php
/** @var PDO $pdo */
include_once (__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check admin permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

// Get Class ID
$class_id = isset($_REQUEST['class_id']) ? (int)$_REQUEST['class_id'] : 0;

if (!$class_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid Class ID']);
    exit;
}

try {
    // Get class name
    $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
    $stmt->execute([$class_id]);
    $class = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$class) {
            echo json_encode(['success' => false, 'message' => 'Class not found']);
            exit;
    }

    // Get sections
    $stmt = $pdo->prepare("SELECT id, section_name FROM sections WHERE class_id = ? ORDER BY section_name ASC");
    $stmt->execute([$class_id]);
    $sections = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get students (without section)
    // Filter for Active students who have no section assigned (NULL or 0)
    $stmt = $pdo->prepare("
        SELECT s.id, s.student_id, s.name, s.father_name, s.address
        FROM students s
        WHERE s.class_id = ? 
        AND (s.section_id IS NULL OR s.section_id = 0)
        AND s.status = 'Active'
        ORDER BY s.name ASC
    ");
    $stmt->execute([$class_id]);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'class_name' => $class['class_name'],
        'sections' => $sections,
        'students' => $students
    ]);

} catch (Exception $e) {
    // Log error internally if needed, send generic or specific error to frontend
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
exit;