<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: text/html');

if (isset($_REQUEST['class_id']) && isset($_REQUEST['section_id'])) {
    $class_id = $_REQUEST['class_id'];
    $section_id = $_REQUEST['section_id'];

    // Fixed days of the week
    $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

    // Get class and section names
    $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
    $stmt->execute([$class_id]);
    $class = $stmt->fetch();

    $stmt = $pdo->prepare("SELECT section_name FROM sections WHERE id = ?");
    $stmt->execute([$section_id]);
    $section = $stmt->fetch();

    // Get routine for selected class/section
    $stmt = $pdo->prepare("SELECT cr.*, s.subject_name, t.name as teacher_name
                         FROM class_routines cr
                         JOIN subjects s ON cr.subject_id = s.id
                         LEFT JOIN teachers t ON cr.teacher_id = t.id
                         WHERE cr.class_id = ? AND cr.section_id = ?
                         ORDER BY FIELD(cr.day_name, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), cr.start_time");
    $stmt->execute([$class_id, $section_id]);
    $routine = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Group by day
    $groupedRoutine = [];
    foreach ($routine as $item) {
        $groupedRoutine[$item['day_name']][] = $item;
    }

    // Start output
    ob_start();
?>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4><?= safe_htmlspecialchars($class['class_name']) ?> - <?= safe_htmlspecialchars($section['section_name']) ?></h4>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-dark">
                <tr>
                    <th class="text-center">Day</th>
                    <th class="text-center">Time</th>
                    <th class="text-center">Subject</th>
                    <th class="text-center">Teacher</th>
                    <th class="text-center">Room</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($days as $day): ?>
                    <?php if (isset($groupedRoutine[$day])): ?>
                        <?php foreach ($groupedRoutine[$day] as $index => $item): ?>
                            <tr data-routine-id="<?= $item['id'] ?>">
                                <?php if ($index === 0): ?>
                                    <td class="fw-bold text-center bg-light" rowspan="<?= count($groupedRoutine[$day]) ?>"><?= $day ?></td>
                                <?php endif; ?>
                                <td><?= date('h:i A', strtotime($item['start_time'])) ?> - <?= date('h:i A', strtotime($item['end_time'])) ?></td>
                                <td><?= safe_htmlspecialchars($item['subject_name']) ?></td>
                                <td><?= !empty($item['teacher_name']) ? safe_htmlspecialchars($item['teacher_name']) : '-' ?></td>
                                <td><?= !empty($item['room_number']) ? safe_htmlspecialchars($item['room_number']) : '-' ?></td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-danger delete-routine-btn" title="Delete" data-routine-id="<?= $item['id'] ?>">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td class="fw-bold text-center bg-light"><?= $day ?></td>
                            <td colspan="4" class="text-center text-muted">No classes scheduled</td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

<?php
    echo ob_get_clean();
} else {
    echo '<div class="alert alert-danger">Invalid request</div>';
}
?>