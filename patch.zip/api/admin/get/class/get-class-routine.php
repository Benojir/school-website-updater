<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

if (!isset($_REQUEST['class_id']) || !isset($_REQUEST['section_id'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid request: class_id and section_id are required.']);
    exit;
}

$class_id   = $_REQUEST['class_id'];
$section_id = $_REQUEST['section_id'];

// Get class name
$stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
$stmt->execute([$class_id]);
$class = $stmt->fetch();

if (!$class) {
    echo json_encode(['success' => false, 'message' => 'Class not found.']);
    exit;
}

// Get section name
$stmt = $pdo->prepare("SELECT section_name FROM sections WHERE id = ?");
$stmt->execute([$section_id]);
$section = $stmt->fetch();

if (!$section) {
    echo json_encode(['success' => false, 'message' => 'Section not found.']);
    exit;
}

// Get routine ordered by day and time
$stmt = $pdo->prepare("
    SELECT
        cr.id,
        cr.day_name,
        cr.start_time,
        cr.end_time,
        cr.room_number,
        s.subject_name,
        t.name AS teacher_name
    FROM class_routines cr
    JOIN subjects s ON cr.subject_id = s.id
    LEFT JOIN teachers t ON cr.teacher_id = t.id
    WHERE cr.class_id = ? AND cr.section_id = ?
    ORDER BY
        FIELD(cr.day_name, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'),
        cr.start_time
");
$stmt->execute([$class_id, $section_id]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Group routine entries by day
$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
$groupedRoutine = array_fill_keys($days, []);

foreach ($rows as $item) {
    $groupedRoutine[$item['day_name']][] = [
        'id'           => (int) $item['id'],
        'start_time'   => date('h:i A', strtotime($item['start_time'])),
        'end_time'     => date('h:i A', strtotime($item['end_time'])),
        'subject_name' => $item['subject_name'],
        'teacher_name' => $item['teacher_name'] ?: null,
        'room_number'  => $item['room_number']  ?: null,
    ];
}

echo json_encode([
    'success'   => true,
    'class'     => $class['class_name'],
    'section'   => $section['section_name'],
    'days'      => $days,
    'routine'   => $groupedRoutine,
]);