<?php
/** @var PDO $pdo */
include_once("../../../../includes/auth-check.php");
header('Content-Type: application/json');

// 1. Permission Check
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

// 2. Input Validation
$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : null;
$section_id = isset($_GET['section_id']) ? (int)$_GET['section_id'] : null;
$sort_by = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'name_asc';

if (!$class_id) {
    echo json_encode(['success' => false, 'message' => 'Class ID is required', 'data' => []]);
    exit;
}

if (!$section_id) {
    echo json_encode(['success' => false, 'message' => 'Section ID is required', 'data' => []]);
    exit;
}

try {
    // 3. Construct Query
    // Base clause: Active students in class, with no valid roll number
    $whereClause = "s.class_id = ? AND (s.roll_no IS NULL OR s.roll_no <= 0) AND s.status = 'Active'";
    $params = [$class_id];

    // Handle Section Logic
    // If section_id is provided and > 0, filter by it.
    // If it's 0 or null, filter for students with NULL/0 section_id.
    if ($section_id && $section_id > 0) {
        $whereClause .= " AND s.section_id = ?";
        $params[] = $section_id;
    } else {
        $whereClause .= " AND (s.section_id IS NULL OR s.section_id = 0)";
    }

    // Handle Sort Logic
    $orderBy = "s.name ASC"; // Default
    switch ($sort_by) {
        case 'name_desc':
            $orderBy = "s.name DESC";
            break;
        case 'father_asc':
            $orderBy = "s.father_name ASC";
            break;
        case 'father_desc':
            $orderBy = "s.father_name DESC";
            break;
        case 'name_asc':
        default:
            $orderBy = "s.name ASC";
            break;
    }

    $sql = "
        SELECT s.id, s.student_id, s.name, s.father_name, s.address 
        FROM students s
        WHERE $whereClause
        ORDER BY $orderBy
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 4. Return Data
    echo json_encode([
        'success' => true,
        'count' => count($students),
        'data' => $students
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}