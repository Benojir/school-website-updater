<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$offset = ($page - 1) * $limit;

$response = [
    'releases' => [],
    'total' => 0
];

try {
    // Get total count
    $totalStmt = $pdo->query("
        SELECT COUNT(*) 
        FROM exam_admit_releases er
        JOIN exams e ON er.exam_id = e.id
        JOIN classes c ON er.class_id = c.id
    ");
    $response['total'] = $totalStmt->fetchColumn();
    
    // Get paginated results
    $stmt = $pdo->prepare("
        SELECT er.*, e.exam_name, c.class_name 
        FROM exam_admit_releases er
        JOIN exams e ON er.exam_id = e.id
        JOIN classes c ON er.class_id = c.id
        ORDER BY er.release_date DESC
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$limit, $offset]);
    $response['releases'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    http_response_code(500);
    $response['error'] = 'Database error: ' . $e->getMessage();
}

echo json_encode($response);