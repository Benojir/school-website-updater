<?php
/** @var PDO $pdo */
include_once(__DIR__ . "/../../../../includes/auth-check.php");
header('Content-Type: application/json');

$exam_type = $_REQUEST['exam_type'] ?? 'active';
$page = (int) ($_REQUEST['page'] ?? 1);
$results_per_page = (int) ($_REQUEST['results_per_page'] ?? 20);

// Basic validation
if ($page <= 0 || $results_per_page <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid page or results_per_page']);
    exit;
}

// Limit constraints
$max_results_per_page = 100;
if ($results_per_page > $max_results_per_page) {
    $results_per_page = $max_results_per_page;
}

// Calculate Offset
$offset = ($page - 1) * $results_per_page;

// 1. Get Total Count first (for pagination calculation)
$countSql = "SELECT COUNT(*) FROM exams WHERE status = :status";
$stmtCount = $pdo->prepare($countSql);
$stmtCount->execute([':status' => $exam_type]);
$total_results = $stmtCount->fetchColumn();

// 2. Get Actual Data with LIMIT and OFFSET
$sql = "SELECT * FROM exams WHERE status = :status ORDER BY exam_date DESC LIMIT :limit OFFSET :offset";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':status', $exam_type, PDO::PARAM_STR);
$stmt->bindValue(':limit', $results_per_page, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$exams = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    'success' => true,
    'message' => 'Exams retrieved successfully',
    'data' => $exams,
    'pagination' => [
        'page' => $page,
        'results_per_page' => $results_per_page,
        'total_results' => $total_results,
        'total_pages' => ceil($total_results / $results_per_page)
    ]
]);
?>