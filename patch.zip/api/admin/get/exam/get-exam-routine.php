<?php
/** @var PDO $pdo */
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

$exam_id = $_REQUEST['exam_id'] ?? '';
$class_id = $_REQUEST['class_id'] ?? '';

if (empty($exam_id) || empty($class_id)) {
    echo json_encode(['success' => false, 'message' => 'Required fields are missing']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT * FROM exam_routines 
        WHERE exam_id = ? AND class_id = ?
    ");
    $stmt->execute([$exam_id, $class_id]);
    $subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$subjects) {
        echo json_encode(['success' => false, 'message' => 'No exam routine found for the given exam and class']);
        exit;
    }
    
    echo json_encode([
        'success' => true,
        'data' => $subjects
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}