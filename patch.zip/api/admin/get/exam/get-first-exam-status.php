<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

$student_ids = $_GET['student_ids'] ?? [];
$class_id = $_GET['class_id'] ?? null;

if (empty($student_ids) || empty($class_id)) {
    echo json_encode(['success' => false, 'message' => 'Student IDs and Class ID are required.']);
    exit;
}

$response = ['success' => false, 'data' => []];

try {
    // Step 1: Find the first exam_id for each student in the provided list
    $placeholders = implode(',', array_fill(0, count($student_ids), '?'));
    $stmt_first_exam = $pdo->prepare("
        SELECT r.student_id, MIN(r.exam_id) as first_exam_id
        FROM results r
        WHERE r.student_id IN ($placeholders) AND r.class_id = ?
        GROUP BY r.student_id
    ");
    $params = array_merge($student_ids, [$class_id]);
    $stmt_first_exam->execute($params);
    $first_exams = $stmt_first_exam->fetchAll(PDO::FETCH_KEY_PAIR); // Creates an associative array [student_id => first_exam_id]

    if (empty($first_exams)) {
        // No students have prior exam history, so nothing to lock
        $response['success'] = true;
        echo json_encode($response);
        exit;
    }

    // Step 2: For each student, get the subject statuses from their specific first exam
    $data = [];
    foreach ($first_exams as $student_id => $first_exam_id) {
        // Find the result_id that corresponds to the student's first exam
        $stmt_result = $pdo->prepare("SELECT id FROM results WHERE student_id = ? AND exam_id = ? AND class_id = ? LIMIT 1");
        $stmt_result->execute([$student_id, $first_exam_id, $class_id]);
        $first_result = $stmt_result->fetch(PDO::FETCH_ASSOC);

        if ($first_result) {
            $first_result_id = $first_result['id'];
            
            // Fetch all subject statuses for that result
            $stmt_subjects = $pdo->prepare("SELECT subject_id, is_excluded FROM subject_marks WHERE result_id = ?");
            $stmt_subjects->execute([$first_result_id]);
            // Group results by subject_id for easy lookup
            $subjects_status = $stmt_subjects->fetchAll(PDO::FETCH_GROUP | PDO::FETCH_UNIQUE | PDO::FETCH_ASSOC);
            
            $data[$student_id] = [
                'first_exam_id' => $first_exam_id,
                'subjects' => $subjects_status
            ];
        }
    }

    $response['success'] = true;
    $response['data'] = $data;
} catch (PDOException $e) {
    // Handle database errors
    $response['message'] = 'Database error: ' . $e->getMessage();
}

echo json_encode($response);
?>