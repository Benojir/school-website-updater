<?php
include_once("../../../../includes/auth-check.php");

header('Content-Type: application/json');

$limit = 50;
$page  = isset($_POST['page']) ? (int)$_POST['page'] : 1;
$offset = ($page - 1) * $limit;

$search   = isset($_POST['search'])   ? trim($_POST['search'])   : '';
$exam_id  = isset($_POST['exam_id'])  ? (int)$_POST['exam_id']  : '';
$class_id = isset($_POST['class_id']) ? (int)$_POST['class_id'] : '';

$sql = "SELECT er.*, e.exam_name, c.class_name, s.subject_name
        FROM exam_routines er
        JOIN exams    e ON er.exam_id    = e.id AND e.status = 'active'
        JOIN classes  c ON er.class_id   = c.id
        JOIN subjects s ON er.subject_id = s.id";

$where  = [];
$params = [];

if (!empty($search)) {
    $where[]  = "s.subject_name LIKE ?";
    $params[] = "%$search%";
}
if (!empty($exam_id)) {
    $where[]  = "er.exam_id = ?";
    $params[] = $exam_id;
}
if (!empty($class_id)) {
    $where[]  = "er.class_id = ?";
    $params[] = $class_id;
}
if ($where) {
    $sql .= " WHERE " . implode(" AND ", $where);
}

// Count total records
$count_stmt = $pdo->prepare("SELECT COUNT(*) FROM ($sql) AS total");
$count_stmt->execute($params);
$total_records = (int)$count_stmt->fetchColumn();
$total_pages   = (int)ceil($total_records / $limit);

// Fetch page of records
$sql .= " ORDER BY er.theory_exam_date, er.theory_start_time LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Build clean data array — no HTML
$routines = [];
foreach ($rows as $r) {
    $routines[] = [
        'id'           => (int)$r['id'],
        'exam_name'    => $r['exam_name'],
        'class_name'   => $r['class_name'],
        'subject_name' => $r['subject_name'],
        'marks' => [
            'theory'    => (int)$r['theory_marks'],
            'practical' => (int)$r['practical_marks'],
        ],
        'theory' => [
            'date'       => $r['theory_exam_date'],              // ISO: YYYY-MM-DD
            'start_time' => $r['theory_start_time'],             // ISO: HH:MM:SS
            'end_time'   => $r['theory_end_time'],
        ],
        'practical' => $r['practical_exam_date'] ? [
            'date'       => $r['practical_exam_date'],
            'start_time' => $r['practical_start_time'],
            'end_time'   => $r['practical_end_time'],
        ] : null,
    ];
}

echo json_encode([
    'success'       => true,
    'data'          => $routines,
    'pagination'    => [
        'current_page'  => $page,
        'total_pages'   => $total_pages,
        'total_records' => $total_records,
        'per_page'      => $limit,
    ],
]);