<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

if (!isset($_GET['student_ids']) || !isset($_GET['exam_id'])) {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
    exit;
}

$student_ids = explode(',', $_GET['student_ids']);
$exam_id = (int)$_GET['exam_id'];

// Prepare the query to get result IDs
$placeholders = implode(',', array_fill(0, count($student_ids), '?'));
$query = "SELECT id FROM results WHERE student_id IN ($placeholders) AND exam_id = ?";
$params = array_merge($student_ids, [$exam_id]);

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$result_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);

echo json_encode([
    'success' => true,
    'result_ids' => $result_ids
]);

?>