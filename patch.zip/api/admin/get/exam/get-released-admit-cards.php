<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

$classId = $_REQUEST['class_id'] ?? null;
$admitCards = [];

if ($classId) {
    $admitCards = $pdo->query("
                SELECT ea.id, e.exam_name, c.class_name 
                FROM exam_admit_releases ea
                JOIN exams e ON ea.exam_id = e.id
                JOIN classes c ON ea.class_id = c.id
                WHERE ea.class_id = $classId AND ea.status = 'released'
                ORDER BY e.exam_date DESC
            ")->fetchAll(PDO::FETCH_ASSOC);
} else {
    $admitCards = $pdo->query("
                SELECT ea.id, e.exam_name, c.class_name 
                FROM exam_admit_releases ea
                JOIN exams e ON ea.exam_id = e.id
                JOIN classes c ON ea.class_id = c.id
                WHERE ea.status = 'released'
                ORDER BY e.exam_date DESC
            ")->fetchAll(PDO::FETCH_ASSOC);
}

echo json_encode([
    'success' => true,
    'message' => 'Admit cards fetched successfully',
    'data' => $admitCards
]);
?>