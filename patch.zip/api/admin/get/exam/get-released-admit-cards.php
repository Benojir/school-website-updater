<?php
require_once __DIR__ . '/../../../../includes/auth-check.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
authenticateAdminApiRequest($pdo);
$classId = $_GET['class_id'] ?? '';
if ($classId !== '' && filter_var($classId, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) === false) {
    http_response_code(422);
    exit(json_encode(['success' => false, 'message' => 'Invalid class.']));
}
// Administrators can prepare cards before a release record exists at all.
if ($classId !== '') {
    $statement = $pdo->prepare('SELECT e.id AS exam_id, e.exam_name, c.class_name, a.id AS release_id FROM exams e JOIN classes c ON c.id = ? LEFT JOIN exam_admit_releases a ON a.exam_id = e.id AND a.class_id = c.id ORDER BY e.exam_date DESC');
    $statement->execute([(int) $classId]);
    $cards = $statement->fetchAll(PDO::FETCH_ASSOC);
    foreach ($cards as &$card) $card['id'] = 'exam-' . $card['exam_id'];
    unset($card);
    exit(json_encode(['success' => true, 'message' => 'Admit cards fetched successfully', 'data' => $cards]));
}
// Admin selection deliberately includes pending, scheduled and expired releases.
$query = 'SELECT ea.id, e.exam_name, c.class_name FROM exam_admit_releases ea JOIN exams e ON ea.exam_id = e.id JOIN classes c ON ea.class_id = c.id';
$params = [];
if ($classId !== '') { $query .= ' WHERE ea.class_id = ?'; $params[] = (int) $classId; }
$query .= ' ORDER BY e.exam_date DESC';
$statement = $pdo->prepare($query);
$statement->execute($params);
echo json_encode(['success' => true, 'message' => 'Admit cards fetched successfully', 'data' => $statement->fetchAll(PDO::FETCH_ASSOC)]);
