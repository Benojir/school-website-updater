<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$offset = ($page - 1) * $limit;

$response = [
    'releases' => [],
    'total' => 0
];

try {
    // Get total count for active exams only
    $totalStmt = $pdo->query("
        SELECT COUNT(*) 
        FROM exam_admit_releases er
        JOIN exams e ON er.exam_id = e.id
        JOIN classes c ON er.class_id = c.id
        WHERE e.status = 'active'
    ");
    $response['total'] = $totalStmt->fetchColumn();
    
    // Get paginated results for active exams only
    $stmt = $pdo->prepare("
        SELECT er.*, e.exam_name, c.class_name 
        FROM exam_admit_releases er
        JOIN exams e ON er.exam_id = e.id
        JOIN classes c ON er.class_id = c.id
        WHERE e.status = 'active'
        ORDER BY er.release_date DESC
        LIMIT ? OFFSET ?
    ");
    // PDO uses 1-based indexing for bindParam/bindValue, but passing array to execute works well
    // Note: When using LIMIT/OFFSET in execute() with arrays, PDO sometimes treats them as strings 
    // depending on emulation mode. For strict integers, bindValue is safer, but if your setup 
    // already works with array execution, this is fine:
    $stmt->bindValue(1, $limit, PDO::PARAM_INT);
    $stmt->bindValue(2, $offset, PDO::PARAM_INT);
    $stmt->execute();
    
    $response['releases'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    http_response_code(500);
    $response['error'] = 'Database error: ' . $e->getMessage();
}

echo json_encode($response);