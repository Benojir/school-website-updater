<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

if (!isset($_GET['student_id']) || empty($_GET['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'Student ID is required']);
    exit;
}

$student_id = $_GET['student_id'];

// Fetch current permissions
$stmt = $pdo->prepare("
    SELECT 
        override_admit_check,
        allow_admit_card,
        override_marksheet_check,
        allow_marksheet,
        notes 
    FROM student_permissions 
    WHERE student_id = ?
");
$stmt->execute([$student_id]);
$permissions = $stmt->fetch(PDO::FETCH_ASSOC);

// Fetch fee status
$stmt = $pdo->prepare("SELECT * FROM student_unpaid_fees WHERE student_id = ?");
$stmt->execute([$student_id]);
$unpaid_fees = $stmt->fetch(PDO::FETCH_ASSOC);

$fee_paid = true;

if ($unpaid_fees) {
    $fee_paid = false;
}

if (!$permissions) {
    $permissions = [
        'override_admit_check' => 0,
        'allow_admit_card' => 0,
        'override_marksheet_check' => 0,
        'allow_marksheet' => 0,
        'notes' => ''
    ];
}

echo json_encode([
    'success' => true,
    'data' => $permissions,
    'fee_paid' => $fee_paid,
    'unpaid_amount' => number_format($unpaid_fees['unpaid_amount'] ?? 0, 2)
]);
?>