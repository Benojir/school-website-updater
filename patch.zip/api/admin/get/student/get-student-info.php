<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");
require_once __DIR__ . '/../../../../includes/financial/monthly-fee-ledger.php';

header('Content-Type: application/json');

$student_id = $_REQUEST['student_id'] ?? null;

if (empty(sanitize_input($student_id))) {
    echo json_encode([
        "success" => false,
        "message" => "Missing required parameter: student_id."
    ]);
    exit();
}

try {
    $student_info = getStudentInfo($pdo, $student_id, academicRequestedYear($_REQUEST));
    if ($student_info) $student_info['academic_history'] = academicGetHistory($pdo, (int)$student_info['id']);
    if ($student_info && !empty($_REQUEST['monthly_fee_id'])) {
        if (!hasPermission(PERM_MANAGE_FEES)) throw new DomainException('Permission denied.');
        $stmt = $pdo->prepare('SELECT * FROM student_unpaid_fees WHERE id = ? AND student_id = ?');
        $stmt->execute([$_REQUEST['monthly_fee_id'], $student_id]);
        $fee = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$fee) throw new DomainException('Monthly bill no longer exists.');
        $ledger = new MonthlyFeeLedger($pdo); $bill = $ledger->bill($student_id, $fee['month_year']);
        if ($bill && $bill['breakdown_state'] === 'complete') {
            $ledger->assertFee($bill, $fee);
            foreach ($ledger->components((int)$bill['id']) as $component) {
                if ($component['fee_code'] === 'unclassified') continue;
                $key = $component['fee_code'] === 'tuition' ? 'tution_fee' : $component['fee_code'] . '_fee';
                $student_info[$key] = $component['billed_amount'];
            }
        }
        $student_info['monthly_bill_discount'] = $fee['discount_amount'];
    }
} catch (Throwable $e) {
    http_response_code(400);
    exit(json_encode(['success' => false, 'message' => $e->getMessage()]));
}

if (!$student_info) {
    echo json_encode([
        "success" => false,
        "message" => "Student not found."
    ]);
    exit();
}

echo json_encode([
    "success" => true,
    "message" => "Student info fetched successfully.",
    "student_info" => $student_info
]);
