<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

$student_id = $_REQUEST['student_id'] ?? null;

if (empty(sanitize_input($student_id))) {
    echo json_encode([
        "success" => false,
        "message" => "Missing required parameter: student_id."
    ]);
    exit();
}

$student_info = getStudentInfo($pdo, $student_id);

if (!$student_info) {
    echo json_encode([
        "success" => false,
        "message" => "Student not found."
    ]);
    exit();
}

echo json_encode([
    "success" => true,
    "message" => "Student info fetched successfully.",
    "student_info" => $student_info
]);