<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");

$response = [
    'success' => true,
    'classes' => $pdo->query("SELECT * FROM classes")->fetchAll(),
    'sections' => $pdo->query("SELECT s.id, s.section_name, c.class_name FROM sections s JOIN classes c ON s.class_id = c.id ORDER BY c.class_name, s.section_name")->fetchAll(),
    'exams' => $pdo->query("SELECT * FROM exams WHERE status = 'active' ORDER BY exam_date DESC")->fetchAll(),
    'admit_cards' => $pdo->query("SELECT ea.id, e.exam_name, c.class_name FROM exam_admit_releases ea JOIN exams e ON ea.exam_id = e.id JOIN classes c ON ea.class_id = c.id WHERE ea.status = 'released' ORDER BY e.exam_date DESC")->fetchAll()
];

echo json_encode($response);
exit;