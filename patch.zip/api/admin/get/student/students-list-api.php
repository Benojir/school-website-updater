<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");

// Initialize filter variables
$search = trim($_GET['search'] ?? '');
$class_filter = isset($_GET['class']) ? (int)$_GET['class'] : '';
$section_filter = isset($_GET['section']) ? (int)$_GET['section'] : '';
$gender_filter = isset($_GET['gender']) ? $_GET['gender'] : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$fee_status_filter_monthly = isset($_GET['monthly_fee_status']) ? $_GET['monthly_fee_status'] : '';
$fee_status_filter_admission = isset($_GET['admission_fee_status']) ? $_GET['admission_fee_status'] : '';
$hosteler_filter = isset($_GET['hosteler']) ? $_GET['hosteler'] : '';
$car_route_filter = isset($_GET['car_route']) ? $_GET['car_route'] : '';
$driver_id_filter = isset($_GET['driver_id']) ? $_GET['driver_id'] : '';
$sort_by_filter = isset($_GET['sort_by']) ? $_GET['sort_by'] : '';
$academic_year_filter = isset($_GET['academic_year']) ? $_GET['academic_year'] : '';

// Validating fees filter to avoid conflicts
if (!empty($fee_status_filter_monthly) && !empty($fee_status_filter_admission)) {
    $fee_status_filter_monthly = "";
    $fee_status_filter_admission = "";
}

// This page will only respond to AJAX requests
header('Content-Type: application/json');

// Pagination configuration
$per_page = 1000;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) {
    $page = 1;
}
$offset = ($page - 1) * $per_page;

// Base query with monthly fee status consideration
if (!empty($fee_status_filter_monthly)) {
    // New query that works with the current system
    $query = "
    SELECT s.*, c.class_name, sec.section_name,
           COALESCE((
               SELECT SUM(total_paid_amount) 
               FROM student_full_paid_fees 
               WHERE student_id = s.student_id
           ), 0) as paid_amount,
           COALESCE((
               SELECT SUM(unpaid_amount) 
               FROM student_unpaid_fees 
               WHERE student_id = s.student_id
           ), 0) as unpaid_amount
    FROM students s
    LEFT JOIN classes c ON s.class_id = c.id
    LEFT JOIN sections sec ON s.section_id = sec.id
    ";
} else {
    $query = "
    SELECT s.*, c.class_name, sec.section_name
    FROM students s
    LEFT JOIN classes c ON s.class_id = c.id
    LEFT JOIN sections sec ON s.section_id = sec.id
    ";
}

// Base query with admission fee status consideration
if (!empty($fee_status_filter_admission)) {
    // New query that works with the current system
    $query = "
    SELECT s.*, c.class_name, sec.section_name,
           COALESCE((
               SELECT SUM(total_paid_amount) 
               FROM admission_full_paid_fees 
               WHERE student_id = s.student_id
           ), 0) as paid_amount,
           COALESCE((
               SELECT SUM(unpaid_amount) 
               FROM admission_unpaid_fees 
               WHERE student_id = s.student_id
           ), 0) as unpaid_amount
    FROM students s
    LEFT JOIN classes c ON s.class_id = c.id
    LEFT JOIN sections sec ON s.section_id = sec.id
    ";
} else {
    $query = "
    SELECT s.*, c.class_name, sec.section_name
    FROM students s
    LEFT JOIN classes c ON s.class_id = c.id
    LEFT JOIN sections sec ON s.section_id = sec.id
    ";
}

// Where conditions
$where = [];
$params = [];

if (!empty($search)) {
    $where[] = "(s.student_id LIKE :search_id 
            OR s.name LIKE :search_name
            OR s.father_name LIKE :search_father
            OR s.mother_name LIKE :search_mother
            OR s.registration_no LIKE :search_reg_no
            OR s.phone_number LIKE :search_phone
            OR s.alternate_phone_number LIKE :search_alt_phone
            OR s.address LIKE :search_address)";
    $params[':search_id'] = "%$search%";
    $params[':search_name'] = "%$search%";
    $params[':search_father'] = "%$search%";
    $params[':search_mother'] = "%$search%";
    $params[':search_reg_no'] = "%$search%";
    $params[':search_phone'] = "%$search%";
    $params[':search_alt_phone'] = "%$search%";
    $params[':search_address'] = "%$search%";
}

if (!empty($class_filter)) {
    $where[] = "s.class_id = :class_id";
    $params[':class_id'] = $class_filter;
}

if (!empty($section_filter)) {
    if ($section_filter === -1) {
        $where[] = "(s.section_id IS NULL OR s.section_id = '')";
    } else {
        $where[] = "s.section_id = :section_id";
        $params[':section_id'] = $section_filter;
    }
}

if (!empty($gender_filter)) {
    $where[] = "s.gender = :gender";
    $params[':gender'] = $gender_filter;
}

if (!empty($status_filter)) {
    $where[] = "s.status = :status";
    $params[':status'] = $status_filter;
}

if (!empty($academic_year_filter)) {
    $where[] = "s.academic_year = :academic_year";
    $params[':academic_year'] = $academic_year_filter;
}

if ($hosteler_filter !== '') {
    $where[] = "s.is_hosteler = :is_hosteler";
    $params[':is_hosteler'] = (int)$hosteler_filter;
}

if (!empty($driver_id_filter)) {
    $where[] = "s.driving_route_id IN (SELECT id FROM driving_routes WHERE driver_id = :driver_id)";
    $params[':driver_id'] = $driver_id_filter;
}

if ($car_route_filter === 'has_route') {
    $where[] = "s.driving_route_id IS NOT NULL AND s.driving_route_id != ''";
} elseif ($car_route_filter === 'no_route') {
    $where[] = "(s.driving_route_id IS NULL OR s.driving_route_id = '')";
}

// Fee status conditions
// Update the fee status conditions to work with the new system
if (!empty($fee_status_filter_monthly)) {
    if ($fee_status_filter_monthly === 'paid') {
        $where[] = "EXISTS (SELECT 1 FROM student_full_paid_fees WHERE student_id = s.student_id)";
    } elseif ($fee_status_filter_monthly === 'unpaid') {
        $where[] = "EXISTS (SELECT 1 FROM student_unpaid_fees WHERE student_id = s.student_id)";
    } elseif ($fee_status_filter_monthly === 'fully_paid') {
        $where[] = "NOT EXISTS (SELECT 1 FROM student_unpaid_fees WHERE student_id = s.student_id)";
    }
}

// Admission Fee status conditions
if (!empty($fee_status_filter_admission)) {
    if ($fee_status_filter_admission === 'paid') {
        $where[] = "EXISTS (SELECT 1 FROM admission_full_paid_fees WHERE student_id = s.student_id)";
    } elseif ($fee_status_filter_admission === 'unpaid') {
        $where[] = "EXISTS (SELECT 1 FROM admission_unpaid_fees WHERE student_id = s.student_id)";
    } elseif ($fee_status_filter_admission === 'fully_paid') {
        $where[] = "NOT EXISTS (SELECT 1 FROM admission_unpaid_fees WHERE student_id = s.student_id)";
    }
}

// Add WHERE clause if needed
if (!empty($where)) {
    $query .= " WHERE " . implode(" AND ", $where);
}

// Group by if using fee status
if (!empty($fee_status_filter_monthly)) {
    $query .= " GROUP BY s.id";
}

// Group by if using admission fee status
if (!empty($fee_status_filter_admission)) {
    $query .= " GROUP BY s.id";
}

// Count total records for pagination
// Replace the count query with:
$count_query = "SELECT COUNT(DISTINCT s.id) FROM students s";
if (!empty($fee_status_filter_monthly)) {
    $count_query .= " 
    LEFT JOIN student_full_paid_fees f ON s.student_id = f.student_id
    LEFT JOIN student_unpaid_fees u ON s.student_id = u.student_id";
}

if (!empty($fee_status_filter_admission)) {
    $count_query .= " 
    LEFT JOIN admission_full_paid_fees f ON s.student_id = f.student_id
    LEFT JOIN admission_unpaid_fees u ON s.student_id = u.student_id";
}

$count_query .= " LEFT JOIN classes c ON s.class_id = c.id";
$count_query .= " LEFT JOIN sections sec ON s.section_id = sec.id";

if (!empty($where)) {
    $count_query .= " WHERE " . implode(" AND ", $where);
}

$count_stmt = $pdo->prepare($count_query);
foreach ($params as $key => $val) {
    $count_stmt->bindValue($key, $val);
}
$count_stmt->execute();
$total_students = $count_stmt->fetchColumn();
$total_pages = ceil($total_students / $per_page);

// Determine sorting
$order_by = "ORDER BY s.id DESC"; // Default sort
if (!empty($sort_by_filter)) {
    if ($sort_by_filter === 'student_name_asc') {
        $order_by = " ORDER BY s.name ASC";
    } elseif ($sort_by_filter === 'student_name_desc') {
        $order_by = " ORDER BY s.name DESC";
    } elseif ($sort_by_filter === 'roll_number_asc') {
        $order_by = " ORDER BY s.roll_no ASC";
    } elseif ($sort_by_filter === 'roll_number_desc') {
        $order_by = " ORDER BY s.roll_no DESC";
    }
}

// Add sorting and pagination
$query .= " " . $order_by . " LIMIT :limit OFFSET :offset";
$params[':limit'] = $per_page;
$params[':offset'] = $offset;

// Execute query and fetch students
$stmt = $pdo->prepare($query);
foreach ($params as $key => &$val) {
    if ($key === ':limit' || $key === ':offset') {
        $stmt->bindParam($key, $val, PDO::PARAM_INT);
    } else {
        $stmt->bindParam($key, $val);
    }
}
$stmt->execute();
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);


// Get driving routes for students
$student_ids = array_column($students, 'student_id');
if (!empty($student_ids)) {
    $in_query = implode(',', array_fill(0, count($student_ids), '?'));
    $route_stmt = $pdo->prepare("SELECT id, route_name FROM driving_routes WHERE id IN (SELECT DISTINCT driving_route_id FROM students WHERE student_id IN ($in_query) AND driving_route_id IS NOT NULL AND driving_route_id != '')");
    $route_stmt->execute($student_ids);
    $routes = $route_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    // Map routes to students
    foreach ($students as &$student) {
        if (!empty($student['driving_route_id']) && isset($routes[$student['driving_route_id']])) {
            $student['driving_route'] = $routes[$student['driving_route_id']];
        } else {
            $student['driving_route'] = null;
        }
    }
    unset($student);
}


// Prepare response
$response = [
    'success' => true,
    'students' => $students,
    'total_students' => $total_students,
    'total_pages' => $total_pages,
    'current_page' => $page,
    'classes' => $pdo->query("SELECT * FROM classes")->fetchAll(),
    'sections' => $pdo->query("SELECT s.id, s.section_name, c.class_name FROM sections s JOIN classes c ON s.class_id = c.id ORDER BY c.class_name, s.section_name")->fetchAll(),
    'exams' => $pdo->query("SELECT * FROM exams WHERE status = 'active' ORDER BY exam_date DESC")->fetchAll(),
    'admit_cards' => $pdo->query("SELECT ea.id, e.exam_name, c.class_name FROM exam_admit_releases ea JOIN exams e ON ea.exam_id = e.id JOIN classes c ON ea.class_id = c.id WHERE ea.status = 'released' ORDER BY e.exam_date DESC")->fetchAll()
];

echo json_encode($response);
exit;
