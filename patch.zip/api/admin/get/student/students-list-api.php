<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");

// Initialize filter variables
$search = trim($_GET['search'] ?? '');
$class_filter = isset($_GET['class']) ? (int)$_GET['class'] : '';
$section_filter = isset($_GET['section']) ? (int)$_GET['section'] : '';
$gender_filter = isset($_GET['gender']) ? $_GET['gender'] : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';
$fee_status_filter_monthly = isset($_GET['monthly_fee_status']) ? $_GET['monthly_fee_status'] : '';
$fee_status_filter_admission = isset($_GET['admission_fee_status']) ? $_GET['admission_fee_status'] : '';
$hosteler_filter = isset($_GET['hosteler']) ? $_GET['hosteler'] : '';
$car_route_filter = isset($_GET['car_route']) ? $_GET['car_route'] : '';
$driver_id_filter = isset($_GET['driver_id']) ? $_GET['driver_id'] : '';
$sort_by_filter = isset($_GET['sort_by']) ? $_GET['sort_by'] : '';
$academic_year_filter = isset($_GET['academic_year']) ? $_GET['academic_year'] : '';
$coaching_filter = isset($_GET['coaching']) ? $_GET['coaching'] : '';
$tiffin_filter = isset($_GET['tiffin']) ? $_GET['tiffin'] : '';
$custom_fee_filter = isset($_GET['customFee']) ? $_GET['customFee'] : '';
$paid_month_filter = isset($_GET['paid_month']) ? trim($_GET['paid_month']) : '';
$unpaid_month_filter = isset($_GET['unpaid_month']) ? trim($_GET['unpaid_month']) : '';

// Validating fees filter to avoid conflicts-এর নিচে এই লজিকটি দিন
if (!empty($paid_month_filter) && !empty($unpaid_month_filter) && $paid_month_filter === $unpaid_month_filter) {
    // ইউজার যদি Paid এবং Unpaid উভয় ক্ষেত্রেই একই মাস সিলেক্ট করে, তবে দুটি ফিল্টারই রিসেট হয়ে যাবে
    $paid_month_filter = "";
    $unpaid_month_filter = "";
}

// Validating fees filter to avoid conflicts
if (!empty($fee_status_filter_monthly) && !empty($fee_status_filter_admission)) {
    $fee_status_filter_monthly = "";
    $fee_status_filter_admission = "";
}

header('Content-Type: application/json');

// Pagination configuration
$per_page = 400;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $per_page;

// Where conditions
$where = [];
$params = [];

if (!empty($search)) {
    $where[] = "(s.student_id LIKE :search1 
                OR s.name LIKE :search2 
                OR s.father_name LIKE :search3 
                OR s.mother_name LIKE :search4 
                OR s.registration_no LIKE :search5 
                OR s.phone_number LIKE :search6 
                OR s.alternate_phone_number LIKE :search7 
                OR s.address LIKE :search8)";
                
    $params[':search1'] = "%$search%";
    $params[':search2'] = "%$search%";
    $params[':search3'] = "%$search%";
    $params[':search4'] = "%$search%";
    $params[':search5'] = "%$search%";
    $params[':search6'] = "%$search%";
    $params[':search7'] = "%$search%";
    $params[':search8'] = "%$search%";
}

if (!empty($class_filter)) {
    $where[] = "s.class_id = :class_id";
    $params[':class_id'] = $class_filter;
}

if (!empty($section_filter)) {
    if ($section_filter === -1) {
        $where[] = "(s.section_id IS NULL OR s.section_id = '')";
    } else {
        $where[] = "s.section_id = :section_id";
        $params[':section_id'] = $section_filter;
    }
}

if (!empty($gender_filter)) {
    $where[] = "s.gender = :gender";
    $params[':gender'] = $gender_filter;
}

if (!empty($status_filter)) {
    $where[] = "s.status = :status";
    $params[':status'] = $status_filter;
}

if (!empty($academic_year_filter)) {
    $where[] = "s.academic_year = :academic_year";
    $params[':academic_year'] = $academic_year_filter;
}

if ($hosteler_filter !== '') {
    $where[] = "s.is_hosteler = :is_hosteler";
    $params[':is_hosteler'] = (int)$hosteler_filter;
}

if (!empty($driver_id_filter)) {
    $where[] = "s.driving_route_id IN (SELECT id FROM driving_routes WHERE driver_id = :driver_id)";
    $params[':driver_id'] = $driver_id_filter;
}

if ($car_route_filter === 'has_route') {
    $where[] = "(s.driver_id IS NOT NULL AND s.driver_id > 0)";
} elseif ($car_route_filter === 'no_route') {
    $where[] = "(s.driver_id IS NULL OR s.driver_id = 0)";
}

if ($coaching_filter === '1') {
    $where[] = "s.coaching_fee > 0";
} elseif ($coaching_filter === '0') {
    $where[] = "(s.coaching_fee <= 0 OR s.coaching_fee IS NULL)";
}

if ($tiffin_filter === '1') {
    $where[] = "s.tiffin_fee > 0";
} elseif ($tiffin_filter === '0') {
    $where[] = "(s.tiffin_fee <= 0 OR s.tiffin_fee IS NULL)";
}

if ($custom_fee_filter === '1') {
    $where[] = "s.custom_class_fee > 0";
} elseif ($custom_fee_filter === '0') {
    $where[] = "(s.custom_class_fee <= 0 OR s.custom_class_fee IS NULL)";
}

// Fee status conditions utilizing fast EXISTS queries
if (!empty($fee_status_filter_monthly)) {
    if ($fee_status_filter_monthly === 'paid') {
        $where[] = "EXISTS (SELECT 1 FROM student_full_paid_fees WHERE student_id = s.student_id)";
    } elseif ($fee_status_filter_monthly === 'unpaid') {
        $where[] = "EXISTS (SELECT 1 FROM student_unpaid_fees WHERE student_id = s.student_id)";
    } elseif ($fee_status_filter_monthly === 'fully_paid') {
        $where[] = "NOT EXISTS (SELECT 1 FROM student_unpaid_fees WHERE student_id = s.student_id)";
    }
}

if (!empty($fee_status_filter_admission)) {
    if ($fee_status_filter_admission === 'paid') {
        $where[] = "EXISTS (SELECT 1 FROM admission_full_paid_fees WHERE student_id = s.student_id)";
    } elseif ($fee_status_filter_admission === 'unpaid') {
        $where[] = "EXISTS (SELECT 1 FROM admission_unpaid_fees WHERE student_id = s.student_id)";
    } elseif ($fee_status_filter_admission === 'fully_paid') {
        $where[] = "NOT EXISTS (SELECT 1 FROM admission_unpaid_fees WHERE student_id = s.student_id)";
    }
}

if (!empty($paid_month_filter)) {
    $where[] = "EXISTS (SELECT 1 FROM student_full_paid_fees WHERE student_id = s.student_id AND month_year = :paid_month)";
    $params[':paid_month'] = $paid_month_filter;
}

if (!empty($unpaid_month_filter)) {
    $where[] = "EXISTS (SELECT 1 FROM student_unpaid_fees WHERE student_id = s.student_id AND month_year = :unpaid_month)";
    $params[':unpaid_month'] = $unpaid_month_filter;
}

$where_sql = !empty($where) ? " WHERE " . implode(" AND ", $where) : "";

// -------------------------------------------------------------
// OPTIMIZED COUNT QUERY: No unnecessary joins!
// -------------------------------------------------------------
$count_query = "SELECT COUNT(s.id) FROM students s" . $where_sql;
$count_stmt = $pdo->prepare($count_query);
foreach ($params as $key => $val) {
    $count_stmt->bindValue($key, $val);
}
$count_stmt->execute();
$total_students = $count_stmt->fetchColumn();
$total_pages = ceil($total_students / $per_page);

// Determine sorting
$order_by = " ORDER BY s.id DESC"; // Default sort
if (!empty($sort_by_filter)) {
    if ($sort_by_filter === 'student_name_asc') $order_by = " ORDER BY s.name ASC, s.id DESC";
    elseif ($sort_by_filter === 'student_name_desc') $order_by = " ORDER BY s.name DESC, s.id DESC";
    elseif ($sort_by_filter === 'roll_number_asc') $order_by = " ORDER BY s.roll_no ASC, s.id DESC";
    elseif ($sort_by_filter === 'roll_number_desc') $order_by = " ORDER BY s.roll_no DESC, s.id DESC";
    elseif ($sort_by_filter === 'registration_number_asc') $order_by = " ORDER BY s.registration_no ASC, s.id DESC";
    elseif ($sort_by_filter === 'registration_number_desc') $order_by = " ORDER BY s.registration_no DESC, s.id DESC";
    elseif ($sort_by_filter === 'pending_fee_desc') $order_by = " ORDER BY total_pending_fees DESC, s.id DESC";
    elseif ($sort_by_filter === 'pending_fee_asc') $order_by = " ORDER BY total_pending_fees ASC, s.id DESC";
}

// -------------------------------------------------------------
// OPTIMIZED MAIN QUERY
// -------------------------------------------------------------
$select_sql = "SELECT s.*, c.class_name, sec.section_name";

// If sorting by fee, we MUST calculate it in SQL, otherwise avoid it completely
if ($sort_by_filter === 'pending_fee_desc' || $sort_by_filter === 'pending_fee_asc') {
    $select_sql .= ", (
        COALESCE((SELECT SUM(unpaid_amount) FROM student_unpaid_fees WHERE student_id = s.student_id), 0) + 
        COALESCE((SELECT SUM(unpaid_amount) FROM admission_unpaid_fees WHERE student_id = s.student_id), 0)
    ) as total_pending_fees";
}

$query = "$select_sql FROM students s 
          LEFT JOIN classes c ON s.class_id = c.id 
          LEFT JOIN sections sec ON s.section_id = sec.id 
          $where_sql $order_by LIMIT :limit OFFSET :offset";

$stmt = $pdo->prepare($query);
foreach ($params as $key => &$val) {
    $stmt->bindParam($key, $val);
}
$stmt->bindParam(':limit', $per_page, PDO::PARAM_INT);
$stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

// -------------------------------------------------------------
// BATCH PROCESSING (Lightweight Post-processing to save RAM)
// -------------------------------------------------------------
$student_ids = array_column($students, 'student_id');
if (!empty($student_ids)) {
    $in_query = implode(',', array_fill(0, count($student_ids), '?'));
    
    // 1. Driving Routes Fetching
    $route_stmt = $pdo->prepare("SELECT id, route_name FROM driving_routes WHERE id IN (SELECT DISTINCT driving_route_id FROM students WHERE student_id IN ($in_query) AND driving_route_id IS NOT NULL AND driving_route_id != '')");
    $route_stmt->execute($student_ids);
    $routes = $route_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    // 2. Unpaid Monthly Fees & Amounts Fetching (Batch)
    $unpaid_stmt = $pdo->prepare("
        SELECT student_id, month_year, unpaid_amount 
        FROM student_unpaid_fees 
        WHERE student_id IN ($in_query) 
        ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC
    ");
    $unpaid_stmt->execute($student_ids);
    
    $student_unpaid_months = [];
    $student_unpaid_monthly_totals = [];
    while ($row = $unpaid_stmt->fetch(PDO::FETCH_ASSOC)) {
        $sid = $row['student_id'];
        $student_unpaid_months[$sid][] = $row['month_year'];
        $student_unpaid_monthly_totals[$sid] = ($student_unpaid_monthly_totals[$sid] ?? 0) + (float)$row['unpaid_amount'];
    }

    // 3. Unpaid Admission Fees & Amounts Fetching (Batch)
    $admission_stmt = $pdo->prepare("
        SELECT student_id, academic_year, unpaid_amount 
        FROM admission_unpaid_fees 
        WHERE student_id IN ($in_query) 
        ORDER BY academic_year ASC
    ");
    $admission_stmt->execute($student_ids);
    
    $student_admission_years = [];
    $student_unpaid_admission_totals = [];
    while ($row = $admission_stmt->fetch(PDO::FETCH_ASSOC)) {
        $sid = $row['student_id'];
        $student_admission_years[$sid][] = $row['academic_year'];
        $student_unpaid_admission_totals[$sid] = ($student_unpaid_admission_totals[$sid] ?? 0) + (float)$row['unpaid_amount'];
    }

    // 4. All Class Fees Fetching 
    $class_fee_stmt = $pdo->query("SELECT class_id, amount FROM class_wise_monthly_fees");
    $class_fees = $class_fee_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    // 5. Map everything to the students array
    foreach ($students as &$student) {
        $sid = $student['student_id'];
        $class_id = (int)$student['class_id'];

        // Driving route
        $student['driving_route'] = (!empty($student['driving_route_id']) && isset($routes[$student['driving_route_id']])) 
                                    ? $routes[$student['driving_route_id']] 
                                    : null;

        // Due months text
        $student['due_months'] = ""; 
        if (isset($student_unpaid_months[$sid])) {
            $months = $student_unpaid_months[$sid];
            $student['due_months'] = count($months) == 1 ? $months[0] : $months[0] . ' - ' . end($months);
        }

        // Admission Due years text
        $student['admission_due_years'] = isset($student_admission_years[$sid]) 
                                        ? implode(', ', $student_admission_years[$sid]) 
                                        : "";

        // Calculated Pending Amounts
        $student['total_monthly_pending_fees'] = $student_unpaid_monthly_totals[$sid] ?? 0;
        $student['total_admission_pending_fees'] = $student_unpaid_admission_totals[$sid] ?? 0;
        $student['total_pending_fees'] = $student['total_monthly_pending_fees'] + $student['total_admission_pending_fees'];

        // Monthly Fees Calculation
        $class_fee = isset($class_fees[$class_id]) ? (float)$class_fees[$class_id] : 0.00;
        $custom_fee = (float)($student['custom_class_fee'] ?? 0);
        
        $monthly_fee = ($custom_fee > 0 ? $custom_fee : $class_fee) + 
                       (float)($student['car_fee'] ?? 0) + 
                       (float)($student['hostel_fee'] ?? 0) + 
                       (float)($student['coaching_fee'] ?? 0) + 
                       (float)($student['tiffin_fee'] ?? 0);

        $student['class_fee'] = $class_fee;
        $student['monthly_fee'] = $monthly_fee;
    }
    unset($student);
}

// Clear memory for heavy variables
unset($routes, $student_unpaid_months, $student_unpaid_monthly_totals, $student_admission_years, $student_unpaid_admission_totals, $class_fees);

// Prepare response
echo json_encode([
    'success' => true,
    'students' => $students,
    'total_students' => $total_students,
    'total_pages' => $total_pages,
    'current_page' => $page
]);
exit;