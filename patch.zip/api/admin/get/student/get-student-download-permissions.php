<?php
require_once __DIR__ . '/../../../../includes/auth-check.php';
require_once __DIR__ . '/../../../../includes/exam-document-access.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
authenticateAdminApiRequest($pdo);
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    http_response_code(403);
    exit(json_encode(['success' => false, 'message' => 'You do not have permission to manage student download access.']));
}
try {
    $ids = examDocumentCsv($_GET['student_id'] ?? null);
    if (count($ids) !== 1) throw new InvalidArgumentException('Select one student.');
    $studentId = $ids[0];
    $statement = $pdo->prepare('SELECT name FROM students WHERE student_id = ?');
    $statement->execute([$studentId]);
    if ($statement->fetchColumn() === false) throw new InvalidArgumentException('Student not found.');
    $access = examDocumentPermissions($pdo, $studentId);
    $statement = $pdo->prepare('SELECT * FROM student_download_permissions WHERE student_id = ?');
    $statement->execute([$studentId]);
    $data = $statement->fetch(PDO::FETCH_ASSOC) ?: [];
    foreach (['admit', 'marksheet'] as $type) {
        $active = $access[$type . '_override_active'];
        $data['override_' . $type . '_check'] = $active ? 1 : 0;
        $allow = $type === 'admit' ? 'allow_admit_card' : 'allow_marksheet';
        $data[$allow] = $active && !empty($data[$allow]) ? 1 : 0;
        $data[$type . '_expires_at'] = $active ? $access[$type . '_expires_at'] : null;
    }
    $data['notes'] ??= '';
    echo json_encode(['success' => true, 'data' => $data, 'fee_paid' => $access['all_fees_paid'],
        'unpaid_amount' => $access['fees']['total_amount'], 'fee_breakdown' => $access['fees'],
        'server_time' => date('Y-m-d H:i:s'), 'timezone' => date_default_timezone_get()]);
} catch (InvalidArgumentException $error) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => $error->getMessage()]);
} catch (Throwable $error) {
    error_log('Student download permissions: ' . $error->getMessage());
    http_response_code(503);
    echo json_encode(['success' => false, 'message' => 'Download permissions could not be loaded. Please try again later.']);
}
