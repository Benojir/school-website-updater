<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

$studentId = $_REQUEST['student_id'] ?? '';

if (empty($studentId)) {
    echo json_encode(['success' => false, 'message' => 'Student ID is required']);
    exit;
}

// Fetch current permissions
$stmt = $pdo->prepare("
    SELECT 
        override_admit_check,
        allow_admit_card,
        override_marksheet_check,
        allow_marksheet,
        notes 
    FROM student_download_permissions 
    WHERE student_id = ?
");
$stmt->execute([$studentId]);
$permissions = $stmt->fetch(PDO::FETCH_ASSOC);

// Fetch fee status
$stmt = $pdo->prepare("SELECT * FROM student_unpaid_fees WHERE student_id = ?");
$stmt->execute([$studentId]);
$unpaid_fees = $stmt->fetch(PDO::FETCH_ASSOC);

$fee_paid = true;

if ($unpaid_fees) {
    $fee_paid = false;
}

if (!$permissions) {
    $permissions = [
        'override_admit_check' => 0,
        'allow_admit_card' => 0,
        'override_marksheet_check' => 0,
        'allow_marksheet' => 0,
        'notes' => ''
    ];
}

echo json_encode([
    'success' => true,
    'data' => $permissions,
    'fee_paid' => $fee_paid,
    'unpaid_amount' => number_format($unpaid_fees['unpaid_amount'] ?? 0, 2)
]);
?>