<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

try {
    // Prepare and execute query
    $stmt = $pdo->prepare("SELECT * FROM notices ORDER BY notice_date DESC, created_at DESC LIMIT 30");
    $stmt->execute();

    $notices = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $formatted_notices = [];

    if (!empty($notices)) {
        foreach ($notices as $notice) {
            // ডাটাগুলো অ্যাপ এবং ওয়েবের জন্য গুছিয়ে নিচ্ছি
            $raw_content = strip_tags($notice['content']);
            $short_content = mb_substr($raw_content, 0, 100);
            if (mb_strlen($raw_content) > 100) {
                $short_content .= '...';
            }

            $formatted_notices[] = [
                'id' => $notice['id'],
                'notice_date' => $notice['notice_date'],
                'formatted_date' => date('d M Y', strtotime($notice['notice_date'])),
                'title' => safe_htmlspecialchars($notice['title']),
                'content' => safe_htmlspecialchars($raw_content), // ফুল কন্টেন্ট
                'short_content' => safe_htmlspecialchars($short_content) // টেবিলের জন্য শর্ট কন্টেন্ট
            ];
        }
    }

    // Return JSON response (শুধুমাত্র ডাটা)
    echo json_encode([
        'success' => true,
        'data' => $formatted_notices
    ]);

} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}