<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

// Check admin permissions
session_start();
// if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'admin') {
//     echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
//     exit();
// }

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $noticeId = intval($_GET['id']);

    try {
        $stmt = $pdo->prepare("SELECT * FROM notices WHERE id = ?");
        $stmt->execute([$noticeId]);
        $notice = $stmt->fetch();

        if ($notice) {
            echo json_encode(['success' => true, 'data' => $notice]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Notice not found']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
}
?>