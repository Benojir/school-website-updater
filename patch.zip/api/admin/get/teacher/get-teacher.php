<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$response = ['success' => false, 'teacher' => null];

try {
    if ($id > 0) {
        $stmt = $pdo->prepare("SELECT * FROM teachers WHERE id = ?");
        $stmt->execute([$id]);
        $teacher = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($teacher) {
            $response['success'] = true;
            $response['teacher'] = $teacher;
        } else {
            $response['message'] = 'Teacher not found';
        }
    } else {
        $response['message'] = 'Invalid teacher ID';
    }
} catch (PDOException $e) {
    $response['message'] = 'Database error: ' . $e->getMessage();
}

echo json_encode($response);