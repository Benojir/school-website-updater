<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check permission
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

// Validate input
if (!isset($_GET['application_id']) || empty(trim($_GET['application_id']))) {
    echo json_encode(['success' => false, 'message' => 'Application ID is required']);
    exit;
}

$application_id = (int) trim($_GET['application_id']);

try {
    // Applications are stored in the teachers table with an application status
    $stmt = $pdo->prepare("SELECT * FROM teachers WHERE id = ? AND status IN ('pending', 'reject', 'archive')");
    $stmt->execute([$application_id]);
    $application = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$application) {
        echo json_encode(['success' => false, 'message' => 'Application not found']);
        exit;
    }

    // Hand the documents over as a real array so the client doesn't have to parse JSON
    $documents = json_decode($application['documents'] ?? '[]', true);
    $application['documents'] = is_array($documents) ? $documents : [];

    echo json_encode(['success' => true, 'message' => 'Application details fetched successfully', 'application' => $application]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'An error occurred. ' . $e->getMessage()]);
    exit;
}
