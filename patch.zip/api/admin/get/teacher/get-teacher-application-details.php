<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check permission
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

// Validate input
if (!isset($_GET['application_id']) || empty(trim($_GET['application_id']))) {
    echo json_encode(['success' => false, 'message' => 'Application ID is required']);
    exit;
}

$application_id = trim($_GET['application_id']);

try {
    // Fetch application details
    $stmt = $pdo->prepare("SELECT * FROM teacher_applications WHERE id = ?");
    $stmt->execute([$application_id]);
    $application = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$application) {
        echo json_encode(['success' => false, 'message' => 'Application not found']);
        exit;
    }

    echo json_encode(['success' => true, 'message' => 'Application details fetched successfully', 'application' => $application]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'An error occurred. ' . $e->getMessage()]);
    exit;
}
?>