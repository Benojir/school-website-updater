<?php
include_once(__DIR__ . "/../../../../includes/config.php");

header('Content-Type: application/json');

if (!isset($websiteConfig)) {
    echo json_encode([
        'success' => false,
        'message' => 'Website configuration not found.'
    ]);
    exit;
}

$settings = [
    'country_code' => '91',
    'theme_color' => $websiteConfig['theme_color'],
    'is_online_payment_available' => ($additional_website_configs['allow_online_payment']) ? true : false,
    'currency_symbol' => $websiteConfig['currency_symbol'],
    'telegram_bot_token' => $websiteConfig['telegram_bot_token']
];

echo json_encode([
    'success' => true,
    'data' => $settings
]);
