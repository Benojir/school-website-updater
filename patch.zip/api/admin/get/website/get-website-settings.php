<?php
include_once(__DIR__ . "/../../../../includes/config.php");

header('Content-Type: application/json');

if (!isset($websiteConfig)) {
    echo json_encode([
        'success' => false,
        'message' => 'Website configuration not found.'
    ]);
    exit;
}

$settings = [
    'country_code' => $websiteConfig['country_code'],
    'theme_color' => $websiteConfig['theme_color'],
    'is_online_payment_available' => ($websiteConfig['allow_online_payment'] == "yes") ? true : false,
    'currency_symbol' => $websiteConfig['currency_symbol']
];

echo json_encode([
    'success' => true,
    'data' => $settings
]);
