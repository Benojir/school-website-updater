<?php
include_once(__DIR__ . "/../../../../includes/config.php");

header('Content-Type: application/json');

try {
    $logo_square_path = __DIR__ . '/../../../../uploads/school/logo-square.png';
    $logo_square_mod_time = file_exists($logo_square_path) ? filemtime($logo_square_path) : 0;
    $logo_square = BASE_URL . '/uploads/school/logo-square.png?v=' . $logo_square_mod_time;

    $logo_rectangle_path = __DIR__ . '/../../../../uploads/school/logo-rectangle.png';
    $logo_rectangle_mod_time = file_exists($logo_rectangle_path) ? filemtime($logo_rectangle_path) : 0;
    $logo_rectangle = BASE_URL . '/uploads/school/logo-rectangle.png?v=' . $logo_rectangle_mod_time;

    $schoolInfo['logo-square'] = $logo_square;
    $schoolInfo['logo-rectangle'] = $logo_rectangle;
    
    echo json_encode([
        'success' => true,
        'message' => 'School information retrieved successfully.',
        'school_information' => $schoolInfo
    ]);
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
