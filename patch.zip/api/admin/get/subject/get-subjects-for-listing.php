<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$offset = ($page - 1) * $limit;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
$type = isset($_GET['type']) ? trim($_GET['type']) : '';

$response = [
    'subjects' => [],
    'total' => 0
];

try {
    // Base query
    $sql = "SELECT SQL_CALC_FOUND_ROWS s.id, s.subject_name, s.subject_type, c.class_name 
            FROM subjects s 
            JOIN classes c ON s.class_id = c.id 
            WHERE 1=1";
    
    $params = [];
    
    // Add search condition
    if (!empty($search)) {
        $sql .= " AND (s.subject_name LIKE ? OR c.class_name LIKE ?)";
        $searchParam = "%$search%";
        $params[] = $searchParam;
        $params[] = $searchParam;
    }
    
    // Add class filter
    if ($class_id > 0) {
        $sql .= " AND s.class_id = ?";
        $params[] = $class_id;
    }
    
    // Add type filter
    if (!empty($type)) {
        $sql .= " AND s.subject_type = ?";
        $params[] = $type;
    }
    
    // Add sorting and pagination
    $sql .= " ORDER BY c.class_name, s.subject_name LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    
    // Prepare and execute query
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $response['subjects'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total count
    $totalStmt = $pdo->query("SELECT FOUND_ROWS()");
    $response['total'] = $totalStmt->fetchColumn();
} catch (PDOException $e) {
    http_response_code(500);
    $response['error'] = 'Database error: ' . $e->getMessage();
}

echo json_encode($response);