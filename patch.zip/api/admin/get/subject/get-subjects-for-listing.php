<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 30;
$offset = ($page - 1) * $limit;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
$type = isset($_GET['type']) ? trim($_GET['type']) : '';
$order_by = isset($_GET['order_by']) ? trim($_GET['order_by']) : '';

$response = [
    'subjects' => [],
    'total' => 0,
    'success' => false,
    'message' => ''
];

try {
    // 1. Build the dynamic WHERE clause and parameters array
    // We do this first so we can reuse it for both the Count query and the Data query.
    $where_conditions = ["1=1"];
    $params = [];

    // Add search condition
    if (!empty($search)) {
        $where_conditions[] = "(s.subject_name LIKE ? OR c.class_name LIKE ?)";
        $searchParam = "%$search%";
        $params[] = $searchParam;
        $params[] = $searchParam;
    }

    // Add class filter
    if ($class_id > 0) {
        $where_conditions[] = "s.class_id = ?";
        $params[] = $class_id;
    }

    // Add type filter
    if (!empty($type)) {
        $where_conditions[] = "s.subject_type = ?";
        $params[] = $type;
    }

    // Combine conditions into a string
    $where_clause = implode(" AND ", $where_conditions);

    // 2. Query A: Get Total Count
    // This query runs without LIMIT/OFFSET to get the total matching records
    $count_sql = "SELECT COUNT(*) 
                  FROM subjects s 
                  JOIN classes c ON s.class_id = c.id 
                  WHERE $where_clause";
    
    $count_stmt = $pdo->prepare($count_sql);
    $count_stmt->execute($params);
    $total_records = $count_stmt->fetchColumn();


    // 3. Query B: Fetch Data
    // Prepare sorting
    $order_by_sql = ' ORDER BY c.class_name, s.subject_name';
    
    if (!empty($order_by)) {
        if ($order_by === 'marksheet_order_asc') {
            $order_by_sql = " ORDER BY s.marksheet_order_by ASC";
        } elseif ($order_by === 'marksheet_order_desc') {
            $order_by_sql = " ORDER BY s.marksheet_order_by DESC";
        }
    }

    // Construct final data query
    $data_sql = "SELECT s.id, s.subject_name, s.subject_type, c.class_name, s.class_id, s.exclude_from_marksheet
                 FROM subjects s 
                 JOIN classes c ON s.class_id = c.id 
                 WHERE $where_clause 
                 $order_by_sql 
                 LIMIT ? OFFSET ?";
    
    // Add LIMIT and OFFSET to parameters for the data query only
    // We clone the original params array to avoid modifying it if we were to loop, 
    // though here we just append to the current array usage.
    $data_params = $params; 
    $data_params[] = $limit;
    $data_params[] = $offset;

    $stmt = $pdo->prepare($data_sql);
    $stmt->execute($data_params);
    $subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 4. Prepare Response
    $response['subjects'] = $subjects;
    $response['total'] = $total_records;
    $response['success'] = true;
    $response['message'] = "Subjects fetched successfully!";

} catch (PDOException $e) {
    http_response_code(500);
    $response['success'] = false;
    $response['message'] = "Database error: " . $e->getMessage();
}

echo json_encode($response);
?>