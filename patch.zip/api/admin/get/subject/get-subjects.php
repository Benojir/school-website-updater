<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

if (isset($_REQUEST['class_id'])) {
    $class_id = (int)$_REQUEST['class_id'];
    $stmt = $pdo->prepare("SELECT id, subject_name FROM subjects WHERE class_id = ?");
    $stmt->execute([$class_id]);
    $subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($subjects);
} else {
    echo json_encode([]);
}
?>