<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

$class_id = $_REQUEST['class_id'] ?? 0;
$filter_exclude_from_marksheet = isset($_REQUEST['filter_exclude_from_marksheet']) ? 1 : 0;
$order_by = $_REQUEST['order_by'] ?? '';

if ($class_id == 0) {
    echo json_encode([]);
    exit;
}

$sql = "SELECT id, subject_name FROM subjects WHERE class_id = ?";
$data = [$class_id];

if ($filter_exclude_from_marksheet) {
    $exclude_from_marksheet = 0;
    $sql .= " AND exclude_from_marksheet = ?";
    $data[] = $exclude_from_marksheet;
}

if ($order_by == 'mark_entry_order_asc') {
    $sql .= " ORDER BY mark_entry_order_by ASC";
} elseif ($order_by == 'mark_entry_order_desc') {
    $sql .= " ORDER BY mark_entry_order_by DESC";
}

$stmt = $pdo->prepare($sql);
$stmt->execute($data);
$subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($subjects);
