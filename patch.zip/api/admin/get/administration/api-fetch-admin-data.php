<?php
// api-fetch-data.php
include_once(__DIR__ . "/../../../../includes/auth-check.php"); // Adjust path as needed

if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$action = $_GET['action'] ?? '';

// 1. Get All Admins (HTML for Table)
if ($action === 'get_admins_table') {
    $admins = $pdo->query("SELECT u.*, r.name as role_name FROM users u LEFT JOIN admin_roles r ON u.role_id = r.id WHERE u.user_role = 'admin'")->fetchAll();

    foreach ($admins as $admin) {
        echo '<tr data-id="' . $admin['id'] . '">
            <td>' . $admin['id'] . '</td>
            <td>' . safe_htmlspecialchars($admin['full_name']) . '</td>
            <td>' . safe_htmlspecialchars($admin['username']) . '</td>
            <td>' . safe_htmlspecialchars($admin['email']) . '</td>
            <td>' . safe_htmlspecialchars($admin['role_name'] ?? 'No Role') . '</td>
            <td>' . ucfirst($admin['status']) . '</td>
            <td>
                <button class="btn btn-sm btn-info edit-admin" data-id="' . $admin['id'] . '"><i class="fa fa-edit"></i> Edit</button>
                <button class="btn btn-sm btn-danger delete-admin" data-id="' . $admin['id'] . '" data-name="' . safe_htmlspecialchars($admin['full_name']) . '"><i class="fa fa-trash"></i> Delete</button>
            </td>
        </tr>';
    }
    exit();
}

// 2. Get All Roles (JSON for Dropdown/Table)
if ($action === 'get_roles_list') {
    $roles = $pdo->query("SELECT r.*, COUNT(p.id) as permissions_count, COUNT(u.id) as admins_count FROM admin_roles r LEFT JOIN admin_permissions p ON r.id = p.role_id LEFT JOIN users u ON r.id = u.role_id AND u.user_role = 'admin' GROUP BY r.id")->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($roles);
    exit();
}

// 3. Get Single Admin (JSON for Edit Modal)
if ($action === 'get_single_admin') {
    $id = (int)$_GET['id'];
    $stmt = $pdo->prepare("SELECT id, full_name, username, email, role_id FROM users WHERE id = ?");
    $stmt->execute([$id]);
    echo json_encode(['success' => true, 'data' => $stmt->fetch(PDO::FETCH_ASSOC)]);
    exit();
}

// 4. Get Single Role & Permissions (JSON for Edit Modal)
if ($action === 'get_single_role') {
    $id = (int)$_GET['id'];
    $role = $pdo->prepare("SELECT * FROM admin_roles WHERE id = ?");
    $role->execute([$id]);

    $perms = $pdo->prepare("SELECT permission FROM admin_permissions WHERE role_id = ?");
    $perms->execute([$id]);

    echo json_encode([
        'success' => true,
        'role' => $role->fetch(PDO::FETCH_ASSOC),
        'permissions' => $perms->fetchAll(PDO::FETCH_COLUMN)
    ]);
    exit();
}
