<?php
/** @var PDO $pdo */
include_once(__DIR__ . "/../../../../includes/auth-check.php");
header('Content-Type: application/json');

// Fetch marksheet settings
$stmt = $pdo->prepare("SELECT * FROM settings_marksheet LIMIT 1");
$stmt->execute();
$marksheet_settings = $stmt->fetch(PDO::FETCH_ASSOC);

$exam_id = $_REQUEST['exam_id'] ?? 0;
$class_id = $_REQUEST['class_id'] ?? 0;
$section_id = $_REQUEST['section_id'] ?? null;
$include_minor_subjects_marks = $marksheet_settings['include_minor_subjects_marks'];

// Validate inputs
if (!$exam_id || !$class_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

// Fetch total students in class
$stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE class_id = ?");
$stmt->execute([$class_id]);
$total_students = $stmt->fetchColumn();

$top_rankers = getTopRankersForSingleMarksheet($pdo, $class_id, $exam_id, $include_minor_subjects_marks, $section_id, $total_students);

echo json_encode([
    'success' => true,
    'message' => 'Top rankers fetched successfully',
    'data' => $top_rankers
]);
