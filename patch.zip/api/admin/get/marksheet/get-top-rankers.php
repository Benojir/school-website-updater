<?php
/** @var PDO $pdo */
include_once(__DIR__ . "/../../../../includes/auth-check.php");
header('Content-Type: application/json');

// Fetch marksheet settings
$stmt = $pdo->prepare("SELECT * FROM settings_marksheet LIMIT 1");
$stmt->execute();
$marksheet_settings = $stmt->fetch(PDO::FETCH_ASSOC);

$exam_ids = getRankingExamIds($_REQUEST['exam_ids'] ?? $_REQUEST['exam_id'] ?? []);
$class_id = filter_var($_REQUEST['class_id'] ?? 0, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$section_value = $_REQUEST['section_id'] ?? '';
$section_id = $section_value === '' ? null : filter_var($section_value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);

// Validate inputs
if (!$exam_ids || !$class_id || $section_id === false) {
    echo json_encode(['success' => false, 'message' => 'Please select at least one valid exam and a class.']);
    exit;
}

$top_rankers = getTopRankersForSelectedExams($pdo, $exam_ids, $class_id, $marksheet_settings, $section_id);

echo json_encode([
    'success' => true,
    'message' => 'Top rankers fetched successfully',
    'data' => $top_rankers
]);
