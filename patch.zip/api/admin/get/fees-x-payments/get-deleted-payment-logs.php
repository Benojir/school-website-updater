<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

// --- Input Sanitization & Defaults ---
$payment_type = (isset($_GET['paymentType']) ? sanitize_input($_GET['paymentType']) : '');
$page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, ['options' => ['default' => 1, 'min_range' => 1]]);
$search_query = (isset($_GET['search']) ? sanitize_input($_GET['search']) : '');
$start_date = (isset($_GET['startDate']) ? sanitize_input($_GET['startDate']) : '');
$end_date = (isset($_GET['endDate']) ? sanitize_input($_GET['endDate']) : '');
$adminId = (isset($_GET['adminId']) ? sanitize_input($_GET['adminId']) : '');
$per_page = 20;
$offset = ($page - 1) * $per_page;

// Payment type is optional here (empty = both admission & monthly)
if (!empty($payment_type) && $payment_type !== 'admission' && $payment_type !== 'monthly') {
    echo json_encode(['success' => false, 'message' => 'Invalid fees type provided.']);
    exit;
}

// The log table only stores IDs, so all names come from these joins
$join_sql = "LEFT JOIN students s ON l.student_id = s.student_id
             LEFT JOIN classes c ON c.id = s.class_id
             LEFT JOIN sections sec ON sec.id = s.section_id
             LEFT JOIN users ea ON l.payment_entry_by = ea.id
             LEFT JOIN users da ON l.deleted_by = da.id";

// --- Build Dynamic WHERE clause ---
$where_clauses = [];
$params = [];

if (!empty($payment_type)) {
    $where_clauses[] = "l.payment_type = ?";
    $params[] = $payment_type;
}

if (!empty($search_query)) {
    $search_conditions = [
        "l.student_id LIKE ?",
        "s.name LIKE ?",
        "s.registration_no LIKE ?",
        "s.roll_no LIKE ?",
        "s.father_name LIKE ?",
        "s.mother_name LIKE ?",
        "s.phone_number LIKE ?",
        "s.alternate_phone_number LIKE ?",
        "s.email LIKE ?",
        "s.address LIKE ?",
        "l.payment_remark LIKE ?",
        "da.full_name LIKE ?",
        "ea.full_name LIKE ?"
    ];

    $where_clauses[] = "(" . implode(" OR ", $search_conditions) . ")";

    $search_param = "%" . $search_query . "%";
    for ($i = 0; $i < count($search_conditions); $i++) {
        $params[] = $search_param;
    }
}

// Date range filters on the deletion date
if (!empty($start_date)) {
    $where_clauses[] = "DATE(l.deleted_at) >= ?";
    $params[] = $start_date;
}

if (!empty($end_date)) {
    $where_clauses[] = "DATE(l.deleted_at) <= ?";
    $params[] = $end_date;
}

// Filter by the admin who performed the deletion
if (!empty($adminId)) {
    if ($adminId == 'unknown') {
        $where_clauses[] = "l.deleted_by IS NULL";
    } else {
        $where_clauses[] = "l.deleted_by = ?";
        $params[] = $adminId;
    }
}

$where_sql = count($where_clauses) > 0 ? 'WHERE ' . implode(' AND ', $where_clauses) : '';

try {
    // --- Get Total Count for Pagination ---
    $count_sql = "SELECT COUNT(l.id)
                  FROM deleted_payment_logs l
                  $join_sql
                  $where_sql";
    $stmt_count = $pdo->prepare($count_sql);
    $stmt_count->execute($params);
    $total_logs = $stmt_count->fetchColumn();
    $total_pages = ceil($total_logs / $per_page);

    // --- Get Paginated Log Data ---
    $data_sql = "SELECT l.*,
                        s.name AS student_name, s.father_name, s.class_id, s.section_id,
                        s.roll_no, s.registration_no, s.phone_number, s.student_image, s.address,
                        c.class_name, sec.section_name,
                        ea.full_name AS payment_entry_by_name,
                        da.full_name AS deleted_by_name
                 FROM deleted_payment_logs l
                 $join_sql
                 $where_sql
                 ORDER BY l.id DESC
                 LIMIT ? OFFSET ?";

    $stmt_data = $pdo->prepare($data_sql);
    // Manually bind LIMIT and OFFSET as integers
    $param_count = count($params);
    for ($i = 0; $i < $param_count; $i++) {
        $stmt_data->bindValue($i + 1, $params[$i]);
    }
    $stmt_data->bindValue($param_count + 1, $per_page, PDO::PARAM_INT);
    $stmt_data->bindValue($param_count + 2, $offset, PDO::PARAM_INT);
    $stmt_data->execute();
    $logs = $stmt_data->fetchAll(PDO::FETCH_ASSOC);

    // --- Get Summary Data (Total Deleted Amount, Unique Students) ---
    $summary_sql = "SELECT
                        SUM(l.payment_amount) as total_amount,
                        COUNT(DISTINCT l.student_id) as total_students
                    FROM deleted_payment_logs l
                    $join_sql
                    $where_sql";
    $stmt_summary = $pdo->prepare($summary_sql);
    $stmt_summary->execute($params);
    $summary = $stmt_summary->fetch(PDO::FETCH_ASSOC);

    // --- Send Response ---
    echo json_encode([
        'success'       => true,
        'logs'          => $logs,
        'pagination'    => [
            'currentPage' => $page,
            'totalPages'  => $total_pages,
            'totalRecords' => $total_logs
        ],
        'summary'       => [
            'totalAmount'   => $summary['total_amount'] ?? 0,
            'totalStudents' => $summary['total_students'] ?? 0,
            'totalRecords'  => $total_logs
        ]
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
