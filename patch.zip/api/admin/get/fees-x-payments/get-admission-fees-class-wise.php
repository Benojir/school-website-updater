<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
$admission_type = isset($_GET['admission_type']) ? trim($_GET['admission_type']) : '';

$response = [
    'amounts' => [],
    'total' => 0
];

$allowed_admission_type = ['new-admission', 're-admission'];

if (!in_array($admission_type, $allowed_admission_type, true)) {
    // ❌ Invalid admission type or empty/null admission type
    echo json_encode($response);
    exit;
}

$table_name = "class_wise_new_admission_fees";

if ($admission_type == $allowed_admission_type[1]) {
    $table_name = "class_wise_re_admission_fees";
}

try {
    // Base query

    $sql = "SELECT cwaf.id, cwaf.class_id, cwaf.amount, c.class_name 
            FROM `{$table_name}` cwaf 
            JOIN classes c ON cwaf.class_id = c.id 
            WHERE 1=1";
    
    $params = [];
    
    // Add search condition
    if (!empty($search)) {
        $sql .= " AND (cwaf.amount LIKE ? OR c.class_name LIKE ?)";
        $searchParam = "%$search%";
        $params[] = $searchParam;
        $params[] = $searchParam;
    }
    
    // Add class filter
    if ($class_id > 0) {
        $sql .= " AND cwaf.class_id = ?";
        $params[] = $class_id;
    }
    
    // Prepare and execute query
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $response['amounts'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total count
    $totalStmt = $pdo->query("SELECT FOUND_ROWS()");
    $response['total'] = $totalStmt->fetchColumn();
} catch (PDOException $e) {
    http_response_code(500);
    $response['error'] = 'Database error: ' . $e->getMessage();
}

echo json_encode($response);