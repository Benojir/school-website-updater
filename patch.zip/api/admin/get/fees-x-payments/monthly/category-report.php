<?php
require_once __DIR__ . '/../../../../../includes/auth-check.php';
require_once __DIR__ . '/../../../../../includes/financial/monthly-fee-category-report.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if (!hasPermission(PERM_CAN_SEE_FINANCIAL_REPORT)) {
    http_response_code(403); echo json_encode(['success' => false, 'message' => 'Permission denied']); exit;
}
try {
    $report = (new MonthlyFeeCategoryReport($pdo))->read((string)($_GET['month'] ?? date('Y-m')),
        (string)($_GET['from'] ?? date('Y-m-01')), (string)($_GET['to'] ?? date('Y-m-d')),
        trim((string)($_GET['student_id'] ?? '')));
    echo json_encode(['success' => true, 'report' => $report], JSON_THROW_ON_ERROR);
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
