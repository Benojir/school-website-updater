<?php

/** @var PDO $pdo
 * @var string $currency_symbol
 */
include_once(__DIR__ . "/../../../../../includes/auth-check.php");

header('Content-Type: application/json');

if (!hasPermission(PERM_MANAGE_FEES)) {
    json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$student_id = $_POST['student_id'] ?? null;

if (!$student_id) {
    echo json_encode(array(
        "success" => false,
        "message" => "Missing required parameters."
    ));
    exit();
}

$unpaid_fees = getUnpaidMonthlyFeesData($pdo, $student_id);
$full_paid_fees = getPaidMonthlyFeesData($pdo, $student_id);

$unpaid_rows = '';
$total_unpaid_amount = 0;
$unpaid_months_list = [];
$unpaid_months_names = [];
$total_actual_amount = 0;
$total_discount_amount = 0;

if (count($unpaid_fees) > 0) {
    foreach ($unpaid_fees as $row) {
        // --- নতুন লজিক: হিসাবগুলো সেভ করা ---
        $total_unpaid_amount += ($row['unpaid_amount'] ?? 0);

        $total_actual_amount += ($row['actual_amount'] ?? 0);
        $total_discount_amount += ($row['discount_amount'] ?? 0);

        $unpaid_months_list[] = [
            'month' => $row['month_year'],
            'due'   => $row['unpaid_amount'] ?? 0
        ];
        $unpaid_months_names[] = $row['month_year'];
        
        $unpaid_rows .= '<tr class="text-center align-middle">';
        // ... আপনার আগের $unpaid_rows তৈরির কোড ...
        $unpaid_rows .= '<td><span class="fw-bold text-dark"><i class="fas fa-calendar-days"></i>' . $row["month_year"] . '</span></td>';
        $unpaid_rows .= '<td>' . $currency_symbol . $row['actual_amount'] . '</td>';
        $unpaid_rows .= '<td>' . $currency_symbol . ($row['actual_amount'] - $row['discount_amount']) . '</td>';
        $unpaid_rows .= '<td>' . $currency_symbol . $row['discount_amount'] . '</td>';
        $unpaid_rows .= "<td>" . $currency_symbol . $row['unpaid_amount'] . "</td>";

        if ($row['actual_amount'] - $row['discount_amount'] == $row['unpaid_amount']) {
            $unpaid_rows .= '<td>
                        <div class="btn-group" role="group">
                            <button onclick="deleteUnpaidFeeEntry(' . $row['id'] . ', \'' . $row['student_id'] . '\')" type="button" class="btn btn-danger btn-sm me-1" title="Delete Entry"><i class="fas fa-trash-alt"></i></button>
                            <button onclick="populateFeeEntryModal(' . $row['id'] . ', \'' . $row['month_year'] . '\', \'' . $row['student_id'] . '\')" type="button" class="btn btn-primary btn-sm edit-fee-btn" title="Edit Entry"><i class="fas fa-edit"></i></button>
                        </div>
                    </td>';
        } else {
            $unpaid_rows .= '<td>
                                <span class="badge bg-secondary-subtle text-secondary border px-3 py-2">
                                    <i class="fas fa-lock me-1"></i> Not Editable
                                </span>
                            </td>';
        }

        $unpaid_rows .= "</tr>";
    }
} else {
    $unpaid_rows = "<tr><td colspan='6'>No unpaid fees found.</td></tr>";
}

$paid_fees_rows = '';

if (count($full_paid_fees) > 0) {

    $i = 1;

    foreach ($full_paid_fees as $row) {
        $paid_fees_rows .= '<tr class="text-center align-middle">';
        $paid_fees_rows .= '<td><span class="fw-bold text-dark"><i class="fas fa-calendar-days"></i>' . $row["month_year"] . '</span></td>';
        $paid_fees_rows .= '<td>' . $currency_symbol . $row['actual_amount'] . '</td>';
        $paid_fees_rows .= '<td>' . $currency_symbol . $row['discount_amount'] . '</td>';
        $paid_fees_rows .= "<td>" . $currency_symbol . $row['total_paid_amount'] . "</td>";
        $paid_fees_rows .= "<td>" .  date('d M, Y', strtotime($row['updated_at'])) . "</td>";
        $paid_fees_rows .= "</tr>";

        if ($i == 5) {
            break;
        }

        $i++;
    }
} else {
    $paid_fees_rows = "<tr><td colspan='5'>No unpaid fees found.</td></tr>";
}

// ------------------------------------------------------------------------------

// --- মাসের নাম শর্ট (Sort) এবং টেক্সট তৈরি করা ---
if (count($unpaid_months_names) > 0) {
    usort($unpaid_months_names, function ($a, $b) {
        return strtotime("1 " . $a) <=> strtotime("1 " . $b);
    });
}
$months_text = '';
if (count($unpaid_months_names) > 0) {
    if (count($unpaid_months_names) == 1) {
        $months_text = $unpaid_months_names[0];
    } else {
        $months_text = $unpaid_months_names[0] . ' to ' . end($unpaid_months_names);
    }
}

$unpaid_fees_table = '
<div class="mb-2 fw-bold text-danger"><i class="fa-solid fa-file-invoice-dollar"></i> All Unpaid Fees</div>
<div class="table-responsive rounded-3">
    <table class="table table-striped table-hover">
        <thead class="table-danger">
            <tr class="text-center align-middle">
                <th>Month/Year</th>
                <th>Actual Amount</th>
                <th>Offer Amount</th>
                <th>Discount Amount</th>
                <th>Pending Amount</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="studentUnpaidFeesTableBody">
            {{unpaid_fees_rows}}
        </tbody>
    </table>
</div>
';

$paid_fees_table = '
<div class="my-2 fw-bold text-success"><i class="fa-solid fa-file-invoice-dollar"></i> All Paid Fees</div>
<div class="table-responsive rounded-3">
    <table class="table table-light table-striped table-hover">
        <thead class="table-success">
            <tr class="text-center align-middle">
                <th>Month/Year</th>
                <th>Actual Amount</th>
                <th>Discount Amount</th>
                <th>Paid Amount</th>
                <th>Completed At</th>
            </tr>
        </thead>
        <tbody id="studentPaidFeesTableBody">
            {{paid_fees_rows}}
        </tbody>
    </table>
</div>
';

$unpaid_fees_table = str_replace('{{unpaid_fees_rows}}', $unpaid_rows, $unpaid_fees_table);
$paid_fees_table = str_replace('{{paid_fees_rows}}', $paid_fees_rows, $paid_fees_table);
$total_offer_amount = $total_actual_amount - $total_discount_amount;
$unpaid_count = count($unpaid_fees) > 0 ? count($unpaid_fees) : 1;
$average_monthly_fee = $total_offer_amount / $unpaid_count;

echo json_encode([
    'success' => true,
    'message' => 'Success',
    'unpaid_fees_table'   => $unpaid_fees_table,
    'paid_fees_table'     => $paid_fees_table,
    'total_unpaid_amount' => $total_unpaid_amount,
    'unpaid_months_list'  => $unpaid_months_list,
    'unpaid_months_text'  => $months_text,
    'total_actual_amount'   => $total_actual_amount,
    'total_discount_amount' => $total_discount_amount,
    'total_offer_amount'    => $total_offer_amount,
    'average_monthly_fee'   => number_format($average_monthly_fee, 2, '.', '')
]);