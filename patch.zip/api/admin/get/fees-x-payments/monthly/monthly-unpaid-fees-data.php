<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'error' => true
    ]);
    die();
}

$student_ids = $_REQUEST['student_ids'] ?? null;

if (!$student_ids) {
    echo json_encode(['success' => false, 'message' => 'Student IDs are required']);
    exit;
}

$student_ids = explode(',', $student_ids);
$all_month_years = [];

foreach ($student_ids as $student_id) {
    $student_id = trim($student_id);

    // Fetch unpaid fees for the student
    $stmt = $pdo->prepare("SELECT * FROM student_unpaid_fees WHERE student_id = :student_id");
    $stmt->execute(['student_id' => $student_id]);
    $unpaid_fees = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($unpaid_fees) {
        foreach ($unpaid_fees as $unpaid_fee) {
            if ($unpaid_fee['actual_amount'] - $unpaid_fee['discount_amount'] == $unpaid_fee['unpaid_amount']) {
                $all_month_years[] = $unpaid_fee['month_year'];
            }
        }
    } 
}

if (empty($all_month_years)) {
    echo json_encode([
        'success' => false,
        'message' => 'No unpaid fees found for these students',
        'html' => '<div class="alert alert-info">No unpaid fees found for these students.</div>'
    ]);
    exit;
}

$all_month_years = array_unique($all_month_years);
usort($all_month_years, function($a, $b) {
    return strtotime($a) - strtotime($b);
});

echo json_encode([
    'success' => true,
    'message' => 'Unpaid fees fetched successfully',
    'data' => $all_month_years
]);

exit;