<?php
require_once __DIR__ . '/../../../../../includes/auth-check.php';
require_once __DIR__ . '/../../../../../includes/financial/monthly-fee-student-search.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if (!hasPermission(PERM_CAN_SEE_FINANCIAL_REPORT)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Permission denied.', 'results' => []]); exit;
}
try {
    if (!is_string($_GET['q'] ?? '') || !is_string($_GET['month'] ?? date('Y-m'))) throw new InvalidArgumentException('Invalid search parameters.');
    $page = filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT);
    if ($page === false) throw new InvalidArgumentException('Invalid search page.');
    $result = (new MonthlyFeeStudentSearch($pdo))->search($_GET['q'] ?? '', $_GET['month'] ?? date('Y-m'), $page);
    echo json_encode(['success' => true] + $result, JSON_THROW_ON_ERROR);
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $e->getMessage(), 'results' => []]);
}
