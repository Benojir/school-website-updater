<?php

/**
 * Powers the "Quick Add" student search on the monthly Collect Fees page.
 *
 * Two operations, chosen by which parameter arrives:
 *   ?q=<term>          Select2 type-ahead results (id, name, class, roll, image, pending amount)
 *   ?student_id=<id>   The rendered <tr> for that student, ready to append to the table
 *
 * @var PDO    $pdo
 * @var string $currency_symbol
 */

include_once(__DIR__ . "/../../../../../includes/auth-check.php");

header('Content-Type: application/json');

if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.'
    ]);
    exit();
}

$student_id = trim($_REQUEST['student_id'] ?? '');
$search_term = trim($_REQUEST['q'] ?? '');

// ---------------------------------------------------------------------
// MODE 1: Return the table row for one student
// ---------------------------------------------------------------------
if ($student_id !== '') {
    // Rendered through the shared template so a searched row is identical to a
    // row rendered on page load - the page's JS depends on those data-* attributes.
    $row_index = isset($_REQUEST['row_index']) ? (int) $_REQUEST['row_index'] : 0;

    ob_start();
    include(__DIR__ . "/../../../../../includes/financial/monthly-payment-entry-row.php");
    // Trimmed so the client gets a bare <tr> with no leading newline, which would
    // otherwise become a stray text node when jQuery parses it
    $row_html = trim(ob_get_clean());

    if (empty($row_rendered)) {
        echo json_encode([
            'success' => false,
            'message' => 'Student not found.'
        ]);
        exit();
    }

    // Left/alumni students must not be collected from - processSingleStudentPayment()
    // refuses them anyway, so block them here rather than adding a row that cannot save.
    $status = strtolower($student_info['status'] ?? '');

    if ($status === 'left' || $status === 'alumni') {
        echo json_encode([
            'success' => false,
            'message' => 'This student is marked as ' . $student_info['status'] . ', so fees cannot be collected.'
        ]);
        exit();
    }

    echo json_encode([
        'success' => true,
        'message' => 'Row generated successfully.',
        'html' => $row_html,
        'student_id' => $student_id,
        'student_name' => $student_info['name'],
        'total_unpaid_amount' => (float) $row_total_unpaid_amount,
        'is_no_due' => (bool) $row_is_no_due
    ]);
    exit();
}

// ---------------------------------------------------------------------
// MODE 2: Type-ahead search
// ---------------------------------------------------------------------
if ($search_term === '') {
    echo json_encode([
        'success' => true,
        'message' => 'No search term provided.',
        'results' => []
    ]);
    exit();
}

try {
    // Same fields the students list page searches on, minus the address (not useful here).
    // Roll number is added because it is what counter staff usually have to hand.
    $sql = "SELECT s.student_id, s.name, s.roll_no, s.student_image, s.status,
                   c.class_name, sec.section_name,
                   COALESCE((
                       SELECT SUM(suf.unpaid_amount)
                       FROM student_unpaid_fees suf
                       WHERE suf.student_id = s.student_id
                   ), 0) AS total_unpaid_amount
            FROM students s
            LEFT JOIN classes c ON s.class_id = c.id
            LEFT JOIN sections sec ON s.section_id = sec.id
            WHERE LOWER(s.status) NOT IN ('left', 'alumni')
              AND (s.student_id LIKE :search1
                   OR s.name LIKE :search2
                   OR s.father_name LIKE :search3
                   OR s.mother_name LIKE :search4
                   OR s.registration_no LIKE :search5
                   OR s.phone_number LIKE :search6
                   OR s.alternate_phone_number LIKE :search7
                   OR s.roll_no LIKE :search8)
            ORDER BY s.name ASC
            LIMIT 20";

    $stmt = $pdo->prepare($sql);

    $like = "%" . $search_term . "%";
    for ($i = 1; $i <= 8; $i++) {
        $stmt->bindValue(':search' . $i, $like);
    }

    $stmt->execute();
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $results = [];

    foreach ($students as $student) {
        $class_info = trim(($student['class_name'] ?? '') . ' (' . ($student['section_name'] ?? '') . ')');

        $results[] = [
            'student_id' => $student['student_id'],
            'name' => $student['name'],
            'roll_no' => $student['roll_no'],
            'class_info' => $class_info,
            'image_url' => BASE_URL . '/uploads/students/' . $student['student_image'],
            'total_unpaid_amount' => (float) $student['total_unpaid_amount']
        ];
    }

    echo json_encode([
        'success' => true,
        'message' => count($results) . ' student(s) found.',
        'results' => $results
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error searching students: ' . $e->getMessage(),
        'results' => []
    ]);
}
