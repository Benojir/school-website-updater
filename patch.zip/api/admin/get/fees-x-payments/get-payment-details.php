<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

if (!isset($_GET['payment_id'])) {
    echo json_encode(['success' => false, 'message' => 'Payment ID required']);
    exit;
}

$payment_id = sanitize_input($_GET['payment_id']);

// Get payment details
$stmt = $pdo->prepare("
    SELECT 
        ph.*,
        s.name as student_name,
        s.father_name,
        c.class_name,
        sec.section_name,
        DATE_FORMAT(ph.created_at, '%d %b %Y %H:%i') as formatted_date,
        IF(JSON_LENGTH(ph.student_full_paid_fees_ids) > 0, 'full', 'partial') as payment_type
    FROM student_payment_history ph
    LEFT JOIN students s ON ph.student_id = s.student_id
    LEFT JOIN classes c ON s.class_id = c.id
    LEFT JOIN sections sec ON s.section_id = sec.id
    WHERE ph.id = ?
");
$stmt->execute([$payment_id]);
$payment = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$payment) {
    echo json_encode(['success' => false, 'message' => 'Payment not found']);
    exit;
}

// Format amounts
$payment['payment_amount'] = floatval($payment['payment_amount']);
$payment['discount_amount'] = floatval($payment['discount_amount']);

// Get related records
$payment['unpaid_fees'] = [];
$payment['partial_payments'] = [];
$payment['full_payments'] = [];

if (!empty($payment['student_unpaid_fees_rows_backup'])) {
    $payment['unpaid_fees'] = json_decode($payment['student_unpaid_fees_rows_backup'], true);
    foreach ($payment['unpaid_fees'] as &$fee) {
        $fee['unpaid_amount'] = floatval($fee['unpaid_amount']);
        $fee['discount_amount'] = floatval($fee['discount_amount']);
    }
}

if (!empty($payment['student_partial_payments_ids'])) {
    $partial_ids = json_decode($payment['student_partial_payments_ids'], true);
    if (!empty($partial_ids)) {
        $placeholders = implode(',', array_fill(0, count($partial_ids), '?'));
        $stmt = $pdo->prepare("
            SELECT id, unpaid_fees_id, partial_paid_amount, 
                   DATE_FORMAT(created_at, '%d %b %Y') as formatted_date
            FROM student_partial_payments 
            WHERE id IN ($placeholders)
        ");
        $stmt->execute($partial_ids);
        $payment['partial_payments'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($payment['partial_payments'] as &$pp) {
            $pp['partial_paid_amount'] = floatval($pp['partial_paid_amount']);
        }
    }
}

if (!empty($payment['student_full_paid_fees_ids'])) {
    $full_ids = json_decode($payment['student_full_paid_fees_ids'], true);
    if (!empty($full_ids)) {
        $placeholders = implode(',', array_fill(0, count($full_ids), '?'));
        $stmt = $pdo->prepare("
            SELECT id, student_id, month_year, paid_amount, 
                   discount_amount, remark, DATE_FORMAT(created_at, '%d %b %Y') as formatted_date
            FROM student_full_paid_fees 
            WHERE id IN ($placeholders)
        ");
        $stmt->execute($full_ids);
        $payment['full_payments'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($payment['full_payments'] as &$fp) {
            $fp['paid_amount'] = floatval($fp['paid_amount']);
            $fp['discount_amount'] = floatval($fp['discount_amount']);
        }
    }
}

echo json_encode([
    'success' => true,
    'payment' => $payment
]);
?>