<?php
include_once(__DIR__ . "/../../../../../includes/auth-check.php");

header('Content-Type: application/json');

if (!hasPermission(PERM_MANAGE_FEES)) {
    json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$student_id = $_POST['student_id'] ?? null;

if (!$student_id) {
    echo json_encode(array(
        "success" => false,
        "message" => "Missing required parameters."
    ));
    exit();
}

$unpaid_fees = getUnpaidAdmissionFeesData($pdo, $student_id);
$full_paid_fees = getPaidAdmissionFeesData($pdo, $student_id);

$unpaid_rows = '';

if (count($unpaid_fees) > 0) {
    foreach ($unpaid_fees as $row) {
        $unpaid_rows .= '<tr class="text-center align-middle">';
        $unpaid_rows .= '<td><span class="fw-bold text-dark"><i class="fas fa-calendar-days"></i>' . $row["academic_year"] . '</span><br><small class="text-muted" style="font-size: 0.8rem;">(' . $row["class_name"] . ')</small></td>';
        $unpaid_rows .= '<td>' . $currency_symbol . $row['actual_amount'] . '</td>';
        $unpaid_rows .= '<td>' . $currency_symbol . ($row['actual_amount'] - $row['discount_amount']) . '</td>';
        $unpaid_rows .= '<td>' . $currency_symbol . $row['discount_amount'] . '</td>';
        $unpaid_rows .= "<td>" . $currency_symbol . $row['unpaid_amount'] . "</td>";
        $unpaid_rows .= "</tr>";
    }
} else {
    $unpaid_rows = "<tr><td colspan='5'>No unpaid fees found.</td></tr>";
}

$paid_fees_rows = '';

if (count($full_paid_fees) > 0) {

    $i = 1;
    
    foreach ($full_paid_fees as $row) {
        $paid_fees_rows .= '<tr class="text-center align-middle">';
        $paid_fees_rows .= '<td><span class="fw-bold text-dark"><i class="fas fa-calendar-days"></i>' . $row["academic_year"] . '</span><br><small class="text-muted" style="font-size: 0.8rem;">(' . $row["class_name"] . ')</small></td>';
        $paid_fees_rows .= '<td>' . $currency_symbol . $row['actual_amount'] . '</td>';
        $paid_fees_rows .= '<td>' . $currency_symbol . $row['discount_amount'] . '</td>';
        $paid_fees_rows .= "<td>" . $currency_symbol . $row['total_paid_amount'] . "</td>";
        $paid_fees_rows .= "<td>" .  date('d M, Y', strtotime($row['updated_at'])) . "</td>";
        $paid_fees_rows .= "</tr>";

        if ($i == 5) {
            break;
        }

        $i++;
    }
} else {
    $paid_fees_rows = "<tr><td colspan='5'>No unpaid fees found.</td></tr>";
}

// ------------------------------------------------------------------------------

$unpaid_fees_table = '
<div class="mb-2 fw-bold text-danger"><i class="fa-solid fa-file-invoice-dollar"></i> All Unpaid Fees</div>
<div class="table-responsive rounded-3">
    <table class="table table-striped table-hover">
        <thead class="table-danger">
            <tr class="text-center align-middle">
                <th>Pending Session</th>
                <th>Actual Amount</th>
                <th>Offer Amount</th>
                <th>Discount Amount</th>
                <th>Pending Amount</th>
            </tr>
        </thead>
        <tbody id="studentUnpaidFeesTableBody">
            {{unpaid_fees_rows}}
        </tbody>
    </table>
</div>
';

$paid_fees_table = '
<div class="my-2 fw-bold text-success"><i class="fa-solid fa-file-invoice-dollar"></i> All Paid Fees</div>
<div class="table-responsive rounded-3">
    <table class="table table-light table-striped table-hover">
        <thead class="table-success">
            <tr class="text-center align-middle">
                <th>Academic Year</th>
                <th>Actual Amount</th>
                <th>Discount Amount</th>
                <th>Paid Amount</th>
                <th>Completed At</th>
            </tr>
        </thead>
        <tbody id="studentPaidFeesTableBody">
            {{paid_fees_rows}}
        </tbody>
    </table>
</div>
';

$unpaid_fees_table = str_replace('{{unpaid_fees_rows}}', $unpaid_rows, $unpaid_fees_table);
$paid_fees_table = str_replace('{{paid_fees_rows}}', $paid_fees_rows, $paid_fees_table);

echo json_encode([
    'success' => true,
    'message' => 'Success',
    'unpaid_fees_table' => $unpaid_fees_table,
    'paid_fees_table' => $paid_fees_table,
]);
