<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'error' => true
    ]);
    die();
}

if (!isset($_GET['student_id'])) {
    echo json_encode(['success' => false, 'message' => 'Student ID is required']);
    exit;
}

$student_id = $_GET['student_id'];

// Fetch unpaid fees for the student
$stmt = $pdo->prepare("SELECT * FROM admission_unpaid_fees WHERE student_id = :student_id");
$stmt->execute(['student_id' => $student_id]);
$unpaid_fees = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$unpaid_fees || count($unpaid_fees) == 0) {
    echo json_encode([
        'success' => false, 
        'message' => 'No unpaid admission fees found for this student',
        'html' => '<div class="alert alert-info">No unpaid admission fees found for this student.</div>'
    ]);
    exit;
}

$html = '';

foreach ($unpaid_fees as $fee) {
    $actual_amount = $fee['actual_amount'];
    $discount = $fee['discount_amount'];
    $unpaid_amount = $fee['unpaid_amount'];

    if ($unpaid_amount == ($actual_amount - $discount)) {
        $html .= '<div class="alert alert-info d-flex justify-content-between align-items-center">
            <p class="mb-0">Academic Year: (<b>' . $fee['academic_year'] . '</b>)<br> Total Amount: <b>' . $actual_amount . '/-</b><br>Pending Amount: <b>' . $unpaid_amount . '/-</b></p>
            <button onclick="deleteUnpaidFeeEntry(' . $fee['id'] . ', this, \'admission\')" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i> Delete</button>
        </div>';
    } else {
        $html .= '<div class="alert alert-warning d-flex justify-content-between align-items-center">
            <p class="mb-0">Academic Year: (<b>' . $fee['academic_year'] . '</b>)<br> Total Amount: <b>' . $actual_amount . '/-</b><br>Pending Amount: <b>' . $unpaid_amount . '/-</b> (Partially Paid)</p>
            <button class="btn btn-sm btn-light" disabled>Cannot Delete</button>
        </div>';
    }
}

echo json_encode([
    'success' => true,
    'message' => 'Unpaid admission fees fetched successfully',
    'html' => $html
]);