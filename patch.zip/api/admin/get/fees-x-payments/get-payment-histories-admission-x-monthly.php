<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check permission
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit;
}

// --- Input Sanitization & Defaults ---
$payment_type = (isset($_GET['paymentType']) ? sanitize_input($_GET['paymentType']) : '');
$page = filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT, ['options' => ['default' => 1, 'min_range' => 1]]);
$search_query = (isset($_GET['search']) ? sanitize_input($_GET['search']) : '');
$start_date = (isset($_GET['startDate']) ? sanitize_input($_GET['startDate']) : '');
$end_date = (isset($_GET['endDate']) ? sanitize_input($_GET['endDate']) : '');
$per_page = 20;
$offset = ($page - 1) * $per_page;

if ($payment_type !== 'admission' && $payment_type !== 'monthly') {
    echo json_encode(['success' => false, 'message' => 'Invalid fees type provided.']);
    exit;
}

$table_name = "student_payment_history";

if($payment_type == 'admission') {
    $table_name = "admission_fees_payment_history";
}


// --- Build Dynamic WHERE clause ---
$where_clauses = [];
$params = [];

if (!empty($search_query)) {
    $where_clauses[] = "s.name LIKE ?";
    $params[] = "%" . $search_query . "%";
}
if (!empty($start_date)) {
    $where_clauses[] = "ph.payment_date >= ?";
    $params[] = $start_date;
}
if (!empty($end_date)) {
    $where_clauses[] = "ph.payment_date <= ?";
    $params[] = $end_date;
}

$where_sql = count($where_clauses) > 0 ? 'WHERE ' . implode(' AND ', $where_clauses) : '';

try {
    // --- Get Total Count for Pagination ---
    $count_sql = "SELECT COUNT(ph.id) 
                  FROM {$table_name} ph
                  LEFT JOIN students s ON ph.student_id = s.student_id
                  $where_sql";
    $stmt_count = $pdo->prepare($count_sql);
    $stmt_count->execute($params);
    $total_payments = $stmt_count->fetchColumn();
    $total_pages = ceil($total_payments / $per_page);

    // --- Get Paginated Payment Data ---
    $data_sql = "SELECT ph.*, s.name AS student_name, s.father_name, s.class_id, s.section_id, 
                        c.class_name, sec.section_name 
                 FROM {$table_name} ph
                 LEFT JOIN students s ON ph.student_id = s.student_id
                 LEFT JOIN classes c ON c.id = s.class_id
                 LEFT JOIN sections sec ON sec.id = s.section_id
                 $where_sql
                 ORDER BY ph.id DESC
                 LIMIT ? OFFSET ?";
    
    $data_params = array_merge($params, [$per_page, $offset]);
    
    $stmt_data = $pdo->prepare($data_sql);
    // Manually bind LIMIT and OFFSET as integers
    $param_count = count($params);
    for ($i = 0; $i < $param_count; $i++) {
        $stmt_data->bindValue($i + 1, $params[$i]);
    }
    $stmt_data->bindValue($param_count + 1, $per_page, PDO::PARAM_INT);
    $stmt_data->bindValue($param_count + 2, $offset, PDO::PARAM_INT);
    $stmt_data->execute();
    $payments = $stmt_data->fetchAll(PDO::FETCH_ASSOC);

    // --- Get Summary Data (Total Amount, Unique Students) ---
    $summary_sql = "SELECT 
                        SUM(ph.payment_amount) as total_amount, 
                        COUNT(DISTINCT ph.student_id) as total_students
                    FROM {$table_name} ph
                    LEFT JOIN students s ON ph.student_id = s.student_id
                    $where_sql";
    $stmt_summary = $pdo->prepare($summary_sql);
    $stmt_summary->execute($params);
    $summary = $stmt_summary->fetch(PDO::FETCH_ASSOC);


    // --- Send Response ---
    echo json_encode([
        'success'       => true,
        'payments'      => $payments,
        'pagination'    => [
            'currentPage' => $page,
            'totalPages'  => $total_pages,
            'totalRecords' => $total_payments
        ],
        'summary'       => [
            'totalAmount'   => $summary['total_amount'] ?? 0,
            'totalStudents' => $summary['total_students'] ?? 0
        ]
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>