<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;

$response = [
    'amounts' => [],
    'total' => 0
];

try {
    // Base query

    $sql = "SELECT cwf.id, cwf.class_id, cwf.amount, c.class_name 
            FROM class_wise_monthly_fees cwf 
            JOIN classes c ON cwf.class_id = c.id 
            WHERE 1=1";
    
    $params = [];
    
    // Add search condition
    if (!empty($search)) {
        $sql .= " AND (cwf.amount LIKE ? OR c.class_name LIKE ?)";
        $searchParam = "%$search%";
        $params[] = $searchParam;
        $params[] = $searchParam;
    }
    
    // Add class filter
    if ($class_id > 0) {
        $sql .= " AND cwf.class_id = ?";
        $params[] = $class_id;
    }
    
    // Prepare and execute query
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $response['amounts'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total count
    $totalStmt = $pdo->query("SELECT FOUND_ROWS()");
    $response['total'] = $totalStmt->fetchColumn();
} catch (PDOException $e) {
    http_response_code(500);
    $response['error'] = 'Database error: ' . $e->getMessage();
}

echo json_encode($response);