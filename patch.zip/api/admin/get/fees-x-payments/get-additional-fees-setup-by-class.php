<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

$class_id = isset($_REQUEST['class_id']) ? (int)$_REQUEST['class_id'] : 0;

$response = [
    'success' => false,
    'total' => 0
];

if ($class_id == 0) {
    $response['message'] = 'Class ID is required';
    echo json_encode($response);
    exit;
}

$table_name = "class_wise_additional_fees";

try {
    // Base query

    $sql = "SELECT cwaf.id, cwaf.class_id, cwaf.amount, cwaf.fee_type, c.class_name 
            FROM `{$table_name}` cwaf 
            JOIN classes c ON cwaf.class_id = c.id 
            WHERE 1=1";
    
    $params = [];
    
    
    // Add class filter
    if ($class_id > 0) {
        $sql .= " AND cwaf.class_id = ?";
        $params[] = $class_id;
    }
    
    // Prepare and execute query
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $response['amounts'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total count
    $totalStmt = $pdo->query("SELECT FOUND_ROWS()");
    $response['total'] = $totalStmt->fetchColumn();

    if ($response['total'] > 0) {
        $response['success'] = true;
    } else {
        $response['message'] = 'No additional fees found for the class';
    }

} catch (PDOException $e) {
    http_response_code(500);
    $response['message'] = 'Database error: ' . $e->getMessage();
}

echo json_encode($response);