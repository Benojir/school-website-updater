<?php
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

$student_id = $_REQUEST['student_id'] ?? null;

if (empty($student_id)) {
    echo json_encode([
        'success' => false,
        'message' => 'Student ID is required'
    ]);
    exit;
}

// FIX: The WHERE clause was moved to the end of the query, after all the JOINs.
// I also added the table prefix to student_id for clarity.
$sql = "SELECT
            afd.additional_fee_status,
            afd.additional_fee_due_date,
            afd.additional_fee_paid_date,
            afd.additional_fee_setup_id,
            cwaf.amount,
            cwaf.fee_type,
            c.class_name
        FROM
            additional_fees_data AS afd
        LEFT JOIN
            classes AS c ON c.id = afd.class_id
        LEFT JOIN
            class_wise_additional_fees AS cwaf ON cwaf.id = afd.additional_fee_setup_id
        WHERE
            afd.student_id = ?
        LIMIT 20;";

$stmt = $pdo->prepare($sql);
$stmt->execute([$student_id]);

$additional_fees_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($additional_fees_data) <= 0) {
    echo json_encode([
        'success' => false,
        'message' => 'No additional fees data found for the student'
    ]);
    exit;
}

echo json_encode([
    'success' => true,
    'message' => 'Additional fees data retrieved successfully',
    'data' => $additional_fees_data
]);