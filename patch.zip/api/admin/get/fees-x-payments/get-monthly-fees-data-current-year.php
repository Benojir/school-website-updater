<?php
// Include required files
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/permission-check.php");

header('Content-Type: application/json');

try {
    $current_year = date('Y');
    
    // Get paid fees by month for current year
    $paid_query = "SELECT 
                    MONTH(STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y')) as month, 
                    SUM(total_paid_amount) as paid 
                  FROM student_full_paid_fees 
                  WHERE YEAR(STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y')) = ?
                  GROUP BY MONTH(STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y'))";
    $stmt = $pdo->prepare($paid_query);
    $stmt->execute([$current_year]);
    $paid_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get pending fees by month for current year
    $pending_query = "SELECT 
                       MONTH(STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y')) as month,
                       SUM(unpaid_amount) as pending
                     FROM student_unpaid_fees 
                     WHERE YEAR(STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y')) = ?
                     GROUP BY MONTH(STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y'))";
    $stmt = $pdo->prepare($pending_query);
    $stmt->execute([$current_year]);
    $pending_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Combine the data
    $result = [];
    
    // Process paid data
    foreach ($paid_data as $row) {
        $month = $row['month'];
        if (!isset($result[$month])) {
            $result[$month] = ['month' => $month, 'paid' => 0, 'pending' => 0];
        }
        $result[$month]['paid'] = $row['paid'];
    }
    
    // Process pending data
    foreach ($pending_data as $row) {
        $month = $row['month'];
        if (!isset($result[$month])) {
            $result[$month] = ['month' => $month, 'paid' => 0, 'pending' => 0];
        }
        $result[$month]['pending'] = $row['pending'];
    }
    
    // Convert to indexed array
    $final_result = array_values($result);
    
    echo json_encode($final_result);
    
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>