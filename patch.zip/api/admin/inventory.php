<?php
require_once __DIR__ . '/../../includes/auth-check.php';
require_once __DIR__ . '/../../includes/inventory/inventory-service.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$admin = authenticateAdminApiRequest($pdo);
if (!hasPermission(PERM_MANAGE_INVENTORY)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'You do not have permission to manage inventory.']);
    exit;
}
$canReport = hasPermission(PERM_CAN_SEE_FINANCIAL_REPORT);
$service = new InventoryService($pdo, (int)$admin['user_id']);
try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 131072) throw new InvalidArgumentException('This entry is too large.');
        $input = json_decode(file_get_contents('php://input'), true, 64, JSON_THROW_ON_ERROR);
        if (!is_array($input)) throw new InvalidArgumentException('Invalid request.');
        if (!is_string($input['csrf'] ?? null) || empty($_SESSION['inventory_csrf']) || !hash_equals($_SESSION['inventory_csrf'], $input['csrf'])) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'Your form expired. Refresh this page before saving.']);
            exit;
        }
        $action = (string)($input['action'] ?? '');
        unset($input['csrf'], $input['action']);
        // Release the PHP session lock; stock integrity is enforced by DB row locks.
        session_write_close();
        $data = $service->mutate($action, $input);
    } elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $action = $_GET['action'] ?? 'products';
        if ($action === 'report' && !$canReport) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'Financial-report permission is required to view profit and loss.']);
            exit;
        }
        $data = match ($action) {
            'products' => $service->products($_GET),
            'students' => $service->students((string)($_GET['search'] ?? '')),
            'documents' => $service->documents($_GET),
            'detail' => $service->detail(inventoryInteger($_GET['id'] ?? 0, 'Entry', 1, PHP_INT_MAX)),
            'movements' => $service->movements($_GET),
            'report' => $service->report($_GET),
            default => throw new InvalidArgumentException('Unknown inventory view.')
        };
        if (!$canReport) {
            // Transaction prices stay available for daily work; valuations and profit do not.
            $redact = function (array $row): array { unset($row['cost_paise'], $row['stock_value_paise'], $row['line_cost_paise']); return $row; };
            $data = $redact($data);
            if (isset($data['rows'])) $data['rows'] = array_map($redact, $data['rows']);
            if (isset($data['items'])) $data['items'] = array_map($redact, $data['items']);
        }
    } else {
        http_response_code(405);
        header('Allow: GET, POST');
        echo json_encode(['success' => false, 'message' => 'Use GET or POST.']);
        exit;
    }
    echo json_encode(['success' => true, 'data' => $data], JSON_THROW_ON_ERROR);
} catch (InvalidArgumentException | JsonException $e) {
    http_response_code(422);
    echo json_encode(['success' => false, 'message' => $e instanceof JsonException ? 'Invalid form data. Please refresh and try again.' : $e->getMessage()]);
} catch (PDOException $e) {
    $missing = $e->getCode() === '42S02';
    http_response_code($missing ? 503 : 500);
    error_log('Inventory: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => $missing ? 'Inventory is not ready yet. Ask the school owner to finish setup.' : 'The entry could not be completed. Please retry; the same request will not be saved twice.']);
} catch (Throwable $e) {
    http_response_code(500);
    error_log('Inventory: ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Something went wrong. Please retry or refresh the page.']);
}
