<?php
ini_set('memory_limit', '512M'); // or '1G' for very large files
include_once(__DIR__ . "/../../includes/auth-check.php");

$main_html_path = __DIR__ . "/../../assets/templates/student-transfer-certificates/design1/main.html";
$content_html_path = __DIR__ . "/../../assets/templates/student-transfer-certificates/design1/content.html";

$student_data_json = $_REQUEST['student_data'] ?? '';
$student_data = json_decode($student_data_json, true);

$main_html = file_get_contents($main_html_path);
$content_html = file_get_contents($content_html_path);
$school_logo = BASE_URL . '/uploads/school/logo-square.png';
$principal_sign_link = BASE_URL . '/uploads/school/principle_sign.png';
$student_image_link = BASE_URL . '/uploads/students/';

$certificates_html = '';

foreach ($student_data as $data) {
    $student_id = $data['student_id'];
    $last_class = getClassNameById($pdo, $data['last_class']);
    $promoted_class = $data['promoted_class'];
    $reason_for_leaving = $data['reason_for_leaving'];
    $date = $data['date'];

    $student = getStudentInfo($pdo, $student_id);

    if (empty($student)) {
        continue;
    }

    // Replace placeholders
    $placeholders = [
        '{{school_logo}}' => $school_logo,
        '{{school_name}}' => $school_name,
        '{{estd}}' => $schoolInfo['established_year'],
        '{{school_phone}}' => '+' . $websiteConfig['country_code'] . ' ' . $schoolInfo['phone'],
        '{{school_address}}' => $schoolInfo['address'],
        '{{student_name}}' => $student['name'],
        '{{student_image}}' => $student_image_link . $student['student_image'],
        '{{father_name}}' => $student['father_name'],
        '{{student_address}}' => $student['address'],
        '{{date_of_birth}}' => date('d-m-Y', strtotime($student['date_of_birth'])),
        '{{registration_no}}' => $student['registration_no'],
        '{{last_class_passed}}' => $last_class,
        '{{promoted_class}}' => $promoted_class,
        '{{reason_for_leaving}}' => $reason_for_leaving,
        '{{date}}' => date('d-m-Y', strtotime($date)),
        '{{principal_sign}}' => $principal_sign_link
    ];
    $final_content = str_replace(array_keys($placeholders), array_values($placeholders), $content_html);

    $certificates_html .= $final_content;
}

$main_html = str_replace('{{contents}}', $certificates_html, $main_html);
echo $main_html;