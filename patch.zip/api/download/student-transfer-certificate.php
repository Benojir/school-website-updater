<?php
ini_set('memory_limit', '512M'); // or '1G' for very large files
include_once(__DIR__ . "/../../includes/auth-check.php");

$main_html_path = __DIR__ . "/../../assets/templates/student-transfer-certificates/design1/main.html";
$content_html_path = __DIR__ . "/../../assets/templates/student-transfer-certificates/design1/content.html";

$student_ids_string = $_REQUEST['student_ids'] ?? '';
$student_ids = !empty($student_ids_string) ? array_map('trim', explode(',', $student_ids_string)) : [];
$promoted_class = $_REQUEST['promoted_class'] ?? '';
$date = $_REQUEST['date'] ?? '';
$reason_for_leaving = $_REQUEST['reason_for_leaving'] ?? '';

// Validate inputs
if (empty($student_ids) || empty($promoted_class) || empty($date) || empty($reason_for_leaving)) {
    echo "<center><h1>Invalid request</h1></center>";
    exit;
}

$main_html = file_get_contents($main_html_path);
$content_html = file_get_contents($content_html_path);
$principal_sign_link = BASE_URL . '/uploads/school/principle_sign.png';
$student_image_link = BASE_URL . '/uploads/students/';

$certificates_html = '';

foreach ($student_ids as $student_id) {

    $student = getStudentInfo($pdo, $student_id);

    // Replace placeholders
    $placeholders = [
        '{{school_name}}' => $school_name,
        '{{estd}}' => $schoolInfo['established_year'],
        '{{school_phone}}' => '+' . $websiteConfig['country_code'] . ' ' . $schoolInfo['phone'],
        '{{school_address}}' => $schoolInfo['address'],
        '{{student_name}}' => $student['name'],
        '{{student_image}}' => $student_image_link . $student['student_image'],
        '{{father_name}}' => $student['father_name'],
        '{{student_address}}' => $student['address'],
        '{{date_of_birth}}' => date('d-m-Y', strtotime($student['date_of_birth'])),
        '{{registration_no}}' => $student['registration_no'],
        '{{last_class_passed}}' => $student['class_name'],
        '{{promoted_class}}' => $promoted_class,
        '{{reason_for_leaving}}' => $reason_for_leaving,
        '{{date}}' => date('d-m-Y', strtotime($date)),
        '{{principal_sign}}' => $principal_sign_link
    ];
    $final_content = str_replace(array_keys($placeholders), array_values($placeholders), $content_html);

    $certificates_html .= $final_content;
}

$main_html = str_replace('{{contents}}', $certificates_html, $main_html);
echo $main_html;