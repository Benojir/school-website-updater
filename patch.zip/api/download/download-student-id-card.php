<?php
/** @var PDO $pdo */
include_once("../../includes/auth-check.php");
include_once("../../../vendor/autoload.php");

use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;

// Check if student IDs are provided
$student_ids = $_REQUEST['student_ids'] ?? "";
$student_ids = json_decode($student_ids, true);

if (!is_array($student_ids) || empty($student_ids)) {
    die("Invalid student IDs");
}

$stmt = $pdo->query("SELECT * FROM student_id_card_settings LIMIT 1");
$card_settings = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$card_settings) {
    die("ID Card settings not found");
}

$template_name = $card_settings['template'];
$school_address = $card_settings['school_address'];
$school_contacts = $card_settings['school_contacts'];
$colors = json_decode($card_settings['colors'], true);

// Prepare placeholders based on array count
$placeholders = str_repeat('?,', count($student_ids) - 1) . '?';

$sql = "SELECT s.*, c.class_name, sec.section_name 
        FROM students s
        LEFT JOIN classes c ON s.class_id = c.id
        LEFT JOIN sections sec ON s.section_id = sec.id
        WHERE s.student_id IN ($placeholders)";

// Prepare statement
$stmt = $pdo->prepare($sql);
$stmt->execute($student_ids);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$results) {
    die("No results found");
}

// HTML parts
$header_html = file_get_contents('../../assets/templates/student-id-cards/header.html');
$footer_html = file_get_contents('../../assets/templates/student-id-cards/footer.html');
$cards_container_html = file_get_contents('../../assets/templates/student-id-cards/id-cards-container.html');
$id_card_html = file_get_contents('../../assets/templates/student-id-cards/' . $template_name . '/id-card.html');
$css_codes = file_get_contents('../../assets/templates/student-id-cards/' . $template_name . '/styles.css');

$school_logo_url = BASE_URL . '/uploads/school/logo-square.png';
$id_card_background_url = BASE_URL . '/uploads/school/student-id-cards-bg/' . $template_name . '.jpg';
$student_photo_url = BASE_URL . '/uploads/students/';

// Style replacements
$css_codes = str_replace('{{background_image_url}}', $id_card_background_url, $css_codes);
$css_codes = str_replace('{{school_name_color}}', $colors['school_name'], $css_codes);
$css_codes = str_replace('{{school_address_color}}', $colors['school_address'], $css_codes);
$css_codes = str_replace('{{school_contact_color}}', $colors['school_contacts'], $css_codes);
$css_codes = str_replace('{{student_name_color}}', $colors['student_name'], $css_codes);
$css_codes = str_replace('{{student_details_label_color}}', $colors['details_title'], $css_codes);
$css_codes = str_replace('{{student_details_value_color}}', $colors['details_data'], $css_codes);
$css_codes = str_replace('{{student_address_title_color}}', $colors['student_address_title'], $css_codes);
$css_codes = str_replace('{{student_address_color}}', $colors['student_address_data'], $css_codes);

// Replace universal placeholders
$header_html = str_replace('{{css_codes}}', $css_codes, $header_html);
$id_card_html = str_replace('{{school_name}}', $school_name, $id_card_html);
$id_card_html = str_replace('{{school_address}}', $school_address, $id_card_html);
$id_card_html = str_replace('{{school_contacts}}', safe_htmlspecialchars($school_contacts), $id_card_html);
$id_card_html = str_replace('{{school_logo}}', $school_logo_url, $id_card_html);

// Build HTML content
$all_pages_html = '';

$results = array_chunk($results, 9); // 9 ID cards per page

foreach ($results as $results_chunk) {
    $page_html = '';
    $cards_html = '';

    foreach ($results_chunk as $student) {
        $current_card_html = $id_card_html;

        $qr_code_data = json_encode([
            'student_id' => $student['student_id'],
            'name' => $student['name'],
            'class' => $student['class_name'],
            'section' => $student['section_name'],
            'school_name' => $school_name,
            'student_contact' => "+" . $websiteConfig['country_code'] . " " . $student['phone_number'],
            'student_image' => $student_photo_url . $student['student_image']
        ]);

        $qr_code = new QrCode($qr_code_data);
        $writer = new PngWriter();
        $qr_code_base64 = $writer->write($qr_code)->getDataUri();

        // Replace placeholders
        $current_card_html = str_replace('{{student_image}}', $student_photo_url . $student['student_image'], $current_card_html);
        $current_card_html = str_replace('{{qr_code}}', $qr_code_base64, $current_card_html);
        $current_card_html = str_replace('{{student_name}}', $student['name'], $current_card_html);
        $current_card_html = str_replace('{{roll_no}}', safe_htmlspecialchars($student['roll_no']), $current_card_html);
        $current_card_html = str_replace('{{class}}', $student['class_name'] . ' (' . $student['section_name'] . ')', $current_card_html);
        $current_card_html = str_replace('{{dob}}', date('d M, Y', strtotime($student['date_of_birth'])), $current_card_html);
        $current_card_html = str_replace('{{student_id}}', $student['student_id'], $current_card_html);
        $current_card_html = str_replace('{{father_name}}', $student['father_name'], $current_card_html);
        $current_card_html = str_replace('{{student_contact}}', "+" . $websiteConfig['country_code'] . " " . $student['phone_number'], $current_card_html);
        $current_card_html = str_replace('{{student_address}}', safe_htmlspecialchars($student['address']), $current_card_html);

        $cards_html .= $current_card_html;
    }

    $page_html .= str_replace('{{id_cards}}', $cards_html, $cards_container_html);
    $all_pages_html .= $page_html;
}

$final_html = $header_html . $all_pages_html . $footer_html;

echo $final_html;