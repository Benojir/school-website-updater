<?php
require_once(__DIR__ . '/../../includes/auth-check.php');
require_once(__DIR__ . '/../../includes/driver/driver-id-card-data.php');
if (!hasPermission(PERM_MANAGE_ID_CARDS) || !hasPermission(PERM_MANAGE_TRANSPORT)) {
    http_response_code(403); exit('Permission denied');
}
try { $driver_ids = driverIdCardSelectedIds($_POST + $_GET); }
catch (InvalidArgumentException $e) { http_response_code(400); exit(htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8')); }
$template = null;
$migration_required = false;
try {
    $template = $pdo->query('SELECT template_name, has_back, back_design_json FROM driver_id_card_templates WHERE is_active = 1 ORDER BY id LIMIT 1')->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) { $migration_required = true; }
$has_back = $template && !empty($template['has_back']) && !empty($template['back_design_json']);
include_once(__DIR__ . '/../../includes/header-open.php');
?>
<title>Print Driver ID Cards</title>
<?php include_once(__DIR__ . '/../../includes/header-close.php'); ?>
<div class="container py-5" style="max-width:720px">
    <div class="card shadow-sm">
        <div class="card-body p-4">
            <h3><i class="fas fa-id-card me-2"></i>Driver ID Cards</h3>
            <p><?= count($driver_ids) ?> driver(s) selected.</p>
            <?php if ($migration_required): ?>
                <div class="alert alert-warning">The driver template library is not available. Review and manually apply the Driver ID Card block in migrate.sql first.</div>
            <?php elseif (!$template): ?>
                <div class="alert alert-info">Create and save a named template in the Driver ID Card Builder first.</div>
            <?php else: ?>
                <p>Printing template: <strong><?= htmlspecialchars($template['template_name'], ENT_QUOTES, 'UTF-8') ?></strong></p>
                <form action="generate-driver-id-cards.php" method="post" target="_blank">
                    <input type="hidden" name="driver_ids" value="<?= htmlspecialchars(json_encode($driver_ids), ENT_QUOTES, 'UTF-8') ?>">
                    <?php if ($has_back): ?>
                        <label class="form-label" for="duplexLayout">Front &amp; back arrangement</label>
                        <select id="duplexLayout" name="duplex_layout" class="form-select mb-3">
                            <option value="sequential">Separate front/back sheets — duplex, flip on long edge</option>
                            <option value="side-by-side">Front &amp; back side by side — cut and laminate</option>
                        </select>
                    <?php endif; ?>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-print me-1"></i>Generate &amp; Print</button>
                </form>
            <?php endif; ?>
            <div class="d-flex flex-wrap gap-2 mt-3">
                <?php if (!$migration_required): ?>
                <a href="../../management/settings/driver-id-card-builder.php" class="btn btn-outline-primary">Driver ID Card Builder</a>
                <?php endif; ?>
                <a href="../../management/driver/list-drivers.php" class="btn btn-outline-secondary">Back to drivers</a>
            </div>
        </div>
    </div>
</div>
<?php include_once(__DIR__ . '/../../includes/body-close.php'); ?>
