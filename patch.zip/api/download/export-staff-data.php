<?php
require_once __DIR__ . '/../../includes/auth-check.php';
require_once __DIR__ . '/../../includes/exports/staff-data-export.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Please use the export form on the teacher or driver list.');
}
$type = $_POST['staff_type'] ?? '';
$permission = match ($type) {
    'teacher' => PERM_MANAGE_TEACHERS,
    'driver' => PERM_MANAGE_TRANSPORT,
    default => null
};
if ($permission === null || !hasPermission($permission)) {
    http_response_code(403);
    exit('You do not have permission to export this data.');
}
try {
    $config = staffExportConfig($type, hasPermission(PERM_CAN_SEE_FINANCIAL_REPORT));
    [$ids, $columns] = staffExportRequest($_POST, $config);
    $rows = staffExportRows($pdo, $config, $ids, $columns);
    if (!$rows) throw new InvalidArgumentException('No data found for the selected people. Please refresh the list and select again.');
    require_once __DIR__ . '/../../../vendor/autoload.php';
    $book = staffExportWorkbook($config, $columns, $rows);
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $type . 's_export_' . date('Y-m-d_H-i') . '.xlsx"');
    header('Cache-Control: private, no-store');
    (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($book))->save('php://output');
    $book->disconnectWorksheets();
} catch (InvalidArgumentException $e) {
    http_response_code(400);
    header('Content-Type: text/plain; charset=utf-8');
    echo $e->getMessage();
} catch (Throwable $e) {
    error_log('Staff data export: ' . $e->getMessage());
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Unable to export data. Please try again.';
}
