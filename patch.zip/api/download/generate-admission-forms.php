<?php
define('ID_CARD_AUDIENCE', 'admission');
require __DIR__ . '/generate-student-id-cards.php';
