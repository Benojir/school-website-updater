<?php
ini_set('memory_limit', '512M'); // or '1G' for very large files
include_once(__DIR__ . "/../../includes/auth-check.php");

$main_html_path = __DIR__ . "/../../assets/templates/student-transport-id-cards/design1/main.html";
$content_html_path = __DIR__ . "/../../assets/templates/student-transport-id-cards/design1/content.html";
$card_bg_img = BASE_URL . '/uploads/school/student-transport-id-cards-bg/design-1.jpg';

$student_ids_string = $_REQUEST['student_ids'] ?? '';
$student_ids = explode(',', $student_ids_string);

if (empty($student_ids_string) || count($student_ids) == 0) {
    echo "<div class='container mt-4'><div class='alert alert-danger'>No student IDs provided.</div></div>";
    include_once(__DIR__ . "/../../includes/body-close.php");
    exit();
}

$main_html = file_get_contents($main_html_path);
$main_html = str_replace('{{card_background_image}}', $card_bg_img, $main_html);
$content_html = file_get_contents($content_html_path);

$driver_image_link = BASE_URL . '/uploads/drivers/';

$cards_html = '';

$skip_count = 0;

foreach ($student_ids as $student_id) {
   
    $stmt = $pdo->prepare("
        SELECT 
            s.name AS student_name,
            s.driver_id,
            d.name AS driver_name,
            d.driver_image,
            d.serial_number
        FROM students s
        JOIN drivers d ON s.driver_id = d.id
        WHERE s.student_id = :student_id
    ");
    $stmt->bindParam(':student_id', $student_id);
    $stmt->execute();
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (empty($student)) {
        $skip_count++;
        continue;
    }

    $student_name_parts = explode(' ', $student['student_name']);
    $student_first_name = $student_name_parts[0];
    $student_last_name = implode(' ', array_slice($student_name_parts, 1));

    $driver_name_parts = explode(' ', $student['driver_name']);
    $driver_first_name = $driver_name_parts[0];
    $driver_last_name = implode(' ', array_slice($driver_name_parts, 1));

    // Replace placeholders
    $placeholders = [
        '{{school_name}}' => $school_name,
        '{{student_name}}' => $student_first_name . ' ' . $student_last_name,
        '{{serial_number}}' => $student['serial_number'],
        '{{driver_image}}' => $driver_image_link . $student['driver_image'],
        '{{driver_name}}' => $driver_first_name . ' ' . $driver_last_name
    ];

    $final_content = str_replace(array_keys($placeholders), array_values($placeholders), $content_html);

    $cards_html .= $final_content;
}

$main_html = str_replace('{{cards}}', $cards_html, $main_html);

if ($skip_count > 0) {
    $main_html = str_replace('{{error_message}}', "Total students: " . count($student_ids) . ", Skipped: " . $skip_count, $main_html);
} else {
    $main_html = str_replace('{{error_message}}', '', $main_html);
}

echo $main_html;