<?php
// Check if user is logged in
include_once("../../includes/config.php"); // auth checking + config.php included
include_once("../../includes/permission-check.php");
require_once('../../vendor/autoload.php');

// Check if student IDs are provided
if (!isset($_GET['student_ids']) || empty($_GET['student_ids'])) {
    die("Student IDs are required (comma-separated)");
}

$student_ids = explode(',', $_GET['student_ids']);

// Permission check for download both admin and parent
if (count($student_ids) == 1) {
    $sid = $student_ids[0];
    // check admin permission + student permission
    if (isLoggedIn()) { // check if any admin logged in
        if (!hasPermission(PERM_MANAGE_STUDENTS)) {
            echo json_encode([
                'success' => false,
                'message' => 'You do not have permission to download id cards.'
            ]);
            exit;
        }
    } else {
        if (isParentAuthenticated()) {
            if (!hasParentAccessPermission($sid)) {
                echo json_encode([
                    'success' => false,
                    'message' => 'You do not have permission to access this content.'
                ]);
                exit;
            }
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Authentication required.'
            ]);
            exit;
        }
    }
} else {
    // Check if user has permission to download id cards
    if (!hasPermission(PERM_MANAGE_STUDENTS)) {
        echo json_encode([
            'success' => false,
            'message' => 'You do not have permission to download id cards.'
        ]);
        die();
    }
}

// Create new PDF document with PORTRAIT orientation ('P')
$pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);

// Document information
$pdf->SetCreator($schoolInfo['name']);
$pdf->SetAuthor($schoolInfo['name']);
$pdf->SetTitle('Bulk ID Cards');
$pdf->SetSubject('Student ID Cards');

// Disable header/footer
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

$pdf->SetAutoPageBreak(true, 5);

// Pre-load custom fonts
$funky_bird = TCPDF_FONTS::addTTFfont('../../assets/fonts/FunkyBird.ttf', 'TrueTypeUnicode', '', 96);
$heavitas = TCPDF_FONTS::addTTFfont('../../assets/fonts/Heavitas.ttf', 'TrueTypeUnicode', '', 96);
$one_slice = TCPDF_FONTS::addTTFfont('../../assets/fonts/OneSlice.otf', 'TrueTypeUnicode', '', 96);

// ID card dimensions
$id_width = 54;  // mm
$id_height = 86; // mm

// Calculate positions for ID cards (3x3 grid)
$positions = [];
$horizontal_spacing = 10;
$vertical_spacing = 10;

for ($row = 0; $row < 3; $row++) {
    for ($col = 0; $col < 3; $col++) {
        $x = 10 + ($col * ($id_width + $horizontal_spacing));
        $y = 10 + ($row * ($id_height + $vertical_spacing));
        $positions[] = [$x, $y];
    }
}

$current_position = 0;

foreach ($student_ids as $student_id) {
    if ($current_position === 0) {
        $pdf->AddPage('P');
    }

    // Fetch student details
    $stmt = $pdo->prepare("
        SELECT s.*, c.class_name, sec.section_name 
        FROM students s
        LEFT JOIN classes c ON s.class_id = c.id
        LEFT JOIN sections sec ON s.section_id = sec.id
        WHERE s.student_id = ?
    ");
    $stmt->execute([trim($student_id)]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        continue;
    }

    // Get current position coordinates
    $x = $positions[$current_position][0];
    $y = $positions[$current_position][1];

    // --- Start of a single ID Card ---

    // Set background image
    $bg_path = '../../assets/img/id-bg/1.jpg';
    if ($websiteConfig['id_card_style']) {
        $bg_path = '../../assets/img/id-bg/' . $websiteConfig['id_card_style'];
    }
    if (file_exists($bg_path)) {
        $pdf->Image($bg_path, $x, $y, $id_width, $id_height, 'JPG', '', '', false, 300, '', false, false, 0);
    }

    // School Name
    $padding = 2;
    $pdf->SetXY($x + $padding, $y + 3); // Move start position right by padding
    $pdf->SetFont($funky_bird, 'B', 12);
    $pdf->SetTextColor(255, 200, 66);
    $pdf->MultiCell($id_width - ($padding * 2), 3, strtoupper($schoolInfo['name']), 0, 'C', false);

    $pdf->Ln(1);
    // School Address
    $padding = 3;
    $line_height = 3;
    $max_lines = 2;
    $max_height = $line_height * $max_lines; // 6mm total height for 2 lines

    $pdf->SetX($x + $padding);
    $pdf->SetFont('helvetica', '', 6);
    $pdf->SetTextColor(255, 255, 255);
    $pdf->MultiCell($id_width - ($padding * 2), $line_height, $schoolInfo['address'], 0, 'C', false, 1, null, null, true, 0, false, true, $max_height, 'M');


    // Define positions relative to the card's top-left corner ($x, $y)
    $photo_base_x = $x + 19.55;
    $photo_base_y = $y + 21;
    $photo_width = 15;
    $photo_height = 18;
    $logo_size = 11;
    $logo_left_x = $photo_base_x - $logo_size - 7;
    $logo_right_x = $photo_base_x + $photo_width + 5;
    $logo_y = $photo_base_y + ($photo_height / 9) - ($logo_size / 9);

    // QR Code (Left)
    $qr_data = $student['student_id'];
    $style = ['border' => 0, 'vpadding' => '1', 'hpadding' => '1', 'fgcolor' => [0, 0, 0], 'bgcolor' => [255, 255, 255], 'module_width' => 1, 'module_height' => 1];
    $pdf->write2DBarcode($qr_data, 'QRCODE,L', $logo_left_x + 2, $logo_y + 1, $logo_size, $logo_size, $style, 'N');

    // School Logo (Right)
    $logo_path = '../../uploads/school/logo-square.png';
    if (file_exists($logo_path)) {
        $pdf->StartTransform();
        $pdf->RoundedRect($logo_right_x, $logo_y, $logo_size, $logo_size, $logo_size / 2, '1111', 'CNZ');
        $pdf->Image($logo_path, $logo_right_x, $logo_y, $logo_size, $logo_size, 'PNG', '', '', true, 300, '', false, false, 0);
        $pdf->StopTransform();
    }

    // Student Photo
    $photo_path = "../../uploads/students/" . $student['student_image'];
    if (!empty($student['student_image']) && file_exists($photo_path)) {
        $pdf->StartTransform();
        $pdf->RoundedRect($photo_base_x, $photo_base_y, $photo_width, $photo_height, 2, '1111', 'CNZ');
        $pdf->Image($photo_path, $photo_base_x, $photo_base_y, $photo_width, $photo_height, strtolower(pathinfo($photo_path, PATHINFO_EXTENSION)), '', '', true, 300, '', false, false, 0);
        $pdf->StopTransform();
    } else {
        $pdf->SetXY($photo_base_x, $photo_base_y);
        $pdf->SetFont('helvetica', '', 6);
        $pdf->SetTextColor(150, 150, 150);
        $pdf->Cell($photo_width, $photo_height, 'No Photo', 0, 0, 'C');
    }

    // Student Name
    $student_name_html = '<table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td align="center">' . strtoupper($student['name']) . '</td></tr></table>';
    $pdf->SetXY($x, $y + 42);
    $pdf->SetFont($one_slice, '', 10);
    $pdf->SetTextColor(0, 36, 220);
    $pdf->writeHTMLCell($id_width, 0, $x, $y + 42, $student_name_html, 0, 1, 0, true, 'C', true);

    // Student Details
    $student_info = <<<EOD
    <div style="text-align: center;">
        <table width="100%" style="border: none;" cellspacing="1" cellpadding="1">
            <tr><td align="left">Father:</td><td align="left">{$student['father_name']}</td></tr>
            <tr><td align="left">Roll No:</td><td align="left">{$student['roll_no']}</td></tr>
            <tr><td align="left">Class:</td><td align="left">{$student['class_name']} ({$student['section_name']})</td></tr>
            <tr><td align="left">D.O.B:</td><td align="left">{$student['date_of_birth']}</td></tr>
            <tr><td align="left">Contact:</td><td align="left">{$student['phone_number']}</td></tr>
            <tr><td align="left">School Contact:</td><td align="left">{$schoolInfo['phone']}</td></tr>
        </table>
    </div>
    EOD;
    $pdf->SetFont('helvetica', '', 6);
    $pdf->SetTextColor(10, 10, 10);
    $pdf->writeHTMLCell($id_width - 10, 0, $x + 5, $y + 48, $student_info, 0, 1, 0, true, 'C', true);

    // Address Footer
    $student_address = '<div style="text-align: center;">' . $student['address'] . '</div>';
    $pdf->SetFont('helvetica', '', 5);
    $pdf->SetTextColor(255, 255, 255);
    $pdf->writeHTMLCell($id_width - 10, 0, $x + 5, $y + $id_height - 7, $student_address, 0, 1, 0, true, 'C', true);

    // --- End of a single ID Card ---

    // Move to the next position on the page
    $current_position = ($current_position + 1) % 9;
}

// Output PDF
$pdf->Output('Bulk-ID-Cards.pdf', 'I');
