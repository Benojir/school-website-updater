<?php
// Check if user is logged in
include_once(__DIR__ . "/../../includes/auth-check.php");
try { $academicSource = academicStudentSourceSql($pdo, academicRequestedYear($_REQUEST)); }
catch (InvalidArgumentException $e) { http_response_code(400); exit(htmlspecialchars($e->getMessage(), ENT_QUOTES, "UTF-8")); }

include_once(__DIR__ . "/../../../vendor/autoload.php");

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;

// Check permissions
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    die('You do not have permission to export students data.');
}

// 1. Handle Student IDs (Support both POST and GET)
$raw_ids = $_POST['student_ids'] ?? $_GET['student_ids'] ?? '';

if (empty($raw_ids)) {
    die("No students selected for export.");
}

$student_ids = explode(',', $raw_ids);
$student_ids = array_map('trim', $student_ids); // Clean whitespace

// 2. Define Configuration Map
// Keys match the 'name' attributes in your Modal HTML
// 'db' = Database column, 'header' = Excel Header Name, 'type' = formatting type
$exportConfig = [
    'exportStudentId'     => ['db' => 's.student_id', 'header' => 'Student ID'],
    'exportStudentName'   => ['db' => 's.name', 'header' => 'Student Name'],
    'exportClass'         => ['db' => 'c.class_name', 'header' => 'Class'],
    'exportSection'       => ['db' => 'sec.section_name', 'header' => 'Section'],
    'exportRollNo'        => ['db' => 's.roll_no', 'header' => 'Roll No'],
    'exportRegNo'         => ['db' => 's.registration_no', 'header' => 'Reg. No.'],
    'exportAdmissionDate' => ['db' => 's.admission_date', 'header' => 'Admission Date', 'type' => 'date'],
    'exportDOB'           => ['db' => 's.date_of_birth', 'header' => 'Date of Birth', 'type' => 'date'],
    'exportGender'        => ['db' => 's.gender', 'header' => 'Gender'],
    'exportBloodGroup'    => ['db' => 's.blood_group', 'header' => 'Blood Group'],
    'exportEmail'         => ['db' => 's.email', 'header' => 'Email'],
    'exportPhone'         => ['db' => 's.phone_number', 'header' => 'Phone'],
    'exportAltPhone'      => ['db' => 's.alternate_phone_number', 'header' => 'Alt. Phone'],
    'exportReligion'      => ['db' => 's.religion', 'header' => 'Religion'],
    'exportFullAddress'   => ['db' => 's.address', 'header' => 'Full Address'],
    'exportVillage'       => ['db' => 's.village', 'header' => 'Village/Town'],
    'exportPostOffice'    => ['db' => 's.post_office', 'header' => 'Post Office'],
    'exportPoliceStation' => ['db' => 's.police_station', 'header' => 'Police Station'],
    'exportDistrict'      => ['db' => 's.district', 'header' => 'District'],
    'exportPinCode'       => ['db' => 's.pin_code', 'header' => 'Pin Code'],
    'exportFatherName'    => ['db' => 's.father_name', 'header' => 'Father Name'],
    'exportMotherName'    => ['db' => 's.mother_name', 'header' => 'Mother Name'],
    'exportStudentAadhar' => ['db' => 's.student_adhaar_no', 'header' => 'Student Aadhar'],
    'exportFatherAadhar'  => ['db' => 's.father_adhaar_no', 'header' => 'Father Aadhar'],
    'exportMotherAadhar'  => ['db' => 's.mother_adhaar_no', 'header' => 'Mother Aadhar'],
];

// 3. Build Dynamic Query Parts
$selectedDbColumns = [];
$excelHeaders = [];
$mapKeys = []; // To keep track of order

// ফ্রন্টএন্ড থেকে পাঠানো কাস্টম অর্ডার ধরা
$raw_order = $_POST['column_order'] ?? '';

if (!empty($raw_order)) {
    // কমা সেপারেটেড স্ট্রিং কে অ্যারেতে কনভার্ট করা
    $ordered_keys = explode(',', $raw_order);

    foreach ($ordered_keys as $key) {
        // সিকিউরিটি চেক: এই key টি আমাদের $exportConfig এ আছে কিনা
        if (array_key_exists($key, $exportConfig)) {
            $config = $exportConfig[$key];
            
            $selectedDbColumns[] = $config['db'];
            $excelHeaders[] = $config['header'];
            $mapKeys[] = $key;
        }
    }
}

// Fallback: যদি কোনো কারণে অর্ডার না আসে বা সব খালি থাকে (যেমন সরাসরি GET রিকোয়েস্ট)
if (empty($selectedDbColumns)) {
    // ডিফল্ট লজিক বা আগের লজিক রাখতে পারেন
    // অথবা $exportConfig লুপ চালিয়ে যেগুলো চেকবক্সে আছে সেগুলো নিতে পারেন (আগের কোডের মতো)
    foreach ($exportConfig as $postKey => $config) {
        if (isset($_POST[$postKey]) || isset($_GET[$postKey])) {
            $selectedDbColumns[] = $config['db'];
            $excelHeaders[] = $config['header'];
            $mapKeys[] = $postKey;
        }
    }
}

// একদমই কিছু সিলেক্ট না থাকলে ডিফল্ট ভ্যালু
if (empty($selectedDbColumns)) {
    $selectedDbColumns = ['s.student_id', 's.name', 'c.class_name'];
    $excelHeaders = ['Student ID', 'Name', 'Class'];
    $mapKeys = ['exportStudentId', 'exportStudentName', 'exportClass'];
}

try {
    // 4. Prepare SQL
    $placeholders = rtrim(str_repeat('?,', count($student_ids)), ',');
    $selectClause = implode(', ', $selectedDbColumns);

    $query = "
        SELECT $selectClause
        FROM {$academicSource} s
        LEFT JOIN classes c ON s.class_id = c.id
        LEFT JOIN sections sec ON s.section_id = sec.id
        WHERE s.student_id IN ($placeholders) 
        ORDER BY c.id, sec.id, s.roll_no
    ";

    $stmt = $pdo->prepare($query);
    $stmt->execute($student_ids);
    $results = $stmt->fetchAll(PDO::FETCH_NUM); // Fetch numeric to match header order

    if (empty($results)) {
        die("No data found for the provided Student IDs.");
    }

    // 5. Create Spreadsheet
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();
    $sheet->setTitle("Student Data");

    // Set Headers (Row 1)
    $sheet->fromArray($excelHeaders, NULL, 'A1');

    // Style Headers
    $headerStyle = [
        'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
        'fill' => ['fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, 'startColor' => ['rgb' => '0d6efd']] // Bootstrap Primary
    ];
    // Calculate last column letter (e.g., 'C', 'Z', 'AA')
    $lastColumnLetter = Coordinate::stringFromColumnIndex(count($excelHeaders));
    $sheet->getStyle("A1:{$lastColumnLetter}1")->applyFromArray($headerStyle);

    // 6. Process Data Rows
    $rowIndex = 2;
    foreach ($results as $row) {
        $formattedRow = [];
        
        // Loop through each column in the row to apply formatting based on config
        foreach ($row as $colIndex => $value) {
            $configKey = $mapKeys[$colIndex]; // Get the original config key
            $type = $exportConfig[$configKey]['type'] ?? 'string';

            if ($type === 'date' && !empty($value)) {
                $formattedRow[] = date('d-m-Y', strtotime($value));
            } else {
                $formattedRow[] = $value;
            }
        }

        $sheet->fromArray($formattedRow, NULL, 'A' . $rowIndex);
        $rowIndex++;
    }

    // 7. Auto-size columns
    foreach (range(1, count($excelHeaders)) as $colIndex) {
        $colString = Coordinate::stringFromColumnIndex($colIndex);
        $sheet->getColumnDimension($colString)->setAutoSize(true);
    }

    // 8. Output
    $filename = 'students_export_' . date('Y-m-d_H-i') . '.xlsx';

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="' . $filename . '"');
    header('Cache-Control: max-age=0');

    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;

} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}