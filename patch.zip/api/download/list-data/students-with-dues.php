<?php
ob_start();
/** 
 * @var PDO $pdo 
 * @var array $schoolInfo
 * @var string $currency_symbol
 * @var array $websiteConfig
 */
ini_set('memory_limit', '512M');
include_once(__DIR__ . "/../../../includes/auth-check.php");

$student_ids_raw = $_REQUEST['student_ids'] ?? '';

if (empty($student_ids_raw)) {
    die("Student ID(s) are required.");
}

if (is_array($student_ids_raw)) {
    $student_ids = $student_ids_raw;
} else {
    $student_ids = explode(',', (string)$student_ids_raw);
}
$student_ids = array_unique(array_filter(array_map('trim', $student_ids)));

if (empty($student_ids)) {
    die("No valid student(s) found.");
}

$school_name = $schoolInfo['name'] ?? 'School';
$school_address = $schoolInfo['address'] ?? '';
$school_contact = trim(($schoolInfo['phone'] ?? '') . ' / ' . ($schoolInfo['alternate_phone'] ?? ''), ' /');
$school_email = $schoolInfo['email'] ?? '';
$school_logo = BASE_URL . '/uploads/school/logo-square.png?v=' . time();

// Prepare SQL statements once for efficiency
$stmt_admission = $pdo->prepare("SELECT unpaid_amount, academic_year FROM admission_unpaid_fees WHERE student_id = :student_id");
$stmt_monthly = $pdo->prepare("SELECT unpaid_amount, month_year FROM student_unpaid_fees WHERE student_id = :student_id");
$stmt_additional = $pdo->prepare("
    SELECT cwaf.fee_type, cwaf.amount
    FROM additional_fees_data afd
    JOIN class_wise_additional_fees cwaf ON cwaf.id = afd.additional_fee_setup_id
    WHERE afd.student_id = :student_id AND afd.additional_fee_status = 'unpaid'
");

$students_data = [];
$grand_total_admission = 0.0;
$grand_total_monthly = 0.0;
$grand_total_additional = 0.0;
$grand_total_due = 0.0;
$total_students_with_dues = 0;

$default_avatar = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%239ca3af'%3E%3Cpath d='M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z'/%3E%3C/svg%3E";

foreach ($student_ids as $student_id) {
    $student_info = getStudentInfo($pdo, (string)$student_id);
    if (!$student_info) {
        continue;
    }

    // ------------- Get total admission pending fees -------------
    $stmt_admission->execute(['student_id' => $student_id]);
    $academic_years = [];
    $total_admission_pending_fees = 0.0;
    while ($row = $stmt_admission->fetch(PDO::FETCH_ASSOC)) {
        $total_admission_pending_fees += (float)$row['unpaid_amount'];
        if (!empty($row['academic_year'])) {
            $academic_years[] = $row['academic_year'];
        }
    }
    $academic_years = array_unique($academic_years);
    $admission_detail_text = '';
    if (count($academic_years) > 0) {
        usort($academic_years, function ($a, $b) {
            return $a <=> $b;
        });
        $admission_detail_text = implode(', ', $academic_years);
    }

    // ------------- Get total monthly pending fees -------------
    $stmt_monthly->execute(['student_id' => $student_id]);
    $month_years = [];
    $total_monthly_pending_fees = 0.0;
    while ($row = $stmt_monthly->fetch(PDO::FETCH_ASSOC)) {
        $total_monthly_pending_fees += (float)$row['unpaid_amount'];
        if (!empty($row['month_year'])) {
            $month_years[] = $row['month_year'];
        }
    }
    $months_detail_text = '';
    if (count($month_years) > 0) {
        usort($month_years, function ($a, $b) {
            return strtotime("1 " . $a) <=> strtotime("1 " . $b);
        });
        if (count($month_years) <= 2) {
            $months_detail_text = implode(', ', $month_years);
        } else {
            $months_detail_text = $month_years[0] . ' to ' . end($month_years) . ' (' . count($month_years) . ' mos)';
        }
    }

    // ------------- Get total pending additional fees -------------
    $stmt_additional->execute(['student_id' => $student_id]);
    $total_additional_pending_fees = 0.0;
    $additional_names = [];
    while ($row = $stmt_additional->fetch(PDO::FETCH_ASSOC)) {
        $total_additional_pending_fees += (float)$row['amount'];
        if (!empty($row['fee_type'])) {
            $additional_names[] = $row['fee_type'];
        }
    }
    $additional_detail_text = implode(', ', array_unique($additional_names));

    $total_pending_fees = $total_admission_pending_fees + $total_monthly_pending_fees + $total_additional_pending_fees;

    $grand_total_admission += $total_admission_pending_fees;
    $grand_total_monthly += $total_monthly_pending_fees;
    $grand_total_additional += $total_additional_pending_fees;
    $grand_total_due += $total_pending_fees;

    if ($total_pending_fees > 0) {
        $total_students_with_dues++;
    }

    $photo_url = '';
    if (!empty($student_info['student_image'])) {
        $photo_url = BASE_URL . '/uploads/students/' . $student_info['student_image'];
    }

    $students_data[] = [
        'student_id' => $student_info['student_id'] ?? $student_id,
        'name' => $student_info['name'] ?? '',
        'roll_no' => $student_info['roll_no'] ?? '',
        'class_name' => $student_info['class_name'] ?? '',
        'section_name' => $student_info['section_name'] ?? '',
        'photo_url' => $photo_url,
        'father_name' => $student_info['father_name'] ?? '',
        'mother_name' => $student_info['mother_name'] ?? '',
        'father_phone' => $student_info['phone_number'] ?? '',
        'mother_phone' => $student_info['alternate_phone_number'] ?? '',
        'tuition_fee' => $student_info['tution_fee'] ?? 0,
        'admission_due' => $total_admission_pending_fees,
        'admission_year' => $admission_detail_text,
        'monthly_due' => $total_monthly_pending_fees,
        'monthly_months' => $months_detail_text,
        'additional_due' => $total_additional_pending_fees,
        'additional_detail' => $additional_detail_text,
        'total_due' => $total_pending_fees,
    ];
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dues List - <?= safe_htmlspecialchars($school_name) ?></title>
    <style>
        @page {
            size: A4 portrait;
            margin: 8mm 6mm 8mm 6mm;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: "Segoe UI", Arial, "Kalpurush", "SolaimanLipi", sans-serif;
            font-size: 11px;
            color: #1e293b;
            background-color: #f1f5f9;
            line-height: 1.35;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        .sheet-wrap {
            max-width: 900px;
            margin: 15px auto;
            background: #ffffff;
            padding: 12px 14px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            border-radius: 6px;
        }

        /* ----- Action Bar (Hidden on Print) ----- */
        .action-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
            padding: 10px 14px;
            margin-bottom: 12px;
            background: #e2e8f0;
            border-radius: 6px;
            border: 1px solid #cbd5e1;
        }

        .action-bar-left {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
            font-size: 11.5px;
        }

        .badge-info {
            background: #0284c7;
            color: #fff;
            padding: 3px 8px;
            border-radius: 4px;
            font-weight: 500;
        }

        .badge-due {
            background: #e11d48;
            color: #fff;
            padding: 3px 8px;
            border-radius: 4px;
            font-weight: 500;
        }

        .badge-total {
            background: #047857;
            color: #fff;
            padding: 3px 8px;
            border-radius: 4px;
            font-weight: 500;
        }

        .filter-toggle {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            cursor: pointer;
            margin-left: 6px;
            font-weight: 600;
            color: #334155;
            user-select: none;
        }

        .filter-toggle input {
            cursor: pointer;
            width: 14px;
            height: 14px;
        }

        .btn-print {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #2563eb;
            color: #ffffff;
            border: none;
            border-radius: 5px;
            padding: 6px 16px;
            font-size: 12.5px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.15s ease;
        }

        .btn-print:hover {
            background: #1d4ed8;
        }

        /* ----- School Header ----- */
        .school-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 2px solid #0f172a;
            padding-bottom: 6px;
            margin-bottom: 8px;
            gap: 12px;
        }

        .school-header .logo-box {
            width: 46px;
            height: 46px;
            min-width: 46px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            border-radius: 4px;
        }

        .school-header .logo-box img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }

        .school-header .school-text {
            flex: 1;
            text-align: left;
        }

        .school-header .school-name {
            font-size: 17px;
            font-weight: 800;
            color: #0f172a;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            line-height: 1.2;
        }

        .school-header .school-sub {
            font-size: 10px;
            color: #475569;
            margin-top: 1px;
        }

        .school-header .school-contact {
            font-size: 9.5px;
            color: #64748b;
        }

        .report-meta {
            text-align: right;
            min-width: 140px;
        }

        .report-title {
            font-size: 13px;
            font-weight: 800;
            color: #b91c1c;
            letter-spacing: 0.5px;
            border: 1px solid #b91c1c;
            padding: 2px 6px;
            border-radius: 3px;
            background: #fef2f2;
            display: inline-block;
            margin-bottom: 2px;
        }

        .report-date {
            font-size: 9.5px;
            color: #64748b;
            font-weight: 500;
        }

        /* ----- Main Dues Table ----- */
        table.due-table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            font-size: 10.5px;
        }

        table.due-table thead {
            display: table-header-group; /* Repeats header on every printed A4 page */
        }

        table.due-table tfoot {
            display: table-footer-group;
        }

        table.due-table tbody tr {
            page-break-inside: avoid;
            break-inside: avoid;
        }

        table.due-table th,
        table.due-table td {
            border: 1px solid #94a3b8;
            padding: 3.5px 4px;
            vertical-align: middle;
            word-break: break-word;
        }

        table.due-table th {
            background-color: #e2e8f0;
            color: #0f172a;
            font-weight: 700;
            font-size: 10.5px;
            text-align: center;
            padding: 5px 3px;
        }

        /* Column Widths (A4 Portrait Optimization) */
        .th-sl      { width: 24px; text-align: center; }
        .th-photo   { width: 40px; text-align: center; }
        .th-student { width: 175px; text-align: left; }
        .th-parents { width: 125px; text-align: left; }
        .th-fee     { width: 92px; text-align: right; }
        .th-total   { width: 84px; text-align: right; }

        .td-sl {
            text-align: center;
            font-weight: 600;
            color: #475569;
            font-size: 10px;
        }

        .td-photo {
            text-align: center;
            padding: 2px;
        }

        .student-img {
            width: 34px;
            height: 34px;
            object-fit: cover;
            border-radius: 4px;
            border: 1px solid #cbd5e1;
            display: block;
            margin: 0 auto;
            background: #f8fafc;
        }

        .td-student {
            text-align: left;
            padding-left: 5px;
        }

        .st-name {
            font-weight: 700;
            font-size: 11px;
            color: #0f172a;
            line-height: 1.25;
        }

        .st-meta {
            font-size: 9.5px;
            color: #334155;
            margin-top: 1px;
            display: flex;
            flex-wrap: wrap;
            gap: 4px;
        }

        .st-id {
            font-size: 8.5px;
            color: #64748b;
        }

        .td-parents {
            text-align: left;
            font-size: 9.5px;
            line-height: 1.35;
        }

        .parent-row {
            display: flex;
            align-items: baseline;
            gap: 3px;
            white-space: nowrap;
        }

        .parent-tag {
            font-weight: 700;
            color: #475569;
            font-size: 9px;
            min-width: 22px;
        }

        .phone-val {
            color: #0f172a;
            font-family: monospace;
            font-size: 10px;
            font-weight: 600;
        }

        .td-fee {
            text-align: right;
            padding-right: 5px;
        }

        .amt {
            font-weight: 700;
            font-size: 10.5px;
        }

        .amt-due {
            color: #b91c1c;
        }

        .amt-zero {
            color: #94a3b8;
            font-weight: 500;
        }

        .fee-detail {
            font-size: 8.5px;
            color: #475569;
            line-height: 1.15;
            margin-top: 1px;
        }

        .td-total {
            text-align: right;
            padding-right: 5px;
        }

        .total-badge {
            display: inline-block;
            background-color: #fee2e2;
            color: #b91c1c;
            border: 1px solid #f87171;
            padding: 1px 5px;
            border-radius: 3px;
            font-weight: 800;
            font-size: 11px;
        }

        .clear-badge {
            display: inline-block;
            background-color: #ecfdf5;
            color: #047857;
            border: 1px solid #a7f3d0;
            padding: 1px 5px;
            border-radius: 3px;
            font-weight: 700;
            font-size: 9.5px;
        }

        /* Zebra Striping */
        tbody tr:nth-child(even) {
            background-color: #f8fafc;
        }

        /* Total Summary Footer */
        .total-summary-row th {
            background-color: #cbd5e1 !important;
            color: #0f172a;
            font-weight: 800;
            font-size: 10.5px;
            padding: 5px;
        }

        .total-summary-row .text-end {
            text-align: right;
            padding-right: 8px;
        }

        .total-grand-badge {
            display: inline-block;
            background-color: #991b1b;
            color: #ffffff;
            padding: 2px 6px;
            border-radius: 3px;
            font-weight: 800;
            font-size: 11px;
        }

        .print-footer-info {
            display: none;
        }

        /* ----- Print Styles ----- */
        @media print {
            body {
                background: #fff !important;
                margin: 0 !important;
                padding: 0 !important;
            }

            .sheet-wrap {
                max-width: 100% !important;
                margin: 0 !important;
                padding: 0 !important;
                box-shadow: none !important;
                border-radius: 0 !important;
            }

            .no-print {
                display: none !important;
            }

            table.due-table {
                border-color: #475569 !important;
            }

            table.due-table th,
            table.due-table td {
                border-color: #64748b !important;
            }

            .print-footer-info {
                display: flex;
                justify-content: space-between;
                margin-top: 10px;
                font-size: 8.5px;
                color: #64748b;
                border-top: 1px dashed #cbd5e1;
                padding-top: 4px;
            }
        }
    </style>
</head>
<body>

<div class="sheet-wrap">

    <!-- Top Action Bar (Hidden in Print) -->
    <div class="action-bar no-print">
        <div class="action-bar-left">
            <span class="badge-info">Students: <strong><?= count($students_data) ?></strong></span>
            <span class="badge-due">With Dues: <strong><?= $total_students_with_dues ?></strong></span>
            <span class="badge-total">Total Outstanding: <strong><?= $currency_symbol . number_format($grand_total_due, 2) ?></strong></span>
            <label class="filter-toggle">
                <input type="checkbox" id="toggleDuesOnly" onchange="filterDuesOnly(this.checked)">
                <span>Show Only Students With Dues</span>
            </label>
        </div>
        <div class="action-bar-right">
            <button type="button" class="btn-print" onclick="window.print()">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z"/></svg>
                Print / Save PDF
            </button>
        </div>
    </div>

    <!-- School Header -->
    <div class="school-header">
        <?php if (!empty($school_logo)): ?>
            <div class="logo-box">
                <img src="<?= safe_htmlspecialchars($school_logo) ?>" alt="Logo" onerror="this.parentElement.style.display='none'">
            </div>
        <?php endif; ?>
        <div class="school-text">
            <h1 class="school-name"><?= safe_htmlspecialchars($school_name) ?></h1>
            <?php if (!empty($school_address)): ?>
                <div class="school-sub"><?= safe_htmlspecialchars($school_address) ?></div>
            <?php endif; ?>
            <div class="school-contact">
                <?php if (!empty($school_contact)): ?><span>Phone: <?= safe_htmlspecialchars($school_contact) ?></span><?php endif; ?>
                <?php if (!empty($school_email)): ?><span> | Email: <?= safe_htmlspecialchars($school_email) ?></span><?php endif; ?>
            </div>
        </div>
        <div class="report-meta">
            <div class="report-title">STUDENT DUES LIST</div>
            <div class="report-date">Generated: <?= date('d/m/Y h:i A') ?></div>
        </div>
    </div>

    <!-- Main Table -->
    <table class="due-table" id="dueTable">
        <thead>
            <tr>
                <th class="th-sl">#</th>
                <th class="th-photo">Photo</th>
                <th class="th-student">Student Information</th>
                <th class="th-parents">Parents' Phone</th>
                <th class="th-fee">Admission Due</th>
                <th class="th-fee">Monthly Due</th>
                <th class="th-fee">Additional Fees</th>
                <th class="th-total">Total Due</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $sl = 1;
            foreach ($students_data as $st): 
                $has_due = ($st['total_due'] > 0);
            ?>
                <tr class="data-row <?= $has_due ? 'has-due' : 'zero-due' ?>">
                    <td class="td-sl"><?= $sl++ ?></td>
                    <td class="td-photo">
                        <img src="<?= !empty($st['photo_url']) ? safe_htmlspecialchars($st['photo_url']) : $default_avatar ?>" 
                             alt="Photo" 
                             class="student-img" 
                             onerror="this.onerror=null;this.src='<?= $default_avatar ?>'">
                    </td>
                    <td class="td-student">
                        <div class="st-name"><?= safe_htmlspecialchars($st['name']) ?></div>
                        <div class="st-meta">
                            <span>Roll: <strong><?= safe_htmlspecialchars($st['roll_no'] ?: '-') ?></strong></span>
                            <span>Class: <strong><?= safe_htmlspecialchars($st['class_name'] ?: '-') ?></strong></span>
                            <?php if (!empty($st['section_name'])): ?>
                                <span>Sec: <strong><?= safe_htmlspecialchars($st['section_name']) ?></strong></span>
                            <?php endif; ?>
                        </div>
                        <div class="st-id">ID: <?= safe_htmlspecialchars($st['student_id']) ?></div>
                    </td>
                    <td class="td-parents">
                        <div class="parent-row">
                            <span class="parent-tag">F:</span> 
                            <span class="phone-val"><?= !empty($st['father_phone']) ? safe_htmlspecialchars($st['father_phone']) : '<span class="text-muted">-</span>' ?></span>
                        </div>
                        <div class="parent-row">
                            <span class="parent-tag">M:</span> 
                            <span class="phone-val"><?= !empty($st['mother_phone']) ? safe_htmlspecialchars($st['mother_phone']) : '<span class="text-muted">-</span>' ?></span>
                        </div>
                    </td>
                    <td class="td-fee">
                        <?php if ($st['admission_due'] > 0): ?>
                            <div class="amt amt-due"><?= $currency_symbol . number_format($st['admission_due'], 2) ?></div>
                            <?php if (!empty($st['admission_year'])): ?>
                                <div class="fee-detail"><?= safe_htmlspecialchars($st['admission_year']) ?></div>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="amt-zero">-</span>
                        <?php endif; ?>
                    </td>
                    <td class="td-fee">
                        <?php if ($st['monthly_due'] > 0): ?>
                            <div class="amt amt-due"><?= $currency_symbol . number_format($st['monthly_due'], 2) ?></div>
                            <?php if (!empty($st['monthly_months'])): ?>
                                <div class="fee-detail"><?= safe_htmlspecialchars($st['monthly_months']) ?></div>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="amt-zero">-</span>
                        <?php endif; ?>
                    </td>
                    <td class="td-fee">
                        <?php if ($st['additional_due'] > 0): ?>
                            <div class="amt amt-due"><?= $currency_symbol . number_format($st['additional_due'], 2) ?></div>
                            <?php if (!empty($st['additional_detail'])): ?>
                                <div class="fee-detail"><?= safe_htmlspecialchars($st['additional_detail']) ?></div>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="amt-zero">-</span>
                        <?php endif; ?>
                    </td>
                    <td class="td-total">
                        <?php if ($st['total_due'] > 0): ?>
                            <span class="total-badge"><?= $currency_symbol . number_format($st['total_due'], 2) ?></span>
                        <?php else: ?>
                            <span class="clear-badge">Paid</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr class="total-summary-row">
                <th colspan="4" class="text-end">Grand Total:</th>
                <th class="td-fee"><?= $currency_symbol . number_format($grand_total_admission, 2) ?></th>
                <th class="td-fee"><?= $currency_symbol . number_format($grand_total_monthly, 2) ?></th>
                <th class="td-fee"><?= $currency_symbol . number_format($grand_total_additional, 2) ?></th>
                <th class="td-total"><span class="total-grand-badge"><?= $currency_symbol . number_format($grand_total_due, 2) ?></span></th>
            </tr>
        </tfoot>
    </table>

    <div class="print-footer-info">
        <span><?= safe_htmlspecialchars($school_name) ?> &bull; Student Dues List</span>
        <span>Page &bull; Generated on <?= date('d/m/Y h:i A') ?></span>
    </div>

</div>

<script>
function filterDuesOnly(showOnlyDues) {
    const rows = document.querySelectorAll('#dueTable tbody tr.zero-due');
    rows.forEach(row => {
        row.style.display = showOnlyDues ? 'none' : '';
    });

    // Re-index visible rows
    let visibleIndex = 1;
    const allRows = document.querySelectorAll('#dueTable tbody tr');
    allRows.forEach(row => {
        if (row.style.display !== 'none') {
            const slCell = row.querySelector('.td-sl');
            if (slCell) {
                slCell.textContent = visibleIndex++;
            }
        }
    });
}
</script>

</body>
</html>
<?php
ob_end_flush();
