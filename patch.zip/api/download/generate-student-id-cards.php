<?php
/**
 * print-id-cards.php
 * -----------------------------------------------------------------
 * Main page for batch printing.
 *
 * Strategy: server-side Fabric.js canvas rendering isn't possible in PHP
 * (Fabric depends on the browser canvas API). So the strategy is —
 *   1. PHP just prepares the raw data: (a) the saved design_json template(s),
 *      (b) an array of the selected students' data, (c) the page grid worked
 *      out from the card's real size.
 *   2. In the browser (client-side), render-id-cards-batch.js clones the
 *      template JSON for each student, replaces the variables/images, loads
 *      it into an offscreen Fabric canvas, and exports it to an image.
 *   3. All the card images are laid out on the computed A4 grid and
 *      window.print() is called (the same pattern used elsewhere in this
 *      system for wkhtmltoimage/browser printing — no extra Node/Puppeteer
 *      service needed).
 *
 * Cards are no longer a fixed 55x85mm single-sided format: the size comes from
 * the template (canvas_width/canvas_height in px at 10 px per mm) and the card
 * may have a back side, which is printed according to $layout_mode.
 */
include_once("../../includes/auth-check.php");
require_once __DIR__ . '/../../includes/id-card-school-data.php';
$is_teacher_id_card = defined('ID_CARD_AUDIENCE') && ID_CARD_AUDIENCE === 'teacher';
$is_driver_id_card = defined('ID_CARD_AUDIENCE') && ID_CARD_AUDIENCE === 'driver';
$is_admit_card = defined('ID_CARD_AUDIENCE') && ID_CARD_AUDIENCE === 'admit';
$is_admission_form = defined('ID_CARD_AUDIENCE') && ID_CARD_AUDIENCE === 'admission';
$id_card_subject_label = $is_admission_form ? 'Admission' : ($is_admit_card ? 'Admit' : ($is_driver_id_card ? 'Driver' : ($is_teacher_id_card ? 'Teacher' : 'Student')));
$card_document_label = $is_admission_form ? 'Admission Forms' : ($is_admit_card ? 'Admit Cards' : $id_card_subject_label . ' ID Cards');
$id_card_template_table = $is_admission_form ? 'admission_form_templates' : ($is_admit_card ? 'admit_card_templates' : strtolower($id_card_subject_label) . '_id_card_templates');
if ($is_admission_form) {
    if (!hasPermission(PERM_MANAGE_STUDENTS)) { http_response_code(403); exit('Permission denied'); }
    require_once __DIR__ . '/../../includes/admission-form-builder-data.php';
    try {
        $admissionInput = $_POST + $_GET;
        $student_ids = admissionFormSelectedIds($admissionInput['student_ids'] ?? null);
        $admissionYear = academicNormalizeYear($admissionInput['selected_year'] ?? $admissionInput['session_year'] ?? $admissionInput['academic_year'] ?? null);
    } catch (InvalidArgumentException $error) { http_response_code(400); exit(htmlspecialchars($error->getMessage(), ENT_QUOTES, 'UTF-8')); }
} elseif ($is_admit_card) {
    require_once __DIR__ . '/../../includes/exam-document-download.php';
    require_once __DIR__ . '/../../includes/admit-card-builder-data.php';
    $admitRequest = examDocumentRequireDownload('admit');
} elseif ($is_teacher_id_card) {
    if (!hasPermission(PERM_MANAGE_ID_CARDS) || !hasPermission(PERM_MANAGE_TEACHERS)) {
        http_response_code(403); exit('Permission denied');
    }
    require_once(__DIR__ . '/../../includes/teacher/teacher-id-card-data.php');
} elseif ($is_driver_id_card) {
    if (!hasPermission(PERM_MANAGE_ID_CARDS) || !hasPermission(PERM_MANAGE_TRANSPORT)) {
        http_response_code(403); exit('Permission denied');
    }
    require_once(__DIR__ . '/../../includes/driver/driver-id-card-data.php');
} else {
    try { $academicSource = academicStudentSourceSql($pdo, academicRequestedYear($_REQUEST)); }
    catch (InvalidArgumentException $e) { http_response_code(400); exit(htmlspecialchars($e->getMessage(), ENT_QUOTES, "UTF-8")); }
}


// Fixed scale shared with the builder: 10 canvas pixels = 1 millimetre.
// See PX_PER_MM in assets/js/student/id-card/id-card-builder.js.
const PX_PER_MM = 10;

// A4 portrait page geometry, in millimetres. PAGE_MARGIN_MM must match the
// `margin` in the @page rule below.
const PAGE_WIDTH_MM  = 210;
const PAGE_HEIGHT_MM = 297;
define('PAGE_MARGIN_MM', ($is_admit_card || $is_admission_form) ? 0 : 8);
define('CARD_GAP_MM', ($is_admit_card || $is_admission_form) ? 0 : 4);

// 1. Selected student IDs
if ($is_admission_form) {
    // IDs and selected year were validated after authorization above.
} elseif ($is_admit_card) {
    $student_ids = $admitRequest['student_ids'];
} elseif ($is_teacher_id_card) {
    try { $teacher_ids = teacherIdCardSelectedIds($_POST + $_GET); }
    catch (InvalidArgumentException $e) { http_response_code(400); exit(htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8')); }
} elseif ($is_driver_id_card) {
    try { $driver_ids = driverIdCardSelectedIds($_POST + $_GET); }
    catch (InvalidArgumentException $e) { http_response_code(400); exit(htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8')); }
} else {
    $student_ids = json_decode($_REQUEST['student_ids'] ?? '[ ]', true);
    if (!is_array($student_ids) || empty($student_ids)) die("Invalid student IDs");
}

// 1b. How to arrange the two sides of a double-sided card:
//   'sequential'    — fronts on one sheet, matching backs on the next (duplex)
//   'side-by-side'  — each card's front and back next to each other on one sheet
// Ignored entirely for single-sided cards.
$layout_mode = $_REQUEST['duplex_layout'] ?? 'sequential';
if (!in_array($layout_mode, ['sequential', 'side-by-side'], true)) {
    $layout_mode = 'sequential';
}

// 2. Load the active design template
try {
$stmt = $pdo->query("SELECT * FROM {$id_card_template_table} WHERE is_active = 1 ORDER BY id LIMIT 1");
$template = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $error) {
    if (!$is_admit_card && !$is_admission_form) throw $error;
    http_response_code(503); exit($is_admission_form ? 'Admission Form Builder is not set up. Review and manually apply its migrate.sql block first.' : 'Custom admit cards are not set up yet. Please contact the school.');
}
if (!$template) {
    if ($is_admission_form) http_response_code(422);
    die($is_admission_form ? 'Save a design and choose Use for printing in the Admission Form Builder first.' : ($is_admit_card ? 'No custom admit-card template is selected. Save a design and choose Use for printing in the Admit Card Builder.' : "No active ID card design found. Please save a design in the Builder first."));
}

// 2b. Card format: size in mm (derived from the stored pixel size) plus whether
// a back side should be printed.
$card_width_px  = max(1, (int)$template['canvas_width']);
$card_height_px = max(1, (int)$template['canvas_height']);
$card_w_mm = $card_width_px / PX_PER_MM;
$card_h_mm = $card_height_px / PX_PER_MM;

$has_back = !empty($template['has_back']) && !empty($template['back_design_json']);
if ($is_admission_form) $layout_mode = 'sequential';
if (!$has_back) {
    $layout_mode = 'sequential'; // nothing to arrange
}

// 2c. Work out how many cards fit on one A4 sheet. This replaces the previously
// hardcoded 3x3 grid, which only ever matched a 55x85mm card.
//
// For N columns of width u separated by gap g: N*u + (N-1)*g <= usable, i.e.
// N <= (usable + g) / (u + g).
//
// In 'side-by-side' mode a grid "column" holds a whole front+back pair, so the
// unit width is two cards plus the gap that separates them.
$usable_w_mm = PAGE_WIDTH_MM  - (2 * PAGE_MARGIN_MM);
$usable_h_mm = PAGE_HEIGHT_MM - (2 * PAGE_MARGIN_MM);

$is_side_by_side = ($has_back && $layout_mode === 'side-by-side');
$unit_w_mm = $is_side_by_side ? (2 * $card_w_mm + CARD_GAP_MM) : $card_w_mm;

$grid_cols = max(1, (int)floor(($usable_w_mm + CARD_GAP_MM) / ($unit_w_mm + CARD_GAP_MM)));
$grid_rows = max(1, (int)floor(($usable_h_mm + CARD_GAP_MM) / ($card_h_mm + CARD_GAP_MM)));
$cards_per_page = $grid_cols * $grid_rows;
$page_orientation = 'portrait';
if ($is_admission_form) {
    // One form per sheet at its exact custom dimensions, including sizes larger than A4.
    if ($card_width_px < 200 || $card_width_px > 6000 || $card_height_px < 200 || $card_height_px > 6000) {
        http_response_code(422); exit('Save a form size between 20mm and 600mm on each side.');
    }
    $grid_cols = $grid_rows = $cards_per_page = 1;
    $page_orientation = $card_w_mm > $card_h_mm ? 'landscape' : 'portrait';
} elseif ($is_admit_card) {
    try {
        $grid = admitCardBuilderPrintGrid($card_w_mm, $card_h_mm, $is_side_by_side);
        $page_orientation = $grid['orientation']; $grid_cols = $grid['cols']; $grid_rows = $grid['rows']; $cards_per_page = $grid['count'];
    } catch (InvalidArgumentException $error) { http_response_code(422); exit(htmlspecialchars($error->getMessage(), ENT_QUOTES, 'UTF-8')); }
}

$school_logo_url = BASE_URL . '/uploads/school/logo-square.png?v=' . time();
if ($is_admission_form) {
    $front = json_decode($template['design_json'], true);
    $back = $has_back ? json_decode($template['back_design_json'], true) : [];
    if (!is_array($front) || empty($front['objects']) || !is_array($back) || ($has_back && empty($back['objects']))) {
        http_response_code(422); exit('The saved admission form design needs review in the builder.');
    }
    $financial = admissionFormNeedsFinancialData($front, $back);
    if ($financial && !hasPermission(PERM_MANAGE_FEES) && !hasPermission(PERM_CAN_SEE_FINANCIAL_REPORT)) {
        http_response_code(403); exit('This form includes financial information. Fee management or financial-report access is required to download it.');
    }
    try { $students_payload = admissionFormLoad($pdo, $student_ids, $admissionYear, $schoolInfo, $financial, $currency_symbol ?? ''); }
    catch (InvalidArgumentException $error) { http_response_code(422); exit(htmlspecialchars($error->getMessage(), ENT_QUOTES, 'UTF-8')); }
} elseif ($is_admit_card) {
    try { $students_payload = admitCardBuilderLoad($pdo, $admitRequest, $schoolInfo); }
    catch (InvalidArgumentException $error) { http_response_code(422); exit(htmlspecialchars($error->getMessage(), ENT_QUOTES, 'UTF-8')); }
} elseif ($is_teacher_id_card) {
    $columns = implode(', ', teacherIdCardColumns());
    $placeholders = implode(',', array_fill(0, count($teacher_ids), '?'));
    // Pending/rejected public applications are not school staff.
    $stmt = $pdo->prepare("SELECT $columns FROM teachers WHERE id IN ($placeholders) AND status IN ('active', 'inactive')");
    $stmt->execute($teacher_ids);
    $teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (!$teachers) { http_response_code(404); exit('No selected teachers found.'); }
    $byId = array_column($teachers, null, 'id');
    $students_payload = [];
    foreach ($teacher_ids as $teacher_id) {
        if (isset($byId[$teacher_id])) $students_payload[] = teacherIdCardPayload($byId[$teacher_id], $schoolInfo, BASE_URL);
    }
} elseif ($is_driver_id_card) {
    $columns = implode(', ', driverIdCardColumns());
    $placeholders = implode(',', array_fill(0, count($driver_ids), '?'));
    $stmt = $pdo->prepare("SELECT $columns FROM drivers WHERE id IN ($placeholders) AND status IN ('active', 'inactive')");
    $stmt->execute($driver_ids);
    $drivers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (!$drivers) { http_response_code(404); exit('No selected drivers found.'); }
    $assignedRouteIds = [];
    foreach ($drivers as $driver) foreach (driverIdCardRouteIds($driver) as $id) $assignedRouteIds[$id] = $id;
    $routes = [];
    if ($assignedRouteIds) {
        $routePlaceholders = implode(',', array_fill(0, count($assignedRouteIds), '?'));
        $stmt = $pdo->prepare("SELECT id, route_name FROM driving_routes WHERE id IN ($routePlaceholders)");
        $stmt->execute(array_values($assignedRouteIds));
        $routes = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'route_name', 'id');
    }
    $byId = array_column($drivers, null, 'id');
    $students_payload = [];
    foreach ($driver_ids as $driver_id) {
        if (isset($byId[$driver_id])) $students_payload[] = driverIdCardPayload($byId[$driver_id], $schoolInfo, BASE_URL, $routes);
    }
} else {
// 3. Fetch student data (same query style as the earlier download-student-id-card.php)
$placeholders = str_repeat('?,', count($student_ids) - 1) . '?';
$sql = "SELECT s.*, c.class_name, sec.section_name
        FROM {$academicSource} s
        LEFT JOIN classes c ON s.class_id = c.id
        LEFT JOIN sections sec ON s.section_id = sec.id
        WHERE s.student_id IN ($placeholders)";
$stmt = $pdo->prepare($sql);
$stmt->execute($student_ids);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$students) {
    die("No results found");
}

// 4. Send only what's needed for JS, per student (data minimization)
$school_logo_url = BASE_URL . '/uploads/school/logo-square.png?v=' . time();
$student_photo_base = BASE_URL . '/uploads/students/';

// Use the same School Info fields as the other card builders.
$school_card_data = idCardSchoolPayload($schoolInfo);

/** @var string $school_name */

// Safely formats a nullable date column. strtotime(null/'') resolves to
// "now" rather than failing, which would silently print today's date on
// the card — so empty/zero-date values are caught explicitly and turned
// into '' instead.
$format_date_val = function ($value) {
    if (empty($value) || $value === '0000-00-00' || $value === '0000-00-00 00:00:00') {
        return '';
    }
    return date('d M, Y', strtotime($value));
};

$students_payload = array_map(function ($s) use ($student_photo_base, $school_card_data, $format_date_val) {
    return [
        'student_name'     => $s['name'],
        'roll_no'          => $s['roll_no'],
        'class'            => $s['class_name'] . ' (' . $s['section_name'] . ')',
        'class_name'       => $s['class_name'] ?? '',
        'section'          => $s['section_name'] ?? '',
        'dob'              => $format_date_val($s['date_of_birth']),
        'student_id'       => $s['student_id'],
        'father_name'      => $s['father_name'],
        'student_contact'  => "+91 " . $s['phone_number'],
        'student_address'  => $s['address'],
        'student_photo_url'=> schoolPhotoCanvasUrl('students', $s['student_image']),
        ...$school_card_data,

        // ---- New student-level variables (Aug 2026) ----
        // All of these columns can be NULL/empty in the DB, so `?? ''`
        // ensures the ID card prints a blank instead of the literal
        // strings "NULL" or "null" that Fabric would otherwise render.
        'gender'           => $s['gender'] ?? '',
        'blood_group'      => $s['blood_group'] ?? '',
        'academic_year'    => $s['academic_year'] ?? '',
        'admission_date'   => $format_date_val($s['admission_date']),
        'registration_no'  => $s['registration_no'] ?? '',
        'aadhaar_no'       => $s['student_adhaar_no'] ?? '',
        // Alternative contact — only prefix "+91" when a number actually exists,
        // otherwise you'd get a card showing just "+91" with no digits.
        'alt_contact'      => !empty($s['alternate_phone_number']) ? '+91 ' . $s['alternate_phone_number'] : '',
        'village'          => $s['village'] ?? '',
        'post_office'      => $s['post_office'] ?? '',
        'police_station'   => $s['police_station'] ?? '',
        'district'         => $s['district'] ?? '',
        'pin_code'         => $s['pin_code'] ?? '',

        // Minimal data for the QR code — generated client-side via the QR library
        'qr_payload'       => json_encode([
            'student_id' => $s['student_id'],
            'class_id'   => $s['class_id'],
            'section_id' => $s['section_id']
        ])
    ];
}, $students);
}

if (!$is_teacher_id_card && !$is_driver_id_card && $students_payload) {
    // Transport assignments belong to the student profile across academic years.
    $transportStudentIds = array_column($students_payload, 'student_id');
    $transportPlaceholders = implode(',', array_fill(0, count($transportStudentIds), '?'));
    $stmt = $pdo->prepare("SELECT s.student_id, d.name AS transport_driver_name, r.route_name AS driving_route_name
        FROM students s
        LEFT JOIN drivers d ON d.id = s.driver_id
        LEFT JOIN driving_routes r ON r.id = s.driving_route_id
        WHERE s.student_id IN ($transportPlaceholders)");
    $stmt->execute($transportStudentIds);
    $transportByStudent = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), null, 'student_id');
    foreach ($students_payload as $index => $student) {
        $transport = $transportByStudent[$student['student_id']] ?? [];
        $students_payload[$index]['transport_driver_name'] = $transport['transport_driver_name'] ?? '';
        $students_payload[$index]['driving_route_name'] = $transport['driving_route_name'] ?? '';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Print <?= $card_document_label ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <!-- The same font catalog/loader as the editor, including table fonts. -->
    <script src="../../assets/js/student/id-card/id-card-fonts.js?v=<?= filemtime(__DIR__ . '/../../assets/js/student/id-card/id-card-fonts.js') ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.0/fabric.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcode/1.5.1/qrcode.min.js"></script>
    <style>
        /* @page margin must match PAGE_MARGIN_MM above — the grid below is
           sized against the usable area those margins leave. */
        @page { size: <?= $is_admission_form ? $card_w_mm . 'mm ' . $card_h_mm . 'mm' : 'A4 ' . $page_orientation ?>; margin: <?= PAGE_MARGIN_MM ?>mm; }
        body { margin: 0; font-family: sans-serif; }

        /* Page grid computed from the card's real size (see $grid_cols/$grid_rows).
           A "column" is one card normally, or one front+back pair in
           side-by-side mode. */
        .page {
            display: grid;
            grid-template-columns: repeat(<?= $grid_cols ?>, <?= $is_side_by_side ? $unit_w_mm : $card_w_mm ?>mm);
            grid-template-rows: repeat(<?= $grid_rows ?>, <?= $card_h_mm ?>mm);
            gap: <?= CARD_GAP_MM ?>mm;
            justify-content: center;
            align-content: start;
            page-break-after: always;
        }
        /* Without this the blanket rule above emits a trailing blank sheet —
           which in duplex mode means a wasted blank BACK sheet. */
        .page:last-child { page-break-after: auto; }
        @media print { .no-print { display: none !important; } }

        .page img { width: <?= $card_w_mm ?>mm; height: <?= $card_h_mm ?>mm; object-fit: cover; }

        /* side-by-side mode: one grid cell holding a card's two sides, with the
           same gap between them so there's a clean line to cut along. */
        .card-pair {
            display: grid;
            grid-template-columns: repeat(2, <?= $card_w_mm ?>mm);
            gap: <?= CARD_GAP_MM ?>mm;
        }

        /* Placeholder that keeps a grid position occupied on a partially-filled
           page, so the mirrored back sheet stays aligned with the front. */
        .empty-slot { width: <?= $card_w_mm ?>mm; height: <?= $card_h_mm ?>mm; }

        #loadingMsg { text-align: center; padding: 40px; font-size: 18px; }
        /* hidden canvases used only for rendering (one per card side) */
        #offscreenCanvasFront, #offscreenCanvasBack { display: none; }
    </style>
</head>
<body>
    <div id="loadingMsg">Preparing <?= $card_document_label ?>... Please wait.</div>
    <div id="printContainer"></div>
    <canvas id="offscreenCanvasFront"></canvas>
    <canvas id="offscreenCanvasBack"></canvas>

    <script>
        const TEMPLATE_DESIGN_JSON = <?= json_encode(json_decode($template['design_json'], true), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
        // Back side design — null when this card is single-sided.
        const TEMPLATE_BACK_DESIGN_JSON = <?= json_encode($has_back ? json_decode($template['back_design_json'], true) : null, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
        const HAS_BACK = <?= $has_back ? 'true' : 'false' ?>;
        const DOCUMENT_LABEL = <?= json_encode($card_document_label) ?>;
        const IS_ADMISSION_FORM = <?= $is_admission_form ? 'true' : 'false' ?>;
        const RENDER_MULTIPLIER = <?= ($is_admit_card || $is_admission_form) ? 1 : 2 ?>;
        const PRINT_ORIENTATION = <?= json_encode($page_orientation) ?>;
        // 'sequential' (fronts sheet then backs sheet) | 'side-by-side'
        const LAYOUT_MODE = <?= json_encode($layout_mode) ?>;
        const CANVAS_WIDTH = <?= $card_width_px ?>;
        const CANVAS_HEIGHT = <?= $card_height_px ?>;
        const SCHOOL_NAME = <?= json_encode($school_name, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
        const SCHOOL_LOGO_URL = <?= json_encode($school_logo_url, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
        const STUDENTS = <?= json_encode($students_payload, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
        // Page grid, computed server-side from the card's millimetre size.
        // GRID_COLS/GRID_ROWS are what the duplex row-mirroring works against.
        const GRID_COLS = <?= $grid_cols ?>;
        const GRID_ROWS = <?= $grid_rows ?>;
        const CARDS_PER_PAGE = <?= $cards_per_page ?>;
    </script>
    <script src="../../assets/js/student/id-card/id-card-table.js?v=<?= filemtime(__DIR__ . '/../../assets/js/student/id-card/id-card-table.js') ?>"></script>
    <script src="../../assets/js/student/id-card/id-card-shapes.js?v=<?= filemtime(__DIR__ . '/../../assets/js/student/id-card/id-card-shapes.js') ?>"></script>
    <script src="../../assets/js/student/id-card/render-id-cards-batch.js?v=<?= filemtime(__DIR__ . '/../../assets/js/student/id-card/render-id-cards-batch.js') ?>"></script>
</body>
</html>
