<?php
/**
 * print-id-cards.php
 * -----------------------------------------------------------------
 * Main page for batch printing.
 *
 * Strategy: server-side Fabric.js canvas rendering isn't possible in PHP
 * (Fabric depends on the browser canvas API). So the strategy is —
 *   1. PHP just prepares the raw data: (a) the saved design_json template(s),
 *      (b) an array of the selected students' data, (c) the page grid worked
 *      out from the card's real size.
 *   2. In the browser (client-side), render-id-cards-batch.js clones the
 *      template JSON for each student, replaces the variables/images, loads
 *      it into an offscreen Fabric canvas, and exports it to an image.
 *   3. All the card images are laid out on the computed A4 grid and
 *      window.print() is called (the same pattern used elsewhere in this
 *      system for wkhtmltoimage/browser printing — no extra Node/Puppeteer
 *      service needed).
 *
 * Cards are no longer a fixed 55x85mm single-sided format: the size comes from
 * the template (canvas_width/canvas_height in px at 10 px per mm) and the card
 * may have a back side, which is printed according to $layout_mode.
 */
include_once("../../includes/auth-check.php");

// Fixed scale shared with the builder: 10 canvas pixels = 1 millimetre.
// See PX_PER_MM in assets/js/student/id-card/id-card-builder.js.
const PX_PER_MM = 10;

// A4 portrait page geometry, in millimetres. PAGE_MARGIN_MM must match the
// `margin` in the @page rule below.
const PAGE_WIDTH_MM  = 210;
const PAGE_HEIGHT_MM = 297;
const PAGE_MARGIN_MM = 8;
const CARD_GAP_MM    = 4;

// 1. Selected student IDs
$student_ids = json_decode($_REQUEST['student_ids'] ?? '[ ]', true);
if (!is_array($student_ids) || empty($student_ids)) {
    die("Invalid student IDs");
}

// 1b. How to arrange the two sides of a double-sided card:
//   'sequential'    — fronts on one sheet, matching backs on the next (duplex)
//   'side-by-side'  — each card's front and back next to each other on one sheet
// Ignored entirely for single-sided cards.
$layout_mode = $_REQUEST['duplex_layout'] ?? 'sequential';
if (!in_array($layout_mode, ['sequential', 'side-by-side'], true)) {
    $layout_mode = 'sequential';
}

// 2. Load the active design template
$stmt = $pdo->query("SELECT * FROM student_id_card_templates WHERE is_active = 1 LIMIT 1");
$template = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$template) {
    die("No active ID card design found. Please save a design in the Builder first.");
}

// 2b. Card format: size in mm (derived from the stored pixel size) plus whether
// a back side should be printed.
$card_width_px  = max(1, (int)$template['canvas_width']);
$card_height_px = max(1, (int)$template['canvas_height']);
$card_w_mm = $card_width_px / PX_PER_MM;
$card_h_mm = $card_height_px / PX_PER_MM;

$has_back = !empty($template['has_back']) && !empty($template['back_design_json']);
if (!$has_back) {
    $layout_mode = 'sequential'; // nothing to arrange
}

// 2c. Work out how many cards fit on one A4 sheet. This replaces the previously
// hardcoded 3x3 grid, which only ever matched a 55x85mm card.
//
// For N columns of width u separated by gap g: N*u + (N-1)*g <= usable, i.e.
// N <= (usable + g) / (u + g).
//
// In 'side-by-side' mode a grid "column" holds a whole front+back pair, so the
// unit width is two cards plus the gap that separates them.
$usable_w_mm = PAGE_WIDTH_MM  - (2 * PAGE_MARGIN_MM);
$usable_h_mm = PAGE_HEIGHT_MM - (2 * PAGE_MARGIN_MM);

$is_side_by_side = ($has_back && $layout_mode === 'side-by-side');
$unit_w_mm = $is_side_by_side ? (2 * $card_w_mm + CARD_GAP_MM) : $card_w_mm;

$grid_cols = max(1, (int)floor(($usable_w_mm + CARD_GAP_MM) / ($unit_w_mm + CARD_GAP_MM)));
$grid_rows = max(1, (int)floor(($usable_h_mm + CARD_GAP_MM) / ($card_h_mm + CARD_GAP_MM)));
$cards_per_page = $grid_cols * $grid_rows;

// 3. Fetch student data (same query style as the earlier download-student-id-card.php)
$placeholders = str_repeat('?,', count($student_ids) - 1) . '?';
$sql = "SELECT s.*, c.class_name, sec.section_name
        FROM students s
        LEFT JOIN classes c ON s.class_id = c.id
        LEFT JOIN sections sec ON s.section_id = sec.id
        WHERE s.student_id IN ($placeholders)";
$stmt = $pdo->prepare($sql);
$stmt->execute($student_ids);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$students) {
    die("No results found");
}

// 4. Send only what's needed for JS, per student (data minimization)
$school_logo_url = BASE_URL . '/uploads/school/logo-square.png?v=' . time();
$student_photo_base = BASE_URL . '/uploads/students/';

// The school's own details (name/address/contact) — for the new
// {{school_name}}, {{school_address}}, {{school_contact_no}} variables added
// in the Builder. render-id-cards-batch.js looks these up from each student
// object (student[key]), so these constant values are placed inside every
// student payload.
// Assumes $school_address and $school_contact_no are already loaded from
// session/config, just like $school_name — falls back to an empty string
// if not.
$school_address_val    = $schoolInfo['address'] ?? '';
$school_contact_no_val = ($schoolInfo['phone'] ?? '') . ' / ' . ($schoolInfo['alternate_phone'] ?? '');

/** @var string $school_name */

// Safely formats a nullable date column. strtotime(null/'') resolves to
// "now" rather than failing, which would silently print today's date on
// the card — so empty/zero-date values are caught explicitly and turned
// into '' instead.
$format_date_val = function ($value) {
    if (empty($value) || $value === '0000-00-00' || $value === '0000-00-00 00:00:00') {
        return '';
    }
    return date('d M, Y', strtotime($value));
};

$students_payload = array_map(function ($s) use ($student_photo_base, $school_name, $school_address_val, $school_contact_no_val, $format_date_val) {
    return [
        'student_name'     => $s['name'],
        'roll_no'          => $s['roll_no'],
        'class'            => $s['class_name'] . ' (' . $s['section_name'] . ')',
        'dob'              => $format_date_val($s['date_of_birth']),
        'student_id'       => $s['student_id'],
        'father_name'      => $s['father_name'],
        'student_contact'  => "+91 " . $s['phone_number'],
        'student_address'  => $s['address'],
        'student_photo_url'=> $student_photo_base . $s['student_image'],
        // New: school-level variables (same value on every card)
        'school_name'         => $school_name,
        'school_address'      => $school_address_val,
        'school_contact_no'   => $school_contact_no_val,

        // ---- New student-level variables (Aug 2026) ----
        // All of these columns can be NULL/empty in the DB, so `?? ''`
        // ensures the ID card prints a blank instead of the literal
        // strings "NULL" or "null" that Fabric would otherwise render.
        'gender'           => $s['gender'] ?? '',
        'blood_group'      => $s['blood_group'] ?? '',
        'academic_year'    => $s['academic_year'] ?? '',
        'admission_date'   => $format_date_val($s['admission_date']),
        'registration_no'  => $s['registration_no'] ?? '',
        'aadhaar_no'       => $s['student_adhaar_no'] ?? '',
        // Alternative contact — only prefix "+91" when a number actually exists,
        // otherwise you'd get a card showing just "+91" with no digits.
        'alt_contact'      => !empty($s['alternate_phone_number']) ? '+91 ' . $s['alternate_phone_number'] : '',
        'village'          => $s['village'] ?? '',
        'post_office'      => $s['post_office'] ?? '',
        'police_station'   => $s['police_station'] ?? '',
        'district'         => $s['district'] ?? '',
        'pin_code'         => $s['pin_code'] ?? '',

        // Minimal data for the QR code — generated client-side via the QR library
        'qr_payload'       => json_encode([
            'student_id' => $s['student_id'],
            'class_id'   => $s['class_id'],
            'section_id' => $s['section_id']
        ])
    ];
}, $students);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Print ID Cards</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <!-- Same font set as the Builder (student-id-card-builder.php) — must match
         FONT_LIST in id-card-builder.js, including Roboto, or a card can be
         designed with a font that never loads here at print/export time. -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Open+Sans:wght@400;600;700&family=Lato:wght@400;700&family=Nunito:wght@400;700&family=Oswald:wght@400;600&family=Playfair+Display:wght@400;700&family=Merriweather:wght@400;700&family=Poppins:wght@400;600;700&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.0/fabric.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcode/1.5.1/qrcode.min.js"></script>
    <style>
        /* @page margin must match PAGE_MARGIN_MM above — the grid below is
           sized against the usable area those margins leave. */
        @page { size: A4; margin: <?= PAGE_MARGIN_MM ?>mm; }
        body { margin: 0; font-family: sans-serif; }

        /* Page grid computed from the card's real size (see $grid_cols/$grid_rows).
           A "column" is one card normally, or one front+back pair in
           side-by-side mode. */
        .page {
            display: grid;
            grid-template-columns: repeat(<?= $grid_cols ?>, <?= $is_side_by_side ? $unit_w_mm : $card_w_mm ?>mm);
            grid-template-rows: repeat(<?= $grid_rows ?>, <?= $card_h_mm ?>mm);
            gap: <?= CARD_GAP_MM ?>mm;
            justify-content: center;
            align-content: start;
            page-break-after: always;
        }
        /* Without this the blanket rule above emits a trailing blank sheet —
           which in duplex mode means a wasted blank BACK sheet. */
        .page:last-child { page-break-after: auto; }

        .page img { width: <?= $card_w_mm ?>mm; height: <?= $card_h_mm ?>mm; object-fit: cover; }

        /* side-by-side mode: one grid cell holding a card's two sides, with the
           same gap between them so there's a clean line to cut along. */
        .card-pair {
            display: grid;
            grid-template-columns: repeat(2, <?= $card_w_mm ?>mm);
            gap: <?= CARD_GAP_MM ?>mm;
        }

        /* Placeholder that keeps a grid position occupied on a partially-filled
           page, so the mirrored back sheet stays aligned with the front. */
        .empty-slot { width: <?= $card_w_mm ?>mm; height: <?= $card_h_mm ?>mm; }

        #loadingMsg { text-align: center; padding: 40px; font-size: 18px; }
        /* hidden canvases used only for rendering (one per card side) */
        #offscreenCanvasFront, #offscreenCanvasBack { display: none; }
    </style>
</head>
<body>
    <div id="loadingMsg">Preparing ID cards... Please wait.</div>
    <div id="printContainer"></div>
    <canvas id="offscreenCanvasFront"></canvas>
    <canvas id="offscreenCanvasBack"></canvas>

    <script>
        const TEMPLATE_DESIGN_JSON = <?= $template['design_json'] ?>;
        // Back side design — null when this card is single-sided.
        const TEMPLATE_BACK_DESIGN_JSON = <?= $has_back ? $template['back_design_json'] : 'null' ?>;
        const HAS_BACK = <?= $has_back ? 'true' : 'false' ?>;
        // 'sequential' (fronts sheet then backs sheet) | 'side-by-side'
        const LAYOUT_MODE = <?= json_encode($layout_mode) ?>;
        const CANVAS_WIDTH = <?= $card_width_px ?>;
        const CANVAS_HEIGHT = <?= $card_height_px ?>;
        const SCHOOL_NAME = <?= json_encode($school_name) ?>;
        const SCHOOL_LOGO_URL = <?= json_encode($school_logo_url) ?>;
        const STUDENTS = <?= json_encode($students_payload) ?>;
        // Page grid, computed server-side from the card's millimetre size.
        // GRID_COLS/GRID_ROWS are what the duplex row-mirroring works against.
        const GRID_COLS = <?= $grid_cols ?>;
        const GRID_ROWS = <?= $grid_rows ?>;
        const CARDS_PER_PAGE = <?= $cards_per_page ?>;
    </script>
    <script src="../../assets/js/student/id-card/render-id-cards-batch.js"></script>
</body>
</html>