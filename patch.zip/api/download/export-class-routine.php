<?php
/** @var string $school_name */
/** @var array  $schoolInfo */
include_once(__DIR__ . "/../../includes/auth-check.php");

if (!isset($_REQUEST['class_id']) || !isset($_REQUEST['section_id'])) {
    http_response_code(400);
    die('Invalid request: class_id and section_id are required.');
}

$class_id   = $_REQUEST['class_id'];
$section_id = $_REQUEST['section_id'];

// Get class name
$stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
$stmt->execute([$class_id]);
$class = $stmt->fetch();

if (!$class) {
    http_response_code(404);
    die('Class not found.');
}

// Get section name
$stmt = $pdo->prepare("SELECT section_name FROM sections WHERE id = ?");
$stmt->execute([$section_id]);
$section = $stmt->fetch();

if (!$section) {
    http_response_code(404);
    die('Section not found.');
}

// Get routine ordered by day and time
$stmt = $pdo->prepare("
    SELECT
        cr.day_name,
        cr.start_time,
        cr.end_time,
        cr.room_number,
        s.subject_name,
        t.name AS teacher_name
    FROM class_routines cr
    JOIN subjects s ON cr.subject_id = s.id
    LEFT JOIN teachers t ON cr.teacher_id = t.id
    WHERE cr.class_id = ? AND cr.section_id = ?
    ORDER BY
        FIELD(cr.day_name, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'),
        cr.start_time
");
$stmt->execute([$class_id, $section_id]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Group routine entries by day (same shape as get-class-routine.php)
$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
$groupedRoutine = array_fill_keys($days, []);

foreach ($rows as $item) {
    $groupedRoutine[$item['day_name']][] = [
        'start_time'   => date('h:i A', strtotime($item['start_time'])),
        'end_time'     => date('h:i A', strtotime($item['end_time'])),
        'subject_name' => $item['subject_name'],
        'teacher_name' => $item['teacher_name'] ?: '—',
        'room_number'  => $item['room_number']  ?: '—',
    ];
}

$totalSlots = count($rows);

$schoolInfo    = $schoolInfo ?? [];
$schoolName    = $school_name ?? ($schoolInfo['name'] ?? 'School');
$schoolPhone   = $schoolInfo['phone'] ?? '';
$schoolAltPh   = $schoolInfo['alternate_phone'] ?? '';
$logoUrl       = BASE_URL . "/uploads/school/logo-square.png?v=" . time();
$className     = $class['class_name'];
$sectionName   = $section['section_name'];

function h($str)
{
    return htmlspecialchars((string) ($str ?? ''), ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Class Routine - <?= h($className) ?> <?= h($sectionName) ?></title>
<style>
    :root {
        --brand-dark: #1e3a8a;
        --brand: #2563eb;
        --brand-light: #eff6ff;
        --ink: #1f2937;
        --muted: #6b7280;
        --border: #dbe3ef;
        --base-font: 10.5px;
    }
    @page {
        size: A4;
        margin: 10mm 10mm;
    }
    * { box-sizing: border-box; }
    html, body {
        margin: 0;
        padding: 0;
    }
    body {
        font-family: 'Segoe UI', 'Poppins', Arial, sans-serif;
        color: var(--ink);
        background: #f3f4f6;
    }
    .sheet {
        width: 100%;
        max-width: 190mm;
        margin: 0 auto;
        padding: 5mm 6mm;
        background: #fff;
        font-size: var(--base-font);
    }

    .toolbar {
        display: flex;
        justify-content: flex-end;
        gap: 8px;
        margin-bottom: 10px;
        font-size: 14px;
    }
    .toolbar button {
        padding: 8px 16px;
        border: none;
        border-radius: 6px;
        background: var(--brand);
        color: #fff;
        font-size: 14px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }
    .toolbar button:hover { background: var(--brand-dark); }

    /* ---------- Header ---------- */
    .header {
        border-bottom: 2.5px solid var(--brand);
        padding-bottom: 0.6em;
        margin-bottom: 0.8em;
    }
    .header-top {
        display: flex;
        align-items: center;
        gap: 0.8em;
    }
    .school-logo {
        width: 3.6em;
        height: 3.6em;
        object-fit: contain;
        border-radius: 0.5em;
        flex-shrink: 0;
        background: var(--brand-light);
        padding: 0.25em;
        border: 1px solid var(--border);
    }
    .school-meta {
        flex: 1;
        min-width: 0;
    }
    .school-meta h1 {
        margin: 0;
        font-size: 1.9em;
        font-weight: 700;
        color: var(--brand-dark);
        letter-spacing: 0.2px;
    }
    .contact-line {
        margin: 0.25em 0 0;
        font-size: 1.05em;
        color: var(--muted);
        display: flex;
        gap: 1.1em;
        flex-wrap: wrap;
    }
    .contact-line span {
        display: inline-flex;
        align-items: center;
        gap: 0.35em;
        white-space: nowrap;
    }
    .routine-title {
        display: flex;
        justify-content: space-between;
        align-items: baseline;
        margin-top: 0.6em;
    }
    .routine-title h2 {
        margin: 0;
        font-size: 1.35em;
        font-weight: 600;
        color: var(--ink);
    }
    .routine-title .badge-pill {
        background: var(--brand);
        color: #fff;
        font-size: 0.95em;
        font-weight: 600;
        padding: 0.3em 0.9em;
        border-radius: 999px;
        white-space: nowrap;
    }

    /* ---------- Table ---------- */
    table {
        width: 100%;
        border-collapse: collapse;
        font-size: 1em;
        table-layout: fixed;
    }
    th, td {
        border: 1px solid var(--border);
        padding: 0.55em 0.7em;
        text-align: left;
        vertical-align: middle;
        word-wrap: break-word;
    }
    thead th {
        background: var(--brand-dark);
        color: #fff;
        text-align: center;
        font-size: 0.92em;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }
    tbody tr:nth-child(even) td:not(.day-cell) {
        background: #f8fafc;
    }
    td.day-cell {
        font-weight: 700;
        text-align: center;
        background: var(--brand-light);
        color: var(--brand-dark);
        white-space: nowrap;
    }
    td.time-cell {
        text-align: center;
        white-space: nowrap;
        font-weight: 600;
        color: var(--brand-dark);
    }
    td.subject-cell {
        font-weight: 600;
    }
    td.empty-day {
        text-align: center;
        font-style: italic;
        color: #9ca3af;
        background: #fff;
    }

    .footer-note {
        margin-top: 1em;
        padding-top: 0.5em;
        border-top: 1px solid var(--border);
        font-size: 0.85em;
        color: var(--muted);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    @media print {
        body { background: #fff; }
        .toolbar { display: none; }
        .sheet { padding: 0; max-width: none; margin: 0; }
        table { page-break-inside: auto; }
        tr { page-break-inside: avoid; page-break-after: auto; }
    }
</style>
</head>
<body>
    <div class="sheet" id="routineSheet">
        <div class="toolbar">
            <button type="button" onclick="window.print()">🖨️ Print</button>
        </div>

        <div class="header">
            <div class="header-top">
                <img src="<?= h($logoUrl) ?>" alt="Logo" class="school-logo" onerror="this.style.display='none'">
                <div class="school-meta">
                    <h1><?= h($schoolName) ?></h1>
                    <?php if ($schoolPhone || $schoolAltPh): ?>
                    <p class="contact-line">
                        <?php if ($schoolPhone): ?><span>📞 <?= h($schoolPhone) ?></span><?php endif; ?>
                        <?php if ($schoolAltPh): ?><span>📱 <?= h($schoolAltPh) ?></span><?php endif; ?>
                    </p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="routine-title">
                <h2>Class Routine &mdash; <?= h($className) ?> (<?= h($sectionName) ?>)</h2>
                <span class="badge-pill"><?= (int) $totalSlots ?> Classes / Week</span>
            </div>
        </div>

        <table>
            <thead>
                <tr>
                    <th style="width:12%;">Day</th>
                    <th style="width:18%;">Time</th>
                    <th style="width:32%;">Subject</th>
                    <th style="width:26%;">Teacher</th>
                    <th style="width:12%;">Room</th>
                </tr>
            </thead>
            <tbody>
<?php foreach ($days as $day):
    $slots = $groupedRoutine[$day];
    if (empty($slots)): ?>
                <tr>
                    <td class="day-cell"><?= h($day) ?></td>
                    <td class="empty-day" colspan="4">No classes scheduled</td>
                </tr>
<?php else:
    foreach ($slots as $i => $slot): ?>
                <tr>
<?php if ($i === 0): ?>
                    <td class="day-cell" rowspan="<?= count($slots) ?>"><?= h($day) ?></td>
<?php endif; ?>
                    <td class="time-cell"><?= h($slot['start_time']) ?> &ndash; <?= h($slot['end_time']) ?></td>
                    <td class="subject-cell"><?= h($slot['subject_name']) ?></td>
                    <td><?= h($slot['teacher_name']) ?></td>
                    <td><?= h($slot['room_number']) ?></td>
                </tr>
<?php endforeach;
    endif;
endforeach; ?>
            </tbody>
        </table>

        <div class="footer-note">
            <span>School Songi &mdash; Class Routine</span>
            <span><?= h($schoolName) ?></span>
        </div>
    </div>

<script>
(function () {
    // Auto-shrink the routine so it always fits on a single A4 page,
    // regardless of how many periods/days are filled in.
    var sheet = document.getElementById('routineSheet');
    if (!sheet) return;

    var PX_PER_MM   = 96 / 25.4;
    var PAGE_H_MM   = 297;   // A4 height
    var PAGE_MARGIN_MM = 20; // matches @page margin (10mm top + 10mm bottom)
    var MAX_HEIGHT_PX  = (PAGE_H_MM - PAGE_MARGIN_MM) * PX_PER_MM;

    var MAX_FONT = 10.5; // px, normal density
    var MIN_FONT = 6.5;  // px, floor for very dense routines
    var STEP     = 0.25;

    function fitToPage() {
        var fontSize = MAX_FONT;
        sheet.style.setProperty('--base-font', fontSize + 'px');

        var guard = 0;
        while (sheet.scrollHeight > MAX_HEIGHT_PX && fontSize > MIN_FONT && guard < 60) {
            fontSize -= STEP;
            sheet.style.setProperty('--base-font', fontSize + 'px');
            guard++;
        }
    }

    if (document.readyState === 'complete') {
        fitToPage();
    } else {
        window.addEventListener('load', fitToPage);
    }
    window.addEventListener('beforeprint', fitToPage);
    window.addEventListener('resize', fitToPage);
})();
</script>
</body>
</html>