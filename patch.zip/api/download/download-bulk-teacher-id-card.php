<?php
// Check if user is logged in
include_once("../../includes/auth-check.php"); // auth checking + config.php included
include_once("../../includes/permission-check.php");
require_once('../../vendor/autoload.php');

// check admin permission
if (!hasPermission(PERM_MANAGE_TEACHERS)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to download id cards.'
    ]);
    exit;
}

// Check if student IDs are provided
if (!isset($_GET['ids']) || empty($_GET['ids'])) {
    die("Teacher IDs are required (comma-separated)");
}

$teacher_ids = explode(',', $_GET['ids']);

// Create new PDF document with PORTRAIT orientation ('P')
$pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);

// Document information
$pdf->SetCreator($schoolInfo['name']);
$pdf->SetAuthor($schoolInfo['name']);
$pdf->SetTitle('Bulk Teacher ID Cards');
$pdf->SetSubject('Student ID Cards');

// Disable header/footer
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

$pdf->SetAutoPageBreak(true, 5);

// Pre-load custom fonts
$funky_bird = TCPDF_FONTS::addTTFfont('../../assets/fonts/FunkyBird.ttf', 'TrueTypeUnicode', '', 96);
$heavitas = TCPDF_FONTS::addTTFfont('../../assets/fonts/Heavitas.ttf', 'TrueTypeUnicode', '', 96);
$one_slice = TCPDF_FONTS::addTTFfont('../../assets/fonts/OneSlice.otf', 'TrueTypeUnicode', '', 96);

// ID card dimensions
$id_width = 54;  // mm
$id_height = 86; // mm

// Calculate positions for ID cards (3x3 grid)
$positions = [];
$horizontal_spacing = 10;
$vertical_spacing = 10;

for ($row = 0; $row < 3; $row++) {
    for ($col = 0; $col < 3; $col++) {
        $x = 10 + ($col * ($id_width + $horizontal_spacing));
        $y = 10 + ($row * ($id_height + $vertical_spacing));
        $positions[] = [$x, $y];
    }
}

$current_position = 0;

foreach ($teacher_ids as $teacher_id) {
    if ($current_position === 0) {
        $pdf->AddPage('P');
    }

    // Fetch teacher details
    $stmt = $pdo->prepare("SELECT * FROM teachers WHERE id = ?");
    $stmt->execute([trim($teacher_id)]);
    $teacher = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$teacher) {
        continue;
    }

    // Get current position coordinates
    $x = $positions[$current_position][0];
    $y = $positions[$current_position][1];

    // --- Start of a single ID Card ---

    // Set background image
    $bg_path = '../../assets/img/id-bg/1.jpg';
    if ($websiteConfig['id_card_style']) {
        $bg_path = '../../assets/img/id-bg/' . $websiteConfig['id_card_style'];
    }
    if (file_exists($bg_path)) {
        $pdf->Image($bg_path, $x, $y, $id_width, $id_height, 'JPG', '', '', false, 300, '', false, false, 0);
    }

    // School Name
    $padding = 2;
    $pdf->SetXY($x + $padding, $y + 3); // Move start position right by padding
    $pdf->SetFont($heavitas, 'B', 12);
    $pdf->SetTextColor(255, 255, 255);
    $pdf->MultiCell($id_width - ($padding * 2), 3, strtoupper($schoolInfo['name']), 0, 'C', false);

    $pdf->Ln(1);
    // School Address
    $padding = 3;
    $line_height = 3;
    $max_lines = 2;
    $max_height = $line_height * $max_lines; // 6mm total height for 2 lines

    $pdf->SetX($x + $padding);
    $pdf->SetFont('helvetica', '', 6);
    $pdf->SetTextColor(255, 255, 255);
    $pdf->MultiCell($id_width - ($padding * 2), $line_height, $schoolInfo['address'], 0, 'C', false, 1, null, null, true, 0, false, true, $max_height, 'M');

    // Define positions relative to the card's top-left corner ($x, $y)
    $photo_base_x = $x + 19.55;
    $photo_base_y = $y + 21;
    $photo_width = 15;
    $photo_height = 18;
    $logo_size = 11;
    $logo_left_x = $photo_base_x - $logo_size - 7;
    $logo_right_x = $photo_base_x + $photo_width + 5;
    $logo_y = $photo_base_y + ($photo_height / 9) - ($logo_size / 9);

    // QR Code (Left)
    $qr_data = (string)$teacher['id'];
    $style = ['border' => 0, 'vpadding' => '1', 'hpadding' => '1', 'fgcolor' => [0, 0, 0], 'bgcolor' => [255, 255, 255], 'module_width' => 1, 'module_height' => 1];
    $pdf->write2DBarcode($qr_data, 'QRCODE,L', $logo_left_x + 2, $logo_y + 1, $logo_size, $logo_size, $style, 'N');

    // School Logo (Right)
    $logo_path = '../../uploads/school/logo-square.png';
    if (file_exists($logo_path)) {
        $pdf->StartTransform();
        $pdf->RoundedRect($logo_right_x, $logo_y, $logo_size, $logo_size, $logo_size / 2, '1111', 'CNZ');
        $pdf->Image($logo_path, $logo_right_x, $logo_y, $logo_size, $logo_size, 'PNG', '', '', true, 300, '', false, false, 0);
        $pdf->StopTransform();
    }

    // Teacher Photo
    $photo_path = "../../uploads/teachers/" . $teacher['teacher_image'];
    if (!empty($teacher['teacher_image']) && file_exists($photo_path)) {
        $pdf->StartTransform();
        $pdf->RoundedRect($photo_base_x, $photo_base_y, $photo_width, $photo_height, 2, '1111', 'CNZ');
        $pdf->Image($photo_path, $photo_base_x, $photo_base_y, $photo_width, $photo_height, strtolower(pathinfo($photo_path, PATHINFO_EXTENSION)), '', '', true, 300, '', false, false, 0);
        $pdf->StopTransform();
    } else {
        $pdf->SetXY($photo_base_x, $photo_base_y);
        $pdf->SetFont('helvetica', '', 6);
        $pdf->SetTextColor(150, 150, 150);
        $pdf->Cell($photo_width, $photo_height, 'No Photo', 0, 0, 'C');
    }

    $padding = 2;
    $pdf->SetXY($x + $padding, $y + 43); // Move start position right by padding
    $pdf->SetFont($heavitas, '', 8);
    $pdf->SetTextColor(0, 36, 220);
    $pdf->MultiCell($id_width - ($padding * 2), 3, strtoupper($teacher['name']), 0, 'C', false);

    // Teacher Details
    $formatted_date = (new DateTime($teacher['joining_date']))->format('F jS, Y');

    $table_x = $x + 5;
    $table_y = $y + 51;
    $table_width = $id_width - 10;

    // FIXED: Adjust column widths to give more space to left column
    $col1_width = $table_width * 0.45; // Increased from 0.4 to 0.45
    $col2_width = $table_width * 0.55; // Decreased from 0.6 to 0.55

    $pdf->SetFont('helvetica', '', 6);
    $pdf->SetTextColor(10, 10, 10);
    $pdf->SetDrawColor(0, 0, 0);
    $pdf->SetLineWidth(0.05);

    // FIXED: Shorter labels and increased row heights
    $table_data = [
        ['ID:', $teacher['teacher_id'], 5], // Increased height from 4 to 5
        ['Working Since:', $formatted_date, 5],     // Shortened "Working Since:" to "Since:"
        ['Contact:', $teacher['phone'], 5],
        ['School:', $schoolInfo['phone'], 5] // Shortened "School Contact:" to "School:"
    ];

    $current_y = $table_y;

    foreach ($table_data as $row) {
        $row_height = $row[2];

        // Draw border rectangles first
        $pdf->Rect($table_x, $current_y, $col1_width, $row_height, 'D');
        $pdf->Rect($table_x + $col1_width, $current_y, $col2_width, $row_height, 'D');

        // FIXED: Better text positioning with proper padding and font weight
        // Left cell text - make it bold for better visibility
        $pdf->SetXY($table_x + 0.5, $current_y + 0.5); // Reduced padding for more space
        $pdf->SetFont('helvetica', '', 6); // Bold font for labels
        $pdf->MultiCell($col1_width - 1, $row_height - 1, $row[0], 0, 'L', false, 0, null, null, true, 0, false, true, $row_height - 1, 'M');

        // Right cell text - regular font
        $pdf->SetFont('helvetica', '', 6); // Regular font for values
        $pdf->SetXY($table_x + $col1_width + 0.5, $current_y + 0.5);
        $pdf->MultiCell($col2_width - 1, $row_height - 1, $row[1], 0, 'L', false, 1, null, null, true, 0, false, true, $row_height - 1, 'M');

        $current_y += $row_height;
    }

    // Address Footer
    $teacher_address = '<div style="text-align: center;">' . $teacher['address'] . '</div>';
    $pdf->SetFont('helvetica', '', 5);
    $pdf->SetTextColor(255, 255, 255);
    $pdf->writeHTMLCell($id_width - 10, 0, $x + 5, $y + $id_height - 7, $teacher_address, 0, 1, 0, true, 'C', true);

    // --- End of a single ID Card ---

    // Move to the next position on the page
    $current_position = ($current_position + 1) % 9;
}

// Output PDF
$pdf->Output('Bulk-Teacher-ID-Cards.pdf', 'I');
