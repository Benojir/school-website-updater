<?php
/** 
 * @var PDO $pdo 
 * @var array $schoolInfo
 * @var string $currency_symbol
 * */
include_once(__DIR__ . "/../../../includes/auth-check.php");

$payment_ids = $_REQUEST['ids'] ?? '';

if (empty($payment_ids)) {
    die("Payment ID(s) are required");
}

$payment_ids = explode(',', $payment_ids);

if (!is_array($payment_ids)) {
    die("Invalid payment ID(s) provided");
}

if (count($payment_ids) <= 0) {
    die("No payment ID(s) provided");
}

$school_name = $schoolInfo['name'];
$school_contact = "Phone: " . $schoolInfo['phone'] . " | " . $schoolInfo['alternate_phone'];
$principal_name = $schoolInfo['principal_name'];
$principal_sign = BASE_URL . '/uploads/school/principle_sign.png?v=' . time();
$school_logo = BASE_URL . '/uploads/school/logo-square.png?v=' . time();

$main = file_get_contents(__DIR__ . "/../../../assets/templates/payment-receipts/monthly/design-1/main.html");
$css = BASE_URL . '/assets/templates/payment-receipts/monthly/design-1/styles.css';
$content = file_get_contents(__DIR__ . "/../../../assets/templates/payment-receipts/monthly/design-1/content.html");

// Static placeholders replacements
$main = str_replace('style.css', $css, $main);
$content = str_replace('{school_logo}', $school_logo, $content);
$content = str_replace('{school_name}', $school_name, $content);
$content = str_replace('{school_contact}', $school_contact, $content);
$content = str_replace('{principal_name}', $principal_name, $content);
$content = str_replace('{principal_sign}', $principal_sign, $content);

$skipped_count = 0;

$all_receipts_html = '';

foreach($payment_ids as $payment_id) {
    if (!isIntegerLike($payment_id)) {
        $skipped_count++;
        continue;
    }

    // Fetch payment data
    $stmt = $pdo->prepare("SELECT * FROM student_payment_history WHERE id = :id");
    $stmt->execute(['id' => $payment_id]);
    $payment = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$payment) {
        $skipped_count++;
        continue;
    }

    $receipt_html = $content;

    $student_id = $payment['student_id'];
    $payment_amount = $payment['payment_amount'];
    $payment_date = $payment['payment_date'];
    $full_paid_payment_ids = $payment['full_paid_payment_ids'];
    $partial_payment_ids = $payment['partial_payment_ids_backup'];
    $wallet_credited_amount = $payment['wallet_affected_balance'];
    $method = $payment['method'];
    $collector_id = $payment['entry_by'];

    $student = getStudentInfo($pdo, $student_id);
    $collector_name = getAdminNameById($collector_id);

    $payment_amount = round($payment_amount, 2);
    $wallet_credited_amount = round($wallet_credited_amount, 2);

    if (json_validate($partial_payment_ids)) {
        $partial_payment_ids = json_decode($partial_payment_ids, true);
    } else {
        $partial_payment_ids = [];
    }

    $last_partial_month_name = "";
    $last_partial_payment_amount = 0;

    if (!empty($partial_payment_ids)) {
        $stmt = $pdo->prepare("SELECT * FROM student_partial_payments WHERE id = ?");
        $stmt->execute([$partial_payment_ids[count($partial_payment_ids) - 1]]);
        $last_partial_payment = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($last_partial_payment) {
            if (empty($last_partial_payment['full_paid_fees_id'])) {
                $last_partial_month_name = $last_partial_payment['month_year'];
                $last_partial_payment_amount = $last_partial_payment['partial_paid_amount'];
            }
        }
    }

    $average_full_paid_amount = 0;

    if (!json_validate($full_paid_payment_ids)) {
        die("Invalid full paid payment ids");
    } else {
        $full_paid_payment_ids = json_decode($full_paid_payment_ids, true);
    }

    $first_full_paid_month_name = "";
    $last_full_paid_month_name = "";

    if (!empty($full_paid_payment_ids)) {
        $first_id = $full_paid_payment_ids[0];
        $last_id = $full_paid_payment_ids[count($full_paid_payment_ids) - 1];

        $stmt = $pdo->prepare("SELECT month_year FROM student_full_paid_fees WHERE id = ?");
        $stmt->execute([$first_id]);
        $first_full_paid_month_name = $stmt->fetchColumn();

        if ($last_id !== $first_id) {
            $stmt = $pdo->prepare("SELECT month_year FROM student_full_paid_fees WHERE id = ?");
            $stmt->execute([$last_id]);
            $last_full_paid_month_name = $stmt->fetchColumn();
        }

        $average_full_paid_amount = ($payment_amount - $last_partial_payment_amount - $wallet_credited_amount) / count($full_paid_payment_ids);
    }

    $average_full_paid_amount = round($average_full_paid_amount, 2);
    $last_partial_payment_amount = round($last_partial_payment_amount, 2);

    $trows = "";

    if ($first_full_paid_month_name !== "" && $last_full_paid_month_name !== "") {
        $td1 = "<td><b>" . $first_full_paid_month_name . "</b><br>to<br><b>" . $last_full_paid_month_name . "</b></td>";
        $td2 = '<td class="text-center status-paid">Paid</td>';
        $td3 = '<td class="text-right">' . $average_full_paid_amount . ' x ' . count($full_paid_payment_ids) . ' = ₹' . $average_full_paid_amount * count($full_paid_payment_ids) . '/-</td>';
        $trows .= "<tr>" . $td1 . $td2 . $td3 . "</tr>";
    } else if ($first_full_paid_month_name !== "" && $last_full_paid_month_name === "") {
        $td1 = "<td><b>" . $first_full_paid_month_name . "</b></td>";
        $td2 = '<td class="text-center status-paid">Paid</td>';
        $td3 = '<td class="text-right">₹' . $average_full_paid_amount . ' x ' . count($full_paid_payment_ids) . ' = ₹' . $average_full_paid_amount * count($full_paid_payment_ids) . '/-</td>';
        $trows .= "<tr>" . $td1 . $td2 . $td3 . "</tr>";
    }

    if ($last_partial_month_name !== "" && $last_partial_month_name !== $last_full_paid_month_name) {
        $td1 = "<td><b>" . $last_partial_month_name . "</b></td>";
        $td2 = '<td class="text-center status-adv">Partial</td>';
        $td3 = '<td class="text-right">₹' . $last_partial_payment_amount . '/-</td>';
        $trows .= "<tr>" . $td1 . $td2 . $td3 . "</tr>";
    }

    if ($wallet_credited_amount > 0) {
        $td1 = "<td>Wallet Credit</td>";
        $td2 = '<td class="text-center status-paid">Credit</td>';
        $td3 = '<td class="text-right">₹' . $wallet_credited_amount . '/-</td>';
        $trows .= "<tr>" . $td1 . $td2 . $td3 . "</tr>";
    }

    $student_name = $student['name'];
    $student_class = $student['class_name'];
    $student_section = $student['section_name']; 
    $student_roll_no = $student['roll_no'];
    $student_image = BASE_URL . '/uploads/students/' . $student['student_image'];

    $receipt_data = [
        "{receipt_no}" =>$payment_id,
        "{student_name}" => $student_name,
        "{class_name}" => $student_class,
        "{section_name}" => $student_section,
        "{roll_no}" => $student_roll_no,
        "{student_image}" => $student_image,
        "{tbody_rows}" => $trows,
        "{total_payment_amount}" => "₹" . number_format($payment_amount) . "/-",
        "{paid_amount_in_words}" => ucfirst(convertNumberToWords((float) $payment_amount)) . " only",
        "{payment_date}" => date('d-m-Y', strtotime($payment_date)),
        "{collector_name}" => $collector_name ?? "N/A",
    ];

    $receipt_html = str_replace(array_keys($receipt_data), array_values($receipt_data), $receipt_html);
    $all_receipts_html .= $receipt_html;
}

$main = str_replace("{receipts}", $all_receipts_html, $main);

echo $main;