<?php
/** 
 * @var PDO $pdo 
 * @var array $schoolInfo
 * @var string $currency_symbol
 * */
include_once(__DIR__ . "/../../../includes/auth-check.php");

$payment_ids = $_REQUEST['ids'] ?? '';

if (empty($payment_ids)) {
    die("Payment ID(s) are required");
}

$payment_ids = explode(',', $payment_ids);

if (!is_array($payment_ids)) {
    die("Invalid payment ID(s) provided");
}

if (count($payment_ids) <= 0) {
    die("No payment ID(s) provided");
}

$school_name = $schoolInfo['name'];
$school_contact = "Phone: " . $schoolInfo['phone'] . " | " . $schoolInfo['alternate_phone'];
$principal_name = $schoolInfo['principal_name'];
$principal_sign = BASE_URL . '/uploads/school/principle_sign.png?v=' . time();
$school_logo = BASE_URL . '/uploads/school/logo-square.png?v=' . time();

$main = file_get_contents(__DIR__ . "/../../../assets/templates/payment-receipts/monthly/design-1/main.html");
$css = BASE_URL . '/assets/templates/payment-receipts/monthly/design-1/styles.css';
$content = file_get_contents(__DIR__ . "/../../../assets/templates/payment-receipts/monthly/design-1/content.html");

// Static placeholders replacements
$main = str_replace('style.css', $css, $main);
$content = str_replace('{school_logo}', $school_logo, $content);
$content = str_replace('{school_name}', $school_name, $content);
$content = str_replace('{school_contact}', $school_contact, $content);
$content = str_replace('{principal_name}', $principal_name, $content);
$content = str_replace('{principal_sign}', $principal_sign, $content);

$skipped_count = 0;

$all_receipts_html = '';
$monthly_due_summaries = [];
$format_receipt_months = static function(array $months, bool $unknown_month = false): string {
    ksort($months, SORT_NUMERIC);
    $indices = array_keys($months);
    $ranges = [];
    for ($i = 0; $i < count($indices); $i++) {
        $first = $last = $indices[$i];
        while (isset($indices[$i + 1]) && $indices[$i + 1] === $last + 1) $last = $indices[++$i];
        $ranges[] = $months[$first]->format('F Y') . ($first === $last ? '' : ' to ' . $months[$last]->format('F Y'));
    }
    // Sparse dues can have many separate ranges. Group abbreviated month names
    // by year to keep the exact months readable on a small receipt.
    if (count($ranges) > 2) {
        $by_year = [];
        foreach ($months as $month) $by_year[$month->format('Y')][] = $month->format('M');
        $ranges = [];
        foreach ($by_year as $year => $names) $ranges[] = implode(', ', $names) . ' ' . $year;
    }
    if ($unknown_month) $ranges[] = 'Other month(s)';
    return $ranges ? implode('; ', $ranges) : 'No unpaid months';
};
$summarize_monthly_dues = static function(array $fees) use ($format_receipt_months): array {
    $total_cents = 0;
    $months = [];
    $unknown_month = false;
    foreach ($fees as $fee) {
        $total_cents += (int)round((float)$fee['unpaid_amount'] * 100);
        $label = preg_replace('/\s+/', ' ', trim((string)($fee['month_year'] ?? '')));
        $month = DateTimeImmutable::createFromFormat('!F Y', $label);
        if (!$month || (strcasecmp($label, $month->format('F Y')) !== 0 && strcasecmp($label, $month->format('M Y')) !== 0)) {
            $unknown_month = true;
            continue;
        }
        $months[(int)$month->format('Y') * 12 + (int)$month->format('n') - 1] = $month;
    }
    return ['total' => $total_cents / 100, 'months' => $format_receipt_months($months, $unknown_month)];
};
$decode_receipt_ids = static function(mixed $encoded): array {
    $ids = is_string($encoded) ? json_decode($encoded, true) : null;
    if (!is_array($ids) || !array_is_list($ids)) return [];
    $ids = array_filter($ids, static fn($id) => (is_int($id) || is_string($id))
        && filter_var($id, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) !== false);
    return array_values(array_unique(array_map('strval', $ids)));
};

foreach($payment_ids as $payment_id) {
    if (!isIntegerLike($payment_id)) {
        $skipped_count++;
        continue;
    }

    // Fetch payment data
    $stmt = $pdo->prepare("SELECT * FROM student_payment_history WHERE id = :id");
    $stmt->execute(['id' => $payment_id]);
    $payment = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$payment) {
        $skipped_count++;
        continue;
    }

    $receipt_html = $content;

    $student_id = $payment['student_id'];
    // The current balance includes every outstanding month, not just the month
    // partially paid on this receipt. Reprints intentionally show today's dues.
    if (!array_key_exists($student_id, $monthly_due_summaries)) {
        $due_stmt = $pdo->prepare('SELECT month_year, unpaid_amount FROM student_unpaid_fees WHERE student_id = ? AND unpaid_amount > 0');
        $due_stmt->execute([$student_id]);
        $monthly_due_summaries[$student_id] = $summarize_monthly_dues($due_stmt->fetchAll(PDO::FETCH_ASSOC));
    }
    $current_monthly_due = $monthly_due_summaries[$student_id]['total'];
    $payment_amount = $payment['payment_amount'];
    $payment_date = $payment['payment_date'];
    $full_paid_payment_ids = $decode_receipt_ids($payment['full_paid_payment_ids'] ?? null);
    $partial_payment_ids = $decode_receipt_ids($payment['partial_payment_ids_backup'] ?? null);
    $wallet_credited_amount = $payment['wallet_affected_balance'];
    $method = $payment['method'];
    if ($method === 'wallet') $wallet_credited_amount = 0;
    $collector_id = $payment['entry_by'];

    $student = getStudentInfo($pdo, $student_id);
    $collector_name = getAdminNameById($collector_id);

    $payment_amount = round($payment_amount, 2);
    $wallet_credited_amount = round($wallet_credited_amount, 2);

    $last_partial_month_name = "";
    $last_partial_payment_amount = 0;
    $partial_details_available = true;

    if (!empty($partial_payment_ids)) {
        $stmt = $pdo->prepare("SELECT * FROM student_partial_payments WHERE id = ? AND student_id = ?");
        $stmt->execute([$partial_payment_ids[count($partial_payment_ids) - 1], $student_id]);
        $last_partial_payment = $stmt->fetch(PDO::FETCH_ASSOC);
        $partial_details_available = (bool)$last_partial_payment;

        if ($last_partial_payment) {
            // Later payments backfill this FK on older partial rows. Only the
            // full-paid IDs saved with THIS history record establish completion.
            if (!in_array((string)($last_partial_payment['full_paid_fees_id'] ?? ''), $full_paid_payment_ids, true)) {
                $last_partial_month_name = $last_partial_payment['month_year'];
                $last_partial_payment_amount = $last_partial_payment['partial_paid_amount'];
            }
        }
    }

    $average_full_paid_amount = 0;

    $first_full_paid_month_name = "";
    $last_full_paid_month_name = "";
    $full_months_available = true;

    if (!empty($full_paid_payment_ids)) {
        $first_id = $full_paid_payment_ids[0];
        $last_id = $full_paid_payment_ids[count($full_paid_payment_ids) - 1];

        $stmt = $pdo->prepare("SELECT month_year FROM student_full_paid_fees WHERE id = ? AND student_id = ?");
        $stmt->execute([$first_id, $student_id]);
        $first_full_paid_month_name = (string)($stmt->fetchColumn() ?: '');

        if ($last_id !== $first_id) {
            $stmt = $pdo->prepare("SELECT month_year FROM student_full_paid_fees WHERE id = ? AND student_id = ?");
            $stmt->execute([$last_id, $student_id]);
            $last_full_paid_month_name = (string)($stmt->fetchColumn() ?: '');
        }
        $full_months_available = $first_full_paid_month_name !== '' && ($first_id === $last_id || $last_full_paid_month_name !== '');

        $average_full_paid_amount = ($payment_amount - $last_partial_payment_amount - $wallet_credited_amount) / count($full_paid_payment_ids);
    }

    $average_full_paid_amount = round($average_full_paid_amount, 2);
    $last_partial_payment_amount = round($last_partial_payment_amount, 2);

    $trows = "";

    if ($first_full_paid_month_name !== "" && $last_full_paid_month_name !== "") {
        $td1 = "<td><b>" . htmlspecialchars($first_full_paid_month_name, ENT_QUOTES, 'UTF-8') . "</b><br>to<br><b>" . htmlspecialchars($last_full_paid_month_name, ENT_QUOTES, 'UTF-8') . "</b></td>";
        $td2 = '<td class="text-center status-paid">Paid</td>';
        $td3 = '<td class="text-right">' . $average_full_paid_amount . ' x ' . count($full_paid_payment_ids) . ' = ₹' . $average_full_paid_amount * count($full_paid_payment_ids) . '/-</td>';
        $trows .= "<tr>" . $td1 . $td2 . $td3 . "</tr>";
    } else if ($first_full_paid_month_name !== "" && $last_full_paid_month_name === "") {
        $td1 = "<td><b>" . htmlspecialchars($first_full_paid_month_name, ENT_QUOTES, 'UTF-8') . "</b></td>";
        $td2 = '<td class="text-center status-paid">Paid</td>';
        $td3 = '<td class="text-right">₹' . $average_full_paid_amount . ' x ' . count($full_paid_payment_ids) . ' = ₹' . $average_full_paid_amount * count($full_paid_payment_ids) . '/-</td>';
        $trows .= "<tr>" . $td1 . $td2 . $td3 . "</tr>";
    }

    if ($last_partial_month_name !== "" && $last_partial_month_name !== $last_full_paid_month_name) {
        $td1 = "<td><b>" . htmlspecialchars($last_partial_month_name, ENT_QUOTES, 'UTF-8') . "</b></td>";
        $td2 = '<td class="text-center status-adv">Partial</td>';
        $td3 = '<td class="text-right">₹' . $last_partial_payment_amount . '/-</td>';
        $trows .= "<tr>" . $td1 . $td2 . $td3 . "</tr>";
    }

    if (!$full_months_available || !$partial_details_available) $trows = '';
    $fee_payment_cents = (int)round(($payment_amount - $wallet_credited_amount) * 100);
    if ($trows === '' && $fee_payment_cents > 0) {
        // Old records can have missing detail links. Recover months only from
        // the structured payment remark when its allocations reconcile exactly.
        $legacy_months = [];
        $legacy_cents = 0;
        $pattern = '~(?<![\d.,])(\d+(?:\.\d{1,2})?)\s*(?:/-)?\s+(?:has\s+been\s+)?used\s+for\s+(?:fee\s+)?payment\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{4})(?![\dA-Za-z])~i';
        preg_match_all($pattern, (string)($payment['remark'] ?? ''), $matches, PREG_SET_ORDER);
        foreach ($matches as $match) {
            $month = DateTimeImmutable::createFromFormat('!F Y', $match[2] . ' ' . $match[3]);
            if (!$month) continue;
            $legacy_cents += (int)round((float)$match[1] * 100);
            $legacy_months[(int)$month->format('Y') * 12 + (int)$month->format('n') - 1] = $month;
        }
        $label = $legacy_cents === $fee_payment_cents && $legacy_months
            ? $format_receipt_months($legacy_months) : 'Month details unavailable';
        $amount = $currency_symbol . number_format($fee_payment_cents / 100, $fee_payment_cents % 100 === 0 ? 0 : 2, '.', '') . '/-';
        $trows = '<tr><td><b>' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</b></td>'
            . '<td class="text-center">Received</td><td class="text-right">' . htmlspecialchars($amount, ENT_QUOTES, 'UTF-8') . '</td></tr>';
    }

    if ($wallet_credited_amount > 0) {
        $td1 = "<td>Wallet Credit</td>";
        $td2 = '<td class="text-center status-paid">Credit</td>';
        $td3 = '<td class="text-right">₹' . $wallet_credited_amount . '/-</td>';
        $trows .= "<tr>" . $td1 . $td2 . $td3 . "</tr>";
    }

    $student_name = $student['name'];
    $student_class = $student['class_name'];
    $student_section = $student['section_name']; 
    $student_roll_no = $student['roll_no'];
    $student_image = schoolPhotoUrl('students', $student['student_image']);

    $receipt_data = [
        "{receipt_no}" =>$payment_id,
        "{student_name}" => $student_name,
        "{class_name}" => $student_class,
        "{section_name}" => $student_section,
        "{roll_no}" => $student_roll_no,
        "{student_image}" => $student_image,
        "{tbody_rows}" => $trows,
        "{total_payment_amount}" => "₹" . number_format($payment_amount, $payment_amount == round($payment_amount) ? 0 : 2) . "/-",
        "{current_monthly_due}" => htmlspecialchars($currency_symbol . number_format($current_monthly_due, 2) . '/-', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
        "{current_monthly_due_months}" => htmlspecialchars($monthly_due_summaries[$student_id]['months'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
        "{monthly_due_class}" => $current_monthly_due > 0 ? 'has-due' : 'no-due',
        "{paid_amount_in_words}" => ucfirst(convertNumberToWords((float) $payment_amount)) . " only",
        "{payment_date}" => date('d-m-Y', strtotime($payment_date)),
        "{collector_name}" => $collector_name ?? "N/A",
    ];

    $receipt_html = str_replace(array_keys($receipt_data), array_values($receipt_data), $receipt_html);
    $all_receipts_html .= $receipt_html;
}

$main = str_replace("{receipts}", $all_receipts_html, $main);

echo $main;
