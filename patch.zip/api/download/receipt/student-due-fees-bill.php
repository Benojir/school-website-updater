<?php
ob_start();
/** 
 * @var PDO $pdo 
 * @var array $schoolInfo
 * @var string $currency_symbol
 * */
ini_set('memory_limit', '512M'); // or '1G' for very large files
include_once(__DIR__ . "/../../../includes/auth-check.php");

$student_ids = $_REQUEST['student_ids'] ?? '';

if (empty($student_ids)) {
    die("Student ID(s) are required");
}

$student_ids = explode(',', $student_ids);

$school_name = $schoolInfo['name'];
$school_contact = $schoolInfo['phone'];
$school_email = $schoolInfo['email'];
$principal_name = $schoolInfo['principal_name'];
$principal_sign = BASE_URL . '/uploads/school/principle_sign.png';

$main_html = file_get_contents(__DIR__ . "/../../../assets/templates/due-fees-receipt-templates/main.html");
$receipt_cell_html = file_get_contents(__DIR__ . "/../../../assets/templates/due-fees-receipt-templates/receipt-cell.html");

$all_receipts_html = '';

foreach ($student_ids as $student_id) {
    $receipt_cell = $receipt_cell_html;
    $student_info = getStudentInfo($pdo, $student_id);

    // ------------- Get total admission pending fees -------------
    $stmt = $pdo->prepare("SELECT * FROM admission_unpaid_fees WHERE student_id = :student_id");
    $stmt->execute(['student_id' => $student_id]);
    
    $academic_years = [];
    $total_admission_pending_fees = 0;
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $total_admission_pending_fees += $row['unpaid_amount'];
        $academic_years[] = $row['academic_year'];
    }

    $admission_detail_text = '';

    if (count($academic_years) > 0) {
        usort($academic_years, function ($a, $b) {
            return $a <=> $b;
        });

        $admission_detail_text = $academic_years[0];
        if (count($academic_years) > 1) {
            $admission_detail_text = $academic_years[0] . ' to ' . end($academic_years);
        }
    }

    // ------------- Get total monthly pending fees -------------
    $stmt = $pdo->prepare("SELECT * FROM student_unpaid_fees WHERE student_id = :student_id");
    $stmt->execute(['student_id' => $student_id]);

    $month_years = [];
    $total_monthly_pending_fees = 0;
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $total_monthly_pending_fees += $row['unpaid_amount'];
        $month_years[] = $row['month_year'];
    }

    $months_detail_text = '';

    if (count($month_years) > 0) {
        usort($month_years, function ($a, $b) {
            return strtotime("1 " . $a) <=> strtotime("1 " . $b);
        });

        $months_detail_text = $month_years[0];
        if (count($month_years) > 1) {
            $months_detail_text = $month_years[0] . ' to ' . end($month_years);
        }
    }

    // ------------- Get total pending additional fees -------------
    $stmt = $pdo->prepare("SELECT additional_fee_setup_id FROM additional_fees_data WHERE student_id = :student_id AND additional_fee_status = 'unpaid'");
    $stmt->execute(['student_id' => $student_id]);

    $total_additional_pending_fees = 0;
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $additional_fee_setup_id = $row['additional_fee_setup_id'];
        $stmt = $pdo->prepare("SELECT amount FROM class_wise_additional_fees WHERE id = :additional_fee_setup_id");
        $stmt->execute(['additional_fee_setup_id' => $additional_fee_setup_id]);
        $total_additional_pending_fees += $stmt->fetchColumn();
    }

    $total_pending_fees = $total_admission_pending_fees + $total_monthly_pending_fees + $total_additional_pending_fees;

    // -------------- Replacing the placeholders --------------
    $receipt_cell = str_replace('{school_name}', $school_name, $receipt_cell);
    $receipt_cell = str_replace('{school_phone}', $school_contact, $receipt_cell);
    $receipt_cell = str_replace('{school_email}', $school_email, $receipt_cell);
    $receipt_cell = str_replace('{student_name}', $student_info['name'], $receipt_cell);
    $receipt_cell = str_replace('{father_name}', $student_info['father_name'], $receipt_cell);
    $receipt_cell = str_replace('{class}', $student_info['class_name'] . ' - ' . $student_info['section_name'], $receipt_cell);
    $receipt_cell = str_replace('{roll_no}', $student_info['roll_no'] ?? '', $receipt_cell);
    $receipt_cell = str_replace('{student_image}', BASE_URL . '/uploads/students/' . $student_info['student_image'] ?? '', $receipt_cell);
    $receipt_cell = str_replace('{currency_symbol}', $currency_symbol, $receipt_cell);
    $receipt_cell = str_replace('{admission_due_fees}', $total_admission_pending_fees, $receipt_cell);
    $receipt_cell = str_replace('{admission_fees_details}', $admission_detail_text, $receipt_cell);
    $receipt_cell = str_replace('{monthly_due_fees}', $total_monthly_pending_fees, $receipt_cell);
    $receipt_cell = str_replace('{monthly_fees_details}', $months_detail_text, $receipt_cell);
    $receipt_cell = str_replace('{additional_due_fees}', $total_additional_pending_fees, $receipt_cell);
    $receipt_cell = str_replace('{total_due_fees}', $total_pending_fees, $receipt_cell);
    $receipt_cell = str_replace('{date}', date('d/m/Y'), $receipt_cell);
    $receipt_cell = str_replace('{principal_sign}', $principal_sign, $receipt_cell);
    $receipt_cell = str_replace('{principal_name}', $principal_name, $receipt_cell);

    $all_receipts_html .= $receipt_cell;
}

$main_html = str_replace('{receipts}', $all_receipts_html, $main_html);

echo $main_html;

ob_end_flush();
