<?php
// প্রথমে চেক করুন ভ্যারিয়েবলগুলো সেট করা আছে কিনা, তারপর টাইপ কাস্টিং করুন
$id = isset($_GET["id"]) ? (int) $_GET["id"] : 0;
$type = $_GET["type"] ?? "";

// empty() এর বদলে সরাসরি সঠিক কন্ডিশন চেক করা ভালো
if ($id === 0 || empty($type)) {
    echo "ID and Type are required, and ID must be a non-zero integer.";
    exit;
}

if ($type === 'monthly_payment_history') {
    // URL-এর সিকিউরিটির জন্য (XSS ও Injection রোধে) urlencode বা filter করা ভালো
    $query = "monthly-payment-receipt.php?id=" . $id;
    
    // রিডাইরেকশনের সঠিক নিয়ম
    http_response_code(301);
    header("Location: " . $query);
    exit; // হেডার পাঠানোর পর স্ক্রিপ্টটি এক্সিট করা আবশ্যক
}
?>
