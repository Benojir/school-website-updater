<?php
include_once __DIR__ . '/../../../includes/auth-check.php';
require_once __DIR__ . '/../../../includes/financial/admission-payment-receipt.php';

header('Content-Type: text/html; charset=UTF-8');
header('Cache-Control: no-store');
if (!hasPermission(PERM_MANAGE_FEES)) {
    http_response_code(403);
    exit('You do not have permission to print fee receipts.');
}

try {
    $ids = admissionReceiptIds($_GET['ids'] ?? '');
    $receipts = admissionReceiptLoad($pdo, $ids);
    if (!$receipts) {
        http_response_code(404);
        exit('No admission payment receipts found. The payments may have been reversed or deleted.');
    }
    echo admissionReceiptRender($receipts, $schoolInfo, BASE_URL, $currency_symbol,
        static fn($image) => schoolPhotoUrl('students', $image),
        static fn($amount) => convertNumberToWords($amount), count($ids) - count($receipts));
} catch (InvalidArgumentException $e) {
    http_response_code(400);
    echo htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
} catch (Throwable $e) {
    http_response_code(500);
    error_log('Admission receipt: ' . $e->getMessage());
    echo 'Unable to prepare the admission receipts. Please try again.';
}
