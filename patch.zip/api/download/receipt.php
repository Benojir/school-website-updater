<?php
$id = $_REQUEST['id'] ?? null;
$studentId = $_REQUEST['student_id'] ?? null;
$type = $_REQUEST['type'] ?? null;

if (!$id || !$studentId || !$type) {
    http_response_code(400);
    echo "<center><h3 style='color:red;'>Invalid request. Missing parameters.</h3></center>";
    exit;
}

if ($type === 'paid_monthly_fees' || $type === 'paid_admission_fees') {
    header("Location: receipt/monthly-x-admission-receipt.php?id=$id&student_id=$studentId&type=$type");
    exit;
}

if ($type === 'paid_additional_fees') {
    header("Location: receipt/additional-receipt.php?id=$id&student_id=$studentId&type=$type");
    exit;
}

if ($type === 'monthly_payment_history' || $type === 'admission_payment_history') {
    header("Location: receipt/payment-history-receipt.php?id=$id&student_id=$studentId&type=$type");
    exit;
}