<?php
define('ID_CARD_AUDIENCE', 'driver');
require __DIR__ . '/generate-student-id-cards.php';
