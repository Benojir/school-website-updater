<?php
require_once(__DIR__ . '/../../includes/auth-check.php');
require_once(__DIR__ . '/../../includes/teacher/teacher-id-card-data.php');
if (!hasPermission(PERM_MANAGE_ID_CARDS) || !hasPermission(PERM_MANAGE_TEACHERS)) {
    http_response_code(403); exit('Permission denied');
}
try { $teacher_ids = teacherIdCardSelectedIds($_POST + $_GET); }
catch (InvalidArgumentException $e) { http_response_code(400); exit(htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8')); }
$template = null;
$migration_required = false;
try {
    $template = $pdo->query('SELECT template_name, has_back, back_design_json FROM teacher_id_card_templates WHERE is_active = 1 ORDER BY id LIMIT 1')->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) { $migration_required = true; }
$has_back = $template && !empty($template['has_back']) && !empty($template['back_design_json']);
include_once(__DIR__ . '/../../includes/header-open.php');
?>
<title>Print Teacher ID Cards</title>
<?php include_once(__DIR__ . '/../../includes/header-close.php'); ?>
<div class="container py-5" style="max-width:720px">
    <div class="card shadow-sm">
        <div class="card-body p-4">
            <h3><i class="fas fa-id-card me-2"></i>Teacher ID Cards</h3>
            <p><?= count($teacher_ids) ?> teacher(s) selected.</p>
            <?php if ($migration_required): ?>
                <div class="alert alert-warning">The teacher template library is not available. Review and manually apply the Teacher ID Card block in migrate.sql first.</div>
            <?php elseif (!$template): ?>
                <div class="alert alert-info">Create and save a named template in the Teacher ID Card Builder first.</div>
            <?php else: ?>
                <p>Printing template: <strong><?= htmlspecialchars($template['template_name'], ENT_QUOTES, 'UTF-8') ?></strong></p>
                <form action="generate-teacher-id-cards.php" method="post" target="_blank">
                    <input type="hidden" name="teacher_ids" value="<?= htmlspecialchars(json_encode($teacher_ids), ENT_QUOTES, 'UTF-8') ?>">
                    <?php if ($has_back): ?>
                        <label class="form-label" for="duplexLayout">Front &amp; back arrangement</label>
                        <select id="duplexLayout" name="duplex_layout" class="form-select mb-3">
                            <option value="sequential">Separate front/back sheets — duplex, flip on long edge</option>
                            <option value="side-by-side">Front &amp; back side by side — cut and laminate</option>
                        </select>
                    <?php endif; ?>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-print me-1"></i>Generate &amp; Print</button>
                </form>
            <?php endif; ?>
            <div class="d-flex flex-wrap gap-2 mt-3">
                <?php if (!$migration_required): ?>
                <a href="../../management/settings/teacher-id-card-builder.php" class="btn btn-outline-primary">Teacher ID Card Builder</a>
                <?php endif; ?>
                <a href="../../management/teacher/list-teachers.php" class="btn btn-outline-secondary">Back to teachers</a>
                <a href="download-bulk-teacher-id-card.php?ids=<?= implode(',', $teacher_ids) ?>" class="btn btn-outline-secondary">Classic teacher cards</a>
            </div>
        </div>
    </div>
</div>
<?php include_once(__DIR__ . '/../../includes/body-close.php'); ?>
