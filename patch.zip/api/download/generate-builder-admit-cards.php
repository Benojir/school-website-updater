<?php
define('ID_CARD_AUDIENCE', 'admit');
require __DIR__ . '/generate-student-id-cards.php';
