<?php
ini_set('memory_limit', '512M'); // or '1G' for very large files
include_once(__DIR__ . "/../../../includes/auth-check.php");

/** @var PDO $pdo */

$admit_id = $_REQUEST['admit_id'] ?? '';
$student_ids = $_REQUEST['student_ids'] ?? '';

if (empty($admit_id)) {
    die("Admit Card ID is required");
}

if (empty($student_ids)) {
    die("Student ID(s) are required");
}

$student_ids = explode(',', $student_ids);

// ---------------------------------------------------------------------
// School info (global) + Admit Card settings (from settings_admit_card)
// ---------------------------------------------------------------------

/** @var array $schoolInfo */
$school_name = $schoolInfo['name'];
$exam_center = $schoolInfo['name'] . (!empty($schoolInfo['campus_name']) ? ' - ' . $schoolInfo['campus_name'] : '');
$school_logo = BASE_URL . '/uploads/school/logo-square.png?v=' . time();
$student_image = BASE_URL . '/uploads/students/';

$stmt = $pdo->prepare("SELECT * FROM settings_admit_card LIMIT 1");
$stmt->execute();
$settings = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

$colors = json_decode($settings['colors'] ?? '', true);
if (!is_array($colors)) {
    $colors = [];
}

// Colors from settings, with sensible hardcoded fallbacks for anything extra
$color_primary       = $colors['primary'] ?? '#3a4a6d';
$color_dark          = $colors['dark'] ?? '#2b3a5a';
$color_light         = $colors['light'] ?? '#F0F5FF';
$color_bg            = $colors['background'] ?? '#FFFFFF';
$color_school_name   = $colors['school_name'] ?? '#EFF0F2';
$color_school_addr   = $colors['school_address'] ?? '#333333';
$color_accent        = '#c9a227'; // hardcoded accent (gold) - not in settings

$school_address = $settings['school_address'] ?? ($schoolInfo['address'] ?? '');
$school_contact = $settings['school_contact'] ?? '';
$instructions   = trim($settings['instructions'] ?? '') ?: 'All outstanding dues must be fully settled in order to be eligible to sit for the examination.';

$bg_image_path = __DIR__ . "/../../../uploads/school/admit-card-bg/admit-card-bg.jpg";
$bg_image = is_file($bg_image_path)
    ? BASE_URL . '/uploads/school/admit-card-bg/admit-card-bg.jpg?v=' . time()
    : '';

// ---------------------------------------------------------------------
// Routine font sizing — scales down as subject count grows (max 17)
// ---------------------------------------------------------------------

function admitcard_routine_sizing(int $count): array
{
    if ($count <= 5)  return ['font' => '8.5pt', 'pad' => '4px 5px',   'lh' => '1.2'];
    if ($count <= 8)  return ['font' => '7.4pt', 'pad' => '3px 4px',   'lh' => '1.15'];
    if ($count <= 11) return ['font' => '6.6pt', 'pad' => '2.4px 3px', 'lh' => '1.1'];
    if ($count <= 14) return ['font' => '5.8pt', 'pad' => '1.8px 2px', 'lh' => '1.05'];
    return ['font' => '5.1pt', 'pad' => '1.2px 2px', 'lh' => '1.0']; // up to 17
}

// ---------------------------------------------------------------------
// Inline templates
// ---------------------------------------------------------------------

$main_html = <<<'HTML'
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admit Cards</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&family=Roboto:wght@400;500;700&display=swap');

        :root {
            --primary: {{color_primary}};
            --dark: {{color_dark}};
            --light: {{color_light}};
            --card-bg: {{color_bg}};
            --school-name-color: {{color_school_name}};
            --school-addr-color: {{color_school_addr}};
            --accent: {{color_accent}};
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        body {
            background-color: #e2e8f0;
            font-family: 'Roboto', sans-serif;
            padding: 20px;
        }

        .page {
            width: 297mm;
            height: 210mm;
            background: white;
            margin: 0 auto 20px auto;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.15);
            display: grid;
            grid-template-columns: 148.5mm 148.5mm;
            grid-template-rows: 105mm 105mm;
            overflow: hidden;
        }

        .card {
            width: 148.5mm;
            height: 105mm;
            position: relative;
            overflow: hidden;
            border: 1px dashed #cbd5e1;
            display: flex;
            flex-direction: column;
        }

        .card.empty {
            visibility: hidden;
        }

        /* ---------------- FRONT CARD ---------------- */

        .card-front {
            background-color: var(--card-bg);
        }

        .card-front .bg-layer {
            position: absolute;
            inset: 0;
            background-image: {{bg_image_css}};
            background-size: cover;
            background-position: center;
            opacity: 0.22;
            z-index: 0;
        }

        .card-front .decor-circle {
            position: absolute;
            border-radius: 50%;
            background: var(--primary);
            z-index: 0;
        }

        .card-front .decor-circle.c1 {
            width: 55mm;
            height: 55mm;
            top: -18mm;
            right: -14mm;
            opacity: 0.05;
        }

        .card-front .decor-circle.c2 {
            width: 30mm;
            height: 30mm;
            bottom: -10mm;
            left: -8mm;
            background: var(--accent);
            opacity: 0.07;
        }

        .card-front .inner {
            position: relative;
            z-index: 1;
            height: 100%;
            display: flex;
            flex-direction: column;
            padding: 4mm;
            border: 1px solid rgba(0, 0, 0, 0.06);
            margin: 1.5mm;
            border-radius: 2mm;
        }

        .front-header {
            background: var(--primary);
            color: var(--school-name-color);
            border-radius: 4px;
            padding: 3.5mm 4mm 3mm 4mm;
            display: flex;
            align-items: center;
            gap: 3.5mm;
        }

        .front-header img.logo {
            width: 13mm;
            height: 13mm;
            border-radius: 50%;
            background: white;
            object-fit: cover;
            flex-shrink: 0;
            border: 2px solid var(--accent);
        }

        .front-header .school-text {
            flex: 1;
            min-width: 0;
        }

        .front-header .school-text h1 {
            font-family: 'Montserrat', sans-serif;
            font-size: 12.5pt;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            line-height: 1.15;
            color: var(--school-name-color);
        }

        .front-header .school-text p {
            font-size: 6.8pt;
            color: var(--school-addr-color);
            margin-top: 1.3mm;
            line-height: 1.3;
        }

        .front-header .school-text p i {
            width: 3mm;
            font-size: 6pt;
            opacity: 0.85;
        }

        .front-header .school-text p.contact {
            font-size: 6.4pt;
            opacity: 0.9;
            margin-top: 0.8mm;
        }

        .title-badge {
            display: flex;
            justify-content: center;
            margin: 3.5mm 0 3mm 0;
        }

        .title-badge span {
            background: var(--accent);
            color: var(--dark);
            font-size: 8.5pt;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1.2px;
            padding: 1.4mm 6mm;
            border-radius: 3mm;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.15);
        }

        .title-badge span i {
            margin-right: 1.5mm;
        }

        .body-row {
            display: flex;
            gap: 5mm;
            align-items: flex-start;
        }

        .photo-col {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 2mm;
            flex-shrink: 0;
        }

        .photo-frame {
            width: 26mm;
            height: 32mm;
            padding: 1mm;
            border: 1.5px solid var(--accent);
            border-radius: 2mm;
            overflow: hidden;
            background: white;
            box-shadow: 0 1px 4px rgba(0, 0, 0, 0.12);
        }

        .photo-frame img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 1mm;
        }

        .student-id-chip {
            background: var(--primary);
            color: var(--school-name-color);
            font-size: 6.4pt;
            font-weight: 700;
            letter-spacing: 0.4px;
            padding: 1mm 3mm;
            border-radius: 3mm;
            text-transform: uppercase;
            white-space: nowrap;
        }

        .fields-grid {
            flex: 1;
            display: grid;
            grid-template-columns: 1fr 1fr;
            column-gap: 6mm;
            row-gap: 3.5mm;
            align-content: center;
        }

        .field-row {
            display: grid;
            grid-template-columns: 25mm 1fr;
            gap: 2mm;
            font-size: 8.6pt;
        }

        .field-row .f-label {
            color: var(--primary);
            opacity: 0.7;
            font-weight: 600;
        }

        .field-row .f-label i {
            width: 4mm;
            font-size: 7.4pt;
        }

        .field-row .f-value {
            font-weight: 700;
            color: var(--dark);
            text-transform: uppercase;
            word-break: break-word;
        }

        .exam-info-panel {
            margin-top: 3.5mm;
            background: var(--light);
            border-radius: 2.5mm;
            padding: 2.5mm 4mm;
            display: flex;
            gap: 6mm;
        }

        .exam-info-panel .info-item {
            flex: 1;
            min-width: 0;
        }

        .exam-info-panel .info-label {
            font-size: 6.4pt;
            color: var(--primary);
            opacity: 0.8;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.4px;
            margin-bottom: 0.6mm;
        }

        .exam-info-panel .info-label i {
            margin-right: 1mm;
        }

        .exam-info-panel .info-value {
            font-size: 8.2pt;
            font-weight: 700;
            color: var(--dark);
            text-transform: uppercase;
            line-height: 1.25;
        }

        .front-divider {
            height: 1px;
            margin: 3mm 0 2.2mm 0;
            background: linear-gradient(90deg, transparent, var(--primary) 50%, transparent);
            opacity: 0.25;
        }

        .front-footer {
            margin-top: auto;
            font-size: 7.5pt;
            color: var(--dark);
            opacity: 0.72;
            text-align: left;
            line-height: 1.35;
        }

        /* ---------------- BACK CARD ---------------- */

        .card-back {
            background-color: var(--card-bg);
        }

        .card-back .inner {
            height: 100%;
            display: flex;
            flex-direction: column;
            padding: 4mm;
        }

        .back-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1.5px solid var(--primary);
            padding-bottom: 1.8mm;
            margin-bottom: 2mm;
        }

        .back-header .title {
            font-size: 8.5pt;
            font-weight: 700;
            text-transform: uppercase;
            color: var(--primary);
            letter-spacing: 0.5px;
        }

        .back-header .who {
            font-size: 6.8pt;
            font-weight: 600;
            color: var(--dark);
            text-align: right;
            text-transform: uppercase;
        }

        .routine-table-wrap {
            flex-grow: 1;
            border: 1px solid #d1d5db;
            border-radius: 3px;
            overflow: hidden;
        }

        .routine-table-wrap table {
            width: 100%;
            height: 100%;
            border-collapse: collapse;
        }

        .routine-table-wrap th {
            background: var(--light);
            color: var(--primary);
            font-weight: 700;
            text-transform: uppercase;
            text-align: center;
            border-bottom: 1.5px solid var(--primary);
            white-space: nowrap;
        }

        .routine-table-wrap td {
            color: #111827;
            border-bottom: 1px solid #e5e7eb;
            text-align: center;
            font-weight: 500;
            text-transform: uppercase;
        }

        .routine-table-wrap tr:nth-child(even) td {
            background: #f9fafb;
        }

        .routine-table-wrap tr:last-child td {
            border-bottom: none;
        }

        .routine-table-wrap td.subject-col {
            text-align: left;
            font-weight: 700;
            color: var(--primary);
        }

        @media print {
            @page {
                size: A4 landscape;
                margin: 0;
            }

            body {
                background: none;
                padding: 0;
            }

            .page {
                margin: 0;
                box-shadow: none;
                page-break-after: always;
            }

            .page:last-child {
                page-break-after: auto;
            }

            .no-print {
                display: none !important;
            }
        }

        .btn-container {
            position: fixed;
            bottom: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
            z-index: 99;
        }

        .btn {
            background-color: var(--primary);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>

    {{admit_pages}}

    <div class="btn-container no-print">
        <button class="btn" onclick="window.print()"><i class="fas fa-print"></i> Print Admit Card</button>
    </div>

</body>

</html>
HTML;

$front_card_tpl = <<<'HTML'
<div class="card card-front">
    <div class="bg-layer"></div>
    <div class="decor-circle c1"></div>
    <div class="decor-circle c2"></div>
    <div class="inner">
        <div class="front-header">
            <img class="logo" src="{{school_logo}}" alt="Logo">
            <div class="school-text">
                <h1>{{school_name}}</h1>
                <p><i class="fas fa-map-marker-alt"></i> {{school_address}}</p>
                <p class="contact"><i class="fas fa-phone-alt"></i> {{school_contact}}</p>
            </div>
        </div>

        <div class="title-badge"><span><i class="fas fa-id-card"></i>Admit Card</span></div>

        <div class="body-row">
            <div class="photo-col">
                <div class="photo-frame">
                    <img src="{{student_image}}" alt="{{student_name}}">
                </div>
                <div class="student-id-chip">{{student_id}}</div>
            </div>
            <div class="fields-grid">
                <div class="field-row"><div class="f-label"><i class="fas fa-user"></i>Student</div><div class="f-value">{{student_name}}</div></div>
                <div class="field-row"><div class="f-label"><i class="fas fa-user-tie"></i>Father</div><div class="f-value">{{father_name}}</div></div>
                <div class="field-row"><div class="f-label"><i class="fas fa-chalkboard"></i>Class</div><div class="f-value">{{class}}</div></div>
                <div class="field-row"><div class="f-label"><i class="fas fa-graduation-cap"></i>Roll No</div><div class="f-value">{{roll_no}}</div></div>
            </div>
        </div>

        <div class="exam-info-panel">
            <div class="info-item">
                <div class="info-label"><i class="fas fa-book"></i>Exam</div>
                <div class="info-value">{{exam_name}}</div>
            </div>
            <div class="info-item">
                <div class="info-label"><i class="fas fa-location-dot"></i>Center</div>
                <div class="info-value">{{exam_center}}</div>
            </div>
        </div>

        <div class="front-divider"></div>
        <div class="front-footer"><b>Note:</b> {{instructions}}</div>
    </div>
</div>
HTML;

$back_card_tpl = <<<'HTML'
<div class="card card-back">
    <div class="inner">
        <div class="back-header">
            <div class="title">Exam Routine</div>
            <!-- <div class="who">{{student_name}} &middot; Roll {{roll_no}}</div> -->
        </div>
        <div class="routine-table-wrap" style="--rf: {{routine_font}}; --rp: {{routine_pad}}; --rlh: {{routine_lh}};">
            <table style="font-size: var(--rf);">
                <thead>
                    <tr style="line-height: var(--rlh);">
                        <th style="padding: var(--rp); text-align:left; padding-left:2mm;">Subject</th>
                        <th style="padding: var(--rp);">W. Date</th>
                        <th style="padding: var(--rp);">W. Time</th>
                        <th style="padding: var(--rp);">O. Date</th>
                        <th style="padding: var(--rp);">O. Time</th>
                    </tr>
                </thead>
                <tbody>
                    {{routine_tbody}}
                </tbody>
            </table>
        </div>
    </div>
</div>
HTML;

$empty_card_tpl = '<div class="card {{type}} empty"></div>';

// Replace settings-driven placeholders in the page shell (colors/background only need to happen once)
$bg_image_css = $bg_image ? "url('{$bg_image}')" : 'none';

$main_html = str_replace(
    ['{{color_primary}}', '{{color_dark}}', '{{color_light}}', '{{color_bg}}', '{{color_school_name}}', '{{color_school_addr}}', '{{color_accent}}', '{{bg_image_css}}'],
    [$color_primary, $color_dark, $color_light, $color_bg, $color_school_name, $color_school_addr, $color_accent, $bg_image_css],
    $main_html
);

// ---------------------------------------------------------------------
// Build front/back card HTML per student
// ---------------------------------------------------------------------

$fronts = [];
$backs = [];
$skip_count = 0;

foreach ($student_ids as $student_id) {

    $student = getStudentInfo($pdo, $student_id);

    if (!$student) {
        $skip_count++;
        continue; // Skip if student not found
    }

    // Fetch specific admit card details and verify it's for the student's class
    $stmt = $pdo->prepare("
        SELECT ea.*, e.exam_name, e.exam_date
        FROM exam_admit_releases ea
        JOIN exams e ON ea.exam_id = e.id
        WHERE ea.id = ? AND ea.class_id = ?
    ");
    $stmt->execute([$admit_id, $student['class_id']]);
    $admit_card = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admit_card) {
        $skip_count++;
        continue; // Skip if admit card not valid for this student
    }

    // Fetch exam routine for this specific admit card (max 17 subjects supported)
    $stmt = $pdo->prepare("
        SELECT er.*, sub.subject_name 
        FROM exam_routines er
        JOIN subjects sub ON er.subject_id = sub.id
        WHERE er.exam_id = ? AND er.class_id = ?
        ORDER BY 
            COALESCE(er.theory_exam_date, er.practical_exam_date) ASC, 
            COALESCE(er.theory_start_time, er.practical_start_time) ASC
    ");
    $stmt->execute([$admit_card['exam_id'], $student['class_id']]);
    $exam_routine = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $sizing = admitcard_routine_sizing(count($exam_routine));

    $routine_tbody = '';

    foreach ($exam_routine as $routine) {
        $theory_start_time = $routine['theory_start_time'] ? date("h:i", strtotime($routine['theory_start_time'])) : '';
        $theory_end_time = $routine['theory_end_time'] ? date("h:i", strtotime($routine['theory_end_time'])) : '';

        $practical_start_time = $routine['practical_start_time'] ? date("h:i", strtotime($routine['practical_start_time'])) : '';
        $practical_end_time = $routine['practical_end_time'] ? date("h:i", strtotime($routine['practical_end_time'])) : '';

        $theory_exam_date = $routine['theory_exam_date'] ? date('d M', strtotime($routine['theory_exam_date'])) : '-';
        $practical_exam_date = $routine['practical_exam_date'] ? date('d M', strtotime($routine['practical_exam_date'])) : '-';

        $routine_tbody .=
            '<tr style="line-height: var(--rlh);">
                <td class="subject-col" style="padding: var(--rp); padding-left:2mm;">' . $routine['subject_name'] . '</td>
                <td style="padding: var(--rp);">' . $theory_exam_date . '</td>
                <td style="padding: var(--rp);">' . $theory_start_time . ($theory_start_time ? '-' . $theory_end_time : '') . '</td>
                <td style="padding: var(--rp);">' . $practical_exam_date . '</td>
                <td style="padding: var(--rp);">' . $practical_start_time . ($practical_start_time ? '-' . $practical_end_time : '') . '</td>
            </tr>';
    }

    $exam_name = $admit_card['exam_name'] ?? '-';
    $student_name = $student['name'] ?? '-';
    $father_name = $student['father_name'] ?? '-';
    $class = $student['class_name'] . " (" . $student['section_name'] . ")";
    $roll_no = $student['roll_no'] ?? '-';
    $student_dp = $student_image . $student['student_image'];

    $front = str_replace(
        ['{{school_logo}}', '{{school_name}}', '{{school_address}}', '{{school_contact}}', '{{exam_name}}', '{{exam_center}}', '{{student_name}}', '{{student_id}}', '{{father_name}}', '{{class}}', '{{roll_no}}', '{{student_image}}', '{{instructions}}'],
        [$school_logo, $school_name, $school_address, $school_contact, $exam_name, $exam_center, $student_name, $student_id, $father_name, $class, $roll_no, $student_dp, $instructions],
        $front_card_tpl
    );

    $back = str_replace(
        ['{{student_name}}', '{{roll_no}}', '{{routine_font}}', '{{routine_pad}}', '{{routine_lh}}', '{{routine_tbody}}'],
        [$student_name, $roll_no, $sizing['font'], $sizing['pad'], $sizing['lh'], $routine_tbody],
        $back_card_tpl
    );

    $fronts[] = $front;
    $backs[] = $back;
}

// ---------------------------------------------------------------------
// Paginate: 4 fronts per page, followed by the matching 4 backs
// ---------------------------------------------------------------------

$all_pages = '';
$front_chunks = array_chunk($fronts, 4);
$back_chunks = array_chunk($backs, 4);

foreach ($front_chunks as $i => $front_chunk) {
    $back_chunk = $back_chunks[$i];

    while (count($front_chunk) < 4) {
        $front_chunk[] = str_replace('{{type}}', 'card-front', $empty_card_tpl);
    }
    while (count($back_chunk) < 4) {
        $back_chunk[] = str_replace('{{type}}', 'card-back', $empty_card_tpl);
    }

    $all_pages .= '<div class="page">' . implode('', $front_chunk) . '</div>';
    $all_pages .= '<div class="page">' . implode('', $back_chunk) . '</div>';
}

$main_html = str_replace('{{admit_pages}}', $all_pages, $main_html);

// Output the HTML
echo $main_html;