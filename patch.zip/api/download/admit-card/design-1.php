<?php
ini_set('memory_limit', '512M'); // or '1G' for very large files
include_once(__DIR__ . "/../../../includes/auth-check.php");

/** @var PDO $pdo */

$admit_id = $_REQUEST['admit_id'] ?? '';
$student_ids = $_REQUEST['student_ids'] ?? '';

if (empty($admit_id)) {
    die("Admit Card ID is required");
}

if (empty($student_ids)) {
    die("Student ID(s) are required");
}

$student_ids = explode(',', $student_ids);

// School information 
/** @var array $schoolInfo */
$school_name = $schoolInfo['name'];
$school_address = $schoolInfo['address'];
$exam_center = $schoolInfo['name'] . (!empty($schoolInfo['campus_name']) ? ' - ' . $schoolInfo['campus_name'] : '');
$principal_name = $schoolInfo['principal_name'];
$school_logo = BASE_URL . '/uploads/school/logo-square.png?v=' . time();
$principal_sign = BASE_URL . '/uploads/school/principle_sign.png?v=' . time();
$student_image = BASE_URL . '/uploads/students/';

// ---------------------------------------------------------------------
// Inline templates (previously in main.html / content.html)
// ---------------------------------------------------------------------

$main_html = <<<'HTML'
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admit Cards</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Roboto:wght@400;500;700&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Archivo+Black&family=Montserrat:ital,wght@0,100..900;1,100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');

        :root {
            --primary-blue: #1a237e;
            --accent-gold: #ffb300;
            --text-dark: #111827;
            --text-light: #4b5563;
            --table-border: #d1d5db;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        body {
            background-color: #e2e8f0;
            font-family: 'Roboto', sans-serif;
            min-height: 100vh;
            padding: 20px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            place-items: center;
        }

        .admit-card {
            width: 210mm;
            height: 148.4mm;
            background: white;
            position: relative;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            padding: 2.5mm;
        }

        .bg-pattern {
            position: absolute;
            right: 50%;
            top: 50%;
            transform: translate(50%, -50%);
            width: 350px;
            height: 350px;
            background: radial-gradient(circle, rgba(26, 35, 126, 0.05) 0%, transparent 70%);
            border-radius: 50%;
            z-index: 0;
        }

        .watermark-img {
            width: 100%;
            height: 100%;
            opacity: 0.05;
            z-index: 0;
        }

        .content {
            position: relative;
            z-index: 1;
            height: 100%;
            display: flex;
            flex-direction: column;
            padding: 0;
        }

        .school-logo {
            width: 50px;
            height: 50px;
            position: absolute;
            background: white;
            border-radius: 50%;
            top: 3%;
            left: 3%;
        }

        .header {
            background-color: var(--primary-blue);
            color: white;
            padding: 8px 15mm;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 22mm;
            border-radius: 5px;
        }

        .school-info h1 {
            font-family: "Montserrat", sans-serif;
            font-size: 18pt;
            margin-bottom: 7px;
            letter-spacing: 0.5px;
            line-height: 1;
            text-align: center;
            text-transform: uppercase;
        }

        .school-info p {
            font-size: 8pt;
            opacity: 0.9;
            font-weight: 300;
            text-align: center;
        }

        .body-section {
            padding: 5px 0mm 0px 0mm;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }

        .title-bar {
            display: flex;
            justify-content: center;
            align-items: flex-end;
            padding-bottom: 2px;
            margin-bottom: 8px;
        }

        .doc-title {
            font-size: 9pt;
            font-weight: 700;
            color: white;
            text-transform: uppercase;
            letter-spacing: 1px;
            background: var(--primary-blue);
            padding: 3px 8px;
            border-radius: 4px;
        }

        .exam-badge {
            background: var(--accent-gold);
            color: var(--primary-blue);
            padding: 3px 8px;
            border-radius: 4px;
            font-weight: 700;
            font-size: 10pt;
            text-transform: uppercase;
        }

        .student-container {
            display: flex;
            gap: 15px;
            margin-bottom: 8px;
            height: 19mm;
            overflow: hidden;
            padding: 0 1mm;
        }

        .info-grid {
            flex: 1;
            display: grid;
            grid-template-columns: auto 1fr;
            gap: 15px 20px;
            font-size: 10pt;
            align-content: start;
        }

        .grid-item {
            display: grid;
            flex: 1;
            grid-template-columns: auto 1fr;
            gap: 15px;
        }

        .info-label {
            color: var(--text-light);
            font-weight: 500;
            text-align: left;
            min-width: 80px;
            font-size: 9pt;
            align-self: center;
        }

        .info-value {
            color: var(--text-dark);
            font-weight: 700;
            text-transform: uppercase;
            font-size: 8pt;
        }

        .address-row {
            grid-column: 1 / -1;
            display: flex;
            gap: 12px;
            margin-top: 2px;
        }

        .address-row .info-label {
            text-align: left;
            min-width: auto;
        }

        .address-row .info-value {
            font-size: 8pt;
            line-height: 1.2;
            align-self: center;
        }

        .photo-frame {
            width: 15mm;
            height: auto;
            border: 3px solid white;
            box-shadow: 0 0 0 1px #e5e7eb, 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 4px;
            overflow: hidden;
            border: 1px solid #e5e7eb;
            background: #f8fafc;
        }

        .photo-frame img,
        .photo-frame svg {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .table-container {
            margin-top: 0;
            flex-grow: 1;
            border-radius: 4px;
            border: 1px solid var(--table-border);
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 7.8pt;
            height: 100%;
        }

        th {
            background-color: #f1f5f9;
            color: var(--primary-blue);
            font-weight: 700;
            text-transform: uppercase;
            padding: 1.5px;
            text-align: center;
            border-bottom: 2px solid var(--table-border);
            font-size: 8pt;
            white-space: nowrap;
        }

        td {
            padding: 3px 4px;
            color: var(--text-dark);
            border-bottom: 1px solid #e5e7eb;
            text-align: center;
            font-weight: 500;
            text-transform: uppercase;
        }

        tr:nth-child(even) {
            background-color: #f9fafb;
        }

        tr:last-child td {
            border-bottom: none;
        }

        .subject-col {
            text-align: left;
            padding-left: 8px;
            font-weight: 700;
            color: var(--primary-blue);
            width: 30%;
        }

        .footnote {
            height: 5mm;
            overflow: hidden;
            font-size: 9pt;
            margin-top: 2mm;
            margin-bottom: 2mm;
        }

        .footnote-value {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .footer {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            height: 13mm;
        }

        .signature-block {
            text-align: center;
            width: 120px;
        }

        .signature-img {
            height: 30px;
            margin-bottom: 2px;
            display: block;
            margin: 0 auto 2px auto;
        }

        .sign-line {
            border-top: 1px solid #9ca3af;
            padding-top: 2px;
            font-size: 8pt;
            color: var(--text-light);
            font-weight: 600;
            text-transform: uppercase;
        }

        @media print {
            @page {
                size: A4 portrait;
                margin: 0;
            }

            body {
                background: none;
                display: block;
                padding: 0;
                margin: 0;
            }

            .admit-card {
                margin: 0;
                box-shadow: none;
                border: 1px dashed #ccc;
                page-break-inside: avoid;
            }

            .admit-card:nth-of-type(even) {
                page-break-after: always;
            }

            .no-print {
                display: none !important;
            }

            .header,
            .exam-badge,
            .doc-title,
            th,
            tr:nth-child(even) {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }

        .btn-container {
            position: fixed;
            bottom: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
            z-index: 99;
        }

        .btn {
            background-color: var(--primary-blue);
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>

    {{admit_cards}}

    <div class="btn-container no-print">
        <button class="btn" onclick="window.print()"><i class="fas fa-print"></i> Print Admit Card</button>
    </div>

</body>

</html>
HTML;

$card = <<<'HTML'
<div class="admit-card">
    <div class="bg-pattern">
        <img class="watermark-img" src="{{school_logo}}" alt="Watermark">
    </div>

    <div class="content">
        <img class="school-logo" src="{{school_logo}}" alt="Logo">
        <div class="header">
            <div class="school-info">
                <h1>{{school_name}}</h1>
                <p><i class="fas fa-map-marker-alt"></i> {{school_address}}</p>
            </div>
        </div>

        <div class="body-section">
            <div class="title-bar">
                <div class="doc-title">Admit Card</div>
            </div>

            <div class="student-container">
                <div class="info-grid">
                    <div class="grid-item">
                        <div class="info-label">Student Name:</div>
                        <div class="info-value">{{student_name}}</div>
                    </div>
                    <div class="grid-item">
                        <div class="info-label">Father's Name:</div>
                        <div class="info-value">{{father_name}}</div>
                    </div>
                    <div class="grid-item">
                        <div class="info-label">Class:</div>
                        <div class="info-value">{{class}}</div>
                    </div>
                    <div class="grid-item">
                        <div class="info-label">Roll No:</div>
                        <div class="info-value">{{roll_no}}</div>
                    </div>
                    <div class="grid-item">
                        <span class="info-label">Exam:</span>
                        <span class="info-value">{{exam_name}}</span>
                    </div>
                    <div class="grid-item">
                        <span class="info-label">Center:</span>
                        <span class="info-value">{{exam_center}}</span>
                    </div>
                </div>

                <div class="photo-frame">
                    <img src="{{student_image}}" alt="{{student_name}}" />
                </div>
            </div>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th style="text-align:left; padding-left:10px;">Subject</th>
                            <th>Written Date</th>
                            <th>Written Time</th>
                            <th>Oral Date</th>
                            <th>Oral Time</th>
                            <th>Signature</th>
                        </tr>
                    </thead>
                    <tbody>
                        {{routine_tbody}}
                    </tbody>
                </table>
            </div>

            <div class="footnote">
                <span class="footnote-label">Note:</span>
                <span class="footnote-value">All outstanding dues must be fully settled in order to be eligible to sit
                    for the examination.</span>
            </div>

            <div class="footer">
                <div class="signature-block">
                    <div class="sign-line">Exam Controller</div>
                </div>
                <div class="signature-block">
                    <img src="{{principal_sign}}" class="signature-img" alt="{{principal_name}}">
                    <div class="sign-line">Principal Signature</div>
                </div>
            </div>
        </div>
    </div>
</div>
HTML;

// ---------------------------------------------------------------------
// Build each admit card
// ---------------------------------------------------------------------

$all_cards = '';
$skip_count = 0;

foreach ($student_ids as $student_id) {

    $content = $card;
    $student = getStudentInfo($pdo, $student_id);

    if (!$student) {
        $skip_count++;
        continue; // Skip if student not found
    }

    // Fetch specific admit card details and verify it's for the student's class
    $stmt = $pdo->prepare("
        SELECT ea.*, e.exam_name, e.exam_date
        FROM exam_admit_releases ea
        JOIN exams e ON ea.exam_id = e.id
        WHERE ea.id = ? AND ea.class_id = ?
    ");
    $stmt->execute([$admit_id, $student['class_id']]);
    $admit_card = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admit_card) {
        $skip_count++;
        continue; // Skip if admit card not valid for this student
    }

    // Fetch exam routine for this specific admit card
    $stmt = $pdo->prepare("
        SELECT er.*, sub.subject_name 
        FROM exam_routines er
        JOIN subjects sub ON er.subject_id = sub.id
        WHERE er.exam_id = ? AND er.class_id = ?
        ORDER BY 
            COALESCE(er.theory_exam_date, er.practical_exam_date) ASC, 
            COALESCE(er.theory_start_time, er.practical_start_time) ASC
    ");
    $stmt->execute([$admit_card['exam_id'], $student['class_id']]);
    $exam_routine = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $routine_tbody = '';

    foreach ($exam_routine as $routine) {
        $theory_start_time = $routine['theory_start_time'] ? date("h:i", strtotime($routine['theory_start_time'])) : '';
        $theory_end_time = $routine['theory_end_time'] ? date("h:i", strtotime($routine['theory_end_time'])) : '';

        $practical_start_time = $routine['practical_start_time'] ? date("h:i", strtotime($routine['practical_start_time'])) : '';
        $practical_end_time = $routine['practical_end_time'] ? date("h:i", strtotime($routine['practical_end_time'])) : '';

        $theory_exam_date = $routine['theory_exam_date'] ? date('d M Y', strtotime($routine['theory_exam_date'])) : '-';
        $practical_exam_date = $routine['practical_exam_date'] ? date('d M Y', strtotime($routine['practical_exam_date'])) : '-';

        $routine_tbody .=
            '<tr>
                <td class="subject-col">' . $routine['subject_name'] . '</td>
                <td>' . $theory_exam_date . '</td>
                <td>' . $theory_start_time . '-' . $theory_end_time . '</td>
                <td>' . $practical_exam_date . '</td>
                <td>' . $practical_start_time . '-' . $practical_end_time . '</td>
                <td></td>
            </tr>';
    }

    $exam_name = $admit_card['exam_name'] ?? '-';
    $student_name = $student['name'] ?? '-';
    $father_name = $student['father_name'] ?? '-';
    $class = $student['class_name'] . " (" . $student['section_name'] . ")";
    $roll_no = $student['roll_no'] ?? '-';
    $student_address = $student['address'] ?? '-';
    $student_dp = $student_image . $student['student_image'];

    $content = str_replace('{{school_logo}}', $school_logo, $content);
    $content = str_replace('{{school_name}}', $school_name, $content);
    $content = str_replace('{{school_address}}', $school_address, $content);
    $content = str_replace('{{exam_name}}', $exam_name, $content);
    $content = str_replace('{{exam_center}}', $exam_center, $content);
    $content = str_replace('{{student_name}}', $student_name, $content);
    $content = str_replace('{{father_name}}', $father_name, $content);
    $content = str_replace('{{class}}', $class, $content);
    $content = str_replace('{{roll_no}}', $roll_no, $content);
    $content = str_replace('{{student_address}}', $student_address, $content);
    $content = str_replace('{{student_image}}', $student_dp, $content);
    $content = str_replace('{{routine_tbody}}', $routine_tbody, $content);
    $content = str_replace('{{principal_sign}}', $principal_sign, $content);
    $content = str_replace('{{principal_name}}', $principal_name, $content);

    $all_cards .= $content;
}

$main_html = str_replace('{{admit_cards}}', $all_cards, $main_html);

// Output the HTML
echo $main_html;