<?php
ini_set('memory_limit', '512M'); // or '1G' for very large files
include_once(__DIR__ . "/../../includes/auth-check.php");
include_once(__DIR__ . "/../../includes/browsershot.php");

$log_directory = __DIR__ . '/../../assets/logs/';
if (!is_dir($log_directory)) {
    mkdir($log_directory, 0755, true);
}

// Check for permission
if (!hasPermission(PERM_MANAGE_STUDENTS)) {
    die("You do not have permission to perform this action.");
}

if (!isset($_GET['student_ids']) || empty($_GET['student_ids'])) {
    die("Student IDs are required");
}

if (!isset($_GET['session_year']) || empty($_GET['session_year'])) {
    die("Session Year is required");
}

$student_ids = explode(',', $_GET['student_ids']);
$session_year = $_GET['session_year'];

// Fetch admission form settings
$stmt = $pdo->prepare("SELECT * FROM settings_admission_form LIMIT 1");
$stmt->execute();
$admission_form_settings = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admission_form_settings) {
    die("Admission form settings not found");
}

$form_design = "design1"; // Default form design
if ($admission_form_settings['admission_form_design']) {
    $form_design = strtolower(str_replace("-", "", $admission_form_settings['admission_form_design']));
}

// Load the HTML template
$content_template = file_get_contents("../../assets/templates/admission-form-templates/{$form_design}/content.html");
// Load container template
$form_template = file_get_contents("../../assets/templates/admission-form-templates/{$form_design}/form.html");

// School information
/** @var array $schoolInfo */
$school_name = $schoolInfo['name'];
$school_address = $schoolInfo['address'];
$school_phone = $schoolInfo['phone'];
$school_email = $schoolInfo['email'];

$school_logo_path = '../../uploads/school/logo-square.png';
$school_logo_base64 = imageToBase64($school_logo_path);

$principle_sign_path = '../../uploads/school/principle_sign.png';
$principle_sign_base64 = imageToBase64($principle_sign_path);

$admission_forms = "";

$first_student_class_id = null;

// Process each student ID
foreach ($student_ids as $student_id) {
    // Fetch student details
    $stmt = $pdo->prepare("SELECT s.*, c.class_name FROM students s JOIN classes c ON s.class_id = c.id WHERE s.student_id = ?");
    $stmt->execute([$student_id]);
    $student_info = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student_info) {
        continue; // Skip if student not found
    }

    // Set the first student's class ID for reference
    if ($first_student_class_id === null) {
        $first_student_class_id = $student_info['class_id'];
    }

    // Now check if all students belong to the same class
    if ($student_info['class_id'] !== $first_student_class_id) {
        die("All selected students must belong to the same class for bulk admission form generation.");
    }

    // Student Photo Base64
    $student_photo_path = '../../uploads/students/' . $student_info['student_image'];
    $student_photo_base64 = imageToBase64($student_photo_path);

    // Define placeholders
    $student_name = $student_info['name'];
    $gender = $student_info['gender'];
    $date_of_birth = $student_info['date_of_birth'];
    $registration_no = $student_info['registration_no'];
    $class_name = $student_info['class_name'];
    $father_name = $student_info['father_name'];
    $mother_name = $student_info['mother_name'];
    $father_occupation = $student_info['father_occupation'];
    $mother_occupation = $student_info['mother_occupation'];
    $address = $student_info['address'];
    $phone_number = $student_info['phone_number'];
    $alternate_phone_number = $student_info['alternate_phone_number'];
    $admission_date = $student_info['admission_date'];

    // Replace placeholders in the template
    $content_html = $content_template;
    $placeholders = [
        '{{school_logo}}'          => $school_logo_base64, // URL or base64 encoded image
        '{{school_name}}'          => safe_htmlspecialchars($school_name),
        '{{school_address}}'       => safe_htmlspecialchars($school_address),
        '{{school_phone}}'         => safe_htmlspecialchars($school_phone),
        '{{school_email}}'         => safe_htmlspecialchars($school_email),

        '{{student_name}}'        => safe_htmlspecialchars($student_name),
        '{{gender}}'              => safe_htmlspecialchars($gender),
        '{{date_of_birth}}'       => safe_htmlspecialchars($date_of_birth),
        '{{registration_no}}'     => safe_htmlspecialchars($registration_no),
        '{{session_year}}'        => safe_htmlspecialchars($session_year),
        '{{admission_class}}'     => safe_htmlspecialchars($class_name),
        '{{student_id}}'          => safe_htmlspecialchars($student_id),
        '{{student_photo}}'       => $student_photo_base64, // URL or base64 image

        '{{father_name}}'         => safe_htmlspecialchars($father_name),
        '{{mother_name}}'         => safe_htmlspecialchars($mother_name),
        '{{permanent_address}}'   => safe_htmlspecialchars($address),

        '{{admission_date}}'      => safe_htmlspecialchars($admission_date),
        '{{principal_sign}}'      => $principle_sign_base64, // URL or base64 image

        '{{father_occupation}}'   => safe_htmlspecialchars($father_occupation),
        '{{mother_occupation}}'   => safe_htmlspecialchars($mother_occupation),
        '{{father_phone}}'        => safe_htmlspecialchars($phone_number),
        '{{mother_phone}}'        => safe_htmlspecialchars($alternate_phone_number)
    ];


    foreach ($placeholders as $key => $value) {
        $content_html = str_replace($key, $value, $content_html);
    }

    $admission_forms .= $content_html;
}

$all_html_content = str_replace('{{form_contents}}', $admission_forms, $form_template);

// Apply theme colors
$all_html_content = str_replace(
    [
        '{{primary_theme_color}}',
        '{{secondary_theme_color}}',
        '{{dark_theme_color}}',
        '{{light_theme_color}}',
        '{{background_color}}',
        '{{school_name_text_color}}',
        '{{school_address_text_color}}'
    ],
    [
        $admission_form_settings['primary_theme_color'],
        $admission_form_settings['secondary_theme_color'],
        $admission_form_settings['dark_theme_color'],
        $admission_form_settings['light_theme_color'],
        $admission_form_settings['background_color'],
        $admission_form_settings['school_name_text_color'],
        $admission_form_settings['school_address_text_color']
    ],
    $all_html_content
);

// For debugging: Save the combined HTML to a file
file_put_contents($log_directory . 'admission_forms_output.html', $all_html_content);

// Export or print the HTML content
if ($admission_form_settings['fast_generation']) {
    header("Content-Type: text/html; charset=UTF-8");
    echo $all_html_content; // For testing purposes, output the HTML
} else {
    $output_file_name = "admission_forms_" . date('Ymd_His');
    generatePDF($all_html_content, $output_file_name);
}