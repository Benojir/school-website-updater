<?php
ini_set('memory_limit', '512M'); // or '1G' for very large files
include_once(__DIR__ . "/../../includes/auth-check.php");

/** @var PDO $pdo */

$admit_id = $_REQUEST['admit_id'] ?? '';
$student_ids = $_REQUEST['student_ids'] ?? '';

if (empty($admit_id)) {
    die("Admit Card ID is required");
}

if (empty($student_ids)) {
    die("Student ID(s) are required");
}

$stmt = $pdo->prepare("SELECT * FROM settings_admit_card LIMIT 1");
$stmt->execute();
$settings = $stmt->fetch(PDO::FETCH_ASSOC);

$admit_card_design = $settings['admit_card_design'] ?? 'design-1';

header("Location: " . BASE_URL . "/api/download/admit-card/{$admit_card_design}.php?admit_id={$admit_id}&student_ids={$student_ids}");