<?php
ini_set('memory_limit', '512M'); // or '1G' for very large files
include_once(__DIR__ . "/../../includes/auth-check.php");

/** @var PDO $pdo */

$admit_id = $_REQUEST['admit_id'] ?? '';
$student_ids = $_REQUEST['student_ids'] ?? '';

if (empty($admit_id)) {
    die("Admit Card ID is required");
}

if (empty($student_ids)) {
    die("Student ID(s) are required");
}

$student_ids = explode(',', $student_ids);

// School information
$school_name = $schoolInfo['name'];
$school_address = $schoolInfo['address'];
$principal_name = $schoolInfo['principal_name'];
$school_logo = BASE_URL . '/uploads/school/logo-square.png';
$principal_sign = BASE_URL . '/uploads/school/principle_sign.png';
$student_image = BASE_URL . '/uploads/students/';

$main_html = file_get_contents(__DIR__ . "/../../assets/templates/admit-cards/design-1/main.html");
$card = file_get_contents(__DIR__ . "/../../assets/templates/admit-cards/design-1/content.html");

$all_cards = '';
$skip_count = 0;

foreach ($student_ids as $student_id) {

    $content = $card;
    $student = getStudentInfo($pdo, $student_id);

    if (!$student) {
        $skip_count++;
        continue; // Skip if student not found
    }

    // Fetch specific admit card details and verify it's for the student's class
    $stmt = $pdo->prepare("
        SELECT ea.*, e.exam_name, e.exam_date
        FROM exam_admit_releases ea
        JOIN exams e ON ea.exam_id = e.id
        WHERE ea.id = ? AND ea.class_id = ?
    ");
    $stmt->execute([$admit_id, $student['class_id']]);
    $admit_card = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admit_card) {
        $skip_count++;
        continue; // Skip if admit card not valid for this student
    }

    // Fetch exam routine for this specific admit card
    $stmt = $pdo->prepare("
        SELECT er.*, sub.subject_name 
        FROM exam_routines er
        JOIN subjects sub ON er.subject_id = sub.id
        WHERE er.exam_id = ? AND er.class_id = ?
        ORDER BY er.theory_exam_date, er.theory_start_time
    ");
    $stmt->execute([$admit_card['exam_id'], $student['class_id']]);
    $exam_routine = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $routine_tbody = '';

    foreach ($exam_routine as $routine) {
        $theory_start_time = $routine['theory_start_time'] ? date("h:i", strtotime($routine['theory_start_time'])) : '';
        $theory_end_time = $routine['theory_end_time'] ? date("h:i", strtotime($routine['theory_end_time'])) : '';

        $practical_start_time = $routine['practical_start_time'] ? date("h:i", strtotime($routine['practical_start_time'])) : '';
        $practical_end_time = $routine['practical_end_time'] ? date("h:i", strtotime($routine['practical_end_time'])) : '';

        $theory_exam_date = $routine['theory_exam_date'] ? date('d M Y', strtotime($routine['theory_exam_date'])) : '-';
        $practical_exam_date = $routine['practical_exam_date'] ? date('d M Y', strtotime($routine['practical_exam_date'])) : '-';

        $routine_tbody .=
            '<tr>
                <td class="subject-col">' . $routine['subject_name'] . '</td>
                <td>' . $theory_exam_date . '</td>
                <td>' . $theory_start_time . '-' . $theory_end_time . '</td>
                <td>' . $practical_exam_date . '</td>
                <td>' . $practical_start_time . '-' . $practical_end_time . '</td>
                <td></td>
            </tr>';
    }

    $exam_name = $admit_card['exam_name'] ?? '-';
    $student_name = $student['name'] ?? '-';
    $father_name = $student['father_name'] ?? '-';
    $class = $student['class_name'] . " (" . $student['section_name'] . ")";
    $roll_no = $student['roll_no'] ?? '-';
    $student_address = $student['address'] ?? '-';
    $student_dp = $student_image . $student['student_image'];

    $content = str_replace('{{school_logo}}', $school_logo, $content);
    $content = str_replace('{{school_name}}', $school_name, $content);
    $content = str_replace('{{school_address}}', $school_address, $content);
    $content = str_replace('{{exam_name}}', $exam_name, $content);
    $content = str_replace('{{student_name}}', $student_name, $content);
    $content = str_replace('{{father_name}}', $father_name, $content);
    $content = str_replace('{{class}}', $class, $content);
    $content = str_replace('{{roll_no}}', $roll_no, $content);
    $content = str_replace('{{student_address}}', $student_address, $content);
    $content = str_replace('{{student_image}}', $student_dp, $content);
    $content = str_replace('{{routine_tbody}}', $routine_tbody, $content);
    $content = str_replace('{{principal_sign}}', $principal_sign, $content);
    $content = str_replace('{{principal_name}}', $principal_name, $content);

    $all_cards .= $content;
}

$main_html = str_replace('{{admit_cards}}', $all_cards, $main_html);

// Output the HTML
echo $main_html;
