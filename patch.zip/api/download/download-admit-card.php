<?php
ini_set('memory_limit', '512M'); // or '1G' for very large files
include_once(__DIR__ . "/../../includes/auth-check.php");
require_once __DIR__ . '/../../includes/exam-document-download.php';
$documentRequest = examDocumentRequireDownload('admit');

/** @var PDO $pdo */

$admit_id = $_REQUEST['admit_id'] ?? '';
$exam_id = $_REQUEST['exam_id'] ?? '';
$student_ids = $_REQUEST['student_ids'] ?? '';

if (empty($admit_id) && empty($exam_id)) {
    die("Admit Card ID is required");
}

if (empty($student_ids)) {
    die("Student ID(s) are required");
}

$stmt = $pdo->prepare("SELECT * FROM settings_admit_card LIMIT 1");
$stmt->execute();
$settings = $stmt->fetch(PDO::FETCH_ASSOC);

$admit_card_design = $settings['admit_card_design'] ?? 'design-1';
if (!in_array($admit_card_design, ['design-1', 'design-2'], true)) $admit_card_design = 'design-1';

header('Location: ' . BASE_URL . '/api/download/admit-card/' . $admit_card_design . '.php?' . examDocumentRedirectParams($documentRequest));
exit;
