<?php
ini_set('memory_limit', '512M'); // or '1G' for very large files
include_once(__DIR__ . "/../../includes/auth-check.php");

$header_html_path = __DIR__ . "/../../assets/templates/ranking-list-templates/student/header.html";
$content_html_path = __DIR__ . "/../../assets/templates/ranking-list-templates/student/content.html";
$footer_html_path = __DIR__ . "/../../assets/templates/ranking-list-templates/student/footer.html";
$style_css_path = __DIR__ . "/../../assets/templates/ranking-list-templates/student/style.css";

// Fetch marksheet settings
$stmt = $pdo->prepare("SELECT * FROM settings_marksheet LIMIT 1");
$stmt->execute();
$marksheet_settings = $stmt->fetch(PDO::FETCH_ASSOC);

$exam_id = $_REQUEST['exam_id'] ?? 0;
$class_id = $_REQUEST['class_id'] ?? 0;
$section_id = $_REQUEST['section_id'] ?? null;
$include_minor_subjects_marks = $marksheet_settings['include_minor_subjects_marks'];

// Validate inputs
if (!$exam_id || !$class_id) {
    echo "<center><h1>Invalid request</h1></center>";
    exit;
}

// Fetch exam name
$stmt = $pdo->prepare("SELECT exam_name FROM exams WHERE id = ?");
$stmt->execute([$exam_id]);
$exam_name = $stmt->fetchColumn();

// Fetch class name
$stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
$stmt->execute([$class_id]);
$class_name = $stmt->fetchColumn();

// Validate inputs
if (empty($class_name) || empty($exam_name)) {
    echo "<center><h1>Invalid request</h1></center>";
    exit;
}

// Fetch total students in class
$stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE class_id = ?");
$stmt->execute([$class_id]);
$total_students = $stmt->fetchColumn();

$top_rankers = getTopRankersForSingleMarksheet($pdo, $class_id, $exam_id, $include_minor_subjects_marks, $section_id, $total_students);

// 1. Prepare Base Templates
$header_html = file_get_contents($header_html_path);
$footer_html = file_get_contents($footer_html_path);
$style_css = file_get_contents($style_css_path);

// Load the content template once
$content_template_raw = file_get_contents($content_html_path);

// 2. School Data & Global Replacements
// Perform replacements that are identical for every page (School Info, Exam Name)
$school_logo_path = '../../uploads/school/logo-square.png';
$school_logo_base64 = imageToBase64($school_logo_path); // Ensure this function exists
$school_name = $schoolInfo['name']; // Ensure $schoolInfo is available
$school_address = $schoolInfo['address'];

// Inject CSS into Header
$header_html = str_replace('<link rel="stylesheet" href="style.css">', "<style>" . $style_css . "</style>", $header_html);

// Pre-fill static data in the content template to save processing time in the loop
$content_template_ready = str_replace(
    ['{{school_logo_base64}}', '{{school_name}}', '{{school_address}}', '{{exam_name}}'],
    [$school_logo_base64, $school_name, $school_address, $exam_name],
    $content_template_raw
);

// 3. Pagination Logic
$max_students_per_page = 35;
$total_students_count = count($top_rankers);
$total_pages = ($total_students_count > 0) ? ceil($total_students_count / $max_students_per_page) : 1;
$full_body_html = "";

// 4. Loop to Generate Pages
for ($page = 1; $page <= $total_pages; $page++) {
    
    // Calculate start and length for array slicing
    $offset = ($page - 1) * $max_students_per_page;
    $chunk = array_slice($top_rankers, $offset, $max_students_per_page);
    
    $rows_html = "";
    $serial_counter = $offset + 1;

    foreach ($chunk as $student) {

        // Build Table Row
        $rows_html .= "<tr>";
        $rows_html .= "<td>" . $serial_counter . "</td>"; // #
        $rows_html .= "<td>" . getOrdinal($student['rank']) . "</td>"; // Rank
        $rows_html .= "<td>" . safe_htmlspecialchars($class_name) . "</td>"; // Class
        $rows_html .= "<td>" . safe_htmlspecialchars($student['section_name'] ?? '') . "</td>"; // Section
        $rows_html .= "<td>" . safe_htmlspecialchars($student['roll_no'] ?? '') . "</td>"; // Roll No
        $rows_html .= "<td>" . safe_htmlspecialchars($student['name']) . "</td>"; // Name
        $rows_html .= "<td>" . (float) round($student['percentage'], 2) . "%</td>"; // Percentage
        $rows_html .= "<td>" . (float) round($student['obtained_marks'] ?? 0, 2) . "</td>"; // Obtained
        $rows_html .= "</tr>";
        
        $serial_counter++;
    }

    // Fill empty rows to maintain layout height? (Optional: Remove if not needed)
    while ($serial_counter <= ($offset + $max_students_per_page)) {
        $rows_html .= "<tr><td>&nbsp;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>";
        $serial_counter++;
    }

    // Insert rows into the template for this specific page
    $current_page_html = str_replace('{{student_list}}', $rows_html, $content_template_ready);
    
    // Append this page to the main body
    $full_body_html .= $current_page_html;
}

// 5. Output Final HTML
echo $header_html;
echo $full_body_html;
echo $footer_html;
?>