<?php
include_once(__DIR__ . "/../../../includes/auth-check.php");

if (!isset($_GET['exam_ids']) || !isset($_GET['student_ids'])) {
    die("Required fields are missing.");
}

$exam_ids = $_GET['exam_ids'];
$student_ids = $_GET['student_ids'];
$class_id = $_GET['class_id'] ?? null;

// Fetch marksheet settings
$stmt = $pdo->prepare("SELECT * FROM settings_marksheet LIMIT 1");
$stmt->execute();
$marksheet_settings = $stmt->fetch(PDO::FETCH_ASSOC);

$marksheet_system = $marksheet_settings['marksheet_system'] ?? "system-1";

header('Location: combined/' . $marksheet_system . '.php?exam_ids=' . $exam_ids . '&student_ids=' . $student_ids . '&class_id=' . $class_id);
exit;
