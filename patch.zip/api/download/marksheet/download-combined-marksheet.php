<?php
include_once(__DIR__ . "/../../../includes/auth-check.php");
require_once __DIR__ . '/../../../includes/exam-document-download.php';
$documentRequest = examDocumentRequireDownload('combined');

if (!isset($_GET['exam_ids']) || !isset($_GET['student_ids'])) {
    die("Required fields are missing.");
}

$exam_ids = $_GET['exam_ids'];
$student_ids = $_GET['student_ids'];
$class_id = $_GET['class_id'] ?? null;

// Fetch marksheet settings
$stmt = $pdo->prepare("SELECT * FROM settings_marksheet LIMIT 1");
$stmt->execute();
$marksheet_settings = $stmt->fetch(PDO::FETCH_ASSOC);

$marksheet_design = $marksheet_settings['combined_marksheet_design'] ?? "design-1";
if (!in_array($marksheet_design, ['design-1', 'design-2', 'design-3', 'design-4'], true)) $marksheet_design = 'design-1';

header('Location: combined/' . $marksheet_design . '.php?' . examDocumentRedirectParams($documentRequest));
exit;
