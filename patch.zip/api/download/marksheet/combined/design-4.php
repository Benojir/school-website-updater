<?php
/** @var array $schoolInfo */
ini_set('memory_limit', '512M'); 
ob_start();
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/browsershot.php");

$log_directory = __DIR__ . '/../../../../assets/logs/';
if (!is_dir($log_directory)) {
    mkdir($log_directory, 0755, true);
}

if (!hasPermission(PERM_MANAGE_RESULTS)) {
    die("You do not have permission to perform this action.");
}

if (!isset($_GET['exam_ids']) || !isset($_GET['student_ids'])) {
    die("Required fields are missing.");
}

$exam_ids = explode(',', $_GET['exam_ids']);
$student_ids = explode(',', $_GET['student_ids']);
$class_id = $_GET['class_id'] ?? null; // Added for Ranking

if (count($exam_ids) < 1 || count($student_ids) < 1) {
    die("Please select at least one exam and one student.");
}

if (empty($class_id)) {
   die("Class ID is required for ranking.");
}

$exam_ids = array_values(array_unique(array_filter(array_map('intval', $exam_ids), fn($id) => $id > 0)));
sort($exam_ids);
if (empty($exam_ids)) {
    die('Please select at least one valid exam.');
}
$yearStmt = $pdo->prepare('SELECT DISTINCT academic_year FROM exams WHERE id IN (' . implode(',', array_fill(0, count($exam_ids), '?')) . ')');
$yearStmt->execute($exam_ids);
$examYears = $yearStmt->fetchAll(PDO::FETCH_COLUMN);
$knownYears = array_values(array_filter($examYears, static fn($year) => $year !== null && $year !== ''));
if (count($knownYears) > 1 || (count($knownYears) === 1 && count($examYears) > 1)) {
    exit('Select exams from one academic year. Assign missing exam years in Manage Examinations first.');
}

$stmt = $pdo->prepare("SELECT * FROM settings_marksheet LIMIT 1");
$stmt->execute();
$marksheet_settings = $stmt->fetch(PDO::FETCH_ASSOC);

$school_name = $schoolInfo['name'];
$school_address = $schoolInfo['address'];
$school_contacts = 'Phone: ' . $schoolInfo['phone'] . ' | ' . $schoolInfo['alternate_phone'];

$school_logo_path = '../../../../uploads/school/logo-square.png';
$principal_sign_path = '../../../../uploads/school/principle_sign.png';
$school_logo_base64 = imageToBase64($school_logo_path);
$principal_signature_base64 = imageToBase64($principal_sign_path);

$skipped_students = [];
$combined_positions = [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Marksheet</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
    <style>
@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&family=Tinos:wght@700&display=swap');

@page {
    size: A4 portrait;
    margin: 0;
}

:root {
    --theme-primary: <?= safe_htmlspecialchars($marksheet_settings['primary_theme_color']) ?>;
    --theme-dark: <?= safe_htmlspecialchars($marksheet_settings['dark_theme_color']) ?>; 
    --theme-light: <?= safe_htmlspecialchars($marksheet_settings['light_theme_color']) ?>;
    --background-color: <?= safe_htmlspecialchars($marksheet_settings['background_color']) ?>;
    --school-name-text-color: <?= safe_htmlspecialchars($marksheet_settings['school_name_text_color']) ?>;
    --school-address-text-color: <?= safe_htmlspecialchars($marksheet_settings['school_address_text_color']) ?>;
}

html, body {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

*, *::before, *::after {
    box-sizing: inherit;
}

.marksheet-container {
    font-family: 'Roboto', sans-serif;
    margin: 0;
    color: #333;
    background-color: var(--background-color);
    width: 210mm;
    height: 297mm;
    padding: 7mm;
    break-after: always;
}

.marksheet {
    display: flex;
    flex-direction: column;
    border: 1.5px solid var(--theme-dark);
    padding: 3mm;
    position: relative;
    width: 100%;
    height: 100%;
    background-color: var(--background-color);
    box-shadow: 0 0 15px rgba(58, 74, 109, 0.15);
    border-radius: 6px;
    overflow: hidden;
}

/* Header */
.header {
    width: 100%;
    height: 25mm;
    background: linear-gradient(135deg, var(--theme-primary) 0%, var(--theme-dark) 100%);
    display: flex;
    padding: 3mm;
    align-items: center;
    justify-content: center;
    gap: 0;
    border-radius: 4px;
}

.header img {
    background: white;
    width: 16mm;
    height: 16mm;
    border: 2px solid white;
    border-radius: 50%;
    object-fit: cover;
}

.school-name-container {
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 1mm;
}

.school-name-container h1 {
    margin: 0;
    font-size: 1.6rem;
    text-transform: uppercase;
    text-align: center;
    font-weight: 700;
    color: var(--school-name-text-color);
    letter-spacing: 0.5px;
}

.school-name-container p {
    font-size: 0.85rem;
    margin:0;
    color: var(--school-address-text-color);
    text-align: center;
}

/* Student Info */
.student-info {
    height: 25mm;
    background: var(--theme-light);
    border-radius: 4px;
    border: 1px solid #d6e0f5;
    padding: 2mm 3mm;
    margin-top: 2mm;
    display: flex;
    justify-content: space-between;
    align-items: center;
    overflow: hidden;
}

.student-info .details-left {
    flex-grow: 1;
}

.student-info .details-left table {
    border-collapse: collapse;
    width: 100%;
    text-align: left;
    font-size: 13px;
}

.student-info .details-left table th {
    color: var(--theme-dark);
    font-weight: 700;
    padding: 2px 8px 2px 0;
    white-space: nowrap;
}

.student-info .details-left table td {
    padding-right: 10px;
    color: #222;
    font-weight: 500;
}

.student-info .photo-right {
    width: 18mm;
    height: 100%;
    display: flex;
    justify-content: flex-end;
}

.student-info .photo-right .photo {
    height: 100%;
    border: 1.5px solid var(--theme-dark);
    border-radius: 4px;
    overflow: hidden;
    background: white;
}

.student-info .photo-right img {
    height: 100%;
    width: 100%;
    object-fit: cover;
}

/* Matrix Table Section */
.marks-tables-container {
    width: 100%;
    margin-top: 2mm;
    flex-grow: 1;
}

.marks-table {
    width: 100%;
    height: 100%;
    border-radius: 5px;
    border: 1px solid #c0ccdf;
    overflow: hidden;
}

.marks-table-exam-name {
    width: 100%;
    text-align: center;
    padding: 1.5mm 0;
    font-weight: bold;
    font-size: 13px;
    background: linear-gradient(to right, var(--theme-primary) 0%, var(--theme-primary) 70%, var(--theme-dark) 100%);
    color: white;
}

.matrix-table-wrapper {
    width: 100%;
    flex-grow: 1;
}

.matrix-table {
    width: 100%;
    height: 100%;
    border-collapse: collapse;
    font-size: 12px; /* Increased font size */
}

.matrix-table th, .matrix-table td {
    border: 1px solid #cbd5e1;
    padding: 4.5px 2px;
    text-align: center;
    vertical-align: middle;
}

.matrix-table th {
    background-color: #f1f5f9;
    color: var(--theme-dark);
    font-weight: bold;
}

.matrix-table .exam-header {
    background-color: #e2e8f0;
}

.matrix-table .overall-header, .matrix-table .overall-cell {
    background-color: #ecfdf5;
}

.matrix-table .subject-col {
    text-align: left;
    font-weight: bold;
    padding-left: 6px;
    width: auto; 
}

.matrix-table tr:nth-child(even) {
    background-color: #f8fafc;
}

/* Bottom Tables (Grading & Summary) */
.bottom-tables {
    display: flex;
    justify-content: space-between;
    gap: 2mm;
    margin-top: 2mm;
    overflow: hidden;
    height: 73mm;
}

.grading-system, .result-summary {
    width: 100%;
    border: 1px solid #c0ccdf;
    border-radius: 5px;
    background: var(--theme-light);
    overflow: hidden;
}

.table-heading {
    background: var(--theme-primary);
    color: white;
    text-align: center;
    font-size: 12px;
    font-weight: bold;
    padding: 2.5px 0;
}

.inner-table {
    width: 100%;
    flex-grow: 1;
    border-collapse: collapse;
    font-size: 12px; /* Increased font size */
}

.inner-table th, .inner-table td {
    padding: 4px 6px;
    border-bottom: 1px solid #cbd5e1;
    border-right: 1px solid #cbd5e1;
}

.inner-table th {
    text-align: left;
    color: var(--theme-dark);
    font-weight: 700;
}

.inner-table tr:last-child th, .inner-table tr:last-child td {
    border-bottom: none;
}

.marks-table, .grading-system, .result-summary {
    width: 100%;
    /* display এবং flex-direction যুক্ত করুন */
    display: flex;
    flex-direction: column;
    border: 1px solid #c0ccdf;
    border-radius: 5px;
    background: var(--theme-light);
    overflow: hidden;
}

/* Signatures */
.signatures {
    width: 100%;
    height: 25mm;
    margin-top: 2mm;
    font-size: 13px;
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    padding: 0;
    align-items: end;
}

.signatures .sign-box {
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    align-items: center;
    width: 100%;
}

.signatures img {
    max-width: 35mm;
    max-height: 12mm; /* Prevents large signature images from taking over */
    object-fit: contain;
    margin-bottom: 2px;
}

.signatures p {
    text-align: center;
    margin: 0;
    padding-top: 3px;
    border-top: 1.5px solid var(--theme-dark);
    border-bottom: 0;
    border-left: 0;
    border-right: 0;
    width: 85%;
    font-weight: 600;
    color: var(--theme-dark);
    border-style: dashed;
}
.matrix-table .totals-row th,
.matrix-table .totals-row td {
    background-color: var(--theme-light);
    color: var(--theme-dark);
    font-weight: bold;
}

.matrix-table .totals-row .subject-col {
    font-size: 11px;
}

.matrix-table .totals-row .overall-cell {
    background-color: #ecfdf5;
}
    </style>
</head>
<body>
<?php
foreach ($student_ids as $student_id) {
    $stmt = $pdo->prepare("
        SELECT s.*, sec.section_name, c.class_name
        FROM students s
        LEFT JOIN sections sec ON s.section_id = sec.id
        LEFT JOIN classes c ON s.class_id = c.id
        WHERE s.student_id = ?
    ");
    $stmt->execute([$student_id]);
    $student_info = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student_info) continue;

    if ($student_info['student_image'] && schoolPhotoExists("../../../../uploads/students/" . $student_info['student_image'])) {
        $student_photo_base64 = imageToBase64("../../../../uploads/students/" . $student_info['student_image']);
    } else {
        $student_photo_base64 = imageToBase64("../../../../uploads/students/default_student_dp.jpg");
    }

    $matrix_data = [];
    $exam_headers = [];
    $first_exam_class_id = null;
    $first_exam_section_id = null;
    $should_skip_this_student = false;
    $first_exam_excluded_subjects = [];
    $exam_count = 1;

    $class_name = null;
    $section_name = null;
    $roll_number = null;

    foreach ($exam_ids as $exam_id) {
        $stmt = $pdo->prepare("
            SELECT r.id AS result_id, r.student_id, r.exam_id AS result_exam_id, r.class_id AS result_class_id, r.section_id AS result_section_id, r.result_roll_no, e.exam_name, c.class_name, sec.section_name
            FROM results r
            JOIN exams e ON r.exam_id = e.id
            JOIN classes c ON r.class_id = c.id
            LEFT JOIN sections sec ON r.section_id = sec.id
            WHERE r.student_id = ? AND r.exam_id = ?
        ");
        $stmt->execute([$student_id, $exam_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$result) continue;

        if (empty($class_name)) $class_name = $result['class_name'];
        if (empty($section_name)) $section_name = $result['section_name'];
        if (empty($roll_number)) $roll_number = $result['result_roll_no'];
        
        if (empty($first_exam_class_id)) {
            $first_exam_class_id = $result['result_class_id'];
            $first_exam_section_id = $result['result_section_id'];
        } else if ($first_exam_class_id !== $result['result_class_id']) {
            $should_skip_this_student = true;
            break;
        }
        
        $exam_headers[$exam_id] = $result['exam_name'];
        
        $routineStmt = $pdo->prepare("SELECT * FROM exam_routines WHERE exam_id = ? AND class_id = ?");
        $routineStmt->execute([$result['result_exam_id'], $student_info['class_id']]);
        $exam_routine = $routineStmt->fetchAll(PDO::FETCH_ASSOC);
        
        $routine_lookup = [];
        foreach ($exam_routine as $routine) {
            $routine_lookup[$routine['subject_id']] = [
                'has_written' => ($routine['theory_marks'] != 0),
                'has_oral'    => ($routine['practical_marks'] != 0),
            ];
        }

        $stmt = $pdo->prepare("
            SELECT sm.*, sub.subject_name, sub.subject_type
            FROM subject_marks sm
            JOIN subjects sub ON sm.subject_id = sub.id
            WHERE sm.result_id = ? ORDER BY sub.marksheet_order_by
        ");
        $stmt->execute([$result['result_id']]);
        $subject_marks = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($subject_marks as $subject) {
            if ($exam_count === 1 && $subject['is_excluded']) {
                $first_exam_excluded_subjects[] = $subject['subject_id'];
            }
            if (in_array($subject['subject_id'], $first_exam_excluded_subjects)) {
                continue;
            }

            $sub_name = $subject['subject_name'];
            if (!isset($matrix_data[$sub_name])) {
                $matrix_data[$sub_name] = [
                    'type' => $subject['subject_type'],
                    'exams' => [],
                    'overall' => ['theory' => 0, 'practical' => 0, 'total' => 0, 'obtained' => 0, 'count' => 0]
                ];
            }
            
            $hasWrittenExam = true;
            $hasOralExam    = true;
            if (isset($routine_lookup[$subject['subject_id']])) {
                $hasWrittenExam = $routine_lookup[$subject['subject_id']]['has_written'];
                $hasOralExam    = $routine_lookup[$subject['subject_id']]['has_oral'];
            }
            
            $matrix_data[$sub_name]['exams'][$exam_id] = [
                'theory'          => $subject['theory_marks'],
                'practical'       => $subject['practical_marks'],
                'obtained'        => $subject['obtained_marks'],
                'total_marks'     => $subject['total_marks'],
                'is_absent'       => $subject['is_absent'],
                'has_written_exam' => $hasWrittenExam,
                'has_oral_exam'    => $hasOralExam,
            ];
            
            $matrix_data[$sub_name]['overall']['theory']    += $subject['theory_marks'];
            $matrix_data[$sub_name]['overall']['practical'] += $subject['practical_marks'];
            $matrix_data[$sub_name]['overall']['obtained']  += $subject['obtained_marks'];
            $matrix_data[$sub_name]['overall']['total']     += $subject['total_marks'];
            $matrix_data[$sub_name]['overall']['count']++;
        }
        $exam_count++;
    }

    if ($should_skip_this_student) {
        $skipped_students[] = [
            'student_id' => $student_id,
            'student_name' => $student_info['name']
        ];
        continue;
    }

    if (empty($exam_headers)) {
        continue;
    }

    $exclude_minor_marks = !$marksheet_settings['include_minor_subjects_marks'];
    $exam_totals = [];
    foreach ($exam_headers as $id => $name) {
        $exam_totals[$id] = ['obtained' => 0, 'full' => 0];
    }

    $overall_marks_total = 0;
    $overall_marks_obtained = 0;
    foreach ($matrix_data as $data) {
        $is_minor = strtolower($data['type']) === 'minor';
        if ($exclude_minor_marks && $is_minor) {
            continue;
        }

        // Exam totals use actual marks even when Overall is set to average.
        foreach ($data['exams'] as $id => $exam) {
            $exam_totals[$id]['obtained'] += $exam['obtained'];
            $exam_totals[$id]['full'] += $exam['total_marks'];
        }

        $count = $marksheet_settings['make_overall_average'] ? max(1, (int)$data['overall']['count']) : 1;
        $overall_marks_total += round($data['overall']['total'] / $count, 2);
        $overall_marks_obtained += round($data['overall']['obtained'] / $count, 2);
    }

    $percentage = $overall_marks_total > 0 ? ($overall_marks_obtained / $overall_marks_total) * 100 : 0;
    $overall_grade = calculateGrade($percentage);
    $pass_fail_status = getPassFailStatus($overall_grade);
    $result_remarks = getRemarksByGrade($overall_grade);
    $section_id = $marksheet_settings['section_based_ranking'] ? $first_exam_section_id : null;
    $ranking_key = $first_exam_class_id . ':' . ($section_id ?: 'all');
    if (!isset($combined_positions[$ranking_key])) {
        $combined_positions[$ranking_key] = getStudentPositionsForCombinedMarksheet(
            $pdo, $exam_ids, $first_exam_class_id,
            (bool)$marksheet_settings['include_minor_subjects_marks'],
            (bool)$marksheet_settings['make_overall_average'], $section_id
        );
    }
    $position = $combined_positions[$ranking_key][$student_id] ?? null;
    $position_in_class = $position === null ? '--' : getOrdinal($position);

    $stmt = $pdo->prepare("SELECT * FROM grading_system ORDER BY min_percentage DESC");
    $stmt->execute();
    $grading_system = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="marksheet-container">
    <div class="marksheet">
        <div class="header">
            <img src="<?= $school_logo_base64 ?>" alt="School Logo">
            <div class="school-name-container">
                <h1><?= safe_htmlspecialchars($school_name) ?></h1>
                <p><?= safe_htmlspecialchars($school_address) ?></p>
                <p><?= safe_htmlspecialchars($school_contacts) ?></p>
            </div>
        </div>

        <div class="student-info">
            <div class="details-left">
                <table>
                    <tr>
                        <th>Student Name:</th>
                        <td><?= safe_htmlspecialchars($student_info['name']) ?></td>
                        <th>Roll No:</th>
                        <td><?= safe_htmlspecialchars($roll_number ?? '-') ?></td>
                    </tr>
                    <tr>
                        <th>Father's Name:</th>
                        <td><?= safe_htmlspecialchars($student_info['father_name']) ?></td>
                        <th>Class:</th>
                        <td><?= safe_htmlspecialchars($class_name) ?> - <?= safe_htmlspecialchars($section_name ?? '-') ?></td>
                    </tr>
                    <tr>
                        <th>Student ID:</th>
                        <td><?= safe_htmlspecialchars($student_id) ?></td>
                        <th></th>
                        <td></td>
                    </tr>
                </table>
            </div>
            <div class="photo-right">
                <div class="photo">
                    <img src="<?= $student_photo_base64 ?>" alt="Student Photo">
                </div>
            </div>
        </div>

        <div class="marks-tables-container matrix-layout">
            <div class="marks-table full-width-matrix">
                <div class="marks-table-exam-name">Consolidated Academic Record</div>
                <div class="matrix-table-wrapper">
                    <table class="matrix-table">
                        <thead>
                            <tr>
                                <th rowspan="2" class="subject-col">Subjects</th>
                                <?php foreach ($exam_headers as $name): ?>
                                    <th colspan="3" class="exam-header"><?= safe_htmlspecialchars($name) ?></th>
                                <?php endforeach; ?>
                                <th colspan="3" class="exam-header overall-header">Overall</th>
                            </tr>
                            <tr>
                                <?php foreach ($exam_headers as $name): ?>
                                    <th>W</th><th>O</th><th>T</th>
                                <?php endforeach; ?>
                                <th class="overall-header">W</th>
                                <th class="overall-header">O</th>
                                <th class="overall-header">P</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($matrix_data as $sub_name => $data):
                                $is_minor = strtolower($data['type']) === 'minor';
                                $count = $marksheet_settings['make_overall_average'] ? max(1, (int)$data['overall']['count']) : 1;
                                $avg_w = round($data['overall']['theory'] / $count, 2);
                                $avg_o = round($data['overall']['practical'] / $count, 2);
                                $avg_t = round($data['overall']['obtained'] / $count, 2);
                                $total_marks = round($data['overall']['total'] / $count, 2);
                                $subject_percentage = $total_marks > 0 ? ($avg_t / $total_marks * 100) : 0;
                            ?>
                                <tr<?= ($exclude_minor_marks && $is_minor) ? ' style="color:#ff8800;font-weight:bold;"' : '' ?>>
                                    <td class="subject-col"><?= safe_htmlspecialchars($sub_name) ?></td>
                                    <?php foreach ($exam_headers as $id => $name): ?>
                                        <?php if (isset($data['exams'][$id])):
                                            $exam = $data['exams'][$id];
                                        ?>
                                            <td><?php if (!$exam['has_written_exam']): ?>-<?php elseif ($exam['is_absent'] == 1): ?><span style="color:red;">AB</span><?php else: ?><?= round($exam['theory'], 2) ?><?php endif; ?></td>
                                            <td><?php if (!$exam['has_oral_exam']): ?>-<?php elseif ($exam['is_absent'] == 1): ?><span style="color:red;">AB</span><?php else: ?><?= round($exam['practical'], 2) ?><?php endif; ?></td>
                                            <td><?= round($exam['obtained'], 2) ?></td>
                                        <?php else: ?>
                                            <td>-</td><td>-</td><td>-</td>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                    <td class="overall-cell"><?= $avg_w ?></td>
                                    <td class="overall-cell"><?= $avg_o ?></td>
                                    <td class="overall-cell"><span><?= round($subject_percentage, 2) ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                            <tr class="totals-row">
                                <th scope="row" class="subject-col">Total Marks Obtained</th>
                                <?php foreach ($exam_headers as $id => $name): ?>
                                    <td colspan="3"><?= round($exam_totals[$id]['obtained'], 2) ?></td>
                                <?php endforeach; ?>
                                <td colspan="3" class="overall-cell"></td>
                            </tr>
                            <tr class="totals-row">
                                <th scope="row" class="subject-col">Total Full Marks</th>
                                <?php foreach ($exam_headers as $id => $name): ?>
                                    <td colspan="3"><?= round($exam_totals[$id]['full'], 2) ?></td>
                                <?php endforeach; ?>
                                <td colspan="3" class="overall-cell"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="bottom-tables">
            <div class="grading-system">
                <div class="table-heading">Grading System</div>
                <table class="inner-table">
                    <thead>
                        <tr><th>Marks Range</th><th>Grade</th><th>Remarks</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($grading_system as $grade): ?>
                            <tr>
                                <td><?= floor($grade['min_percentage']) ?>% - <?= floor($grade['max_percentage']) ?>%</td>
                                <td><strong><?= safe_htmlspecialchars($grade['grade']) ?></strong></td>
                                <td><?= safe_htmlspecialchars($grade['remarks']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="result-summary">
                <div class="table-heading">Result Summary</div>
                <table class="inner-table">
                    <tbody>
                        <tr><th>Total Marks</th><td><?= round($overall_marks_total, 2) ?></td></tr>
                        <tr><th>Obtained Marks</th><td><?= round($overall_marks_obtained, 2) ?></td></tr>
                        <tr><th>Percentage</th><td><?= round($percentage, 2) ?>%</td></tr>
                        <tr><th>Grade</th><td><?= safe_htmlspecialchars($overall_grade) ?></td></tr>
                        <tr><th>Rank</th><td><?= safe_htmlspecialchars($position_in_class) ?></td></tr>
                        <tr><th>Result</th><td><?= safe_htmlspecialchars($pass_fail_status) ?></td></tr>
                        <tr><th>Remarks</th><td><?= safe_htmlspecialchars($result_remarks) ?></td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="signatures">
            <div class="sign-box"><p>Teacher's Sign</p></div>
            <div class="sign-box"><p>Date</p></div>
            <div class="sign-box"><p>Guardian's Sign</p></div>
            <div class="sign-box">
                <img src="<?= $principal_signature_base64 ?>" alt="Principal's Signature">
                <p>Principal's Sign</p>
            </div>
        </div>
    </div>
</div>
<?php } ?>
<?php if (count($skipped_students) > 0): ?>
<script>alert('Total <?= count($skipped_students) ?> student(s) skipped.');</script>
<?php endif; ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const element = document.body;
        const opt = {
            margin: 0,
            filename: 'marksheets.pdf',
            image: { type: 'jpeg', quality: 1 },
            html2canvas: { scale: 2, useCORS: true, windowWidth: element.scrollWidth },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
            pagebreak: { mode: ['avoid-all', 'legacy'] }
        };
        if (window.innerWidth <= 768) {
            html2pdf().from(element).set(opt).save();
        }
    });
</script>
</body>
</html>
<?php
$all_html_content = ob_get_clean();
file_put_contents($log_directory . 'combined_marksheets_output.html', $all_html_content);
header("Content-Type: text/html; charset=UTF-8");
echo $all_html_content;