<?php
/** @var array $schoolInfo */
ini_set('memory_limit', '512M'); // or '1G' for very large files
ob_start();
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/browsershot.php");

$log_directory = __DIR__ . '/../../../../assets/logs/';
if (!is_dir($log_directory)) {
    mkdir($log_directory, 0755, true);
}

if (!hasPermission(PERM_MANAGE_RESULTS)) {
    die("You do not have permission to perform this action.");
}

if (!isset($_GET['exam_ids']) || !isset($_GET['student_ids'])) {
    die("Required fields are missing.");
}

$exam_ids = explode(',', $_GET['exam_ids']);
$student_ids = explode(',', $_GET['student_ids']);
$class_id = $_GET['class_id'] ?? null;

if (count($exam_ids) < 1 || count($student_ids) < 1) {
    die("Please select at least one exam and one student.");
}

if (empty($class_id)) {
   die("Class ID is required.");
}

// Convert to integers (optional but recommended)
$exam_ids = array_values(array_unique(array_filter(array_map('intval', $exam_ids), fn($id) => $id > 0)));
// Sort ascending (low to high)
sort($exam_ids);

// Fetch marksheet settings
$stmt = $pdo->prepare("SELECT * FROM settings_marksheet LIMIT 1");
$stmt->execute();
$marksheet_settings = $stmt->fetch(PDO::FETCH_ASSOC);

// School information
$school_name = $schoolInfo['name'];
$school_address = $schoolInfo['address'];
$school_contacts = 'Phone: ' . $schoolInfo['phone'] . ' | Email: ' . $schoolInfo['email'];

// School logo and principal sign
$school_logo_path = '../../../../uploads/school/logo-square.png';
$principal_sign_path = '../../../../uploads/school/principle_sign.png';
// Convert images to base64
$school_logo_base64 = imageToBase64($school_logo_path);
$principal_signature_base64 = imageToBase64($principal_sign_path);

// Load HTML template and CSS
$css_path = '../../../../assets/templates/marksheet-templates/combined-marksheets/system-2/' . $marksheet_settings['combined_marksheet_design'] . '/style.css';
$css_style = file_get_contents($css_path);
$css_style = str_replace(
    [
        '{{theme_primary}}',
        '{{theme_dark}}',
        '{{theme_light}}',
        '{{page_background_color}}',
        '{{school_name_text_color}}',
        '{{school_address_text_color}}'
    ],
    [
        $marksheet_settings['primary_theme_color'],
        $marksheet_settings['dark_theme_color'],
        $marksheet_settings['light_theme_color'],
        $marksheet_settings['background_color'],
        $marksheet_settings['school_name_text_color'],
        $marksheet_settings['school_address_text_color']
    ],
    $css_style
);
$css = "<style>" . $css_style . "</style>";

$header_html = file_get_contents('../../../../assets/templates/marksheet-templates/header.html');
$header_html = str_replace('<link rel="stylesheet" href="style.css">', $css, $header_html);
$footer_html = file_get_contents('../../../../assets/templates/marksheet-templates/footer.html');

$content_html = file_get_contents('../../../../assets/templates/marksheet-templates/combined-marksheets/system-2/' . $marksheet_settings['combined_marksheet_design'] . '/content.html');

$all_html_content = $header_html;

$skipped_students = [];
$combined_positions = [];

foreach ($student_ids as $student_id) {

    // Fetch student info for placeholders
    $stmt = $pdo->prepare("
        SELECT 
            s.*,
            sec.section_name,
            c.class_name
        FROM students s
        LEFT JOIN sections sec ON s.section_id = sec.id
        LEFT JOIN classes c ON s.class_id = c.id
        WHERE s.student_id = ? AND (s.status = 'Active' OR s.status = 'Alumni')
    ");
    $stmt->execute([$student_id]);
    $student_info = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$student_info) {
        continue; // Skip if student not found or inactive
    }

    // Student photo
    $student_photo_base64 = '';
    if ($student_info['student_image'] && file_exists("../../../../uploads/students/" . $student_info['student_image'])) {
        $student_photo_path = "../../../../uploads/students/" . $student_info['student_image'];
        $student_photo_base64 = imageToBase64($student_photo_path);
    } else {
        $student_photo_path = "../../../../uploads/students/default_student_dp.jpg";
        $student_photo_base64 = imageToBase64($student_photo_path);
    }

    $exam_tables = '';
    $overall_data = [];
    $first_exam_excluded_subjects = [];
    $exam_count = 1;

    $first_exam_class_id = null;
    $first_exam_section_id = null;
    $should_skip_this_student = false;

    // Data placeholders
    $class_name = null;
    $section_name = null;
    $roll_number = null;

    // Co-Scholastic টেবিলের জন্য নতুন ভেরিয়েবল
    $minor_subjects_data = [];
    $exam_names_array = [];

    foreach ($exam_ids as $exam_id) {
        // Fetch result details
        $stmt = $pdo->prepare("
            SELECT 
                r.id AS result_id,
                r.student_id,
                r.exam_id AS result_exam_id,
                r.class_id AS result_class_id,
                r.section_id AS result_section_id,
                r.result_roll_no,
                r.total_marks,
                r.obtained_marks,
                r.percentage,
                r.grade,
                r.remarks,
                r.is_promoted,
                r.created_at,
                r.updated_at,

                e.id AS exam_id,
                e.exam_name,
                e.exam_date,

                c.class_name,
                sec.section_name

            FROM results r
            JOIN exams e ON r.exam_id = e.id 
            JOIN classes c ON r.class_id = c.id
            LEFT JOIN sections sec ON r.section_id = sec.id
            WHERE r.student_id = ? 
            AND r.exam_id = ?
        ");


        $stmt->execute([$student_id, $exam_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$result) continue;

        if (empty($class_name)) {
            $class_name = $result['class_name'];
        }

        if (empty($section_name)) {
            $section_name = $result['section_name'];
        }

        if (empty($roll_number)) {
            $roll_number = $result['result_roll_no'];
        }

        // Assign class id for the first exam
        if (empty($first_exam_class_id)) {
            $first_exam_class_id = $result['result_class_id'];
            $first_exam_section_id = $result['result_section_id'];
        } else {
            if ($first_exam_class_id !== $result['result_class_id']) {
                // Here we should stop the loop
                $should_skip_this_student = true;
                break;
            }
        }

        // টেবিলের হেডারের জন্য এক্সামের নাম স্টোর করা হচ্ছে
        $exam_names_array[$exam_id] = $result['exam_name'];

        // Fetch exam routine
        $routineStmtQuery = "SELECT * FROM exam_routines WHERE exam_id = ? AND class_id = ?";
        $routineStmt = $pdo->prepare($routineStmtQuery);
        $routineStmt->execute([$result['exam_id'], $student_info['class_id']]);
        $exam_routine = $routineStmt->fetchAll(PDO::FETCH_ASSOC);

        // Fetch subject marks
        $stmt = $pdo->prepare("
            SELECT sm.*, sub.subject_name, sub.subject_type, sub.marksheet_order_by  
            FROM subject_marks sm
            JOIN subjects sub ON sm.subject_id = sub.id
            WHERE sm.result_id = ? ORDER BY sub.marksheet_order_by
        ");
        $stmt->execute([$result['result_id']]);
        $subject_marks = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Store the subject rows
        $subject_rows = "";

        // Build subject rows HTML
        foreach ($subject_marks as $subject) {

            // If this is the first exam, record excluded subjects
            if ($exam_count === 1 && $subject['is_excluded']) {
                $first_exam_excluded_subjects[] = $subject['subject_id'];
            }

            // Check if the subject has written and/or oral exams
            $hasWrittenExam = true;
            $hasOralExam = true;

            foreach ($exam_routine as $routine) {
                if ($routine['subject_id'] == $subject['subject_id']) {
                    if ($routine['theory_marks'] == 0) {
                        $hasWrittenExam = false;
                    }
                    if ($routine['practical_marks'] == 0) {
                        $hasOralExam = false;
                    }
                }
            }

            // Skip excluded subjects in subsequent exams
            if (in_array($subject['subject_id'], $first_exam_excluded_subjects)) {
                continue;
            }

            // Build subject row for the exam table
            $tr = "<tr>";
            if (strtolower($subject['subject_type']) == "minor") {
                // Minor subject-এর গ্রেড স্টোর করা হচ্ছে
                $minor_subjects_data[$subject['subject_name']][$exam_id] = $subject['grade'];
                // Do not include minor subjects
                continue;
            }

            $subject_rows .= "{$tr}
                <td>" . safe_htmlspecialchars($subject['subject_name']) . "</td>
                <td>" . ($hasWrittenExam ? ($subject['is_absent'] == 1 ? '<span style="color:red;">AB</span>' : round($subject['theory_marks'], 2)) : '-') . "</td>
                <td>" . ($hasOralExam ? ($subject['is_absent'] == 1 ? '<span style="color:red;">AB</span>' : round($subject['practical_marks'], 2)) : '-') . "</td>
                <td>" . round($subject['obtained_marks'], 2) . "</td>
                <td>" . round($subject['total_marks'], 2) . "</td>
                <td>" . ($subject['grade'] == 'D' ? "<b style='color:red;'>D</b>" : "<strong>" . safe_htmlspecialchars($subject['grade']) . "</strong>") . "</td>
            </tr>";

            // Accumulate overall data
            if (!isset($overall_data[$subject['subject_name']])) {
                $overall_data[$subject['subject_name']] = [
                    'theory' => 0,
                    'practical' => 0,
                    'total' => 0,
                    'obtained' => 0,
                    'count' => 0
                ];
            }
            $overall_data[$subject['subject_name']]['subject_type'] = $subject['subject_type'];
            $overall_data[$subject['subject_name']]['theory'] += $subject['theory_marks'];
            $overall_data[$subject['subject_name']]['practical'] += $subject['practical_marks'];
            $overall_data[$subject['subject_name']]['total'] += $subject['total_marks'];
            $overall_data[$subject['subject_name']]['obtained'] += $subject['obtained_marks'];
            $overall_data[$subject['subject_name']]['count']++;
        }

        // Add exam table
        $exam_tables .= '<div class="marks-table">
            <div class="marks-table-exam-name">' . safe_htmlspecialchars($result['exam_name']) . '</div>
            <table>
                <thead>
                    <tr>
                        <th>Subject</th>
                        <th>Written</th>
                        <th>Oral</th>
                        <th>Obtained</th>
                        <th>Full Mark</th>
                        <th>Grade</th>
                    </tr>
                </thead>
                <tbody>' . $subject_rows . '</tbody>
            </table>
        </div>';

        // Increment exam count variable
        $exam_count++;
    }

    // Should skip this student
    if ($should_skip_this_student) {
        $skipped_students[] = [
            'student_id' => $result['student_id'],
            'student_name' => safe_htmlspecialchars($result['student_name'])
        ];
        continue;
    }

    // --- Build Co-Scholastic (Minor Subjects) Table ---
    $co_scholastic_table_html = "<table>\n<thead>\n<tr>\n<th>Subjects</th>\n";
    
    // ডাইনামিক এক্সাম হেডার তৈরি
    foreach ($exam_ids as $eid) {
        $e_name = isset($exam_names_array[$eid]) ? $exam_names_array[$eid] : 'Exam';
        $co_scholastic_table_html .= "<th>" . safe_htmlspecialchars($e_name) . "</th>\n";
    }
    $co_scholastic_table_html .= "</tr>\n</thead>\n<tbody>\n";

    // সাবজেক্ট এবং গ্রেড অনুযায়ী রো (Row) তৈরি
    if (!empty($minor_subjects_data)) {
        foreach ($minor_subjects_data as $sub_name => $exam_grades) {
            $co_scholastic_table_html .= "<tr>\n<td>" . safe_htmlspecialchars($sub_name) . "</td>\n";
            
            foreach ($exam_ids as $eid) {
                // যদি কোনো পরীক্ষায় গ্রেড না থাকে তবে '-' দেখাবে
                $grade = isset($exam_grades[$eid]) ? $exam_grades[$eid] : '-';
                
                // 'D' গ্রেড হলে লাল রং, নাহলে নরমাল বোল্ড
                $grade_display = ($grade == 'D') ? "<b style='color:red;'>D</b>" : "<strong>" . safe_htmlspecialchars($grade) . "</strong>";
                $co_scholastic_table_html .= "<td>{$grade_display}</td>\n";
            }
            $co_scholastic_table_html .= "</tr>\n";
        }
    } else {
        $colspan = count($exam_ids) + 1;
        $co_scholastic_table_html .= "<tr><td colspan='{$colspan}' style='text-align:center;'>No minor subjects found</td></tr>\n";
    }
    $co_scholastic_table_html .= "</tbody>\n</table>";

    // Build overall table (Dividing the overall data by count for averages)
    $overall_marks_total = 0;
    $overall_marks_obtained = 0;

    $overall_rows = "";
    foreach ($overall_data as $subject => $data) {

        // 1. Determine the divisor ('count') in one step
        // If 'make_overall_average' is true, use the subject's count (at least 1).
        // Otherwise, just use 1 (so we're summing, not averaging).
        $count = $marksheet_settings['make_overall_average']
            ? max(1, (int)$data['count'])
            : 1;

        // 2. Cache repeated checks and values
        $is_minor = (strtolower($data['subject_type']) == "minor");
        $exclude_minor_marks = !$marksheet_settings['include_minor_subjects_marks'];

        // 3. Determine row style
        // Use a ternary operator for a cleaner assignment.
        $tr = ($exclude_minor_marks && $is_minor)
            ? "<tr style='color:#ff8800;font-weight:bold;'>"
            : "<tr>";

        // 4. Calculate grade with a check for division by zero
        // Avoids potential errors if a subject's total marks are 0.
        $percentage = ($data['total'] > 0)
            ? ($data['obtained'] / $data['total'] * 100)
            : 0;
        $grade = calculateGrade($percentage);

        // 5. Calculate averaged values
        // Do the division once and store in variables for clarity.
        $theory_marks = round($data['theory'] / $count, 2);
        $practical_marks = round($data['practical'] / $count, 2);
        $total_marks = round($data['total'] / $count, 2);
        $obtained_marks = round($data['obtained'] / $count, 2);

        // 6. Build the row string
        // Using sprintf or interpolation is often cleaner than repeated concatenation.
        $overall_rows .= "{$tr}
            <td>" . safe_htmlspecialchars($subject) . "</td>
            <td>{$theory_marks}</td>
            <td>{$practical_marks}</td>
            <td>{$total_marks}</td>
            <td>{$obtained_marks}</td>
            <td>{$grade}</td>
        </tr>";

        // 7. Conditionally add to totals
        // If we're excluding minor subject marks and this is a minor subject, skip.
        if ($exclude_minor_marks && $is_minor) {
            continue;
        }

        // Add the (potentially averaged) marks to the grand total.
        $overall_marks_total += $total_marks;
        $overall_marks_obtained += $obtained_marks;
    }


    // Calculate overall percentage and grade
    $percentage = $overall_marks_total > 0 ? ($overall_marks_obtained / $overall_marks_total) * 100 : 0;
    $overall_grade = calculateGrade($percentage);
    $pass_fail_status = getPassFailStatus($overall_grade);
    $result_remarks = getRemarksByGrade($overall_grade);
    $section_id = $marksheet_settings['section_based_ranking'] ? $first_exam_section_id : null;
    $ranking_key = $first_exam_class_id . ':' . ($section_id ?: 'all');
    if (!isset($combined_positions[$ranking_key])) {
        // This design displays minor subjects as grades only and excludes their marks.
        $combined_positions[$ranking_key] = getStudentPositionsForCombinedMarksheet(
            $pdo, $exam_ids, $first_exam_class_id,
            false,
            (bool)$marksheet_settings['make_overall_average'], $section_id
        );
    }
    $position = $combined_positions[$ranking_key][$student_id] ?? null;
    $position_in_class = $position === null ? '--' : getOrdinal($position);

    // Build result summary table
    $result_summary_table = "<table><tbody>";
    $result_summary_table .= "<tr><th>Total Marks</th><td>". round($overall_marks_total, 2) . "</td></tr>";
    $result_summary_table .= "<tr><th>Obtained Marks</th><td>". round($overall_marks_obtained, 2) . "</td></tr>";
    $result_summary_table .= "<tr><th>Percentage</th><td>". round($percentage, 2) . "%</td></tr>";
    $result_summary_table .= "<tr><th>Grade</th><td>". $overall_grade . "</td></tr>";
    $result_summary_table .= "<tr><th>Rank</th><td>". $position_in_class . "</td></tr>";
    $result_summary_table .= "<tr><th>Result</th><td>". $pass_fail_status . "</td></tr>";
    $result_summary_table .= "<tr><th>Remarks</th><td>". $result_remarks . "</td></tr>";
    $result_summary_table .= "</tbody></table>";

    // Replace placeholders
    $page_html = str_replace(
        [
            '{{school_logo}}',
            '{{school_name}}',
            '{{school_address}}',
            '{{school_contacts}}',
            '{{student_id}}',
            '{{roll_no}}',
            '{{student_name}}',
            '{{father_name}}',
            '{{class_name}}',
            '{{section_name}}',
            '{{student_photo}}',
            '{{exam_tables}}',
            '{{co_scholastic_table}}',
            '{{result_summary_table}}',
            '{{principal_signature_image}}'
        ],
        [
            $school_logo_base64,
            $school_name,
            $school_address,
            $school_contacts,
            $student_id,
            $roll_number ?? '-',
            $student_info['name'],
            $student_info['father_name'],
            $class_name,
            $section_name ?? '-',
            $student_photo_base64,
            $exam_tables,
            $co_scholastic_table_html,
            $result_summary_table,
            $principal_signature_base64
        ],
        $content_html
    );

    $all_html_content .= $page_html;
}

// Add skipped students info
if (count($skipped_students) > 0) {
    $all_html_content .= "<script>alert('Total " . count($skipped_students) . " student(s) skipped.');</script>";
}

// Add closing HTML tags
$all_html_content .= $footer_html;

// For debugging: Save the combined HTML to a file
file_put_contents($log_directory . 'combined_marksheets_output.html', $all_html_content);

// Export or print the combined HTML content
header("Content-Type: text/html; charset=UTF-8");
echo $all_html_content;
ob_flush();
?>
