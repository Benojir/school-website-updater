<?php
/** @var array $schoolInfo */
ini_set('memory_limit', '512M'); 
ob_start();
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/browsershot.php");

$log_directory = __DIR__ . '/../../../../assets/logs/';
if (!is_dir($log_directory)) {
    mkdir($log_directory, 0755, true);
}

if (!hasPermission(PERM_MANAGE_RESULTS)) {
    die("You do not have permission to perform this action.");
}

if (!isset($_GET['exam_ids']) || !isset($_GET['student_ids'])) {
    die("Required fields are missing.");
}

$exam_ids = explode(',', $_GET['exam_ids']);
$student_ids = explode(',', $_GET['student_ids']);
$class_id = $_GET['class_id'] ?? null; // Added for Ranking

if (count($exam_ids) < 1 || count($student_ids) < 1) {
    die("Please select at least one exam and one student.");
}

if (empty($class_id)) {
   die("Class ID is required for ranking.");
}

$exam_ids = array_map('intval', $exam_ids);
sort($exam_ids);

$stmt = $pdo->prepare("SELECT * FROM settings_marksheet LIMIT 1");
$stmt->execute();
$marksheet_settings = $stmt->fetch(PDO::FETCH_ASSOC);

$school_name = $schoolInfo['name'];
$school_address = $schoolInfo['address'];
$school_contacts = 'Phone: ' . $schoolInfo['phone'] . ' | ' . $schoolInfo['alternate_phone'];

$school_logo_path = '../../../../uploads/school/logo-square.png';
$principal_sign_path = '../../../../uploads/school/principle_sign.png';
$school_logo_base64 = imageToBase64($school_logo_path);
$principal_signature_base64 = imageToBase64($principal_sign_path);

$css_path = '../../../../assets/templates/marksheet-templates/combined-marksheets/system-3/' . $marksheet_settings['combined_marksheet_design'] . '/style.css';
$css_style = file_get_contents($css_path);
$css_style = str_replace(
    [
        '{{theme_primary}}', '{{theme_dark}}', '{{theme_light}}',
        '{{page_background_color}}', '{{school_name_text_color}}', '{{school_address_text_color}}'
    ],
    [
        $marksheet_settings['primary_theme_color'], $marksheet_settings['dark_theme_color'],
        $marksheet_settings['light_theme_color'], $marksheet_settings['background_color'],
        $marksheet_settings['school_name_text_color'], $marksheet_settings['school_address_text_color']
    ],
    $css_style
);
$css = "<style>" . $css_style . "</style>";

$header_html = file_get_contents('../../../../assets/templates/marksheet-templates/header.html');
$header_html = str_replace('<link rel="stylesheet" href="style.css">', $css, $header_html);
$footer_html = file_get_contents('../../../../assets/templates/marksheet-templates/footer.html');
$content_html = file_get_contents('../../../../assets/templates/marksheet-templates/combined-marksheets/system-3/' . $marksheet_settings['combined_marksheet_design'] . '/content.html');

$all_html_content = $header_html;
$skipped_students = [];

foreach ($student_ids as $student_id) {
    $stmt = $pdo->prepare("
        SELECT s.*, sec.section_name, c.class_name
        FROM students s
        LEFT JOIN sections sec ON s.section_id = sec.id
        LEFT JOIN classes c ON s.class_id = c.id
        WHERE s.student_id = ? AND (s.status = 'Active' OR s.status = 'Alumni')
    ");
    $stmt->execute([$student_id]);
    $student_info = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$student_info) continue;

    $section_id = $student_info['section_id'];
    if (!$marksheet_settings['section_based_ranking']) {
        $section_id = null;
    }

    if ($student_info['student_image'] && file_exists("../../../../uploads/students/" . $student_info['student_image'])) {
        $student_photo_base64 = imageToBase64("../../../../uploads/students/" . $student_info['student_image']);
    } else {
        $student_photo_base64 = imageToBase64("../../../../uploads/students/default_student_dp.jpg");
    }

    $matrix_data = [];
    $exam_headers = [];
    $first_exam_class_id = null;
    $should_skip_this_student = false;
    $first_exam_excluded_subjects = [];
    $exam_count = 1;
    $tempExamId = "";

    $class_name = null;
    $section_name = null;
    $roll_number = null;

    foreach ($exam_ids as $exam_id) {
        $stmt = $pdo->prepare("
            SELECT r.id AS result_id, r.student_id, r.exam_id AS result_exam_id, r.class_id AS result_class_id, r.result_roll_no, e.exam_name, c.class_name, sec.section_name
            FROM results r
            JOIN exams e ON r.exam_id = e.id
            JOIN classes c ON r.class_id = c.id
            LEFT JOIN sections sec ON r.section_id = sec.id
            WHERE r.student_id = ? AND r.exam_id = ?
        ");
        $stmt->execute([$student_id, $exam_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$result) continue;

        if (empty($class_name)) $class_name = $result['class_name'];
        if (empty($section_name)) $section_name = $result['section_name'];
        if (empty($roll_number)) $roll_number = $result['result_roll_no'];
        
        if (empty($first_exam_class_id)) {
            $first_exam_class_id = $result['result_class_id'];
        } else if ($first_exam_class_id !== $result['result_class_id']) {
            $should_skip_this_student = true;
            break;
        }
        
        $tempExamId = $result['result_exam_id'];
        $exam_headers[$exam_id] = $result['exam_name'];
        
        $routineStmt = $pdo->prepare("SELECT * FROM exam_routines WHERE exam_id = ? AND class_id = ?");
        $routineStmt->execute([$result['result_exam_id'], $student_info['class_id']]);
        $exam_routine = $routineStmt->fetchAll(PDO::FETCH_ASSOC);
        
        $routine_lookup = [];
        foreach ($exam_routine as $routine) {
            $routine_lookup[$routine['subject_id']] = [
                'has_written' => ($routine['theory_marks'] != 0),
                'has_oral'    => ($routine['practical_marks'] != 0),
            ];
        }

        $stmt = $pdo->prepare("
            SELECT sm.*, sub.subject_name, sub.subject_type
            FROM subject_marks sm
            JOIN subjects sub ON sm.subject_id = sub.id
            WHERE sm.result_id = ? ORDER BY sub.marksheet_order_by
        ");
        $stmt->execute([$result['result_id']]);
        $subject_marks = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($subject_marks as $subject) {
            if ($exam_count === 1 && $subject['is_excluded']) {
                $first_exam_excluded_subjects[] = $subject['subject_id'];
            }
            if (in_array($subject['subject_id'], $first_exam_excluded_subjects)) {
                continue;
            }

            $sub_name = $subject['subject_name'];
            if (!isset($matrix_data[$sub_name])) {
                $matrix_data[$sub_name] = [
                    'type' => $subject['subject_type'],
                    'exams' => [],
                    'overall' => ['theory' => 0, 'practical' => 0, 'total' => 0, 'obtained' => 0, 'count' => 0]
                ];
            }
            
            $hasWrittenExam = true;
            $hasOralExam    = true;
            if (isset($routine_lookup[$subject['subject_id']])) {
                $hasWrittenExam = $routine_lookup[$subject['subject_id']]['has_written'];
                $hasOralExam    = $routine_lookup[$subject['subject_id']]['has_oral'];
            }
            
            $matrix_data[$sub_name]['exams'][$exam_id] = [
                'theory'          => $subject['theory_marks'],
                'practical'       => $subject['practical_marks'],
                'obtained'        => $subject['obtained_marks'],
                'is_absent'       => $subject['is_absent'],
                'has_written_exam' => $hasWrittenExam,
                'has_oral_exam'    => $hasOralExam,
            ];
            
            $matrix_data[$sub_name]['overall']['theory']    += $subject['theory_marks'];
            $matrix_data[$sub_name]['overall']['practical'] += $subject['practical_marks'];
            $matrix_data[$sub_name]['overall']['obtained']  += $subject['obtained_marks'];
            $matrix_data[$sub_name]['overall']['total']     += $subject['total_marks'];
            $matrix_data[$sub_name]['overall']['count']++;
        }
        $exam_count++;
    }

    if ($should_skip_this_student) {
        $skipped_students[] = [
            'student_id' => $student_id,
            'student_name' => $student_info['name']
        ];
        continue;
    }

    $matrix_html = '<table class="matrix-table">';
    $matrix_html .= '<thead><tr><th rowspan="2" class="subject-col">Subjects</th>';
    foreach ($exam_headers as $id => $name) {
        $matrix_html .= '<th colspan="3" class="exam-header">' . safe_htmlspecialchars($name) . '</th>';
    }
    $matrix_html .= '<th colspan="3" class="exam-header overall-header">Overall</th></tr><tr>';
    foreach ($exam_headers as $id => $name) {
        $matrix_html .= '<th>W</th><th>O</th><th>T</th>';
    }
    $matrix_html .= '<th class="overall-header">W</th><th class="overall-header">O</th><th class="overall-header">P</th></tr></thead><tbody>';
    
    $overall_marks_total = 0;
    $overall_marks_obtained = 0;
    
    foreach ($matrix_data as $sub_name => $data) {
        $is_minor = (strtolower($data['type']) == "minor");
        $exclude_minor_marks = !$marksheet_settings['include_minor_subjects_marks'];
        $tr_style = ($exclude_minor_marks && $is_minor) ? " style='color:#ff8800;font-weight:bold;'" : "";
        $matrix_html .= "<tr{$tr_style}>";
        $matrix_html .= '<td class="subject-col">' . safe_htmlspecialchars($sub_name) . '</td>';
        
        foreach ($exam_headers as $id => $name) {
            if (isset($data['exams'][$id])) {
                $exam = $data['exams'][$id];
                $w = $exam['has_written_exam'] ? ($exam['is_absent'] == 1 ? '<span style="color:red;">AB</span>' : round($exam['theory'], 2)) : '-';
                $o = $exam['has_oral_exam'] ? ($exam['is_absent'] == 1 ? '<span style="color:red;">AB</span>' : round($exam['practical'], 2)) : '-';
                $t = round($exam['obtained'], 2);
                $matrix_html .= "<td>{$w}</td><td>{$o}</td><td>{$t}</td>";
            } else {
                $matrix_html .= "<td>-</td><td>-</td><td>-</td>";
            }
        }
        
        $count = $marksheet_settings['make_overall_average'] ? max(1, (int)$data['overall']['count']) : 1;
        $avg_w = round($data['overall']['theory'] / $count, 2);
        $avg_o = round($data['overall']['practical'] / $count, 2);
        $avg_t = round($data['overall']['obtained'] / $count, 2);
        $total_marks = round($data['overall']['total'] / $count, 2);
        $percentage = ($total_marks > 0) ? ($avg_t / $total_marks * 100) : 0;
        $grade = calculateGrade($percentage);
        $matrix_html .= "<td class='overall-cell'>{$avg_w}</td><td class='overall-cell'>{$avg_o}</td><td class='overall-cell'><span>" . round($percentage, 2) . "</span></td></tr>";
        
        if (!($exclude_minor_marks && $is_minor)) {
            $overall_marks_total += $total_marks;
            $overall_marks_obtained += $avg_t;
        }
    }
    $matrix_html .= '</tbody></table>';

    $percentage = $overall_marks_total > 0 ? ($overall_marks_obtained / $overall_marks_total) * 100 : 0;
    $overall_grade = calculateGrade($percentage);
    $pass_fail_status = getPassFailStatus($overall_grade);
    $result_remarks = getRemarksByGrade($overall_grade);

    // Summary Table (From system-2)
    $result_summary_table = "<table class='inner-table'><tbody>";
    $result_summary_table .= "<tr><th>Total Marks</th><td>". round($overall_marks_total, 2) . "</td></tr>";
    $result_summary_table .= "<tr><th>Obtained Marks</th><td>". round($overall_marks_obtained, 2) . "</td></tr>";
    $result_summary_table .= "<tr><th>Percentage</th><td>". round($percentage, 2) . "%</td></tr>";
    $result_summary_table .= "<tr><th>Grade</th><td>". $overall_grade . "</td></tr>";
    $result_summary_table .= "<tr><th>Rank</th><td>". getOrdinal(getStudentPositionInClass($pdo, $tempExamId, $class_id, $student_id, $marksheet_settings['include_minor_subjects_marks'], $section_id)) . "</td></tr>";
    $result_summary_table .= "<tr><th>Result</th><td>". $pass_fail_status . "</td></tr>";
    $result_summary_table .= "<tr><th>Remarks</th><td>". $result_remarks . "</td></tr>";
    $result_summary_table .= "</tbody></table>";

    // Grading System Table
    $grading_rows = "";
    $stmt = $pdo->prepare("SELECT * FROM grading_system ORDER BY min_percentage DESC");
    $stmt->execute();
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $grade) {
        $grading_rows .= "<tr>
            <td>" . floor($grade['min_percentage']) . "% - " . floor($grade['max_percentage']) . "%</td>
            <td><strong>" . safe_htmlspecialchars($grade['grade']) . "</strong></td>
            <td>" . safe_htmlspecialchars($grade['remarks']) . "</td>
        </tr>";
    }

    $page_html = str_replace(
        [
            '{{school_logo}}', '{{school_name}}', '{{school_address}}', '{{school_contacts}}',
            '{{student_id}}', '{{roll_no}}', '{{student_name}}', '{{father_name}}',
            '{{class_name}}', '{{section_name}}', '{{student_photo}}', '{{matrix_html}}',
            '{{grading_rows}}', '{{result_summary_table}}', '{{principal_signature_image}}'
        ],
        [
            $school_logo_base64, $school_name, $school_address, $school_contacts,
            $student_id, $roll_number ?? '-', $student_info['name'], $student_info['father_name'],
            $class_name, $section_name ?? '-', $student_photo_base64, $matrix_html,
            $grading_rows, $result_summary_table, $principal_signature_base64
        ],
        $content_html
    );
    $all_html_content .= $page_html;
}

if (count($skipped_students) > 0) {
    $all_html_content .= "<script>alert('Total " . count($skipped_students) . " student(s) skipped.');</script>";
}
$all_html_content .= $footer_html;
file_put_contents($log_directory . 'combined_marksheets_output.html', $all_html_content);
header("Content-Type: text/html; charset=UTF-8");
echo $all_html_content;
ob_flush();
?>