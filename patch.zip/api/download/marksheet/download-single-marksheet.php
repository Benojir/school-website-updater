<?php
include_once(__DIR__ . "/../../../includes/auth-check.php");

if (!isset($_GET['result_ids'])) {
    die("Result IDs are required");
}

$result_ids = $_GET['result_ids'];

// Fetch marksheet settings
$stmt = $pdo->prepare("SELECT * FROM settings_marksheet LIMIT 1");
$stmt->execute();
$marksheet_settings = $stmt->fetch(PDO::FETCH_ASSOC);

$marksheet_system = $marksheet_settings['marksheet_system'] ?? "system-1";

header('Location: single/' . $marksheet_system . '.php?result_ids=' . $result_ids);
exit;
