<?php
include_once(__DIR__ . "/../../../includes/auth-check.php");

if (!isset($_GET['result_ids'])) {
    die("Result IDs are required");
}

$result_ids = $_GET['result_ids'];

// Check permission: Admins can download any marksheet anytime
if (!isAnyAdminLoggedIn()) {
    $ids = array_filter(array_map('intval', explode(',', $result_ids)));
    if (empty($ids)) {
        die("Invalid result IDs provided.");
    }

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $currentDateTime = date('Y-m-d H:i:s');

    $checkQuery = "
        SELECT r.id, e.exam_name, c.class_name,
               emr.status as release_status, emr.release_date
        FROM results r
        JOIN exams e ON r.exam_id = e.id
        JOIN classes c ON r.class_id = c.id
        LEFT JOIN exam_marksheet_releases emr 
            ON emr.exam_id = r.exam_id AND emr.class_id = r.class_id
        WHERE r.id IN ($placeholders)
    ";
    $checkStmt = $pdo->prepare($checkQuery);
    $checkStmt->execute($ids);
    $rows = $checkStmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($rows)) {
        die("No marksheet results found.");
    }

    foreach ($rows as $row) {
        $examName = htmlspecialchars($row['exam_name']);
        $className = htmlspecialchars($row['class_name']);

        if (empty($row['release_status']) || $row['release_status'] !== 'released') {
            die("
                <div style='font-family: Arial, sans-serif; text-align: center; margin-top: 50px;'>
                    <div style='display: inline-block; padding: 30px; border: 1px solid #e0e0e0; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); max-width: 500px;'>
                        <h2 style='color: #dc3545; margin-bottom: 15px;'>Marksheet Not Released</h2>
                        <p style='color: #555; font-size: 16px; line-height: 1.5;'>The marksheet for <strong>{$examName}</strong> (Class: {$className}) has not been released yet.</p>
                    </div>
                </div>
            ");
        }

        if ($row['release_date'] > $currentDateTime) {
            $formattedDate = date('d M Y, h:i A', strtotime($row['release_date']));
            die("
                <div style='font-family: Arial, sans-serif; text-align: center; margin-top: 50px;'>
                    <div style='display: inline-block; padding: 30px; border: 1px solid #e0e0e0; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); max-width: 500px;'>
                        <h2 style='color: #fd7e14; margin-bottom: 15px;'>Marksheet Not Available Yet</h2>
                        <p style='color: #555; font-size: 16px; line-height: 1.5;'>The marksheet for <strong>{$examName}</strong> (Class: {$className}) is scheduled for release on <strong>{$formattedDate}</strong>.</p>
                        <p style='color: #777; font-size: 14px;'>Please check back after the scheduled release time.</p>
                    </div>
                </div>
            ");
        }
    }
}

// Fetch marksheet settings
$stmt = $pdo->prepare("SELECT * FROM settings_marksheet LIMIT 1");
$stmt->execute();
$marksheet_settings = $stmt->fetch(PDO::FETCH_ASSOC);

$marksheet_design = $marksheet_settings['single_marksheet_design'] ?? "design-1";

header('Location: single/' . $marksheet_design . '.php?result_ids=' . $result_ids);
exit;
