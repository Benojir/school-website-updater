<?php
/** @var array $schoolInfo */
ini_set('memory_limit', '512M');
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/browsershot.php");

$log_directory = __DIR__ . '/../../../../assets/logs/';
if (!is_dir($log_directory)) {
    mkdir($log_directory, 0755, true);
}

use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;

if (!isset($_GET['result_ids'])) {
    die("Result IDs are required");
}

$raw_ids = explode(',', $_GET['result_ids']);
$placeholders = implode(',', array_fill(0, count($raw_ids), '?'));

// Numeric sorting by student roll number
$sortStmt = $pdo->prepare("
    SELECT r.id 
    FROM results r 
    JOIN students s ON r.student_id = s.student_id 
    WHERE r.id IN ($placeholders)
    ORDER BY CAST(s.roll_no AS UNSIGNED) ASC
");
$sortStmt->execute($raw_ids);
$result_ids = $sortStmt->fetchAll(PDO::FETCH_COLUMN);

// Verify release permissions for non-admin users
if (!isAnyAdminLoggedIn()) {
    $currentDateTime = date('Y-m-d H:i:s');
    $checkPlaceholders = implode(',', array_fill(0, count($result_ids), '?'));

    $checkQuery = "
        SELECT r.id, e.exam_name, c.class_name,
               emr.status as release_status, emr.release_date
        FROM results r
        JOIN exams e ON r.exam_id = e.id
        JOIN classes c ON r.class_id = c.id
        LEFT JOIN exam_marksheet_releases emr 
            ON emr.exam_id = r.exam_id AND emr.class_id = r.class_id
        WHERE r.id IN ($checkPlaceholders)
    ";
    $checkStmt = $pdo->prepare($checkQuery);
    $checkStmt->execute($result_ids);
    $rows = $checkStmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($rows)) {
        die("No marksheet results found.");
    }

    foreach ($rows as $row) {
        $examName = htmlspecialchars($row['exam_name']);
        $className = htmlspecialchars($row['class_name']);

        if (empty($row['release_status']) || $row['release_status'] !== 'released') {
            die("
                <div style='font-family: Arial, sans-serif; text-align: center; margin-top: 50px;'>
                    <div style='display: inline-block; padding: 30px; border: 1px solid #e0e0e0; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); max-width: 500px;'>
                        <h2 style='color: #dc3545; margin-bottom: 15px;'>Marksheet Not Released</h2>
                        <p style='color: #555; font-size: 16px; line-height: 1.5;'>The marksheet for <strong>{$examName}</strong> (Class: {$className}) has not been released yet.</p>
                    </div>
                </div>
            ");
        }

        if ($row['release_date'] > $currentDateTime) {
            $formattedDate = date('d M Y, h:i A', strtotime($row['release_date']));
            die("
                <div style='font-family: Arial, sans-serif; text-align: center; margin-top: 50px;'>
                    <div style='display: inline-block; padding: 30px; border: 1px solid #e0e0e0; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); max-width: 500px;'>
                        <h2 style='color: #fd7e14; margin-bottom: 15px;'>Marksheet Not Available Yet</h2>
                        <p style='color: #555; font-size: 16px; line-height: 1.5;'>The marksheet for <strong>{$examName}</strong> (Class: {$className}) is scheduled for release on <strong>{$formattedDate}</strong>.</p>
                        <p style='color: #777; font-size: 14px;'>Please check back after the scheduled release time.</p>
                    </div>
                </div>
            ");
        }
    }
}

// Fetch settings
$stmt = $pdo->prepare("SELECT * FROM settings_marksheet LIMIT 1");
$stmt->execute();
$marksheet_settings = $stmt->fetch(PDO::FETCH_ASSOC);

$fast_generation = !empty($marksheet_settings['fast_generation']);
$include_minor_subjects_marks = !empty($marksheet_settings['include_minor_subjects_marks']);
$section_based_ranking = !empty($marksheet_settings['section_based_ranking']);
$show_text_watermark = !empty($marksheet_settings['show_text_watermark']);

// School info
$school_name = $schoolInfo['name'] ?? '';
$school_established = $schoolInfo['established_year'] ?? '';

// Build formatted address line matching design
$village = $schoolInfo['village'] ?? '';
$post_office = $schoolInfo['post_office'] ?? '';
$police_station = $schoolInfo['police_station'] ?? '';
$district = $schoolInfo['district'] ?? '';
$pincode = $schoolInfo['pincode'] ?? '';

$addr_parts = [];
if (!empty($village)) $addr_parts[] = 'Village :- ' . safe_htmlspecialchars($village);
if (!empty($post_office)) $addr_parts[] = 'P.O :- ' . safe_htmlspecialchars($post_office);
if (!empty($police_station)) $addr_parts[] = 'P.S :- ' . safe_htmlspecialchars($police_station);
if (!empty($district)) $addr_parts[] = 'Dist :- ' . safe_htmlspecialchars($district);
if (!empty($pincode)) $addr_parts[] = 'Pin :- ' . safe_htmlspecialchars($pincode);

$address_display = !empty($addr_parts) ? implode(' * ', $addr_parts) : safe_htmlspecialchars($schoolInfo['address'] ?? '');

$school_logo_path = '../../../../uploads/school/logo-square.png';
$school_logo_base64 = imageToBase64($school_logo_path);

$school_stamp_path = '../../../../uploads/school/school_stamp.png';
if (!file_exists($school_stamp_path)) {
    $school_stamp_path = '../../../../uploads/school/stamp.png';
}
$school_stamp_base64 = imageToBase64($school_stamp_path);

$headmaster_sign_path = '../../../../uploads/school/headmaster_sign.png';
$headmaster_sign_base64 = imageToBase64($headmaster_sign_path);

// Start buffer
ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Progress Report - <?= safe_htmlspecialchars($school_name) ?></title>
    <style>
        @page {
            size: A4 portrait;
            margin: 0;
        }

        *, *::before, *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html, body {
            margin: 0;
            padding: 0;
            background-color: #f1f5f9;
            font-family: Arial, Helvetica, sans-serif;
            color: #000000;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        .marksheet-page {
            width: 210mm;
            height: 297mm;
            max-height: 297mm;
            padding: 3.5mm 5mm;
            margin: 0 auto;
            background-color: #ffffff;
            break-after: always;
            page-break-after: always;
            box-sizing: border-box;
            position: relative;
            overflow: hidden;
        }

        .outer-frame {
            height: 100%;
            width: 100%;
            background: #ffffff;
            border: 2.5px solid #002147;
            padding: 2mm 3mm;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            position: relative;
            box-sizing: border-box;
            overflow: hidden;
        }

        /* Top invocation */
        .top-invocation {
            text-align: center;
            font-size: 8pt;
            font-weight: 700;
            font-style: italic;
            color: #000000;
            margin-bottom: 1.2mm;
            flex-shrink: 0;
            line-height: 1.1;
        }

        /* School Name Bar */
        .school-name-bar {
            background-color: #fff200;
            border: 1.5px solid #000000;
            text-align: center;
            padding: 1.2mm 2mm;
            flex-shrink: 0;
        }

        .school-name-text {
            font-size: 16pt;
            font-weight: 900;
            letter-spacing: 0.5px;
            color: #000000;
            text-transform: uppercase;
            line-height: 1.15;
        }

        /* Address Bar */
        .address-bar {
            background-color: #00e5ff;
            border: 1.5px solid #000000;
            border-top: none;
            text-align: center;
            padding: 0.8mm 1.5mm;
            font-size: 7pt;
            font-weight: 700;
            font-style: italic;
            color: #000000;
            flex-shrink: 0;
            letter-spacing: 0.2px;
            line-height: 1.15;
        }

        /* 3-Column Header Box */
        .header-meta-grid {
            display: flex;
            border: 1.5px solid #000000;
            border-top: none;
            height: 18mm;
            flex-shrink: 0;
        }

        .header-logo-box {
            width: 22%;
            border-right: 1.5px solid #000000;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0.8mm;
            background: #ffffff;
        }

        .header-logo-img {
            max-height: 16mm;
            max-width: 95%;
            object-fit: contain;
        }

        .header-center-box {
            width: 56%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            text-align: center;
            background: #ffffff;
        }

        .estd-text {
            color: #e91e63;
            font-size: 9.5pt;
            font-weight: 800;
            font-style: italic;
            padding-top: 0.5mm;
            border-bottom: 1px solid #000000;
            line-height: 1.1;
        }

        .academic-year-text {
            color: #d32f2f;
            font-size: 13.5pt;
            font-weight: 800;
            padding: 0.3mm 0;
            border-bottom: 1px solid #000000;
            line-height: 1.1;
        }

        .progress-report-banner {
            background-color: #fff200;
            color: #d32f2f;
            font-size: 9.5pt;
            font-weight: 900;
            letter-spacing: 0.8px;
            text-transform: uppercase;
            padding: 0.6mm 0;
            line-height: 1.1;
        }

        .header-stamp-box {
            width: 22%;
            border-left: 1.5px solid #000000;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0.8mm;
            background: #ffffff;
        }

        .header-stamp-img {
            max-height: 16mm;
            max-width: 95%;
            object-fit: contain;
        }

        /* SL. NO & Result Date & Student ID Bar */
        .sub-meta-bar {
            display: flex;
            border: 1.5px solid #000000;
            border-top: none;
            height: 5.5mm;
            align-items: stretch;
            flex-shrink: 0;
        }

        .sl-no-label {
            color: #2e7d32;
            font-style: italic;
            font-weight: 900;
            font-size: 8.5pt;
            padding: 0 2mm;
            display: flex;
            align-items: center;
            background: #ffffff;
        }

        .sl-no-val {
            background-color: #f5b041;
            font-size: 8pt;
            font-weight: 800;
            padding: 0 3mm;
            display: flex;
            align-items: center;
            border-left: 1px solid #000000;
            border-right: 1.5px solid #000000;
        }

        .result-date-box {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #0d47a1;
            font-weight: 800;
            font-size: 9pt;
            background: #ffffff;
        }

        .student-id-box {
            background-color: #fef9e7;
            border-left: 1.5px solid #000000;
            padding: 0 3.5mm;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 8.5pt;
            font-weight: 800;
            color: #000000;
        }

        /* Student Info Table */
        .student-info-table {
            width: 100%;
            border-collapse: collapse;
            border: 1.5px solid #000000;
            border-top: none;
            font-size: 8pt;
            flex-shrink: 0;
        }

        .student-info-table td {
            border: 1px solid #000000;
            padding: 0.7mm 2mm;
            vertical-align: middle;
            line-height: 1.15;
        }

        .bg-peach {
            background-color: #fdebd0;
        }

        .student-label {
            background-color: #fdebd0;
            font-weight: 800;
            font-style: italic;
            font-size: 7.8pt;
            color: #000000;
        }

        .student-val {
            font-weight: 800;
            font-size: 9.5pt;
            color: #000000;
        }

        /* Exam Title Bar */
        .exam-title-bar {
            border: 1.5px solid #000000;
            border-top: none;
            background-color: #ffffff;
            color: #2e7d32;
            font-size: 11pt;
            font-weight: 800;
            font-style: italic;
            text-align: center;
            padding: 0.8mm 0;
            flex-shrink: 0;
            line-height: 1.15;
        }

        /* Marks Table */
        .marks-table-wrap {
            border: 1.5px solid #000000;
            border-top: none;
            flex: 1 1 auto;
            min-height: 0;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .marks-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 8.5pt;
            height: 100%;
        }

        .marks-table th, .marks-table td {
            border: 1px solid #000000;
            text-align: center;
            vertical-align: middle;
            padding: 0.7mm 1mm;
            box-sizing: border-box;
            line-height: 1.15;
        }

        .subject-th {
            width: 26%;
            background-color: #ffffff;
            font-weight: 800;
            font-size: 8.5pt;
            text-transform: uppercase;
        }

        .marks-obtained-th {
            background-color: #fff200;
            font-size: 8.5pt;
            font-weight: 800;
            font-style: italic;
            padding: 0.6mm 0;
        }

        .th-fm {
            background-color: #f8bbd0;
            font-weight: 800;
            font-style: italic;
            font-size: 8pt;
            width: 12%;
        }

        .th-written {
            background-color: #90caf9;
            font-weight: 800;
            font-style: italic;
            font-size: 8pt;
            width: 13%;
        }

        .th-oral {
            background-color: #90caf9;
            font-weight: 800;
            font-style: italic;
            font-size: 8pt;
            width: 13%;
        }

        .th-total {
            background-color: #ffcdd2;
            font-weight: 800;
            font-style: italic;
            font-size: 8pt;
            width: 12%;
        }

        .th-pct {
            background-color: #ffcdd2;
            font-weight: 800;
            font-style: italic;
            font-size: 8pt;
            width: 13%;
        }

        .th-grade {
            background-color: #ffcdd2;
            font-weight: 800;
            font-style: italic;
            font-size: 8pt;
            width: 11%;
        }

        .marks-table td.subject-name-td {
            text-align: left;
            padding-left: 2.5mm;
            font-weight: 700;
            font-style: italic;
            font-size: 8.5pt;
        }

        .marks-table td.num-td {
            font-weight: 800;
            font-size: 8.5pt;
        }

        .marks-table tr.grand-total-row {
            background-color: #fbc02d;
            font-weight: 800;
        }

        .marks-table tr.grand-total-row td {
            border-top: 1.5px solid #000000;
            border-bottom: 1.5px solid #000000;
            padding: 0.8mm 1mm;
            font-weight: 900;
            font-size: 8.5pt;
        }

        .additional-header-row td {
            background-color: #ffffff;
            font-size: 8.5pt;
            font-weight: 800;
            font-style: italic;
            text-align: center;
            padding: 0.6mm 0;
            border-top: 1.5px solid #000000;
            border-bottom: 1.5px solid #000000;
        }

        .minor-sub-row {
            background-color: #fffde7;
        }

        /* Bottom Section Grid */
        .bottom-intel-section {
            display: flex;
            justify-content: space-between;
            margin-top: 2mm;
            flex-shrink: 0;
            min-height: 70mm;
            height: 70mm;
        }

        .bottom-col {
            width: 48.5%;
            display: flex;
            flex-direction: column;
            border: 1.5px solid #000000;
            background: #ffffff;
            box-sizing: border-box;
        }

        .bottom-header-banner {
            background-color: #fff200;
            border-bottom: 1px solid #000000;
            color: #000000;
            font-size: 8pt;
            font-weight: 800;
            font-style: italic;
            text-align: center;
            padding: 0.6mm 0;
            flex-shrink: 0;
        }

        .intel-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 7pt;
            flex: 1;
        }

        .intel-table td, .intel-table th {
            border: 1px solid #000000;
            text-align: center;
            vertical-align: middle;
            padding: 0.4mm 0.8mm;
            box-sizing: border-box;
            line-height: 1.15;
        }

        .intel-range-td {
            background-color: #ffe0b2;
            font-weight: 800;
            width: 32%;
        }

        .intel-desc-td {
            background-color: #ffffff;
            font-weight: 700;
            width: 46%;
        }

        .intel-grade-td {
            background-color: #ffe0b2;
            font-weight: 900;
            width: 22%;
        }

        /* Right Summary Table */
        .summary-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 7.5pt;
            flex: 1;
        }

        .summary-table td {
            border: 1px solid #000000;
            vertical-align: middle;
            padding: 0.4mm 1.5mm;
            box-sizing: border-box;
            line-height: 1.15;
        }

        .summary-label {
            font-weight: 800;
            text-align: left;
            width: 46%;
        }

        .summary-val {
            font-weight: 800;
            text-align: center;
            width: 54%;
        }

        .bg-blue-summary {
            background-color: #bbdefb;
        }

        .bg-highest-summary {
            background-color: #ffcc80;
        }

        /* Signature Bars */
        .sig-banner {
            background-color: #fff200;
            border-top: 1px solid #000000;
            border-bottom: 1px solid #000000;
            font-size: 7.5pt;
            font-weight: 800;
            font-style: italic;
            text-align: center;
            padding: 0.6mm 0;
            flex-shrink: 0;
        }

        .sig-box {
            height: 11mm;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #ffffff;
            padding: 0.8mm;
            flex-shrink: 0;
        }

        .headmaster-sig-img {
            max-height: 10mm;
            max-width: 90%;
            object-fit: contain;
        }

        /* Dynamic Density Scaling */
        .dense .top-invocation {
            margin-bottom: 0.8mm;
            font-size: 7.5pt;
        }
        .dense .school-name-text {
            font-size: 15pt;
        }
        .dense .header-meta-grid {
            height: 16.5mm;
        }
        .dense .header-logo-img, .dense .header-stamp-img {
            max-height: 14.5mm;
        }
        .dense .academic-year-text {
            font-size: 12pt;
        }
        .dense .sub-meta-bar {
            height: 5mm;
        }
        .dense .student-info-table td {
            padding: 0.5mm 1.5mm;
            font-size: 7.5pt;
        }
        .dense .student-val {
            font-size: 8.5pt;
        }
        .dense .exam-title-bar {
            padding: 0.6mm 0;
            font-size: 10pt;
        }
        .dense .marks-table th, .dense .marks-table td {
            padding: 0.45mm 0.8mm;
            font-size: 7.8pt;
        }
        .dense .marks-table td.subject-name-td {
            font-size: 7.8pt;
            padding-left: 2mm;
        }
        .dense .marks-table td.num-td {
            font-size: 7.8pt;
        }
        .dense .grand-total-row td {
            padding: 0.6mm 0.8mm;
            font-size: 8pt;
        }
        .dense .bottom-intel-section {
            min-height: 70mm;
            height: 70mm;
            margin-top: 1.5mm;
        }
        .dense .intel-table td, .dense .intel-table th {
            padding: 0.3mm 0.6mm;
            font-size: 6.8pt;
        }
        .dense .summary-table td {
            padding: 0.35mm 1.2mm;
            font-size: 7.2pt;
        }
        .dense .sig-box {
            height: 9.5mm;
        }
        .dense .headmaster-sig-img {
            max-height: 8.5mm;
        }

        .ultra-dense .top-invocation {
            margin-bottom: 0.5mm;
            font-size: 7pt;
        }
        .ultra-dense .school-name-bar {
            padding: 0.8mm 1mm;
        }
        .ultra-dense .school-name-text {
            font-size: 13.5pt;
        }
        .ultra-dense .address-bar {
            padding: 0.5mm 1mm;
            font-size: 6.5pt;
        }
        .ultra-dense .header-meta-grid {
            height: 15mm;
        }
        .ultra-dense .header-logo-img, .ultra-dense .header-stamp-img {
            max-height: 13mm;
        }
        .ultra-dense .academic-year-text {
            font-size: 11pt;
        }
        .ultra-dense .progress-report-banner {
            font-size: 8.5pt;
            padding: 0.4mm 0;
        }
        .ultra-dense .sub-meta-bar {
            height: 4.8mm;
        }
        .ultra-dense .student-info-table td {
            padding: 0.4mm 1.2mm;
            font-size: 7pt;
        }
        .ultra-dense .student-val {
            font-size: 8pt;
        }
        .ultra-dense .exam-title-bar {
            padding: 0.5mm 0;
            font-size: 9.5pt;
        }
        .ultra-dense .marks-table th, .ultra-dense .marks-table td {
            padding: 0.35mm 0.5mm;
            font-size: 7.2pt;
        }
        .ultra-dense .marks-table td.subject-name-td {
            font-size: 7.2pt;
            padding-left: 1.5mm;
        }
        .ultra-dense .marks-table td.num-td {
            font-size: 7.2pt;
        }
        .ultra-dense .grand-total-row td {
            padding: 0.5mm 0.8mm;
            font-size: 7.5pt;
        }
        .ultra-dense .bottom-intel-section {
            min-height: 70mm;
            height: 70mm;
            margin-top: 1.2mm;
        }
        .ultra-dense .intel-table td, .ultra-dense .intel-table th {
            padding: 0.25mm 0.5mm;
            font-size: 6.5pt;
        }
        .ultra-dense .summary-table td {
            padding: 0.3mm 1mm;
            font-size: 6.8pt;
        }
        .ultra-dense .sig-banner {
            padding: 0.4mm 0;
            font-size: 7pt;
        }
        .ultra-dense .sig-box {
            height: 8.5mm;
        }
        .ultra-dense .headmaster-sig-img {
            max-height: 7.5mm;
        }
    </style>
</head>
<body>

<?php
foreach ($result_ids as $result_id) {
    // Fetch student & result
    $stmt = $pdo->prepare("
        SELECT s.*, r.*, e.exam_name, e.exam_date, c.class_name, sec.section_name,
               emr.release_date 
        FROM results r 
        JOIN students s ON r.student_id = s.student_id 
        JOIN exams e ON r.exam_id = e.id 
        JOIN classes c ON r.class_id = c.id 
        LEFT JOIN sections sec ON r.section_id = sec.id 
        LEFT JOIN exam_marksheet_releases emr 
            ON emr.exam_id = r.exam_id AND emr.class_id = r.class_id
        WHERE r.id = ? 
        AND (s.status = 'Active' OR s.status = 'Alumni');
    ");
    $stmt->execute([$result_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$result) {
        continue;
    }

    $issue_date = '';
    if (!empty($result['release_date']) && strtotime($result['release_date']) > 0) {
        $issue_date = date('d/m/Y', strtotime($result['release_date']));
    } elseif (!empty($result['exam_date']) && strtotime($result['exam_date']) > 0) {
        $issue_date = date('d/m/Y', strtotime($result['exam_date']));
    } else {
        $issue_date = date('d/m/Y');
    }

    $academic_year = !empty($result['exam_date']) ? date('Y', strtotime($result['exam_date'])) : date('Y');
    
    // Serial Number (e.g., 26-0205)
    $year_short = date('y', strtotime($result['exam_date'] ?? 'now'));
    $roll_pad = str_pad($result['result_roll_no'] ?? $result['roll_no'] ?? $result['id'], 4, '0', STR_PAD_LEFT);
    $sl_no = !empty($result['registration_no']) ? $result['registration_no'] : ($year_short . '-' . $roll_pad);

    // Routine
    $routineStmtQuery = "SELECT * FROM exam_routines WHERE exam_id = ? AND class_id = ?";
    $routineStmt = $pdo->prepare($routineStmtQuery);
    $routineStmt->execute([$result['exam_id'], $result['class_id']]);
    $exam_routine = $routineStmt->fetchAll(PDO::FETCH_ASSOC);

    // Subjects & Marks
    $stmt = $pdo->prepare("
        SELECT sm.*, sub.subject_name, sub.subject_type, sub.marksheet_order_by 
        FROM subject_marks sm
        JOIN subjects sub ON sm.subject_id = sub.id
        WHERE sm.result_id = ? ORDER BY sub.marksheet_order_by
    ");
    $stmt->execute([$result_id]);
    $subject_marks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $main_subjects = [];
    $minor_subjects = [];
    $minor_subjects_total_marks = 0;
    $minor_subjects_obtained_marks = 0;

    foreach ($subject_marks as $subject) {
        if ($subject['is_excluded'] == 1) {
            continue;
        }

        $hasWrittenExam = true;
        $hasOralExam = true;

        foreach ($exam_routine as $routine) {
            if ($routine['subject_id'] == $subject['subject_id']) {
                if ($routine['theory_marks'] == 0) {
                    $hasWrittenExam = false;
                }
                if ($routine['practical_marks'] == 0) {
                    $hasOralExam = false;
                }
            }
        }

        $subject['has_written_exam'] = $hasWrittenExam;
        $subject['has_oral_exam'] = $hasOralExam;

        if (strtolower($subject['subject_type']) === 'minor') {
            $minor_subjects[] = $subject;
            if (!$include_minor_subjects_marks) {
                $minor_subjects_total_marks += $subject['total_marks'];
                $minor_subjects_obtained_marks += $subject['obtained_marks'];
            }
        } else {
            $main_subjects[] = $subject;
        }
    }

    // Default Fallback Grading System if database table is empty
    $stmt = $pdo->prepare("SELECT * FROM grading_system ORDER BY min_percentage DESC");
    $stmt->execute();
    $grading_system = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($grading_system)) {
        $grading_system = [
            ['min_percentage' => 90, 'max_percentage' => 100, 'grade' => 'AA', 'remarks' => 'Outstanding'],
            ['min_percentage' => 80, 'max_percentage' => 89, 'grade' => 'A+', 'remarks' => 'Excellent'],
            ['min_percentage' => 60, 'max_percentage' => 79, 'grade' => 'A', 'remarks' => 'Very Good'],
            ['min_percentage' => 45, 'max_percentage' => 59, 'grade' => 'B+', 'remarks' => 'Good'],
            ['min_percentage' => 35, 'max_percentage' => 44, 'grade' => 'B', 'remarks' => 'Satisfactory'],
            ['min_percentage' => 25, 'max_percentage' => 34, 'grade' => 'C', 'remarks' => 'Marginal'],
            ['min_percentage' => 0, 'max_percentage' => 24, 'grade' => 'D', 'remarks' => 'Disqualify'],
        ];
    }

    $section_id = $result['section_id'];
    if (!$section_based_ranking) {
        $section_id = null;
    }

    $top_rankers_table = getTopRankersForSingleMarksheet($pdo, $result['class_id'], $result['exam_id'], $include_minor_subjects_marks, $section_id, 5);
    $highest_marks = !empty($top_rankers_table) ? (float) round($top_rankers_table[0]['obtained_marks'] + ($include_minor_subjects_marks ? ($top_rankers_table[0]['obtained_minor_marks'] ?? 0) : 0), 2) : '-';

    // Recalculations
    $result['total_marks'] = $result['total_marks'] - $minor_subjects_total_marks;
    $result['obtained_marks'] = $result['obtained_marks'] - $minor_subjects_obtained_marks;

    if (!$include_minor_subjects_marks) {
        $result['percentage'] = $result['percentage_without_minor'];
        $result['grade'] = $result['grade_without_minor'];
        $result['remarks'] = $result['remarks_without_minor'];
    }

    $position_in_class_num = getStudentPositionInClass($pdo, $result['exam_id'], $result['class_id'], $result['student_id'], $include_minor_subjects_marks, $section_id);
    $result_status = getPassFailStatus($result['grade']);
    $pass_status = (stripos(strip_tags($result_status), 'pass') !== false) ? 'PASS' : 'FAIL';

    $has_minor = !empty($minor_subjects);
    $total_subs = count($main_subjects) + count($minor_subjects);

    $density_class = '';
    if ($total_subs > 12 || ($total_subs > 10 && count($grading_system) > 7)) {
        $density_class = 'ultra-dense';
    } elseif ($total_subs > 8 || count($grading_system) > 7) {
        $density_class = 'dense';
    }
?>

    <div class="marksheet-page">
        <div class="outer-frame <?= $density_class ?>">
            <!-- Top Invocation -->
            <div class="top-invocation">In the name of Allah , Most gracious ,Most Merciful</div>

            <!-- School Name Bar -->
            <div class="school-name-bar">
                <h1 class="school-name-text"><?= strtoupper(safe_htmlspecialchars($school_name)) ?></h1>
            </div>

            <!-- Address Bar -->
            <div class="address-bar">
                <?= $address_display ?>
            </div>

            <!-- 3-Column Header Meta Grid (Logo, Center Meta, Stamp) -->
            <div class="header-meta-grid">
                <div class="header-logo-box">
                    <?php if (!empty($school_logo_base64)): ?>
                        <img src="<?= $school_logo_base64 ?>" class="header-logo-img" alt="School Logo">
                    <?php endif; ?>
                </div>

                <div class="header-center-box">
                    <div class="estd-text">Estd - <?= safe_htmlspecialchars($school_established) ?></div>
                    <div class="academic-year-text">Academic Year - <?= safe_htmlspecialchars($academic_year) ?></div>
                    <div class="progress-report-banner">PROGRESS REPORT</div>
                </div>

                <div class="header-stamp-box">
                    <?php if (!empty($school_stamp_base64)): ?>
                        <img src="<?= $school_stamp_base64 ?>" class="header-stamp-img" alt="School Stamp">
                    <?php endif; ?>
                </div>
            </div>

            <!-- Sub-Meta Bar (SL. NO, Result Date, Student ID) -->
            <div class="sub-meta-bar">
                <div class="sl-no-label">SL. NO</div>
                <div class="sl-no-val"><?= safe_htmlspecialchars($sl_no) ?></div>
                <div class="result-date-box">Result Date- <?= safe_htmlspecialchars($issue_date) ?></div>
                <div class="student-id-box"><?= safe_htmlspecialchars($result['student_id']) ?></div>
            </div>

            <!-- Student Info Table -->
            <table class="student-info-table">
                <tr>
                    <td class="student-label" style="width: 17%;">Name :-</td>
                    <td class="student-val" style="width: 48%;"><?= safe_htmlspecialchars($result['name']) ?></td>
                    <td class="student-label" style="width: 15%; text-align: center;">Class :-</td>
                    <td class="student-val bg-peach" style="width: 20%; text-align: center; font-size: 11pt;"><?= safe_htmlspecialchars($result['class_name']) ?></td>
                </tr>
                <tr>
                    <td class="student-label" rowspan="2">Father's Name :-</td>
                    <td class="student-val" rowspan="2"><?= safe_htmlspecialchars($result['father_name']) ?></td>
                    <td class="student-label" style="text-align: center;">Section :-</td>
                    <td class="student-val" style="text-align: center;"><?= safe_htmlspecialchars($result['section_name'] ?? '-') ?></td>
                </tr>
                <tr>
                    <td class="student-label" style="text-align: center;">Roll :-</td>
                    <td class="student-val" style="text-align: center;"><?= safe_htmlspecialchars($result['result_roll_no'] ?? $result['roll_no'] ?? '-') ?></td>
                </tr>
            </table>

            <!-- Exam Title Bar -->
            <div class="exam-title-bar">
                <?= safe_htmlspecialchars($result['exam_name']) ?>
            </div>

            <!-- Academic Marks Table -->
            <div class="marks-table-wrap">
                <table class="marks-table">
                    <thead>
                        <tr>
                            <th rowspan="2" class="subject-th">SUBJECT</th>
                            <th colspan="6" class="marks-obtained-th">Marks Obtained</th>
                        </tr>
                        <tr>
                            <th class="th-fm">F.M</th>
                            <th class="th-written">Written</th>
                            <th class="th-oral">Oral</th>
                            <th class="th-total">Total</th>
                            <th class="th-pct">%</th>
                            <th class="th-grade">Grade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $total_fm = 0;
                        $total_written = 0;
                        $total_oral = 0;

                        foreach ($main_subjects as $sub): 
                            $total_fm += $sub['total_marks'];
                            if ($sub['has_written_exam'] && $sub['is_absent'] != 1) {
                                $total_written += $sub['theory_marks'];
                            }
                            if ($sub['has_oral_exam'] && $sub['is_absent'] != 1) {
                                $total_oral += $sub['practical_marks'];
                            }

                            $sub_pct = $sub['total_marks'] > 0 ? ($sub['obtained_marks'] / $sub['total_marks']) * 100 : 0;
                        ?>
                        <tr>
                            <td class="subject-name-td"><?= safe_htmlspecialchars($sub['subject_name']) ?></td>
                            <td class="num-td"><?= (float) round($sub['total_marks'], 2) ?></td>
                            <td class="num-td"><?= $sub['has_written_exam'] ? ($sub['is_absent'] == 1 ? '<span style="color:#d32f2f;">AB</span>' : (float) round($sub['theory_marks'], 2)) : '' ?></td>
                            <td class="num-td"><?= $sub['has_oral_exam'] ? ($sub['is_absent'] == 1 ? '<span style="color:#d32f2f;">AB</span>' : (float) round($sub['practical_marks'], 2)) : '' ?></td>
                            <td class="num-td"><?= (float) round($sub['obtained_marks'], 2) ?></td>
                            <td class="num-td"><?= number_format($sub_pct, 2) ?>%</td>
                            <td class="num-td"><?= safe_htmlspecialchars($sub['grade']) ?></td>
                        </tr>
                        <?php endforeach; ?>

                        <!-- Grand Total Row -->
                        <tr class="grand-total-row">
                            <td class="subject-name-td" style="text-align: center;">Grand Total</td>
                            <td class="num-td"><?= (float) round($total_fm, 2) ?></td>
                            <td class="num-td"><?= (float) round($total_written, 2) ?></td>
                            <td class="num-td"><?= (float) round($total_oral, 2) ?></td>
                            <td class="num-td"><?= (float) round($result['obtained_marks'], 2) ?></td>
                            <td class="num-td"><?= number_format($result['percentage'], 2) ?>%</td>
                            <td class="num-td"><?= safe_htmlspecialchars($result['grade']) ?></td>
                        </tr>

                        <!-- Additional / Minor Subjects Section -->
                        <?php if ($has_minor): ?>
                            <tr class="additional-header-row">
                                <td colspan="7">(Additional)</td>
                            </tr>
                            <?php foreach ($minor_subjects as $sub): 
                                $sub_pct = $sub['total_marks'] > 0 ? ($sub['obtained_marks'] / $sub['total_marks']) * 100 : 0;
                            ?>
                            <tr class="minor-sub-row">
                                <td class="subject-name-td"><?= safe_htmlspecialchars($sub['subject_name']) ?></td>
                                <td class="num-td"><?= (float) round($sub['total_marks'], 2) ?></td>
                                <td class="num-td"><?= $sub['has_written_exam'] ? ($sub['is_absent'] == 1 ? '<span style="color:#d32f2f;">AB</span>' : (float) round($sub['theory_marks'], 2)) : '' ?></td>
                                <td class="num-td"><?= $sub['has_oral_exam'] ? ($sub['is_absent'] == 1 ? '<span style="color:#d32f2f;">AB</span>' : (float) round($sub['practical_marks'], 2)) : '' ?></td>
                                <td class="num-td"><?= (float) round($sub['obtained_marks'], 2) ?></td>
                                <td class="num-td"><?= number_format($sub_pct, 2) ?>%</td>
                                <td class="num-td"><?= safe_htmlspecialchars($sub['grade']) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Bottom Section (Left: Performance Scale & Teacher Sign, Right: Term Summary & Headmaster Sign) -->
            <div class="bottom-intel-section">
                <!-- Left: Performance / Grading Scale -->
                <div class="bottom-col">
                    <div class="bottom-header-banner">Performance</div>
                    <table class="intel-table">
                        <tbody>
                            <?php foreach ($grading_system as $grade): ?>
                            <tr>
                                <td class="intel-range-td"><?= floor($grade['min_percentage']) . '-' . floor($grade['max_percentage']) ?></td>
                                <td class="intel-desc-td"><?= safe_htmlspecialchars($grade['remarks']) ?></td>
                                <td class="intel-grade-td"><?= safe_htmlspecialchars($grade['grade']) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div class="sig-banner">Signature of the Class Teacher</div>
                    <div class="sig-box"></div>
                </div>

                <!-- Right: Exam Summary & Headmaster Signature -->
                <div class="bottom-col">
                    <div class="bottom-header-banner"><?= strtoupper(safe_htmlspecialchars($result['exam_name'])) ?></div>
                    <table class="summary-table">
                        <tbody>
                            <tr>
                                <td class="summary-label bg-blue-summary">Full Marks</td>
                                <td class="summary-val bg-blue-summary"><?= (float) round($result['total_marks'], 2) ?></td>
                            </tr>
                            <tr>
                                <td class="summary-label">Marks Obtain</td>
                                <td class="summary-val"><?= (float) round($result['obtained_marks'], 2) ?></td>
                            </tr>
                            <tr>
                                <td class="summary-label">Percentage</td>
                                <td class="summary-val"><?= number_format($result['percentage'], 2) ?></td>
                            </tr>
                            <tr>
                                <td class="summary-label">Grade</td>
                                <td class="summary-val"><?= safe_htmlspecialchars($result['grade']) ?></td>
                            </tr>
                            <tr>
                                <td class="summary-label">Rank</td>
                                <td class="summary-val"><?= safe_htmlspecialchars($position_in_class_num ?? '-') ?></td>
                            </tr>
                            <tr>
                                <td class="summary-label bg-blue-summary">Result</td>
                                <td class="summary-val bg-blue-summary" style="font-weight: 900;"><?= $pass_status ?></td>
                            </tr>
                            <tr>
                                <td class="summary-label bg-highest-summary">Highest Marks</td>
                                <td class="summary-val bg-highest-summary"><?= safe_htmlspecialchars($highest_marks) ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="sig-banner">Signature of the Headmaster</div>
                    <div class="sig-box">
                        <?php if (!empty($headmaster_sign_base64)): ?>
                            <img src="<?= $headmaster_sign_base64 ?>" class="headmaster-sig-img" alt="Headmaster Signature">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php } // End of foreach ?>

<?php if ($fast_generation): ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const element = document.body;
        const opt = {
            margin: 0,
            filename: 'academic_progress_report.pdf',
            image: { type: 'jpeg', quality: 1 },
            html2canvas: { scale: 2, useCORS: true, windowWidth: element.scrollWidth },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
            pagebreak: { mode: ['avoid-all', 'legacy'] }
        };

        const isMobile = window.innerWidth <= 768;
        if (isMobile) {
            html2pdf().from(element).set(opt).save();
        }
    });
</script>
<?php endif; ?>

</body>
</html>
<?php
$all_html_content = ob_get_clean();

// For debugging: Save combined HTML to log file
file_put_contents($log_directory . 'single_marksheets_output.html', $all_html_content);

header("Content-Type: text/html; charset=UTF-8");
echo $all_html_content;
