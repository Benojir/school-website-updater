<?php
/** @var array $schoolInfo */
ini_set('memory_limit', '512M');
include_once(__DIR__ . "/../../../../includes/auth-check.php");
include_once(__DIR__ . "/../../../../includes/browsershot.php");

$log_directory = __DIR__ . '/../../../../assets/logs/';
if (!is_dir($log_directory)) {
    mkdir($log_directory, 0755, true);
}

use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;

if (!isset($_GET['result_ids'])) {
    die("Result IDs are required");
}

$raw_ids = explode(',', $_GET['result_ids']);
$placeholders = implode(',', array_fill(0, count($raw_ids), '?'));

// Numeric sorting by student roll number
$sortStmt = $pdo->prepare("
    SELECT r.id 
    FROM results r 
    JOIN students s ON r.student_id = s.student_id 
    WHERE r.id IN ($placeholders)
    ORDER BY CAST(s.roll_no AS UNSIGNED) ASC
");
$sortStmt->execute($raw_ids);
$result_ids = $sortStmt->fetchAll(PDO::FETCH_COLUMN);

// Verify release permissions for non-admin users
if (!isAnyAdminLoggedIn()) {
    $currentDateTime = date('Y-m-d H:i:s');
    $checkPlaceholders = implode(',', array_fill(0, count($result_ids), '?'));

    $checkQuery = "
        SELECT r.id, e.exam_name, c.class_name,
               emr.status as release_status, emr.release_date
        FROM results r
        JOIN exams e ON r.exam_id = e.id
        JOIN classes c ON r.class_id = c.id
        LEFT JOIN exam_marksheet_releases emr 
            ON emr.exam_id = r.exam_id AND emr.class_id = r.class_id
        WHERE r.id IN ($checkPlaceholders)
    ";
    $checkStmt = $pdo->prepare($checkQuery);
    $checkStmt->execute($result_ids);
    $rows = $checkStmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($rows)) {
        die("No marksheet results found.");
    }

    foreach ($rows as $row) {
        $examName = htmlspecialchars($row['exam_name']);
        $className = htmlspecialchars($row['class_name']);

        if (empty($row['release_status']) || $row['release_status'] !== 'released') {
            die("
                <div style='font-family: Arial, sans-serif; text-align: center; margin-top: 50px;'>
                    <div style='display: inline-block; padding: 30px; border: 1px solid #e0e0e0; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); max-width: 500px;'>
                        <h2 style='color: #dc3545; margin-bottom: 15px;'>Marksheet Not Released</h2>
                        <p style='color: #555; font-size: 16px; line-height: 1.5;'>The marksheet for <strong>{$examName}</strong> (Class: {$className}) has not been released yet.</p>
                    </div>
                </div>
            ");
        }

        if ($row['release_date'] > $currentDateTime) {
            $formattedDate = date('d M Y, h:i A', strtotime($row['release_date']));
            die("
                <div style='font-family: Arial, sans-serif; text-align: center; margin-top: 50px;'>
                    <div style='display: inline-block; padding: 30px; border: 1px solid #e0e0e0; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); max-width: 500px;'>
                        <h2 style='color: #fd7e14; margin-bottom: 15px;'>Marksheet Not Available Yet</h2>
                        <p style='color: #555; font-size: 16px; line-height: 1.5;'>The marksheet for <strong>{$examName}</strong> (Class: {$className}) is scheduled for release on <strong>{$formattedDate}</strong>.</p>
                        <p style='color: #777; font-size: 14px;'>Please check back after the scheduled release time.</p>
                    </div>
                </div>
            ");
        }
    }
}

// Fetch settings
$stmt = $pdo->prepare("SELECT * FROM settings_marksheet LIMIT 1");
$stmt->execute();
$marksheet_settings = $stmt->fetch(PDO::FETCH_ASSOC);

// Color Scheme
$theme_primary = $marksheet_settings['primary_theme_color'] ?? '#1e3a8a';
$theme_dark = $marksheet_settings['dark_theme_color'] ?? '#0f172a';
$theme_light = $marksheet_settings['light_theme_color'] ?? '#f0fdf4';
$page_background_color = $marksheet_settings['background_color'] ?? '#ffffff';
$school_name_color = $marksheet_settings['school_name_text_color'] ?? '#1e3a8a';
$school_address_color = $marksheet_settings['school_address_text_color'] ?? '#475569';

$hide_top_rankers = !empty($marksheet_settings['hide_top_rankers']);
$hide_position_in_class = !empty($marksheet_settings['hide_position_in_class']);
$show_text_watermark = !empty($marksheet_settings['show_text_watermark']);
$fast_generation = !empty($marksheet_settings['fast_generation']);
$include_minor_subjects_marks = !empty($marksheet_settings['include_minor_subjects_marks']);
$section_based_ranking = !empty($marksheet_settings['section_based_ranking']);

// School info
$school_name = $schoolInfo['name'];
$school_address = $schoolInfo['address'];
$school_phone = $schoolInfo['phone'];
$school_email = $schoolInfo['email'];

$school_logo_path = '../../../../uploads/school/logo-square.png';
$school_logo_base64 = imageToBase64($school_logo_path);

$headmaster_sign_path = '../../../../uploads/school/headmaster_sign.png';
$headmaster_sign_base64 = imageToBase64($headmaster_sign_path);

// Start buffer
ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Academic Transcript - <?= safe_htmlspecialchars($school_name) ?></title>
    <!-- Modern Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        @page {
            size: A4 portrait;
            margin: 0;
        }

        *, *::before, *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html, body {
            margin: 0;
            padding: 0;
            background-color: #f1f5f9;
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
            color: #1e293b;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        .marksheet-page {
            width: 210mm;
            height: 297mm;
            max-height: 297mm;
            padding: 5mm 6mm;
            margin: 0 auto;
            background-color: <?= safe_htmlspecialchars($page_background_color) ?>;
            break-after: always;
            page-break-after: always;
            box-sizing: border-box;
            position: relative;
        }

        .certificate-border {
            height: 100%;
            width: 100%;
            background: #ffffff;
            border: 2px solid <?= safe_htmlspecialchars($theme_primary) ?>;
            outline: 1.2px solid <?= safe_htmlspecialchars($theme_dark) ?>;
            outline-offset: -5px;
            padding: 5mm 6mm;
            position: relative;
            display: flex;
            flex-direction: column;
            box-shadow: 0 4px 14px rgba(0, 0, 0, 0.06);
        }

        /* Watermark Background */
        .watermark-bg {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 48%;
            opacity: 0.045;
            pointer-events: none;
            z-index: 1;
        }

        #text-watermark {
            color: rgba(100, 116, 139, 0.12);
            height: 100%;
            left: 0;
            line-height: 1.2;
            position: fixed;
            top: 0;
            transform: rotate(-32deg);
            transform-origin: 0 100%;
            width: 100%;
            font-size: 0.72rem;
            z-index: 1;
            user-select: none;
            pointer-events: none;
        }

        .content-layer {
            position: relative;
            z-index: 2;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        /* Header Styling */
        .header-section {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding-bottom: 1.5mm;
            border-bottom: 1.5px solid #e2e8f0;
            margin-bottom: 1.5mm;
            flex-shrink: 0;
        }

        .school-crest {
            width: 18mm;
            height: 18mm;
            object-fit: contain;
            border-radius: 50%;
            padding: 1px;
            border: 1.5px solid <?= safe_htmlspecialchars($theme_primary) ?>;
            background: #fff;
        }

        .school-info-center {
            text-align: center;
            flex: 1;
            padding: 0 3mm;
        }

        .school-title {
            font-family: 'Cinzel', serif;
            font-size: 1.45rem;
            font-weight: 700;
            letter-spacing: 0.8px;
            color: <?= safe_htmlspecialchars($school_name_color) ?>;
            line-height: 1.15;
            margin-bottom: 0.5mm;
            text-transform: uppercase;
        }

        .school-meta {
            font-size: 0.72rem;
            color: <?= safe_htmlspecialchars($school_address_color) ?>;
            line-height: 1.25;
        }

        .school-contact {
            font-size: 0.68rem;
            color: #64748b;
            margin-top: 0.3mm;
            font-weight: 500;
        }

        .school-crest-placeholder {
            width: 18mm;
            height: 18mm;
            visibility: hidden;
        }

        /* Banner Tag */
        .report-banner {
            text-align: center;
            margin-bottom: 2mm;
            flex-shrink: 0;
        }

        .report-banner span {
            display: inline-block;
            background: linear-gradient(135deg, <?= safe_htmlspecialchars($theme_primary) ?>, <?= safe_htmlspecialchars($theme_dark) ?>);
            color: #ffffff;
            font-size: 0.75rem;
            font-weight: 700;
            letter-spacing: 1.2px;
            text-transform: uppercase;
            padding: 0.8mm 5mm;
            border-radius: 30px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.12);
        }

        /* Student Details Box */
        .student-card {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            padding: 2mm 3mm;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2.5mm;
            flex-shrink: 0;
        }

        .student-fields {
            width: 82%;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1.5mm 3mm;
        }

        .field-group {
            display: flex;
            flex-direction: column;
        }

        .field-label {
            font-size: 0.6rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #64748b;
            line-height: 1;
            margin-bottom: 0.5mm;
        }

        .field-value {
            font-size: 0.8rem;
            font-weight: 700;
            color: #0f172a;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .student-photo-frame {
            width: 18mm;
            height: 21mm;
            border: 2px solid #ffffff;
            border-radius: 6px;
            overflow: hidden;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.12);
            background: #e2e8f0;
            flex-shrink: 0;
        }

        .student-photo-frame img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* Academic Marks Tables */
        .marks-section {
            display: flex;
            flex-direction: column;
            gap: 2.5mm;
            margin-bottom: 2.5mm;
            flex: 1; /* Automatically expands to fill page height when subjects are few */
            min-height: 80mm;
        }

        .marks-card {
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            overflow: hidden;
            background: #ffffff;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
            display: flex;
            flex-direction: column;
        }

        .marks-card-header {
            background: #f1f5f9;
            border-bottom: 1px solid #cbd5e1;
            padding: 1.2mm 3mm;
            font-size: 0.68rem;
            font-weight: 700;
            letter-spacing: 0.6px;
            text-transform: uppercase;
            color: <?= safe_htmlspecialchars($theme_dark) ?>;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-shrink: 0;
            height: 6mm;
            box-sizing: border-box;
        }

        .marks-card-header.minor-header {
            background: #f8fafc;
            color: #475569;
        }

        .marks-table-wrap {
            flex: 1;
            height: calc(100% - 6mm);
            width: 100%;
            overflow: hidden;
            display: block;
        }

        .marks-table {
            width: 100%;
            height: 100%;
            border-collapse: collapse;
            font-size: 0.74rem;
        }

        .marks-table th {
            background: <?= safe_htmlspecialchars($theme_primary) ?>;
            color: #ffffff;
            font-weight: 700;
            font-size: 0.68rem;
            letter-spacing: 0.4px;
            text-transform: uppercase;
            padding: 0.8mm 1.5mm;
            border: 1px solid rgba(255, 255, 255, 0.15);
            text-align: center;
            vertical-align: middle;
            height: 6mm;
            box-sizing: border-box;
        }

        .minor-card .marks-table th {
            background: <?= safe_htmlspecialchars($theme_dark) ?>;
        }

        .marks-table tr {
            height: 1%; /* Distributes available height equally among subject rows */
        }

        .marks-table td {
            padding: 1mm 1.5mm;
            border: 1px solid #e2e8f0;
            text-align: center;
            vertical-align: middle;
            color: #1e293b;
            font-weight: 500;
            line-height: 1.15;
            box-sizing: border-box;
        }

        .marks-table td.subject-title {
            text-align: left;
            padding-left: 3mm;
            font-weight: 600;
            color: #0f172a;
        }

        .marks-table tbody tr:nth-child(even) {
            background-color: #f8fafc;
        }

        .marks-table tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }

        .col-sub { width: 38%; }
        .col-val { width: 12.4%; }

        .grade-badge {
            display: inline-block;
            font-weight: 700;
            padding: 0.2mm 1.5mm;
            border-radius: 3px;
        }
        .grade-d { color: #dc2626; font-weight: 800; }
        .absent-text { color: #dc2626; font-weight: 700; }

        /* KPI Scorecard Grid */
        .scorecard-grid {
            display: grid;
            grid-template-columns: repeat(6, 1fr);
            gap: 2.5mm;
            margin-bottom: 2.5mm;
            flex-shrink: 0;
            height: 16mm;
        }

        .score-pill {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            padding: 1.2mm 1.5mm;
            text-align: center;
            display: flex;
            flex-direction: column;
            justify-content: center;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.03);
            box-sizing: border-box;
        }

        .score-label {
            font-size: 0.62rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.4px;
            color: #64748b;
            margin-bottom: 0.5mm;
        }

        .score-val {
            font-size: 1.02rem;
            font-weight: 800;
            color: <?= safe_htmlspecialchars($theme_primary) ?>;
            line-height: 1.15;
        }

        .status-passed { color: #16a34a !important; }
        .status-failed { color: #dc2626 !important; }

        /* Lower Row: Grading Scale & Top Performers / QR */
        .bottom-intel-row {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 3.5mm;
            margin-bottom: 2mm;
            flex-shrink: 0;
            height: 65mm;
            min-height: 65mm;
        }

        .intel-card {
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            background: #ffffff;
            display: flex;
            flex-direction: column;
            height: 65mm;
            min-height: 65mm;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
            overflow: hidden;
        }

        .intel-header {
            background: #f1f5f9;
            border-bottom: 1px solid #cbd5e1;
            padding: 1.2mm 3mm;
            font-size: 0.68rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.6px;
            color: <?= safe_htmlspecialchars($theme_primary) ?>;
            flex-shrink: 0;
            height: 6mm;
            box-sizing: border-box;
            display: flex;
            align-items: center;
        }

        .intel-table-wrap {
            flex: 1;
            height: calc(100% - 6mm);
            width: 100%;
            overflow: hidden;
            display: block;
        }

        .intel-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.68rem;
        }

        .intel-table th {
            background: #f8fafc;
            color: #475569;
            font-weight: 700;
            padding: 0.8mm 1.5mm;
            border-bottom: 1px solid #cbd5e1;
            text-align: center;
            font-size: 0.63rem;
            text-transform: uppercase;
            box-sizing: border-box;
        }

        .intel-table td {
            padding: 0.7mm 1.5mm;
            border-bottom: 1px solid #f1f5f9;
            text-align: center;
            color: #1e293b;
            line-height: 1.15;
            font-weight: 500;
            font-size: 0.68rem;
            box-sizing: border-box;
        }

        .intel-table tbody tr:nth-child(even) {
            background: #f8fafc;
        }

        /* Grading Scale: Distribute height equally across all rows so there is NO blank space at bottom */
        .grading-scale-col .intel-table-wrap {
            height: calc(100% - 6mm);
        }

        .grading-scale-col .intel-table {
            height: 100%;
        }

        .grading-scale-col .intel-table tr {
            height: 1%; /* Forces browser to distribute container height equally among all rows */
        }

        .grading-scale-col .intel-table th,
        .grading-scale-col .intel-table td {
            vertical-align: middle;
            padding: 0.6mm 1.5mm;
        }

        .grading-scale-col .intel-table tbody tr:last-child td {
            border-bottom: none;
        }

        /* Top Rankers: Standard row height so 1 to 5 rankers fit cleanly */
        .top-rankers-col .intel-table th {
            height: 6mm;
            vertical-align: middle;
        }

        .top-rankers-col .intel-table td {
            height: 9.5mm;
            vertical-align: middle;
            padding: 1mm 1.5mm;
        }

        .qr-wrapper {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            padding: 2mm;
        }

        .qr-wrapper img {
            max-height: 36mm;
            width: auto;
        }

        /* Signatures Section */
        .signatures-band {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 3mm;
            padding-top: 1mm;
            margin-top: auto;
            flex-shrink: 0;
            align-items: flex-end;
        }

        .sign-slot {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            position: relative;
        }

        .sign-img-box {
            height: 9mm;
            display: flex;
            align-items: flex-end;
            justify-content: center;
            margin-bottom: 1mm;
        }

        .sign-img-box img {
            max-height: 8.5mm;
            width: auto;
        }

        .sign-date-val {
            font-size: 0.78rem;
            font-weight: 700;
            color: #0f172a;
            line-height: 1.2;
            letter-spacing: 0.5px;
            padding-bottom: 0.5mm;
        }

        .sign-rule {
            width: 85%;
            height: 1px;
            background: #94a3b8;
            margin-bottom: 1mm;
        }

        .sign-designation {
            font-size: 0.65rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.4px;
            color: #334155;
        }

        /* Dynamic density adjustments when many subjects exist */
        .dense-subjects .marks-table td {
            padding: 0.6mm 1mm;
            font-size: 0.68rem;
        }
        .dense-subjects .marks-table th {
            padding: 0.7mm 1mm;
            font-size: 0.64rem;
        }
        .dense-subjects .marks-card-header {
            padding: 0.6mm 2.5mm;
            font-size: 0.64rem;
        }
        .dense-subjects .bottom-intel-row {
            min-height: 60mm;
        }

        .ultra-dense-subjects .marks-table td {
            padding: 0.35mm 0.8mm;
            font-size: 0.62rem;
        }
        .ultra-dense-subjects .marks-table th {
            padding: 0.5mm 0.8mm;
            font-size: 0.58rem;
        }
        .ultra-dense-subjects .bottom-intel-row {
            min-height: 58mm;
        }

        <?php if ($hide_top_rankers): ?>
        .top-rankers-col { display: none !important; }
        <?php else: ?>
        .qr-code-col { display: none !important; }
        <?php endif; ?>

        <?php if ($hide_position_in_class): ?>
        .pos-score-pill { display: none !important; }
        <?php endif; ?>
    </style>
</head>
<body>

<?php
foreach ($result_ids as $result_id) {
    // Fetch student & result
    $stmt = $pdo->prepare("
        SELECT s.*, r.*, e.exam_name, e.exam_date, c.class_name, sec.section_name,
               emr.release_date 
        FROM results r 
        JOIN students s ON r.student_id = s.student_id 
        JOIN exams e ON r.exam_id = e.id 
        JOIN classes c ON r.class_id = c.id 
        LEFT JOIN sections sec ON r.section_id = sec.id 
        LEFT JOIN exam_marksheet_releases emr 
            ON emr.exam_id = r.exam_id AND emr.class_id = r.class_id
        WHERE r.id = ? 
        AND (s.status = 'Active' OR s.status = 'Alumni');
    ");
    $stmt->execute([$result_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$result) {
        continue;
    }

    $issue_date = '';
    if (!empty($result['release_date']) && strtotime($result['release_date']) > 0) {
        $issue_date = date('d/m/Y', strtotime($result['release_date']));
    }

    // Routine
    $routineStmtQuery = "SELECT * FROM exam_routines WHERE exam_id = ? AND class_id = ?";
    $routineStmt = $pdo->prepare($routineStmtQuery);
    $routineStmt->execute([$result['exam_id'], $result['class_id']]);
    $exam_routine = $routineStmt->fetchAll(PDO::FETCH_ASSOC);

    // Subjects & Marks
    $stmt = $pdo->prepare("
        SELECT sm.*, sub.subject_name, sub.subject_type, sub.marksheet_order_by 
        FROM subject_marks sm
        JOIN subjects sub ON sm.subject_id = sub.id
        WHERE sm.result_id = ? ORDER BY sub.marksheet_order_by
    ");
    $stmt->execute([$result_id]);
    $subject_marks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $main_subjects = [];
    $minor_subjects = [];
    $minor_subjects_total_marks = 0;
    $minor_subjects_obtained_marks = 0;

    foreach ($subject_marks as $subject) {
        if ($subject['is_excluded'] == 1) {
            continue;
        }

        $hasWrittenExam = true;
        $hasOralExam = true;

        foreach ($exam_routine as $routine) {
            if ($routine['subject_id'] == $subject['subject_id']) {
                if ($routine['theory_marks'] == 0) {
                    $hasWrittenExam = false;
                }
                if ($routine['practical_marks'] == 0) {
                    $hasOralExam = false;
                }
            }
        }

        $subject['has_written_exam'] = $hasWrittenExam;
        $subject['has_oral_exam'] = $hasOralExam;

        if (strtolower($subject['subject_type']) === 'minor') {
            $minor_subjects[] = $subject;
            if (!$include_minor_subjects_marks) {
                $minor_subjects_total_marks += $subject['total_marks'];
                $minor_subjects_obtained_marks += $subject['obtained_marks'];
            }
        } else {
            $main_subjects[] = $subject;
        }
    }

    // Grading System
    $stmt = $pdo->prepare("SELECT * FROM grading_system ORDER BY min_percentage DESC");
    $stmt->execute();
    $grading_system = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $section_id = $result['section_id'];
    if (!$section_based_ranking) {
        $section_id = null;
    }

    $top_rankers_table = getTopRankersForSingleMarksheet($pdo, $result['class_id'], $result['exam_id'], $include_minor_subjects_marks, $section_id, 5);
    if (!empty($top_rankers_table)) {
        $top_rankers_table = array_slice($top_rankers_table, 0, 5);
    }

    // QR
    $qrContent = "Student: {$result['name']}\nID: {$result['student_id']}\nPercentage: " . number_format($result['percentage'], 2) . "%";
    $qrCode = new QrCode($qrContent);
    $writer = new PngWriter();
    $qr_code_base64 = $writer->write($qrCode)->getDataUri();

    // Photo
    $student_photo_path = '../../../../uploads/students/' . $result['student_image'];
    $student_photo_base64 = imageToBase64($student_photo_path);

    // Recalculations
    $result['total_marks'] = $result['total_marks'] - $minor_subjects_total_marks;
    $result['obtained_marks'] = $result['obtained_marks'] - $minor_subjects_obtained_marks;

    if (!$include_minor_subjects_marks) {
        $result['percentage'] = $result['percentage_without_minor'];
        $result['grade'] = $result['grade_without_minor'];
        $result['remarks'] = $result['remarks_without_minor'];
    }

    $position_in_class = getOrdinal(getStudentPositionInClass($pdo, $result['exam_id'], $result['class_id'], $result['student_id'], $include_minor_subjects_marks, $section_id));
    $result_status = getPassFailStatus($result['grade']);

    $has_minor = !empty($minor_subjects);
    $total_subs = count($main_subjects) + count($minor_subjects);

    $density_class = '';
    if ($total_subs > 14) {
        $density_class = 'ultra-dense-subjects';
    } elseif ($total_subs > 10) {
        $density_class = 'dense-subjects';
    }
?>

    <div class="marksheet-page">
        <div class="certificate-border <?= $density_class ?>">
            <!-- Watermark -->
            <?php if (!empty($school_logo_base64)): ?>
                <img src="<?= $school_logo_base64 ?>" class="watermark-bg" alt="Watermark">
            <?php endif; ?>
            <span id="text-watermark"></span>

            <div class="content-layer">
                <!-- Header -->
                <header class="header-section">
                    <?php if (!empty($school_logo_base64)): ?>
                        <img src="<?= $school_logo_base64 ?>" class="school-crest" alt="Crest">
                    <?php else: ?>
                        <div class="school-crest-placeholder"></div>
                    <?php endif; ?>

                    <div class="school-info-center">
                        <h1 class="school-title"><?= safe_htmlspecialchars($school_name) ?></h1>
                        <p class="school-meta"><?= safe_htmlspecialchars($school_address) ?></p>
                        <p class="school-contact">Phone: <?= safe_htmlspecialchars($school_phone) ?> &bull; Email: <?= safe_htmlspecialchars($school_email) ?></p>
                    </div>

                    <?php if (!empty($school_logo_base64)): ?>
                        <img src="<?= $school_logo_base64 ?>" class="school-crest" alt="Crest" style="visibility:hidden;">
                    <?php else: ?>
                        <div class="school-crest-placeholder"></div>
                    <?php endif; ?>
                </header>

                <!-- Banner -->
                <div class="report-banner">
                    <span>ACADEMIC PERFORMANCE REPORT &mdash; <?= strtoupper(safe_htmlspecialchars($result['exam_name'])) ?></span>
                </div>

                <!-- Student Information Card -->
                <section class="student-card">
                    <div class="student-fields">
                        <div class="field-group">
                            <span class="field-label">Student Name</span>
                            <span class="field-value"><?= safe_htmlspecialchars($result['name']) ?></span>
                        </div>
                        <div class="field-group">
                            <span class="field-label">Roll Number</span>
                            <span class="field-value"><?= safe_htmlspecialchars($result['result_roll_no'] ?? '-') ?></span>
                        </div>
                        <div class="field-group">
                            <span class="field-label">Student ID</span>
                            <span class="field-value"><?= safe_htmlspecialchars($result['student_id']) ?></span>
                        </div>
                        <div class="field-group">
                            <span class="field-label">Class & Section</span>
                            <span class="field-value"><?= safe_htmlspecialchars($result['class_name']) ?> &bull; <?= safe_htmlspecialchars($result['section_name']) ?></span>
                        </div>
                        <div class="field-group">
                            <span class="field-label">Father's Name</span>
                            <span class="field-value"><?= safe_htmlspecialchars($result['father_name']) ?></span>
                        </div>
                        <div class="field-group">
                            <span class="field-label">Academic Session / Date</span>
                            <span class="field-value"><?= safe_htmlspecialchars($result['exam_date'] ?? date('Y')) ?></span>
                        </div>
                    </div>

                    <div class="student-photo-frame">
                        <img src="<?= $student_photo_base64 ?>" alt="Student Photo">
                    </div>
                </section>

                <!-- Marks Tables (Main & Minor separated, no Subject Type column) -->
                <?php
                $has_minor = !empty($minor_subjects);
                $main_flex = $has_minor ? (count($main_subjects) + 1) : 1;
                $minor_flex = $has_minor ? (count($minor_subjects) + 1) : 1;
                ?>
                <div class="marks-section">
                    <!-- Main Subjects Table -->
                    <div class="marks-card main-card" style="flex: <?= $main_flex ?>;">
                        <div class="marks-card-header">
                            <span>Main / Core Subjects</span>
                            <small style="font-size:0.6rem;opacity:0.8;font-weight:normal;">Compulsory Academic Subjects</small>
                        </div>
                        <div class="marks-table-wrap">
                            <table class="marks-table">
                                <thead>
                                    <tr>
                                        <th class="col-sub">Subject Name</th>
                                        <th class="col-val">Full Marks</th>
                                        <th class="col-val">Written</th>
                                        <th class="col-val">Oral</th>
                                        <th class="col-val">Marks Obtained</th>
                                        <th class="col-val">Grade</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($main_subjects as $sub): ?>
                                    <tr>
                                        <td class="subject-title"><?= safe_htmlspecialchars($sub['subject_name']) ?></td>
                                        <td><?= (float) round($sub['total_marks'], 2) ?></td>
                                        <td><?= $sub['has_written_exam'] ? ($sub['is_absent'] == 1 ? '<span class="absent-text">AB</span>' : (float) round($sub['theory_marks'], 2)) : '-' ?></td>
                                        <td><?= $sub['has_oral_exam'] ? ($sub['is_absent'] == 1 ? '<span class="absent-text">AB</span>' : (float) round($sub['practical_marks'], 2)) : '-' ?></td>
                                        <td><strong><?= (float) round($sub['obtained_marks'], 2) ?></strong></td>
                                        <td>
                                            <span class="grade-badge <?= ($sub['grade'] === 'D' ? 'grade-d' : '') ?>">
                                                <?= safe_htmlspecialchars($sub['grade']) ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Minor Subjects Table (Rendered only if student has minor subjects) -->
                    <?php if ($has_minor): ?>
                    <div class="marks-card minor-card" style="flex: <?= $minor_flex ?>;">
                        <div class="marks-card-header minor-header">
                            <span>Minor / Additional Subjects</span>
                            <small style="font-size:0.6rem;opacity:0.8;font-weight:normal;">Co-Scholastic Evaluations</small>
                        </div>
                        <div class="marks-table-wrap">
                            <table class="marks-table">
                                <thead>
                                    <tr>
                                        <th class="col-sub">Subject Name</th>
                                        <th class="col-val">Full Marks</th>
                                        <th class="col-val">Written</th>
                                        <th class="col-val">Oral</th>
                                        <th class="col-val">Marks Obtained</th>
                                        <th class="col-val">Grade</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($minor_subjects as $sub): ?>
                                    <tr>
                                        <td class="subject-title"><?= safe_htmlspecialchars($sub['subject_name']) ?></td>
                                        <td><?= (float) round($sub['total_marks'], 2) ?></td>
                                        <td><?= $sub['has_written_exam'] ? ($sub['is_absent'] == 1 ? '<span class="absent-text">AB</span>' : (float) round($sub['theory_marks'], 2)) : '-' ?></td>
                                        <td><?= $sub['has_oral_exam'] ? ($sub['is_absent'] == 1 ? '<span class="absent-text">AB</span>' : (float) round($sub['practical_marks'], 2)) : '-' ?></td>
                                        <td><strong><?= (float) round($sub['obtained_marks'], 2) ?></strong></td>
                                        <td>
                                            <span class="grade-badge <?= ($sub['grade'] === 'D' ? 'grade-d' : '') ?>">
                                                <?= safe_htmlspecialchars($sub['grade']) ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Executive Scorecard (Modern KPI Metrics) -->
                <div class="scorecard-grid">
                    <div class="score-pill">
                        <span class="score-label">Full Marks</span>
                        <span class="score-val"><?= (float) round($result['total_marks'], 2) ?></span>
                    </div>
                    <div class="score-pill">
                        <span class="score-label">Obtained</span>
                        <span class="score-val"><?= (float) round($result['obtained_marks'], 2) ?></span>
                    </div>
                    <div class="score-pill">
                        <span class="score-label">Percentage</span>
                        <span class="score-val"><?= (float) round($result['percentage'], 2) ?>%</span>
                    </div>
                    <div class="score-pill">
                        <span class="score-label">Overall Grade</span>
                        <span class="score-val"><?= safe_htmlspecialchars($result['grade']) ?></span>
                    </div>
                    <div class="score-pill pos-score-pill">
                        <span class="score-label">Class Rank</span>
                        <span class="score-val"><?= $position_in_class ?></span>
                    </div>
                    <div class="score-pill">
                        <span class="score-label">Result Status</span>
                        <span class="score-val <?= (stripos($result_status, 'pass') !== false ? 'status-passed' : 'status-failed') ?>">
                            <?= strtoupper($result_status) ?>
                        </span>
                    </div>
                </div>

                <!-- Lower Intel Grid: Grading Scale & Top Achievers / QR Verification -->
                <div class="bottom-intel-row">
                    <!-- Left: Grading Scale (Full height so all 8-9 rows are clearly visible) -->
                    <div class="intel-card grading-scale-col">
                        <div class="intel-header">Official Grading Scale</div>
                        <div class="intel-table-wrap">
                            <table class="intel-table">
                                <thead>
                                    <tr>
                                        <th>Percentage</th>
                                        <th>Grade</th>
                                        <th>Performance</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($grading_system as $grade): ?>
                                    <tr>
                                        <td><?= floor($grade['min_percentage']) . '% - ' . floor($grade['max_percentage']) . '%' ?></td>
                                        <td><strong><?= safe_htmlspecialchars($grade['grade']) ?></strong></td>
                                        <td><?= safe_htmlspecialchars($grade['remarks']) ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Right (Option A): Top Rankers -->
                    <div class="intel-card top-rankers-col">
                        <div class="intel-header">Top Performers in Class</div>
                        <div class="intel-table-wrap">
                            <table class="intel-table">
                                <thead>
                                    <tr>
                                        <th style="width:18%;">Rank</th>
                                        <th style="width:46%;text-align:left;padding-left:3mm;">Student Name</th>
                                        <th style="width:20%;">Percentage</th>
                                        <th style="width:16%;">Grade</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (!empty($top_rankers_table)): ?>
                                        <?php 
                                        $displayed_rankers = 0;
                                        foreach ($top_rankers_table as $ranker): 
                                            if ($displayed_rankers >= 5) break;
                                            $displayed_rankers++;
                                        ?>
                                        <tr>
                                            <td><strong><?= getOrdinal($ranker['rank']) ?></strong></td>
                                            <td style="text-align:left;padding-left:3mm;font-weight:600;"><?= safe_htmlspecialchars($ranker['name']) ?></td>
                                            <td><?= number_format($ranker['percentage'], 2) ?>%</td>
                                            <td><span class="grade-badge"><?= safe_htmlspecialchars($ranker['grade']) ?></span></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="4" style="color:#94a3b8;padding:8mm 0;">No rankers data available</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Right (Option B): QR Code Verification -->
                    <div class="intel-card qr-code-col">
                        <div class="intel-header">Document Verification</div>
                        <div class="qr-wrapper">
                            <img src="<?= $qr_code_base64 ?>" alt="Verification QR">
                            <p style="font-size:0.65rem;color:#64748b;margin-top:1.5mm;font-weight:600;">Scan to verify transcript authenticity</p>
                        </div>
                    </div>
                </div>

                <!-- Signatures Band (Anchored at the very bottom) -->
                <footer class="signatures-band">
                    <div class="sign-slot">
                        <div class="sign-img-box"></div>
                        <div class="sign-rule"></div>
                        <span class="sign-designation">Class Teacher</span>
                    </div>

                    <div class="sign-slot">
                        <div class="sign-img-box">
                            <?php if (!empty($issue_date)): ?>
                                <span class="sign-date-val"><?= safe_htmlspecialchars($issue_date) ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="sign-rule"></div>
                        <span class="sign-designation">Date of Issue</span>
                    </div>

                    <div class="sign-slot">
                        <div class="sign-img-box"></div>
                        <div class="sign-rule"></div>
                        <span class="sign-designation">Parent / Guardian</span>
                    </div>

                    <div class="sign-slot">
                        <div class="sign-img-box">
                            <?php if (!empty($headmaster_sign_base64)): ?>
                                <img src="<?= $headmaster_sign_base64 ?>" alt="Signature">
                            <?php endif; ?>
                        </div>
                        <div class="sign-rule"></div>
                        <span class="sign-designation">Headmaster</span>
                    </div>
                </footer>
            </div>
        </div>
    </div>

<?php } // End of foreach ?>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        <?php if ($show_text_watermark): ?>
        var textWatermark = <?= json_encode($school_name) ?>;
        var fullTextWatermark = '';
        var n = 10000;
        for (var i = 0; i < n; i++) {
            fullTextWatermark += ' ' + textWatermark;
        }
        var watermarkElem = document.getElementById('text-watermark');
        if (watermarkElem) {
            watermarkElem.innerHTML = fullTextWatermark;
        }
        <?php endif; ?>
    });
</script>

<?php if ($fast_generation): ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const element = document.body;
        const opt = {
            margin: 0,
            filename: 'academic_transcript.pdf',
            image: { type: 'jpeg', quality: 1 },
            html2canvas: { scale: 2, useCORS: true, windowWidth: element.scrollWidth },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
            pagebreak: { mode: ['avoid-all', 'legacy'] }
        };

        const isMobile = window.innerWidth <= 768;
        if (isMobile) {
            html2pdf().from(element).set(opt).save();
        }
    });
</script>
<?php endif; ?>

</body>
</html>
<?php
$all_html_content = ob_get_clean();

// For debugging: Save the combined HTML to log file
file_put_contents($log_directory . 'single_marksheets_output.html', $all_html_content);

header("Content-Type: text/html; charset=UTF-8");
echo $all_html_content;
