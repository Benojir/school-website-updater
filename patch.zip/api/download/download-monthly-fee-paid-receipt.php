<?php
require_once('../../../vendor/autoload.php');
require_once('../../includes/config.php');

// Check if ID is provided in GET request
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid receipt ID");
}

$id = $_GET['id'];

// Fetch payment details
$stmt = $pdo->prepare("SELECT * FROM student_full_paid_fees WHERE id = ?");
$stmt->execute([$id]);
$payment = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$payment) {
    die("Payment record not found");
}

// Fetch student details
$stmt = $pdo->prepare("
SELECT students.*, classes.class_name AS class
FROM students
LEFT JOIN classes ON classes.id = students.class_id
WHERE students.student_id = ?
");
$stmt->execute([$payment['student_id']]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

// Create new PDF document - A4 size for better readability
$pdf = new TCPDF('P', PDF_UNIT, 'A4', true, 'UTF-8', false);

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('School Management System');
$pdf->SetTitle('Fee Receipt - ' . $payment['student_id']);
$pdf->SetSubject('Fee Payment Receipt');
$pdf->SetKeywords('Receipt, Fee, School, Payment');

// Remove default header/footer
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);

// Set margins
$pdf->SetMargins(20, 20, 20);
$pdf->SetAutoPageBreak(TRUE, 20);

// Add a page
$pdf->AddPage();

// Define colors
$primaryColor = array(44, 62, 80);      // Dark blue-gray
$secondaryColor = array(52, 152, 219);  // Professional blue
$accentColor = array(231, 76, 60);      // Red for highlights
$successColor = array(46, 204, 113);    // Green for totals
$lightBg = array(248, 249, 250);        // Very light gray
$borderColor = array(189, 195, 199);    // Light border

// Professional border - draw first
$pdf->SetDrawColor($borderColor[0], $borderColor[1], $borderColor[2]);
$pdf->SetLineWidth(0.5);
$pdf->Rect(10, 10, 190, 277, 'D');

// Header section with school info - NOW INSIDE MARGINS
$headerStartY = 10; // Start at top margin
$pdf->SetFillColor($primaryColor[0], $primaryColor[1], $primaryColor[2]);
$pdf->Rect(10, $headerStartY, 190, 35, 'F'); // Width adjusted to fit within margins

// School information
$pdf->SetTextColor(255, 255, 255);
$pdf->SetFont('helvetica', 'B', 20);
$pdf->SetXY(20, $headerStartY + 8);
$pdf->Cell(170, 8, strtoupper($schoolInfo['name']), 0, 1, 'C');
$pdf->SetFont('helvetica', '', 11);
$pdf->SetXY(20, $headerStartY + 20);
$pdf->Cell(170, 5, 'Phone: ' . $schoolInfo['phone'] . ' | Email: ' . $schoolInfo['email'], 0, 1, 'C');

// Receipt title section - adjusted position
$titleY = $headerStartY + 35;
$pdf->SetFillColor($secondaryColor[0], $secondaryColor[1], $secondaryColor[2]);
$pdf->Rect(10, $titleY, 190, 18, 'F'); // Width adjusted to fit within margins
$pdf->SetTextColor(255, 255, 255);
$pdf->SetFont('helvetica', 'B', 16);
$pdf->SetXY(20, $titleY + 5);
$pdf->Cell(170, 8, 'FEE RECEIPT', 0, 1, 'C');

// Receipt details section with better spacing - adjusted position
$startY = $titleY + 28; // Adjusted to account for new header position
$pdf->SetTextColor($primaryColor[0], $primaryColor[1], $primaryColor[2]);

// Create info box with border
$pdf->SetDrawColor($borderColor[0], $borderColor[1], $borderColor[2]);
$pdf->SetFillColor($lightBg[0], $lightBg[1], $lightBg[2]);
$pdf->Rect(20, $startY, 170, 38, 'DF');

// Receipt information in organized layout
$infoY = $startY + 8;
$leftCol = 25;
$rightCol = 110;
$labelWidth = 35;
$valueWidth = 70;
$lineHeight = 7;

// Left column information
$pdf->SetFont('helvetica', 'B', 10);
$pdf->SetXY($leftCol, $infoY);
$pdf->Cell($labelWidth, $lineHeight, 'Receipt No:', 0, 0, 'L');
$pdf->SetFont('helvetica', '', 10);
$pdf->Cell($valueWidth, $lineHeight, 'REC-' . str_pad($payment['id'], 6, '0', STR_PAD_LEFT), 0, 1, 'L');

if ($student) {
    $infoY += $lineHeight;
    $pdf->SetXY($leftCol, $infoY);
    $pdf->SetFont('helvetica', 'B', 10);
    $pdf->Cell($labelWidth, $lineHeight, 'Student Name:', 0, 0, 'L');
    $pdf->SetFont('helvetica', '', 10);
    $pdf->Cell($valueWidth, $lineHeight, ucwords(strtolower($student['name'])), 0, 1, 'L');

    $infoY += $lineHeight;
    $pdf->SetXY($leftCol, $infoY);
    $pdf->SetFont('helvetica', 'B', 10);
    $pdf->Cell($labelWidth, $lineHeight, 'Class:', 0, 0, 'L');
    $pdf->SetFont('helvetica', '', 10);
    $pdf->Cell($valueWidth, $lineHeight, $student['class'], 0, 1, 'L');
}

// Right column information
$infoY = $startY + 8;
$pdf->SetXY($rightCol, $infoY);
$pdf->SetFont('helvetica', 'B', 10);
$pdf->Cell($labelWidth, $lineHeight, 'Date:', 0, 0, 'L');
$pdf->SetFont('helvetica', '', 10);
$pdf->Cell($valueWidth, $lineHeight, date('d M Y', strtotime($payment['created_at'])), 0, 1, 'L');

$infoY += $lineHeight;
$pdf->SetXY($rightCol, $infoY);
$pdf->SetFont('helvetica', 'B', 10);
$pdf->Cell($labelWidth, $lineHeight, 'Period:', 0, 0, 'L');
$pdf->SetFont('helvetica', '', 10);
$pdf->Cell($valueWidth, $lineHeight, $payment['month_year'], 0, 1, 'L');

$infoY += $lineHeight;
$pdf->SetXY($rightCol, $infoY);
$pdf->SetFont('helvetica', 'B', 10);
$pdf->Cell($labelWidth, $lineHeight, 'Mode:', 0, 0, 'L');
$pdf->SetFont('helvetica', '', 10);
$pdf->Cell($valueWidth, $lineHeight, 'Cash Payment', 0, 1, 'L');

// Payment breakdown table with professional design - adjusted position
$tableY = $startY + 50; // Adjusted for new layout
$pdf->SetY($tableY);

// Table header with gradient-like effect
$pdf->SetFillColor($primaryColor[0], $primaryColor[1], $primaryColor[2]);
$pdf->SetTextColor(255, 255, 255);
$pdf->SetFont('helvetica', 'B', 12);
$pdf->SetDrawColor($primaryColor[0], $primaryColor[1], $primaryColor[2]);

$pdf->SetXY(20, $tableY);
$pdf->Cell(100, 10, 'DESCRIPTION', 1, 0, 'C', true);
$pdf->Cell(70, 10, 'AMOUNT', 1, 1, 'C', true);

// Table rows with alternating colors
$pdf->SetFont('helvetica', '', 11);
$pdf->SetDrawColor($borderColor[0], $borderColor[1], $borderColor[2]);
$rowHeight = 8;

// Actual fee row
$tableY += 10;
$pdf->SetFillColor(255, 255, 255);
$pdf->SetTextColor($primaryColor[0], $primaryColor[1], $primaryColor[2]);
$pdf->SetXY(20, $tableY);
$pdf->Cell(100, $rowHeight, '  Monthly Fee (Base Amount)', 1, 0, 'L', true);
$pdf->SetFont('helvetica', 'B', 11);
$pdf->Cell(70, $rowHeight, number_format($payment['actual_amount'], 2), 1, 1, 'R', true);

// Discount row
$tableY += $rowHeight;
$pdf->SetFillColor($lightBg[0], $lightBg[1], $lightBg[2]);
$pdf->SetTextColor($accentColor[0], $accentColor[1], $accentColor[2]);
$pdf->SetFont('helvetica', '', 11);
$pdf->SetXY(20, $tableY);
$pdf->Cell(100, $rowHeight, '  Less: Discount Applied', 1, 0, 'L', true);
$pdf->SetFont('helvetica', 'B', 11);
$pdf->Cell(70, $rowHeight, '- ' . number_format($payment['discount_amount'], 2), 1, 1, 'R', true);

// Separator line
$tableY += $rowHeight;
$pdf->SetDrawColor($primaryColor[0], $primaryColor[1], $primaryColor[2]);
$pdf->Line(20, $tableY, 190, $tableY);

// Total amount row with emphasis
$tableY += 2;
$pdf->SetFillColor($successColor[0], $successColor[1], $successColor[2]);
$pdf->SetTextColor(255, 255, 255);
$pdf->SetFont('helvetica', 'B', 14);
$pdf->SetDrawColor($successColor[0], $successColor[1], $successColor[2]);
$pdf->SetXY(20, $tableY);
$pdf->Cell(100, 12, '  NET AMOUNT PAID', 1, 0, 'L', true);
$pdf->SetFont('helvetica', 'B', 16);
$pdf->Cell(70, 12, number_format($payment['total_paid_amount'], 2), 1, 1, 'C', true);

// Amount in words
$pdf->SetTextColor($primaryColor[0], $primaryColor[1], $primaryColor[2]);
$pdf->SetFont('helvetica', 'I', 10);
$pdf->SetXY(20, $tableY + 18);
$pdf->Cell(170, 6, 'Amount in words: ' . ucwords(convertNumberToWords($payment['total_paid_amount'])) . ' Rupees Only', 0, 1, 'L');

// Remarks section with better formatting
if (!empty($payment['remark'])) {
    $remarksY = $tableY + 30;
    $pdf->SetDrawColor($borderColor[0], $borderColor[1], $borderColor[2]);
    $pdf->SetFillColor($lightBg[0], $lightBg[1], $lightBg[2]);
    $pdf->Rect(20, $remarksY, 170, 20, 'DF');

    $pdf->SetTextColor($primaryColor[0], $primaryColor[1], $primaryColor[2]);
    $pdf->SetFont('helvetica', 'B', 10);
    $pdf->SetXY(25, $remarksY + 5);
    $pdf->Cell(0, 6, 'REMARKS:', 0, 1, 'L');
    $pdf->SetFont('helvetica', '', 9);
    $pdf->SetXY(25, $remarksY + 12);
    $pdf->MultiCell(160, 5, $payment['remark'], 0, 'L');
}

// Signature section with professional layout
$sigY = 220;
$pdf->SetDrawColor($borderColor[0], $borderColor[1], $borderColor[2]);
$pdf->Line(20, $sigY, 190, $sigY);

$pdf->SetTextColor($primaryColor[0], $primaryColor[1], $primaryColor[2]);
$pdf->SetFont('helvetica', '', 9);
$pdf->SetXY(25, $sigY + 15);
$pdf->Cell(50, 5, 'Date: ' . date('d/m/Y'), 0, 0, 'L');
$pdf->SetXY(145, $sigY + 15);
$pdf->Cell(40, 5, 'Authorized Signature', 0, 1, 'C');

// Principle Signature Image
$photo_width = 20;

if (file_exists('../../uploads/school/principle_sign.png')) {
    $pdf->Image('../../uploads/school/principle_sign.png', 155, $sigY + 5, $photo_width, 0, '', '', 'T', false, 300, '', false, false, 0, false, false, false);
}

// Footer with modern styling
$pdf->SetY(250);
$pdf->SetFont('helvetica', 'I', 8);
$pdf->SetTextColor(120, 120, 120);
$pdf->Cell(0, 4, 'This is a computer-generated receipt and does not require a physical signature.', 0, 1, 'C');
$pdf->Cell(0, 4, 'Please retain this receipt for your records. Thank you for your payment!', 0, 1, 'C');

// Close and output PDF document
$filename = 'Fee_Receipt_' . $payment['student_id'] . '_' . date('Y-m-d_His') . '.pdf';
$pdf->Output($filename, 'I');

// Helper function to convert numbers to words (basic implementation)
function convertNumberToWords($number)
{
    $words = array(
        0 => 'zero',
        1 => 'one',
        2 => 'two',
        3 => 'three',
        4 => 'four',
        5 => 'five',
        6 => 'six',
        7 => 'seven',
        8 => 'eight',
        9 => 'nine',
        10 => 'ten',
        11 => 'eleven',
        12 => 'twelve',
        13 => 'thirteen',
        14 => 'fourteen',
        15 => 'fifteen',
        16 => 'sixteen',
        17 => 'seventeen',
        18 => 'eighteen',
        19 => 'nineteen',
        20 => 'twenty',
        30 => 'thirty',
        40 => 'forty',
        50 => 'fifty',
        60 => 'sixty',
        70 => 'seventy',
        80 => 'eighty',
        90 => 'ninety'
    );

    if ($number < 21) {
        return $words[$number];
    } elseif ($number < 100) {
        $tens = intval($number / 10) * 10;
        $units = $number % 10;
        return $words[$tens] . ($units ? ' ' . $words[$units] : '');
    } elseif ($number < 1000) {
        $hundreds = intval($number / 100);
        $remainder = $number % 100;
        return $words[$hundreds] . ' hundred' . ($remainder ? ' ' . convertNumberToWords($remainder) : '');
    }

    return 'amount exceeds word conversion limit';
}
