<?php
define('ID_CARD_AUDIENCE', 'teacher');
require __DIR__ . '/generate-student-id-cards.php';
