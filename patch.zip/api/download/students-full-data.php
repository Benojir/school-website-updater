<?php
/** @var array $schoolInfo */
ini_set('memory_limit', '512M'); // or '1G' for very large files
include_once(__DIR__ . "/../../includes/auth-check.php");

$student_ids_string = $_REQUEST['student_ids'] ?? '';
$student_ids = explode(',', $student_ids_string);

if (empty($student_ids_string) || count($student_ids) == 0) {
    echo "No student IDs provided.";
    exit();
}

if (!isAnyAdminLoggedIn()) {
    echo "Access denied. Admin privileges required.";
    exit();
}

// Remove duplicate student IDs
$student_ids = array_unique($student_ids);

$principal_signature = BASE_URL . '/uploads/school/principle_sign.png?v=' . time();
$school_logo = BASE_URL . '/uploads/school/logo-square.png?v=' . time();

function calculateAge(string $dob) {
    $dobDate = new DateTime($dob);
    $today = new DateTime();
    $age = $today->diff($dobDate)->y;
    return $age;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Student Information Sheet - School Songi</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;500;600;700&display=swap');

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html,
        body {
            font-family: 'Noto Sans', Arial, sans-serif;
            color: #1a1a1a;
            font-size: 10px;
            line-height: 1.35;
        }

        /* ===== Print page setup - A4 Portrait ===== */
        @page {
            size: A4 portrait;
            margin: 8mm 7mm;
        }

        @media print {
            body {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }

            .no-print {
                display: none !important;
            }
        }

        /* ===== Header (appears only on first page, due to natural document flow) ===== */
        .school-header {
            display: flex;
            align-items: center;
            gap: 12px;
            border: 2px solid #14532d;
            border-radius: 6px;
            padding: 10px 14px;
            margin-bottom: 10px;
            background: #f0fdf4;
        }

        .school-header .logo-box {
            width: 62px;
            height: 62px;
            min-width: 62px;
            border: 1px dashed #14532d;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 8px;
            color: #14532d;
            text-align: center;
            overflow: hidden;
            background: #fff;
        }

        .school-header .logo-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .school-header .school-text {
            flex: 1;
        }

        .school-header .school-name {
            font-size: 20px;
            font-weight: 700;
            color: #14532d;
        }

        .school-header .foundation-name {
            font-size: 11px;
            font-weight: 600;
            color: #3f6212;
        }

        .school-header .school-meta {
            font-size: 9.5px;
            color: #333;
            margin-top: 2px;
        }

        .sheet-title {
            text-align: center;
            font-size: 13px;
            font-weight: 700;
            margin: 6px 0 10px;
            text-decoration: underline;
            color: #14532d;
        }

        /* ===== Card container ===== */
        .cards-wrap {
            width: 100%;
        }

        .student-card {
            display: inline-block;
            vertical-align: top;
            width: 49%;
            border: 1.4px solid #444;
            border-radius: 5px;
            padding: 7px 8px;
            margin-bottom: 8px;
            page-break-inside: avoid;
            break-inside: avoid;
        }

        .student-card:nth-child(odd) {
            margin-right: 1.6%;
        }

        .card-top {
            display: flex;
            gap: 8px;
            border-bottom: 1px solid #999;
            padding-bottom: 5px;
            margin-bottom: 5px;
        }

        .photo-box {
            width: 60px;
            height: 72px;
            min-width: 60px;
            border: 1px dashed #555;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 7.5px;
            color: #555;
            text-align: center;
            overflow: hidden;
        }

        .photo-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .card-title .student-name {
            font-size: 13px;
            font-weight: 700;
            word-break: break-word;
        }

        .card-title .sub-line {
            font-size: 9.5px;
            color: #333;
            margin-top: 1px;
        }

        .id-row {
            font-size: 8.6px;
            margin-top: 3px;
            display: flex;
            flex-wrap: wrap;
            gap: 2px 8px;
        }

        .id-row span b {
            color: #14532d;
        }

        /* ===== Info grid ===== */
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1px 8px;
            font-size: 8.8px;
            margin-bottom: 4px;
        }

        .info-grid .full {
            grid-column: 1 / -1;
        }

        .info-grid div {
            word-break: break-word;
            overflow-wrap: anywhere;
        }

        .info-grid b {
            color: #222;
            font-weight: 600;
        }

        .section-label {
            font-size: 9px;
            font-weight: 700;
            background: #eee;
            padding: 2px 5px;
            margin: 4px 0 2px;
            border-radius: 3px;
            color: #14532d;
        }

        /* ===== Bank details ===== */
        .bank-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1px 8px;
            font-size: 8.6px;
            margin-bottom: 4px;
        }

        .bank-grid .full {
            grid-column: 1 / -1;
            word-break: break-word;
        }

        /* ===== Signatures ===== */
        /* All 4 boxes share the same fixed height and bottom-align their label text,
     so "Father's Signature / Mother's Signature / Student's Signature / Headmaster's Signature"
     all sit on the same line, whether the box has a blank line or a signature image above it. */
        .sign-row {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 4px;
            margin-top: 8px;
        }

        .sign-box {
            height: 38px;
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
            align-items: center;
            text-align: center;
            font-size: 7.8px;
        }

        .sign-box .sign-line {
            flex: 1;
            width: 100%;
            border-top: 1px solid #444;
        }

        .sign-box.hm-sign .hm-sign-img {
            width: 100%;
            height: 26px;
            border: 1px dashed #888;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 7px;
            color: #888;
            overflow: hidden;
            margin-bottom: 2px;
        }

        .sign-box.hm-sign .hm-sign-img img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }

        .footer-note {
            text-align: center;
            font-size: 8px;
            color: #666;
            margin-top: 10px;
        }
    </style>
</head>

<body>

    <!-- ================= School header (shows only on the first page, due to normal document flow) ================= -->
    <div class="school-header">
        <div class="logo-box"><img src="<?= $school_logo ?>" alt="Logo" onerror="this.parentElement.textContent='School Logo'"></div>
        <div class="school-text">
            <div class="school-name"><?= safe_htmlspecialchars($schoolInfo['name']) ?></div>
            <div class="foundation-name">Managed by: <?= safe_htmlspecialchars($schoolInfo['foundation_name'] ?? '') ?></div>
            <div class="school-meta">Address: <?= safe_htmlspecialchars($schoolInfo['address']) ?> | Phone: <?= safe_htmlspecialchars($schoolInfo['phone']) ?></div>
        </div>
    </div>
    <div class="sheet-title">Student Information Sheet</div>

    <!-- ================= Card container — loop through students in PHP and output one .student-card per student ================= -->
    <div class="cards-wrap" id="cardsWrap">

        <?php
        foreach ($student_ids as $student_id) {
            $student = getStudentInfo($pdo, $student_id);
        ?>
            <div class="student-card">
                <div class="card-top">
                    <div class="photo-box"><img src="<?= BASE_URL . '/uploads/students/' . $student['student_image'] ?>" alt="photo"></div>
                    <div class="card-title">
                        <div class="student-name"><?= safe_htmlspecialchars($student['name']) ?></div>
                        <div class="sub-line">Class: <b><?= safe_htmlspecialchars($student['class_name']) ?></b> &nbsp;|&nbsp; Section: <b><?= safe_htmlspecialchars($student['section_name']) ?></b> &nbsp;|&nbsp; Roll: <b><?= safe_htmlspecialchars($student['roll_no']) ?></b></div>
                        <div class="id-row">
                            <span><b>Student ID:</b> <?= safe_htmlspecialchars($student['student_id']) ?></span>
                            <span><b>Reg. ID:</b> <?= safe_htmlspecialchars($student['registration_no']) ?></span>
                            <span><b>BSSC:</b> <?= safe_htmlspecialchars($student['banglar_shiksha_code']) ?></span>
                        </div>
                    </div>
                </div>

                <div class="info-grid">
                    <div><b>Aadhaar No:</b> <?= safe_htmlspecialchars($student['student_adhaar_no']) ?></div>
                    <div><b>Age:</b> <?= safe_htmlspecialchars(calculateAge($student['date_of_birth'])) ?></div>
                    <div><b>Date of Birth:</b> <?= safe_htmlspecialchars($student['date_of_birth']) ?></div>
                    <div><b>Admission Date:</b> <?= safe_htmlspecialchars($student['admission_date']) ?></div>
                    <div class="full"><b>Academic Year:</b> <?= safe_htmlspecialchars($student['academic_year']) ?></div>
                </div>

                <div class="section-label">Parent / Guardian Information</div>
                <div class="info-grid">
                    <div><b>Father's Name:</b> <?= safe_htmlspecialchars($student['father_name']) ?></div>
                    <div><b>Father's Occupation:</b> <?= safe_htmlspecialchars($student['father_occupation']) ?></div>
                    <div><b>Father's Income:</b> <?= safe_htmlspecialchars($student['father_annual_income']) ?></div>
                    <div><b>Father's Aadhaar No:</b> <?= safe_htmlspecialchars($student['father_adhaar_no']) ?></div>
                    <div><b>Father's Mobile No:</b> <?= safe_htmlspecialchars($student['phone_number']) ?></div>
                    <div><b>Mother's Name:</b> <?= safe_htmlspecialchars($student['mother_name']) ?></div>
                    <div><b>Mother's Occupation:</b> <?= safe_htmlspecialchars($student['mother_occupation']) ?></div>
                    <div><b>Mother's Income:</b> <?= safe_htmlspecialchars($student['mother_annual_income']) ?></div>
                    <div><b>Mother's Aadhaar No:</b> <?= safe_htmlspecialchars($student['mother_adhaar_no']) ?></div>
                    <div><b>Mother's Mobile No:</b> <?= safe_htmlspecialchars($student['alternate_phone_number']) ?></div>
                    <div class="full"><b>Address:</b> <?= safe_htmlspecialchars($student['address']) ?></div>
                </div>

                <div class="section-label">Bank Account Details</div>
                <div class="bank-grid">
                    <div><b>Account No:</b> <?= safe_htmlspecialchars($student['bank_account_no']) ?></div>
                    <div><b>Bank Name:</b> <?= safe_htmlspecialchars($student['bank_name']) ?></div>
                    <div><b>Branch:</b> <?= safe_htmlspecialchars($student['bank_branch_name']) ?></div>
                    <div><b>IFSC Code:</b> <?= safe_htmlspecialchars($student['ifsc_code']) ?></div>
                </div>

                <div class="sign-row">
                    <div class="sign-box">
                        <div class="sign-line"></div>Father's Signature
                    </div>
                    <div class="sign-box">
                        <div class="sign-line"></div>Mother's Signature
                    </div>
                    <div class="sign-box">
                        <div class="sign-line"></div>Student's Signature
                    </div>
                    <div class="sign-box hm-sign">
                        <div class="hm-sign-img"><img src="<?= $principal_signature ?>" alt="Principal's Sign"></div>
                        Principal's Signature
                    </div>
                </div>
            </div>
        <?php
        }
        ?>
    </div>

    <div class="footer-note no-print">
        * Before printing, press Ctrl+P and keep "Background graphics" checked so the header colors print correctly.<br>
        * To remove the browser's own title/URL/date text at the top and bottom of the page: open "More settings" in the print dialog and <b>uncheck</b> "Headers and footers".
    </div>

</body>

</html>