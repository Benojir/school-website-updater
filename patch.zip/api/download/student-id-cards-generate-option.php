<?php

/**
 * student-id-cards-generate-option.php
 * UI to let user choose between Old ID Card Generator and New Builder Generator.
 *
 * When the active canvas template is double-sided, this page also asks HOW the
 * back sides should reach the paper — see the $has_back block below.
 */
include_once("../../includes/auth-check.php");

// Verifying student_ids from the request
$raw_student_ids = $_POST['student_ids'] ?? $_GET['student_ids'] ?? '';
$student_ids = json_decode($raw_student_ids, true);

if (!is_array($student_ids) || empty($student_ids)) {
    die("<div style='text-align:center; margin-top:50px; font-family:sans-serif; color:#dc2626;'><h3>Error: No valid students selected!</h3><p>Please select at least one student and try again.</p></div>");
}

$student_count = count($student_ids);

// Does the active canvas design have a back side? Only then is there a choice
// of print arrangement to offer.
$has_back = false;
try {
    $stmt = $pdo->query("SELECT has_back, back_design_json FROM student_id_card_templates WHERE is_active = 1 LIMIT 1");
    $tpl = $stmt->fetch(PDO::FETCH_ASSOC);
    $has_back = $tpl && !empty($tpl['has_back']) && !empty($tpl['back_design_json']);
} catch (Exception $e) {
    $has_back = false; // no template saved yet — the generator itself reports that
}

include_once("../../includes/header-open.php");
?>
<title>Select ID Card Generation Method</title>
<style>
    body {
        background-color: #f3f4f6;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        padding: 20px;
    }

    .selection-card {
        background: #ffffff;
        border-radius: 16px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
        max-width: 650px;
        width: 100%;
        padding: 35px;
    }

    .option-box {
        border: 2px solid #e5e7eb;
        border-radius: 12px;
        padding: 24px 20px;
        cursor: pointer;
        transition: all 0.25s ease-in-out;
        text-align: center;
        background: #ffffff;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }

    .option-box:hover {
        border-color: #4f46e5;
        transform: translateY(-4px);
        box-shadow: 0 12px 20px rgba(79, 70, 229, 0.12);
    }

    .icon-circle {
        width: 65px;
        height: 65px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 16px;
        font-size: 26px;
    }

    .icon-old {
        background: #eef2ff;
        color: #4f46e5;
    }

    .icon-new {
        background: #ecfdf5;
        color: #059669;
    }

    .badge-count {
        background: #e0e7ff;
        color: #3730a3;
        font-size: 0.85rem;
        padding: 6px 14px;
        border-radius: 20px;
        display: inline-block;
        margin-bottom: 20px;
        font-weight: 600;
    }

    /* Double-sided print arrangement (only shown for a two-sided design) */
    .duplex-options {
        text-align: left;
        background: #f9fafb;
        border: 1px solid #e5e7eb;
        border-radius: 8px;
        padding: 10px 12px;
        margin-top: 14px;
        cursor: default;
    }
    .duplex-options .duplex-title {
        font-size: 0.7rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .04em;
        color: #6b7280;
        margin-bottom: 8px;
    }
    .duplex-options label {
        display: block;
        font-size: 0.78rem;
        color: #374151;
        cursor: pointer;
        margin-bottom: 6px;
    }
    .duplex-options label:last-child { margin-bottom: 0; }
    .duplex-options label span {
        display: block;
        font-size: 0.68rem;
        color: #9ca3af;
        padding-left: 20px;
    }
</style>

<?php include_once("../../includes/header-close.php"); ?>

<div class="selection-card">
    <div class="text-center">
        <span class="badge-count">
            <i class="fa-solid fa-users me-1"></i> Selected students count: <?= $student_count ?>
        </span>
        <h3 class="fw-bold mb-2 text-dark">ID Card Generation Method</h3>
        <p class="text-muted small mb-4">Select which designer/method you want to use to generate the ID cards</p>
    </div>

    <div class="row g-4">
        <!-- Old Version Option -->
        <div class="col-md-6">
            <div class="option-box" onclick="submitToTarget('download-student-id-card.php')">
                <div>
                    <div class="icon-circle icon-old">
                        <i class="fa-solid fa-id-card-clip"></i>
                    </div>
                    <h5 class="fw-bold text-dark mb-1">Classic Layout</h5>
                    <span class="badge bg-secondary-subtle text-secondary mb-2">Old Template</span>
                    <p class="text-muted small mb-0">HTML/CSS based pre-defined general format.</p>
                </div>
                <button class="btn btn-outline-primary btn-sm w-100 mt-3 rounded-pill">
                    Generate Classic <i class="fa-solid fa-arrow-right ms-1"></i>
                </button>
            </div>
        </div>

        <!-- New Version Option -->
        <div class="col-md-6">
            <div class="option-box" onclick="submitToTarget('generate-student-id-cards.php')">
                <div>
                    <div class="icon-circle icon-new">
                        <i class="fa-solid fa-wand-magic-sparkles"></i>
                    </div>
                    <h5 class="fw-bold text-dark mb-1">Custom Builder</h5>
                    <span class="badge bg-success-subtle text-success mb-2">New Fabric Engine</span>
                    <p class="text-muted small mb-0">Custom layout and high-quality print created in the canvas builder.</p>

                    <?php if ($has_back): ?>
                        <!-- The active design is double-sided, so ask how the backs
                             should be arranged on the paper. stopPropagation keeps a
                             click in here from triggering the box's own onclick and
                             submitting before a choice is made. -->
                        <div class="duplex-options" onclick="event.stopPropagation();">
                            <div class="duplex-title"><i class="fa-solid fa-clone me-1"></i> Double-sided printing</div>
                            <label>
                                <input type="radio" name="duplexLayout" value="sequential" checked>
                                Fronts sheet, then backs sheet
                                <span>For a duplex printer — set it to flip on the <b>long edge</b>.</span>
                            </label>
                            <label>
                                <input type="radio" name="duplexLayout" value="side-by-side">
                                Front &amp; back side-by-side
                                <span>Works on any printer — cut out and laminate back-to-back.</span>
                            </label>
                        </div>
                    <?php endif; ?>
                </div>
                <button class="btn btn-success btn-sm w-100 mt-3 rounded-pill">
                    Generate New <i class="fa-solid fa-arrow-right ms-1"></i>
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Dynamic Form for POST submission -->
<form id="redirectForm" method="POST" style="display: none;">
    <input type="hidden" name="student_ids" value="<?= htmlspecialchars($raw_student_ids, ENT_QUOTES, 'UTF-8') ?>">
    <!-- Only meaningful for the Custom Builder path with a double-sided design;
         generate-student-id-cards.php ignores it otherwise. -->
    <input type="hidden" name="duplex_layout" id="duplexLayoutField" value="sequential">
</form>

<script>
    function submitToTarget(actionFile) {
        const form = document.getElementById('redirectForm');
        const chosen = document.querySelector('input[name="duplexLayout"]:checked');
        if (chosen) {
            document.getElementById('duplexLayoutField').value = chosen.value;
        }
        form.action = actionFile;
        form.submit();
    }
</script>

<?php include_once("../../includes/body-close.php"); ?>