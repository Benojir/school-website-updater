<?php
ini_set('memory_limit', '512M'); // or '1G' for very large files
include_once(__DIR__ . "/../../includes/auth-check.php");
include_once(__DIR__ . "/../../includes/browsershot.php");

$log_directory = __DIR__ . '/../../assets/logs/';
if (!is_dir($log_directory)) {
    mkdir($log_directory, 0755, true);
}

use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;

// Check for permission
// if (!hasPermission(PERM_MANAGE_RESULTS)) {
//     die("You do not have permission to perform this action.");
// }

if (!isset($_GET['result_ids'])) {
    die("Result IDs are required");
}

$result_ids = explode(',', $_GET['result_ids']);

// Fetch marksheet settings
$stmt = $pdo->prepare("SELECT * FROM settings_marksheet LIMIT 1");
$stmt->execute();
$marksheet_settings = $stmt->fetch(PDO::FETCH_ASSOC);

// Load HTML template and CSS
$css_style = file_get_contents('../../assets/templates/marksheet-templates/single-marksheets/design1/style.css');
$css_style = str_replace(
    [
        '{{theme_primary}}',
        '{{theme_dark}}',
        '{{theme_light}}',
        '{{page_background_color}}',
        '{{school_name_text_color}}',
        '{{school_address_text_color}}'
    ],
    [
        $marksheet_settings['primary_theme_color'],
        $marksheet_settings['dark_theme_color'],
        $marksheet_settings['light_theme_color'],
        $marksheet_settings['background_color'],
        $marksheet_settings['school_name_text_color'],
        $marksheet_settings['school_address_text_color']
    ],
    $css_style
);
$css = "<style>" . $css_style . "</style>";

$header_html = file_get_contents('../../assets/templates/marksheet-templates/header.html');
$header_html = str_replace('<link rel="stylesheet" href="style.css">', $css, $header_html);
$footer_html = file_get_contents('../../assets/templates/marksheet-templates/footer.html');

$footer_js_html = file_get_contents('../../assets/templates/marksheet-templates/single-marksheets/design1/js.html');
$content_html = file_get_contents('../../assets/templates/marksheet-templates/single-marksheets/design1/content.html');


$all_html_content = $header_html;

// School information
$school_name = $schoolInfo['name'];
$school_address = $schoolInfo['address'];
$school_phone = $schoolInfo['phone'];
$school_email = $schoolInfo['email'];

$school_logo_path = '../../uploads/school/logo-square.png';
$school_logo_base64 = imageToBase64($school_logo_path);

$principle_sign_path = '../../uploads/school/principle_sign.png';
$principal_sign_base64 = imageToBase64($principle_sign_path);


// Process each result ID
foreach ($result_ids as $result_id) {
    // Fetch result details with student and exam information
    $stmt = $pdo->prepare("
        SELECT r.*, s.*, e.exam_name, e.exam_date, c.class_name, sec.section_name 
        FROM results r 
        JOIN students s ON r.student_id = s.student_id 
        JOIN exams e ON r.exam_id = e.id 
        JOIN classes c ON r.class_id = c.id 
        LEFT JOIN sections sec ON s.section_id = sec.id 
        WHERE r.id = ? 
        AND (s.status = 'Active' OR s.status = 'Alumni');

    ");
    $stmt->execute([$result_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$result) {
        continue; // Skip if result not found
    }

    // Fetch exam routine
    $routineStmtQuery = "SELECT * FROM exam_routines WHERE exam_id = ? AND class_id = ?";
    $routineStmt = $pdo->prepare($routineStmtQuery);
    $routineStmt->execute([$result['exam_id'], $result['class_id']]);
    $exam_routine = $routineStmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch subject marks
    $stmt = $pdo->prepare("
        SELECT sm.*, sub.subject_name, sub.subject_type, sub.marksheet_order_by 
        FROM subject_marks sm
        JOIN subjects sub ON sm.subject_id = sub.id
        WHERE sm.result_id = ? ORDER BY sub.marksheet_order_by
    ");
    $stmt->execute([$result_id]);
    $subject_marks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Build subject rows HTML
    $minor_subjects_total_marks = 0;
    $minor_subjects_obtained_marks = 0;
    $subject_rows = "";
    foreach ($subject_marks as $subject) {

        if ($subject['is_excluded'] == 1) {
            continue; // Skipping excluded subjects
        }

        $hasWrittenExam = true;
        $hasOralExam = true;

        foreach ($exam_routine as $routine) {
            if ($routine['subject_id'] == $subject['subject_id']) {
                if ($routine['theory_marks'] == 0) {
                    $hasWrittenExam = false;
                }
                if ($routine['practical_marks'] == 0) {
                    $hasOralExam = false;
                }
            }
        }

        $tr = "<tr>";
        if (!$marksheet_settings['include_minor_subjects_marks']) {
            if (strtolower($subject['subject_type']) == "minor") {
                $tr = "<tr style='color:#ff8800;font-weight:bold;'>";
                $minor_subjects_total_marks += $subject['total_marks'];
                $minor_subjects_obtained_marks += $subject['obtained_marks'];
            }
        }

        $subject_rows .= "{$tr}
            <td>" . safe_htmlspecialchars($subject['subject_name']) . "</td>
            <td>" . safe_htmlspecialchars($subject['subject_type']) . "</td>
            <td>" . ($hasWrittenExam ? ($subject['is_absent'] == 1 ? '<span style="color:red;">AB</span>' : (float) round($subject['theory_marks'], 2)) : '-') . "</td>
            <td>" . ($hasOralExam ? ($subject['is_absent'] == 1 ? '<span style="color:red;">AB</span>' : (float) round($subject['practical_marks'], 2)) : '-') . "</td>
            <td>" . (float) round($subject['total_marks'], 2) . "</td>
            <td>" . (float) round($subject['obtained_marks'], 2) . "</td>
            <td>" . ($subject['grade'] == 'D' ? "<b style='color:red;'>D</b>" : "<strong>" . safe_htmlspecialchars($subject['grade']) . "</strong>") . "</td>
        </tr>";
    }

    // Fetch grading system
    $stmt = $pdo->prepare("SELECT * FROM grading_system ORDER BY min_percentage DESC");
    $stmt->execute();
    $grading_system = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $grading_rows = "";
    foreach ($grading_system as $grade) {
        $range = floor($grade['min_percentage']) . '% - ' . floor($grade['max_percentage']) . '%';
        $grading_rows .= "<tr>
            <td>" . $range . "</td>
            <td><strong>" . safe_htmlspecialchars($grade['grade']) . "</strong></td>
            <td>" . safe_htmlspecialchars($grade['remarks']) . "</td>
        </tr>";
    }

    $section_id = $result['section_id'];

    if (!$marksheet_settings['section_based_ranking']) {
        $section_id = null;
    }

    // Generate Top Rankers Table
    $top_rankers_rows = "";
    $top_rankers_table = getTopRankersForSingleMarksheet($pdo, $result['class_id'], $result['exam_id'], $marksheet_settings['include_minor_subjects_marks'], $section_id);
    foreach ($top_rankers_table as $ranker) {
        $top_rankers_rows .= "<tr>
            <td>" . getOrdinal($ranker['rank']) . "</td>
            <td>" . safe_htmlspecialchars($ranker['name']) . "</td>
            <td>" . number_format($ranker['percentage'], 2) . "%</td>
            <td>" . safe_htmlspecialchars($ranker['grade']) . "</td>
        </tr>";
    }

    // Generate QR Code
    $qrContent = "Student: {$result['name']}\nID: {$result['student_id']}\nPercentage: " . number_format($result['percentage'], 2) . "%";
    $qrCode = new QrCode($qrContent);
    $writer = new PngWriter();
    $qr_code_base64 = $writer->write($qrCode)->getDataUri();

    // Student Photo Base64
    $student_photo_path = '../../uploads/students/' . $result['student_image'];
    $student_photo_base64 = imageToBase64($student_photo_path);

    // Promotion Status
    $promotion_status_row = $result['is_promoted'] ? '<tr><td><strong>Promotion Status:</strong></td><td colspan="3">Promoted</td></tr>' : '';

    // Re-calculate total marks, obtained marks and percentage
    $result['total_marks'] = $result['total_marks'] - $minor_subjects_total_marks;
    $result['obtained_marks'] = $result['obtained_marks'] - $minor_subjects_obtained_marks;

    if (!$marksheet_settings['include_minor_subjects_marks']) {
        $result['percentage'] = $result['percentage_without_minor'];
        $result['grade'] = $result['grade_without_minor'];
        $result['remarks'] = $result['remarks_without_minor'];
    }

    // Replace placeholders in the template
    $page_html = $content_html;
    $placeholders = [
        '{{school_logo_base64}}'      => $school_logo_base64,
        '{{school_name}}'             => safe_htmlspecialchars($school_name),
        '{{school_address}}'          => safe_htmlspecialchars($school_address),
        '{{school_phone}}'            => safe_htmlspecialchars($school_phone),
        '{{school_email}}'            => safe_htmlspecialchars($school_email),
        '{{exam_name}}'               => strtoupper(safe_htmlspecialchars($result['exam_name'])),
        '{{student_id}}'              => safe_htmlspecialchars($result['student_id']),
        '{{roll_no}}'                 => safe_htmlspecialchars($result['roll_no']),
        '{{student_name}}'            => safe_htmlspecialchars($result['name']),
        '{{father_name}}'             => safe_htmlspecialchars($result['father_name']),
        '{{class_name}}'              => safe_htmlspecialchars($result['class_name']),
        '{{section_name}}'            => safe_htmlspecialchars($result['section_name']),
        '{{exam_date}}'               => safe_htmlspecialchars($result['exam_date']),
        '{{student_photo_base64}}'    => $student_photo_base64,
        '{{subject_rows}}'            => $subject_rows,
        '{{total_marks}}'             => (float) round($result['total_marks'],2),
        '{{obtained_marks}}'          => (float) round($result['obtained_marks'],2),
        '{{percentage}}'              => (float) round($result['percentage'], 2),
        '{{overall_grade}}'           => safe_htmlspecialchars($result['grade']),
        '{{position_in_class}}'       => getOrdinal(getStudentPositionInClass($pdo, $result['exam_id'], $result['class_id'], $result['student_id'], $marksheet_settings['include_minor_subjects_marks'], $section_id)),
        '{{result_status}}'           => getPassFailStatus($result['grade']),
        '{{remarks}}'                 => safe_htmlspecialchars($result['remarks']),
        '{{promotion_status_row}}'    => $promotion_status_row,
        '{{grading_rows}}'            => $grading_rows,
        '{{top_rankers_rows}}'        => $top_rankers_rows,
        '{{qr_code_base64}}'          => $qr_code_base64,
        '{{principle_sign_base64}}'   => $principal_sign_base64
    ];

    foreach ($placeholders as $key => $value) {
        $page_html = str_replace($key, $value, $page_html);
    }

    $all_html_content .= $page_html;
}

// Add footer HTMLs
if ($marksheet_settings['show_text_watermark']) {
    $footer_js_html = str_replace('{{school_name}}', $school_name, $footer_js_html);
} else {
    $footer_js_html = str_replace('{{school_name}}', '', $footer_js_html);
}

if ($marksheet_settings['fast_generation']) {
    $footer_html = str_replace('{{fast_generation}}', '1', $footer_html);
}

// Add closing HTML tags
$all_html_content .= $footer_js_html;
$all_html_content .= $footer_html;

// For debugging: Save the combined HTML to a file
file_put_contents($log_directory . 'single_marksheets_output.html', $all_html_content);

// Export or print the combined HTML content
if ($marksheet_settings['fast_generation']) {
    header("Content-Type: text/html; charset=UTF-8");
    echo $all_html_content; // For testing purposes, output the HTML
} else {
    $output_file_name = "marksheets_" . date('Ymd_His');
    generatePDF($all_html_content, $output_file_name);
}
