<?php
ini_set('memory_limit', '512M'); // or '1G' for very large files
include_once(__DIR__ . "/../../../includes/auth-check.php");

/** @var PDO $pdo 
 * @var string $school_name
*/

$student_ids = $_REQUEST['student_ids'] ?? '';

if (empty($student_ids)) {
    die("Student ID(s) are required");
}

$student_ids = explode(',', $student_ids);

foreach ($student_ids as $student_id) {
    $student_info = getStudentInfo($pdo, $student_id);
    if (!$student_info) {
        continue; // Skip if student info is not found
    }

    // Fetch financial dues for the student
    
}