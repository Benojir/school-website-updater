<?php
ini_set('memory_limit', '512M'); // or '1G' for very large files
include_once(__DIR__ . "/../../../includes/auth-check.php");

/** @var PDO $pdo 
 * @var string $school_name
*/

$class_id = $_REQUEST['class_id'] ?? '';
$exam_id = $_REQUEST['exam_id'] ?? '';
$student_ids = $_REQUEST['student_ids'] ?? '';

if (empty($class_id)) {
    die("Class ID is required");
}

if (empty($exam_id)) {
    die("Exam ID is required");
}

if (empty($student_ids)) {
    die("Student ID(s) are required");
}

$student_ids = explode(',', $student_ids);

// Get class name
$stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = :class_id");
$stmt->execute(['class_id' => $class_id]);
$class_name = $stmt->fetchColumn();

// Fetch exam name
$stmt = $pdo->prepare("SELECT exam_name FROM exams WHERE id = :exam_id");
$stmt->execute(['exam_id' => $exam_id]);
$exam_name = $stmt->fetchColumn();

// Use getStudentInfo($pdo, $student_id) function to fetch student details
$students = [];
foreach ($student_ids as $student_id) {
    $student_info = getStudentInfo($pdo, $student_id);
    if ($student_info) {
        $students[] = [
            'roll_no' => $student_info['roll_no'],
            'name' => $student_info['name'],
            'section' => $student_info['section_name']
        ];
    }
}

// Ftech the subjects for the class
$stmt = $pdo->prepare("SELECT id, subject_name FROM subjects WHERE class_id = :class_id AND exclude_from_marksheet = 0 ORDER BY mark_entry_order_by");
$stmt->execute(['class_id' => $class_id]);
$subjects = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Prepare short (4 character) subject codes for narrow columns
foreach ($subjects as &$subj) {
    $subj['short_name'] = mb_substr($subj['subject_name'], 0, 4, 'UTF-8');
}
unset($subj);
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<title>Oral Marksheet - <?= safe_htmlspecialchars($class_name) ?></title>
<style>
    @page {
        size: A4 landscape;
        margin: 8mm;
    }
    * { box-sizing: border-box; }
    body {
        font-family: "SolaimanLipi", "Kalpurush", "Segoe UI", Arial, sans-serif;
        margin: 0;
        padding: 0;
        color: #1a1a1a;
        background: #fafafa;
    }
    .sheet-wrap {
        max-width: 1250px;
        margin: 0 auto;
        padding: 10px;
    }
    .print-btn {
        text-align: center;
        margin: 10px 0 16px;
    }
    .print-btn button {
        padding: 9px 26px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        background: #2563eb;
        color: #fff;
        border: none;
        border-radius: 6px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.15);
    }
    .print-btn button:hover { background: #1d4ed8; }

    .header-box {
        border: 2px solid #222;
        border-radius: 8px;
        padding: 12px 18px;
        margin-bottom: 10px;
        background: linear-gradient(180deg, #f5f6f8 0%, #eceef2 100%);
        box-shadow: 0 1px 3px rgba(0,0,0,0.12);
    }
    .header-box h1 {
        text-align: center;
        margin: 0 0 4px 0;
        font-size: 25px;
        font-weight: 800;
        letter-spacing: 0.3px;
    }
    .header-box .exam-name {
        text-align: center;
        font-size: 15px;
        font-weight: 600;
        color: #333;
        margin-bottom: 10px;
    }
    .header-meta {
        display: flex;
        justify-content: space-between;
        font-size: 13px;
        font-weight: 600;
        flex-wrap: wrap;
        gap: 8px;
        border-top: 1px solid #c9c9c9;
        padding-top: 8px;
    }
    .header-meta u { text-decoration: none; border-bottom: 1px solid #555; padding-bottom: 1px; }

    table.marksheet {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    table.marksheet th,
    table.marksheet td {
        border: 1px solid #444;
        text-align: center;
        font-size: 11.5px;
        padding: 3px 2px;
        overflow: hidden;
        word-break: break-word;
    }
    table.marksheet thead {
        display: table-header-group; /* repeat header on every printed page */
    }
    table.marksheet tbody tr {
        page-break-inside: avoid;
        break-inside: avoid;
    }
    table.marksheet tbody tr:nth-child(even) {
        background: #f7f8fa;
    }
    table.marksheet th {
        background: #dbe3ef;
        color: #1a1a2e;
        font-weight: 700;
        font-size: 11.5px;
        height: 38px;
    }
    col.col-roll   { width: 32px; }
    col.col-section{ width: 46px; }
    col.col-name   { width: 140px; }
    col.col-subj   { width: 34px; }
    col.col-oral   { width: 28px; }

    td.name-cell { text-align: left; padding-left: 6px; font-weight: 500; }

    tr.data-row td {
        height: 24px;
    }

    @media print {
        body { background: #fff; }
        .sheet-wrap { max-width: 100%; padding: 0; }
        .header-box { box-shadow: none; }
        table.marksheet { box-shadow: none; }
        .no-print { display: none !important; }
    }
</style>
</head>
<body>
<div class="sheet-wrap">

<div class="print-btn no-print">
    <button onclick="window.print()">Print / প্রিন্ট করুন</button>
</div>

<div class="header-box">
    <h1><?= safe_htmlspecialchars($school_name) ?></h1>
    <div class="exam-name"><?= safe_htmlspecialchars($exam_name) ?></div>
    <div class="header-meta">
        <span>CLASS : <u><?= safe_htmlspecialchars($class_name) ?></u></span>
        <span>FULL MARKS : </span>
        <span>TEACHER FULL SIGN : _____________________</span>
    </div>
</div>

<table class="marksheet">
    <colgroup>
        <col class="col-roll">
        <col class="col-section">
        <col class="col-name">
        <?php foreach ($subjects as $s): ?>
            <col class="col-subj">
            <col class="col-oral">
        <?php endforeach; ?>
    </colgroup>
    <thead>
        <tr>
            <th rowspan="2">ROLL</th>
            <th rowspan="2">Section</th>
            <th rowspan="2">NAME</th>
            <?php foreach ($subjects as $s): ?>
                <th colspan="2"><?= safe_htmlspecialchars($s['short_name']) ?></th>
            <?php endforeach; ?>
        </tr>
        <tr>
            <?php foreach ($subjects as $s): ?>
                <th>W</th>
                <th>O</th>
            <?php endforeach; ?>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($students as $st): ?>
            <tr class="data-row">
                <td><?= safe_htmlspecialchars($st['roll_no']) ?></td>
                <td><?= safe_htmlspecialchars($st['section']) ?></td>
                <td class="name-cell"><?= safe_htmlspecialchars($st['name']) ?></td>
                <?php foreach ($subjects as $s): ?>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                <?php endforeach; ?>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

</div>
</body>
</html>