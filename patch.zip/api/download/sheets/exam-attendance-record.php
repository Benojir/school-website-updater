<?php
require_once __DIR__ . '/../../../includes/auth-check.php';
require_once __DIR__ . '/../../../includes/academic/academic-context.php';

// Input validation and read-only sheet data.
function examAttendanceRequest(array $input): array {
    $ids = [];
    foreach (['class_id', 'exam_id'] as $key) {
        $ids[$key] = filter_var($input[$key] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1]]);
        if ($ids[$key] === false) throw new InvalidArgumentException('Please select a valid class and exam.');
    }
    $mode = $input['mode'] ?? 'written';
    if (!in_array($mode, ['written','oral','both'], true)) throw new InvalidArgumentException('Please choose written, oral or both exam papers.');
    $raw = $input['student_ids'] ?? '';
    if (!is_string($raw) || strlen($raw) > 26000) throw new InvalidArgumentException('Please select up to 500 students.');
    $students = array_values(array_unique(array_map('trim', explode(',', $raw))));
    if (count($students) > 500) throw new InvalidArgumentException('Please select up to 500 students.');
    foreach ($students as $id) {
        if ($id === '' || mb_strlen($id) > 50 || preg_match('/[\x00-\x1F\x7F]/', $id)) throw new InvalidArgumentException('Please select valid students.');
    }
    return $ids + ['mode'=>$mode, 'student_ids'=>$students];
}

function examAttendanceColumns(array $subjects, string $mode): array {
    $columns = [];
    foreach ($subjects as $subject) {
        foreach (['written'=>'theory', 'oral'=>'practical'] as $type=>$prefix) {
            if ($mode !== 'both' && $mode !== $type) continue;
            $date = $subject[$prefix . '_exam_date'] ?? '';
            $parsed = is_string($date) ? DateTimeImmutable::createFromFormat('!Y-m-d', $date) : false;
            $date = $parsed && $parsed->format('Y-m-d') === $date ? $date : '';
            // An unscheduled class subject remains available with a blank date.
            if ($subject['routine_id'] !== null && (float)($subject[$prefix . '_marks'] ?? 0) <= 0 && $date === '') continue;
            $columns[] = [
                'name'=>(string)$subject['subject_name'] . ($mode === 'both' ? ($type === 'written' ? "\n(Written)" : "\n(Oral)") : ''),
                'date'=>$date, 'time'=>(string)($subject[$prefix . '_start_time'] ?? ''),
                'order'=>(int)($subject['mark_entry_order_by'] ?? 9999), 'type'=>$type,
            ];
        }
    }
    usort($columns, static fn($a,$b) => [($a['date'] ?: '9999-12-31'), $a['time'], $a['order'], $a['name']] <=> [($b['date'] ?: '9999-12-31'), $b['time'], $b['order'], $b['name']]);
    if (!$columns) throw new InvalidArgumentException('No subjects are available for these exam papers. Please check the class subjects and exam routine.');
    return $columns;
}

function loadExamAttendanceSheet(PDO $pdo, array $request): array {
    $query = static function (string $sql, array $params) use ($pdo): PDOStatement {
        $stmt=$pdo->prepare($sql); $stmt->execute($params); return $stmt;
    };
    $className=$query('SELECT class_name FROM classes WHERE id=?',[$request['class_id']])->fetchColumn();
    $examName=$query('SELECT exam_name FROM exams WHERE id=?',[$request['exam_id']])->fetchColumn();
    if ($className === false || $examName === false) throw new InvalidArgumentException('The selected class or exam no longer exists.');
    $academicYear = academicRequireExamYear($pdo, $request['exam_id']);
    $placeholders=implode(',',array_fill(0,count($request['student_ids']),'?'));
    $students=$query("SELECT s.student_id, s.name, ar.roll_no, ar.class_id, ar.section_id, sec.section_name
        FROM students s JOIN student_academic_records ar ON ar.student_row_id=s.id AND ar.academic_year=?
        LEFT JOIN sections sec ON sec.id=ar.section_id
        WHERE s.student_id IN ($placeholders)", array_merge([$academicYear], $request['student_ids']))->fetchAll(PDO::FETCH_ASSOC);
    if (count($students) !== count($request['student_ids'])) throw new InvalidArgumentException('Some selected students no longer exist. Refresh the list and select them again.');
    foreach ($students as $student) {
        if ((int)$student['class_id'] !== $request['class_id']) throw new InvalidArgumentException('Please select students from the same class.');
    }
    usort($students, static function ($a,$b) {
        return strnatcasecmp((string)$a['section_name'], (string)$b['section_name'])
            ?: ((int)$a['section_id'] <=> (int)$b['section_id'])
            ?: (($a['roll_no'] === null ? PHP_INT_MAX : (int)$a['roll_no']) <=> ($b['roll_no'] === null ? PHP_INT_MAX : (int)$b['roll_no']))
            ?: strnatcasecmp($a['name'] ?? '', $b['name'] ?? '')
            ?: strcmp($a['student_id'], $b['student_id']);
    });
    $sections=[];
    foreach ($students as $student) {
        $key=(string)($student['section_id'] ?? 'none');
        if (!isset($sections[$key])) $sections[$key]=['name'=>(string)($student['section_name'] ?? ''), 'students'=>[]];
        $sections[$key]['students'][]=$student;
    }
    $subjects=$query("SELECT s.subject_name, s.mark_entry_order_by, r.id AS routine_id,
        r.theory_marks, r.practical_marks, r.theory_exam_date, r.practical_exam_date,
        r.theory_start_time, r.practical_start_time
        FROM subjects s LEFT JOIN exam_routines r ON r.subject_id=s.id AND r.class_id=s.class_id AND r.exam_id=?
        WHERE s.class_id=? AND (s.exclude_from_marksheet=0 OR r.id IS NOT NULL) ORDER BY s.mark_entry_order_by, s.id",
        [$request['exam_id'], $request['class_id']])->fetchAll(PDO::FETCH_ASSOC);
    return ['class_name'=>(string)$className, 'exam_name'=>(string)$examName, 'mode'=>$request['mode'],
        'sections'=>array_values($sections), 'columns'=>examAttendanceColumns($subjects, $request['mode'])];
}

header('Cache-Control: no-store');

// Authorize before reading any student records, including direct download requests.
if (!isAnyAdminLoggedIn()) {
    http_response_code(401); header('Content-Type: text/plain; charset=utf-8');
    exit('Please sign in as an admin to download this sheet.');
}
if (!hasPermission(PERM_MANAGE_STUDENTS) && !hasPermission(PERM_MANAGE_EXAMS) && !hasPermission(PERM_MANAGE_RESULTS)) {
    http_response_code(403); header('Content-Type: text/plain; charset=utf-8');
    exit('You do not have permission to download exam attendance records.');
}
if (!in_array($_SERVER['REQUEST_METHOD'],['POST','GET'],true)) {
    http_response_code(405); header('Allow: GET, POST'); exit;
}
try {
    $request=examAttendanceRequest($_SERVER['REQUEST_METHOD']==='POST' ? $_POST : $_GET);
    $sheet=loadExamAttendanceSheet($pdo,$request);
    header('Content-Type: text/html; charset=utf-8');

} catch (InvalidArgumentException $e) {
    http_response_code(422); header('Content-Type: text/plain; charset=utf-8'); echo $e->getMessage(); exit;
} catch (Throwable $e) {
    error_log('Exam attendance sheet: ' . $e->getMessage());
    http_response_code(500); header('Content-Type: text/plain; charset=utf-8');
    echo 'Unable to generate the attendance record. Please try again or contact the school administrator.';
    exit;
}

$h = static fn($value) => htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
$subjectGroups = array_chunk($sheet['columns'], 10);
$paperLabel = ['written'=>'Written papers', 'oral'=>'Oral / practical papers', 'both'=>'Written and oral / practical papers'][$sheet['mode']];
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Exam Attendance Record - <?= $h($sheet['class_name']) ?> - <?= $h($sheet['exam_name']) ?></title>
    <style>
        @page { size: A4 landscape; margin: 8mm; }
        * { box-sizing: border-box; }
        body { margin: 0; color: #111; background: #e9ecef; font-family: Arial, "Nirmala UI", sans-serif; }
        .print-toolbar { padding: 16px; text-align: center; }
        .print-toolbar button { padding: 10px 24px; border: 0; border-radius: 5px; background: #176b52; color: white; font: inherit; cursor: pointer; }
        .print-toolbar p { margin: 8px 0; font-size: 14px; }
        .sheet { width: 297mm; margin: 0 auto 20px; padding: 8mm; background: white; }
        /* Independent cell borders survive browser print page breaks. */
        table { width: 100%; table-layout: fixed; border-collapse: separate; border-spacing: 0; }
        col.roll { width: 12mm; } col.name { width: 50mm; }
        th, td { border: 0.5px solid #333; padding: 1mm; text-align: center; overflow-wrap: anywhere; }
        thead { display: table-header-group; }
        tfoot { display: table-footer-group; }
        tr { break-inside: avoid; page-break-inside: avoid; }
        .heading { border: 0; padding: 0 0 3mm; font-weight: normal; }
        h1 { margin: 0 0 2mm; font-family: Georgia, "Nirmala UI", serif; font-size: 20pt; line-height: 1.1; }
        .exam-title { width: 58%; margin: 0 auto 1mm; border: 1.5px solid #222; padding: 1mm; font-size: 13pt; font-weight: bold; }
        .subtitle { margin: 0 0 2mm; font-size: 12pt; }
        .meta { display: flex; align-items: center; justify-content: space-between; gap: 5mm; font-size: 11pt; text-align: left; }
        .in-charge { display: flex; align-items: center; gap: 2mm; white-space: nowrap; }
        .signature-box { display: inline-block; width: 40mm; height: 8mm; border: 1.5px solid #222; }
        .dates th { height: 7mm; font-size: 10pt; }
        .subjects th { height: 12mm; white-space: pre-line; font-size: 10pt; font-weight: normal; }
        .student-row td { height: 6mm; font-size: 10pt; line-height: 1.15; padding: 0.7mm 1mm; }
        .student-name { text-align: left; font-weight: 600; }
        .examiner th, .examiner td { height: 15mm; }
        .examiner th { font: italic bold 12pt Georgia, serif; }
        .sheet-note { border: 0; padding: 2mm 0 0; text-align: left; font-size: 8pt; }
        @media screen and (max-width: 1122px) { .sheets { overflow-x: auto; } .sheet { margin-left: 0; } }
        @media print {
            body { background: white; }
            .print-toolbar { display: none !important; }
            .sheets { overflow: visible; }
            .sheet { width: 100%; margin: 0; padding: 0; break-after: page; page-break-after: always; }
            .sheet:last-child { break-after: auto; page-break-after: auto; }
            thead, tfoot { break-inside: avoid; }
        }
    </style>
</head>
<body>
<div class="print-toolbar">
    <button type="button" onclick="window.print()">Print / Save as PDF</button>
    <p>Press Ctrl+P to print. Paper: A4 &middot; Landscape &middot; Scale: 100%. Turn off browser headers and footers.</p>
</div>
<main class="sheets">
<?php foreach ($sheet['sections'] as $section): ?>
    <?php foreach ($subjectGroups as $groupIndex => $columns): ?>
        <section class="sheet" aria-label="<?= $h($sheet['class_name'] . ' ' . $section['name']) ?> attendance record">
            <table>
                <colgroup><col class="roll"><col class="name"><?php foreach ($columns as $column): ?><col><?php endforeach; ?></colgroup>
                <thead>
                    <tr><th colspan="<?= count($columns) + 2 ?>" class="heading">
                        <h1><?= $h($school_name) ?></h1>
                        <div class="exam-title"><?= $h($sheet['exam_name']) ?></div>
                        <p class="subtitle">Attendance Record of Students</p>
                        <div class="meta">
                            <div><strong>Class:</strong> <?= $h($sheet['class_name']) ?><?php if ($section['name'] !== ''): ?> &nbsp; <strong>Section:</strong> <?= $h($section['name']) ?><?php endif; ?></div>
                            <div class="in-charge"><strong>Signature of Exam-In-Charge:</strong><span class="signature-box"></span></div>
                        </div>
                    </th></tr>
                    <tr class="dates">
                        <th rowspan="2">Roll<br>No.</th><th rowspan="2">Student's name</th>
                        <?php for ($index = 0; $index < count($columns);):
                            $end = $index + 1;
                            while ($columns[$index]['date'] !== '' && $end < count($columns) && $columns[$end]['date'] === $columns[$index]['date']) $end++;
                            $date = $columns[$index]['date'] !== '' ? (new DateTimeImmutable($columns[$index]['date']))->format('d/m/Y') : '';
                        ?>
                            <th colspan="<?= $end - $index ?>"><?= $h($date) ?></th>
                        <?php $index = $end; endfor; ?>
                    </tr>
                    <tr class="subjects"><?php foreach ($columns as $column): ?><th><?= $h($column['name']) ?></th><?php endforeach; ?></tr>
                </thead>
                <tbody>
                    <?php foreach ($section['students'] as $student): ?>
                        <tr class="student-row"><td><?= $h($student['roll_no']) ?></td><td class="student-name"><?= $h($student['name']) ?></td><?php foreach ($columns as $column): ?><td></td><?php endforeach; ?></tr>
                    <?php endforeach; ?>
                    <?php for ($row = count($section['students']); $row < 18; $row++): ?>
                        <tr class="student-row"><td></td><td></td><?php foreach ($columns as $column): ?><td></td><?php endforeach; ?></tr>
                    <?php endfor; ?>
                </tbody>
                <tfoot>
                    <tr class="examiner"><th colspan="2">Examiner's<br>Signature</th><?php foreach ($columns as $column): ?><td></td><?php endforeach; ?></tr>
                    <tr><td colspan="<?= count($columns) + 2 ?>" class="sheet-note"><?= $h($paperLabel) ?><?php if (count($subjectGroups) > 1): ?> &middot; Subject group <?= $groupIndex + 1 ?> of <?= count($subjectGroups) ?><?php endif; ?></td></tr>
                </tfoot>
            </table>
        </section>
    <?php endforeach; ?>
<?php endforeach; ?>
</main>
</body>
</html>
