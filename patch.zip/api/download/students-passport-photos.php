<?php
ob_start();
/** 
 * @var PDO $pdo 
 * @var array $schoolInfo
 * @var array $websiteConfig
 */
ini_set('memory_limit', '512M');
include_once(__DIR__ . "/../../includes/auth-check.php");

$student_ids_raw = $_REQUEST['student_ids'] ?? '';

if (empty($student_ids_raw)) {
    die("Student ID(s) are required.");
}

if (is_array($student_ids_raw)) {
    $student_ids = $student_ids_raw;
} else {
    $student_ids = explode(',', (string)$student_ids_raw);
}
$student_ids = array_unique(array_filter(array_map('trim', $student_ids)));

if (empty($student_ids)) {
    die("No valid student(s) found.");
}

$students = [];
$default_avatar = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%239ca3af'%3E%3Cpath d='M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z'/%3E%3C/svg%3E";

foreach ($student_ids as $student_id) {
    $st = getStudentInfo($pdo, (string)$student_id);
    if (!$st) {
        continue;
    }

    $photo_url = '';
    if (!empty($st['student_image'])) {
        $photo_url = BASE_URL . '/uploads/students/' . $st['student_image'];
    }

    $students[] = [
        'student_id' => $st['student_id'],
        'name' => $st['name'],
        'roll_no' => $st['roll_no'] ?? '',
        'class_name' => $st['class_name'] ?? '',
        'section_name' => $st['section_name'] ?? '',
        'photo_url' => $photo_url
    ];
}

$school_name = $schoolInfo['name'] ?? 'School';
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Passport Photos - <?= safe_htmlspecialchars($school_name) ?></title>
    <style>
        @page {
            size: A4 portrait;
            margin: 7mm 6mm;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: "Segoe UI", Arial, sans-serif;
            background-color: #f1f5f9;
            color: #0f172a;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        /* Top Bar (Hidden on Print) */
        .action-bar {
            position: sticky;
            top: 0;
            z-index: 1000;
            background: #1e293b;
            color: #ffffff;
            padding: 10px 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.18);
        }

        .action-bar-left {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
            font-size: 13px;
        }

        .badge-count {
            background: #2563eb;
            color: #ffffff;
            padding: 3px 10px;
            border-radius: 4px;
            font-weight: 600;
            font-size: 12px;
        }

        .action-bar-controls {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 12px;
        }

        .action-bar-controls label {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            cursor: pointer;
            user-select: none;
        }

        .action-bar-controls select {
            background: #334155;
            color: #ffffff;
            border: 1px solid #475569;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            cursor: pointer;
        }

        .btn-print {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #10b981;
            color: #ffffff;
            border: none;
            padding: 7px 18px;
            border-radius: 5px;
            font-weight: 600;
            font-size: 13px;
            cursor: pointer;
            transition: background 0.15s;
        }

        .btn-print:hover {
            background: #059669;
        }

        /* Printable Sheet Container */
        .sheet-container {
            width: 198mm;
            margin: 15px auto;
            background: #ffffff;
            padding: 4mm 2mm;
            border-radius: 4px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        }

        /* Photos Grid Layout */
        .photos-grid {
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-start;
            align-content: flex-start;
            column-gap: 3.5mm;
            row-gap: 3mm;
            width: 100%;
        }

        /* Standard Passport Size (35mm x 45mm photo + caption) */
        .photo-card {
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            width: 35mm;
            break-inside: avoid;
            page-break-inside: avoid;
            background: #ffffff;
        }

        .photo-box {
            width: 35mm;
            height: 45mm;
            border: 1px dashed #94a3b8;
            border-radius: 2px;
            overflow: hidden;
            background: #f8fafc;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .photo-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .photo-name-bar {
            width: 35mm;
            text-align: center;
            margin-top: 1.5mm;
            line-height: 1.15;
            overflow: hidden;
        }

        .st-name {
            font-size: 8.5px;
            font-weight: 700;
            color: #0f172a;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 100%;
        }

        .st-meta {
            font-size: 7.5px;
            color: #475569;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 100%;
        }

        /* Compact Size Mode (30mm x 38mm - fits 36 photos per A4) */
        .sheet-container.mode-compact .photo-card {
            width: 30mm;
        }

        .sheet-container.mode-compact .photo-box {
            width: 30mm;
            height: 38mm;
        }

        .sheet-container.mode-compact .photo-name-bar {
            width: 30mm;
        }

        .sheet-container.mode-compact .st-name {
            font-size: 8px;
        }

        .sheet-container.mode-compact .st-meta {
            font-size: 7px;
        }

        /* Border Style Variants */
        .sheet-container.border-solid .photo-box {
            border-style: solid;
            border-color: #0f172a;
        }

        .sheet-container.border-light .photo-box {
            border-style: dashed;
            border-color: #cbd5e1;
        }

        .sheet-container.border-none .photo-box {
            border: none;
        }

        /* Hide meta when unchecked */
        .sheet-container.hide-meta .st-meta {
            display: none;
        }

        /* Print Media Styles */
        @media print {
            body {
                background: #ffffff !important;
                margin: 0 !important;
                padding: 0 !important;
            }

            .action-bar {
                display: none !important;
            }

            .sheet-container {
                width: 100% !important;
                margin: 0 !important;
                padding: 0 !important;
                box-shadow: none !important;
                border-radius: 0 !important;
            }

            .photo-card {
                break-inside: avoid !important;
                page-break-inside: avoid !important;
            }
        }
    </style>
</head>
<body>

    <!-- Action Toolbar (Hidden during Print) -->
    <div class="action-bar no-print">
        <div class="action-bar-left">
            <span>Passport Photos</span>
            <span class="badge-count">Total: <?= count($students) ?></span>
        </div>

        <div class="action-bar-controls">
            <label>
                Size:
                <select id="sizeSelect" onchange="updateSize(this.value)">
                    <option value="standard">Standard 35×45mm (~25/page)</option>
                    <option value="compact">Compact 30×38mm (~36/page)</option>
                </select>
            </label>

            <label>
                Border:
                <select id="borderSelect" onchange="updateBorder(this.value)">
                    <option value="border-light">Light Dashed</option>
                    <option value="border-solid">Solid Black</option>
                    <option value="border-none">No Border</option>
                </select>
            </label>

            <label>
                <input type="checkbox" id="showRollCheck" checked onchange="toggleRoll(this.checked)">
                <span>Show Roll/Class</span>
            </label>

            <button type="button" class="btn-print" onclick="window.print()">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z"/></svg>
                Print / Save PDF
            </button>
        </div>
    </div>

    <!-- Printable Sheet Container -->
    <div class="sheet-container border-light" id="sheetContainer">
        <div class="photos-grid">
            <?php foreach ($students as $st): ?>
                <div class="photo-card">
                    <div class="photo-box">
                        <img src="<?= !empty($st['photo_url']) ? safe_htmlspecialchars($st['photo_url']) : $default_avatar ?>" 
                             alt="<?= safe_htmlspecialchars($st['name']) ?>"
                             onerror="this.onerror=null;this.src='<?= $default_avatar ?>'">
                    </div>
                    <div class="photo-name-bar">
                        <div class="st-name" title="<?= safe_htmlspecialchars($st['name']) ?>">
                            <?= safe_htmlspecialchars($st['name']) ?>
                        </div>
                        <div class="st-meta">
                            Roll: <?= safe_htmlspecialchars($st['roll_no'] ?: '-') ?><?php if (!empty($st['class_name'])): ?> &bull; <?= safe_htmlspecialchars($st['class_name']) ?><?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script>
        function updateSize(size) {
            const container = document.getElementById('sheetContainer');
            if (size === 'compact') {
                container.classList.add('mode-compact');
            } else {
                container.classList.remove('mode-compact');
            }
        }

        function updateBorder(borderClass) {
            const container = document.getElementById('sheetContainer');
            container.classList.remove('border-light', 'border-solid', 'border-none');
            container.classList.add(borderClass);
        }

        function toggleRoll(show) {
            const container = document.getElementById('sheetContainer');
            if (show) {
                container.classList.remove('hide-meta');
            } else {
                container.classList.add('hide-meta');
            }
        }
    </script>

</body>
</html>
<?php
ob_end_flush();
