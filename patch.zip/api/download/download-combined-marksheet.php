<?php
ini_set('memory_limit', '512M'); // or '1G' for very large files
include_once(__DIR__ . "/../../includes/auth-check.php");
include_once(__DIR__ . "/../../includes/permission-check.php");
include_once(__DIR__ . "/../../includes/browsershot.php");

$log_directory = __DIR__ . '/../../assets/logs/';
if (!is_dir($log_directory)) {
    mkdir($log_directory, 0755, true);
}

if (!hasPermission(PERM_MANAGE_RESULTS)) {
    die("You do not have permission to perform this action.");
}

if (!isset($_GET['exam_ids']) || !isset($_GET['student_ids'])) {
    die("Required fields are missing.");
}

$exam_ids = explode(',', $_GET['exam_ids']);
$student_ids = explode(',', $_GET['student_ids']);

if (count($exam_ids) < 1 || count($student_ids) < 1) {
    die("Please select at least one exam and one student.");
}

// Convert to integers (optional but recommended)
$exam_ids = array_map('intval', $exam_ids);
// Sort ascending (low to high)
sort($exam_ids);

// Fetch marksheet settings
$stmt = $pdo->prepare("SELECT * FROM settings_marksheet LIMIT 1");
$stmt->execute();
$marksheet_settings = $stmt->fetch(PDO::FETCH_ASSOC);

// School information
$school_name = $schoolInfo['name'];
$school_address = $schoolInfo['address'];
$school_contacts = 'Phone: ' . $schoolInfo['phone'] . ' | Email: ' . $schoolInfo['email'];

// School logo and principal sign
$school_logo_path = '../../uploads/school/logo-square.png';
$principal_sign_path = '../../uploads/school/principle_sign.png';
// Convert images to base64
$school_logo_base64 = imageToBase64($school_logo_path);
$principal_signature_base64 = imageToBase64($principal_sign_path);

// Load HTML template and CSS
$css_style = file_get_contents('../../assets/templates/marksheet-templates/combined-marksheets/design1/style.css');
$css_style = str_replace(
    [
        '{{theme_primary}}',
        '{{theme_dark}}',
        '{{theme_light}}',
        '{{page_background_color}}',
        '{{school_name_text_color}}',
        '{{school_address_text_color}}'
    ],
    [
        $marksheet_settings['primary_theme_color'],
        $marksheet_settings['dark_theme_color'],
        $marksheet_settings['light_theme_color'],
        $marksheet_settings['background_color'],
        $marksheet_settings['school_name_text_color'],
        $marksheet_settings['school_address_text_color']
    ],
    $css_style
);
$css = "<style>" . $css_style . "</style>";

$header_html = file_get_contents('../../assets/templates/marksheet-templates/header.html');
$header_html = str_replace('<link rel="stylesheet" href="style.css">', $css, $header_html);
$footer_html = file_get_contents('../../assets/templates/marksheet-templates/footer.html');

$content_html = file_get_contents('../../assets/templates/marksheet-templates/combined-marksheets/design1/content.html');


$all_html_content = $header_html;

foreach ($student_ids as $student_id) {

    // Fetch student info for placeholders
    $stmt = $pdo->prepare("
        SELECT 
            s.*,
            sec.section_name,
            c.class_name
        FROM students s
        LEFT JOIN sections sec ON s.section_id = sec.id
        LEFT JOIN classes c ON s.class_id = c.id
        WHERE s.student_id = ? AND (s.status = 'Active' OR s.status = 'Alumni')
    ");
    $stmt->execute([$student_id]);
    $student_info = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$student_info) {
        continue; // Skip if student not found or inactive
    }

    // Student photo
    $student_photo_base64 = '';
    if ($student_info['student_image'] && file_exists("../../uploads/students/" . $student_info['student_image'])) {
        $student_photo_path = "../../uploads/students/" . $student_info['student_image'];
        $student_photo_base64 = imageToBase64($student_photo_path);
    } else {
        $student_photo_path = "../../uploads/students/default_student_dp.jpg";
        $student_photo_base64 = imageToBase64($student_photo_path);
    }

    $exam_tables = '';
    $overall_data = [];
    $first_exam_excluded_subjects = [];
    $exam_count = 1;

    foreach ($exam_ids as $exam_id) {
        // Fetch result details
        $stmt = $pdo->prepare("
            SELECT 
                r.id AS result_id,
                r.student_id,
                r.exam_id AS result_exam_id,
                r.class_id AS result_class_id,
                r.total_marks,
                r.obtained_marks,
                r.percentage,
                r.grade,
                r.remarks,
                r.is_promoted,
                r.created_at,
                r.updated_at,

                e.id AS exam_id,
                e.exam_name,
                e.exam_date

            FROM results r
            JOIN exams e ON r.exam_id = e.id
            WHERE r.student_id = ? 
            AND r.exam_id = ?
        ");


        $stmt->execute([$student_id, $exam_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$result) continue;

        // Fetch exam routine
        $routineStmtQuery = "SELECT * FROM exam_routines WHERE exam_id = ? AND class_id = ?";
        $routineStmt = $pdo->prepare($routineStmtQuery);
        $routineStmt->execute([$result['exam_id'], $student_info['class_id']]);
        $exam_routine = $routineStmt->fetchAll(PDO::FETCH_ASSOC);

        // Fetch subject marks
        $stmt = $pdo->prepare("
            SELECT sm.*, sub.subject_name, sub.subject_type 
            FROM subject_marks sm
            JOIN subjects sub ON sm.subject_id = sub.id
            WHERE sm.result_id = ? ORDER BY sub.subject_type
        ");
        $stmt->execute([$result['result_id']]);
        $subject_marks = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Store the subject rows
        $subject_rows = "";

        // Build subject rows HTML
        foreach ($subject_marks as $subject) {

            // If this is the first exam, record excluded subjects
            if ($exam_count === 1 && $subject['is_excluded']) {
                $first_exam_excluded_subjects[] = $subject['subject_id'];
            }

            // Check if the subject has written and/or oral exams
            $hasWrittenExam = true;
            $hasOralExam = true;

            foreach ($exam_routine as $routine) {
                if ($routine['subject_id'] == $subject['subject_id']) {
                    if ($routine['theory_marks'] == 0) {
                        $hasWrittenExam = false;
                    }
                    if ($routine['practical_marks'] == 0) {
                        $hasOralExam = false;
                    }
                }
            }

            // Skip excluded subjects in subsequent exams
            if (in_array($subject['subject_id'], $first_exam_excluded_subjects)) {
                continue;
            }

            // Build subject row for the exam table
            $tr = "<tr>";
            if (!$marksheet_settings['include_minor_subjects_marks']) {
                if (strtolower($subject['subject_type']) == "minor") {
                    $tr = "<tr style='color:#ff8800;font-weight:bold;'>";
                }
            }
            $subject_rows .= "{$tr}
                <td>" . safe_htmlspecialchars($subject['subject_name']) . "</td>
                <td>" . ($hasWrittenExam ? ($subject['is_absent'] == 1 ? '<span style="color:red;">AB</span>' : round($subject['theory_marks'])) : '-') . "</td>
                <td>" . ($hasOralExam ? ($subject['is_absent'] == 1 ? '<span style="color:red;">AB</span>' : round($subject['practical_marks'])) : '-') . "</td>
                <td>" . round($subject['total_marks']) . "</td>
                <td>" . round($subject['obtained_marks']) . "</td>
                <td>" . ($subject['grade'] == 'D' ? "<b style='color:red;'>D</b>" : "<strong>" . safe_htmlspecialchars($subject['grade']) . "</strong>") . "</td>
            </tr>";

            // Accumulate overall data
            if (!isset($overall_data[$subject['subject_name']])) {
                $overall_data[$subject['subject_name']] = [
                    'theory' => 0,
                    'practical' => 0,
                    'total' => 0,
                    'obtained' => 0,
                    'count' => 0
                ];
            }
            $overall_data[$subject['subject_name']]['subject_type'] = $subject['subject_type'];
            $overall_data[$subject['subject_name']]['theory'] += $subject['theory_marks'];
            $overall_data[$subject['subject_name']]['practical'] += $subject['practical_marks'];
            $overall_data[$subject['subject_name']]['total'] += $subject['total_marks'];
            $overall_data[$subject['subject_name']]['obtained'] += $subject['obtained_marks'];
            $overall_data[$subject['subject_name']]['count']++;
        }

        // Add exam table
        $exam_tables .= '<div class="marks-table">
            <div class="marks-table-exam-name">' . safe_htmlspecialchars($result['exam_name']) . '</div>
            <table>
                <thead>
                    <tr>
                        <th>Subject</th>
                        <th>Written</th>
                        <th>Oral</th>
                        <th>Total</th>
                        <th>Obtained</th>
                        <th>Grade</th>
                    </tr>
                </thead>
                <tbody>' . $subject_rows . '</tbody>
            </table>
        </div>';

        // Increment exam count variable
        $exam_count++;
    }

    // Build overall table (Dividing the overall data by count for averages)
    $overall_marks_total = 0;
    $overall_marks_obtained = 0;

    $overall_rows = "";
    foreach ($overall_data as $subject => $data) {

        // 1. Determine the divisor ('count') in one step
        // If 'make_overall_average' is true, use the subject's count (at least 1).
        // Otherwise, just use 1 (so we're summing, not averaging).
        $count = $marksheet_settings['make_overall_average']
            ? max(1, (int)$data['count'])
            : 1;

        // 2. Cache repeated checks and values
        $is_minor = (strtolower($data['subject_type']) == "minor");
        $exclude_minor_marks = !$marksheet_settings['include_minor_subjects_marks'];

        // 3. Determine row style
        // Use a ternary operator for a cleaner assignment.
        $tr = ($exclude_minor_marks && $is_minor)
            ? "<tr style='color:#ff8800;font-weight:bold;'>"
            : "<tr>";

        // 4. Calculate grade with a check for division by zero
        // Avoids potential errors if a subject's total marks are 0.
        $percentage = ($data['total'] > 0)
            ? ($data['obtained'] / $data['total'] * 100)
            : 0;
        $grade = calculateGrade($percentage);

        // 5. Calculate averaged values
        // Do the division once and store in variables for clarity.
        $theory_marks = round($data['theory'] / $count);
        $practical_marks = round($data['practical'] / $count);
        $total_marks = round($data['total'] / $count);
        $obtained_marks = round($data['obtained'] / $count);

        // 6. Build the row string
        // Using sprintf or interpolation is often cleaner than repeated concatenation.
        $overall_rows .= "{$tr}
            <td>" . safe_htmlspecialchars($subject) . "</td>
            <td>{$theory_marks}</td>
            <td>{$practical_marks}</td>
            <td>{$total_marks}</td>
            <td>{$obtained_marks}</td>
            <td>{$grade}</td>
        </tr>";

        // 7. Conditionally add to totals
        // If we're excluding minor subject marks and this is a minor subject, skip.
        if ($exclude_minor_marks && $is_minor) {
            continue;
        }

        // Add the (potentially averaged) marks to the grand total.
        $overall_marks_total += $total_marks;
        $overall_marks_obtained += $obtained_marks;
    }


    // Calculate overall percentage and grade
    $percentage = $overall_marks_total > 0 ? ($overall_marks_obtained / $overall_marks_total) * 100 : 0;
    $overall_grade = calculateGrade($percentage);
    $pass_fail_status = getPassFailStatus($overall_grade);
    $result_remarks = getRemarksByGrade($overall_grade);
    $position_in_class = "--"; // Placeholder, implement logic as needed


    // Build grading system table
    $grading_rows = "";
    $stmt = $pdo->prepare("SELECT * FROM grading_system ORDER BY min_percentage DESC");
    $stmt->execute();
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $grade) {
        $grading_rows .= "<tr>
            <td>" . floor($grade['min_percentage']) . "% - " . floor($grade['max_percentage']) . "%</td>
            <td><strong>" . safe_htmlspecialchars($grade['grade']) . "</strong></td>
            <td>" . safe_htmlspecialchars($grade['remarks']) . "</td>
        </tr>";
    }

    // Replace placeholders
    $page_html = str_replace(
        [
            '{{school_logo}}',
            '{{school_name}}',
            '{{school_address}}',
            '{{school_contacts}}',
            '{{student_id}}',
            '{{roll_no}}',
            '{{student_name}}',
            '{{father_name}}',
            '{{class_name}}',
            '{{section_name}}',
            '{{student_photo}}',
            '{{exam_tables}}',
            '{{overall_rows}}',
            '{{grading_rows}}',
            '{{total_marks}}',
            '{{obtained_marks}}',
            '{{percentage}}',
            '{{overall_grade}}',
            '{{position_in_class}}',
            '{{result_status}}',
            '{{result_remarks}}',
            '{{principal_signature_image}}'
        ],
        [
            $school_logo_base64,
            $school_name,
            $school_address,
            $school_contacts,
            $student_id,
            $student_info['roll_no'],
            $student_info['name'],
            $student_info['father_name'],
            $student_info['class_name'],
            $student_info['section_name'],
            $student_photo_base64,
            $exam_tables,
            $overall_rows,
            $grading_rows,
            round($overall_marks_total),
            round($overall_marks_obtained),
            round($percentage, 1) . '%',
            $overall_grade,
            $position_in_class,
            $pass_fail_status,
            $result_remarks,
            $principal_signature_base64
        ],
        $content_html
    );

    $all_html_content .= $page_html;
}

// Add closing HTML tags
$all_html_content .= $footer_html;

// For debugging: Save the combined HTML to a file
file_put_contents($log_directory . 'combined_marksheets_output.html', $all_html_content);

// Export or print the combined HTML content
if ($marksheet_settings['fast_generation']) {
    header("Content-Type: text/html; charset=UTF-8");
    echo $all_html_content; // Output the HTML
} else {
    $output_file_name = "marksheets_" . date('Ymd_His');
    generatePDF($all_html_content, $output_file_name);
}
