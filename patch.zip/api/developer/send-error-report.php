<?php
include_once("../../includes/config.php");
include_once("../../includes/phpmailer.php");

$subject = "Error Report";
$message = $_POST['message'] ?? '';
$to = "mr.nuralam.com@gmail.com";

if (function_exists('fastcgi_finish_request')) {
    fastcgi_finish_request();
}

sendMail($school_name, $to, 'Nur Alam', $subject, $message, $message);
