<?php
include_once __DIR__ . '/../../../includes/driver/auth/driver-auth-check.php';
header('Content-Type: application/json');
$authData = authenticateApiRequest($pdo);
try {
    $upload = $_FILES['image_file'] ?? [];
    if (($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file($upload['tmp_name'])) throw new RuntimeException('Choose a valid photo.');
    $imageFile = $upload['tmp_name'];
    $info = @getimagesize($imageFile);
    if (!$info || !isValidImageFile($imageFile) || filesize($imageFile) > 5 * 1024 * 1024) throw new RuntimeException('Upload a valid JPG or PNG photo of at most 5 MB.');
    $photo = 'drv_' . bin2hex(random_bytes(16)) . ($info['mime'] === 'image/jpeg' ? '.jpg' : '.png');
    $current = $pdo->prepare('SELECT driver_image FROM drivers WHERE id = ?');
    $current->execute([$authData['driver_id']]);
    $oldPhoto = $current->fetchColumn();
    schoolPhotoStoreFile($imageFile, __DIR__ . '/../../../uploads/drivers/' . $photo);
    $stmt = $pdo->prepare('UPDATE drivers SET driver_image = ? WHERE id = ?');
    if (!$stmt->execute([$photo, $authData['driver_id']])) throw new RuntimeException('Failed to update profile picture.');
    if ($oldPhoto) schoolPhotoScheduleDelete(__DIR__ . '/../../../uploads/drivers/' . $oldPhoto);
    echo json_encode(['success' => true, 'message' => 'Profile picture updated successfully.']);
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
