<?php
include_once(__DIR__ . "/../../../includes/driver/auth/driver-auth-check.php");

header('Content-Type: application/json');

$authData = authenticateApiRequest($pdo);

$imageFile = $_FILES['image_file']['tmp_name'];

$imageInfo = @getimagesize($imageFile);
if ($imageInfo === false) {
    echo json_encode(['success' => false, 'message' => 'You are trying to upload an invalid or corrupted image.']);
    exit();
}

if (!isValidImageFile($imageFile)) {
    echo json_encode(['success' => false, 'message' => 'You are trying to upload an invalid or corrupted image.']);
    exit();
}

$ext = pathinfo($_FILES['image_file']['name'], PATHINFO_EXTENSION) ?: 'jpg';
$photo = uniqid('drv_') . '.' . $ext;

$uploadDir = __DIR__ . '/../../../uploads/drivers/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

$destination = $uploadDir . $photo;

if (!move_uploaded_file($imageFile, $destination)) {
    echo json_encode(['success' => false, 'message' => 'Failed to upload image.']);
    exit();
}

// Now update the drive image name in db
try {
    $stmt = $pdo->prepare("UPDATE drivers SET driver_image = ? WHERE id = ?");
    $success = $stmt->execute([$photo, $authData['driver_id']]);
    if ($success) {
        echo json_encode(['success' => true, 'message' => 'Profile picture updated successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update profile picture.']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}