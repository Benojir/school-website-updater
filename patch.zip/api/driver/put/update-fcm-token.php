<?php
include_once(__DIR__ . "/../../../includes/config.php");

header('Content-Type: application/json');

$fcmToken = $_REQUEST['fcm_token'] ?? "";
$deviceId = $_REQUEST['device_id'] ?? "";

if (empty($fcmToken) || empty($deviceId)) {
    echo json_encode(['success' => false, 'message' => 'FCM token and device ID cannot be empty']);
    exit;
}

try {
    // Save the FCM token and device ID to the database
    $stmt = $pdo->prepare("UPDATE driver_auth_sessions SET fcm_token = ? WHERE device_id = ?");
    $stmt->execute([$fcmToken, $deviceId]);

    echo json_encode(['success' => true, 'message' => 'FCM token updated successfully']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Internal server error: ' . $e->getMessage()]);
}