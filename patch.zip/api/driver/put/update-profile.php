<?php
include_once(__DIR__ . "/../../../includes/driver/auth/driver-auth-check.php");

header('Content-Type: application/json');

$authData = authenticateApiRequest($pdo);

$jsonInput = file_get_contents('php://input');
$data = json_decode($jsonInput, true);

// ডেটা ঠিকমতো JSON ফরম্যাটে এসেছে কিনা চেক করা
if (json_last_error() !== JSON_ERROR_NONE || empty($data)) {
    http_response_code(400); // Bad Request
    echo json_encode([
        "success" => false, 
        "message" => "Invalid or empty JSON payload."
    ]);
    exit;
}

$driver_id = $authData['driver_id'];

$name = isset($data['name']) ? trim($data['name']) : null;
$vehicle_number = isset($data['vehicle_number']) ? trim($data['vehicle_number']) : null;

// Check if vehicle number already exist for another driver
if (!empty($vehicle_number)) {
    $sql = "SELECT id FROM drivers WHERE vehicle_number = ? AND id != ?";
    $checkDuplicate = $pdo->prepare($sql);
    $checkDuplicate->execute([$vehicle_number, $driver_id]);
    $existingDriver = $checkDuplicate->fetch(PDO::FETCH_ASSOC);

    if ($existingDriver) {
        echo json_encode([
            "success" => false, 
            "message" => "Vehicle number already exists for another driver."
        ]);
        exit;
    }
}

$sql = "UPDATE drivers SET name = ?, vehicle_number = ? WHERE id = ?";
$stmt = $pdo->prepare($sql);
if ($stmt->execute([$name, $vehicle_number, $driver_id])) {
    echo json_encode([
        "success" => true, 
        "message" => "Profile updated successfully."
    ]);
} else {
    echo json_encode([
        "success" => false, 
        "message" => "Profile update failed."
    ]);
}