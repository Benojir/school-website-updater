<?php
include_once(__DIR__ . "/../../../includes/config.php");
include_once(__DIR__ . "/../../../includes/functions.php");

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(['success' => false, 'message' => 'Invalid request method']));
}

$phone = sanitize_input($_POST['phone'] ?? '');
$otp = sanitize_input($_POST['otp'] ?? '');
$purpose = sanitize_input($_POST['purpose'] ?? '');
$data = $_POST['data'] ?? '';

// Validate inputs
if (empty($phone) || empty($otp) || empty($purpose)) {
    die(json_encode(['success' => false, 'message' => 'Phone number, OTP, and purpose are required']));
}

// Verify OTP
$stmt = $pdo->prepare("SELECT id FROM otp_verification WHERE phone_number = ? AND otp = ? AND purpose = ? AND expiry > NOW() AND verified = 0");
$stmt->execute([$phone, $otp, $purpose]);
$otpRecord = $stmt->fetch();

if (!$otpRecord) {
    die(json_encode(['success' => false, 'message' => 'Invalid or expired OTP']));
}

// Mark OTP as verified
$stmt = $pdo->prepare("UPDATE otp_verification SET verified = 1 WHERE id = ?");
$stmt->execute([$otpRecord['id']]);

if ($purpose === 'login') {
    $parsedData = json_decode($data, true);

    // Validate JSON payload
    if (!$parsedData || empty($parsedData['device_id']) || empty($parsedData['device_name'])) {
        die(json_encode(['success' => false, 'message' => 'Invalid or missing device data']));
    }

    $device_id = $parsedData['device_id'];
    $fcm_token = $parsedData['fcm_token'] ?? ''; // FCM token might be optional
    $device_name = $parsedData['device_name'];
    $session_source = 'mobile';
    $ip_address = getUserPublicIP();
    $token = generateToken();
    $tokenHash = hash('sha256', $token);

    // Fetch the driver id associated with this phone number
    $stmt = $pdo->prepare("SELECT id FROM drivers WHERE phone = ? LIMIT 1");
    $stmt->execute([$phone]);
    $driver_id = $stmt->fetchColumn();

    // Check if driver exists
    if (!$driver_id) {
        die(json_encode(['success' => false, 'message' => 'Driver not found with this phone number']));
    }

    try {
        // Begin Transaction
        $pdo->beginTransaction();

        // Insert the session
        $stmt = $pdo->prepare("INSERT INTO driver_auth_sessions (driver_id, phone, token_hash, device_id, device_name, fcm_token, session_source, ip_address, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$driver_id, $phone, $tokenHash, $device_id, $device_name, $fcm_token, $session_source, $ip_address]);
        $new_session_id = $pdo->lastInsertId();

        // Delete old sessions of this driver (Enforce single device login)
        $stmt = $pdo->prepare("DELETE FROM driver_auth_sessions WHERE driver_id = ? AND id != ?");
        $stmt->execute([$driver_id, $new_session_id]);

        // Commit Transaction
        $pdo->commit();

        echo json_encode([
            'success' => true,
            'message' => 'OTP verified successfully!',
            'token' => $token,
            'driver_id' => $driver_id,
            'phone' => $phone,
            'school_id' => FULL_SCHOOL_ID // Assuming this is defined globally
        ]);

    } catch (Exception $e) {
        // Rollback Transaction on error
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'Failed to initiate session. Please try again.']);
    }

} else {
    // For password reset
    echo json_encode(['success' => true, 'message' => 'OTP verified successfully!']);
}