<?php
require_once __DIR__ . '/../../../includes/driver/auth/driver-auth-check.php';
require_once __DIR__ . '/../../../includes/driver/driver-payroll-service.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
try {
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') { http_response_code(405); header('Allow: GET'); exit(json_encode(['success' => false, 'message' => 'Use GET.'])); }
    $auth = authenticateApiRequest($pdo);
    $service = new DriverPayrollService($pdo);
    // Never trust a phone, driver_id or account ID supplied by the mobile client.
    $id = $service->id($auth['driver_id']);
    $account = $pdo->prepare('SELECT status FROM drivers WHERE id = ?'); $account->execute([$id]);
    if ($account->fetchColumn() !== 'active') throw new DriverPayrollDenied('This driver account is inactive or unavailable.');
    $action = $_GET['action'] ?? 'ledger';
    if ($action === 'ledger') $data = $service->ledger($id, driverPayrollMonth($_GET['month'] ?? date('Y-m')), false);
    elseif ($action === 'report') $data = $service->report($_GET['from'] ?? date('Y-m-01'), $_GET['to'] ?? date('Y-m-d'), $id, empty($_GET['salary_month']) ? null : driverPayrollMonth($_GET['salary_month']), (int)($_GET['page'] ?? 1), false);
    else throw new InvalidArgumentException('Unknown salary view.');
    echo json_encode(['success' => true, 'data' => $data, 'currency' => $currency_symbol, 'today' => date('Y-m-d')], JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
} catch (DriverPayrollDenied $e) { http_response_code(403); echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} catch (InvalidArgumentException $e) { http_response_code(422); echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} catch (Throwable $e) { error_log('Driver salary read: ' . $e->getMessage()); http_response_code(503); echo json_encode(['success' => false, 'message' => 'Salary records are temporarily unavailable. Please contact the school or try again.']); }
