<?php
include_once(__DIR__ . "/../../../../includes/driver/auth/driver-auth-check.php");

header('Content-Type: application/json');

try {
    $authData = authenticateApiRequest($pdo);
    // $authData['driver_id'] = 2; // Testing

    // Get all students associated with this driver
    $stmt = $pdo->prepare('
        SELECT 
            s.*,
            c.class_name,
            sec.section_name,
            droute.route_name,
            CONCAT("/uploads/students/", s.student_image) as image_url
        FROM students s
        LEFT JOIN classes c ON s.class_id = c.id
        LEFT JOIN sections sec ON s.section_id = sec.id 
        LEFT JOIN driving_routes droute ON s.driving_route_id = droute.id
        WHERE s.driver_id = ? AND s.status = "Active"
        ORDER BY c.id, sec.id, s.roll_no
    ');
    $stmt->execute([$authData['driver_id']]);
    // PDO::FETCH_ASSOC ব্যবহার করা হয়েছে যাতে শুধু অ্যাসোসিয়েটিভ অ্যারে আসে
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC); 

    // Fetch the driver details
    $driver_stmt = $pdo->prepare('SELECT * FROM drivers WHERE id = ?');
    $driver_stmt->execute([$authData['driver_id']]);
    $driver = $driver_stmt->fetch(PDO::FETCH_ASSOC);

    $driving_routes = [];

    // চেক করা হচ্ছে ড্রাইভার ডেটা আছে কিনা এবং route_ids খালি কিনা
    if ($driver && !empty($driver['route_ids'])) {
        $assigned_routes = json_decode($driver['route_ids'], true);
        
        // অ্যারে ঠিকমতো জেনারেট হয়েছে কিনা এবং তার ভেতরে ডেটা আছে কিনা তা চেক করা হচ্ছে
        if (is_array($assigned_routes) && count($assigned_routes) > 0) {
            
            // SQL ইনজেকশন রোধ করতে Placeholders (?, ?, ?) তৈরি করা হচ্ছে
            $placeholders = str_repeat('?,', count($assigned_routes) - 1) . '?';
            
            $driving_routes_stmt = $pdo->prepare("SELECT * FROM driving_routes WHERE id IN ($placeholders)");
            // অ্যারের ভ্যালুগুলো execute এর মাধ্যমে পাস করা হচ্ছে
            $driving_routes_stmt->execute($assigned_routes);
            $driving_routes = $driving_routes_stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    // Return the data
    echo json_encode([
        'success' => true,
        'message' => 'Students fetched successfully',
        'data' => [
            'students' => $students,
            'driver' => $driver,
            'driving_routes' => $driving_routes
        ]
    ]);

} catch (Exception $e) {
    // কোনো ডাটাবেস এরর হলে 500 স্ট্যাটাস কোড এবং JSON রেসপন্স রিটার্ন করবে
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred: ' . $e->getMessage()
    ]);
}
?>
