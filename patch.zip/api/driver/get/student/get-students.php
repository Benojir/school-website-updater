<?php
include_once(__DIR__ . "/../../../../includes/driver/auth/driver-auth-check.php");

header('Content-Type: application/json');

try {
    $authData = authenticateApiRequest($pdo);
    // $authData['driver_id'] = 2; // Testing

    // Get all students associated with this driver
    $stmt = $pdo->prepare('
        SELECT 
            s.*,
            c.class_name,
            sec.section_name,
            droute.route_name,
            CONCAT("/uploads/students/", s.student_image) as image_url
        FROM students s
        LEFT JOIN classes c ON s.class_id = c.id
        LEFT JOIN sections sec ON s.section_id = sec.id 
        LEFT JOIN driving_routes droute ON s.driving_route_id = droute.id
        WHERE s.driver_id = ? AND s.status = "Active"
        ORDER BY c.id, sec.id, s.roll_no
    ');
    $stmt->execute([$authData['driver_id']]);
    // PDO::FETCH_ASSOC ব্যবহার করা হয়েছে যাতে শুধু অ্যাসোসিয়েটিভ অ্যারে আসে
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC); 

    // Fetch the driver details
    $driver_stmt = $pdo->prepare('SELECT * FROM drivers WHERE id = ?');
    $driver_stmt->execute([$authData['driver_id']]);
    $driver = $driver_stmt->fetch(PDO::FETCH_ASSOC);

    // Drivers without the financial-report permission get the same payload shape, with the
    // money-related student fields blanked out rather than removed, so existing clients
    // don't break. The column is NOT NULL DEFAULT 0, so a missing value reads as denied.
    $canViewStudentFinancialReport = !empty($driver['can_view_student_financial_report']);

    // -------------------------------------------------------------
    // Pending fees calculation (matching students-with-dues.php)
    // -------------------------------------------------------------
    $student_unpaid_monthly_totals = [];
    $student_unpaid_months = [];
    $student_unpaid_admission_totals = [];
    $student_admission_years = [];
    $student_unpaid_additional_totals = [];
    $student_additional_names = [];

    if ($canViewStudentFinancialReport && !empty($students)) {
        $student_ids = array_column($students, 'student_id');
        $student_ids = array_values(array_filter($student_ids));

        if (!empty($student_ids)) {
            $in_query = implode(',', array_fill(0, count($student_ids), '?'));

            // 1. Unpaid admission fees
            $admission_stmt = $pdo->prepare("
                SELECT student_id, unpaid_amount, academic_year
                FROM admission_unpaid_fees
                WHERE student_id IN ($in_query)
            ");
            $admission_stmt->execute($student_ids);
            while ($row = $admission_stmt->fetch(PDO::FETCH_ASSOC)) {
                $sid = $row['student_id'];
                $student_unpaid_admission_totals[$sid] = ($student_unpaid_admission_totals[$sid] ?? 0) + (float)$row['unpaid_amount'];
                if (!empty($row['academic_year'])) {
                    $student_admission_years[$sid][] = $row['academic_year'];
                }
            }

            // 2. Unpaid monthly fees (ordered by month)
            $unpaid_stmt = $pdo->prepare("
                SELECT student_id, month_year, unpaid_amount
                FROM student_unpaid_fees
                WHERE student_id IN ($in_query)
                ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC
            ");
            $unpaid_stmt->execute($student_ids);
            while ($row = $unpaid_stmt->fetch(PDO::FETCH_ASSOC)) {
                $sid = $row['student_id'];
                $student_unpaid_monthly_totals[$sid] = ($student_unpaid_monthly_totals[$sid] ?? 0) + (float)$row['unpaid_amount'];
                if (!empty($row['month_year'])) {
                    $student_unpaid_months[$sid][] = $row['month_year'];
                }
            }

            // 3. Unpaid additional fees
            $additional_stmt = $pdo->prepare("
                SELECT afd.student_id, cwaf.fee_type, cwaf.amount
                FROM additional_fees_data afd
                JOIN class_wise_additional_fees cwaf ON cwaf.id = afd.additional_fee_setup_id
                WHERE afd.student_id IN ($in_query) AND afd.additional_fee_status = 'unpaid'
            ");
            $additional_stmt->execute($student_ids);
            while ($row = $additional_stmt->fetch(PDO::FETCH_ASSOC)) {
                $sid = $row['student_id'];
                $student_unpaid_additional_totals[$sid] = ($student_unpaid_additional_totals[$sid] ?? 0) + (float)$row['amount'];
                if (!empty($row['fee_type'])) {
                    $student_additional_names[$sid][] = $row['fee_type'];
                }
            }
        }
    }

    $financial_fields = [
        'car_fee', 'hostel_fee', 'coaching_fee', 'tiffin_fee', 'custom_class_fee',
        'father_annual_income', 'mother_annual_income',
        'bank_name', 'bank_branch_name', 'bank_account_no', 'ifsc_code',
    ];

    foreach ($students as &$student) {
        if (!$canViewStudentFinancialReport) {
            foreach ($financial_fields as $financial_field) {
                if (array_key_exists($financial_field, $student)) {
                    $student[$financial_field] = null;
                }
            }
            $student['admission_due'] = null;
            $student['admission_year'] = null;
            $student['monthly_due'] = null;
            $student['monthly_months'] = null;
            $student['additional_due'] = null;
            $student['additional_detail'] = null;
            $student['total_due'] = null;
            $student['total_monthly_pending_fees'] = null;
            $student['total_admission_pending_fees'] = null;
            $student['total_additional_pending_fees'] = null;
            $student['total_pending_fees'] = null;
            $student['due_months'] = null;
            continue;
        }

        $sid = $student['student_id'];

        $adm_due = (float)($student_unpaid_admission_totals[$sid] ?? 0);
        $adm_years = array_unique($student_admission_years[$sid] ?? []);
        if (count($adm_years) > 0) {
            usort($adm_years, function ($a, $b) {
                return $a <=> $b;
            });
            $adm_year_text = implode(', ', $adm_years);
        } else {
            $adm_year_text = '';
        }

        $m_due = (float)($student_unpaid_monthly_totals[$sid] ?? 0);
        $m_years = $student_unpaid_months[$sid] ?? [];
        $m_detail_text = '';
        if (count($m_years) > 0) {
            if (count($m_years) <= 2) {
                $m_detail_text = implode(', ', $m_years);
            } else {
                $m_detail_text = $m_years[0] . ' to ' . end($m_years) . ' (' . count($m_years) . ' mos)';
            }
        }

        $add_due = (float)($student_unpaid_additional_totals[$sid] ?? 0);
        $add_detail_text = implode(', ', array_unique($student_additional_names[$sid] ?? []));

        $tot_due = $adm_due + $m_due + $add_due;

        $student['admission_due'] = $adm_due;
        $student['admission_year'] = $adm_year_text;
        $student['monthly_due'] = $m_due;
        $student['monthly_months'] = $m_detail_text;
        $student['additional_due'] = $add_due;
        $student['additional_detail'] = $add_detail_text;
        $student['total_due'] = $tot_due;

        // Aliases matching teacher get-students.php
        $student['total_admission_pending_fees'] = $adm_due;
        $student['total_monthly_pending_fees'] = $m_due;
        $student['total_additional_pending_fees'] = $add_due;
        $student['total_pending_fees'] = $tot_due;
        $student['due_months'] = $m_detail_text;
    }
    unset($student);

    $driving_routes = [];

    // চেক করা হচ্ছে ড্রাইভার ডেটা আছে কিনা এবং route_ids খালি কিনা
    if ($driver && !empty($driver['route_ids'])) {
        $assigned_routes = json_decode($driver['route_ids'], true);
        
        // অ্যারে ঠিকমতো জেনারেট হয়েছে কিনা এবং তার ভেতরে ডেটা আছে কিনা তা চেক করা হচ্ছে
        if (is_array($assigned_routes) && count($assigned_routes) > 0) {
            
            // SQL ইনজেকশন রোধ করতে Placeholders (?, ?, ?) তৈরি করা হচ্ছে
            $placeholders = str_repeat('?,', count($assigned_routes) - 1) . '?';
            
            $driving_routes_stmt = $pdo->prepare("SELECT * FROM driving_routes WHERE id IN ($placeholders)");
            // অ্যারের ভ্যালুগুলো execute এর মাধ্যমে পাস করা হচ্ছে
            $driving_routes_stmt->execute($assigned_routes);
            $driving_routes = $driving_routes_stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    // Return the data
    echo json_encode([
        'success' => true,
        'message' => 'Students fetched successfully',
        'can_view_student_financial_report' => (int) $canViewStudentFinancialReport,
        'data' => [
            'students' => $students,
            'driver' => $driver,
            'driving_routes' => $driving_routes
        ]
    ]);

} catch (Exception $e) {
    // কোনো ডাটাবেস এরর হলে 500 স্ট্যাটাস কোড এবং JSON রেসপন্স রিটার্ন করবে
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred: ' . $e->getMessage()
    ]);
}
?>
