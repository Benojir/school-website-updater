<?php
include_once(__DIR__ . "/../../../../includes/driver/auth/driver-auth-check.php");

header('Content-Type: application/json');

$authData = authenticateApiRequest($pdo);

// Get all students associated with this parent
$stmt = $pdo->prepare('
    SELECT DISTINCT 
        s.*,
        c.class_name,
        sec.section_name,
        CONCAT("/uploads/students/", s.student_image) as image_url
    FROM students s
    LEFT JOIN classes c ON s.class_id = c.id
    LEFT JOIN sections sec ON s.section_id = sec.id
    WHERE s.driver_id = ? 
    ORDER BY c.id, sec.id, s.roll_no
');
$stmt->execute([$authData['driver_id']]);
$students = $stmt->fetchAll();

// Fetch the driver details
$driver_stmt = $pdo->prepare('SELECT * FROM drivers WHERE id = ?');
$driver_stmt->execute([$authData['driver_id']]);
$driver = $driver_stmt->fetch();

// Format data for mobile response
// $formattedStudents = [];

// foreach ($students as $student) {

//     // ----------------Fetch personal data---------------------
//     $formattedStudents[] = [
//         'personal_data' => $student
//     ];

//     // ----------------Fetch financial data---------------------
//     $financial_data = [];

//     $student_grand_total_unpaid = 0;
//     $student_id = $student['student_id'];

//     // 1. Get Wallet Balance (from get-student-wallet-data.php logic)
//     $wallet_stmt = $pdo->prepare("SELECT * FROM student_wallet WHERE student_id = :student_id");
//     $wallet_stmt->execute([':student_id' => $student_id]);
//     $wallet = $wallet_stmt->fetch(PDO::FETCH_ASSOC);

//     $wallet_balanace = $wallet ? $wallet['balance'] : "0.00";
//     $financial_data['wallet_balance'] = $wallet_balanace;

//     // 2. Get Monthly Fees Unpaid Total (from get-fees-x-payments-data.php logic)
//     $mf_stmt = $pdo->prepare("SELECT SUM(unpaid_amount) AS total FROM student_unpaid_fees WHERE student_id = ?");
//     $mf_stmt->execute([$student_id]);
//     $monthly_total_unpaid = (float)$mf_stmt->fetchColumn();
//     $student_grand_total_unpaid += $monthly_total_unpaid;
//     $financial_data['monthly_fees_unpaid_total'] = number_format($monthly_total_unpaid, 2);

//     // 3. Get Admission Fees Unpaid Total (from get-fees-x-payments-data.php logic)
//     $af_stmt = $pdo->prepare("SELECT SUM(unpaid_amount) AS total FROM admission_unpaid_fees WHERE student_id = ?");
//     $af_stmt->execute([$student_id]);
//     $admission_total_unpaid = (float)$af_stmt->fetchColumn();
//     $student_grand_total_unpaid += $admission_total_unpaid;
//     $financial_data['admission_fees_unpaid_total'] = number_format($admission_total_unpaid, 2);

//     // 4. Get Additional Fees Unpaid Total (from get-fees-x-payments-data.php logic)
//     // Note: Assuming 'unpaid' is the correct status string.
//     $adf_stmt = $pdo->prepare("
//             SELECT SUM(cwaf.amount) 
//             FROM additional_fees_data AS afd
//             JOIN class_wise_additional_fees AS cwaf ON cwaf.id = afd.additional_fee_setup_id
//             WHERE afd.student_id = ? AND afd.additional_fee_status = 'unpaid'
//         ");
//     $adf_stmt->execute([$student_id]);
//     $additional_total_unpaid = (float)$adf_stmt->fetchColumn();
//     $student_grand_total_unpaid += $additional_total_unpaid;
//     $financial_data['additional_fees_unpaid_total'] = number_format($additional_total_unpaid, 2);

//     // 5. Set Grand Total for this child
//     $financial_data['total_unpaid_amount'] = number_format($student_grand_total_unpaid, 2);

//     // Merge financial data into student data
//     $formattedStudents[count($formattedStudents) - 1]['financial_data'] = $financial_data;
// }

// Return the data
echo json_encode([
    'success' => true,
    'message' => 'Students fetched successfully',
    'data' => [
        'students' => $students,
        'driver' => $driver
    ]
]);
