<?php
// Preserves existing website and Android /uploads/... photo URLs after migration.
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/photo-storage.php';
$websiteConfig = $pdo->query('SELECT * FROM website_config LIMIT 1')->fetch(PDO::FETCH_ASSOC) ?: [];
$category = (string)($_GET['category'] ?? '');
$filename = (string)($_GET['filename'] ?? '');
if (!schoolPhotoValidName($category, $filename)) { http_response_code(404); exit; }
try {
    $bytes = schoolPhotoRead($category, $filename);
    $info = getimagesizefromstring($bytes);
    if (!$info) throw new RuntimeException('Invalid photo.');
    $etag = '"' . hash('sha256', $bytes) . '"';
    header('Content-Type: ' . $info['mime']);
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: public, max-age=300');
    header('ETag: ' . $etag);
    if (($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $etag) { http_response_code(304); exit; }
    header('Content-Length: ' . strlen($bytes));
    if ($_SERVER['REQUEST_METHOD'] !== 'HEAD') echo $bytes;
} catch (Throwable $e) {
    // A storage outage is retryable, rather than a cached missing photo.
    http_response_code(503);
    header('Cache-Control: no-store');
}
