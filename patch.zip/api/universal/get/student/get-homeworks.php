<?php
include_once __DIR__ . "/../../../../includes/config.php";

header('Content-Type: application/json');

$section_id = $_REQUEST['section_id'] ?? null;
$page = isset($_REQUEST['page']) ? (int)$_REQUEST['page'] : 1;
$limit = isset($_REQUEST['limit']) ? (int)$_REQUEST['limit'] : 15;

if (!$section_id) {
    echo json_encode(['success' => false, 'message' => 'section_id is required']);
    exit;
}

$offset = ($page - 1) * $limit;

try {
    // JOIN করে ইউনিক পোস্টগুলো বের করা
    $groupQuery = "
        SELECT COALESCE(sh.media_group_id, sh.id) AS post_key, MAX(sh.created_at) as post_date
        FROM student_homeworks sh
        JOIN homework_section_map hsm ON sh.id = hsm.homework_id
        WHERE hsm.section_id = :section_id 
          AND sh.status = 'active' 
          AND sh.created_at >= DATE_SUB(NOW(), INTERVAL 1 YEAR)
        GROUP BY post_key
        ORDER BY post_date DESC
        LIMIT :limit OFFSET :offset
    ";
    
    $groupStmt = $pdo->prepare($groupQuery);
    $groupStmt->bindValue(':section_id', $section_id, PDO::PARAM_INT);
    $groupStmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $groupStmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $groupStmt->execute();
    
    $groupResults = $groupStmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($groupResults)) {
        echo json_encode(['success' => true, 'page' => $page, 'has_more' => false, 'data' => []]);
        exit;
    }

    $postKeys = array_column($groupResults, 'post_key');
    $inQuery = implode(',', array_fill(0, count($postKeys), '?'));
    
    // JOIN করে মূল ডেটা ফেচ করা
    $dataQuery = "
        SELECT sh.* FROM student_homeworks sh
        JOIN homework_section_map hsm ON sh.id = hsm.homework_id
        WHERE hsm.section_id = ? 
          AND sh.status = 'active' 
          AND COALESCE(sh.media_group_id, sh.id) IN ($inQuery)
        ORDER BY sh.created_at DESC, sh.id ASC
    ";
    
    $dataStmt = $pdo->prepare($dataQuery);
    $params = array_merge([$section_id], $postKeys);
    $dataStmt->execute($params);
    $rows = $dataStmt->fetchAll(PDO::FETCH_ASSOC);

    $posts = [];
    
    foreach ($rows as $row) {
        $key = $row['media_group_id'] ?: $row['id'];
        $isAlbum = !empty($row['media_group_id']);
        
        if (!isset($posts[$key])) {
            $posts[$key] = [
                'post_id' => $key,
                'type' => $isAlbum ? 'album' : 'single',
                'text' => $row['message_text'],
                'date' => date("j F Y, h:i:s A", strtotime($row['created_at'])),
                'media' => []
            ];
        }
        
        if (empty($posts[$key]['text']) && !empty($row['message_text'])) {
            $posts[$key]['text'] = $row['message_text'];
        }
        
        if (!empty($row['file_id'])) {
            $posts[$key]['media'][] = [
                'file_type' => $row['file_type'],
                'file_id' => $row['file_id'],
                'file_name' => $row['file_name'] ?? '', 
                'file_size' => $row['file_size'] ?? 0,
                'file_width' => $row['file_width'] ?? null,
                'file_height' => $row['file_height'] ?? null,
                'thumb_id' => $row['thumb_id'] ?? null,
                'thumb_width' => $row['thumb_width'] ?? null,
                'thumb_height' => $row['thumb_height'] ?? null
            ];
        }

        if (empty($posts[$key]['text']) && empty($posts[$key]['media'])) {
            unset($posts[$key]);
        }
    }
    
    $final_data = array_values($posts);
    
    echo json_encode([
        'success' => true,
        'page' => $page,
        'has_more' => count($groupResults) === $limit,
        'data' => $final_data
    ]);

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>