<?php
include_once __DIR__ . "/../../../../includes/config.php";

header('Content-Type: application/json');

// Get parameters
$student_id = $_REQUEST['student_id'] ?? '';
$month_param = $_REQUEST['month'] ?? ''; // Example: "March 2026"

// Check if required parameters are missing
if (empty($student_id) || empty($month_param)) {
    echo json_encode([
        "success" => false,
        "message" => "Missing required parameter: student_id or month."
    ]);
    exit;
}

// Convert "March 2026" to "Y-m" format (e.g., "2026-03")
$target_month = date('Y-m', strtotime($month_param));

// Validate date conversion
if (!$target_month || $target_month == '1970-01') {
    echo json_encode([
        "success" => false,
        "message" => "Invalid month format. Please use format like 'March 2026'."
    ]);
    exit;
}

// Fetch student's attendance data for the specific month
// We use LIKE ? to filter the specific 'YYYY-MM' directly in the SQL query for better performance
$stmt = $pdo->prepare("
    SELECT sa.*, c.class_name, sec.section_name, t.name as submitted_by_teacher
    FROM student_attendance sa 
    JOIN classes c ON sa.class_id = c.id
    LEFT JOIN sections sec ON sa.section_id = sec.id
    LEFT JOIN teachers t ON sa.processed_by_teacher = t.id
    WHERE sa.student_id = ? AND sa.date LIKE ?
    ORDER BY sa.date DESC, sa.time DESC
");

// The placeholder value will be "2026-03-%" to match any date in that month
$stmt->execute([$student_id, $target_month . '-%']);
$studentAttendance = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Return JSON response
echo json_encode([
    "success" => true,
    "attendance" => $studentAttendance
]);