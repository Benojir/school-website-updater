<?php
include_once __DIR__ . "/../../../../includes/config.php";

header('Content-Type: application/json');

$student_id = $_REQUEST['student_id'] ?? '';

if (empty($student_id)) {
    echo json_encode([
        "success" => false,
        "message" => "Missing required parameter: student_id."
    ]);
    exit;
}

// Student profile fetch
$stmt = $pdo->prepare("
    SELECT s.*, c.class_name, sec.section_name 
    FROM students s
    JOIN classes c ON s.class_id = c.id
    LEFT JOIN sections sec ON s.section_id = sec.id
    WHERE s.student_id = ?
");
$stmt->execute([$student_id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    echo json_encode([
        "success" => false,
        "message" => "Student not found."
    ]);
    exit;
}

// Fetch student's attendance data (Ordered by date DESC)
$stmt = $pdo->prepare("
    SELECT sa.*, c.class_name, sec.section_name, t.name as submitted_by_teacher
    FROM student_attendance sa 
    JOIN classes c ON sa.class_id = c.id
    LEFT JOIN sections sec ON sa.section_id = sec.id
    LEFT JOIN teachers t ON sa.processed_by_teacher = t.id
    WHERE sa.student_id = ?
    ORDER BY sa.date DESC, sa.time DESC
");
$stmt->execute([$student_id]);
$studentAttendance = $stmt->fetchAll(PDO::FETCH_ASSOC);

$currentYearMonth = date('Y-m');
$previousYearMonth = date('Y-m', strtotime('-1 month'));

// Use array_values() to guarantee clean JSON array structure []
$thisMonthAttendance = array_values(array_filter($studentAttendance, function ($attendance) use ($currentYearMonth) {
    return date('Y-m', strtotime($attendance['date'])) === $currentYearMonth;
}));

$previousMonthAttendance = array_values(array_filter($studentAttendance, function ($attendance) use ($previousYearMonth) {
    return date('Y-m', strtotime($attendance['date'])) === $previousYearMonth;
}));

echo json_encode([
    "success" => true,
    "student" => $student,
    'attendance' => [
        'thisMonth' => $thisMonthAttendance,
        'previousMonth' => $previousMonthAttendance,
    ]
]);