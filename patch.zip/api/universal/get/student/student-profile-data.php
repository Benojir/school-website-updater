<?php
include_once __DIR__ . "/../../../../includes/config.php";

header('Content-Type: application/json');

$student_id = $_REQUEST['student_id'] ?? '';

if (empty($student_id)) {
    echo json_encode([
        "success" => false,
        "message" => "Missing required parameter: student_id."
    ]);
    exit;
}

// An omitted year preserves the current-profile response used by existing apps.
// An explicit year must match a saved enrollment; never fall back to another year.
try {
    if (!is_string($student_id)) throw new InvalidArgumentException('Invalid student_id.');
    $student = academicGetStudent($pdo, $student_id, academicRequestedYear($_REQUEST));
} catch (InvalidArgumentException $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    exit;
}

if (!$student) {
    echo json_encode([
        "success" => false,
        "message" => "Student not found."
    ]);
    exit;
}

$academicHistory = academicGetHistory($pdo, (int)$student['id']);

// Fetch student's attendance data (Ordered by date DESC)
$stmt = $pdo->prepare("
    SELECT sa.*, c.class_name, sec.section_name, t.name as submitted_by_teacher
    FROM student_attendance sa 
    JOIN classes c ON sa.class_id = c.id
    LEFT JOIN sections sec ON sa.section_id = sec.id
    LEFT JOIN teachers t ON sa.processed_by_teacher = t.id
    WHERE sa.student_id = ?
    ORDER BY sa.date DESC, sa.time DESC
");
$stmt->execute([$student_id]);
$studentAttendance = $stmt->fetchAll(PDO::FETCH_ASSOC);

$currentYearMonth = date('Y-m');
$previousYearMonth = date('Y-m', strtotime('-1 month'));

// Use array_values() to guarantee clean JSON array structure []
$thisMonthAttendance = array_values(array_filter($studentAttendance, function ($attendance) use ($currentYearMonth) {
    return date('Y-m', strtotime($attendance['date'])) === $currentYearMonth;
}));

$previousMonthAttendance = array_values(array_filter($studentAttendance, function ($attendance) use ($previousYearMonth) {
    return date('Y-m', strtotime($attendance['date'])) === $previousYearMonth;
}));

echo json_encode([
    "success" => true,
    "student" => $student,
    'academic_history' => $academicHistory,
    'attendance' => [
        'thisMonth' => $thisMonthAttendance,
        'previousMonth' => $previousMonthAttendance,
    ]
]);
