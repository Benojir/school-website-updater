<?php
include_once __DIR__ . "/../../../../includes/config.php";
header('Content-Type: application/json');

$post_id = $_REQUEST['post_id'] ?? null;

if (!$post_id) {
    echo json_encode(['success' => false, 'message' => 'post_id is required']);
    exit;
}

try {
    // সিঙ্গেল মেসেজ বা অ্যালবামের সব ফাইলের স্ট্যাটাস 'deleted' করে দেওয়া হচ্ছে
    $query = "UPDATE student_homeworks SET status = 'deleted' 
              WHERE id = :id OR media_group_id = :group_id";
              
    $stmt = $pdo->prepare($query);
    
    // একই $post_id ভ্যালু দুটি আলাদা প্যারামিটারে বাইন্ড করা হলো
    $stmt->bindValue(':id', $post_id, PDO::PARAM_STR);
    $stmt->bindValue(':group_id', $post_id, PDO::PARAM_STR);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Homework deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Homework not found or already deleted']);
    }

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>