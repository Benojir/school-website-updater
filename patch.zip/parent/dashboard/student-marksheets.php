<?php
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Marksheets - " . $school_name . "</title>";
include_once("../../includes/header-close.php"); 

// Check if student ID is provided
if (!isset($_GET['student_id'])) {
    die("Student ID not provided.");
}

$student_id = $_GET['student_id'];

// chech admin permission + student permission
if (isLoggedIn()) { // check any admin logged in
    include_once("../../includes/dashboard-navbar.php");
    if (!hasPermission(PERM_MANAGE_EXAMS)) {
        include_once("../../includes/permission-denied.php");
    }
} else {
    if (isParentAuthenticated()) {
        include_once("../../includes/parent-dashboard-navbar.php");
        if (!hasParentAccessPermission($student_id)) {
            include_once("../../includes/permission-denied.php");
        }
    } else {
        echo '<script>location.replace("/");</script>';
        exit;
    }
}

// Fetch student details
$student_query = "SELECT s.*, c.class_name, sec.section_name 
                 FROM students s 
                 JOIN classes c ON s.class_id = c.id 
                 JOIN sections sec ON s.section_id = sec.id 
                 WHERE s.student_id = ?";
$stmt = $pdo->prepare($student_query);
$stmt->execute([$student_id]);
$student = $stmt->fetch();

if (!$student) {
    echo '<div class="container mt-5">
            <div class="alert alert-warning" role="alert">
                No results found for this student.<br>
                Maybe no marksheet is released yet.
            </div>
        </div>';
    die();
}

// Get all classes the student has results for (for filter dropdown)
$classes_query = "SELECT DISTINCT c.id, c.class_name 
                 FROM results r 
                 JOIN classes c ON r.class_id = c.id 
                 WHERE r.student_id = ? 
                 ORDER BY c.class_name";
$stmt = $pdo->prepare($classes_query);
$stmt->execute([$student_id]);
$available_classes = $stmt->fetchAll();

// Process filter parameters
$class_filter = $_GET['class_filter'] ?? '';
$sort_by = $_GET['sort_by'] ?? 'date_desc';

// Build base query
$results_query = "
    SELECT r.*, e.exam_name, e.exam_date, c.class_name
    FROM results r
    JOIN exams e ON r.exam_id = e.id
    JOIN classes c ON r.class_id = c.id
    INNER JOIN exam_marksheet_releases emr 
        ON emr.exam_id = r.exam_id AND emr.class_id = r.class_id
    WHERE r.student_id = ?
";

// Add class filter if selected
$params = [$student_id];
if (!empty($class_filter)) {
    $results_query .= " AND r.class_id = ?";
    $params[] = $class_filter;
}

// Add sorting
switch ($sort_by) {
    case 'date_asc':
        $results_query .= " ORDER BY e.exam_date ASC";
        break;
    case 'percentage_desc':
        $results_query .= " ORDER BY r.percentage DESC";
        break;
    case 'percentage_asc':
        $results_query .= " ORDER BY r.percentage ASC";
        break;
    default: // date_desc
        $results_query .= " ORDER BY e.exam_date DESC";
}

// Execute query
$stmt = $pdo->prepare($results_query);
$stmt->execute($params);
$results = $stmt->fetchAll();
?>

<style>
    .student-header {
        background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
        color: white;
        padding: 25px;
        border-radius: 10px;
        margin-bottom: 30px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .filter-card {
        background-color: white;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 25px;
        border: 1px solid lightgray;
    }
    .marksheet-table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 0 20px rgba(0,0,0,0.05);
    }
    .marksheet-table th {
        background-color: #4e73df;
        color: white;
        font-weight: 600;
        padding: 15px;
    }
    .marksheet-table td {
        padding: 12px 15px;
        border-bottom: 1px solid #f0f0f0;
        vertical-align: middle;
    }
    .marksheet-table tr:last-child td {
        border-bottom: none;
    }
    .marksheet-table tr:hover {
        background-color: #f8f9ff;
    }
    .action-btn {
        padding: 6px 12px;
        font-size: 14px;
        border-radius: 20px;
        transition: all 0.3s;
    }
    .action-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    .badge-grade {
        font-size: 0.9rem;
        padding: 5px 10px;
        border-radius: 10px;
    }
    .grade-AA { background-color:rgb(0, 107, 45); color: white; }
    .grade-Aplus { background-color: #28a745; color: white; }
    .grade-A { background-color: #5cb85c; color: white; }
    .grade-Bplus { background-color: #8fd19e; color: #333; }
    .grade-B { background-color: #b5d8b7; color: #333; }
    .grade-Cplus { background-color: #ffc107; color: #333; }
    .grade-C { background-color: #fd7e14; color: white; }
    .grade-D { background-color: #dc3545; color: white; }
    .grade-F { background-color: #6c757d; color: white; }
    .percentage-cell {
        font-weight: 600;
    }
    .filter-label {
        font-weight: 500;
        margin-bottom: 8px;
        color: #555;
    }
</style>

<div class="container py-4">
    <div class="student-header">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h2><i class="fas fa-user-graduate me-2"></i><?php echo safe_htmlspecialchars($student['name']); ?></h2>
                <p class="mb-1"><i class="fas fa-id-card me-2"></i>Student ID: <?php echo safe_htmlspecialchars($student['student_id']); ?></p>
                <p class="mb-0"><i class="fas fa-chalkboard me-2"></i>Current Class: <?php echo safe_htmlspecialchars($student['class_name'] . ' ' . $student['section_name']); ?></p>
            </div>
            <div class="text-end">
                <span class="badge bg-light text-dark p-2">
                    <i class="fas fa-calendar-alt me-1"></i> <?php echo date('d M Y'); ?>
                </span>
            </div>
        </div>
    </div>

    <div class="filter-card shadow-sm">
        <h4 class="mb-4"><i class="fas fa-filter me-2"></i>Filter Results</h4>
        <form method="get" action="" class="row g-3">
            <input type="hidden" name="student_id" value="<?php echo safe_htmlspecialchars($student_id); ?>">
            
            <div class="col-md-6">
                <label class="filter-label"><i class="fas fa-graduation-cap me-1"></i> Class</label>
                <select name="class_filter" class="form-select">
                    <option value="">All Classes</option>
                    <?php foreach ($available_classes as $class): ?>
                        <option value="<?php echo $class['id']; ?>" <?php echo $class_filter == $class['id'] ? 'selected' : ''; ?>>
                            <?php echo safe_htmlspecialchars($class['class_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="col-md-6">
                <label class="filter-label"><i class="fas fa-sort me-1"></i> Sort By</label>
                <div class="input-group">
                    <select name="sort_by" class="form-select">
                        <option value="date_desc" <?php echo $sort_by == 'date_desc' ? 'selected' : ''; ?>>
                            <i class="fas fa-arrow-down-wide-short me-1"></i> Newest First
                        </option>
                        <option value="date_asc" <?php echo $sort_by == 'date_asc' ? 'selected' : ''; ?>>
                            <i class="fas fa-arrow-up-wide-short me-1"></i> Oldest First
                        </option>
                        <option value="percentage_desc" <?php echo $sort_by == 'percentage_desc' ? 'selected' : ''; ?>>
                            <i class="fas fa-arrow-down-a-z me-1"></i> Highest % First
                        </option>
                        <option value="percentage_asc" <?php echo $sort_by == 'percentage_asc' ? 'selected' : ''; ?>>
                            <i class="fas fa-arrow-up-a-z me-1"></i> Lowest % First
                        </option>
                    </select>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-sync-alt"></i> Apply
                    </button>
                </div>
            </div>
        </form>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <h4 class="mb-0"><i class="fas fa-clipboard-list me-2"></i>Exam Results</h4>
            <span class="badge bg-primary">
                <?php echo count($results); ?> record<?php echo count($results) != 1 ? 's' : ''; ?>
            </span>
        </div>
        
        <div class="card-body p-0">
            <?php if (count($results) > 0): ?>
                <div class="table-responsive">
                    <table class="marksheet-table">
                        <thead>
                            <tr>
                                <th><i class="fas fa-graduation-cap me-1"></i> Class</th>
                                <th><i class="fas fa-file-alt me-1"></i> Exam</th>
                                <th><i class="fas fa-calendar-day me-1"></i> Date</th>
                                <th><i class="fas fa-star me-1"></i> Grade</th>
                                <th><i class="fas fa-percentage me-1"></i> Percentage</th>
                                <th><i class="fas fa-trophy me-1"></i> Obtained</th>
                                <th><i class="fas fa-cog me-1"></i> Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($results as $result): 
                                $grade_class = 'grade-' . str_replace('+', 'plus', $result['grade']);
                            ?>
                                <tr>
                                    <td><?php echo safe_htmlspecialchars($result['class_name']); ?></td>
                                    <td><?php echo safe_htmlspecialchars($result['exam_name']); ?></td>
                                    <td><?php echo safe_htmlspecialchars(date('d M Y', strtotime($result['exam_date']))); ?></td>
                                    <td>
                                        <span class="badge <?php echo $grade_class; ?>">
                                            <?php echo safe_htmlspecialchars($result['grade']); ?>
                                        </span>
                                    </td>
                                    <td class="percentage-cell">
                                        <?php echo safe_htmlspecialchars($result['percentage']); ?>%
                                    </td>
                                    <td>
                                        <?php echo safe_htmlspecialchars($result['obtained_marks']); ?>/<?php echo safe_htmlspecialchars($result['total_marks']); ?>
                                    </td>
                                    <td>
                                        <a href="../../api/download/download-marksheet.php?result_id=<?php echo $result['id']; ?>" 
                                           class="btn btn-primary btn-sm action-btn"
                                           title="Download Marksheet">
                                            <i class="fas fa-download me-1"></i> Download
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-clipboard-list fa-3x text-muted mb-3"></i>
                    <h4 class="text-muted">No results found</h4>
                    <p class="text-muted">Try adjusting your filters or check back later</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include_once("../../includes/body-close.php"); ?>