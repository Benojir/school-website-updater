<?php
// --- Keep only the essential setup and initial permission checks ---
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Student Dashboard - " . $school_name . "</title>";
include_once("../../includes/header-close.php");

// Validate student id from get request
if (!isset($_GET['student_id'])) {
    die("Student ID not provided.");
}
$student_id = $_GET['student_id'];

// Check if user has permission to even VIEW this page.
// The API will do its own detailed check later.
if (isLoggedIn()) {
    include_once("../../includes/dashboard-navbar.php");
    if (!hasPermission(PERM_MANAGE_EXAMS) && !hasPermission(PERM_MANAGE_STUDENTS) && !hasPermission(PERM_MANAGE_FEES)) {
        include_once("../../includes/permission-denied.php");
        exit;
    }
} elseif (isParentAuthenticated()) {
    include_once("../../includes/parent-dashboard-navbar.php");
    if (!hasParentAccessPermission($student_id)) {
        include_once("../../includes/permission-denied.php");
        exit;
    }
} else {
    echo '<script>location.replace("/");</script>';
    exit;
}
?>

<div class="container mt-5" id="student-report">
    <div id="loading-indicator" class="text-center py-5">
        <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;">
            <span class="visually-hidden">Loading...</span>
        </div>
        <p class="mt-3">Loading Student Data...</p>
    </div>

    <div id="main-content" class="card shadow mb-5" style="display: none;">
        <div class="card-header bg-primary text-white">
            <h3 class="mb-0"><i class="fas fa-user-graduate"></i> Student Profile</h3>
        </div>

        <div class="card-body">
            <div class="row">
                <div class="col-md-3 text-center mb-4 mb-md-0">
                    <img id="studentImage" src="" class="img-thumbnail rounded-circle shadow" style="width: 200px; height: 200px; object-fit: cover;" alt="Student Image">
                    <h4 id="studentName" class="mt-3">-</h4>
                    <p id="studentIdText" class="text-muted">-</p>
                </div>

                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="info-card mb-3">
                                <h5><i class="fas fa-id-card"></i> Basic Information</h5>
                                <hr>
                                <p><strong>Class:</strong> <span id="studentClass">-</span></p>
                                <p><strong>Roll No:</strong> <span id="studentRoll">-</span></p>
                                <p><strong>Admission Date:</strong> <span id="studentAdmissionDate">-</span></p>
                                <p><strong>Status:</strong> <span id="studentStatus" class="badge">-</span></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-card mb-3">
                                <h5><i class="fas fa-home"></i> Family Information</h5>
                                <hr>
                                <p><strong>Father's Name:</strong> <span id="fatherName">-</span></p>
                                <p><strong>Phone:</strong> <span id="phoneNumber">-</span></p>
                                <p><strong>Address:</strong> <span id="address">-</span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-4 border-0 shadow-sm">
                <div class="card-header bg-info text-white"><i class="fas fa-money-bill-wave"></i> Fee Summary</div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-md-6 mb-3 mb-md-0">
                            <div class="p-3 rounded bg-light">
                                <h5>Total Unpaid</h5>
                                <p id="totalUnpaid" class="fs-4 fw-bold text-danger">₹0.00</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="p-3 rounded bg-light">
                                <h5>Wallet Balance</h5>
                                <p id="walletBalance" class="fs-4 fw-bold text-success">₹0.00</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div id="download-section" class="card mb-4 border-0 shadow-sm">
                </div>

            <div class="card mb-4 border border-danger shadow-sm">
                <div class="card-header bg-danger text-white"><i class="fas fa-exclamation-circle"></i> Monthly Unpaid Fees</div>
                <div class="card-body bg-danger bg-opacity-10">
                    <table class="table table-hover text-center align-middle" id="unpaidFeesTable">
                        <thead class="table-dark">
                            <tr>
                                <th>Month/Year</th>
                                <th>Total Amount</th>
                                <th>Unpaid Amount</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="unpaidFeesTableBody">
                            </tbody>
                    </table>
                </div>
            </div>
            </div>
    </div>
</div>

<script>
$(document).ready(function() {
    const studentId = '<?= $student_id ?>'; // Get student_id from PHP

    // Helper function to format currency
    function formatCurrency(amount) {
        return `₹${parseFloat(amount).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }

    // Main function to fetch and render data
    function loadStudentData() {
        $.ajax({
            url: '../../api/parent/get/get-student-details.php',
            type: 'GET',
            data: { student_id: studentId },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    const data = response.data;
                    renderStudentInfo(data.student);
                    renderFeeSummary(data.fees.summary, data.wallet);
                    renderDownloads(data.permissions);
                    renderUnpaidFees(data.fees.monthly.unpaid);
                    // Call other render functions here...

                    // Hide loader and show content
                    $('#loading-indicator').hide();
                    $('#main-content').show();
                } else {
                    // Handle API errors (e.g., permission denied)
                    $('#loading-indicator').html(`<div class="alert alert-danger">${response.message}</div>`);
                }
            },
            error: function(xhr, status, error) {
                // Handle server/network errors
                $('#loading-indicator').html('<div class="alert alert-danger">Failed to load student data. Please try again.</div>');
                console.error(xhr.responseText);
            }
        });
    }

    function renderStudentInfo(student) {
        $('#studentImage').attr('src', `../../uploads/students/${student.student_image}`);
        $('#studentName').text(student.name);
        $('#studentIdText').text(`ID: ${student.student_id}`);
        $('#studentClass').text(`${student.class_name} - ${student.section_name}`);
        $('#studentRoll').text(student.roll_no);
        $('#studentAdmissionDate').text(new Date(student.admission_date).toLocaleDateString('en-GB'));
        $('#fatherName').text(student.father_name);
        $('#phoneNumber').text(student.phone_number);
        $('#address').text(student.address);
        
        const statusBadge = $('#studentStatus');
        statusBadge.text(student.status);
        if (student.status === 'Active') {
            statusBadge.addClass('bg-success');
        } else {
            statusBadge.addClass('bg-danger');
        }
    }

    function renderFeeSummary(summary, wallet) {
        $('#totalUnpaid').text(formatCurrency(summary.total_unpaid));
        $('#walletBalance').text(formatCurrency(wallet.balance));
    }
    
    function renderDownloads(permissions) {
        let content = `
            <div class="card-header bg-success text-white">
                <i class="fas fa-download"></i> Download Documents
            </div>
            <div class="card-body"><div class="row">`;
        
        // ID Card
        content += `
            <div class="col-md-4 mb-3">
                <div class="download-card p-3 text-center border rounded h-100">
                    <i class="fas fa-id-card fa-3x text-primary mb-3"></i>
                    <h4>Student ID Card</h4>
                    <a href="../../api/download/download-bulk-id-card.php?student_ids=${studentId}" class="btn btn-primary mt-auto">
                        <i class="fas fa-download"></i> Download ID Card
                    </a>
                </div>
            </div>`;

        // Admit Card
        content += `
            <div class="col-md-4 mb-3">
                <div class="download-card p-3 text-center border rounded h-100">
                    <i class="fas fa-id-card fa-3x text-warning mb-3"></i>
                    <h4>Admit Card</h4>`;
        if (permissions.can_download_admit) {
            if (permissions.admit_override_active) {
                 content += `<div class="alert alert-info p-2 mb-2"><small><i class="fas fa-info-circle"></i> Allowed by admin override</small></div>`;
            }
            content += `<a href="student-admit-cards.php?student_id=${studentId}" class="btn btn-warning text-white mt-auto">Download Admit</a>`;
        } else {
            content += `<p class="text-muted">Unavailable</p><button class="btn btn-warning text-white mt-auto" disabled>Not Available</button>`;
        }
        content += `</div></div>`;

        // Marksheet (similar logic)
        // ...
        
        content += `</div></div>`;
        $('#download-section').html(content);
    }


    function renderUnpaidFees(unpaidFees) {
        const tableBody = $('#unpaidFeesTableBody');
        tableBody.empty(); // Clear previous data

        if (unpaidFees.length === 0) {
            tableBody.html('<tr><td colspan="4" class="text-center text-muted py-4">No unpaid fees found.</td></tr>');
            return;
        }

        let rows = '';
        unpaidFees.forEach(fee => {
            rows += `
                <tr>
                    <td>${fee.month_year}</td>
                    <td>${formatCurrency(fee.actual_amount)}</td>
                    <td class="text-danger fw-bold">${formatCurrency(fee.unpaid_amount)}</td>
                    <td>
                        <a href="../../api/parent/put/fees-x-payments/pay-fee.php?id=${fee.id}&type=monthly-fee" class="btn btn-sm btn-success">
                            <i class="fas fa-money-bill-wave"></i> Pay Now
                        </a>
                    </td>
                </tr>
            `;
        });
        tableBody.html(rows);
        
        // Initialize DataTables *after* populating the table
        if (!$.fn.DataTable.isDataTable('#unpaidFeesTable')) {
             $('#unpaidFeesTable').DataTable({ responsive: true });
        }
    }
    
    // Initial load
    loadStudentData();
});
</script>

<?php include_once("../../includes/body-close.php"); ?>