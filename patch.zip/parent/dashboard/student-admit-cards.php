<?php
include_once("../../includes/parent/parent-auth-check.php");
include_once("../../includes/permission-check.php");

$navbar_type = 'parent'; // Set the navbar type
$hasPermissionAccessToStudent = true;

// Check admin permission + parent permission
if (isLoggedIn()) { // Check any admin logged in
    $navbar_type = 'admin'; // Set the navbar type
    if (!hasPermission(PERM_MANAGE_EXAMS) && !hasPermission(PERM_MANAGE_STUDENTS) && !hasPermission(PERM_MANAGE_FEES)) {
        $hasPermissionAccessToStudent = false;
    }
} else {
    $parentAuthData = authenticateWebPageRequest($pdo); // If not logged in any parent then it will redirect to parent login
    if (!hasParentAccessToStudent($parentAuthData['parent_id'], $_GET['student_id'] ?? '')) {
        $hasPermissionAccessToStudent = false;
    }
}

include_once("../../includes/header-open.php");
echo "<title>Admit Cards - " . $school_name . "</title>";
include_once("../../includes/header-close.php");

// Validate student id from get request
if (!isset($_GET['student_id'])) {
    die("Student ID not provided.");
}

$student_id = $_GET['student_id'];

// ----------------------------Dashboard Including According to User-----------------------------

if ($navbar_type === 'admin') { // check any admin logged in
    include_once("../../includes/dashboard-navbar.php");
} else {
    include_once("../../includes/parent/parent-dashboard-navbar.php");
}

if (!$hasPermissionAccessToStudent) {
    include_once("../../includes/permission-denied.php");
}

// ----------------------------Main Content-------------------------------------------------------

// Fetch student details with current class information
$student_query = "SELECT s.*, c.class_name, sec.section_name 
                 FROM students s 
                 JOIN classes c ON s.class_id = c.id 
                 JOIN sections sec ON s.section_id = sec.id 
                 WHERE s.student_id = ?";
$stmt = $pdo->prepare($student_query);
$stmt->execute([$student_id]);
$student = $stmt->fetch();

if (!$student) {
    echo '<div class="container mt-5">
            <div class="alert alert-warning" role="alert">
                No admit cards found for this student.<br>
                Maybe no admin card is released yet.
            </div>
        </div>';
    die();
}

// Fetch all released admit cards for the student's current class
$admit_query = "SELECT ea.*, e.exam_name, e.exam_date
                FROM exam_admit_releases ea
                JOIN exams e ON ea.exam_id = e.id
                WHERE ea.class_id = ? 
                AND ea.status = 'released'
                ORDER BY e.exam_date DESC";
$stmt = $pdo->prepare($admit_query);
$stmt->execute([$student['class_id']]);
$admit_cards = $stmt->fetchAll();
?>

<style>
    .admit-card {
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        background-color: #f9f9f9;
    }

    .student-header {
        background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
        color: white;
        padding: 20px;
        border-radius: 8px;
        margin-bottom: 30px;
    }

    .admit-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid #eee;
    }

    .admit-details {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 15px;
        margin-bottom: 15px;
    }

    .detail-item {
        background-color: white;
        padding: 10px;
        border-radius: 5px;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    }

    .detail-item strong {
        display: block;
        color: #666;
        font-size: 0.9rem;
        margin-bottom: 5px;
    }

    .action-btn {
        padding: 6px 12px;
        font-size: 14px;
        border-radius: 20px;
        transition: all 0.3s;
    }

    .action-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .no-admits {
        text-align: center;
        padding: 40px;
        background-color: white;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
</style>

<div class="container py-4">
    <div class="student-header">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h2><i class="fas fa-user-graduate me-2"></i><?php echo safe_htmlspecialchars($student['name']); ?></h2>
                <p class="mb-1"><i class="fas fa-id-card me-2"></i>Student ID: <?php echo safe_htmlspecialchars($student['student_id']); ?></p>
                <p class="mb-0"><i class="fas fa-chalkboard me-2"></i>Current Class: <?php echo safe_htmlspecialchars($student['class_name'] . ' ' . $student['section_name']); ?></p>
            </div>
            <div class="text-end">
                <span class="badge bg-light text-dark p-2">
                    <i class="fas fa-calendar-alt me-1"></i> <?php echo date('d M Y'); ?>
                </span>
            </div>
        </div>
    </div>

    <h3 class="mb-4"><i class="fas fa-id-card me-2"></i>Available Admit Cards</h3>

    <?php if (count($admit_cards) > 0): ?>
        <?php foreach ($admit_cards as $admit): ?>
            <div class="admit-card">
                <div class="admit-header">
                    <h4><?php echo safe_htmlspecialchars($admit['exam_name']); ?></h4>
                    <a href="../../api/download/download-admit-card.php?admit_id=<?php echo $admit['id']; ?>&student_id=<?php echo $student['student_id']; ?>"
                        class="btn btn-primary action-btn">
                        <i class="fas fa-download me-1"></i> Download
                    </a>
                </div>

                <div class="admit-details">
                    <div class="detail-item">
                        <strong>Exam Date</strong>
                        <?php echo safe_htmlspecialchars(date('d M Y', strtotime($admit['exam_date']))); ?>
                    </div>
                    <div class="detail-item">
                        <strong>Release Date</strong>
                        <?php echo safe_htmlspecialchars(date('d M Y H:i', strtotime($admit['release_date']))); ?>
                    </div>
                    <div class="detail-item">
                        <strong>Status</strong>
                        <span class="badge bg-success"><?php echo safe_htmlspecialchars(ucfirst($admit['status'])); ?></span>
                    </div>
                    <div class="detail-item">
                        <strong>Class</strong>
                        <?php echo safe_htmlspecialchars($student['class_name'] . ' ' . $student['section_name']); ?>
                    </div>
                </div>

                <div class="alert alert-info mb-0">
                    <i class="fas fa-info-circle me-2"></i>
                    Please download and print this admit card to bring to your exam.
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="no-admits">
            <i class="fas fa-id-card fa-3x text-muted mb-3"></i>
            <h4 class="text-muted">No admit cards available</h4>
            <p class="text-muted">Admit cards will appear here when released by the administration</p>
        </div>
    <?php endif; ?>
</div>

<?php include_once("../../includes/body-close.php"); ?>