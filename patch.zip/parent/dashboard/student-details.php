<?php
include_once("../../includes/parent/auth/parent-auth-check.php");
include_once("../../includes/permission-check.php");

$navbar_type = 'parent'; // Set the navbar type
$hasPermissionAccessToStudent = true;

// Check admin permission + parent permission
if (isLoggedIn()) { // Check any admin logged in
    $navbar_type = 'admin'; // Set the navbar type
    if (!hasPermission(PERM_MANAGE_EXAMS) && !hasPermission(PERM_MANAGE_STUDENTS) && !hasPermission(PERM_MANAGE_FEES)) {
        $hasPermissionAccessToStudent = false;
    }
} else {
    $parentAuthData = authenticateWebPageRequest($pdo); // If not logged in any parent then it will redirect to parent login
    if (!hasParentAccessToStudent($parentAuthData['parent_id'], $_GET['student_id'] ?? '')) {
        $hasPermissionAccessToStudent = false;
    }
}

include_once("../../includes/header-open.php");
echo "<title>Student Dashboard - " . $school_name . "</title>";
include_once("../../includes/header-close.php");

$student_id = $_GET['student_id'] ?? null;

if (!$student_id) {
    die("Student ID not provided.");
}

// ----------------------------Dashboard Including According to User-----------------------------

if ($navbar_type === 'admin') { // check any admin logged in
    include_once("../../includes/dashboard-navbar.php");
} else {
    include_once("../../includes/parent/parent-dashboard-navbar.php");
}

if (!$hasPermissionAccessToStudent) {
    include_once("../../includes/permission-denied.php");
    // Stop rendering the rest of the page
    include_once("../../includes/body-close.php");
    exit;
}
?>

<div class="container mt-5" id="student-report">
    <div class="card shadow mb-5">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-user-graduate"></i> Student Profile</h3>
                <div class="d-print-none d-none">
                    <button onclick="window.print()" class="btn btn-light">
                        <i class="fas fa-print"></i> Print
                    </button>
                </div>
            </div>
        </div>

        <div class="card-body">
            <div class="row">
                <div class="col-md-3 text-center mb-4 mb-md-0">
                    <div class="student-photo-container">
                        <img src="" class="img-thumbnail rounded-circle shadow"
                            style="width: 200px; height: 200px; object-fit: cover;"
                            id="student-image"
                            alt="Student Image">
                        <h4 class="mt-3" id="student-name">
                            <span class="placeholder col-8"></span>
                        </h4>
                        <p class="text-muted" id="student-id-display">
                            <span class="placeholder col-4"></span>
                        </p>
                    </div>
                </div>

                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="info-card mb-3">
                                <h5><i class="fas fa-id-card"></i> Basic Information</h5>
                                <hr>
                                <p><strong>Class:</strong> <span id="student-class"><span class="placeholder col-6"></span></span></p>
                                <p><strong>Roll No:</strong> <span id="student-roll"><span class="placeholder col-3"></span></span></p>
                                <p><strong>Admission Date:</strong> <span id="student-admission-date"><span class="placeholder col-5"></span></span></p>
                                <p><strong>Date of Birth:</strong> <span id="student-dob"><span class="placeholder col-5"></span></span></p>
                                <p><strong>Gender:</strong> <span id="student-gender"><span class="placeholder col-4"></span></span></p>
                                <p><strong>Blood Group:</strong> <span id="student-blood"><span class="placeholder col-2"></span></span></p>
                                <p><strong>Status:</strong> <span id="student-status"><span class="placeholder col-3"></span></span></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-card mb-3">
                                <h5><i class="fas fa-home"></i> Family Information</h5>
                                <hr>
                                <p><strong>Father's Name:</strong> <span id="student-father-name"><span class="placeholder col-7"></span></span></p>
                                <p><strong>Mother's Name:</strong> <span id="student-mother-name"><span class="placeholder col-7"></span></span></p>
                                <p><strong>Father's Occupation:</strong> <span id="student-father-occupation"><span class="placeholder col-6"></span></span></p>
                                <p><strong>Mother's Occupation:</strong> <span id="student-mother-occupation"><span class="placeholder col-6"></span></span></p>
                                <p><strong>Phone:</strong> <span id="student-phone"><span class="placeholder col-5"></span></span></p>
                                <p><strong>Alternate Phone:</strong> <span id="student-alt-phone"><span class="placeholder col-5"></span></span></p>
                                <p><strong>Address:</strong> <span id="student-address"><span class="placeholder col-10"></span></span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-4 border-0 shadow-sm">
                <div class="card-header bg-info text-white">
                    <i class="fas fa-money-bill-wave"></i> Fee Summary
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-md-6 mb-3 mb-md-0">
                            <div class="p-3 rounded bg-light">
                                <h5>Total Unpaid</h5>
                                <p class="fs-4 fw-bold text-danger" id="total-unpaid-summary">
                                    <span class="spinner-border spinner-border-sm"></span>
                                </p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="p-3 rounded bg-light">
                                <h5>Wallet Balance</h5>
                                <p class="fs-4 fw-bold text-success" id="wallet-balance-summary">
                                    <span class="spinner-border spinner-border-sm"></span>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-4 border-0 shadow-sm">
                <div class="card-header bg-success text-white">
                    <i class="fas fa-download"></i> Download Documents
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <div class="download-card p-3 text-center border rounded">
                                <i class="fas fa-id-card fa-3x text-primary mb-3"></i>
                                <h4>Student ID Card</h4>
                                <p>Download student's official ID card</p>
                                <a href="../../api/download/download-bulk-id-card.php?student_ids=<?= urlencode($student_id) ?>" class="btn btn-primary">
                                    <i class="fas fa-download"></i> Download ID Card
                                </a>
                            </div>
                        </div>

                        <div class="col-md-4 mb-3">
                            <div class="download-card p-3 text-center border rounded">
                                <i class="fas fa-file-lines fa-3x text-warning mb-3"></i>
                                <h4>Admit Card</h4>
                                <p>Download student's examination admit card</p>
                                <a href="student-admit-cards.php?student_id=<?= urlencode($student_id) ?>" class="btn btn-warning text-white">
                                    <i class="fas fa-download"></i> Download Admit
                                </a>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="download-card p-3 text-center border rounded">
                                <i class="fas fa-file-alt fa-3x text-info mb-3"></i>
                                <h4>Marksheet</h4>
                                <p>Download student's examination marksheet</p>
                                <a href="student-marksheets.php?student_id=<?= urlencode($student_id) ?>" class="btn btn-info text-white">
                                    <i class="fas fa-download"></i> Download Marksheet
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mb-4 border-0 shadow-sm" id="wallet-transactions-card">
                <div class="card-header bg-secondary text-white">
                    <i class="fas fa-wallet"></i> Recent Wallet Transactions
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Date</th>
                                    <th>Type</th>
                                    <th>Amount</th>
                                    <th>Description</th>
                                </tr>
                            </thead>
                            <tbody id="wallet-transactions-tbody">
                            </tbody>
                        </table>
                    </div>
                    <div id="walletTransactionsPagination" class="d-flex justify-content-center mt-3"></div>
                </div>
            </div>

            <div class="card mb-4 border border-primary shadow-sm">
                <div class="card-header bg-primary text-white">
                    <i class="fas fa-history"></i> Additional Fees Information
                </div>
                <div class="card-body bg-info bg-opacity-10">
                    <div class="table-responsive">
                        <table class="table table-hover text-center align-middle" id="additionalFeesInfoTable">
                            <thead class="table-dark">
                                <tr>
                                    <th>Class</th>
                                    <th>Fee Type</th>
                                    <th>Amount</th>
                                    <th>Paid Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody id="additionalFeesTbody">
                            </tbody>
                        </table>
                        <div id="additionalFeesPagination" class="d-flex justify-content-center mt-3"></div>
                    </div>
                </div>
            </div>

            <div class="card mb-4 border border-primary shadow-sm">
                <div class="card-header bg-primary text-white">
                    <i class="fas fa-history"></i> Monthly Fees Payments History
                </div>
                <div class="card-body bg-info bg-opacity-10">
                    <div class="table-responsive">
                        <table class="table table-hover text-center align-middle" id="monthlyPaymentsHistoryTable">
                            <thead class="table-dark">
                                <tr>
                                    <th>Payment Date</th>
                                    <th>Amount</th>
                                    <th>Method</th>
                                    <th>Remark</th>
                                </tr>
                            </thead>
                            <tbody id="monthlyHistoryTbody">
                            </tbody>
                        </table>
                        <div id="monthlyPaymentHistoryPagination" class="d-flex justify-content-center mt-3"></div>
                    </div>
                </div>
            </div>

            <div class="card mb-4 border border-danger shadow-sm">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-circle"></i> Monthly Unpaid Fees
                </div>
                <div class="card-body bg-danger bg-opacity-10">
                    <div class="table-responsive">
                        <table class="table table-hover text-center align-middle" id="unpaidMonthlyFeesTable">
                            <thead class="table-dark">
                                <tr>
                                    <th>Payments</th>
                                    <th>Month/Year</th>
                                    <th>Total Amount</th>
                                    <th>Offer Amount</th>
                                    <th>Discount</th>
                                    <th>Pending Amount</th>
                                    <th>Remark</th>
                                    <th class="d-print-none">Action</th>
                                </tr>
                            </thead>
                            <tbody id="unpaidMonthlyTbody">
                            </tbody>
                        </table>
                        <div id="unpaidMonthlyPagination" class="d-flex justify-content-center mt-3"></div>
                    </div>
                </div>
            </div>

            <div class="card mb-4 border border-success shadow-sm">
                <div class="card-header bg-success text-white">
                    <i class="fas fa-check-circle"></i> Monthly Paid Fees
                </div>
                <div class="card-body bg-success bg-opacity-10">
                    <div class="table-responsive">
                        <table class="table table-hover text-center align-middle" id="paidMonthlyFeesTable">
                            <thead class="table-dark">
                                <tr>
                                    <th>Payments</th>
                                    <th>Month/Year</th>
                                    <th>Total Amount</th>
                                    <th>Paid Amount</th>
                                    <th>Discount</th>
                                    <th>Remark</th>
                                    <th>Payment Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="paidMonthlyTbody">
                            </tbody>
                        </table>
                        <div id="paidMonthlyPagination" class="d-flex justify-content-center mt-3"></div>
                    </div>
                </div>
            </div>

            <div class="card mb-4 border border-primary shadow-sm">
                <div class="card-header bg-primary text-white">
                    <i class="fas fa-history"></i> Admission Fees Payments History
                </div>
                <div class="card-body bg-info bg-opacity-10">
                    <div class="table-responsive">
                        <table class="table table-hover text-center align-middle" id="admissionPaymentsHistoryTable">
                            <thead class="table-dark">
                                <tr>
                                    <th>Payment Date</th>
                                    <th>Amount</th>
                                    <th>Method</th>
                                    <th>Remark</th>
                                </tr>
                            </thead>
                            <tbody id="admissionHistoryTbody">
                            </tbody>
                        </table>
                        <div id="admissionPaymentHistoryPagination" class="d-flex justify-content-center mt-3"></div>
                    </div>
                </div>
            </div>

            <div class="card mb-4 border border-danger shadow-sm">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-circle"></i> Unpaid Admission Fees
                </div>
                <div class="card-body bg-danger bg-opacity-10">
                    <div class="table-responsive">
                        <table class="table table-hover text-center align-middle" id="unpaidAdmissionFeesTable">
                            <thead class="table-dark">
                                <tr>
                                    <th>Payments</th>
                                    <th>Academic Year</th>
                                    <th>Class</th>
                                    <th>Total Amount</th>
                                    <th>Offer Amount</th>
                                    <th>Discount</th>
                                    <th>Pending Amount</th>
                                    <th>Remark</th>
                                </tr>
                            </thead>
                            <tbody id="unpaidAdmissionTbody">
                            </tbody>
                        </table>
                        <div id="unpaidAdmissionPagination" class="d-flex justify-content-center mt-3"></div>
                    </div>
                </div>
            </div>

            <div class="card mb-4 border border-success shadow-sm">
                <div class="card-header bg-success text-white">
                    <i class="fas fa-check-circle"></i> Paid Admission Fees
                </div>
                <div class="card-body bg-success bg-opacity-10">
                    <div class="table-responsive">
                        <table class="table table-hover text-center align-middle" id="paidAdmissionFeesTable">
                            <thead class="table-dark">
                                <tr>
                                    <th>Payments</th>
                                    <th>Academic Year</th>
                                    <th>Class</th>
                                    <th>Total Amount</th>
                                    <th>Paid Amount</th>
                                    <th>Discount</th>
                                    <th>Remark</th>
                                    <th>Payment Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="paidAdmissionTbody">
                            </tbody>
                        </table>
                        <div id="paidAdmissionPagination" class="d-flex justify-content-center mt-3"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="partialPaymentsModal" tabindex="-1" aria-labelledby="partialPaymentsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header text-white bg-primary">
                <h5 class="modal-title" id="partialPaymentsModalLabel"><i class="fas fa-receipt"></i> Partial Payment Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-sm table-bordered mb-0 text-center align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th width="25%">Date</th>
                                <th width="25%">Partial Paid Amount</th>
                                <th width="20%">Method</th>
                                <th width="30%">Remark</th>
                            </tr>
                        </thead>
                        <tbody id="partialPaymentsModalTbody">
                            <!-- Will be loaded dynamically -->
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
    // --- Global Variables ---
    const studentId = '<?= $student_id ?>';
    const perPage = 10; // How many items to show per table page
    let partialPaymentsModal; // Will be initialized as a Bootstrap Modal

    // --- Helper Functions ---
    function formatCurrency(amount) {
        if (typeof amount !== 'number') {
            amount = parseFloat(amount) || 0;
        }
        return `₹${amount.toFixed(2)}`;
    }

    function formatDate(dateString) {
        if (!dateString || dateString === '0000-00-00') return '-';
        const date = new Date(dateString.split(' ')[0]); // Handle 'YYYY-MM-DD HH:MM:SS'
        return date.toLocaleDateString('en-GB', {
            day: 'numeric',
            month: 'short',
            year: 'numeric'
        });
    }

    function formatDateTime(dateTimeString) {
        if (!dateTimeString) return '-';
        const date = new Date(dateTimeString);
        return date.toLocaleDateString('en-GB', {
            day: 'numeric',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
        });
    }

    function escapeHtml(unsafe) {
        if (unsafe === null || typeof unsafe === 'undefined') return '-';
        return unsafe.toString()
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function showLoader(tbodyId) {
        const colSpan = $(`#${tbodyId}`).closest('table').find('thead th').length;
        $(`#${tbodyId}`).html(`<tr><td colspan="${colSpan}" class="text-center py-4"><div class="spinner-border text-primary"></div></td></tr>`);
    }

    function showNoData(tbodyId, message) {
        const colSpan = $(`#${tbodyId}`).closest('table').find('thead th').length;
        $(`#${tbodyId}`).html(`<tr><td colspan="${colSpan}" class="text-center text-muted py-4"><i class="fas fa-info-circle fa-2x mb-2"></i><br>${message}</td></tr>`);
    }

    // --- Pagination Renderer ---
    function renderPagination(paginationId, paginationData, pageType) {
        const {
            current_page,
            total_pages
        } = paginationData;
        const paginationEl = $(paginationId);
        paginationEl.empty();

        if (total_pages <= 1) {
            return; // No pagination needed
        }

        let paginationHtml = '<nav><ul class="pagination justify-content-center">';

        // Previous Button
        paginationHtml += `<li class="page-item ${current_page === 1 ? 'disabled' : ''}">
                           <a class="page-link" href="#" data-page="${current_page - 1}" data-type="${pageType}">Previous</a>
                       </li>`;

        // Page Number Buttons
        for (let i = 1; i <= total_pages; i++) {
            paginationHtml += `<li class="page-item ${i === current_page ? 'active' : ''}">
                               <a class="page-link" href="#" data-page="${i}" data-type="${pageType}">${i}</a>
                           </li>`;
        }

        // Next Button
        paginationHtml += `<li class="page-item ${current_page === total_pages ? 'disabled' : ''}">
                               <a class="page-link" href="#" data-page="${current_page + 1}" data-type="${pageType}">Next</a>
                           </li>`;

        paginationHtml += '</ul></nav>';
        paginationEl.html(paginationHtml);
    }

    // --- Data Loading Functions ---

    /**
     * 1. Load Student Details
     * Populates the main student profile card.
     */
    function loadStudentDetails() {
        $.ajax({
            url: '../../api/parent/get/student/get-student-details.php',
            type: 'GET',
            data: {
                student_id: studentId
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    const student = response.data;
                    $('#student-image').attr('src', `../../uploads/students/${escapeHtml(student.student_image)}`);
                    $('#student-name').text(escapeHtml(student.name));
                    $('#student-id-display').text(`ID: ${escapeHtml(student.student_id)}`);

                    $('#student-class').text(`${escapeHtml(student.class_name)} - ${escapeHtml(student.section_name)}`);
                    $('#student-roll').text(escapeHtml(student.roll_no));
                    $('#student-admission-date').text(formatDate(student.admission_date));
                    $('#student-dob').text(formatDate(student.date_of_birth));
                    $('#student-gender').text(escapeHtml(student.gender));
                    $('#student-blood').text(escapeHtml(student.blood_group));

                    const statusBadge = student.status === 'Active' ?
                        '<span class="badge bg-success">Active</span>' :
                        '<span class="badge bg-danger">Inactive</span>';
                    $('#student-status').html(statusBadge);

                    $('#student-father-name').text(escapeHtml(student.father_name));
                    $('#student-mother-name').text(escapeHtml(student.mother_name));
                    $('#student-father-occupation').text(escapeHtml(student.father_occupation));
                    $('#student-mother-occupation').text(escapeHtml(student.mother_occupation));
                    $('#student-phone').text(escapeHtml(student.phone_number));
                    $('#student-alt-phone').text(escapeHtml(student.alternate_phone_number));
                    $('#student-address').text(escapeHtml(student.address));

                } else {
                    toastr.error(response.message || 'Failed to load student details.');
                }
            },
            error: function(xhr) {
                toastr.error('Error fetching student details.');
                console.error(xhr.responseText);
            }
        });
    }

    /**
     * 2. Load Wallet Data
     * Populates the wallet balance in the summary card and the recent transactions table.
     */
    function loadWalletData(page = 1) { // Accept page parameter
        const tbodyId = 'wallet-transactions-tbody';
        const paginationId = '#walletTransactionsPagination';
        showLoader(tbodyId); // Show loader

        $.ajax({
            url: '../../api/parent/get/fees-x-payments/get-student-wallet-data.php',
            type: 'GET',
            data: {
                student_id: studentId,
                page: page, // Pass current page
                result_per_page: perPage // Pass global perPage limit
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Populate wallet balance
                    const walletBalance = response.wallet ? (response.wallet.balance || 0) : 0;
                    $('#wallet-balance-summary').text(formatCurrency(walletBalance));

                    // Populate recent wallet transactions
                    const transactions = response.wallet_transactions;
                    const tbody = $(`#${tbodyId}`);
                    tbody.empty();

                    if (transactions && transactions.length > 0) {
                        let html = '';
                        transactions.forEach(tx => {
                            let type_class = 'info';
                            let type_text = escapeHtml(tx.transaction_type);
                            let amount_class = '';
                            let amount_prefix = '';

                            if (tx.transaction_type === 'deposit') {
                                type_class = 'success';
                                type_text = 'Deposit';
                                amount_class = 'text-success';
                                amount_prefix = '+';
                            } else if (tx.transaction_type === 'deduct') {
                                type_class = 'danger';
                                type_text = 'Deduct';
                                amount_class = 'text-danger';
                                amount_prefix = '-';
                            }

                            html += `
                                <tr>
                                    <td>${formatDateTime(tx.created_at)}</td>
                                    <td><span class="badge bg-${type_class}">${type_text}</span></td>
                                    <td class="${amount_class}">${amount_prefix}${formatCurrency(tx.amount)}</td>
                                    <td>${escapeHtml(tx.description)}</td>
                                </tr>
                            `;
                        });
                        tbody.html(html);

                        // --- Render Pagination ---
                        const paginationData = response.pagination;
                        if (paginationData) {
                            renderPagination(paginationId, paginationData, "walletHistory");
                        } else {
                            $(paginationId).empty();
                        }
                        // --- End Render Pagination ---

                        $('#wallet-transactions-card').show();

                    } else {
                        // Show no data message
                        showNoData(tbodyId, 'No wallet transactions found.');
                        $(paginationId).empty(); // Clear pagination
                        $('#wallet-transactions-card').show();
                    }
                } else {
                    toastr.error(response.message || 'Failed to load wallet data.');
                    $('#wallet-balance-summary').text('Error');
                    showNoData(tbodyId, 'Error loading transactions.');
                }
            },
            error: function(xhr) {
                toastr.error('Error fetching wallet data.');
                console.error(xhr.responseText);
                $('#wallet-balance-summary').text('Error');
                showNoData(tbodyId, 'Error loading transactions.');
            }
        });
    }

    /**
     * 3. Load Fee Package (All 5 Fee Tables)
     * Calls the main fee API and populates all 5 fee tables and their pagination.
     */
    function loadFeePackage(page = 1) {
        // Show loaders for all 5 tables
        showLoader('unpaidMonthlyTbody');
        showLoader('paidMonthlyTbody');
        showLoader('unpaidAdmissionTbody');
        showLoader('paidAdmissionTbody');
        showLoader('additionalFeesTbody');

        $.ajax({
            url: '../../api/parent/get/fees-x-payments/get-fees-x-payments-data.php',
            type: 'GET', // Using GET as it's idempotent
            data: {
                student_id: studentId,
                page: page,
                result_per_page: perPage
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    const data = response.data;

                    // Set Total Unpaid
                    $('#total-unpaid-summary').text(formatCurrency(response.totals.grand_total_unpaid_amount));

                    // --- Populate Tables ---
                    populateFeeTable('monthly_unpaid', data.monthly_fees.unpaid_fees);
                    populateFeeTable('monthly_paid', data.monthly_fees.paid_fees);
                    populateFeeTable('admission_unpaid', data.admission_fees.unpaid_fees);
                    populateFeeTable('admission_paid', data.admission_fees.paid_fees);
                    populateFeeTable('additional', data.additional_fees); // Special case

                } else {
                    toastr.error(response.message || 'Failed to load fee data.');
                }
            },
            error: function(xhr) {
                toastr.error('Error fetching fee data.');
                console.error(xhr.responseText);
            }
        });
    }

    /**
     * Helper for loadFeePackage. Populates a single table.
     */
    function populateFeeTable(type, feeData) {
        let tbodyId, paginationId, noDataMsg;
        let html = '';
        let data, pagination; // Declare variables here

        switch (type) {
            case 'monthly_unpaid':
                tbodyId = '#unpaidMonthlyTbody';
                paginationId = '#unpaidMonthlyPagination';
                noDataMsg = 'No unpaid monthly fees found.';
                data = feeData.data; // Assign 'data' from feeData.data
                pagination = feeData.pagination; // Assign 'pagination' from feeData.pagination

                data.forEach(fee => {
                    const partialPayments = fee.partial_payments || [];
                    html += `
                        <tr class="bg-white">
                            <td>
                                <button class="btn btn-sm btn-info view-partials" data-payments='${JSON.stringify(partialPayments)}'>
                                    View (${partialPayments.length})
                                </button>
                            </td>
                            <td>${escapeHtml(fee.month_year)}</td>
                            <td>${formatCurrency(fee.actual_amount)}</td>
                            <td class="text-danger fw-bold">${formatCurrency(fee.actual_amount - fee.discount_amount)}</td>
                            <td>${formatCurrency(fee.discount_amount)}</td>
                            <td class="text-danger fw-bold">${formatCurrency(fee.unpaid_amount)}</td>
                            <td width="20%">${escapeHtml(fee.remark)}</td>
                            <td class="d-print-none">
                                <a href="../../api/parent/put/fees-x-payments/pay-fee.php?id=${fee.id}&type=monthly-fee" class="btn btn-sm btn-success">
                                    <i class="fas fa-money-bill-wave"></i> Pay Now
                                </a>
                            </td>
                        </tr>`;
                });
                break;

            case 'monthly_paid':
                tbodyId = '#paidMonthlyTbody';
                paginationId = '#paidMonthlyPagination';
                noDataMsg = 'No paid monthly fees found.';
                data = feeData.data; // Assign 'data' from feeData.data
                pagination = feeData.pagination; // Assign 'pagination' from feeData.pagination

                data.forEach(fee => {
                    const partialPayments = fee.partial_payments || [];
                    html += `
                        <tr class="bg-white">
                            <td>
                                <button class="btn btn-sm btn-info view-partials" data-payments='${JSON.stringify(partialPayments)}'>
                                    View (${partialPayments.length})
                                </button>
                            </td>
                            <td>${escapeHtml(fee.month_year)}</td>
                            <td>${formatCurrency(fee.actual_amount)}</td>
                            <td class="text-success fw-bold">${formatCurrency(fee.total_paid_amount)}</td>
                            <td>${formatCurrency(fee.discount_amount)}</td>
                            <td width="20%">${escapeHtml(fee.remark)}</td>
                            <td>${formatDate(fee.created_at)}</td>
                            <td><button onclick="downloadReciept(${fee.id})" class="btn btn-sm btn-primary"><i class="fas fa-file"></i> Receipt</button></td>
                        </tr>`;
                });
                break;

            case 'admission_unpaid':
                tbodyId = '#unpaidAdmissionTbody';
                paginationId = '#unpaidAdmissionPagination';
                noDataMsg = 'No unpaid admission fees found.';
                data = feeData.data; // Assign 'data' from feeData.data
                pagination = feeData.pagination; // Assign 'pagination' from feeData.pagination

                data.forEach(fee => {
                    const partialPayments = fee.partial_payments || [];
                    html += `
                        <tr class="bg-white">
                            <td>
                                <button class="btn btn-sm btn-info view-partials" data-payments='${JSON.stringify(partialPayments)}'>
                                    View (${partialPayments.length})
                                </button>
                            </td>
                            <td>${escapeHtml(fee.academic_year)}</td>
                            <td>${escapeHtml(fee.class_name)}</td>
                            <td>${formatCurrency(fee.actual_amount)}</td>
                            <td class="text-danger fw-bold">${formatCurrency(fee.actual_amount - fee.discount_amount)}</td>
                            <td>${formatCurrency(fee.discount_amount)}</td>
                            <td class="text-danger fw-bold">${formatCurrency(fee.unpaid_amount)}</td>
                            <td width="20%">${escapeHtml(fee.remark)}</td>
                        </tr>`;
                });
                break;

            case 'admission_paid':
                tbodyId = '#paidAdmissionTbody';
                paginationId = '#paidAdmissionPagination';
                noDataMsg = 'No paid admission fees found.';
                data = feeData.data; // Assign 'data' from feeData.data
                pagination = feeData.pagination; // Assign 'pagination' from feeData.pagination

                data.forEach(fee => {
                    const partialPayments = fee.partial_payments || [];
                    html += `
                        <tr class="bg-white">
                            <td>
                                <button class="btn btn-sm btn-info view-partials" data-payments='${JSON.stringify(partialPayments)}'>
                                    View (${partialPayments.length})
                                </button>
                            </td>
                            <td>${escapeHtml(fee.academic_year)}</td>
                            <td>${escapeHtml(fee.class_name)}</td>
                            <td>${formatCurrency(fee.actual_amount)}</td>
                            <td class="text-success fw-bold">${formatCurrency(fee.total_paid_amount)}</td>
                            <td>${formatCurrency(fee.discount_amount)}</td>
                            <td width="20%">${escapeHtml(fee.remark)}</td>
                            <td>${formatDate(fee.created_at)}</td>
                            <td><button onclick="downloadAdmissionReciept(${fee.id})" class="btn btn-sm btn-primary"><i class="fas fa-file"></i> Receipt</button></td>
                        </tr>`;
                });
                break;

            case 'additional':
                tbodyId = '#additionalFeesTbody';
                paginationId = '#additionalFeesPagination';
                noDataMsg = 'No additional fees history found.';
                data = feeData.all_fees; // <-- FIX: Assign 'data' from feeData.all_fees
                pagination = feeData.pagination; // <-- FIX: Assign 'pagination' from feeData.pagination

                data.forEach(fee => {
                    const statusBadge = fee.additional_fee_status === 'paid' ?
                        `<span class="badge bg-success">Paid</span>` :
                        `<span class="badge bg-danger">Unpaid</span>`;
                    const dateToShow = fee.additional_fee_status === 'paid' ?
                        formatDate(fee.additional_fee_paid_date) :
                        formatDate(fee.additional_fee_due_date);

                    html += `
                        <tr class="text-center align-middle">
                            <td>${escapeHtml(fee.class_name)}</td>
                            <td>${escapeHtml(fee.fee_type)}</td>
                            <td class="text-success fw-bold">${formatCurrency(fee.amount)}</td>
                            <td>${statusBadge}</td>
                            <td>${dateToShow}</td>
                        </tr>`;
                });
                break;
        }

        // Populate Tbody
        // This check will now work for all cases
        if (data && data.length > 0) {
            $(tbodyId).html(html);
        } else {
            showNoData(tbodyId.substring(1), noDataMsg);
        }

        // Render Pagination
        // This will also work for all cases now
        renderPagination(paginationId, pagination, 'feePackage'); // All use the 'feePackage' type
    }

    /**
     * 4. Load Payment History (Monthly or Admission)
     * Reusable function to populate the two payment history tables.
     */
    function loadPaymentHistory(type, page = 1) {
        const tbodyId = (type === 'monthly') ? '#monthlyHistoryTbody' : '#admissionHistoryTbody';
        const paginationId = (type === 'monthly') ? '#monthlyPaymentHistoryPagination' : '#admissionPaymentHistoryPagination';
        const noDataMsg = (type === 'monthly') ? 'No monthly payment history found.' : 'No admission payment history found.';

        showLoader(tbodyId.substring(1));

        $.ajax({
            url: '../../api/parent/get/fees-x-payments/get-payment-history.php',
            type: 'GET',
            data: {
                student_id: studentId,
                type: type,
                page: page,
                per_page: perPage
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    const tbody = $(tbodyId);
                    tbody.empty();
                    if (response.data && response.data.length > 0) {
                        let html = '';
                        response.data.forEach(payment => {
                            html += `
                                <tr>
                                    <td>${formatDate(payment.payment_date)}</td>
                                    <td class="text-success fw-bold">${formatCurrency(payment.payment_amount)}</td>
                                    <td class="text-capitalize">${escapeHtml(payment.method)}</td>
                                    <td>${escapeHtml(payment.remark)}</td>
                                </tr>`;
                        });
                        tbody.html(html);

                        // Render pagination for this specific history type
                        const paginationData = {
                            current_page: response.current_page,
                            total_pages: response.total_pages
                        };
                        const pageType = (type === 'monthly') ? 'monthlyHistory' : 'admissionHistory';
                        renderPagination(paginationId, paginationData, pageType);

                    } else {
                        showNoData(tbodyId.substring(1), noDataMsg);
                        $(paginationId).empty(); // Clear pagination
                    }
                } else {
                    toastr.error(response.message || 'Failed to load payment history.');
                    showNoData(tbodyId.substring(1), 'Error loading history.');
                }
            },
            error: function(xhr) {
                toastr.error('Error fetching payment history.');
                console.error(xhr.responseText);
                showNoData(tbodyId.substring(1), 'Error loading history.');
            }
        });
    }

    /**
     * 5. Build and Show Partial Payments Modal
     * Called when a .view-partials button is clicked.
     */
    function buildPartialPaymentsModal(payments) {
        const tbody = $('#partialPaymentsModalTbody');
        tbody.empty();

        if (!payments || payments.length === 0) {
            tbody.html('<tr><td colspan="4" class="text-center text-muted py-3">No partial payments found.</td></tr>');
            return;
        }

        let html = '';
        payments.forEach(payment => {
            html += `
            <tr>
                <td>${formatDate(payment.created_at)}</td>
                <td class="text-success fw-bold">${formatCurrency(payment.partial_paid_amount)}</td>
                <td class="text-capitalize">${escapeHtml(payment.method)}</td>
                <td>${escapeHtml(payment.remark)}</td>
            </tr>`;
        });
        tbody.html(html);
    }

    // --- Global Functions (for inline HTML) ---
    function downloadAdmissionReciept(paid_id) {
        window.open("../../api/download/download-admission-paid-receipt.php?id=" + paid_id, "_blank");
    }

    function downloadReciept(paid_id) {
        window.open("../../api/download/download-monthly-fee-paid-receipt.php?id=" + paid_id, "_blank");
    }


    // --- Document Ready ---
    $(document).ready(function() {

        // Initialize the Bootstrap Modal
        partialPaymentsModal = new bootstrap.Modal($('#partialPaymentsModal')[0]);

        // --- Initial Data Load ---
        loadStudentDetails();
        loadWalletData(1);
        loadFeePackage(1); // Load page 1 for all 5 fee tables
        loadPaymentHistory('monthly', 1); // Load page 1 for monthly history
        loadPaymentHistory('admission', 1); // Load page 1 for admission history

        // --- Event Listeners ---

        // 1. Pagination Click Handler (delegated)
        $(document).on('click', '.page-link', function(e) {
            e.preventDefault();
            const page = $(this).data('page');
            const type = $(this).data('type');

            // Ignore clicks on disabled links
            if ($(this).closest('.page-item').hasClass('disabled') || !page) {
                return;
            }

            switch (type) {
                case 'feePackage':
                    loadFeePackage(page);
                    break;
                case 'monthlyHistory':
                    loadPaymentHistory('monthly', page);
                    break;
                case 'admissionHistory':
                    loadPaymentHistory('admission', page);
                    break;
                case 'walletHistory': // Add this new case
                    loadWalletData(page);
                    break;
            }
        });

        // 2. View Partial Payments Modal Click Handler (delegated)
        $(document).on('click', '.view-partials', function() {
            // 'data-payments' attribute holds the JSON string.
            // .data() automatically parses it into an object.
            const payments = $(this).data('payments');
            buildPartialPaymentsModal(payments);
            partialPaymentsModal.show();
        });

    }); // End of $(document).ready()
</script>

<style>
    /* NOTE: All DataTables-specific CSS has been removed */

    @media print {
        body {
            background: white;
            font-size: 12pt;
        }

        .card {
            border: none !important;
            box-shadow: none !important;
        }

        .d-print-none {
            display: none !important;
        }

        .badge {
            color: white !important;
            border: 1px solid #000;
        }

        .student-photo-container {
            text-align: left !important;
            margin-bottom: 20px;
        }

        .img-thumbnail {
            border: none !important;
            max-width: 150px !important;
            max-height: 150px !important;
        }
    }

    .info-card {
        background-color: #f8f9fa;
        border-radius: 8px;
        padding: 15px;
        height: 100%;
    }

    .download-card {
        transition: all 0.3s ease;
        height: 100%;
    }

    .download-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    .student-photo-container {
        position: relative;
    }

    .student-photo-container h4 {
        color: #333;
        font-weight: 600;
    }

    .table-hover tbody tr:hover {
        background-color: rgba(0, 123, 255, 0.05);
    }

    /* Skeleton Loader Placeholder */
    .placeholder {
        display: inline-block;
        min-height: 1em;
        vertical-align: middle;
        cursor: wait;
        background-color: currentColor;
        opacity: 0.1;
    }
</style>

<?php include_once("../../includes/body-close.php"); ?>