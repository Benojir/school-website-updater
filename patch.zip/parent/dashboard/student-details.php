<?php
/** @var string $school_name */
include_once("../../includes/parent/auth/parent-auth-check.php");
include_once("../../includes/auth-check.php");

$navbar_type = 'parent'; // Set the navbar type
$hasPermissionAccessToStudent = true;

// Check admin permission + parent permission
if (isAnyAdminLoggedIn()) { // Check any admin logged in
    $navbar_type = 'admin'; // Set the navbar type
    if (!hasPermission(PERM_MANAGE_EXAMS) && !hasPermission(PERM_MANAGE_STUDENTS) && !hasPermission(PERM_MANAGE_FEES)) {
        $hasPermissionAccessToStudent = false;
    }
} else {
    $parentAuthData = authenticateWebPageRequest($pdo); // If not logged in any parent then it will redirect to parent login
    if (!hasParentAccessToStudent($parentAuthData['phone_number'], $_GET['student_id'] ?? '')) {
        $hasPermissionAccessToStudent = false;
    }
}

include_once("../../includes/header-open.php");
echo "<title>Student Dashboard - " . $school_name . "</title>";
include_once("../../includes/header-close.php");

$student_id = $_GET['student_id'] ?? null;

if (!$student_id) {
    die("Student ID not provided.");
}

// ----------------------------Dashboard Including According to User-----------------------------

if ($navbar_type === 'admin') { // check any admin logged in
    include_once("../../includes/dashboard-navbar.php");
} else {
    include_once("../../includes/parent/parent-dashboard-navbar.php");
}

if (!$hasPermissionAccessToStudent) {
    include_once("../../includes/permission-denied.php");
    // Stop rendering the rest of the page
    include_once("../../includes/body-close.php");
    exit;
}
?>

<!-- ===================== HERO PROFILE HEADER ===================== -->
<div class="student-profile-page" id="student-report">
    <div class="container-fluid px-lg-5 pt-4 pb-5">

        <!-- Hero Card -->
        <div class="card border-0 shadow-lg mb-4 overflow-hidden student-hero-card">
            <div class="card-body position-relative py-4">
                <div class="row align-items-center">
                    <!-- Photo -->
                    <div class="col-auto">
                        <div class="student-hero-photo-wrap">
                            <img src="" class="student-hero-photo" id="student-image" alt="Student Image" data-fancybox="Student Image" />
                            <span class="student-status-dot" id="student-status-dot" title="Status"></span>
                        </div>
                    </div>
                    <!-- Name & Quick Info -->
                    <div class="col">
                        <h2 class="fw-bold mb-1 text-white" id="student-name">
                            <span class="placeholder col-5"></span>
                        </h2>
                        <p class="mb-2 fs-5" style="color: rgba(255,255,255,0.8);" id="student-class-subtitle">
                            <span class="placeholder col-3"></span>
                        </p>
                        <!-- Quick Stat Pills -->
                        <div class="d-flex flex-wrap gap-2 mt-2" id="student-quick-stats">
                            <span class="badge hero-pill px-3 py-2 rounded-pill">
                                <i class="fas fa-fingerprint me-1"></i> <span id="qs-student-id"><span class="placeholder col-4"></span></span>
                            </span>
                            <span class="badge hero-pill px-3 py-2 rounded-pill">
                                <i class="fas fa-list-ol me-1"></i> Roll: <span id="qs-roll"><span class="placeholder col-2"></span></span>
                            </span>
                            <span class="badge hero-pill px-3 py-2 rounded-pill">
                                <i class="fas fa-calendar-plus me-1"></i> <span id="qs-admission-date"><span class="placeholder col-3"></span></span>
                            </span>
                            <span class="badge hero-pill px-3 py-2 rounded-pill" id="qs-reg-wrap">
                                <i class="fas fa-hashtag me-1"></i> Reg: <span id="qs-reg-no"><span class="placeholder col-3"></span></span>
                            </span>
                        </div>
                    </div>
                    <!-- Actions -->
                    <div class="col-auto d-print-none">
                        <button onclick="window.print()" class="btn btn-light btn-sm rounded-pill shadow-sm">
                            <i class="fas fa-print me-1"></i> Print
                        </button>
                    </div>
                </div>

                <!-- Parent Photos Row -->
                <div class="d-flex flex-wrap gap-4 mt-3 pt-3 border-top" id="parent-photos-row" style="display:none !important;">
                    <div class="d-flex align-items-center gap-2" id="father-photo-wrap" style="display:none !important;">
                        <img src="" class="rounded-circle border border-2 border-primary" style="width:40px;height:40px;object-fit:cover;" id="father-photo" alt="Father" data-fancybox="Parents" />
                        <div>
                            <small class="text-muted d-block" style="font-size:0.7rem;">Father</small>
                            <span class="fw-semibold small" id="hero-father-name"></span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center gap-2" id="mother-photo-wrap" style="display:none !important;">
                        <img src="" class="rounded-circle border border-2 border-danger" style="width:40px;height:40px;object-fit:cover;" id="mother-photo" alt="Mother" data-fancybox="Parents" />
                        <div>
                            <small class="text-muted d-block" style="font-size:0.7rem;">Mother</small>
                            <span class="fw-semibold small" id="hero-mother-name"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ===================== TAB NAVIGATION ===================== -->
        <ul class="nav nav-pills student-nav-tabs mb-4 d-print-none flex-nowrap overflow-auto" id="studentTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="overview-tab" data-bs-toggle="pill" data-bs-target="#tab-overview" type="button" role="tab" aria-controls="tab-overview" aria-selected="true">
                    <i class="fas fa-id-card me-1"></i> Overview
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="documents-tab" data-bs-toggle="pill" data-bs-target="#tab-documents" type="button" role="tab" aria-controls="tab-documents" aria-selected="false">
                    <i class="fas fa-folder-open me-1"></i> Documents
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="fees-tab" data-bs-toggle="pill" data-bs-target="#tab-fees" type="button" role="tab" aria-controls="tab-fees" aria-selected="false">
                    <i class="fas fa-money-bill-wave me-1"></i> Fees & Payments
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="attendance-tab" data-bs-toggle="pill" data-bs-target="#tab-attendance" type="button" role="tab" aria-controls="tab-attendance" aria-selected="false">
                    <i class="fas fa-calendar-check me-1"></i> Attendance
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="wallet-tab" data-bs-toggle="pill" data-bs-target="#tab-wallet" type="button" role="tab" aria-controls="tab-wallet" aria-selected="false">
                    <i class="fas fa-wallet me-1"></i> Wallet
                </button>
            </li>
        </ul>

        <!-- ===================== TAB CONTENT ===================== -->
        <div class="tab-content" id="studentTabContent">

            <!-- ==================== TAB 1: OVERVIEW ==================== -->
            <div class="tab-pane fade show active" id="tab-overview" role="tabpanel" aria-labelledby="overview-tab">
                <div class="row g-4">

                    <!-- Basic Information -->
                    <div class="col-lg-6">
                        <div class="card border-0 shadow-sm h-100 info-section-card">
                            <div class="card-header info-card-header info-card-header--blue pt-3 pb-2">
                                <h5 class="fw-bold mb-0"><i class="fas fa-user-graduate me-2"></i>Basic Information</h5>
                            </div>
                            <div class="card-body">
                                <div class="info-grid">
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-chalkboard text-muted me-1"></i> Class & Section</span>
                                        <span class="info-value" id="student-class"><span class="placeholder col-6"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-list-ol text-muted me-1"></i> Roll No</span>
                                        <span class="info-value" id="student-roll"><span class="placeholder col-3"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-hashtag text-muted me-1"></i> Registration No</span>
                                        <span class="info-value" id="student-reg-no"><span class="placeholder col-5"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-calendar-plus text-muted me-1"></i> Admission Date</span>
                                        <span class="info-value" id="student-admission-date"><span class="placeholder col-5"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-graduation-cap text-muted me-1"></i> Academic Year</span>
                                        <span class="info-value" id="student-academic-year"><span class="placeholder col-4"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-birthday-cake text-muted me-1"></i> Date of Birth</span>
                                        <span class="info-value" id="student-dob"><span class="placeholder col-5"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-venus-mars text-muted me-1"></i> Gender</span>
                                        <span class="info-value" id="student-gender"><span class="placeholder col-4"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-tint text-muted me-1"></i> Blood Group</span>
                                        <span class="info-value" id="student-blood"><span class="placeholder col-2"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-toggle-on text-muted me-1"></i> Status</span>
                                        <span class="info-value" id="student-status"><span class="placeholder col-3"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-pray text-muted me-1"></i> Religion</span>
                                        <span class="info-value text-capitalize" id="student-religion"><span class="placeholder col-4"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-users text-muted me-1"></i> Caste</span>
                                        <span class="info-value" id="student-caste"><span class="placeholder col-4"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-envelope text-muted me-1"></i> Email</span>
                                        <span class="info-value" id="student-email"><span class="placeholder col-6"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-id-card text-muted me-1"></i> Student Aadhaar</span>
                                        <span class="info-value" id="student-aadhaar-no"><span class="placeholder col-5"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-school text-muted me-1"></i> Banglar Shiksha Code</span>
                                        <span class="info-value" id="student-bsk-code"><span class="placeholder col-5"></span></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Family Information -->
                    <div class="col-lg-6">
                        <div class="card border-0 shadow-sm h-100 info-section-card">
                            <div class="card-header info-card-header info-card-header--rose pt-3 pb-2">
                                <h5 class="fw-bold mb-0"><i class="fas fa-heart me-2"></i>Family Information</h5>
                            </div>
                            <div class="card-body">
                                <div class="info-grid">
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-male text-muted me-1"></i> Father's Name</span>
                                        <span class="info-value" id="student-father-name"><span class="placeholder col-7"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-briefcase text-muted me-1"></i> Father's Occupation</span>
                                        <span class="info-value" id="student-father-occupation"><span class="placeholder col-6"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-rupee-sign text-muted me-1"></i> Father's Annual Income</span>
                                        <span class="info-value" id="student-father-income"><span class="placeholder col-4"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-id-card text-muted me-1"></i> Father's Aadhaar</span>
                                        <span class="info-value" id="student-father-aadhaar"><span class="placeholder col-5"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-credit-card text-muted me-1"></i> Father's PAN</span>
                                        <span class="info-value" id="student-father-pan"><span class="placeholder col-4"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-vote-yea text-muted me-1"></i> Father's Voter No</span>
                                        <span class="info-value" id="student-father-voter"><span class="placeholder col-5"></span></span>
                                    </div>
                                    <div class="info-item full-width"><hr class="my-1 opacity-25"></div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-female text-muted me-1"></i> Mother's Name</span>
                                        <span class="info-value" id="student-mother-name"><span class="placeholder col-7"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-briefcase text-muted me-1"></i> Mother's Occupation</span>
                                        <span class="info-value" id="student-mother-occupation"><span class="placeholder col-6"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-rupee-sign text-muted me-1"></i> Mother's Annual Income</span>
                                        <span class="info-value" id="student-mother-income"><span class="placeholder col-4"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-id-card text-muted me-1"></i> Mother's Aadhaar</span>
                                        <span class="info-value" id="student-mother-aadhaar"><span class="placeholder col-5"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-credit-card text-muted me-1"></i> Mother's PAN</span>
                                        <span class="info-value" id="student-mother-pan"><span class="placeholder col-4"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-vote-yea text-muted me-1"></i> Mother's Voter No</span>
                                        <span class="info-value" id="student-mother-voter"><span class="placeholder col-5"></span></span>
                                    </div>
                                    <div class="info-item full-width"><hr class="my-1 opacity-25"></div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-phone text-muted me-1"></i> Phone</span>
                                        <span class="info-value" id="student-phone"><span class="placeholder col-5"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-phone-alt text-muted me-1"></i> Alternate Phone</span>
                                        <span class="info-value" id="student-alt-phone"><span class="placeholder col-5"></span></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Address Details -->
                    <div class="col-lg-6">
                        <div class="card border-0 shadow-sm h-100 info-section-card">
                            <div class="card-header info-card-header info-card-header--green pt-3 pb-2">
                                <h5 class="fw-bold mb-0"><i class="fas fa-map-marker-alt me-2"></i>Address Details</h5>
                            </div>
                            <div class="card-body">
                                <div class="info-grid">
                                    <div class="info-item full-width">
                                        <span class="info-label"><i class="fas fa-home text-muted me-1"></i> Full Address</span>
                                        <span class="info-value" id="student-address"><span class="placeholder col-10"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-map-pin text-muted me-1"></i> Village</span>
                                        <span class="info-value" id="student-village"><span class="placeholder col-5"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-envelope-open text-muted me-1"></i> Post Office</span>
                                        <span class="info-value" id="student-po"><span class="placeholder col-5"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-shield-alt text-muted me-1"></i> Police Station</span>
                                        <span class="info-value" id="student-ps"><span class="placeholder col-5"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-city text-muted me-1"></i> District</span>
                                        <span class="info-value" id="student-district"><span class="placeholder col-5"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-map text-muted me-1"></i> Pin Code</span>
                                        <span class="info-value" id="student-pincode"><span class="placeholder col-3"></span></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Additional / Transport / Banking Info -->
                    <div class="col-lg-6">
                        <div class="card border-0 shadow-sm h-100 info-section-card">
                            <div class="card-header info-card-header info-card-header--amber pt-3 pb-2">
                                <h5 class="fw-bold mb-0"><i class="fas fa-cogs me-2"></i>Additional Information</h5>
                            </div>
                            <div class="card-body">
                                <div class="info-grid">
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-bed text-muted me-1"></i> Hosteler</span>
                                        <span class="info-value" id="student-is-hosteler"><span class="placeholder col-2"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-rupee-sign text-muted me-1"></i> Hostel Fee</span>
                                        <span class="info-value" id="student-hostel-fee"><span class="placeholder col-3"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-car text-muted me-1"></i> Car Fee</span>
                                        <span class="info-value" id="student-car-fee"><span class="placeholder col-3"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-chalkboard-user text-muted me-1"></i> Coaching Fee</span>
                                        <span class="info-value" id="student-coaching-fee"><span class="placeholder col-3"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-utensils text-muted me-1"></i> Tiffin Fee</span>
                                        <span class="info-value" id="student-tiffin-fee"><span class="placeholder col-3"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-book text-muted me-1"></i> Custom Class Fee</span>
                                        <span class="info-value" id="student-custom-fee"><span class="placeholder col-3"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-car-side text-muted me-1"></i> Driver</span>
                                        <span class="info-value" id="student-driver-name"><span class="placeholder col-5"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-route text-muted me-1"></i> Route</span>
                                        <span class="info-value" id="student-route-name"><span class="placeholder col-5"></span></span>
                                    </div>
                                    <div class="info-item full-width"><hr class="my-1 opacity-25"></div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-university text-muted me-1"></i> Bank Name</span>
                                        <span class="info-value" id="student-bank-name"><span class="placeholder col-5"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-code-branch text-muted me-1"></i> Bank Branch</span>
                                        <span class="info-value" id="student-bank-branch"><span class="placeholder col-5"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-credit-card text-muted me-1"></i> Account No</span>
                                        <span class="info-value" id="student-bank-account"><span class="placeholder col-5"></span></span>
                                    </div>
                                    <div class="info-item">
                                        <span class="info-label"><i class="fas fa-barcode text-muted me-1"></i> IFSC Code</span>
                                        <span class="info-value" id="student-ifsc"><span class="placeholder col-4"></span></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- ==================== TAB 2: DOCUMENTS ==================== -->
            <div class="tab-pane fade" id="tab-documents" role="tabpanel" aria-labelledby="documents-tab">

                <!-- Document Images Gallery -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header info-card-header info-card-header--blue pt-3 pb-2">
                        <h5 class="fw-bold mb-0"><i class="fas fa-images me-2"></i>Uploaded Documents</h5>
                        <small style="color:rgba(255,255,255,0.75);">Click on any document to view it in full size</small>
                    </div>
                    <div class="card-body">
                        <div class="row g-3" id="documents-gallery">
                            <!-- Populated via JS -->
                            <div class="col-12 text-center py-4">
                                <div class="spinner-border text-primary" role="status"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Download Cards -->
                <div class="card border-0 shadow-sm">
                    <div class="card-header info-card-header info-card-header--green pt-3 pb-2">
                        <h5 class="fw-bold mb-0"><i class="fas fa-download me-2"></i>Download Documents</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <div class="download-card p-4 text-center border rounded-4 bg-light">
                                    <div class="download-card-icon bg-primary bg-opacity-10 text-primary mx-auto mb-3">
                                        <i class="fas fa-id-card fa-2x"></i>
                                    </div>
                                    <h6 class="fw-bold">Student ID Card</h6>
                                    <p class="text-muted small mb-3">Official ID card for the student</p>
                                    <a href="../../api/download/download-bulk-id-card.php?student_ids=<?= urlencode($student_id) ?>" class="btn btn-primary btn-sm rounded-pill px-4">
                                        <i class="fas fa-download me-1"></i> Download
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="download-card p-4 text-center border rounded-4 bg-light">
                                    <div class="download-card-icon bg-warning bg-opacity-10 text-warning mx-auto mb-3">
                                        <i class="fas fa-file-lines fa-2x"></i>
                                    </div>
                                    <h6 class="fw-bold">Admit Card</h6>
                                    <p class="text-muted small mb-3">Examination admit card</p>
                                    <a href="student-admit-cards.php?student_id=<?= urlencode($student_id) ?>" class="btn btn-warning text-white btn-sm rounded-pill px-4">
                                        <i class="fas fa-download me-1"></i> Download
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="download-card p-4 text-center border rounded-4 bg-light">
                                    <div class="download-card-icon bg-info bg-opacity-10 text-info mx-auto mb-3">
                                        <i class="fas fa-file-alt fa-2x"></i>
                                    </div>
                                    <h6 class="fw-bold">Marksheet</h6>
                                    <p class="text-muted small mb-3">Examination marksheet</p>
                                    <a href="student-marksheets.php?student_id=<?= urlencode($student_id) ?>" class="btn btn-info text-white btn-sm rounded-pill px-4">
                                        <i class="fas fa-download me-1"></i> Download
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ==================== TAB 3: FEES & PAYMENTS ==================== -->
            <div class="tab-pane fade" id="tab-fees" role="tabpanel" aria-labelledby="fees-tab">

                <!-- Fee Summary Cards -->
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body d-flex align-items-center gap-3">
                                <div class="fee-summary-icon bg-danger bg-opacity-10 text-danger">
                                    <i class="fas fa-exclamation-triangle fa-2x"></i>
                                </div>
                                <div>
                                    <small class="text-muted fw-semibold text-uppercase" style="font-size:0.7rem;letter-spacing:0.5px;">Total Unpaid</small>
                                    <h3 class="fw-bolder text-danger mb-0" id="total-unpaid-summary">
                                        <span class="spinner-border spinner-border-sm"></span>
                                    </h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card border-0 shadow-sm h-100">
                            <div class="card-body d-flex align-items-center gap-3">
                                <div class="fee-summary-icon bg-success bg-opacity-10 text-success">
                                    <i class="fas fa-wallet fa-2x"></i>
                                </div>
                                <div>
                                    <small class="text-muted fw-semibold text-uppercase" style="font-size:0.7rem;letter-spacing:0.5px;">Wallet Balance</small>
                                    <h3 class="fw-bolder text-success mb-0" id="wallet-balance-summary">
                                        <span class="spinner-border spinner-border-sm"></span>
                                    </h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Fee Accordion -->
                <div class="accordion" id="feeAccordion">

                    <!-- Additional Fees -->
                    <div class="accordion-item border-0 shadow-sm mb-3 rounded-3 overflow-hidden">
                        <h2 class="accordion-header">
                            <button class="accordion-button bg-primary bg-opacity-10 text-white fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseAdditionalFees" aria-expanded="true">
                                <i class="fas fa-plus-circle me-2"></i> Additional Fees Information
                            </button>
                        </h2>
                        <div id="collapseAdditionalFees" class="accordion-collapse collapse show" data-bs-parent="#feeAccordion">
                            <div class="accordion-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover text-center align-middle mb-0" id="additionalFeesInfoTable">
                                        <thead class="table-dark">
                                            <tr>
                                                <th>Class</th>
                                                <th>Fee Type</th>
                                                <th>Amount</th>
                                                <th>Paid Status</th>
                                                <th>Date</th>
                                            </tr>
                                        </thead>
                                        <tbody id="additionalFeesTbody"></tbody>
                                    </table>
                                    <div id="additionalFeesPagination" class="d-flex justify-content-center py-2"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Monthly Fees Payment History -->
                    <div class="accordion-item border-0 shadow-sm mb-3 rounded-3 overflow-hidden">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed bg-info bg-opacity-10 text-info fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseMonthlyHistory">
                                <i class="fas fa-history me-2"></i> Monthly Fees Payment History
                            </button>
                        </h2>
                        <div id="collapseMonthlyHistory" class="accordion-collapse collapse">
                            <div class="accordion-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover text-center align-middle mb-0" id="monthlyPaymentsHistoryTable">
                                        <thead class="table-dark">
                                            <tr>
                                                <th>Payment Date</th>
                                                <th>Amount</th>
                                                <th>Method</th>
                                                <th>Remark</th>
                                            </tr>
                                        </thead>
                                        <tbody id="monthlyHistoryTbody"></tbody>
                                    </table>
                                    <div id="monthlyPaymentHistoryPagination" class="d-flex justify-content-center py-2"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Monthly Unpaid Fees -->
                    <div class="accordion-item border-0 shadow-sm mb-3 rounded-3 overflow-hidden">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed bg-danger bg-opacity-10 text-danger fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseUnpaidMonthly">
                                <i class="fas fa-exclamation-circle me-2"></i> Monthly Unpaid Fees
                            </button>
                        </h2>
                        <div id="collapseUnpaidMonthly" class="accordion-collapse collapse">
                            <div class="accordion-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover text-center align-middle mb-0" id="unpaidMonthlyFeesTable">
                                        <thead class="table-dark">
                                            <tr>
                                                <th>Payments</th>
                                                <th>Month/Year</th>
                                                <th>Total Amount</th>
                                                <th>Offer Amount</th>
                                                <th>Discount</th>
                                                <th>Pending Amount</th>
                                                <th>Remark</th>
                                                <th class="d-print-none">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="unpaidMonthlyTbody"></tbody>
                                    </table>
                                    <div id="unpaidMonthlyPagination" class="d-flex justify-content-center py-2"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Monthly Paid Fees -->
                    <div class="accordion-item border-0 shadow-sm mb-3 rounded-3 overflow-hidden">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed bg-success bg-opacity-10 text-success fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapsePaidMonthly">
                                <i class="fas fa-check-circle me-2"></i> Monthly Paid Fees
                            </button>
                        </h2>
                        <div id="collapsePaidMonthly" class="accordion-collapse collapse">
                            <div class="accordion-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover text-center align-middle mb-0" id="paidMonthlyFeesTable">
                                        <thead class="table-dark">
                                            <tr>
                                                <th>Payments</th>
                                                <th>Month/Year</th>
                                                <th>Total Amount</th>
                                                <th>Paid Amount</th>
                                                <th>Discount</th>
                                                <th>Remark</th>
                                                <th>Payment Date</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="paidMonthlyTbody"></tbody>
                                    </table>
                                    <div id="paidMonthlyPagination" class="d-flex justify-content-center py-2"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Admission Fees Payment History -->
                    <div class="accordion-item border-0 shadow-sm mb-3 rounded-3 overflow-hidden">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed bg-info bg-opacity-10 text-info fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseAdmissionHistory">
                                <i class="fas fa-history me-2"></i> Admission Fees Payment History
                            </button>
                        </h2>
                        <div id="collapseAdmissionHistory" class="accordion-collapse collapse">
                            <div class="accordion-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover text-center align-middle mb-0" id="admissionPaymentsHistoryTable">
                                        <thead class="table-dark">
                                            <tr>
                                                <th>Payment Date</th>
                                                <th>Amount</th>
                                                <th>Method</th>
                                                <th>Remark</th>
                                            </tr>
                                        </thead>
                                        <tbody id="admissionHistoryTbody"></tbody>
                                    </table>
                                    <div id="admissionPaymentHistoryPagination" class="d-flex justify-content-center py-2"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Unpaid Admission Fees -->
                    <div class="accordion-item border-0 shadow-sm mb-3 rounded-3 overflow-hidden">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed bg-danger bg-opacity-10 text-danger fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseUnpaidAdmission">
                                <i class="fas fa-exclamation-circle me-2"></i> Unpaid Admission Fees
                            </button>
                        </h2>
                        <div id="collapseUnpaidAdmission" class="accordion-collapse collapse">
                            <div class="accordion-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover text-center align-middle mb-0" id="unpaidAdmissionFeesTable">
                                        <thead class="table-dark">
                                            <tr>
                                                <th>Payments</th>
                                                <th>Academic Year</th>
                                                <th>Class</th>
                                                <th>Total Amount</th>
                                                <th>Offer Amount</th>
                                                <th>Discount</th>
                                                <th>Pending Amount</th>
                                                <th>Remark</th>
                                            </tr>
                                        </thead>
                                        <tbody id="unpaidAdmissionTbody"></tbody>
                                    </table>
                                    <div id="unpaidAdmissionPagination" class="d-flex justify-content-center py-2"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Paid Admission Fees -->
                    <div class="accordion-item border-0 shadow-sm mb-3 rounded-3 overflow-hidden">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed bg-success bg-opacity-10 text-success fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapsePaidAdmission">
                                <i class="fas fa-check-circle me-2"></i> Paid Admission Fees
                            </button>
                        </h2>
                        <div id="collapsePaidAdmission" class="accordion-collapse collapse">
                            <div class="accordion-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-hover text-center align-middle mb-0" id="paidAdmissionFeesTable">
                                        <thead class="table-dark">
                                            <tr>
                                                <th>Payments</th>
                                                <th>Academic Year</th>
                                                <th>Class</th>
                                                <th>Total Amount</th>
                                                <th>Paid Amount</th>
                                                <th>Discount</th>
                                                <th>Remark</th>
                                                <th>Payment Date</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody id="paidAdmissionTbody"></tbody>
                                    </table>
                                    <div id="paidAdmissionPagination" class="d-flex justify-content-center py-2"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- ==================== TAB 4: ATTENDANCE ==================== -->
            <div class="tab-pane fade" id="tab-attendance" role="tabpanel" aria-labelledby="attendance-tab">
                <div class="card border-0 shadow-sm" id="student-attendance-card">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center flex-wrap gap-2 py-3 rounded-top-3">
                        <div class="d-flex align-items-center">
                            <i class="fa-solid fa-calendar-check fa-lg me-2"></i>
                            <h5 class="mb-0 fw-bold">Attendance Overview & Records</h5>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <label for="attendanceMonthFilter" class="small text-white text-nowrap d-none d-sm-inline fw-semibold"><i class="fas fa-filter me-1"></i>Month:</label>
                            <select id="attendanceMonthFilter" class="form-select form-select-sm shadow-sm bg-white text-dark fw-medium" style="min-width: 170px;">
                                <!-- Populated via JavaScript -->
                            </select>
                        </div>
                    </div>

                    <div class="card-body p-3 p-md-4">
                        <!-- KPI Summary Stats Row -->
                        <div class="row g-3 mb-4">
                            <div class="col-6 col-md-3">
                                <div class="p-3 rounded-4 bg-success bg-opacity-10 border border-success border-opacity-25 h-100 d-flex flex-column justify-content-between shadow-sm">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <span class="text-uppercase text-success fw-bold small" style="font-size: 0.75rem; letter-spacing: 0.5px;">Present Days</span>
                                            <h3 class="fw-bolder text-success my-1" id="att-present-count">0</h3>
                                        </div>
                                        <div class="p-2 rounded-circle bg-success bg-opacity-25 text-success">
                                            <i class="fas fa-check-circle fa-lg"></i>
                                        </div>
                                    </div>
                                    <div class="mt-2 d-flex align-items-center">
                                        <span class="badge bg-success" id="att-present-percent">0%</span>
                                        <span class="text-muted small ms-1">attendance rate</span>
                                    </div>
                                </div>
                            </div>

                            <div class="col-6 col-md-3">
                                <div class="p-3 rounded-4 bg-danger bg-opacity-10 border border-danger border-opacity-25 h-100 d-flex flex-column justify-content-between shadow-sm">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <span class="text-uppercase text-danger fw-bold small" style="font-size: 0.75rem; letter-spacing: 0.5px;">Absent Days</span>
                                            <h3 class="fw-bolder text-danger my-1" id="att-absent-count">0</h3>
                                        </div>
                                        <div class="p-2 rounded-circle bg-danger bg-opacity-25 text-danger">
                                            <i class="fas fa-times-circle fa-lg"></i>
                                        </div>
                                    </div>
                                    <div class="mt-2">
                                        <span class="text-muted small">Missed classes</span>
                                    </div>
                                </div>
                            </div>

                            <div class="col-6 col-md-3">
                                <div class="p-3 rounded-4 bg-warning bg-opacity-10 border border-warning border-opacity-25 h-100 d-flex flex-column justify-content-between shadow-sm">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <span class="text-uppercase text-warning-emphasis fw-bold small" style="font-size: 0.75rem; letter-spacing: 0.5px;">Leave Days</span>
                                            <h3 class="fw-bolder text-warning-emphasis my-1" id="att-leave-count">0</h3>
                                        </div>
                                        <div class="p-2 rounded-circle bg-warning bg-opacity-25 text-warning-emphasis">
                                            <i class="fa-solid fa-person-walking-arrow-right fa-lg"></i>
                                        </div>
                                    </div>
                                    <div class="mt-2">
                                        <span class="text-muted small">Approved leaves</span>
                                    </div>
                                </div>
                            </div>

                            <div class="col-6 col-md-3">
                                <div class="p-3 rounded-4 bg-primary-subtle border border-primary-subtle h-100 d-flex flex-column justify-content-between shadow-sm">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <span class="text-uppercase text-primary fw-bold small" style="font-size: 0.75rem; letter-spacing: 0.5px;">Total Recorded</span>
                                            <h3 class="fw-bolder text-primary my-1" id="att-total-count">0</h3>
                                        </div>
                                        <div class="p-2 rounded-circle bg-primary bg-opacity-25 text-white">
                                            <i class="fas fa-calendar-days fa-lg"></i>
                                        </div>
                                    </div>
                                    <div class="mt-2">
                                        <span class="text-muted small" id="att-summary-month-label">This Month</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Progress Bar -->
                        <div class="p-3 rounded-3 bg-light border mb-4">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <span class="small fw-semibold text-secondary"><i class="fas fa-chart-line me-1"></i> Attendance Health Rate</span>
                                <span class="small fw-bold text-dark" id="att-progress-label">0% Present</span>
                            </div>
                            <div class="progress" style="height: 10px; border-radius: 6px;">
                                <div class="progress-bar bg-success progress-bar-striped progress-bar-animated" role="progressbar" id="att-progress-bar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>

                        <!-- Filter Buttons Bar -->
                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
                            <div class="btn-group btn-group-sm shadow-sm" role="group" id="attendanceStatusFilterGroup">
                                <button type="button" class="btn btn-outline-primary active" data-filter="all">
                                    <i class="fas fa-list me-1"></i> All (<span id="att-filter-count-all">0</span>)
                                </button>
                                <button type="button" class="btn btn-outline-success" data-filter="present">
                                    <i class="fas fa-check-circle me-1"></i> Present (<span id="att-filter-count-present">0</span>)
                                </button>
                                <button type="button" class="btn btn-outline-danger" data-filter="absent">
                                    <i class="fas fa-times-circle me-1"></i> Absent (<span id="att-filter-count-absent">0</span>)
                                </button>
                                <button type="button" class="btn btn-outline-warning text-dark" data-filter="leave">
                                    <i class="fa-solid fa-person-walking-arrow-right me-1"></i> Leave (<span id="att-filter-count-leave">0</span>)
                                </button>
                            </div>
                            <div class="text-muted small">
                                <i class="fas fa-calendar-check me-1 text-primary"></i>Showing records for <strong id="att-current-month-heading">-</strong>
                            </div>
                        </div>

                        <!-- Attendance Table -->
                        <div class="table-responsive rounded-3 border">
                            <table class="table table-hover table-striped text-center align-middle mb-0" id="attendanceRecordsTable">
                                <thead class="table-dark">
                                    <tr>
                                        <th>Date</th>
                                        <th>Day</th>
                                        <th>Time</th>
                                        <th>Status</th>
                                        <th>Logged By</th>
                                        <th>Class / Section</th>
                                    </tr>
                                </thead>
                                <tbody id="attendanceRecordsTbody">
                                    <tr>
                                        <td colspan="6" class="text-center py-4">
                                            <div class="spinner-border text-primary" role="status"></div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ==================== TAB 5: WALLET ==================== -->
            <div class="tab-pane fade" id="tab-wallet" role="tabpanel" aria-labelledby="wallet-tab">
                <div class="card border-0 shadow-sm" id="wallet-transactions-card">
                    <div class="card-header info-card-header info-card-header--blue pt-3 pb-2">
                        <h5 class="fw-bold mb-0"><i class="fas fa-wallet me-2"></i>Wallet Transactions</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>Date</th>
                                        <th>Type</th>
                                        <th>Amount</th>
                                        <th>Description</th>
                                    </tr>
                                </thead>
                                <tbody id="wallet-transactions-tbody">
                                </tbody>
                            </table>
                        </div>
                        <div id="walletTransactionsPagination" class="d-flex justify-content-center mt-3"></div>
                    </div>
                </div>
            </div>

        </div><!-- /tab-content -->
    </div><!-- /container -->
</div><!-- /student-profile-page -->

<!-- Partial Payments Modal -->
<div class="modal fade" id="partialPaymentsModal" tabindex="-1" aria-labelledby="partialPaymentsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header text-white bg-primary">
                <h5 class="modal-title" id="partialPaymentsModalLabel"><i class="fas fa-receipt"></i> Partial Payment Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-sm table-bordered mb-0 text-center align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th width="25%">Date</th>
                                <th width="25%">Partial Paid Amount</th>
                                <th width="20%">Method</th>
                                <th width="30%">Remark</th>
                            </tr>
                        </thead>
                        <tbody id="partialPaymentsModalTbody">
                            <!-- Will be loaded dynamically -->
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
    // --- Global Variables ---
    const studentId = '<?= $student_id ?>';
    const perPage = 10; // How many items to show per table page
    let partialPaymentsModal; // Will be initialized as a Bootstrap Modal

    // --- Helper Functions ---
    function formatCurrency(amount) {
        if (typeof amount !== 'number') {
            amount = parseFloat(amount) || 0;
        }
        return `₹${amount.toFixed(2)}`;
    }

    function showLoader(tbodyId) {
        const colSpan = $(`#${tbodyId}`).closest('table').find('thead th').length;
        $(`#${tbodyId}`).html(`<tr><td colspan="${colSpan}" class="text-center py-4"><div class="spinner-border text-primary"></div></td></tr>`);
    }

    function showNoData(tbodyId, message) {
        const colSpan = $(`#${tbodyId}`).closest('table').find('thead th').length;
        $(`#${tbodyId}`).html(`<tr><td colspan="${colSpan}" class="text-center text-muted py-4"><i class="fas fa-info-circle fa-2x mb-2"></i><br>${message}</td></tr>`);
    }

    function displayValue(val) {
        if (val === null || val === undefined || val === '' || val === 'null') {
            return '<span class="text-muted fst-italic" style="font-size:0.85em;">Not provided</span>';
        }
        return escapeHtml(String(val));
    }

    function displayFee(val) {
        const num = parseFloat(val);
        if (!num || num === 0) return '<span class="text-muted fst-italic" style="font-size:0.85em;">N/A</span>';
        return formatCurrency(num);
    }

    // --- Pagination Renderer ---
    function renderPagination(paginationId, paginationData, pageType) {
        const {
            current_page,
            total_pages
        } = paginationData;
        const paginationEl = $(paginationId);
        paginationEl.empty();

        if (total_pages <= 1) {
            return; // No pagination needed
        }

        let paginationHtml = '<nav><ul class="pagination justify-content-center">';

        // Previous Button
        paginationHtml += `<li class="page-item ${current_page === 1 ? 'disabled' : ''}">
                           <a class="page-link" href="#" data-page="${current_page - 1}" data-type="${pageType}">Previous</a>
                       </li>`;

        // Page Number Buttons
        for (let i = 1; i <= total_pages; i++) {
            paginationHtml += `<li class="page-item ${i === current_page ? 'active' : ''}">
                               <a class="page-link" href="#" data-page="${i}" data-type="${pageType}">${i}</a>
                           </li>`;
        }

        // Next Button
        paginationHtml += `<li class="page-item ${current_page === total_pages ? 'disabled' : ''}">
                               <a class="page-link" href="#" data-page="${current_page + 1}" data-type="${pageType}">Next</a>
                           </li>`;

        paginationHtml += '</ul></nav>';
        paginationEl.html(paginationHtml);
    }

    // --- Data Loading Functions ---

    /**
     * 1. Load Student Details
     * Populates the hero header, overview tab, and documents tab.
     */
    function loadStudentDetails() {
        $.ajax({
            url: '../../api/parent/get/student/get-student-details.php',
            type: 'GET',
            data: {
                student_id: studentId
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    const s = response.data;

                    // --- Hero Header ---
                    $('#student-image').attr('src', `../../uploads/students/${escapeHtml(s.student_image)}`);
                    $('#student-name').text(escapeHtml(s.name));
                    $('#student-class-subtitle').html(`<i class="fas fa-graduation-cap me-1"></i> ${escapeHtml(s.class_name)} - ${escapeHtml(s.section_name)}`);
                    $('#qs-student-id').text(escapeHtml(s.student_id));
                    $('#qs-roll').text(escapeHtml(s.roll_no));
                    $('#qs-admission-date').text(formatDate(s.admission_date));
                    $('#qs-reg-no').text(s.registration_no || 'N/A');

                    // Status dot
                    const dot = $('#student-status-dot');
                    if (s.status === 'Active') {
                        dot.addClass('active-dot').attr('title', 'Active');
                    } else {
                        dot.addClass('inactive-dot').attr('title', 'Inactive');
                    }

                    // Parent photos
                    if (s.father_image && s.father_image !== 'default_father_dp.jpg') {
                        $('#father-photo').attr('src', `../../uploads/fathers/${escapeHtml(s.father_image)}`);
                        $('#hero-father-name').text(escapeHtml(s.father_name));
                        $('#father-photo-wrap').css('display', '');
                        $('#parent-photos-row').css('display', '');
                    }
                    if (s.mother_image && s.mother_image !== 'default_mother_dp.jpg') {
                        $('#mother-photo').attr('src', `../../uploads/mothers/${escapeHtml(s.mother_image)}`);
                        $('#hero-mother-name').text(escapeHtml(s.mother_name));
                        $('#mother-photo-wrap').css('display', '');
                        $('#parent-photos-row').css('display', '');
                    }

                    // --- Overview Tab: Basic Info ---
                    $('#student-class').html(displayValue(`${s.class_name} - ${s.section_name}`));
                    $('#student-roll').html(displayValue(s.roll_no));
                    $('#student-reg-no').html(displayValue(s.registration_no));
                    $('#student-admission-date').html(s.admission_date ? formatDate(s.admission_date) : displayValue(null));
                    $('#student-academic-year').html(displayValue(s.academic_year));
                    $('#student-dob').html(s.date_of_birth ? formatDate(s.date_of_birth) : displayValue(null));
                    $('#student-gender').html(displayValue(s.gender));
                    $('#student-blood').html(displayValue(s.blood_group));
                    $('#student-religion').html(displayValue(s.religion));
                    $('#student-caste').html(displayValue(s.caste));
                    $('#student-email').html(displayValue(s.email));
                    $('#student-aadhaar-no').html(displayValue(s.student_adhaar_no));
                    $('#student-bsk-code').html(displayValue(s.banglar_shiksha_code));

                    const statusBadge = s.status === 'Active' ?
                        '<span class="badge bg-success">Active</span>' :
                        '<span class="badge bg-danger">Inactive</span>';
                    $('#student-status').html(statusBadge);

                    // --- Overview Tab: Family Info ---
                    $('#student-father-name').html(displayValue(s.father_name));
                    $('#student-father-occupation').html(displayValue(s.father_occupation));
                    $('#student-father-income').html(displayValue(s.father_annual_income));
                    $('#student-father-aadhaar').html(displayValue(s.father_adhaar_no));
                    $('#student-father-pan').html(displayValue(s.father_pan_no));
                    $('#student-father-voter').html(displayValue(s.father_voter_no));
                    $('#student-mother-name').html(displayValue(s.mother_name));
                    $('#student-mother-occupation').html(displayValue(s.mother_occupation));
                    $('#student-mother-income').html(displayValue(s.mother_annual_income));
                    $('#student-mother-aadhaar').html(displayValue(s.mother_adhaar_no));
                    $('#student-mother-pan').html(displayValue(s.mother_pan_no));
                    $('#student-mother-voter').html(displayValue(s.mother_voter_no));
                    $('#student-phone').html(displayValue(s.phone_number));
                    $('#student-alt-phone').html(displayValue(s.alternate_phone_number));

                    // --- Overview Tab: Address ---
                    $('#student-address').html(displayValue(s.address));
                    $('#student-village').html(displayValue(s.village));
                    $('#student-po').html(displayValue(s.post_office));
                    $('#student-ps').html(displayValue(s.police_station));
                    $('#student-district').html(displayValue(s.district));
                    $('#student-pincode').html(displayValue(s.pin_code));

                    // --- Overview Tab: Additional ---
                    $('#student-is-hosteler').html(s.is_hosteler == 1 ? '<span class="badge bg-success">Yes</span>' : '<span class="badge bg-secondary">No</span>');
                    $('#student-hostel-fee').html(displayFee(s.hostel_fee));
                    $('#student-car-fee').html(displayFee(s.car_fee));
                    $('#student-coaching-fee').html(displayFee(s.coaching_fee));
                    $('#student-tiffin-fee').html(displayFee(s.tiffin_fee));
                    $('#student-custom-fee').html(displayFee(s.custom_class_fee));
                    $('#student-bank-name').html(displayValue(s.bank_name));
                    $('#student-bank-branch').html(displayValue(s.bank_branch_name));
                    $('#student-bank-account').html(displayValue(s.bank_account_no));
                    $('#student-ifsc').html(displayValue(s.ifsc_code));

                    // Driver & Route
                    if (s.driver_details) {
                        $('#student-driver-name').html(displayValue(s.driver_details.name));
                    } else {
                        $('#student-driver-name').html(displayValue(null));
                    }
                    if (s.driving_route_details) {
                        $('#student-route-name').html(displayValue(s.driving_route_details.route_name));
                    } else {
                        $('#student-route-name').html(displayValue(null));
                    }

                    // --- Documents Tab ---
                    populateDocuments(s);

                } else {
                    toastr.error(response.message || 'Failed to load student details.');
                }
            },
            error: function(xhr) {
                toastr.error('Error fetching student details.');
                console.error(xhr.responseText);
            }
        });
    }

    /**
     * Populate Document Gallery
     */
    function populateDocuments(student) {
        const docMap = [
            { key: 'student_birth_certificate', label: 'Birth Certificate', icon: 'fa-baby', color: 'primary' },
            { key: 'student_aadhaar_image', label: "Student's Aadhaar Card", icon: 'fa-id-card', color: 'info' },
            { key: 'student_transfer_certificate', label: 'Transfer Certificate', icon: 'fa-file-export', color: 'warning' },
            { key: 'father_aadhaar_image', label: "Father's Aadhaar Card", icon: 'fa-id-card', color: 'success' },
            { key: 'father_voter_image', label: "Father's Voter Card", icon: 'fa-vote-yea', color: 'secondary' },
            { key: 'father_pan_image', label: "Father's PAN Card", icon: 'fa-credit-card', color: 'danger' },
            { key: 'mother_aadhaar_image', label: "Mother's Aadhaar Card", icon: 'fa-id-card', color: 'success' },
            { key: 'mother_voter_image', label: "Mother's Voter Card", icon: 'fa-vote-yea', color: 'secondary' },
            { key: 'mother_pan_image', label: "Mother's PAN Card", icon: 'fa-credit-card', color: 'danger' },
        ];

        const gallery = $('#documents-gallery');
        gallery.empty();

        let hasAnyDoc = false;

        docMap.forEach(doc => {
            const url = student[doc.key];
            if (url && url !== '' && url !== 'null') {
                hasAnyDoc = true;
                gallery.append(`
                    <div class="col-6 col-md-4 col-lg-3">
                        <a href="${escapeHtml(url)}" data-fancybox="documents" data-caption="${escapeHtml(doc.label)}" class="doc-gallery-card d-block text-decoration-none">
                            <div class="card border-0 shadow-sm h-100 doc-thumb-card overflow-hidden">
                                <div class="doc-thumb-img-wrap">
                                    <img src="${escapeHtml(url)}" alt="${escapeHtml(doc.label)}" class="doc-thumb-img" loading="lazy" onerror="this.closest('.col-6').remove();" />
                                </div>
                                <div class="card-body p-2 text-center">
                                    <small class="fw-semibold text-dark d-block text-truncate">
                                        <i class="fas ${doc.icon} text-${doc.color} me-1"></i>${escapeHtml(doc.label)}
                                    </small>
                                    <small class="text-muted" style="font-size:0.7rem;"><i class="fas fa-search-plus me-1"></i>Click to view</small>
                                </div>
                            </div>
                        </a>
                    </div>
                `);
            }
        });

        if (!hasAnyDoc) {
            gallery.html(`
                <div class="col-12 text-center py-5">
                    <i class="fas fa-folder-open fa-3x text-muted mb-3 opacity-50"></i>
                    <p class="text-muted">No documents have been uploaded yet.</p>
                </div>
            `);
        }
    }

    /**
     * 2. Load Wallet Data
     * Populates the wallet balance in the summary card and the recent transactions table.
     */
    function loadWalletData(page = 1) { // Accept page parameter
        const tbodyId = 'wallet-transactions-tbody';
        const paginationId = '#walletTransactionsPagination';
        showLoader(tbodyId); // Show loader

        $.ajax({
            url: '../../api/parent/get/fees-x-payments/get-student-wallet-data.php',
            type: 'GET',
            data: {
                student_id: studentId,
                page: page, // Pass current page
                result_per_page: perPage // Pass global perPage limit
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Populate wallet balance
                    const walletBalance = response.wallet ? (response.wallet.balance || 0) : 0;
                    $('#wallet-balance-summary').text(formatCurrency(walletBalance));

                    // Populate recent wallet transactions
                    const transactions = response.wallet_transactions;
                    const tbody = $(`#${tbodyId}`);
                    tbody.empty();

                    if (transactions && transactions.length > 0) {
                        let html = '';
                        transactions.forEach(tx => {
                            let type_class = 'info';
                            let type_text = escapeHtml(tx.transaction_type);
                            let amount_class = '';
                            let amount_prefix = '';

                            if (tx.transaction_type === 'deposit') {
                                type_class = 'success';
                                type_text = 'Deposit';
                                amount_class = 'text-success';
                                amount_prefix = '+';
                            } else if (tx.transaction_type === 'deduct') {
                                type_class = 'danger';
                                type_text = 'Deduct';
                                amount_class = 'text-danger';
                                amount_prefix = '-';
                            }

                            html += `
                                <tr>
                                    <td>${formatDateTime(tx.created_at)}</td>
                                    <td><span class="badge bg-${type_class}">${type_text}</span></td>
                                    <td class="${amount_class}">${amount_prefix}${formatCurrency(tx.amount)}</td>
                                    <td>${escapeHtml(tx.description)}</td>
                                </tr>
                            `;
                        });
                        tbody.html(html);

                        // --- Render Pagination ---
                        const paginationData = response.pagination;
                        if (paginationData) {
                            renderPagination(paginationId, paginationData, "walletHistory");
                        } else {
                            $(paginationId).empty();
                        }
                        // --- End Render Pagination ---

                        $('#wallet-transactions-card').show();

                    } else {
                        // Show no data message
                        showNoData(tbodyId, 'No wallet transactions found.');
                        $(paginationId).empty(); // Clear pagination
                        $('#wallet-transactions-card').show();
                    }
                } else {
                    toastr.error(response.message || 'Failed to load wallet data.');
                    $('#wallet-balance-summary').text('Error');
                    showNoData(tbodyId, 'Error loading transactions.');
                }
            },
            error: function(xhr) {
                toastr.error('Error fetching wallet data.');
                console.error(xhr.responseText);
                $('#wallet-balance-summary').text('Error');
                showNoData(tbodyId, 'Error loading transactions.');
            }
        });
    }

    /**
     * 3. Load Fee Package (All 5 Fee Tables)
     * Calls the main fee API and populates all 5 fee tables and their pagination.
     */
    function loadFeePackage(page = 1) {
        // Show loaders for all 5 tables
        showLoader('unpaidMonthlyTbody');
        showLoader('paidMonthlyTbody');
        showLoader('unpaidAdmissionTbody');
        showLoader('paidAdmissionTbody');
        showLoader('additionalFeesTbody');

        $.ajax({
            url: '../../api/parent/get/fees-x-payments/get-fees-x-payments-data.php',
            type: 'GET', // Using GET as it's idempotent
            data: {
                student_id: studentId,
                page: page,
                result_per_page: perPage
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    const data = response.data;

                    // Set Total Unpaid
                    $('#total-unpaid-summary').text(formatCurrency(response.totals.grand_total_unpaid_amount));

                    // --- Populate Tables ---
                    populateFeeTable('monthly_unpaid', data.monthly_fees.unpaid_fees);
                    populateFeeTable('monthly_paid', data.monthly_fees.paid_fees);
                    populateFeeTable('admission_unpaid', data.admission_fees.unpaid_fees);
                    populateFeeTable('admission_paid', data.admission_fees.paid_fees);
                    populateFeeTable('additional', data.additional_fees); // Special case

                } else {
                    toastr.error(response.message || 'Failed to load fee data.');
                }
            },
            error: function(xhr) {
                toastr.error('Error fetching fee data.');
                console.error(xhr.responseText);
            }
        });
    }

    /**
     * Helper for loadFeePackage. Populates a single table.
     */
    function populateFeeTable(type, feeData) {
        let tbodyId, paginationId, noDataMsg;
        let html = '';
        let data, pagination; // Declare variables here

        switch (type) {
            case 'monthly_unpaid':
                tbodyId = '#unpaidMonthlyTbody';
                paginationId = '#unpaidMonthlyPagination';
                noDataMsg = 'No unpaid monthly fees found.';
                data = feeData.data; // Assign 'data' from feeData.data
                pagination = feeData.pagination; // Assign 'pagination' from feeData.pagination

                data.forEach(fee => {
                    const partialPayments = fee.partial_payments || [];
                    html += `
                        <tr class="bg-white">
                            <td>
                                <button class="btn btn-sm btn-info view-partials" data-payments='${JSON.stringify(partialPayments)}'>
                                    View (${partialPayments.length})
                                </button>
                            </td>
                            <td>${escapeHtml(fee.month_year)}</td>
                            <td>${formatCurrency(fee.actual_amount)}</td>
                            <td class="text-danger fw-bold">${formatCurrency(fee.actual_amount - fee.discount_amount)}</td>
                            <td>${formatCurrency(fee.discount_amount)}</td>
                            <td class="text-danger fw-bold">${formatCurrency(fee.unpaid_amount)}</td>
                            <td width="20%">${escapeHtml(fee.remark)}</td>
                            <td class="d-print-none">
                                <a href="../../api/parent/put/fees-x-payments/pay-fee.php?id=${fee.id}&type=monthly-fee" class="btn btn-sm btn-success">
                                    <i class="fas fa-money-bill-wave"></i> Pay Now
                                </a>
                            </td>
                        </tr>`;
                });
                break;

            case 'monthly_paid':
                tbodyId = '#paidMonthlyTbody';
                paginationId = '#paidMonthlyPagination';
                noDataMsg = 'No paid monthly fees found.';
                data = feeData.data; // Assign 'data' from feeData.data
                pagination = feeData.pagination; // Assign 'pagination' from feeData.pagination

                data.forEach(fee => {
                    const partialPayments = fee.partial_payments || [];
                    html += `
                        <tr class="bg-white">
                            <td>
                                <button class="btn btn-sm btn-info view-partials" data-payments='${JSON.stringify(partialPayments)}'>
                                    View (${partialPayments.length})
                                </button>
                            </td>
                            <td>${escapeHtml(fee.month_year)}</td>
                            <td>${formatCurrency(fee.actual_amount)}</td>
                            <td class="text-success fw-bold">${formatCurrency(fee.total_paid_amount)}</td>
                            <td>${formatCurrency(fee.discount_amount)}</td>
                            <td width="20%">${escapeHtml(fee.remark)}</td>
                            <td>${formatDate(fee.created_at)}</td>
                            <td><button onclick="downloadReciept(${fee.id})" class="btn btn-sm btn-primary"><i class="fas fa-file"></i> Receipt</button></td>
                        </tr>`;
                });
                break;

            case 'admission_unpaid':
                tbodyId = '#unpaidAdmissionTbody';
                paginationId = '#unpaidAdmissionPagination';
                noDataMsg = 'No unpaid admission fees found.';
                data = feeData.data; // Assign 'data' from feeData.data
                pagination = feeData.pagination; // Assign 'pagination' from feeData.pagination

                data.forEach(fee => {
                    const partialPayments = fee.partial_payments || [];
                    html += `
                        <tr class="bg-white">
                            <td>
                                <button class="btn btn-sm btn-info view-partials" data-payments='${JSON.stringify(partialPayments)}'>
                                    View (${partialPayments.length})
                                </button>
                            </td>
                            <td>${escapeHtml(fee.academic_year)}</td>
                            <td>${escapeHtml(fee.class_name)}</td>
                            <td>${formatCurrency(fee.actual_amount)}</td>
                            <td class="text-danger fw-bold">${formatCurrency(fee.actual_amount - fee.discount_amount)}</td>
                            <td>${formatCurrency(fee.discount_amount)}</td>
                            <td class="text-danger fw-bold">${formatCurrency(fee.unpaid_amount)}</td>
                            <td width="20%">${escapeHtml(fee.remark)}</td>
                        </tr>`;
                });
                break;

            case 'admission_paid':
                tbodyId = '#paidAdmissionTbody';
                paginationId = '#paidAdmissionPagination';
                noDataMsg = 'No paid admission fees found.';
                data = feeData.data; // Assign 'data' from feeData.data
                pagination = feeData.pagination; // Assign 'pagination' from feeData.pagination

                data.forEach(fee => {
                    const partialPayments = fee.partial_payments || [];
                    html += `
                        <tr class="bg-white">
                            <td>
                                <button class="btn btn-sm btn-info view-partials" data-payments='${JSON.stringify(partialPayments)}'>
                                    View (${partialPayments.length})
                                </button>
                            </td>
                            <td>${escapeHtml(fee.academic_year)}</td>
                            <td>${escapeHtml(fee.class_name)}</td>
                            <td>${formatCurrency(fee.actual_amount)}</td>
                            <td class="text-success fw-bold">${formatCurrency(fee.total_paid_amount)}</td>
                            <td>${formatCurrency(fee.discount_amount)}</td>
                            <td width="20%">${escapeHtml(fee.remark)}</td>
                            <td>${formatDate(fee.created_at)}</td>
                            <td><button onclick="downloadAdmissionReciept(${fee.id})" class="btn btn-sm btn-primary"><i class="fas fa-file"></i> Receipt</button></td>
                        </tr>`;
                });
                break;

            case 'additional':
                tbodyId = '#additionalFeesTbody';
                paginationId = '#additionalFeesPagination';
                noDataMsg = 'No additional fees history found.';
                data = feeData.all_fees; // <-- FIX: Assign 'data' from feeData.all_fees
                pagination = feeData.pagination; // <-- FIX: Assign 'pagination' from feeData.pagination

                data.forEach(fee => {
                    const statusBadge = fee.additional_fee_status === 'paid' ?
                        `<span class="badge bg-success">Paid</span>` :
                        `<span class="badge bg-danger">Unpaid</span>`;
                    const dateToShow = fee.additional_fee_status === 'paid' ?
                        formatDate(fee.additional_fee_paid_date) :
                        formatDate(fee.additional_fee_due_date);

                    html += `
                        <tr class="text-center align-middle">
                            <td>${escapeHtml(fee.class_name)}</td>
                            <td>${escapeHtml(fee.fee_type)}</td>
                            <td class="text-success fw-bold">${formatCurrency(fee.amount)}</td>
                            <td>${statusBadge}</td>
                            <td>${dateToShow}</td>
                        </tr>`;
                });
                break;
        }

        // Populate Tbody
        // This check will now work for all cases
        if (data && data.length > 0) {
            $(tbodyId).html(html);
        } else {
            showNoData(tbodyId.substring(1), noDataMsg);
        }

        // Render Pagination
        // This will also work for all cases now
        renderPagination(paginationId, pagination, 'feePackage'); // All use the 'feePackage' type
    }

    /**
     * 4. Load Payment History (Monthly or Admission)
     * Reusable function to populate the two payment history tables.
     */
    function loadPaymentHistory(type, page = 1) {
        const tbodyId = (type === 'monthly') ? '#monthlyHistoryTbody' : '#admissionHistoryTbody';
        const paginationId = (type === 'monthly') ? '#monthlyPaymentHistoryPagination' : '#admissionPaymentHistoryPagination';
        const noDataMsg = (type === 'monthly') ? 'No monthly payment history found.' : 'No admission payment history found.';

        showLoader(tbodyId.substring(1));

        $.ajax({
            url: '../../api/parent/get/fees-x-payments/get-payment-history.php',
            type: 'GET',
            data: {
                student_id: studentId,
                type: type,
                page: page,
                per_page: perPage
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    const tbody = $(tbodyId);
                    tbody.empty();
                    if (response.data && response.data.length > 0) {
                        let html = '';
                        response.data.forEach(payment => {
                            html += `
                                <tr>
                                    <td>${formatDate(payment.payment_date)}</td>
                                    <td class="text-success fw-bold">${formatCurrency(payment.payment_amount)}</td>
                                    <td class="text-capitalize">${escapeHtml(payment.method)}</td>
                                    <td>${escapeHtml(payment.remark)}</td>
                                </tr>`;
                        });
                        tbody.html(html);

                        // Render pagination for this specific history type
                        const paginationData = {
                            current_page: response.current_page,
                            total_pages: response.total_pages
                        };
                        const pageType = (type === 'monthly') ? 'monthlyHistory' : 'admissionHistory';
                        renderPagination(paginationId, paginationData, pageType);

                    } else {
                        showNoData(tbodyId.substring(1), noDataMsg);
                        $(paginationId).empty(); // Clear pagination
                    }
                } else {
                    toastr.error(response.message || 'Failed to load payment history.');
                    showNoData(tbodyId.substring(1), 'Error loading history.');
                }
            },
            error: function(xhr) {
                toastr.error('Error fetching payment history.');
                console.error(xhr.responseText);
                showNoData(tbodyId.substring(1), 'Error loading history.');
            }
        });
    }

    /**
     * 5. Build and Show Partial Payments Modal
     * Called when a .view-partials button is clicked.
     */
    function buildPartialPaymentsModal(payments) {
        const tbody = $('#partialPaymentsModalTbody');
        tbody.empty();

        if (!payments || payments.length === 0) {
            tbody.html('<tr><td colspan="4" class="text-center text-muted py-3">No partial payments found.</td></tr>');
            return;
        }

        let html = '';
        payments.forEach(payment => {
            html += `
            <tr>
                <td>${formatDate(payment.created_at)}</td>
                <td class="text-success fw-bold">${formatCurrency(payment.partial_paid_amount)}</td>
                <td class="text-capitalize">${escapeHtml(payment.method)}</td>
                <td>${escapeHtml(payment.remark)}</td>
            </tr>`;
        });
        tbody.html(html);
    }

    // --- Global Functions (for inline HTML) ---
    function downloadAdmissionReciept(paid_id) {
        window.open("../../api/download/download-admission-paid-receipt.php?id=" + paid_id, "_blank");
    }

    function downloadReciept(paid_id) {
        window.open("../../api/download/download-monthly-fee-paid-receipt.php?id=" + paid_id, "_blank");
    }

    // --- 6. Attendance Management Data Loading ---
    let currentAttendanceList = [];
    let currentAttendanceFilter = 'all';

    function initAttendanceMonths() {
        const $select = $('#attendanceMonthFilter');
        $select.empty();

        const monthNames = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];

        const today = new Date();
        for (let i = 0; i < 12; i++) {
            const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
            const mName = monthNames[d.getMonth()];
            const y = d.getFullYear();
            const val = `${mName} ${y}`;
            $select.append(`<option value="${val}" ${i === 0 ? 'selected' : ''}>${val}</option>`);
        }
    }

    function loadStudentAttendanceData(selectedMonth) {
        if (!selectedMonth) {
            selectedMonth = $('#attendanceMonthFilter').val();
        }

        const tbodyId = 'attendanceRecordsTbody';
        showLoader(tbodyId);

        $('#att-current-month-heading').text(selectedMonth);
        $('#att-summary-month-label').text(selectedMonth);

        $.ajax({
            url: '../../api/universal/get/student/student-attendance-data.php',
            type: 'GET',
            data: {
                student_id: studentId,
                month: selectedMonth
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    currentAttendanceList = response.attendance || [];

                    // Calculate counts
                    const totalCount = currentAttendanceList.length;
                    let presentCount = 0;
                    let absentCount = 0;
                    let leaveCount = 0;

                    currentAttendanceList.forEach(item => {
                        const s = (item.status || '').toLowerCase();
                        if (s === 'present') presentCount++;
                        else if (s === 'absent') absentCount++;
                        else if (s === 'leave') leaveCount++;
                    });

                    const presentPercent = totalCount > 0 ? Math.round((presentCount / totalCount) * 100) : 0;

                    // Update KPI counters
                    $('#att-present-count').text(presentCount);
                    $('#att-present-percent').text(presentPercent + '%');
                    $('#att-absent-count').text(absentCount);
                    $('#att-leave-count').text(leaveCount);
                    $('#att-total-count').text(totalCount);

                    // Update Progress Bar
                    $('#att-progress-bar').css('width', presentPercent + '%').attr('aria-valuenow', presentPercent);
                    $('#att-progress-label').text(presentPercent + '% Present (' + presentCount + '/' + totalCount + ' days)');

                    // Update filter counts
                    $('#att-filter-count-all').text(totalCount);
                    $('#att-filter-count-present').text(presentCount);
                    $('#att-filter-count-absent').text(absentCount);
                    $('#att-filter-count-leave').text(leaveCount);

                    renderAttendanceTable();
                } else {
                    toastr.error(response.message || 'Failed to load attendance records.');
                    showNoData(tbodyId, 'Failed to load attendance records.');
                }
            },
            error: function(xhr) {
                toastr.error('Error fetching attendance records.');
                console.error(xhr.responseText);
                showNoData(tbodyId, 'Error loading attendance records.');
            }
        });
    }

    function renderAttendanceTable() {
        const tbody = $('#attendanceRecordsTbody');
        tbody.empty();

        let filteredList = currentAttendanceList;
        if (currentAttendanceFilter !== 'all') {
            filteredList = currentAttendanceList.filter(item => (item.status || '').toLowerCase() === currentAttendanceFilter);
        }

        if (!filteredList || filteredList.length === 0) {
            tbody.html(`
                <tr>
                    <td colspan="6" class="text-center text-muted py-4">
                        <i class="fa-solid fa-calendar-xmark fa-2x mb-2 text-secondary opacity-50"></i><br>
                        No attendance records found for this selection.
                    </td>
                </tr>
            `);
            return;
        }

        const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

        let html = '';
        filteredList.forEach(item => {
            const rawDate = item.date;
            const dateObj = new Date(rawDate + 'T00:00:00');
            const dayName = !isNaN(dateObj.getTime()) ? dayNames[dateObj.getDay()] : '-';

            // Format time
            let timeFormatted = '-';
            if (item.time) {
                const timeParts = item.time.split(':');
                if (timeParts.length >= 2) {
                    let h = parseInt(timeParts[0], 10);
                    const m = timeParts[1];
                    const ampm = h >= 12 ? 'PM' : 'AM';
                    h = h % 12;
                    h = h ? h : 12;
                    timeFormatted = `${h}:${m} ${ampm}`;
                } else {
                    timeFormatted = item.time;
                }
            }

            // Status badge
            const s = (item.status || '').toLowerCase();
            let statusBadge = '';
            if (s === 'present') {
                statusBadge = '<span class="badge bg-success bg-opacity-10 text-success border border-success rounded-pill px-3 py-1 fw-semibold"><i class="fas fa-check-circle me-1"></i> Present</span>';
            } else if (s === 'absent') {
                statusBadge = '<span class="badge bg-danger bg-opacity-10 text-danger border border-danger rounded-pill px-3 py-1 fw-semibold"><i class="fas fa-times-circle me-1"></i> Absent</span>';
            } else if (s === 'leave') {
                statusBadge = '<span class="badge bg-warning bg-opacity-10 text-warning-emphasis border border-warning rounded-pill px-3 py-1 fw-semibold"><i class="fa-solid fa-person-walking-arrow-right me-1"></i> Leave</span>';
            } else {
                statusBadge = `<span class="badge bg-secondary rounded-pill px-3 py-1">${escapeHtml(capitalizeFirstLetter(s))}</span>`;
            }

            // Logged by
            const loggedBy = item.submitted_by_teacher ?
                `<i class="fas fa-chalkboard-user text-primary me-1"></i>${escapeHtml(item.submitted_by_teacher)}` :
                '<span class="badge bg-secondary-subtle text-secondary border px-2 py-1"><i class="fas fa-shield-halved me-1"></i>Admin</span>';

            // Class and section
            const classSection = `${escapeHtml(item.class_name || '-')}${item.section_name ? ' (' + escapeHtml(item.section_name) + ')' : ''}`;

            html += `
                <tr>
                    <td class="fw-bold">${formatDate(rawDate)}</td>
                    <td><span class="badge bg-light text-dark border">${dayName}</span></td>
                    <td class="text-muted"><i class="far fa-clock me-1"></i>${timeFormatted}</td>
                    <td>${statusBadge}</td>
                    <td>${loggedBy}</td>
                    <td>${classSection}</td>
                </tr>
            `;
        });

        tbody.html(html);
    }

    // --- Tab Hash Persistence ---
    function activateTabFromHash() {
        const hash = window.location.hash;
        if (hash) {
            const tabBtn = document.querySelector(`[data-bs-target="${hash}"]`);
            if (tabBtn) {
                new bootstrap.Tab(tabBtn).show();
            }
        }
    }

    // --- Document Ready ---
    $(document).ready(function() {

        // Initialize the Bootstrap Modal
        partialPaymentsModal = new bootstrap.Modal($('#partialPaymentsModal')[0]);

        // --- Initial Data Load ---
        loadStudentDetails();
        initAttendanceMonths();
        loadStudentAttendanceData();
        loadWalletData(1);
        loadFeePackage(1); // Load page 1 for all 5 fee tables
        loadPaymentHistory('monthly', 1); // Load page 1 for monthly history
        loadPaymentHistory('admission', 1); // Load page 1 for admission history

        // Tab hash persistence
        activateTabFromHash();
        document.querySelectorAll('#studentTabs button[data-bs-toggle="pill"]').forEach(tab => {
            tab.addEventListener('shown.bs.tab', function(e) {
                history.replaceState(null, null, e.target.dataset.bsTarget);
            });
        });

        // --- Event Listeners ---

        // Attendance Filter Events
        $('#attendanceMonthFilter').on('change', function() {
            loadStudentAttendanceData($(this).val());
        });

        $('#attendanceStatusFilterGroup button').on('click', function() {
            $('#attendanceStatusFilterGroup button').removeClass('active');
            $(this).addClass('active');
            currentAttendanceFilter = $(this).data('filter');
            renderAttendanceTable();
        });

        // 1. Pagination Click Handler (delegated)
        $(document).on('click', '.page-link', function(e) {
            e.preventDefault();
            const page = $(this).data('page');
            const type = $(this).data('type');

            // Ignore clicks on disabled links
            if ($(this).closest('.page-item').hasClass('disabled') || !page) {
                return;
            }

            switch (type) {
                case 'feePackage':
                    loadFeePackage(page);
                    break;
                case 'monthlyHistory':
                    loadPaymentHistory('monthly', page);
                    break;
                case 'admissionHistory':
                    loadPaymentHistory('admission', page);
                    break;
                case 'walletHistory': // Add this new case
                    loadWalletData(page);
                    break;
            }
        });

        // 2. View Partial Payments Modal Click Handler (delegated)
        $(document).on('click', '.view-partials', function() {
            // 'data-payments' attribute holds the JSON string.
            // .data() automatically parses it into an object.
            const payments = $(this).data('payments');
            buildPartialPaymentsModal(payments);
            partialPaymentsModal.show();
        });

    }); // End of $(document).ready()
</script>

<style>
    /* ============ PAGE BACKGROUND ============ */
    .student-profile-page {
        background: #f0f2f5;
        min-height: 100vh;
    }

    /* ============ HERO PROFILE CARD ============ */
    .student-hero-card {
        border-radius: 16px;
        background: linear-gradient(135deg, #1e3a5f 0%, #2d5f8a 50%, #3a7bd5 100%);
    }
    .hero-pill {
        background: rgba(255,255,255,0.18);
        color: #fff;
        border: 1px solid rgba(255,255,255,0.25);
        backdrop-filter: blur(4px);
        font-weight: 500;
    }
    .student-hero-photo-wrap {
        position: relative;
        display: inline-block;
    }
    .student-hero-photo {
        width: 110px;
        height: 110px;
        object-fit: cover;
        border-radius: 50%;
        border: 4px solid rgba(255,255,255,0.9);
        box-shadow: 0 4px 20px rgba(0,0,0,0.25);
        cursor: pointer;
        transition: transform 0.2s;
    }
    .student-hero-photo:hover {
        transform: scale(1.05);
    }
    .student-status-dot {
        position: absolute;
        bottom: 8px;
        right: 8px;
        width: 18px;
        height: 18px;
        border-radius: 50%;
        border: 3px solid #fff;
        box-shadow: 0 0 0 2px rgba(0,0,0,0.1);
    }
    .student-status-dot.active-dot {
        background-color: #22c55e;
    }
    .student-status-dot.inactive-dot {
        background-color: #ef4444;
    }

    /* ============ TAB NAVIGATION ============ */
    .student-nav-tabs {
        gap: 6px;
        padding-bottom: 2px;
        scrollbar-width: none;
    }
    .student-nav-tabs::-webkit-scrollbar {
        display: none;
    }
    .student-nav-tabs .nav-link {
        border-radius: 12px;
        padding: 10px 20px;
        font-weight: 600;
        font-size: 0.9rem;
        color: #475569;
        background: #fff;
        border: 1px solid #e2e8f0;
        white-space: nowrap;
        transition: all 0.25s ease;
        box-shadow: 0 1px 3px rgba(0,0,0,0.04);
    }
    .student-nav-tabs .nav-link:hover {
        color: #1e3a5f;
        background: #eef2ff;
        border-color: #c7d2fe;
    }
    .student-nav-tabs .nav-link.active {
        color: #fff;
        background: linear-gradient(135deg, #1e3a5f, #3a7bd5);
        border-color: transparent;
        box-shadow: 0 4px 12px rgba(30, 58, 95, 0.35);
    }

    /* ============ INFO CARD HEADERS ============ */
    .info-card-header {
        border-bottom: none;
        border-radius: 16px 16px 0 0;
        color: #fff;
    }
    .info-card-header h5 {
        color: #fff;
    }
    .info-card-header--blue {
        background: linear-gradient(135deg, #1e3a5f, #3a7bd5);
    }
    .info-card-header--rose {
        background: linear-gradient(135deg, #9b1b50, #e84393);
    }
    .info-card-header--green {
        background: linear-gradient(135deg, #166534, #22c55e);
    }
    .info-card-header--amber {
        background: linear-gradient(135deg, #92400e, #f59e0b);
    }

    /* ============ INFO SECTION CARDS ============ */
    .info-section-card {
        border-radius: 16px;
        transition: transform 0.2s ease;
        background: #fff;
    }
    .info-section-card:hover {
        transform: translateY(-2px);
    }

    /* ============ INFO GRID ============ */
    .info-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 14px 28px;
    }
    .info-item {
        display: flex;
        flex-direction: column;
        gap: 3px;
        padding: 6px 0;
        border-bottom: 1px solid #f1f5f9;
    }
    .info-item.full-width {
        grid-column: 1 / -1;
    }
    .info-item.full-width hr {
        border-color: #e2e8f0;
    }
    .info-label {
        font-size: 0.7rem;
        font-weight: 700;
        color: #64748b;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .info-label i {
        width: 14px;
        text-align: center;
    }
    .info-value {
        font-size: 0.95rem;
        font-weight: 600;
        color: #1e293b;
        word-break: break-word;
    }
    @media (max-width: 576px) {
        .info-grid {
            grid-template-columns: 1fr;
        }
    }

    /* ============ DOCUMENT GALLERY ============ */
    .doc-thumb-card {
        border-radius: 12px;
        transition: all 0.3s ease;
        cursor: pointer;
    }
    .doc-thumb-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.12) !important;
    }
    .doc-thumb-img-wrap {
        height: 160px;
        overflow: hidden;
        background: #f1f5f9;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .doc-thumb-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.3s ease;
    }
    .doc-thumb-card:hover .doc-thumb-img {
        transform: scale(1.05);
    }

    /* ============ DOWNLOAD CARDS ============ */
    .download-card {
        transition: all 0.3s ease;
        height: 100%;
    }
    .download-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.08) !important;
    }
    .download-card-icon {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    /* ============ FEE SUMMARY ICON ============ */
    .fee-summary-icon {
        width: 60px;
        height: 60px;
        min-width: 60px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    /* ============ ACCORDION ============ */
    .accordion-button:not(.collapsed) {
        box-shadow: none;
    }
    .accordion-button:focus {
        box-shadow: none;
    }

    /* ============ TABLE STYLING ============ */
    .table-hover tbody tr:hover {
        background-color: rgba(0, 123, 255, 0.05);
    }

    /* ============ SKELETON LOADER ============ */
    .placeholder {
        display: inline-block;
        min-height: 1em;
        vertical-align: middle;
        cursor: wait;
        background-color: currentColor;
        opacity: 0.15;
        border-radius: 4px;
    }

    /* ============ PRINT STYLES ============ */
    @media print {
        body {
            background: white;
            font-size: 12pt;
        }
        .student-profile-page {
            background: white !important;
            padding: 0 !important;
        }
        .student-hero-card {
            background: #f8f9fa !important;
        }
        .student-hero-card * {
            color: #000 !important;
        }
        .info-card-header {
            background: #e9ecef !important;
        }
        .info-card-header h5 {
            color: #000 !important;
        }
        .student-nav-tabs,
        .d-print-none {
            display: none !important;
        }
        .tab-pane {
            display: block !important;
            opacity: 1 !important;
        }
        .card {
            border: 1px solid #dee2e6 !important;
            box-shadow: none !important;
            break-inside: avoid;
        }
        .badge {
            color: white !important;
            border: 1px solid #000;
        }
        .student-hero-photo {
            border: 2px solid #dee2e6 !important;
            max-width: 100px !important;
            max-height: 100px !important;
        }
        .accordion-collapse {
            display: block !important;
        }
    }
</style>

<?php include_once("../../includes/body-close.php"); ?>