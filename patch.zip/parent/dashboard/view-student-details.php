<?php
include_once("../../includes/permission-check.php");
include_once("../../includes/header-open.php");
echo "<title>Student Dashboard - " . $school_name . "</title>";
include_once("../../includes/header-close.php");

// Validate student id from get request
if (!isset($_GET['student_id'])) {
    die("Student ID not provided.");
}

$student_id = $_GET['student_id'];

// ----------------------------Dashboard Access Permission Checking-----------------------------

// check admin permission + student permission
if (isLoggedIn()) { // check any admin logged in
    include_once("../../includes/dashboard-navbar.php");
    if (!hasPermission(PERM_MANAGE_EXAMS) && !hasPermission(PERM_MANAGE_STUDENTS) && !hasPermission(PERM_MANAGE_FEES)) {
        include_once("../../includes/permission-denied.php");
    }
} else {
    if (isParentAuthenticated()) {
        include_once("../../includes/parent-dashboard-navbar.php");
        if (!hasParentAccessPermission($student_id)) {
            include_once("../../includes/permission-denied.php");
        }
    } else {
        echo '<script>location.replace("/");</script>';
        exit;
    }
}

// --------------------------Student Details Section---------------------------------------------

// Get student details
$stmt = $pdo->prepare("
    SELECT students.*, 
           classes.class_name, 
           sections.section_name
    FROM students
    LEFT JOIN classes ON students.class_id = classes.id
    LEFT JOIN sections ON students.section_id = sections.id
    WHERE students.student_id = :student_id
");

$stmt->execute([':student_id' => $student_id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    die("Student not found.");
}
// --------------------------Fees Details Section-------------------------------------------------------

// Calculate totals
$lifetime_total_paid_amount = 0;
$lifetime_total_unpaid_amount = 0;

// -------------------------Monthly Fees Section--------------------------------------------------------

// Get monthly unpaid fees
$unpaid_monthly_stmt = $pdo->prepare("
    SELECT * FROM student_unpaid_fees 
    WHERE student_id = :student_id
    ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC
");
$unpaid_monthly_stmt->execute([':student_id' => $student_id]);
$unpaid_monthly_fees = $unpaid_monthly_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get monthly partial payments for unpaid fees
$partial_payments_for_unpaid_monthly_table = [];

foreach ($unpaid_monthly_fees as $unpaid_fee) {

    $lifetime_total_unpaid_amount += $unpaid_fee['unpaid_amount'];

    $stmt = $pdo->prepare("
        SELECT * FROM student_partial_payments 
        WHERE unpaid_fees_id = :unpaid_id
        ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC
    ");

    $stmt->execute([':unpaid_id' => $unpaid_fee['id']]);
    $partial_payments_for_unpaid_monthly_table[$unpaid_fee['id']] = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get monthly full paid fees
$paid_monthly_stmt = $pdo->prepare("
    SELECT * FROM student_full_paid_fees 
    WHERE student_id = :student_id
    ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC
");
$paid_monthly_stmt->execute([':student_id' => $student_id]);
$paid_monthly_fees = $paid_monthly_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get monthly partial payments for paid fees
$partial_payments_for_paid_monthly_table = [];

foreach ($paid_monthly_fees as $paid_fee) {
    $stmt = $pdo->prepare("
        SELECT * FROM student_partial_payments 
        WHERE full_paid_fees_id = ?
        ORDER BY STR_TO_DATE(CONCAT('01 ', month_year), '%d %M %Y') ASC
    ");
    $stmt->execute([$paid_fee['id']]);
    $partial_payments_for_paid_monthly_table[$paid_fee['id']] = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get total count of payment history records for pagination
$monthly_payment_history_count_stmt = $pdo->prepare("
    SELECT COUNT(*) as total 
    FROM student_payment_history 
    WHERE student_id = :student_id
");
$monthly_payment_history_count_stmt->execute([':student_id' => $student_id]);
$monthly_payment_history_count = $monthly_payment_history_count_stmt->fetch(PDO::FETCH_ASSOC)['total'];

// -------------------------Admission Fees Section------------------------------------------------------

// Get admission unpaid fees
$unpaid_admission_stmt = $pdo->prepare("
    SELECT * FROM admission_unpaid_fees 
    WHERE student_id = :student_id
    ORDER BY academic_year ASC
");
$unpaid_admission_stmt->execute([':student_id' => $student_id]);
$unpaid_admission_fees = $unpaid_admission_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get admission partial payments for unpaid fees
$partial_payments_for_unpaid_admission_table = [];

foreach ($unpaid_admission_fees as $unpaid_fee) {

    $lifetime_total_unpaid_amount += $unpaid_fee['unpaid_amount'];

    $stmt = $pdo->prepare("
        SELECT * FROM admission_partial_fees_payments 
        WHERE unpaid_admission_fees_id = :unpaid_id
        ORDER BY academic_year ASC
    ");

    $stmt->execute([':unpaid_id' => $unpaid_fee['id']]);
    $partial_payments_for_unpaid_admission_table[$unpaid_fee['id']] = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get admission full paid fees
$paid_admission_stmt = $pdo->prepare("
    SELECT * FROM admission_full_paid_fees 
    WHERE student_id = :student_id
    ORDER BY academic_year ASC
");
$paid_admission_stmt->execute([':student_id' => $student_id]);
$paid_admission_fees = $paid_admission_stmt->fetchAll(PDO::FETCH_ASSOC);

// Get admission partial payments for paid fees
$partial_payments_for_paid_admission_table = [];
foreach ($paid_admission_fees as $paid_fee) {
    $stmt = $pdo->prepare("
        SELECT * FROM admission_partial_fees_payments 
        WHERE full_paid_admission_fees_id = ?
        ORDER BY academic_year ASC
    ");
    $stmt->execute([$paid_fee['id']]);
    $partial_payments_for_paid_admission_table[$paid_fee['id']] = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get total count of admission payment history records for pagination
$admission_payment_history_count_stmt = $pdo->prepare("
    SELECT COUNT(*) as total 
    FROM admission_fees_payment_history 
    WHERE student_id = :student_id
");
$admission_payment_history_count_stmt->execute([':student_id' => $student_id]);
$admission_payment_history_count = $admission_payment_history_count_stmt->fetch(PDO::FETCH_ASSOC)['total'];

// --------------------------Additional Extra Fees Section-----------------------------------------------------
$unpaid_additional_fees_stmt = $pdo->prepare("
                                        SELECT COALESCE(SUM(cwaf.amount), 0) AS total_unpaid_amount
                                        FROM additional_fees_data AS afd
                                        LEFT JOIN class_wise_additional_fees AS cwaf 
                                        ON cwaf.id = afd.additional_fee_setup_id
                                        WHERE afd.student_id = ?
                                        AND afd.additional_fee_status = 'unpaid';
                                    ");
$unpaid_additional_fees_stmt->execute([$student_id]);
$unpaid_additional_fees = $unpaid_additional_fees_stmt->fetch(PDO::FETCH_ASSOC);

$lifetime_total_unpaid_amount += $unpaid_additional_fees['total_unpaid_amount'];

// --------------------------Calculations for download permissions---------------------------------------------

$all_fees_paid = ($lifetime_total_unpaid_amount <= 0);

// Get student permissions
$permissions_stmt = $pdo->prepare("
    SELECT 
        override_admit_check,
        allow_admit_card,
        override_marksheet_check,
        allow_marksheet
    FROM student_permissions
    WHERE student_id = :student_id
");
$permissions_stmt->execute([':student_id' => $student_id]);
$permissions = $permissions_stmt->fetch(PDO::FETCH_ASSOC);

// Determine download permissions
$can_download_admit = $all_fees_paid; // Default to fee status
$can_download_marksheet = $all_fees_paid; // Default to fee status

if ($permissions) {
    // Check admit card override
    if ($permissions['override_admit_check']) {
        $can_download_admit = $permissions['allow_admit_card'];
    }

    // Check marksheet override
    if ($permissions['override_marksheet_check']) {
        $can_download_marksheet = $permissions['allow_marksheet'];
    }
}

// ----------------------------Wallet Section------------------------------------------------------

// Get wallet balance
$wallet_stmt = $pdo->prepare("SELECT * FROM student_wallet WHERE student_id = :student_id");
$wallet_stmt->execute([':student_id' => $student_id]);
$wallet = $wallet_stmt->fetch(PDO::FETCH_ASSOC);
$wallet_balance = $wallet ? $wallet['balance'] : 0;

// Get wallet transactions
$wallet_trans_stmt = $pdo->prepare("
    SELECT * FROM wallet_transactions 
    WHERE student_id = :student_id
    ORDER BY created_at DESC
    LIMIT 10
");
$wallet_trans_stmt->execute([':student_id' => $student_id]);
$wallet_transactions = $wallet_trans_stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!-- ----------------------------End of PHP Logic & Start of HTML------------------------------------------------------ -->

<div class="container mt-5" id="student-report">
    <div class="card shadow mb-5">
        <!-- Student Header Section -->
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="mb-0"><i class="fas fa-user-graduate"></i> Student Profile</h3>
                <div class="d-print-none d-none">
                    <button onclick="window.print()" class="btn btn-light">
                        <i class="fas fa-print"></i> Print
                    </button>
                </div>
            </div>
        </div>


        <div class="card-body">
            <div class="row"> <!-- Student Information Section -->
                <!-- Student Photo Column -->
                <div class="col-md-3 text-center mb-4 mb-md-0">
                    <div class="student-photo-container">
                        <img src="../../uploads/students/<?= safe_htmlspecialchars($student['student_image']) ?>"
                            class="img-thumbnail rounded-circle shadow"
                            style="width: 200px; height: 200px; object-fit: cover;"
                            data-src="../../uploads/students/<?= safe_htmlspecialchars($student['student_image']) ?>"
                            data-fancybox=""
                            data-caption="<?= safe_htmlspecialchars($student['name']) ?>"
                            alt="Student Image">
                        <h4 class="mt-3"><?= safe_htmlspecialchars($student['name']) ?></h4>
                        <p class="text-muted">ID: <?= safe_htmlspecialchars($student['student_id']) ?></p>
                    </div>
                </div>

                <!-- Student Details Column -->
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="info-card mb-3">
                                <h5><i class="fas fa-id-card"></i> Basic Information</h5>
                                <hr>
                                <p><strong>Class:</strong> <?= safe_htmlspecialchars($student['class_name']) ?> - <?= safe_htmlspecialchars($student['section_name']) ?></p>
                                <p><strong>Roll No:</strong> <?= safe_htmlspecialchars($student['roll_no']) ?></p>
                                <p><strong>Admission Date:</strong> <?= safe_htmlspecialchars($student['admission_date']) ?></p>
                                <p><strong>Date of Birth:</strong> <?= safe_htmlspecialchars($student['date_of_birth']) ?></p>
                                <p><strong>Gender:</strong> <?= safe_htmlspecialchars($student['gender']) ?></p>
                                <p><strong>Blood Group:</strong> <?= safe_htmlspecialchars($student['blood_group']) ?></p>
                                <p><strong>Status:</strong> <span class="badge bg-<?= $student['status'] === 'Active' ? 'success' : 'danger' ?>"><?= safe_htmlspecialchars($student['status']) ?></span></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-card mb-3">
                                <h5><i class="fas fa-home"></i> Family Information</h5>
                                <hr>
                                <p><strong>Father's Name:</strong> <?= safe_htmlspecialchars($student['father_name']) ?></p>
                                <p><strong>Mother's Name:</strong> <?= safe_htmlspecialchars($student['mother_name']) ?></p>
                                <p><strong>Father's Occupation:</strong> <?= safe_htmlspecialchars($student['father_occupation']) ?></p>
                                <p><strong>Mother's Occupation:</strong> <?= safe_htmlspecialchars($student['mother_occupation']) ?></p>
                                <p><strong>Phone:</strong> <?= safe_htmlspecialchars($student['phone_number']) ?></p>
                                <p><strong>Alternate Phone:</strong> <?= safe_htmlspecialchars($student['alternate_phone_number']) ?></p>
                                <p><strong>Address:</strong> <?= safe_htmlspecialchars($student['address']) ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ----------------------------------------------------Fee Summary Section------------------------------------- -->
            <!-- Fee Summary Section -->
            <div class="card mb-4 border-0 shadow-sm">
                <div class="card-header bg-info text-white">
                    <i class="fas fa-money-bill-wave"></i> Fee Summary
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-md-6 mb-3 mb-md-0">
                            <div class="p-3 rounded bg-light">
                                <h5>Total Unpaid</h5>
                                <p class="fs-4 fw-bold text-danger">₹<?= number_format($lifetime_total_unpaid_amount, 2) ?></p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="p-3 rounded bg-light">
                                <h5>Wallet Balance</h5>
                                <p class="fs-4 fw-bold text-success">₹<?= number_format($wallet_balance, 2) ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- --------------------------------------------------- Wallet Transactions Section ------------------------------------- -->
            <!-- Wallet Transactions Section -->
            <?php if (!empty($wallet_transactions)): ?>
                <div class="card mb-4 border-0 shadow-sm">
                    <div class="card-header bg-secondary text-white">
                        <i class="fas fa-wallet"></i> Recent Wallet Transactions
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th>Date</th>
                                        <th>Type</th>
                                        <th>Amount</th>
                                        <th>Description</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($wallet_transactions as $transaction): ?>
                                        <tr>
                                            <td><?= date('d M Y h:i A', strtotime($transaction['created_at'])) ?></td>
                                            <td>
                                                <?php
                                                $type_class = '';
                                                $type_text = '';
                                                if ($transaction['transaction_type'] === 'deposit') {
                                                    $type_class = 'success';
                                                    $type_text = 'Deposit';
                                                } elseif ($transaction['transaction_type'] === 'deduct') {
                                                    $type_class = 'danger';
                                                    $type_text = 'Deduct';
                                                } else {
                                                    $type_class = 'info';
                                                    $type_text = ucfirst(str_replace('_', ' ', $transaction['transaction_type']));
                                                }
                                                ?>
                                                <span class="badge bg-<?= $type_class ?>"><?= $type_text ?></span>
                                            </td>
                                            <td class="<?= $transaction['transaction_type'] === 'deposit' ? 'text-success' : 'text-danger' ?>">
                                                <?= ($transaction['transaction_type'] === 'deposit' ? '+' : '-') ?>
                                                ₹<?= number_format($transaction['amount'], 2) ?>
                                            </td>
                                            <td><?= safe_htmlspecialchars($transaction['description']) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php if (count($wallet_transactions) >= 10): ?>
                            <div class="text-center mt-3">
                                <a href="wallet-transactions.php?student_id=<?= urlencode($student_id) ?>" class="btn btn-outline-secondary">
                                    View All Transactions
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- ------------------------------------------------------Download Section------------------------------------- -->
            <!-- Download Section -->
            <div class="card mb-4 border-0 shadow-sm">
                <div class="card-header bg-success text-white">
                    <i class="fas fa-download"></i> Download Documents
                </div>
                <div class="card-body">
                    <div class="row">
                        <!-- ID Card (Always available) -->
                        <div class="col-md-4 mb-3">
                            <div class="download-card p-3 text-center border rounded">
                                <i class="fas fa-id-card fa-3x text-primary mb-3"></i>
                                <h4>Student ID Card</h4>
                                <p>Download student's official ID card</p>
                                <a href="../../management/action/download/download-bulk-id-card.php?student_ids=<?= urlencode($student_id) ?>" class="btn btn-primary">
                                    <i class="fas fa-download"></i> Download ID Card
                                </a>
                            </div>
                        </div>

                        <?php if ($can_download_admit || $can_download_marksheet): ?>
                            <!-- Admit Card -->
                            <div class="col-md-4 mb-3">
                                <div class="download-card p-3 text-center border rounded">
                                    <i class="fas fa-id-card fa-3x text-warning mb-3"></i>
                                    <h4>Admit Card</h4>

                                    <?php if ($permissions && $permissions['override_admit_check'] && !$all_fees_paid): ?>
                                        <div class="alert alert-info p-2 mb-2">
                                            <small><i class="fas fa-info-circle"></i> Allowed by admin override</small>
                                        </div>
                                    <?php endif; ?>

                                    <?php if ($can_download_admit): ?>
                                        <p>Download student's examination admit card</p>
                                        <a href="student-admit-cards.php?student_id=<?= urlencode($student_id) ?>" class="btn btn-warning text-white">
                                            <i class="fas fa-download"></i> Download Admit
                                        </a>
                                    <?php else: ?>
                                        <p class="text-muted">Admit card not available</p>
                                        <button class="btn btn-warning text-white" disabled>
                                            <i class="fas fa-ban"></i> Not Available
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Marksheet -->
                            <div class="col-md-4">
                                <div class="download-card p-3 text-center border rounded">
                                    <i class="fas fa-file-alt fa-3x text-info mb-3"></i>
                                    <h4>Marksheet</h4>

                                    <?php if ($permissions && $permissions['override_marksheet_check'] && !$all_fees_paid): ?>
                                        <div class="alert alert-info p-2 mb-2">
                                            <small><i class="fas fa-info-circle"></i> Allowed by admin override</small>
                                        </div>
                                    <?php endif; ?>

                                    <?php if ($can_download_marksheet): ?>
                                        <p>Download student's examination marksheet</p>
                                        <a href="student-marksheets.php?student_id=<?= urlencode($student_id) ?>" class="btn btn-info text-white">
                                            <i class="fas fa-download"></i> Download Marksheet
                                        </a>
                                    <?php else: ?>
                                        <p class="text-muted">Marksheet not available</p>
                                        <button class="btn btn-info text-white" disabled>
                                            <i class="fas fa-ban"></i> Not Available
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php else: ?>
                            <!-- Fee Payment Reminder or Permission Info -->
                            <div class="col-md-8">
                                <div class="alert alert-warning h-100 d-flex align-items-center">
                                    <div>
                                        <i class="fas fa-exclamation-triangle fa-2x me-3"></i>
                                    </div>
                                    <div>
                                        <h5>Download Restrictions</h5>
                                        <p class="mb-0">
                                            <?php if (!$all_fees_paid): ?>
                                                All fees must be paid to download admit cards and marksheets.
                                            <?php endif; ?>
                                            <?php if ($permissions && $permissions['override_admit_check'] && !$permissions['allow_admit_card']): ?>
                                                <br>Admit card download has been specifically disabled by admin.
                                            <?php endif; ?>
                                            <?php if ($permissions && $permissions['override_marksheet_check'] && !$permissions['allow_marksheet']): ?>
                                                <br>Marksheet download has been specifically disabled by admin.
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- ---------------------------------------------History Additional Fees Section------------------------------------ -->

            <div class="card mb-4 border border-primary shadow-sm">
                <div class="card-header bg-primary text-white">
                    <i class="fas fa-history"></i> Additional Fees Information
                </div>
                <div class="card-body bg-info bg-opacity-10">
                    <div class="table-responsive">
                        <table class="table table-hover text-center align-middle" id="additionalFeesInfoTable">
                            <thead class="table-dark">
                                <tr>
                                    <th>Class</th>
                                    <th>Fee Type</th>
                                    <th>Amount</th>
                                    <th>Paid Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Data will be loaded via AJAX -->
                            </tbody>
                        </table>
                        <div id="additionalFeesInfoTablePagination" class="d-flex justify-content-center mt-3"></div>
                    </div>
                </div>
            </div>

            <!-- -----------------------------------------------History Monthly Fees Section------------------------------------- -->
            <div class="card mb-4 border border-primary shadow-sm">
                <div class="card-header bg-primary text-white">
                    <i class="fas fa-history"></i> Monthly Fees Payments History
                </div>
                <div class="card-body bg-info bg-opacity-10">
                    <div class="table-responsive">
                        <table class="table table-hover text-center align-middle" id="monthlyPaymentsHistoryTable">
                            <thead class="table-dark">
                                <tr>
                                    <th>Payment Date</th>
                                    <th>Amount</th>
                                    <th>Method</th>
                                    <th>Remark</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Data will be loaded via AJAX -->
                            </tbody>
                        </table>
                        <div id="monthlyPaymentHistoryPagination" class="d-flex justify-content-center mt-3"></div>
                    </div>
                </div>
            </div>

            <!-- -----------------------------------------------Monthly Unpaid Fees Section---------------------------------------- -->
            <div class="card mb-4 border border-danger shadow-sm">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-circle"></i> Monthly Unpaid Fees
                </div>
                <div class="card-body bg-danger bg-opacity-10">
                    <div class="table-responsive">
                        <table class="table table-hover text-center align-middle" id="unpaidMonthlyFeesTable">
                            <thead class="table-dark">
                                <tr>
                                    <th></th>
                                    <th>Month/Year</th>
                                    <th>Total Amount</th>
                                    <th>Offer Amount</th>
                                    <th>Discount</th>
                                    <th>Pending Amount</th>
                                    <th>Remark</th>
                                    <th class="d-print-none">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($unpaid_monthly_fees) > 0): ?>
                                    <?php foreach ($unpaid_monthly_fees as $unpaid_monthly_fee): ?>
                                        <tr class="bg-white">
                                            <td class="details-control"></td>
                                            <td><?= safe_htmlspecialchars($unpaid_monthly_fee['month_year']) ?></td>
                                            <td>₹<?= number_format($unpaid_monthly_fee['actual_amount'], 2) ?></td>
                                            <td class="text-danger fw-bold">₹<?= number_format($unpaid_monthly_fee['actual_amount'] - $unpaid_monthly_fee['discount_amount'], 2) ?></td>
                                            <td>₹<?= number_format($unpaid_monthly_fee['discount_amount'], 2) ?></td>
                                            <td class="text-danger fw-bold">₹<?= number_format($unpaid_monthly_fee['unpaid_amount'], 2) ?></td>
                                            <td width="20%"><?= safe_htmlspecialchars($unpaid_monthly_fee['remark']) ?></td>
                                            <td class="d-print-none">
                                                <a href="../ajax/pay-fee.php?id=<?= urlencode($unpaid_monthly_fee['id']) ?>&type=monthly-fee"
                                                    class="btn btn-sm btn-success">
                                                    <i class="fas fa-money-bill-wave"></i> Pay Now
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center text-muted py-4">
                                            <i class="fas fa-check-circle fa-2x mb-2"></i><br>
                                            No unpaid fees found for this student.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-----------------------------------------------Monthly Paid Fees Section ------------------------------->
            <div class="card mb-4 border border-success shadow-sm">
                <div class="card-header bg-success text-white">
                    <i class="fas fa-check-circle"></i> Monthly Paid Fees
                </div>
                <div class="card-body bg-success bg-opacity-10">
                    <div class="table-responsive">
                        <table class="table table-hover text-center align-middle" id="paidMonthlyFeesTable">
                            <thead class="table-dark">
                                <tr>
                                    <th></th>
                                    <th>Month/Year</th>
                                    <th>Total Amount</th>
                                    <th>Paid Amount</th>
                                    <th>Discount</th>
                                    <th>Remark</th>
                                    <th>Payment Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($paid_monthly_fees) > 0): ?>
                                    <?php foreach ($paid_monthly_fees as $paid_monthly_fee): ?>
                                        <tr class="bg-white">
                                            <td class="details-control"></td>
                                            <td><?= safe_htmlspecialchars($paid_monthly_fee['month_year']) ?></td>
                                            <td>₹<?= number_format($paid_monthly_fee['actual_amount'], 2) ?></td>
                                            <td class="text-success fw-bold">₹<?= number_format($paid_monthly_fee['total_paid_amount'], 2) ?></td>
                                            <td>₹<?= number_format($paid_monthly_fee['discount_amount'], 2) ?></td>
                                            <td width="20%"><?= safe_htmlspecialchars($paid_monthly_fee['remark']) ?></td>
                                            <td><?= date('d M Y', strtotime($paid_monthly_fee['created_at'])) ?></td>
                                            <td><button onclick="downloadReciept(<?= $paid_monthly_fee['id'] ?>)" class="btn btn-sm btn-primary"><i class="fas fa-file"></i> Reciept</button></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center text-muted py-4">
                                            <i class="fas fa-info-circle fa-2x mb-2"></i><br>
                                            No paid fees found for this student.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- -----------------------------------------------Admission Fees History Section------------------------------------- -->
            <div class="card mb-4 border border-primary shadow-sm">
                <div class="card-header bg-primary text-white">
                    <i class="fas fa-history"></i> Admission Fees Payments History
                </div>
                <div class="card-body bg-info bg-opacity-10">
                    <div class="table-responsive">
                        <table class="table table-hover text-center align-middle" id="admissionPaymentsHistoryTable">
                            <thead class="table-dark">
                                <tr>
                                    <th>Payment Date</th>
                                    <th>Amount</th>
                                    <th>Method</th>
                                    <th>Remark</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                        <div id="admissionPaymentHistoryPagination" class="d-flex justify-content-center mt-3"></div>
                    </div>
                </div>
            </div>

            <!-- -----------------------------------------------Admission Unpaid Fees Section------------------------------------- -->
            <div class="card mb-4 border border-danger shadow-sm">
                <div class="card-header bg-danger text-white">
                    <i class="fas fa-exclamation-circle"></i> Unpaid Admission Fees
                </div>
                <div class="card-body bg-danger bg-opacity-10">
                    <div class="table-responsive">
                        <table class="table table-hover text-center align-middle" id="unpaidAdmissionFeesTable">
                            <thead class="table-dark">
                                <tr>
                                    <th></th>
                                    <th>Academic Year</th>
                                    <th>Class</th>
                                    <th>Total Amount</th>
                                    <th>Offer Amount</th>
                                    <th>Discount</th>
                                    <th>Pending Amount</th>
                                    <th>Remark</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($unpaid_admission_fees) > 0): ?>
                                    <?php foreach ($unpaid_admission_fees as $unpaid_admission_fee): ?>
                                        <tr class="bg-white">
                                            <td class="details-control"></td>
                                            <td><?= safe_htmlspecialchars($unpaid_admission_fee['academic_year']) ?></td>
                                            <td><?= safe_htmlspecialchars(getClassNameById($pdo, $unpaid_admission_fee['class_id'])) ?></td>
                                            <td>₹<?= number_format($unpaid_admission_fee['actual_amount'], 2) ?></td>
                                            <td class="text-danger fw-bold">₹<?= number_format($unpaid_admission_fee['actual_amount'] - $unpaid_admission_fee['discount_amount'], 2) ?></td>
                                            <td>₹<?= number_format($unpaid_admission_fee['discount_amount'], 2) ?></td>
                                            <td class="text-danger fw-bold">₹<?= number_format($unpaid_admission_fee['unpaid_amount'], 2) ?></td>
                                            <td width="20%"><?= safe_htmlspecialchars($unpaid_admission_fee['remark']) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center text-muted py-4">
                                            <i class="fas fa-check-circle fa-2x mb-2"></i><br>
                                            No unpaid admission fees found for this student.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- -----------------------------------------------Admission Paid Fees Section------------------------------------- -->
            <div class="card mb-4 border border-success shadow-sm">
                <div class="card-header bg-success text-white">
                    <i class="fas fa-check-circle"></i> Paid Admission Fees
                </div>
                <div class="card-body bg-success bg-opacity-10">
                    <div class="table-responsive">
                        <table class="table table-hover text-center align-middle" id="paidAdmissionFeesTable">
                            <thead class="table-dark">
                                <tr>
                                    <th></th>
                                    <th>Academic Year</th>
                                    <th>Class</th>
                                    <th>Total Amount</th>
                                    <th>Paid Amount</th>
                                    <th>Discount</th>
                                    <th>Remark</th>
                                    <th>Payment Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($paid_admission_fees) > 0): ?>
                                    <?php foreach ($paid_admission_fees as $paid_admission_fee): ?>
                                        <tr class="bg-white">
                                            <td class="details-control"></td>
                                            <td><?= safe_htmlspecialchars($paid_admission_fee['academic_year']) ?></td>
                                            <td><?= safe_htmlspecialchars(getClassNameById($pdo, $paid_admission_fee['class_id'])) ?></td>
                                            <td>₹<?= number_format($paid_admission_fee['actual_amount'], 2) ?></td>
                                            <td class="text-success fw-bold">₹<?= number_format($paid_admission_fee['total_paid_amount'], 2) ?></td>
                                            <td>₹<?= number_format($paid_admission_fee['discount_amount'], 2) ?></td>
                                            <td width="20%"><?= safe_htmlspecialchars($paid_admission_fee['remark']) ?></td>
                                            <td><?= date('d M Y', strtotime($paid_admission_fee['created_at'])) ?></td>
                                            <td><button onclick="downloadAdmissionReciept(<?= $paid_admission_fee['id'] ?>)" class="btn btn-sm btn-primary"><i class="fas fa-file"></i> Receipt</button></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="9" class="text-center text-muted py-4">
                                            <i class="fas fa-info-circle fa-2x mb-2"></i><br>
                                            No paid admission fees found for this student.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- -----------------------------------------------End of Student's Sections------------------------------------- -->
        </div>
    </div>
</div>

<!-- -----------------------------------------------End of HTML Sections & Start of JavaScript Section------------------------------------- -->
<script>
    // --- Global Functions ---
    function downloadAdmissionReciept(paid_id) {
        window.open("../../api/download/download-admission-paid-receipt.php?id=" + paid_id, "_blank");
    }

    function downloadReciept(paid_id) {
        window.open("../../api/download/download-monthly-fee-paid-receipt.php?id=" + paid_id, "_blank");
    }

    // --- Helper Functions for formatting partial payments ---
    function formatPartialFeesPayments(d, partialPayments) {
        if (!partialPayments || partialPayments.length === 0) {
            return '<div class="p-3 bg-warning bg-opacity-10">No partial payments found.</div>';
        }

        let html = `
        <div class="p-3 border border-warning bg-warning bg-opacity-10">
            <h6 class="mb-3 text-start fw-bold"><i class="fas fa-receipt"></i> Partial Payment Details:</h6>
            <table class="table table-sm table-bordered mb-0 text-center align-middle">
                <thead class="table-dark">
                    <tr>
                        <th width="25%" class="text-center">Date</th>
                        <th width="25%" class="text-center">Partial Paid Amount</th>
                        <th width="20%" class="text-center">Method</th>
                        <th width="30%" class="text-center">Remark</th>
                    </tr>
                </thead>
                <tbody>`;

        partialPayments.forEach(payment => {
            html += `
            <tr>
                <td>${formatDateForDisplay(payment.created_at)}</td>
                <td class="text-success fw-bold">₹${parseFloat(payment.partial_paid_amount).toFixed(2)}</td>
                <td>${payment.method ? payment.method.charAt(0).toUpperCase() + payment.method.slice(1) : '-'}</td>
                <td>${escapeHtml(payment.remark || '-')}</td>
            </tr>`;
        });

        html += `</tbody></table></div>`;
        return html;
    }

    function formatDateForDisplay(dateString) {
        if (!dateString) return '-';
        const date = new Date(dateString);
        return date.toLocaleDateString('en-GB', {
            day: 'numeric',
            month: 'short',
            year: 'numeric'
        });
    }

    function escapeHtml(unsafe) {
        return unsafe.toString().replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }

    // --- AJAX Pagination Logic ---
    function setupAjaxPagination(options) {
        const {
            tableId,
            paginationId,
            ajaxUrl,
            studentId,
            totalItems,
            noDataMessage
        } = options;
        const perPage = 10;
        let currentPage = 1;

        function loadHistory(page) {
            $.ajax({
                url: ajaxUrl,
                type: 'GET',
                data: {
                    student_id: studentId,
                    page: page,
                    per_page: perPage
                },
                dataType: 'json',
                beforeSend: function() {
                    $(`${tableId} tbody`).html(`<tr><td colspan="4" class="text-center py-4"><div class="spinner-border text-primary"></div></td></tr>`);
                },
                success: function(response) {
                    if (response.success && response.data.length > 0) {
                        let html = '';
                        response.data.forEach(function(payment) {
                            html += `
                                    <tr>
                                        <td>${new Date(payment.payment_date + 'T00:00:00').toLocaleDateString('en-GB', {
                                                day: '2-digit',
                                                month: 'short',
                                                year: 'numeric'
                                            })}
                                        </td>
                                        <td class="text-success fw-bold">₹${parseFloat(payment.payment_amount).toFixed(2)}</td>
                                        <td class="text-capitalize">${payment.method || '-'}</td>
                                        <td>${payment.remark || '-'}</td>
                                    </tr>`;
                        });
                        $(`${tableId} tbody`).html(html);
                        renderPagination(response.current_page, response.total_pages);
                    } else {
                        $(`${tableId} tbody`).html(`<tr><td colspan="4" class="text-center text-muted py-4"><i class="fas fa-info-circle fa-2x mb-2"></i><br>${noDataMessage}</td></tr>`);
                        $(paginationId).empty();
                    }
                },
                error: function() {
                    $(`${tableId} tbody`).html(`<tr><td colspan="4" class="text-center text-danger py-4"><i class="fas fa-exclamation-triangle fa-2x mb-2"></i><br>Failed to load history.</td></tr>`);
                }
            });
        }

        function renderPagination(currentPage, totalPages) {
            let paginationHtml = '<nav><ul class="pagination justify-content-center">';
            paginationHtml += `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}"><a class="page-link" href="#" data-page="${currentPage - 1}">Previous</a></li>`;
            for (let i = 1; i <= totalPages; i++) {
                paginationHtml += `<li class="page-item ${i === currentPage ? 'active' : ''}"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
            }
            paginationHtml += `<li class="page-item ${currentPage === totalPages ? 'disabled' : ''}"><a class="page-link" href="#" data-page="${currentPage + 1}">Next</a></li>`;
            paginationHtml += '</ul></nav>';
            $(paginationId).html(paginationHtml);
        }

        $(document).on('click', `${paginationId} .page-link`, function(e) {
            e.preventDefault();
            const page = $(this).data('page');
            if (page && page !== currentPage) {
                currentPage = page;
                loadHistory(currentPage);
            }
        });

        if (totalItems > 0) {
            loadHistory(1);
        } else {
            $(`${tableId} tbody`).html(`<tr><td colspan="4" class="text-center text-muted py-4"><i class="fas fa-info-circle fa-2x mb-2"></i><br>${noDataMessage}</td></tr>`);
        }
    }

    // Function to render pagination
    function renderAdditionalFeesPagination(currentPage, totalPages, paginationId) {
        let paginationHtml = '<nav><ul class="pagination justify-content-center">';

        // Ensure values are numeric for comparison
        currentPage = Number(currentPage);
        totalPages = Number(totalPages);

        // Previous Button
        paginationHtml += `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
                               <a class="page-link" href="#" data-page="${currentPage - 1}">Previous</a>
                           </li>`;

        // Page Number Buttons
        for (let i = 1; i <= totalPages; i++) {
            paginationHtml += `<li class="page-item ${i === currentPage ? 'active' : ''}">
                                   <a class="page-link" href="#" data-page="${i}">${i}</a>
                               </li>`;
        }

        // Next Button
        paginationHtml += `<li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
                               <a class="page-link" href="#" data-page="${currentPage + 1}">Next</a>
                           </li>`;

        paginationHtml += '</ul></nav>';
        $(paginationId).html(paginationHtml);
    }

    // Function load additional fees data
    // Function load additional fees data
    function loadAdditionalFeesData(student_id, page = 1) { // <-- 1. Accept 'page' parameter, default to 1

        let table = $('#additionalFeesInfoTable');
        const perPage = 10; // You can control items per page here

        $.ajax({
            url: '../../api/parent/get/fees-x-payments/get-additional-fees-history.php',
            method: 'POST',
            dataType: 'json',
            data: {
                student_id: student_id,
                result_per_page: perPage, // <-- 2. Use perPage variable
                page: page // <-- 3. Pass the current page
            },
            beforeSend: function() {
                table.find('tbody').html(`<tr><td colspan="5" class="text-center py-4"><div class="spinner-border text-primary"></div></td></tr>`);
                $('#additionalFeesInfoTablePagination').empty(); // Clear old pagination
            },
            success: function(response) {
                if (response.success && response.data.length > 0) { // <-- 4. Check if data array has items
                    let html = '';
                    response.data.forEach(function(fee) {
                        html += `
                        <tr class="text-center align-middle">
                            <td>${fee.class_name}</td>
                            <td>${fee.fee_type}</td>
                            <td class="text-success fw-bold"><?= $currency_symbol ?>${fee.amount}</td>
                            <td>
                                <span class="badge ${
                                    fee.additional_fee_status == 'paid' 
                                        ? 'bg-success' 
                                        : 'bg-danger'
                                } text-capitalize">
                                    ${fee.additional_fee_status}
                                </span>
                            </td>
                            <td>${
                                fee.additional_fee_status == 'paid'
                                    ? (fee.additional_fee_paid_date || '-') // Add fallback
                                    : (fee.additional_fee_due_date || '-')  // Add fallback
                                }
                            </td>
                        </tr>
                        `;
                    });

                    table.find('tbody').html(html);

                    // 5. RENDER THE PAGINATION
                    renderAdditionalFeesPagination(
                        response.pagination.current_page,
                        response.pagination.total_pages,
                        '#additionalFeesInfoTablePagination' // The ID of your pagination container
                    );

                } else if (response.success && response.data.length === 0) {
                    // 6. Handle no data found
                    table.find('tbody').html(`<tr><td colspan="5" class="text-center text-muted py-4"><i class="fas fa-info-circle fa-2x mb-2"></i><br>No additional fees history found.</td></tr>`);
                    $('#additionalFeesInfoTablePagination').empty(); // Ensure no pagination is shown
                } else {
                    toastr.error(response.message);
                    table.find('tbody').html(`<tr><td colspan="5" class="text-center text-danger py-4"><i class="fas fa-info-circle fa-2x mb-2"></i><br>${response.message}</td></tr>`);
                    $('#additionalFeesInfoTablePagination').empty();
                }
            },
            error: function(xhr) {
                toastr.error('Error fetching additional fees data');
                table.find('tbody').html(`<tr><td colspan="5" class="text-center text-danger py-4"><i class="fas fa-info-circle fa-2x mb-2"></i><br>Error fetching additional fees data.</td></tr>`);
                $('#additionalFeesInfoTablePagination').empty();
                console.error(xhr.responseText);
            }
        });
    }

    // This is the single, consolidated ready function
    $(document).ready(function() {

        // --- Data Presence Checks ---
        const hasUnpaidMonthlyData = <?= count($unpaid_monthly_fees) > 0 ? 'true' : 'false' ?>;
        const hasPaidMonthlyData = <?= count($paid_monthly_fees) > 0 ? 'true' : 'false' ?>;
        const hasUnpaidAdmissionData = <?= count($unpaid_admission_fees) > 0 ? 'true' : 'false' ?>;
        const hasPaidAdmissionData = <?= count($paid_admission_fees) > 0 ? 'true' : 'false' ?>;

        let unpaidMonthlyTable, paidMonthlyTable, unpaidAdmissionTable, paidAdmissionTable;

        // --- Initialize DataTables ---
        if (hasUnpaidMonthlyData) {
            unpaidMonthlyTable = $('#unpaidMonthlyFeesTable').DataTable({
                responsive: true,
                columnDefs: [{
                        orderable: false,
                        targets: [0, 7]
                    },
                    {
                        className: "dt-center",
                        targets: "_all"
                    }
                ]
            });
        }
        if (hasPaidMonthlyData) {
            paidMonthlyTable = $('#paidMonthlyFeesTable').DataTable({
                responsive: true,
                columnDefs: [{
                        orderable: false,
                        targets: [0, 7]
                    },
                    {
                        className: "dt-center",
                        targets: "_all"
                    }
                ]
            });
        }
        if (hasUnpaidAdmissionData) {
            unpaidAdmissionTable = $('#unpaidAdmissionFeesTable').DataTable({
                responsive: true,
                columnDefs: [{
                        orderable: false,
                        targets: [0, 7]
                    },
                    {
                        className: "dt-center",
                        targets: "_all"
                    }
                ]
            });
        }
        if (hasPaidAdmissionData) {
            paidAdmissionTable = $('#paidAdmissionFeesTable').DataTable({
                responsive: true,
                columnDefs: [{
                        orderable: false,
                        targets: [0, 7]
                    },
                    {
                        className: "dt-center",
                        targets: "_all"
                    }
                ]
            });
        }

        // --- Event Listeners for Details Control ---
        if (hasUnpaidMonthlyData && unpaidMonthlyTable) {
            $('#unpaidMonthlyFeesTable tbody').on('click', 'td.details-control', function() {
                const tr = $(this).closest('tr');
                const row = unpaidMonthlyTable.row(tr);
                const monthYear = row.data()[1];
                if (row.child.isShown()) {
                    row.child.hide();
                    tr.removeClass('shown');
                } else {
                    const fee = <?= json_encode($unpaid_monthly_fees) ?>.find(f => f.month_year == monthYear);
                    const partialPayments = fee ? <?= json_encode($partial_payments_for_unpaid_monthly_table) ?>[fee.id] || [] : [];
                    row.child(formatPartialFeesPayments(row.data(), partialPayments)).show();
                    tr.addClass('shown');
                }
            });
        }
        if (hasPaidMonthlyData && paidMonthlyTable) {
            $('#paidMonthlyFeesTable tbody').on('click', 'td.details-control', function() {
                const tr = $(this).closest('tr');
                const row = paidMonthlyTable.row(tr);
                const monthYear = row.data()[1];
                if (row.child.isShown()) {
                    row.child.hide();
                    tr.removeClass('shown');
                } else {
                    const fee = <?= json_encode($paid_monthly_fees) ?>.find(f => f.month_year == monthYear);
                    const partialPayments = fee ? <?= json_encode($partial_payments_for_paid_monthly_table) ?>[fee.id] || [] : [];
                    row.child(formatPartialFeesPayments(row.data(), partialPayments)).show();
                    tr.addClass('shown');
                }
            });
        }
        if (hasUnpaidAdmissionData && unpaidAdmissionTable) {
            $('#unpaidAdmissionFeesTable tbody').on('click', 'td.details-control', function() {
                const tr = $(this).closest('tr');
                const row = unpaidAdmissionTable.row(tr);
                const academicYear = row.data()[1];
                if (row.child.isShown()) {
                    row.child.hide();
                    tr.removeClass('shown');
                } else {
                    const fee = <?= json_encode($unpaid_admission_fees) ?>.find(f => f.academic_year == academicYear);
                    const partialPayments = fee ? <?= json_encode($partial_payments_for_unpaid_admission_table) ?>[fee.id] || [] : [];
                    console.log(partialPayments); // Here is the partialPayments data is empty but why?
                    row.child(formatPartialFeesPayments(row.data(), partialPayments)).show();
                    tr.addClass('shown');
                }
            });
        }
        if (hasPaidAdmissionData && paidAdmissionTable) {
            $('#paidAdmissionFeesTable tbody').on('click', 'td.details-control', function() {
                const tr = $(this).closest('tr');
                const row = paidAdmissionTable.row(tr);
                const academicYear = row.data()[1];
                if (row.child.isShown()) {
                    row.child.hide();
                    tr.removeClass('shown');
                } else {
                    const fee = <?= json_encode($paid_admission_fees) ?>.find(f => f.academic_year == academicYear);
                    const partialPayments = fee ? <?= json_encode($partial_payments_for_paid_admission_table) ?>[fee.id] || [] : [];
                    row.child(formatPartialFeesPayments(row.data(), partialPayments)).show();
                    tr.addClass('shown');
                }
            });
        }

        const studentId = '<?= $student_id ?>';

        // Setup for Monthly Fee History
        setupAjaxPagination({
            tableId: '#monthlyPaymentsHistoryTable',
            paginationId: '#monthlyPaymentHistoryPagination',
            ajaxUrl: '../../management/ajax/get-monthly-payment-history.php',
            studentId: studentId,
            totalItems: <?= $monthly_payment_history_count ?>,
            noDataMessage: 'No monthly payment history found.'
        });

        // Setup for Admission Fee History
        setupAjaxPagination({
            tableId: '#admissionPaymentsHistoryTable',
            paginationId: '#admissionPaymentHistoryPagination',
            ajaxUrl: '../../management/ajax/get-admission-payment-history.php',
            studentId: studentId,
            totalItems: <?= $admission_payment_history_count ?>,
            noDataMessage: 'No admission payment history found.'
        });

        // Click listener for Additional Fees pagination
        $(document).on('click', '#additionalFeesInfoTablePagination .page-link', function(e) {
            e.preventDefault();
            const page = $(this).data('page');
            
            // Check if page is a valid number (prevents clicking disabled 'Previous' at page 1)
            if (page && Number.isInteger(page) && page > 0) {
                loadAdditionalFeesData(studentId, page);
            }
        });

        // Load initial additional fees data
        loadAdditionalFeesData(studentId, 1);

    }); // End of the single $(document).ready() function
</script>

<!-- -----------------------------------------------End of JavaScript Section & Start of CSS Section------------------------------------- -->
<style>
    @media print {
        body {
            background: white;
            font-size: 12pt;
        }

        .card {
            border: none !important;
            box-shadow: none !important;
        }

        .d-print-none {
            display: none !important;
        }

        .badge {
            color: white !important;
            border: 1px solid #000;
        }

        .student-photo-container {
            text-align: left !important;
            margin-bottom: 20px;
        }

        .img-thumbnail {
            border: none !important;
            max-width: 150px !important;
            max-height: 150px !important;
        }
    }

    .info-card {
        background-color: #f8f9fa;
        border-radius: 8px;
        padding: 15px;
        height: 100%;
    }

    .download-card {
        transition: all 0.3s ease;
        height: 100%;
    }

    .download-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    .student-photo-container {
        position: relative;
    }

    .student-photo-container h4 {
        color: #333;
        font-weight: 600;
    }

    .table-hover tbody tr:hover {
        background-color: rgba(0, 123, 255, 0.05);
    }

    td.details-control {
        background: url('https://www.datatables.net/examples/resources/details_open.png') no-repeat center center;
        cursor: pointer;
    }

    tr.shown td.details-control {
        background: url('https://www.datatables.net/examples/resources/details_close.png') no-repeat center center;
    }

    .dataTables_wrapper .dataTables_info {
        padding-top: 1em !important;
    }

    .pagination {
        flex-wrap: wrap;
        justify-content: center;
    }
</style>

<?php include_once("../../includes/body-close.php"); ?>