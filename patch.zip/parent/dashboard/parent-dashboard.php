<?php
include_once __DIR__ . "/../../includes/parent/parent-auth-check.php";
$authData = authenticateWebPageRequest($pdo);
$parent_phone = $authData['phone_number'];

include_once("../../includes/header-open.php");
echo "<title>Parent Dashboard - " . $school_name . "</title>";
include_once("../../includes/header-close.php");
include_once("../../includes/parent/parent-dashboard-navbar.php");

// Get all students associated with this parent
$stmt = $pdo->prepare('
    SELECT s.*, c.class_name, sec.section_name 
    FROM students s
    LEFT JOIN classes c ON s.class_id = c.id
    LEFT JOIN sections sec ON s.section_id = sec.id
    WHERE s.phone_number = ? 
    ORDER BY c.id, sec.id, s.roll_no
');
$stmt->execute([$parent_phone]);
$students = $stmt->fetchAll();
?>

<div class="container py-4">
    <h2 class="mb-4 text-center">My Children</h2>

    <?php if (empty($students)): ?>
        <div class="alert alert-info">
            No students found associated with your account.
        </div>
    <?php else: ?>
        <div class="row">
            <?php foreach ($students as $student): ?>
                <div class="col-md-6 mb-4">
                    <div class="card h-100 border-0 shadow-lg">
                        <div class="card-header bg-gradient-primary text-white d-flex justify-content-between align-items-center py-3">
                            <div>
                                <h5 class="mb-0 font-weight-bold"><?= safe_htmlspecialchars($student['name']) ?></h5>
                                <small class="d-block opacity-75"><?= safe_htmlspecialchars($student['class_name'] ?? 'N/A') ?> - <?= safe_htmlspecialchars($student['section_name'] ?? 'N/A') ?></small>
                            </div>
                            <?php if (!empty($student['student_image']) && $student['student_image'] != 'default_student_dp.jpg'): ?>
                                <a href="../../uploads/students/<?= safe_htmlspecialchars($student['student_image']) ?>" data-fancybox="student-gallery" data-caption="<?= safe_htmlspecialchars($student['name']) ?>">
                                    <img src="../../uploads/students/<?= safe_htmlspecialchars($student['student_image']) ?>"
                                        class="rounded-circle shadow-sm"
                                        style="width: 60px; height: 60px; object-fit: cover; border: 3px solid rgba(255,255,255,0.3)"
                                        alt="Student Image">
                                </a>
                            <?php endif; ?>
                        </div>

                        <div class="card-body py-3">
                            <div class="student-details">

                                <div class="row">
                                    <div class="detail-item d-flex mb-3 col-6">
                                        <div class="icon mr-2 text-primary">
                                            <i class="fas fa-id-card"></i>
                                        </div>
                                        <div>
                                            <small class="text-muted d-block">Student ID</small>
                                            <strong><?= safe_htmlspecialchars($student['student_id']) ?></strong>
                                        </div>
                                    </div>

                                    <div class="detail-item d-flex mb-3 col-6">
                                        <div class="icon mr-2 text-primary">
                                            <i class="fas fa-sort-numeric-up"></i>
                                        </div>
                                        <div>
                                            <small class="text-muted d-block">Roll No</small>
                                            <strong><?= safe_htmlspecialchars($student['roll_no'] ?? 'N/A') ?></strong>
                                        </div>
                                    </div>
                                </div>


                                <div class="row">
                                    <div class="col-6">
                                        <div class="detail-item d-flex mb-3">
                                            <div class="icon mr-2 text-primary">
                                                <i class="fas fa-male"></i>
                                            </div>
                                            <div>
                                                <small class="text-muted d-block">Father</small>
                                                <strong><?= safe_htmlspecialchars($student['father_name'] ?? 'N/A') ?></strong>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="detail-item d-flex mb-3">
                                            <div class="icon mr-2 text-primary">
                                                <i class="fas fa-female"></i>
                                            </div>
                                            <div>
                                                <small class="text-muted d-block">Mother</small>
                                                <strong><?= safe_htmlspecialchars($student['mother_name'] ?? 'N/A') ?></strong>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="detail-item d-flex mb-3 col-6">
                                        <div class="icon mr-2 text-primary">
                                            <i class="fas fa-birthday-cake"></i>
                                        </div>
                                        <div>
                                            <small class="text-muted d-block">Date of Birth</small>
                                            <strong><?= !empty($student['date_of_birth']) ? date('d M, Y', strtotime($student['date_of_birth'])) : 'N/A' ?></strong>
                                        </div>
                                    </div>
                                    <div class="detail-item d-flex mb-3 col-6">
                                        <div class="icon mr-2 text-primary">
                                            <i class="fas fa-phone"></i>
                                        </div>
                                        <div>
                                            <small class="text-muted d-block">Phone</small>
                                            <strong><?= $parent_phone ?></strong>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="detail-item d-flex mb-3 col-6">
                                        <div class="icon mr-2 text-primary">
                                            <i class="fa-solid fa-venus-mars"></i>
                                        </div>
                                        <div>
                                            <small class="text-muted d-block">Gender</small>
                                            <strong><?= !empty($student['gender']) ? safe_htmlspecialchars($student['gender']) : 'N/A' ?></strong>
                                        </div>
                                    </div>
                                    <div class="detail-item d-flex mb-3 col-6">
                                        <div class="icon mr-2 text-primary">
                                            <i class="fa-solid fa-hand-holding-droplet"></i>
                                        </div>
                                        <div>
                                            <small class="text-muted d-block">Blood Group</small>
                                            <strong><?= !empty($student['blood_group']) ? safe_htmlspecialchars($student['blood_group']) : 'N/A' ?></strong>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="detail-item d-flex mb-3 col-12">
                                        <div class="icon mr-2 text-primary">
                                            <i class="fa-solid fa-location-dot"></i>
                                        </div>
                                        <div>
                                            <small class="text-muted d-block">Address</small>
                                            <strong><?= !empty($student['address']) ? safe_htmlspecialchars($student['address']) : 'N/A' ?></strong>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card-footer bg-white border-top-0 pt-0 pb-3">
                            <a href="student-details.php?student_id=<?= $student['student_id'] ?>"
                                class="btn btn-primary btn-block rounded-pill py-2">
                                <i class="fas fa-user-circle mr-2"></i> View Full Profile
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<style>
    .card {
        transition: all 0.3s ease;
        border-radius: 15px;
        overflow: hidden;
    }

    .card:hover {
        transform: translateY(-8px);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
    }

    .bg-gradient-primary {
        background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-color) 100%);
        /* background: linear-gradient(90deg, var(--primary-dark) 0%, var(--primary-color) 43%, var(--primary-light) 100%); */
    }

    .detail-item .icon {
        width: 24px;
        text-align: center;
    }

    .card-header {
        border-bottom: 1px solid rgba(255, 255, 255, 0.2);
    }
</style>

<script>
    $(document).ready(function() {
        // Initialize fancybox
        $("[data-fancybox]").fancybox({
            buttons: [
                "zoom",
                "close"
            ],
            animationEffect: "fade",
            transitionEffect: "slide",
        });
    });
</script>

<?php include '../../includes/body-close.php'; ?>