<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(['success' => false, 'message' => 'Invalid request method']));
}

$phone = sanitize_input($_POST['phone']);
$otp = sanitize_input($_POST['otp']);
$purpose = sanitize_input($_POST['purpose']);

// Validate inputs
if (empty($phone) || empty($otp) || empty($purpose)) {
    die(json_encode(['success' => false, 'message' => 'All fields are required']));
}

// Verify OTP
$stmt = $pdo->prepare("SELECT * FROM otp_verification WHERE phone_number = ? AND otp = ? AND purpose = ? AND expiry > NOW() AND verified = 0");
$stmt->execute([$phone, $otp, $purpose]);
$otpRecord = $stmt->fetch();

if (!$otpRecord) {
    die(json_encode(['success' => false, 'message' => 'Invalid or expired OTP']));
}

// Mark OTP as verified
$stmt = $pdo->prepare("UPDATE otp_verification SET verified = 1 WHERE id = ?");
$stmt->execute([$otpRecord['id']]);

if ($purpose === 'signup') {
    // Complete parent signup
    // Get the password from session or you might need to store it temporarily in the database
    // For this example, we'll assume it's passed along (in a real app, you'd need a more secure approach)
    $password = $_POST['password'] ?? '';
    
    if (empty($password)) {
        die(json_encode(['success' => false, 'message' => 'Password is required']));
    }
    
    // Hash the password
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    
    // Get student IDs associated with this phone number
    $stmt = $pdo->prepare("SELECT student_id FROM students WHERE phone_number = ?");
    $stmt->execute([$phone]);
    $students = $stmt->fetchAll();
    $studentIds = implode(',', array_column($students, 'student_id'));
    
    // Create parent account
    $stmt = $pdo->prepare("INSERT INTO parent_accounts (phone_number, password_hash, student_ids) VALUES (?, ?, ?)");
    $stmt->execute([$phone, $passwordHash, $studentIds]);
    
    // Log the parent in
    $_SESSION['parent_logged_in'] = true;
    $_SESSION['parent_phone'] = $phone;
    
    echo json_encode(['success' => true, 'message' => 'Account created successfully!']);
} else {
    // For password reset, just return success - the actual password reset happens in reset-password.php
    echo json_encode(['success' => true, 'message' => 'OTP verified successfully']);
}