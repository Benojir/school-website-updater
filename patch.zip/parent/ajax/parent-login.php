<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';

define('REMEMBER_ME_DAYS', 30);

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(['success' => false, 'message' => 'Invalid request method']));
}

$phone = sanitize_input($_POST['phone']);
$password = $_POST['password'];
$rememberMe = isset($_POST['remember_me']) ? true : false;

// Validate inputs
if (empty($phone) || empty($password)) {
    die(json_encode(['success' => false, 'message' => 'Phone number and password are required']));
}

// Check invalid phone number
if (!isValidPhoneNumber($phone)) {
    die(json_encode(['success' => false, 'message' => 'Phone number is invalid. Do not add country code.']));
}

// Check if parent exists
$stmt = $pdo->prepare("SELECT * FROM parent_accounts WHERE phone_number = ?");
$stmt->execute([$phone]);
$parent = $stmt->fetch();

if (!$parent) {
    die(json_encode(['success' => false, 'message' => 'Invalid phone number or password']));
}

// Verify password
if (!password_verify($password, $parent['password_hash'])) {
    die(json_encode(['success' => false, 'message' => 'Invalid phone number or password']));
}

// Login successful
$_SESSION['parent_logged_in'] = true;
$_SESSION['parent_phone'] = $parent['phone_number'];

// Set remember me cookie if requested
if ($rememberMe) {
    $token = generateToken();
    $expiry = date('Y-m-d H:i:s', strtotime('+' . REMEMBER_ME_DAYS . ' days'));
    
    $stmt = $pdo->prepare("UPDATE parent_accounts SET remember_token = ?, token_expiry = ? WHERE phone_number = ?");
    $stmt->execute([$token, $expiry, $phone]);
    
    setcookie('parent_remember_token', $token, [
        'expires' => time() + (86400 * REMEMBER_ME_DAYS),
        'path' => '/',
        'secure' => true,
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
}

echo json_encode(['success' => true, 'message' => 'Login successful']);