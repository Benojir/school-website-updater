<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(['success' => false, 'message' => 'Invalid request method']));
}

$phone = sanitize_input($_POST['phone']);
$password = $_POST['password'];
$otp = sanitize_input($_POST['otp']);

// Validate inputs
if (empty($phone) || empty($password) || empty($otp)) {
    die(json_encode(['success' => false, 'message' => 'All fields are required']));
}

// Check password length
if (strlen($password) < 6) {
    die(json_encode(['success' => false, 'message' => 'Password lenth minimum 6 characters required.']));
}

// Verify OTP
$stmt = $pdo->prepare("SELECT * FROM otp_verification WHERE phone_number = ? AND otp = ? AND purpose = 'password_reset' AND expiry > NOW() AND verified = 0");
$stmt->execute([$phone, $otp]);
$otpRecord = $stmt->fetch();

if (!$otpRecord) {
    die(json_encode(['success' => false, 'message' => 'Invalid or expired OTP']));
}

// Mark OTP as verified
$stmt = $pdo->prepare("UPDATE otp_verification SET verified = 1 WHERE id = ?");
$stmt->execute([$otpRecord['id']]);

// Update password
$passwordHash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $pdo->prepare("UPDATE parent_accounts SET password_hash = ? WHERE phone_number = ?");
$stmt->execute([$passwordHash, $phone]);

echo json_encode(['success' => true, 'message' => 'Password reset successfully']);