<?php
header('Location: auth');