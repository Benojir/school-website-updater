<?php
header('Location: login');