<?php
header('Location: auth');