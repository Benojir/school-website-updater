<?php 
include_once __DIR__ . "/../../includes/parent/auth/parent-auth-check.php";
include_once __DIR__ . "/../../includes/header-open.php"; 
echo "<title>Parent Login - $school_name</title>";
include_once __DIR__ . "/../../includes/header-close.php";

$authData = getAuthenticatedParent($pdo);

if ($authData) {
    echo '<script>location.replace("../dashboard/parent-dashboard.php");</script>';
    exit;
}
?>

<style>
    .adjust-height {
        height: 3rem;
    }
</style>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-6">
            <div class="card shadow">
                <div class="card-header bg-primary py-3 text-white">
                    <h4 class="mb-0 text-center"><i class="fa-solid fa-user-lock"></i> Parent Portal</h4>
                </div>
                <div class="card-body">
                    <!-- Login Form -->
                    <div id="loginForm">
                        <h5 class="text-center mb-4">Login to Your Account</h5>
                        <form id="parentLoginForm" autocomplete="off">
                            <div class="mb-3">
                                <label for="loginPhone" class="form-label">Registered Phone Number</label>
                                <div class="input-group">
                                    <span class="input-group-text px-3"><i class="fa-solid fa-phone-flip"></i></span>
                                    <input type="text" class="form-control adjust-height" id="loginPhone" name="phone" placeholder="Enter phone number" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="loginPassword" class="form-label">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text px-3"><i class="fa-solid fa-lock"></i></span>
                                    <input type="password" class="form-control adjust-height" id="loginPassword" name="password" placeholder="Enter password" required>
                                </div>
                            </div>
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="rememberMe" name="remember_me">
                                <label class="form-check-label" for="rememberMe">Remember Me</label>
                            </div>
                            <button type="submit" class="btn btn-primary w-100 adjust-height">Login</button>
                        </form>
                        <div class="mt-3 text-center">
                            <a href="#" id="showSignup" class="text-decoration-none">Create new account</a> |
                            <a href="forgot-password.php" class="text-decoration-none">Forgot password?</a>
                        </div>
                    </div>

                    <!-- Signup Form (hidden by default) -->
                    <div id="signupForm" style="display: none;">
                        <h5 class="text-center mb-4">Create New Account</h5>
                        <form id="parentSignupForm" autocomplete="off">
                            <div class="mb-3">
                                <label for="signupPhone" class="form-label">Registered Phone Number</label>
                                <div class="input-group">
                                    <span class="input-group-text px-3"><i class="fa-solid fa-phone-flip"></i></span>
                                    <input type="text" class="form-control adjust-height" id="signupPhone" name="phone" placeholder="Enter phone number" required>
                                </div>
                                <small class="text-muted">Must match the phone number registered with student records</small>
                            </div>
                            <div class="mb-3">
                                <label for="signupPassword" class="form-label">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text px-3"><i class="fa-solid fa-lock"></i></span>
                                    <input type="password" class="form-control adjust-height" id="signupPassword" name="password" placeholder="Enter new password" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="signupConfirmPassword" class="form-label">Confirm Password</label>
                                <div class="input-group">
                                    <span class="input-group-text px-3"><i class="fa-solid fa-lock"></i></span>
                                    <input type="password" class="form-control adjust-height" id="signupConfirmPassword" name="confirm_password" placeholder="Enter confirm password" required>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary w-100 adjust-height">Send OTP</button>
                        </form>
                        <div class="mt-3 text-center">
                            <a href="#" id="showLogin" class="text-decoration-none">Back to Login</a>
                        </div>
                    </div>

                    <!-- OTP Verification Form (hidden by default) -->
                    <div id="otpVerificationForm" style="display: none;">
                        <h5 class="text-center mb-4">Verify OTP</h5>
                        <p class="text-center">We've sent an OTP to <span id="otpPhoneDisplay"></span></p>
                        <form id="verifyOtpForm" autocomplete="off">
                            <input type="hidden" id="verificationPhone" name="phone">
                            <input type="hidden" id="verificationPurpose" name="purpose">
                            <input type="hidden" id="verificationPassword" name="password">
                            <div class="mb-3">
                                <label for="otpCode" class="form-label">Enter OTP</label>
                                <div class="input-group">
                                    <span class="input-group-text px-3"><i class="fa-solid fa-mobile-screen"></i></span>
                                    <input type="text" class="form-control adjust-height" id="otpCode" name="otp" required maxlength="6">
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary w-100 adjust-height">Verify & Complete</button>
                        </form>
                        <div class="mt-3 text-center">
                            <a href="#" id="resendOtp" class="text-decoration-none">Resend OTP</a> |
                            <a href="#" id="cancelVerification" class="text-decoration-none">Cancel</a>
                        </div>
                    </div>

                    <div class="d-flex justify-content-center">
                        <a href="/" class="text-decoration-none mt-3">
                            <button class="btn btn-sm btn-primary"><i class="fa-solid fa-arrow-left"></i> Back to Home</button>
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Toggle between login and signup forms
        $('#showSignup').click(function(e) {
            e.preventDefault();
            $('#loginForm').hide();
            $('#signupForm').show();
        });

        $('#showLogin').click(function(e) {
            e.preventDefault();
            $('#signupForm').hide();
            $('#otpVerificationForm').hide();
            $('#loginForm').show();
        });

        // Cancel verification
        $('#cancelVerification').click(function(e) {
            e.preventDefault();
            $('#otpVerificationForm').hide();
            if ($('#verificationPurpose').val() === 'signup') {
                $('#signupForm').show();
            } else {
                $('#loginForm').show();
            }
        });

        // Parent Login Form Submission
        $('#parentLoginForm').submit(function(e) {
            e.preventDefault();
            const formData = $(this).serialize();

            $.ajax({
                url: '../../api/parent/auth/web-login.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                beforeSend: function() {
                    $('button[type="submit"]').prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Loading...');
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        setTimeout(() => {
                            window.location.href = '../dashboard/parent-dashboard.php';
                        }, 1000);
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred. Please try again.');
                },
                complete: function() {
                    $('button[type="submit"]').prop('disabled', false).text('Login');
                }
            });
        });

        // Resend OTP cooldown timer
        let resendCooldown = false;
        let cooldownInterval;

        function startResendCooldown() {
            resendCooldown = true;
            let seconds = 120; // 2 minutes = 120 seconds
            $('#resendOtp').addClass('text-muted').css('pointer-events', 'none');

            cooldownInterval = setInterval(function() {
                seconds--;
                $('#resendOtp').text(`Resend OTP (${seconds}s)`);

                if (seconds <= 0) {
                    clearInterval(cooldownInterval);
                    resendCooldown = false;
                    $('#resendOtp').text('Resend OTP').removeClass('text-muted').css('pointer-events', 'auto');
                }
            }, 1000);
        }

        // Modify the existing resend OTP click handler
        $('#resendOtp').click(function(e) {
            e.preventDefault();
            if (resendCooldown) return;

            const phone = $('#verificationPhone').val();
            const purpose = $('#verificationPurpose').val();

            $.ajax({
                url: '../../api/parent/auth/resend-otp.php',
                type: 'POST',
                data: {
                    phone: phone,
                    purpose: purpose
                },
                dataType: 'json',
                beforeSend: function() {
                    $('#resendOtp').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Sending...');
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        startResendCooldown();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        toastr.error(response.message || 'Unexpected error');
                    } catch (e) {
                        toastr.error('An error occurred. Please try again.');
                    }
                    console.error('Error details:', xhr.responseText);
                },
                complete: function() {
                    if (!resendCooldown) {
                        $('#resendOtp').text('Resend OTP');
                    }
                }
            });
        });

        // Parent Signup Form Submission
        $('#parentSignupForm').submit(function(e) {
            e.preventDefault();
            const phone = $('#signupPhone').val();
            const password = $('#signupPassword').val();
            const confirmPassword = $('#signupConfirmPassword').val();

            if (password !== confirmPassword) {
                toastr.error('Passwords do not match');
                return;
            }

            $.ajax({
                url: '../../api/parent/auth/parent-signup.php',
                type: 'POST',
                data: {
                    phone: phone,
                    password: password
                },
                dataType: 'json',
                beforeSend: function() {
                    $('button[type="submit"]').prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Checking...');
                },
                success: function(response) {

                    if (response.success) {
                        $('#signupForm').hide();
                        $('#otpVerificationForm').show();
                        $('#otpPhoneDisplay').text(phone);
                        $('#verificationPhone').val(phone);
                        $('#verificationPurpose').val('signup');
                        $('#verificationPassword').val(password);
                        toastr.success(response.message);
                        startResendCooldown(); // Add this line
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        toastr.error(response.message || 'Unexpected error');
                    } catch (e) {
                        toastr.error('An error occurred. Please try again.');
                    }
                    console.error('Error details:', xhr.responseText);
                },
                complete: function() {
                    $('button[type="submit"]').prop('disabled', false).text('Send OTP');
                }
            });
        });

        // OTP Verification Form Submission
        $('#verifyOtpForm').submit(function(e) {
            e.preventDefault();
            const formData = $(this).serialize();

            $.ajax({
                url: '../../api/parent/auth/verify-otp.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                beforeSend: function() {
                    $('button[type="submit"]').prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Verifying...');
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        if ($('#verificationPurpose').val() === 'signup') {
                            setTimeout(() => {
                                window.location.href = '../dashboard/parent-dashboard.php';
                            }, 1000);
                        } else {
                            // For password reset, redirect to login
                            setTimeout(() => {
                                window.location.href = 'parent-auth.php';
                            }, 1000);
                        }
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        toastr.error(response.message || 'Unexpected error');
                    } catch (e) {
                        toastr.error('An error occurred. Please try again.');
                    }
                    console.error('Error details:', xhr.responseText);
                },
                complete: function() {
                    $('button[type="submit"]').prop('disabled', false).text('Verify & Complete');
                }
            });
        });
    });

    window.onHcaptchaLoad = function() {
        console.log('hCaptcha loaded via callback');
        // The initialization is already handled in document ready, so this is just a fallback
    };
</script>

<?php include '../../includes/body-close.php'; ?>