<?php
include_once __DIR__ . "/../../includes/parent/auth/parent-auth-check.php";

$authData = getAuthenticatedParent($pdo);

if ($authData) {
    header("Location: ../dashboard/parent-dashboard.php");
    exit;
}

include_once __DIR__ . "/../../includes/header-open.php";
echo "<title>Reset Password - $school_name</title>";
include_once __DIR__ . "/../../includes/header-close.php";
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0 text-center">Reset Password</h4>
                </div>
                <div class="card-body">
                    <!-- Password Reset Request Form -->
                    <div id="resetRequestForm">
                        <h5 class="text-center mb-4">Enter Your Registered Phone Number</h5>
                        <form id="passwordResetForm" autocomplete="off">
                            <div class="mb-3">
                                <label for="resetPhone" class="form-label">Phone Number</label>
                                <input type="text" class="form-control" id="resetPhone" name="phone" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Send OTP</button>
                        </form>
                        <div class="mt-3 text-center">
                            <a href="login.php">Back to Login</a>
                        </div>
                    </div>

                    <!-- New Password Form (hidden by default) -->
                    <div id="newPasswordForm" style="display: none;">
                        <h5 class="text-center mb-4">Set New Password</h5>
                        <p class="text-center">We've sent an OTP to <span id="resetPhoneDisplay"></span></p>
                        <form id="setNewPasswordForm" autocomplete="off">
                            <input type="hidden" id="resetPhoneNumber" name="phone">
                            <div class="mb-3">
                                <label for="newPassword" class="form-label">New Password</label>
                                <input type="password" class="form-control" id="newPassword" name="password" required>
                            </div>
                            <div class="mb-3">
                                <label for="confirmNewPassword" class="form-label">Confirm New Password</label>
                                <input type="password" class="form-control" id="confirmNewPassword" name="confirm_password" required>
                            </div>
                            <div class="mb-3">
                                <label for="resetOtp" class="form-label">OTP</label>
                                <input type="text" class="form-control" id="resetOtp" name="otp" required maxlength="6">
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Reset Password</button>
                        </form>
                        <div class="mt-3 text-center">
                            <a href="#" id="resendResetOtp">Resend OTP</a> |
                            <a href="login.php">Cancel</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        let resendCooldown = false;
        let cooldownInterval;

        function startResendCooldown() {
            resendCooldown = true;
            let seconds = 120; // 2 minutes = 120 seconds
            $('#resendResetOtp').addClass('text-muted').css('pointer-events', 'none');

            cooldownInterval = setInterval(function() {
                seconds--;
                $('#resendResetOtp').text(`Resend OTP (${seconds}s)`);

                if (seconds <= 0) {
                    clearInterval(cooldownInterval);
                    resendCooldown = false;
                    $('#resendResetOtp').text('Resend OTP').removeClass('text-muted').css('pointer-events', 'auto');
                }
            }, 1000);
        }

        // Modify the existing resend OTP click handler
        $('#resendResetOtp').click(function(e) {
            e.preventDefault();
            if (resendCooldown) return;

            const phone = $('#resetPhoneNumber').val();

            $.ajax({
                url: '../../api/parent/auth/resend-otp.php',
                type: 'POST',
                data: {
                    phone: phone,
                    purpose: 'password_reset'
                },
                dataType: 'json',
                beforeSend: function() {
                    $('#resendResetOtp').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Sending...');
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        startResendCooldown();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred. Please try again.');
                },
                complete: function() {
                    if (!resendCooldown) {
                        $('#resendResetOtp').text('Resend OTP');
                    }
                }
            });
        });

        // Password Reset Request Form Submission
        $('#passwordResetForm').submit(function(e) {
            e.preventDefault();
            const phone = $('#resetPhone').val();

            $.ajax({
                url: '../../api/parent/auth/request-password-reset.php',
                type: 'POST',
                data: {
                    phone: phone
                },
                dataType: 'json',
                beforeSend: function() {
                    $('button[type="submit"]').prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Checking...');
                },
                success: function(response) {
                    if (response.success) {
                        $('#resetRequestForm').hide();
                        $('#newPasswordForm').show();
                        $('#resetPhoneDisplay').text(phone);
                        $('#resetPhoneNumber').val(phone);
                        toastr.success(response.message);
                        startResendCooldown(); // Add this line
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred. Please try again.');
                },
                complete: function() {
                    $('button[type="submit"]').prop('disabled', false).text('Send OTP');
                }
            });
        });

        // Set New Password Form Submission
        $('#setNewPasswordForm').submit(function(e) {
            e.preventDefault();
            const password = $('#newPassword').val();
            const confirmPassword = $('#confirmNewPassword').val();

            if (password !== confirmPassword) {
                toastr.error('Passwords do not match');
                return;
            }

            const formData = $(this).serialize();

            $.ajax({
                url: '../../api/parent/auth/reset-password.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                beforeSend: function() {
                    $('button[type="submit"]').prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...');
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        setTimeout(() => {
                            window.location.href = 'login.php';
                        }, 1000);
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred. Please try again.');
                },
                complete: function() {
                    $('button[type="submit"]').prop('disabled', false).text('Reset Password');
                }
            });
        });
    });
</script>

<?php include '../../includes/body-close.php'; ?>