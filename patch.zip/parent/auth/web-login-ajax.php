<?php
include_once(__DIR__ . "/../../includes/config.php");
include_once(__DIR__ . "/../../includes/functions.php");

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(['success' => false, 'message' => 'Invalid request method']));
}

$phone = sanitize_input($_POST['phone'] ?? '');
$otp = sanitize_input($_POST['otp'] ?? '');
$purpose = sanitize_input($_POST['purpose'] ?? 'login');

// Validate inputs
if (empty($phone)) {
    die(json_encode(['success' => false, 'message' => 'Phone number is required']));
}

if (empty($otp)) {
    die(json_encode(['success' => false, 'message' => 'OTP is required']));
}

// Verify OTP
$stmt = $pdo->prepare("SELECT * FROM otp_verification WHERE phone_number = ? AND otp = ? AND purpose = ? AND expiry > NOW() AND verified = 0");
$stmt->execute([$phone, $otp, $purpose]);
$otpRecord = $stmt->fetch();

if (!$otpRecord) {
    die(json_encode(['success' => false, 'message' => 'Invalid or expired OTP']));
}

// Mark OTP as verified
$stmt = $pdo->prepare("UPDATE otp_verification SET verified = 1 WHERE id = ?");
$stmt->execute([$otpRecord['id']]);

if ($purpose === 'login') {
    $session_source = 'web';
    $ip_address = getUserPublicIP();
    $token = generateToken();
    $tokenHash = hash('sha256', $token);
    
    // For web, we can use user agent as a simple identifier instead of device_id/fcm_token
    $device_name = substr($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown Web Browser', 0, 255);
    $device_id = 'web_' . md5($device_name . $ip_address); // Generate a pseudo device ID

    // Delete all sessions that last activity was more than 90 days ago for cleanup
    $stmt = $pdo->prepare("DELETE FROM parent_auth_sessions WHERE last_activity < NOW() - INTERVAL 90 DAY");
    @$stmt->execute();

    // Optionally, we could delete previous web session from this specific device_id to avoid clutter
    $stmt = $pdo->prepare("DELETE FROM parent_auth_sessions WHERE device_id = ? AND session_source = 'web'");
    $stmt->execute([$device_id]);

    // Insert the session
    $stmt = $pdo->prepare("INSERT INTO parent_auth_sessions (phone, token_hash, device_id, device_name, session_source, ip_address) VALUES (?, ?, ?, ?, ?, ?)");
    $insert = $stmt->execute([$phone, $tokenHash, $device_id, $device_name, $session_source, $ip_address]);

    if ($insert) {
        // Set cookie for web (30 days validity)
        setcookie('parent_auth_token', $token, [
            'expires' => time() + (30 * 24 * 60 * 60), 
            'path' => '/', 
            'secure' => isset($_SERVER['HTTPS']), 
            'httponly' => true,
            'samesite' => 'Lax'
        ]);

        // Return success
        $response = [
            'success' => true,
            'message' => 'OTP verified successfully!',
            'phone' => $phone
        ];

        echo json_encode($response);
    } else {
        // Return error
        echo json_encode(['success' => false, 'message' => 'Failed to start session']);
    }

} else {
    echo json_encode(['success' => true, 'message' => 'OTP verified successfully!']);
}
