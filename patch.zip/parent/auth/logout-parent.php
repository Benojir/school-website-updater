<?php
require_once("../../includes/config.php");

// 1. Delete the session from the database (if it exists)
if (!empty($_COOKIE['parent_auth_token'])) {
    $token = $_COOKIE['parent_auth_token'];
    $tokenHash = hash('sha256', $token);
    
    // Use the new table name
    $stmt = $pdo->prepare("DELETE FROM parent_auth_sessions WHERE token_hash = ?");
    $stmt->execute([$tokenHash]);
}

// 2. Expire the cookie by setting its expiry date to the past
setcookie('parent_auth_token', '', [
    'expires' => time() - 3600, // 1 hour ago
    'path' => '/',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

// 3. Clear any old session data just in case
if (session_status() == PHP_SESSION_ACTIVE) {
    session_destroy();
}

// Redirect to login page
header("Location: login.php");
exit();
?>