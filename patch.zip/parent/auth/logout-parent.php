<?php
include_once __DIR__ . '/../../includes/config.php';
include_once __DIR__ . '/../../includes/parent/auth/parent-auth-check.php';

$authData = getAuthenticatedParent($pdo);

if ($authData) {
    // Delete the session from the database
    $stmt = $pdo->prepare("DELETE FROM parent_auth_sessions WHERE id = ?");
    $stmt->execute([$authData['session_id']]);
}

// Clear the cookie
setcookie('parent_auth_token', '', time() - 3600, '/');

header("Location: login.php");
exit();
