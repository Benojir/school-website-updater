<?php
/**@var string $school_name 
 * @var string $theme_color
 * @var array $websiteConfig
*/
include_once(__DIR__ . "/../../includes/parent/auth/parent-auth-check.php");

// Check if user is logged in via session
if (getAuthenticatedParent($pdo)) {
    header("Location: ../dashboard/parent-dashboard.php");
    exit();
}

include_once(__DIR__ . "/../../includes/header-open.php");
?>
<title>Parent Login - <?= $school_name; ?></title>

<style>
    .login-page {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        min-height: 100vh;
    }

    .login-page .card {
        border-radius: 15px;
        border: none;
        overflow: hidden;
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }

    .login-page .card-body {
        padding: 2rem;
    }

    .login-page .form-control {
        padding: 0.75rem 1rem;
        border-radius: 8px;
        border: 1px solid #dee2e6;
        transition: all 0.3s;
    }

    .login-page .form-control:focus {
        border-color: <?= $theme_color; ?>;
        box-shadow: 0 0 0 0.25rem rgba(<?= hexdec(substr($theme_color, 1, 2)) ?>, <?= hexdec(substr($theme_color, 3, 2)) ?>, <?= hexdec(substr($theme_color, 5, 2)) ?>, 0.25);
    }

    .login-page .input-group-text {
        background-color: #f8f9fa;
        border-right: none;
    }

    .login-page .btn-primary {
        padding: 0.75rem;
        border-radius: 8px;
        font-weight: 500;
        transition: all 0.3s;
    }

    .login-page .btn-primary:hover {
        opacity: 0.9;
        transform: translateY(-2px);
    }

    /* Turnstile container styling */
    .turnstile-container {
        display: flex;
        justify-content: center;
        margin: 1rem 0;
    }

    /* Responsive adjustments */
    @media (max-width: 575.98px) {
        .login-page .card-body {
            padding: 1.5rem;
        }

        .turnstile-container {
            transform: scale(0.9);
            transform-origin: center;
        }
    }
</style>

<?php include_once(__DIR__ . "/../../includes/header-close.php"); ?>

<div class="login-page bg-light">
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-8 col-lg-6 col-xl-5">
                <div class="card shadow-sm">
                    <div class="card-body p-4 p-sm-5">
                        <div class="text-center mb-4">
                            <?php if (file_exists('../../uploads/school/logo-square.png')): ?>
                                <img src="<?= $logo_square; ?>" alt="School Logo" class="img-fluid mb-3" style="max-height: 80px;">
                            <?php endif; ?>
                            <h3 class="mb-1"><?= $school_name; ?></h3>
                            <p class="text-muted">Parent Portal Login</p>
                        </div>

                        <!-- Step 1: Request OTP -->
                        <form id="phoneForm" method="post" autocomplete="off">
                            <div class="mb-3">
                                <label for="phone" class="form-label">Registered Mobile Number</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-phone"></i></span>
                                    <input type="tel" class="form-control" id="phone" name="phone" placeholder="Enter mobile number" required pattern="[0-9]{10}">
                                </div>
                                <small class="text-muted">Enter your 10-digit mobile number without country code.</small>
                            </div>

                            <!-- Cloudflare Turnstile -->
                            <div class="turnstile-container">
                                <div class="cf-turnstile" data-sitekey="<?= $websiteConfig['captcha_site_key'] ?>"></div>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary btn-lg" id="sendOtpBtn" style="background-color: <?= $theme_color; ?>; border-color: <?= $theme_color; ?>">
                                    <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                                    Send OTP
                                </button>
                            </div>
                        </form>

                        <!-- Step 2: Verify OTP -->
                        <form id="otpForm" method="post" autocomplete="off" class="d-none">
                            <div class="mb-3">
                                <label for="otp" class="form-label">Enter OTP</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-key"></i></span>
                                    <input type="text" class="form-control" id="otp" name="otp" placeholder="Enter 6-digit OTP" required pattern="[0-9]{6}">
                                </div>
                                <small class="text-muted">An OTP has been sent to <span id="sentPhoneText" class="fw-bold"></span>. <a href="#" id="changePhoneLnk" class="text-decoration-none">Change?</a></small>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary btn-lg" id="verifyOtpBtn" style="background-color: <?= $theme_color; ?>; border-color: <?= $theme_color; ?>">
                                    <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                                    Verify & Login
                                </button>
                            </div>
                        </form>

                    </div>
                </div>

                <div class="text-center mt-3">
                    <p class="text-muted mb-0">© <?= date('Y'); ?> <?= $school_name; ?>. All rights reserved.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    let turnstileWidgetId;

    // Initialize Turnstile when DOM is ready
    function initTurnstile() {
        const container = document.querySelector('.cf-turnstile');

        if (typeof turnstile !== 'undefined' && container && !turnstileWidgetId) {
            try {
                turnstileWidgetId = turnstile.render(container, {
                    sitekey: '<?= $websiteConfig['captcha_site_key'] ?>',
                    theme: 'light',
                    size: 'normal'
                });
                console.log('Turnstile initialized successfully');
            } catch (error) {
                console.error('Turnstile initialization error:', error);
                setTimeout(initTurnstile, 500);
            }
        } else if (typeof turnstile === 'undefined') {
            setTimeout(initTurnstile, 200);
        }
    }

    function resetTurnstile() {
        if (typeof turnstile !== 'undefined' && turnstileWidgetId !== undefined) {
            try {
                turnstile.reset(turnstileWidgetId);
            } catch (error) {
                console.error('Error resetting Turnstile:', error);
            }
        }
    }

    $(document).ready(function() {
        initTurnstile();

        let currentPhone = '';

        // Handle sending OTP
        $('#phoneForm').submit(function(e) {
            e.preventDefault();

            let turnstileResponse = '';
            if (typeof turnstile !== 'undefined' && turnstileWidgetId !== undefined) {
                try {
                    turnstileResponse = turnstile.getResponse(turnstileWidgetId);
                } catch (error) {}
            }

            if (!turnstileResponse) {
                toastr.error('Please complete the captcha verification');
                return;
            }

            const btn = $('#sendOtpBtn');
            btn.prop('disabled', true);
            btn.find('.spinner-border').removeClass('d-none');
            
            const phone = $('#phone').val();

            $.ajax({
                url: '../../api/parent/auth/login.php', // Reusing the mobile API since it just sends OTP
                type: 'POST',
                data: {
                    phone: phone
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        currentPhone = phone;
                        $('#sentPhoneText').text(phone);
                        $('#phoneForm').addClass('d-none');
                        $('#otpForm').removeClass('d-none');
                    } else {
                        toastr.error(response.message);
                        resetTurnstile();
                    }
                },
                error: function(xhr) {
                    toastr.error('An error occurred while sending OTP.');
                    resetTurnstile();
                    console.error(xhr.responseText);
                },
                complete: function() {
                    btn.prop('disabled', false);
                    btn.find('.spinner-border').addClass('d-none');
                }
            });
        });

        // Handle Change Phone
        $('#changePhoneLnk').click(function(e) {
            e.preventDefault();
            $('#otpForm').addClass('d-none');
            $('#phoneForm').removeClass('d-none');
            $('#otp').val('');
            resetTurnstile();
        });

        // Handle verifying OTP
        $('#otpForm').submit(function(e) {
            e.preventDefault();

            const btn = $('#verifyOtpBtn');
            btn.prop('disabled', true);
            btn.find('.spinner-border').removeClass('d-none');
            
            const otp = $('#otp').val();

            $.ajax({
                url: 'web-login-ajax.php',
                type: 'POST',
                data: {
                    phone: currentPhone,
                    otp: otp,
                    purpose: 'login'
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        setTimeout(function() {
                            window.location.href = '../dashboard/parent-dashboard.php';
                        }, 1500);
                    } else {
                        toastr.error(response.message);
                        btn.prop('disabled', false);
                        btn.find('.spinner-border').addClass('d-none');
                    }
                },
                error: function(xhr) {
                    toastr.error('An error occurred. Please try again.');
                    btn.prop('disabled', false);
                    btn.find('.spinner-border').addClass('d-none');
                    console.error(xhr.responseText);
                }
            });
        });
    });
</script>

<?php include_once(__DIR__ . "/../../includes/body-close.php"); ?>
