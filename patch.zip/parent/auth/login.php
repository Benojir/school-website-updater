<?php
include_once __DIR__ . "/../../includes/parent/auth/parent-auth-check.php";

$authData = getAuthenticatedParent($pdo);

if ($authData) {
    header("Location: ../dashboard/parent-dashboard.php");
    exit;
}

include_once __DIR__ . "/../../includes/header-open.php";
echo "<title>Parent Login - $school_name</title>";
include_once __DIR__ . "/../../includes/header-close.php";
?>

<style>
    .adjust-height {
        height: 3rem;
    }
    .logo-container {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    .logo-container img {
        max-width: 100px; /* Adjust size as needed */
        margin-bottom: 1rem;
    }
</style>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-6">
            
            <div class="logo-container">
                <img src="../../uploads/school/logo-square.png" alt="School Logo" onerror="this.style.display='none'">
                <h3 class="fw-bold"><?php echo strtoupper(safe_htmlspecialchars($school_name ?? 'School Name')); ?></h3>
            </div>

            <div class="card shadow rounded-4 overflow-hidden">
                <div class="card-header bg-primary py-3 text-white">
                    <h4 class="mb-0 text-center"><i class="fa-solid fa-user-lock"></i> Parent Login</h4>
                </div>
                <div class="card-body">
                    <div id="loginForm">
                        <h5 class="text-center mb-4">Login to Your Account</h5>
                        <form id="parentLoginForm" autocomplete="off">
                            <div class="mb-3">
                                <label for="loginPhone" class="form-label">Registered Phone Number</label>
                                <div class="input-group">
                                    <span class="input-group-text px-3"><i class="fa-solid fa-phone-flip"></i></span>
                                    <input type="text" class="form-control adjust-height" id="loginPhone" name="phone" placeholder="Enter phone number" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="loginPassword" class="form-label">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text px-3"><i class="fa-solid fa-lock"></i></span>
                                    <input type="password" class="form-control adjust-height" id="loginPassword" name="password" placeholder="Enter password" required>
                                </div>
                            </div>
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="rememberMe" name="remember_me">
                                <label class="form-check-label" for="rememberMe">Remember Me</label>
                            </div>
                            <button type="submit" class="btn btn-primary w-100 adjust-height">Login</button>
                        </form>
                        <div class="mt-3 text-center">
                            <a href="signup.php" class="text-decoration-none">Create new account</a> |
                            <a href="forgot-password.php" class="text-decoration-none">Forgot password?</a>
                        </div>
                    </div>

                    <div class="d-flex justify-content-center">
                        <a href="/" class="text-decoration-none mt-3">
                            <button class="btn btn-sm btn-primary"><i class="fa-solid fa-arrow-left"></i> Back to Home</button>
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

        // Parent Login Form Submission
        $('#parentLoginForm').submit(function(e) {
            e.preventDefault();
            const formData = $(this).serialize();

            $.ajax({
                url: '../../api/parent/auth/web-login.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                beforeSend: function() {
                    $('#parentLoginForm button[type="submit"]').prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Loading...');
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        setTimeout(() => {
                            window.location.href = '../dashboard/parent-dashboard.php';
                        }, 1000);
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred. Please try again.');
                },
                complete: function() {
                    $('#parentLoginForm button[type="submit"]').prop('disabled', false).text('Login');
                }
            });
        });
    });

    window.onHcaptchaLoad = function() {
        console.log('hCaptcha loaded via callback');
    };
</script>

<?php include '../../includes/body-close.php'; ?>