<?php
include_once __DIR__ . "/../../includes/parent/parent-auth-check.php";

$authData = getAuthenticatedParent($pdo);

if ($authData) {
    header("Location: ../dashboard/parent-dashboard.php");
    exit;
}

include_once __DIR__ . "/../../includes/header-open.php";
echo "<title>Parent Sign Up - $school_name</title>";
include_once __DIR__ . "/../../includes/header-close.php";
?>

<style>
    .adjust-height {
        height: 3rem;
    }

    .logo-container {
        text-align: center;
        margin-bottom: 1.5rem;
    }

    .logo-container img {
        max-width: 100px;
        /* Adjust size as needed */
        margin-bottom: 1rem;
    }
</style>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-6">

            <div class="logo-container">
                <img src="../../uploads/school/logo-square.png" alt="School Logo" onerror="this.style.display='none'">
                <h3 class="fw-bold"><?php echo strtoupper(safe_htmlspecialchars($school_name ?? 'School Name')); ?></h3>
            </div>

            <div class="card shadow rounded-4 overflow-hidden">
                <div class="card-header bg-primary py-3 text-white">
                    <h4 class="mb-0 text-center"><i class="fa-solid fa-user-plus"></i> Parent Sign Up</h4>
                </div>
                <div class="card-body">

                    <div id="signupForm">
                        <h5 class="text-center mb-4">Create New Account</h5>
                        <form id="parentSignupForm" autocomplete="off">
                            <div class="mb-3">
                                <label for="signupPhone" class="form-label">Registered Phone Number</label>
                                <div class="input-group">
                                    <span class="input-group-text px-3"><i class="fa-solid fa-phone-flip"></i></span>
                                    <input type="text" class="form-control adjust-height" id="signupPhone" name="phone" placeholder="Enter phone number" required>
                                </div>
                                <small class="text-muted">Must match the phone number registered with student records</small>
                            </div>
                            <div class="mb-3">
                                <label for="signupPassword" class="form-label">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text px-3"><i class="fa-solid fa-lock"></i></span>
                                    <input type="password" class="form-control adjust-height" id="signupPassword" name="password" placeholder="Enter new password" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="signupConfirmPassword" class="form-label">Confirm Password</label>
                                <div class="input-group">
                                    <span class="input-group-text px-3"><i class="fa-solid fa-lock"></i></span>
                                    <input type="password" class="form-control adjust-height" id="signupConfirmPassword" name="confirm_password" placeholder="Enter confirm password" required>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary w-100 adjust-height">Send OTP</button>
                        </form>
                        <div class="mt-3 text-center">
                            <a href="login.php" class="text-decoration-none">Back to Login</a>
                        </div>
                    </div>

                    <div id="otpVerificationForm" style="display: none;">
                        <h5 class="text-center mb-4">Verify OTP</h5>
                        <p class="text-center">We've sent an OTP to <span id="otpPhoneDisplay"></span></p>
                        <form id="verifyOtpForm" autocomplete="off">
                            <input type="hidden" id="verificationPhone" name="phone">
                            <input type="hidden" id="verificationPurpose" name="purpose">
                            <input type="hidden" id="verificationPassword" name="password">
                            <div class="mb-3">
                                <label for="otpCode" class="form-label">Enter OTP</label>
                                <div class="input-group">
                                    <span class="input-group-text px-3"><i class="fa-solid fa-mobile-screen"></i></span>
                                    <input type="text" class="form-control adjust-height" id="otpCode" name="otp" required maxlength="6">
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary w-100 adjust-height">Verify & Complete</button>
                        </form>
                        <div class="mt-3 text-center">
                            <a href="#" id="resendOtp" class="text-decoration-none">Resend OTP</a> |
                            <a href="#" id="cancelVerification" class="text-decoration-none">Cancel</a>
                        </div>
                    </div>

                    <div class="d-flex justify-content-center">
                        <a href="/" class="text-decoration-none mt-3">
                            <button class="btn btn-sm btn-primary"><i class="fa-solid fa-arrow-left"></i> Back to Home</button>
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {

        // Cancel verification
        $('#cancelVerification').click(function(e) {
            e.preventDefault();
            $('#otpVerificationForm').hide();
            $('#signupForm').show();
        });

        // Resend OTP cooldown timer
        let resendCooldown = false;
        let cooldownInterval;

        function startResendCooldown() {
            resendCooldown = true;
            let seconds = 120; // 2 minutes = 120 seconds
            $('#resendOtp').addClass('text-muted').css('pointer-events', 'none');

            cooldownInterval = setInterval(function() {
                seconds--;
                $('#resendOtp').text(`Resend OTP (${seconds}s)`);

                if (seconds <= 0) {
                    clearInterval(cooldownInterval);
                    resendCooldown = false;
                    $('#resendOtp').text('Resend OTP').removeClass('text-muted').css('pointer-events', 'auto');
                }
            }, 1000);
        }

        // Resend OTP click handler
        $('#resendOtp').click(function(e) {
            e.preventDefault();
            if (resendCooldown) return;

            const phone = $('#verificationPhone').val();
            const purpose = $('#verificationPurpose').val();

            $.ajax({
                url: '../../api/parent/auth/resend-otp.php',
                type: 'POST',
                data: {
                    phone: phone,
                    purpose: purpose
                },
                dataType: 'json',
                beforeSend: function() {
                    $('#resendOtp').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Sending...');
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        startResendCooldown();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        toastr.error(response.message || 'Unexpected error');
                    } catch (e) {
                        toastr.error('An error occurred. Please try again.');
                    }
                    console.error('Error details:', xhr.responseText);
                },
                complete: function() {
                    if (!resendCooldown) {
                        $('#resendOtp').text('Resend OTP');
                    }
                }
            });
        });

        // Parent Signup Form Submission
        $('#parentSignupForm').submit(function(e) {
            e.preventDefault();
            const phone = $('#signupPhone').val();
            const password = $('#signupPassword').val();
            const confirmPassword = $('#signupConfirmPassword').val();

            if (password !== confirmPassword) {
                toastr.error('Passwords do not match');
                return;
            }

            $.ajax({
                url: '../../api/parent/auth/parent-signup.php',
                type: 'POST',
                data: {
                    phone: phone,
                    password: password
                },
                dataType: 'json',
                beforeSend: function() {
                    $('#parentSignupForm button[type="submit"]').prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Checking...');
                },
                success: function(response) {
                    if (response.success) {
                        $('#signupForm').hide();
                        $('#otpVerificationForm').show();
                        $('#otpPhoneDisplay').text(phone);
                        $('#verificationPhone').val(phone);
                        $('#verificationPurpose').val('signup');
                        $('#verificationPassword').val(password);
                        toastr.success(response.message);
                        startResendCooldown();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        toastr.error(response.message || 'Unexpected error');
                    } catch (e) {
                        toastr.error('An error occurred. Please try again.');
                    }
                    console.error('Error details:', xhr.responseText);
                },
                complete: function() {
                    $('#parentSignupForm button[type="submit"]').prop('disabled', false).text('Send OTP');
                }
            });
        });

        // OTP Verification Form Submission
        $('#verifyOtpForm').submit(function(e) {
            e.preventDefault();
            const formData = $(this).serialize();

            $.ajax({
                url: '../../api/parent/auth/verify-otp.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                beforeSend: function() {
                    $('#verifyOtpForm button[type="submit"]').prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Verifying...');
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        // Show sweetalert2 success message
                        Swal.fire({
                            title: 'Success!',
                            text: `${response.message} Now you can log in with your credentials.`,
                            icon: 'success',
                            confirmButtonText: 'OK',
                            customClass: {
                                confirmButton: 'btn btn-primary',
                                popup: 'rounded-4'
                            },
                        }).then((result) => {
                            if (result.isConfirmed) {
                                // Redirect to login page after successful signup
                                window.location.href = 'login.php';
                            }
                        });
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        toastr.error(response.message || 'Unexpected error');
                    } catch (e) {
                        toastr.error('An error occurred. Please try again.');
                    }
                    console.error('Error details:', xhr.responseText);
                },
                complete: function() {
                    $('#verifyOtpForm button[type="submit"]').prop('disabled', false).text('Verify & Complete');
                }
            });
        });
    });

    window.onHcaptchaLoad = function() {
        console.log('hCaptcha loaded via callback');
    };
</script>

<?php include '../../includes/body-close.php'; ?>