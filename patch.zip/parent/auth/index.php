<?php
// header('Location: login.php');
header('Location: /apps/parent/');