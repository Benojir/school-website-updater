<?php
require_once("../../includes/config.php");

// Unset all session variables
$_SESSION = array();

// Destroy the session
unset($_SESSION['parent_logged_in']);
unset($_SESSION['parent_phone']);

// Delete the remember me cookie if it exists
if (isset($_COOKIE['parent_remember_token'])) {
    // Also clear the token from database
    $token = $_COOKIE['parent_remember_token'];
    $pdo->prepare("UPDATE parent_accounts SET remember_token = NULL, token_expiry = NULL WHERE remember_token = ?")
        ->execute([$token]);
    
    setcookie('parent_remember_token', '', time() - 3600, '/');
}

// Redirect to login page
header("Location: parent-auth.php");
exit();
?>