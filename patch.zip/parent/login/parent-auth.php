<?php include '../../includes/header-open.php'; ?>
<title>Parent Portal - <?php echo $school_name; ?></title>
<?php
include '../../includes/header-close.php';

if (isParentAuthenticated()) {
    echo '<script>location.replace("../dashboard/parent-dashboard.php");</script>';
    exit;
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0 text-center">Parent Portal</h4>
                </div>
                <div class="card-body">
                    <!-- Login Form -->
                    <div id="loginForm">
                        <h5 class="text-center mb-4">Login to Your Account</h5>
                        <form id="parentLoginForm" autocomplete="off">
                            <div class="mb-3">
                                <label for="loginPhone" class="form-label">Registered Phone Number</label>
                                <input type="text" class="form-control" id="loginPhone" name="phone" required>
                            </div>
                            <div class="mb-3">
                                <label for="loginPassword" class="form-label">Password</label>
                                <input type="password" class="form-control" id="loginPassword" name="password" required>
                            </div>
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="rememberMe" name="remember_me">
                                <label class="form-check-label" for="rememberMe">Remember Me</label>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Login</button>
                        </form>
                        <div class="mt-3 text-center">
                            <a href="#" id="showSignup">Create New Account</a> |
                            <a href="forgot-password.php">Forgot Password?</a>
                        </div>
                    </div>

                    <!-- Signup Form (hidden by default) -->
                    <div id="signupForm" style="display: none;">
                        <h5 class="text-center mb-4">Create New Account</h5>
                        <form id="parentSignupForm" autocomplete="off">
                            <div class="mb-3">
                                <label for="signupPhone" class="form-label">Registered Phone Number</label>
                                <input type="text" class="form-control" id="signupPhone" name="phone" required>
                                <small class="text-muted">Must match the phone number registered with student records</small>
                            </div>
                            <div class="mb-3">
                                <label for="signupPassword" class="form-label">Password</label>
                                <input type="password" class="form-control" id="signupPassword" name="password" required>
                            </div>
                            <div class="mb-3">
                                <label for="signupConfirmPassword" class="form-label">Confirm Password</label>
                                <input type="password" class="form-control" id="signupConfirmPassword" name="confirm_password" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Send OTP</button>
                        </form>
                        <div class="mt-3 text-center">
                            <a href="#" id="showLogin">Back to Login</a>
                        </div>
                    </div>

                    <!-- OTP Verification Form (hidden by default) -->
                    <div id="otpVerificationForm" style="display: none;">
                        <h5 class="text-center mb-4">Verify OTP</h5>
                        <p class="text-center">We've sent an OTP to <span id="otpPhoneDisplay"></span></p>
                        <form id="verifyOtpForm" autocomplete="off">
                            <input type="hidden" id="verificationPhone" name="phone">
                            <input type="hidden" id="verificationPurpose" name="purpose">
                            <input type="hidden" id="verificationPassword" name="password">
                            <div class="mb-3">
                                <label for="otpCode" class="form-label">Enter OTP</label>
                                <input type="text" class="form-control" id="otpCode" name="otp" required maxlength="6">
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Verify & Complete</button>
                        </form>
                        <div class="mt-3 text-center">
                            <a href="#" id="resendOtp">Resend OTP</a> |
                            <a href="#" id="cancelVerification">Cancel</a>
                        </div>
                    </div>

                    <div class="d-flex justify-content-center">
                        <a href="/" class="text-decoration-none mt-5">
                            <button class="btn btn-sm btn-primary"><i class="fa-solid fa-arrow-left"></i> Back to Home</button>
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Toggle between login and signup forms
        $('#showSignup').click(function(e) {
            e.preventDefault();
            $('#loginForm').hide();
            $('#signupForm').show();
        });

        $('#showLogin').click(function(e) {
            e.preventDefault();
            $('#signupForm').hide();
            $('#otpVerificationForm').hide();
            $('#loginForm').show();
        });

        // Cancel verification
        $('#cancelVerification').click(function(e) {
            e.preventDefault();
            $('#otpVerificationForm').hide();
            if ($('#verificationPurpose').val() === 'signup') {
                $('#signupForm').show();
            } else {
                $('#loginForm').show();
            }
        });

        // Parent Login Form Submission
        $('#parentLoginForm').submit(function(e) {
            e.preventDefault();
            const formData = $(this).serialize();

            $.ajax({
                url: '../ajax/parent-login.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                beforeSend: function() {
                    $('button[type="submit"]').prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Loading...');
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        setTimeout(() => {
                            window.location.href = '../dashboard/parent-dashboard.php';
                        }, 1000);
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    toastr.error('An error occurred. Please try again.');
                },
                complete: function() {
                    $('button[type="submit"]').prop('disabled', false).text('Login');
                }
            });
        });

        // Resend OTP cooldown timer
        let resendCooldown = false;
        let cooldownInterval;

        function startResendCooldown() {
            resendCooldown = true;
            let seconds = 120; // 2 minutes = 120 seconds
            $('#resendOtp').addClass('text-muted').css('pointer-events', 'none');

            cooldownInterval = setInterval(function() {
                seconds--;
                $('#resendOtp').text(`Resend OTP (${seconds}s)`);

                if (seconds <= 0) {
                    clearInterval(cooldownInterval);
                    resendCooldown = false;
                    $('#resendOtp').text('Resend OTP').removeClass('text-muted').css('pointer-events', 'auto');
                }
            }, 1000);
        }

        // Modify the existing resend OTP click handler
        $('#resendOtp').click(function(e) {
            e.preventDefault();
            if (resendCooldown) return;

            const phone = $('#verificationPhone').val();
            const purpose = $('#verificationPurpose').val();

            $.ajax({
                url: '../ajax/resend-otp.php',
                type: 'POST',
                data: {
                    phone: phone,
                    purpose: purpose
                },
                dataType: 'json',
                beforeSend: function() {
                    $('#resendOtp').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Sending...');
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        startResendCooldown();
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        toastr.error(response.message || 'Unexpected error');
                    } catch (e) {
                        toastr.error('An error occurred. Please try again.');
                    }
                    console.error('Error details:', xhr.responseText);
                },
                complete: function() {
                    if (!resendCooldown) {
                        $('#resendOtp').text('Resend OTP');
                    }
                }
            });
        });

        // Parent Signup Form Submission
        $('#parentSignupForm').submit(function(e) {
            e.preventDefault();
            const phone = $('#signupPhone').val();
            const password = $('#signupPassword').val();
            const confirmPassword = $('#signupConfirmPassword').val();

            if (password !== confirmPassword) {
                toastr.error('Passwords do not match');
                return;
            }

            $.ajax({
                url: '../ajax/parent-signup.php',
                type: 'POST',
                data: {
                    phone: phone,
                    password: password
                },
                dataType: 'json',
                beforeSend: function() {
                    $('button[type="submit"]').prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Checking...');
                },
                success: function(response) {

                    if (response.success) {
                        $('#signupForm').hide();
                        $('#otpVerificationForm').show();
                        $('#otpPhoneDisplay').text(phone);
                        $('#verificationPhone').val(phone);
                        $('#verificationPurpose').val('signup');
                        $('#verificationPassword').val(password);
                        toastr.success(response.message);
                        startResendCooldown(); // Add this line
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        toastr.error(response.message || 'Unexpected error');
                    } catch (e) {
                        toastr.error('An error occurred. Please try again.');
                    }
                    console.error('Error details:', xhr.responseText);
                },
                complete: function() {
                    $('button[type="submit"]').prop('disabled', false).text('Send OTP');
                }
            });
        });

        // OTP Verification Form Submission
        $('#verifyOtpForm').submit(function(e) {
            e.preventDefault();
            const formData = $(this).serialize();

            $.ajax({
                url: '../ajax/verify-otp.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                beforeSend: function() {
                    $('button[type="submit"]').prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Verifying...');
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.message);
                        if ($('#verificationPurpose').val() === 'signup') {
                            setTimeout(() => {
                                window.location.href = '../dashboard/parent-dashboard.php';
                            }, 1000);
                        } else {
                            // For password reset, redirect to login
                            setTimeout(() => {
                                window.location.href = 'parent-auth.php';
                            }, 1000);
                        }
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        toastr.error(response.message || 'Unexpected error');
                    } catch (e) {
                        toastr.error('An error occurred. Please try again.');
                    }
                    console.error('Error details:', xhr.responseText);
                },
                complete: function() {
                    $('button[type="submit"]').prop('disabled', false).text('Verify & Complete');
                }
            });
        });
    });

    window.onHcaptchaLoad = function() {
        console.log('hCaptcha loaded via callback');
        // The initialization is already handled in document ready, so this is just a fallback
    };
</script>

<?php include '../../includes/body-close.php'; ?>