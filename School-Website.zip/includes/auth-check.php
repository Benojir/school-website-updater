<?php
include_once 'config.php';

/**
 * Authenticates a admin request from either Mobile (Bearer Token) or Web (Cookie).
 *
 * @param PDO $pdo The database connection.
 * @return array|null The authenticated admin/session data, or null if not authenticated.
 */
function getAuthenticatedAdmin($pdo) {
    $token = null;
    $headers = getallheaders();

    // 1. Check for Mobile App's Bearer Token
    if (!empty($headers['Authentication']) && strpos($headers['Authentication'], 'Bearer ') === 0) {
        $token = str_replace('Bearer ', '', $headers['Authentication']);
    }
    
    // 2. If no Bearer token, check for Web's Auth Cookie
    if (empty($token) && !empty($_COOKIE['admin_auth_token'])) {
        $token = $_COOKIE['admin_auth_token'];
    }

    // 3. If no token found, user is not logged in
    if (empty($token)) {
        return null; 
    }

    // 4. Validate the token against the database
    $tokenHash = hash('sha256', $token);
    $currentDateTime = date('Y-m-d H:i:s');

    // Use the NEW table name 'admin_auth_sessions'
    $stmt = $pdo->prepare("SELECT * FROM admin_auth_sessions WHERE token_hash = ? AND expires_at > ?");
    $stmt->execute([$tokenHash, $currentDateTime]);
    $session = $stmt->fetch();

    if (!$session) {
        return null; // Invalid or expired token
    }

    // 5. Refresh last activity timestamp on activity
    $stmt = $pdo->prepare("UPDATE admin_auth_sessions SET last_activity = NOW() WHERE id = ?");
    $stmt->execute([$session['id']]);

    // Return all relevant admin and session data
    return [
        'success' => true,
        'message' => 'Token successfully validated',
        'user_id' => $session['user_id'],
        'user_role' => $session['user_role'],
        'username' => $session['username'],
        'full_name' => $session['full_name'],
        'session_id' => $session['id'],
        'device_id' => $session['device_id'],
        'session_source' => $session['session_source']
    ];
}

/**
 * A helper function for protected API endpoints (Mobile or Web AJAX).
 * It calls getAuthenticatedAdmin and exits with a 401 error if auth fails.
 *
 * @param PDO $pdo
 * @return array The authenticated admin data.
 */
function authenticateAdminApiRequest($pdo) {
    $authData = getAuthenticatedAdmin($pdo);
    
    if (!$authData) {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Unauthorized: Invalid or expired token']);
        exit;
    }
    
    return $authData;
}

/**
 * Check if any admin is logged in
 */
function isAnyAdminLoggedIn() {
    global $pdo;
    $authData = getAuthenticatedAdmin($pdo);

    if (!$authData) {
        return false;
    } else {
        return true;
    }
}

/**
 * Check if logged-in admin is a super admin
 */
function isSuperAdmin() {
    global $pdo;
    $authData = getAuthenticatedAdmin($pdo);
    
    if ($authData && $authData['user_role'] === 'superadmin') {
        return true;
    }
    return false;
}

/**
 * Check if admin has access to the requested permission
 */
function hasPermission($permission) {
    global $pdo;
    $authData = getAuthenticatedAdmin($pdo);
    
    if (!$authData) {
        return false;
    }


    // Super admin has all permissions
    if ($authData['user_role'] === 'superadmin') {
        return true;
    }
    
    // Check if user is admin
    if ($authData['user_role'] !== 'admin') {
        return false;
    }
    
    try {
        $stmt = $pdo->prepare("
            SELECT 1 FROM admin_permissions p
            JOIN admin_roles r ON p.role_id = r.id
            JOIN users u ON u.role_id = r.id
            WHERE u.id = ? AND p.permission = ?
            LIMIT 1
        ");
        $stmt->execute([$authData['user_id'], $permission]);
        return (bool)$stmt->fetch();
    } catch (PDOException $e) {
        error_log("Permission check error: " . $e->getMessage());
        return false;
    }
}

// Common permission constants
define('PERM_MANAGE_STUDENTS', 'manage_students');
define('PERM_MANAGE_TEACHERS', 'manage_teachers');
define('PERM_MANAGE_RESULTS', 'manage_results');
define('PERM_MANAGE_CLASS_ROUTINES', 'manage_class_routines');
define('PERM_MANAGE_FEES', 'manage_fees');
define('PERM_MANAGE_NOTICES', 'manage_notices');
define('PERM_MANAGE_EXAMS', 'manage_exams');
define('PERM_MANAGE_SCHOOL_GALLERY', 'manage_school_gallery');
define('PERM_MANAGE_STUDENTS_ATTENDANCE', 'manage_students_attendance');
define('PERM_MANAGE_TEACHERS_ATTENDANCE', 'manage_teachers_attendance');
define('PERM_MANAGE_TRANSPORT', 'manage_transport');