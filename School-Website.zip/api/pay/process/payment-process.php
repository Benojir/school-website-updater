<?php
// payment_process.php
require_once('../includes/config.php');
require_once('../vendor/autoload.php'); // Include Razorpay library

use Razorpay\Api\Api;

$keyId = $websiteConfig['razorpay_key_id'];
$keySecret = $websiteConfig['razorpay_key_secret'];
$displayCurrency = 'INR';

// Get form data
if (
    !isset($_REQUEST['id']) || empty($_REQUEST['id']) || !is_numeric($_REQUEST['id'])
    || !isset($_REQUEST['type']) || empty($_REQUEST['type'])
) {
    die('Invalid request');
}

$unpaid_fee_id = trim($_REQUEST['id']);
$fee_type = trim($_REQUEST['type']);

if (!in_array($fee_type, ['admission-fee', 'monthly-fee'])) {
    die('Invalid payment request.');
}

// Fetch unpaid fees data
$unpaid_fee_data = null;

if ($fee_type == "admission-fee") {
    // Fetch unpaid admission fees data
    $stmt = $pdo->prepare("
        SELECT student_admission_fees.*, students.*
        FROM student_admission_fees
        LEFT JOIN students ON students.student_id = student_admission_fees.student_id
        WHERE student_admission_fees.id = ? AND student_admission_fees.payment_status = 'unpaid' LIMIT 1
    ");
    $stmt->execute([$unpaid_fee_id]);
    $unpaid_fee_data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (empty($unpaid_fee_data)) {
        die('No unpaid fees found.');
    }
} else if ($fee_type == "monthly-fee") {
    // Fetch unpaid fees data
    $stmt = $pdo->prepare("
        SELECT student_unpaid_fees.*, students.*
        FROM student_unpaid_fees
        LEFT JOIN students ON students.student_id = student_unpaid_fees.student_id
        WHERE student_unpaid_fees.id = ? LIMIT 1
    ");
    $stmt->execute([$unpaid_fee_id]);
    $unpaid_fee_data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (empty($unpaid_fee_data)) {
        die('No unpaid fees found.');
    }
} else {
    die('Invalid request. No fee type provided.');
}

if (empty($unpaid_fee_data)) {
    die('<center><h1">No unpaid fees found.</h1></center>');
}

$unpaid_amount = $unpaid_fee_data['unpaid_amount'];
$rzp_charge = $unpaid_amount * $websiteConfig['razorpay_charge_percentage'] / 100;
$gst_charge = $rzp_charge * $websiteConfig['gst_on_razorpay_charge'] / 100;

$total_amount = ($unpaid_amount + $rzp_charge + $gst_charge) * 100; // in paisa

$student_name = $unpaid_fee_data['name'];
$student_id = $unpaid_fee_data['student_id'];
$fee_description = $unpaid_fee_data['remark'];

$api = new Api($keyId, $keySecret);

// Create order
$orderData = [
    'receipt'         => 'RCPT_' . time(),
    'amount'          => $total_amount, // 2000 rupees = 200000 paise
    'currency'        => 'INR',
    'payment_capture' => 1 // auto capture
];

$_SESSION['amount'] = $total_amount / 100;

try {
    $razorpayOrder = $api->order->create($orderData);
    $razorpayOrderId = $razorpayOrder['id'];
    $_SESSION['razorpay_order_id'] = $razorpayOrderId;

    // Store in database (you'll need to implement this)
    // saveOrderToDatabase($razorpayOrderId, $total_amount, $student_id, $fee_description);

    $displayAmount = $total_amount / 100; // Convert to rupees

    $data = [
        "key"               => $keyId,
        "amount"            => $total_amount,
        "name"              => $schoolInfo['name'],
        "description"       => $fee_description,
        "image"             => "../uploads/school/logo-square.png",
        "prefill"           => [
            "name"          => $student_name,
            "email"        => $schoolInfo['email'],
            "contact"       => $schoolInfo['phone'],
        ],
        "notes"             => [
            "student_id"    => $student_id,
            "fee_type"      => $fee_description,
        ],
        "theme"             => [
            "color"         => $theme_color
        ],
        "order_id"          => $razorpayOrderId,
    ];

    $json = json_encode($data);
} catch (Exception $e) {
    die('Error: ' . $e->getMessage());
}
?>

<!-- Razorpay Checkout form - Auto submits -->
<form action="payment-verify.php" method="POST" id="razorpay-form">
    <input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id">
    <input type="hidden" name="razorpay_order_id" id="razorpay_order_id" value="<?php echo $razorpayOrderId; ?>">
    <input type="hidden" name="razorpay_signature" id="razorpay_signature">
    <input type="hidden" name="unpaid_fee_id" value="<?php echo $unpaid_fee_id; ?>">
    <input type="hidden" name="type" value="<?php echo $fee_type; ?>">
</form>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
    var options = <?php echo $json; ?>;

    options.handler = function(response) {
        document.getElementById('razorpay_payment_id').value = response.razorpay_payment_id;
        document.getElementById('razorpay_order_id').value = response.razorpay_order_id;
        document.getElementById('razorpay_signature').value = response.razorpay_signature;
        document.getElementById('razorpay-form').submit();
    };

    options.modal = {
        ondismiss: function() {
            window.location.href = 'payment-failed.php';
        }
    };

    var rzp = new Razorpay(options);
    rzp.open();
</script>