<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user has permission to perform this action
if (!hasPermission(PERM_MANAGE_FEES)) {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have permission to perform this action.',
        'error' => true
    ]);
    die();
}

if (!isset($_POST['entry_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unpaid Fee ID is required']);
    exit;
}

$entry_id = $_POST['entry_id'];

if (!is_numeric($entry_id)) {
    echo json_encode(['success' => false, 'message' => 'Invalid Unpaid Fee ID']);
    exit;
}

// Prepare and execute the delete statement
$stmt = $pdo->prepare("DELETE FROM admission_unpaid_fees WHERE id = :entry_id");
$stmt->bindParam(':entry_id', $entry_id, PDO::PARAM_INT);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Unpaid Admission Fee entry deleted successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to delete Unpaid Admission Fee entry']);
}