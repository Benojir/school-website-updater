<?php
// Check if user is logged in
include_once(__DIR__ . "/../../../../includes/auth-check.php");

header('Content-Type: application/json');

// Check if user is superadmin only
if (!isSuperAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Permission denied']);
    exit();
}

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $class_id = isset($_POST['class_id']) ? (int)$_POST['class_id'] : 0;
        $amount = isset($_POST['amount']) ? trim($_POST['amount']) : 0;

        // Validate inputs
        if (empty($amount) || empty($class_id)) {
            throw new Exception('Please fill in all fields');
        }

        // Get class name
        $stmt = $pdo->prepare("SELECT class_name FROM classes WHERE id = ?");
        $stmt->execute([$class_id]);
        $class = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$class) {
            throw new Exception('Invalid class selected');
        }

        $class_name = $class['class_name'];

        // Check for duplicate entry
        $check = $pdo->prepare("SELECT id FROM class_wise_monthly_fees WHERE class_id = ?");
        $check->execute([$class_id]);

        if ($check->rowCount() > 0) {
            throw new Exception('Class fee already exist. If you want to update it then first delete the class fee.');
        }

        // Insert new subject
        $insert = $pdo->prepare("INSERT INTO class_wise_monthly_fees (class_id, amount) VALUES (?, ?)");
        if ($insert->execute([$class_id, $amount])) {
            $response['success'] = true;
            $response['message'] = 'Class fee added successfully';
        } else {
            throw new Exception('Failed to add class fee to database');
        }
    } else {
        throw new Exception('Invalid request method');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);